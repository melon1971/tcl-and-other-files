# aisentryd

A 24/7 background security monitor for Debian: continuous fail2ban-style
SSH auth monitoring and denied-connection logging, plus idle-aware
malware/vuln/hardening scans that only run when the machine isn't busy,
with AI-written plain-English explanations and two narrow automatic
remediations.

## Two tiers of work

**Always on, negligible overhead** (every `POLL_INTERVAL_SECONDS`, default
30s):
- Polls the systemd journal incrementally for SSH logins. A source that
  racks up `AUTH_FAIL_THRESHOLD` failed logins within
  `AUTH_FAIL_WINDOW_SECONDS` gets banned with `ufw insert deny`
  (fail2ban-equivalent), auto-unbanned after `AUTH_BAN_SECONDS`. Successful
  logins are logged too.
- Surfaces ufw's own kernel-log denials (`[UFW BLOCK]`) - denied
  connections - independent of whether `sentryd` (packet-level port-scan
  detection) is also installed.
- All of it lands in a running, condensed event log
  (`REPORT_DIR/events.log` by default) - `aisentryctl tail` reads it.

**Only when the machine is idle** (heavy, would otherwise bottleneck
interactive use):

| tool        | what it catches                                   |
|-------------|----------------------------------------------------|
| `rkhunter`  | rootkits, backdoors, suspicious file changes        |
| `lynis`     | general hardening gaps (SSH config, sysctl, etc.)   |
| `clamscan`  | malware in files (`SCAN_PATHS`, or `/` if FULL_SCAN)|
| `debsecan`  | CVEs affecting your *currently installed* packages  |

All four are standard Debian-archive tools - aisentryd doesn't reimplement
any scanning logic itself, it orchestrates them and structures the output.
A scan starts only once the system has been continuously idle for
`IDLE_THRESHOLD_SECONDS` (default 5 minutes - checked via systemd-logind
session idle hints plus a load-average ceiling) and at least
`SCAN_INTERVAL_SECONDS` (default 6h) has passed since the last one. Every
scanner subprocess runs niced and at idle I/O priority regardless, so an
in-flight scan stays unobtrusive even if you start using the machine again
partway through it - it isn't interrupted, but it also shouldn't be
noticeable.

## What it does with scan results

1. Every finding becomes one record: `{source, severity, id, summary,
   detail, path, fixable_auto, fix_command, auto_fixed}` (`path` is only
   set for clamav findings, where there's an actual file involved).
2. If `SEND_TO_AI=1`, the findings (structured metadata only - **never raw
   file contents**) are sent to an AI backend asking for a plain-English
   explanation and the exact fix command for each, grouped by severity.
   **The model's reply is only ever used as report text - nothing it says
   is executed.** Two backends:
   - `AI_PROVIDER=anthropic` (default) - the Anthropic API, needs
     `ANTHROPIC_API_KEY`. Paid, cloud.
   - `AI_PROVIDER=ollama` - a free, fully local model via
     [Ollama](https://ollama.com). Install once:
     ```sh
     curl -fsSL https://ollama.com/install.sh | sh
     ollama pull llama3.1
     ```
     then set `AI_PROVIDER=ollama` in `aisentryd.conf`. Zero API cost,
     nothing leaves the machine. Any Ollama-served model works
     (`llama3.2`, `mistral`, `qwen2.5`, ...) - pick one that fits your
     RAM; `llama3.1` (8B) is a reasonable default on a typical desktop.
   - `AI_PROVIDER=none` (or `SEND_TO_AI=0`) skips the AI step outright.

   Without a working AI backend it falls back to a grouped listing built
   from the deterministic fix commands aisentryd already attached to each
   finding, so the tool is fully useful offline either way.
3. Exactly two kinds of automatic fix exist, both off by default:
   - `AUTO_FIX_UPDATES=1` - run `unattended-upgrade` (scoped to the
     security origin by its own standard config) when debsecan finds a
     CVE.
   - `AUTO_QUARANTINE_MALWARE=1` - **move** (never delete) a
     clamscan-flagged file into `QUARANTINE_DIR`, mirroring its original
     path underneath (`/home/x/bad.exe` -> `QUARANTINE_DIR/home/x/bad.exe`)
     so it can be found again or restored. Never follows a symlink, and
     never touches a path outside what this run actually scanned.
   Everything else - rkhunter and lynis findings especially - is always
   report-only with a suggested command; they're too varied and
   context-dependent to fix unattended.
4. Writes `REPORT_DIR/<timestamp>/report.md` plus the raw tool output
   under `raw/`, and updates `REPORT_DIR/latest-report.md`.
5. A best-effort desktop notification (`notify-send`, into whichever
   graphical session logind reports as active) fires when a scan finds
   something, an automatic fix/quarantine runs, or a source gets banned -
   "what the AI agent did", visible without opening a report. Silently
   does nothing on a headless box.

## Report format

```
# aisentryd security report - 2026-09-22 20:42:08 -0500

| severity | count |
|---|---|
| critical | 1 |
| high | 3 |

## Tool status
- rkhunter: rc=0, 2 warning(s)
...

## Automatic fixes applied this run
- quarantined /var/www/html/shell.php (Php.Trojan.Generic-1234) -> /var/lib/aisentryd/quarantine/var/www/html/shell.php

## Findings and recommended fixes
### CRITICAL (1)
- **[clamav]** malware found: Php.Trojan.Generic-1234
  fix: `quarantine ...`
...

## Raw findings (JSON)
[ ... ]
```

## Installing

A prebuilt `aisentryd_2.0-2_all.deb` is provided alongside this source
tree - it's pure Python plus config/systemd files (no compiled binary), so
unlike a C package there's no ABI/glibc-version concern in shipping it
prebuilt:

```sh
sudo apt-get install ./aisentryd_2.0-2_all.deb
```

This pulls in `rkhunter`, `lynis`, `clamav`, `clamav-freshclam`,
`debsecan`, `unattended-upgrades` and `systemd` as dependencies, and
recommends `ufw` (needed for the fail2ban-style banning to actually block
anything - without it, monitoring/logging still works, just not blocking)
and `libnotify-bin` (desktop notifications). To build it yourself from the
source tree instead:

```sh
sudo apt-get install build-essential debhelper
dpkg-buildpackage -us -uc -b
sudo apt-get install ../aisentryd_2.0-2_all.deb
```

## Configuring

Edit `/etc/aisentryd/aisentryd.conf` (0600, root-only - it can hold your
API key):

```
AI_PROVIDER=anthropic          # or "ollama" for a free local model
ANTHROPIC_API_KEY=sk-ant-...
SEND_TO_AI=1
REPORT_DIR=/home/smullen/security-reports
IDLE_THRESHOLD_SECONDS=300
SCAN_INTERVAL_SECONDS=21600
AUTH_FAIL_THRESHOLD=5
AUTO_FIX_UPDATES=0
AUTO_QUARANTINE_MALWARE=0
```

See the shipped config for every setting (idle/scheduling, auth
monitoring, scan paths, timeouts, retention, which tools to run, etc.)
with inline comments. A change to this file takes effect on the daemon's
next poll tick - no restart needed, including flipping
`ENABLE_AUTH_MONITOR`/`ENABLE_CONN_MONITOR` from off to on for a daemon
that was started with them disabled (the monitor is created the first
tick it's seen enabled, not only at startup).

Timing/threshold values (`POLL_INTERVAL_SECONDS`, `IDLE_THRESHOLD_SECONDS`,
`SCAN_INTERVAL_SECONDS`, `AUTH_FAIL_THRESHOLD`, `AUTH_FAIL_WINDOW_SECONDS`,
`AUTH_BAN_SECONDS`, `MAX_LOAD_AVERAGE`) are floored at sane minimums on
load, so a typo like `POLL_INTERVAL_SECONDS=0` degrades to "as fast as
allowed" instead of turning the daemon into a CPU-spinning busy loop. An
empty `SSH_UNITS=` falls back to the default unit list rather than
silently widening auth monitoring to the entire system journal.

## Running it

```sh
aisentryctl status    # daemon running? idle state? ban count? last report?
aisentryctl gui        # desktop launcher: status + recent activity + pager on the full report
aisentryctl tail       # tail the condensed event log (logins, bans, denied conns)
aisentryctl run         # run one heavy scan right now, outside the idle schedule
aisentryctl last        # print the most recent report to stdout
aisentryctl list        # list past report timestamps
```

It runs continuously as `aisentryd.service` (systemd) - auth/connection
monitoring at all times, heavy scans only when idle, as described above.
A desktop menu entry ("aisentryd Security Monitor") runs `aisentryctl gui`
in a terminal for anyone on a desktop rather than a headless server.

Only one heavy scan can be active at a time - if you `aisentryctl run`
manually while the daemon's own scheduled scan is still going, the second
one exits immediately with "another run is already in progress" (exit
code 2) rather than scanning the disk twice at once or, worse, racing a
second `unattended-upgrade` against the first. The lock is released the
moment a scan finishes, so a manual run right after the daemon's own scan
completes works normally.

If the service is stopped (`systemctl stop aisentryd`, a manual `kill`,
`Ctrl-C`) while a scanner is in progress, aisentryd kills that scanner's
process too before exiting, instead of leaving it running as an orphan.

## Security notes

- Runs as root (rkhunter/lynis/clamscan/debsecan all need root to see the
  whole filesystem and package database; the auth/connection monitors
  read the systemd journal; ufw ban/unban needs root).
- The Anthropic API key lives in a 0600 root-only conffile and is never
  written to the report or logged.
- Only structured finding metadata (package names, CVE IDs, file paths,
  clamav signature names) goes to the API - never file contents - and the
  call is skipped entirely on a clean run with zero findings.
- The AI is advisory-only by construction: both `call_anthropic()` and
  `call_ollama()` return text that goes straight into the Markdown report;
  there is no code path anywhere that executes text a model returned.
- Disable the network call entirely with `SEND_TO_AI=0`, or keep it fully
  local with `AI_PROVIDER=ollama`, for an air-gapped or privacy-sensitive
  box; everything else still works.
- Every scanner binary is resolved to an absolute path once (via
  `shutil.which()`) and that resolved path is what actually gets
  executed, rather than handing the bare command name to a second,
  independent PATH search at exec time - closes off a PATH-order
  privilege-escalation angle for code that always runs as root.
- `AUTO_QUARANTINE_MALWARE` never follows a symlink (a flagged path that
  turns out to be a symlink is skipped, not dereferenced) and verifies
  the real path it's about to move actually falls under one of the
  directories this run scanned, before touching it.
- `REPORT_DIR`, `QUARANTINE_DIR` and `BACKUP_DIR` are all required to be
  at least two path levels deep - see the comments in `aisentryd.conf` for
  why.
- If one scanner throws an unexpected exception (a future tool update
  changing its output format in some way a regex doesn't expect, a
  permissions problem, etc.), that failure is recorded in the report's
  "Tool status" section as `CRASHED: <reason>` and the run continues with
  whatever the other scanners found, rather than the whole run aborting
  with no report at all.
- All daemon state (journal-poll cursors, the ban list) is written
  atomically, so a crash mid-write can't leave a corrupt file behind. If
  a state file is still found to be unreadable on load (an old version's
  write, manual editing, disk corruption, or a journal cursor rejected
  after log rotation/vacuuming), the bad copy is backed up with a
  timestamp to `BACKUP_DIR` - never silently discarded - and aisentryd
  rebuilds it fresh rather than crashing.
- The desktop notification path runs `notify-send` as the logind-reported
  active graphical session's user, over that session's own D-Bus bus -
  it never runs anything as root beyond the `runuser` step needed to drop
  into that user's session, and is a no-op, never an error, if no such
  session exists.

## A note on free AI models generally

If you're looking for a free/local model to point `AI_PROVIDER=ollama` at
here, or for other projects (this includes IRC bot integrations): current
solid options are Meta's Llama 3.1/3.2, Mistral/Mixtral, and Alibaba's
Qwen2.5 - all runnable locally via Ollama or llama.cpp with no per-request
cost, sized from a few GB (fits modest hardware) up to much larger. If
local inference isn't practical, several providers offer a free API tier
for hosted open-weight models (Groq, OpenRouter's free-tier models, and
others) - check current terms before relying on one, free tiers change.
