# Unit tests for aisentryd's threat-blocklist code (stdlib only; no network,
# no root, no nft binary needed). Run from the source root:  python3 tests/test_threat.py
import importlib.machinery, importlib.util, io, json, os, sys, tempfile, time, unittest, contextlib, ipaddress
from unittest import mock

SRC = os.environ.get("AISENTRYD_SRC") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "aisentryd")
loader = importlib.machinery.SourceFileLoader("aisentryd_mod", SRC)
spec = importlib.util.spec_from_loader("aisentryd_mod", loader)
A = importlib.util.module_from_spec(spec)
loader.exec_module(A)

SPAMHAUS = '''{"cidr":"1.10.16.0/20","sblid":"SBL256894","rir":"apnic"}
{"cidr":"5.101.86.0/24","sblid":"SBL694579","rir":"ripencc"}
{"cidr":"10.0.0.0/8","sblid":"SBLBAD","rir":"other"}
{"cidr":"2a0b:7140::/32","sblid":"SBL1","rir":"ripencc"}
{"type":"metadata","timestamp":1,"size":1,"records":4}
'''
FEODO = '''################################################################
# abuse.ch Feodo Tracker Botnet C2 IP Blocklist (IPs only)     #
################################################################
#
# DstIP
137.184.9.29
162.243.103.246
# END 2 entries
'''
ET = "# comment\n45.148.10.5\n45.148.10.6\n192.168.1.9\n0.0.0.0/0\n1.2.3.4/33\nnotanip\n"
STEVEN = '''# Title: StevenBlack/hosts
127.0.0.1 localhost
127.0.0.1 localhost.localdomain
::1 localhost
255.255.255.255 broadcasthost
0.0.0.0 0.0.0.0
0.0.0.0 ads.example.com
0.0.0.0 tracker.evil.net # comment
0.0.0.0 Malware.Bad.ORG.
0.0.0.0 security.debian.org
0.0.0.0 raw.githubusercontent.com
'''
URLHAUS = "# urlhaus\n127.0.0.1\tdropper.badhost.ru\n127.0.0.1\tads.example.com\n"
PLAIN = "phish.example.co.uk\n; comment\nnot a domain line\nxn--80ak6aa92e.com\n1.2.3.4\n"

FEEDS = {
    "https://www.spamhaus.org/drop/drop_v4.json": SPAMHAUS,
    "https://feodotracker.abuse.ch/downloads/ipblocklist.txt": FEODO,
    "https://rules.emergingthreats.net/blockrules/compromised-ips.txt": ET,
    "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts": STEVEN,
    "https://urlhaus.abuse.ch/downloads/hostfile/": URLHAUS,
    "https://curben.gitlab.io/malware-filter/phishing-filter-hosts.txt": PLAIN,
}


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        t = self.tmp
        self.patches = []
        def p(name, val):
            pp = mock.patch.object(A, name, val); pp.start(); self.patches.append(pp)
        p("STATE_DIR", t + "/state")
        p("THREAT_DIR", t + "/state/threat")
        p("THREAT_FEED_DIR", t + "/state/threat/feeds")
        p("THREAT_STATE_PATH", t + "/state/threat/state.json")
        p("THREAT_LOCK_PATH", t + "/state/threat/update.lock")
        p("THREAT_HOSTS_BACKUP", t + "/state/threat/hosts.pre-aisentryd")
        p("HOSTS_PATH", t + "/hosts")
        p("DNSMASQ_CONF_PATH", t + "/dnsmasq.d/aisentryd-blocklist.conf")
        os.makedirs(t + "/state")
        with open(t + "/hosts", "w") as fh:
            fh.write("127.0.0.1 localhost\n127.0.1.1 myhost\n\n# user line\n")
        conf = t + "/test.conf"
        with open(conf, "w") as fh:
            fh.write("REPORT_DIR=%s/reports/x\nBACKUP_DIR=%s/state/backups\nEVENT_LOG=%s/events.log\n" % (t, t, t))
        self.conf = conf
        self.cfg = A.load_config(conf)
        self.nft_scripts = []
        def fake_nft(cfg, n4, n6):
            self.nft_scripts.append((list(n4), list(n6)))
            return True, ""
        p("apply_nft", fake_nft)
        p("remove_nft", lambda: True)
        self.fetch_fail = set()
        def fake_fetch(url):
            if url in self.fetch_fail:
                raise OSError("simulated network failure")
            if not url.lower().startswith("https://"):
                raise ValueError("only https:// feed URLs are allowed")
            return FEEDS[url]
        p("_fetch_raw", fake_fetch)

    def tearDown(self):
        for pp in self.patches:
            pp.stop()

    def hosts(self):
        return open(A.HOSTS_PATH).read()


class TestParsers(Base):
    def test_spamhaus_json(self):
        nets = A.parse_ip_feed(SPAMHAUS)
        self.assertEqual([str(n) for n in nets],
                         ["1.10.16.0/20", "5.101.86.0/24", "10.0.0.0/8", "2a0b:7140::/32"])

    def test_plain_ip_lists(self):
        self.assertEqual([str(n) for n in A.parse_ip_feed(FEODO)], ["137.184.9.29/32", "162.243.103.246/32"])
        got = [str(n) for n in A.parse_ip_feed(ET)]
        self.assertEqual(got, ["45.148.10.5/32", "45.148.10.6/32", "192.168.1.9/32", "0.0.0.0/0"])

    def test_domains(self):
        d = A.parse_domain_feed(STEVEN)
        self.assertEqual(d, {"ads.example.com", "tracker.evil.net", "malware.bad.org",
                             "raw.githubusercontent.com", "security.debian.org"})
        # (subdomains of never-block names are removed later, in the update flow)
        self.assertNotIn("localhost.localdomain", d); self.assertNotIn("broadcasthost", d)
        self.assertEqual(A.parse_domain_feed(PLAIN), {"phish.example.co.uk", "xn--80ak6aa92e.com"})
        self.assertEqual(A.parse_domain_feed(URLHAUS), {"dropper.badhost.ru", "ads.example.com"})


class TestFilter(Base):
    def test_protected_and_broad(self):
        nets = A.parse_ip_feed(SPAMHAUS + ET)
        v4, v6, dropped = A.filter_ip_nets(nets, A.build_protected_nets(self.cfg))
        s4 = {str(n) for n in v4}
        self.assertIn("1.10.16.0/20", s4)
        self.assertIn("5.101.86.0/24", s4)
        self.assertNotIn("10.0.0.0/8", s4)
        self.assertNotIn("192.168.1.9/32", s4)
        self.assertNotIn("0.0.0.0/0", s4)
        self.assertEqual([str(n) for n in v6], ["2a0b:7140::/32"])
        self.assertEqual(dropped, 3)

    def test_collapse_adjacent(self):
        nets = [ipaddress.ip_network("45.148.10.0/32"), ipaddress.ip_network("45.148.10.1/32"),
                ipaddress.ip_network("45.148.10.0/31")]
        v4, _, _ = A.filter_ip_nets(nets, [])
        self.assertEqual([str(n) for n in v4], ["45.148.10.0/31"])

    def test_user_allow_ips_and_v6(self):
        cfg = dict(self.cfg); cfg["THREAT_ALLOW_IPS"] = ["5.101.86.77", "2a0b:7140::1"]
        nets = A.parse_ip_feed(SPAMHAUS)
        v4, v6, dropped = A.filter_ip_nets(nets, A.build_protected_nets(cfg))
        self.assertNotIn("5.101.86.0/24", {str(n) for n in v4})   # overlaps the allowed host
        self.assertEqual(v6, [])

    def test_interval_set_bisect_edges(self):
        s = A._IntervalSet([ipaddress.ip_network(x) for x in ("10.0.0.0/8", "192.168.0.0/16")])
        for net, exp in (("9.255.255.255/32", False), ("10.0.0.0/32", True), ("11.0.0.0/32", False),
                         ("8.0.0.0/6", True), ("192.168.5.0/24", True), ("192.169.0.0/16", False),
                         ("0.0.0.0/1", True), ("200.0.0.0/8", False)):
            self.assertEqual(s.overlaps(ipaddress.ip_network(net)), exp, net)


class TestNft(Base):
    def test_script_shape(self):
        s = A.build_nft_script([ipaddress.ip_network("1.2.3.0/24")] * 9, [ipaddress.ip_network("2a0b::/32")], True)
        self.assertIn("add table inet aisentryd\ndelete table inet aisentryd\ntable inet aisentryd {", s)
        self.assertIn("type ipv4_addr", s); self.assertIn("type ipv6_addr", s)
        self.assertIn('ip saddr @blocked4 limit rate 6/minute log prefix "[AISENTRY BLOCK] "', s)
        self.assertIn("ip daddr @blocked4 reject with icmpx type admin-prohibited", s)
        self.assertIn("hook forward priority -50", s)
        # last element chunk has no trailing comma; earlier one does
        self.assertRegex(s, r"1\.2\.3\.0/24,\n\t\t\t1\.2\.3\.0/24\n\t\t\}")
        e = A.build_nft_script([], [], False)
        self.assertNotIn("elements", e); self.assertNotIn("log prefix", e)
        self.assertEqual(s.count("{"), s.count("}"))
        print("\n----- sample nft script (empty sets, logging on) -----")
        print(A.build_nft_script([], [], True))


class TestHosts(Base):
    def test_apply_idempotent_remove(self):
        orig = self.hosts()
        A.apply_hosts_block(self.cfg, {"b.example.com", "a.example.com"})
        h1 = self.hosts()
        self.assertTrue(h1.startswith(orig.rstrip("\n") + "\n\n" + A.HOSTS_BEGIN))
        self.assertIn("0.0.0.0 a.example.com\n0.0.0.0 b.example.com\n", h1)
        self.assertTrue(h1.rstrip().endswith(A.HOSTS_END))
        A.apply_hosts_block(self.cfg, {"c.example.com"})
        h2 = self.hosts()
        self.assertEqual(h2.count(A.HOSTS_BEGIN), 1)
        self.assertNotIn("a.example.com", h2); self.assertIn("c.example.com", h2)
        self.assertTrue(os.path.exists(A.THREAT_HOSTS_BACKUP))
        self.assertEqual(open(A.THREAT_HOSTS_BACKUP).read(), orig)
        self.assertTrue(A.remove_hosts_block())
        self.assertEqual(self.hosts().rstrip("\n"), orig.rstrip("\n"))
        self.assertFalse(A.remove_hosts_block())

    def test_malformed_markers_refuse(self):
        with open(A.HOSTS_PATH, "a") as fh:
            fh.write(A.HOSTS_BEGIN + "\n0.0.0.0 x.example.com\n")   # BEGIN without END
        before = self.hosts()
        with self.assertRaises(ValueError):
            A.apply_hosts_block(self.cfg, {"a.example.com"})
        self.assertEqual(self.hosts(), before)
        ok, err = A.apply_domains(self.cfg, {"a.example.com"})
        self.assertFalse(ok); self.assertIn("malformed", err)

    def test_preserves_perms(self):
        os.chmod(A.HOSTS_PATH, 0o640)
        A.apply_hosts_block(self.cfg, {"a.example.com"})
        self.assertEqual(os.stat(A.HOSTS_PATH).st_mode & 0o777, 0o640)

    def test_non_utf8_preserved(self):
        with open(A.HOSTS_PATH, "wb") as fh:
            fh.write(b"127.0.0.1 localhost\n# caf\xe9 latin1\n")
        A.apply_hosts_block(self.cfg, {"a.example.com"})
        self.assertIn(b"# caf\xe9 latin1\n", open(A.HOSTS_PATH, "rb").read())


class TestDnsmasq(Base):
    def test_apply_and_remove(self):
        cfg = dict(self.cfg); cfg["THREAT_DOMAIN_MODE"] = "dnsmasq"
        ok, err = A.apply_domains(cfg, {"a.example.com"})
        self.assertFalse(ok); self.assertIn("does not exist", err)
        os.makedirs(os.path.dirname(A.DNSMASQ_CONF_PATH))
        A.apply_hosts_block(cfg, {"old.example.com"})
        ok, err = A.apply_domains(cfg, {"a.example.com"})
        self.assertTrue(ok, err)
        txt = open(A.DNSMASQ_CONF_PATH).read()
        self.assertIn("address=/a.example.com/0.0.0.0\naddress=/a.example.com/::\n", txt)
        self.assertNotIn(A.HOSTS_BEGIN, self.hosts())     # switched modes -> hosts block removed
        self.assertTrue(A.remove_dnsmasq_conf())
        self.assertFalse(os.path.exists(A.DNSMASQ_CONF_PATH))


class TestFeeds(Base):
    U = "https://feodotracker.abuse.ch/downloads/ipblocklist.txt"

    def test_fresh_then_cache_on_failure(self):
        items, rep = A.load_feed(self.U, A.parse_ip_feed, True)
        self.assertEqual((rep["status"], rep["count"]), ("fresh", 2))
        self.fetch_fail.add(self.U)
        items, rep = A.load_feed(self.U, A.parse_ip_feed, True)
        self.assertEqual((rep["status"], rep["count"]), ("cache", 2)); self.assertIn("simulated", rep["error"])
        # network=False (boot restore) uses cache only
        items, rep = A.load_feed(self.U, A.parse_ip_feed, False)
        self.assertEqual(rep["status"], "cache")

    def test_failed_without_cache(self):
        self.fetch_fail.add(self.U)
        items, rep = A.load_feed(self.U, A.parse_ip_feed, True)
        self.assertEqual(rep["status"], "failed"); self.assertEqual(items, [])
        items, rep = A.load_feed(self.U, A.parse_ip_feed, False)
        self.assertEqual(rep["status"], "failed")

    def test_empty_response_keeps_cache(self):
        A.load_feed(self.U, A.parse_ip_feed, True)
        FEEDS_BAK = FEEDS[self.U]
        FEEDS[self.U] = "<html>rate limited</html>"
        try:
            items, rep = A.load_feed(self.U, A.parse_ip_feed, True)
        finally:
            FEEDS[self.U] = FEEDS_BAK
        self.assertEqual((rep["status"], rep["count"]), ("cache", 2))
        self.assertIn("unparseable", rep["error"])

    def test_legit_empty_feed_accepted_without_cache(self):
        FEEDS[self.U], bak = "# END 0 entries\n", FEEDS[self.U]
        try:
            items, rep = A.load_feed(self.U, A.parse_ip_feed, True)
        finally:
            FEEDS[self.U] = bak
        self.assertEqual((rep["status"], rep["count"]), ("fresh", 0))

    def test_stale_cache_ignored(self):
        A.load_feed(self.U, A.parse_ip_feed, True)
        path = A._feed_cache_path(self.U)
        old = time.time() - A.THREAT_FEED_CACHE_MAX_AGE - 10
        os.utime(path, (old, old))
        self.fetch_fail.add(self.U)
        _, rep = A.load_feed(self.U, A.parse_ip_feed, True)
        self.assertEqual(rep["status"], "failed")

    def test_cache_file_private(self):
        A.load_feed(self.U, A.parse_ip_feed, True)
        self.assertEqual(os.stat(A._feed_cache_path(self.U)).st_mode & 0o777, 0o600)

    def test_http_url_refused_real_fetch(self):
        with self.assertRaises(ValueError):
            mock.patch.stopall()
            A._fetch_raw("http://example.com/list.txt")

    def test_redirect_to_http_refused(self):
        import urllib.error, urllib.request
        h = A._HttpsOnlyRedirect()
        req = urllib.request.Request("https://example.com/a")
        with self.assertRaises(urllib.error.HTTPError):
            h.redirect_request(req, None, 302, "Found", {}, "http://evil.example/x")
        # Cross-host https redirects are also refused: otherwise a trusted
        # feed host could redirect root's fetch into an internal service.
        with self.assertRaises(urllib.error.HTTPError):
            h.redirect_request(req, io.BytesIO(b""), 302, "Found", {}, "https://example.org/b")
        # Same-host https redirects are passed through to the stock handler.
        r = h.redirect_request(req, io.BytesIO(b""), 302, "Found", {}, "https://example.com/b")
        self.assertEqual(r.full_url, "https://example.com/b")


class TestUpdateFlow(Base):
    def test_full_update(self):
        ok, msg = A.threat_update(self.cfg, network=True)
        self.assertTrue(ok, msg)
        v4, v6 = self.nft_scripts[-1]
        s4 = {str(n) for n in v4}
        self.assertIn("1.10.16.0/20", s4); self.assertIn("137.184.9.29/32", s4)
        self.assertNotIn("10.0.0.0/8", s4); self.assertNotIn("192.168.1.9/32", s4)
        self.assertEqual([str(n) for n in v6], ["2a0b:7140::/32"])
        h = self.hosts()
        for d in ("ads.example.com", "tracker.evil.net", "malware.bad.org", "dropper.badhost.ru", "phish.example.co.uk"):
            self.assertIn("0.0.0.0 %s\n" % d, h)
        # raw.githubusercontent.com is a configured feed host -> never blocked
        self.assertNotIn("raw.githubusercontent.com", h.split(A.HOSTS_BEGIN)[1])
        self.assertNotIn("security.debian.org", h)
        st = json.load(open(A.THREAT_STATE_PATH))
        self.assertTrue(st["active"]); self.assertTrue(st["last_update"])
        self.assertEqual(st["domains"], 6)   # ads, tracker, malware, dropper, phish, xn--
        self.assertEqual(st["fingerprint"], A.threat_fingerprint(self.cfg))
        ev = open(self.cfg["EVENT_LOG"]).read()
        self.assertIn("THREAT_UPDATE ip4=", ev)

    def test_allow_domains_and_subdomain_never_block(self):
        cfg = dict(self.cfg); cfg["THREAT_ALLOW_DOMAINS"] = ["example.com"]
        A.threat_update(cfg, network=True)
        h = self.hosts().split(A.HOSTS_BEGIN)[1]
        self.assertNotIn("ads.example.com", h)      # subdomain of an allowlisted domain
        self.assertIn("tracker.evil.net", h)
        never = A._never_block_domains(self.cfg)
        self.assertFalse(A._domain_allowed_to_block("security.debian.org", never))
        self.assertFalse(A._domain_allowed_to_block("debian.org", never))
        self.assertTrue(A._domain_allowed_to_block("notdebian.org", never))

    def test_all_feeds_fail_leaves_existing_rules(self):
        A.threat_update(self.cfg, network=True)
        before = self.hosts(); n_scripts = len(self.nft_scripts)
        # wipe cache + fail everything
        for f in os.listdir(A.THREAT_FEED_DIR):
            os.unlink(os.path.join(A.THREAT_FEED_DIR, f))
        self.fetch_fail.update(FEEDS)
        ok, msg = A.threat_update(self.cfg, network=True)
        self.assertFalse(ok)
        self.assertEqual(self.hosts(), before); self.assertEqual(len(self.nft_scripts), n_scripts)
        st = json.load(open(A.THREAT_STATE_PATH))
        self.assertTrue(st["active"]); self.assertEqual(len(st["problems"]), 2)

    def test_partial_failure_uses_cache(self):
        A.threat_update(self.cfg, network=True)
        self.fetch_fail.add("https://urlhaus.abuse.ch/downloads/hostfile/")
        ok, msg = A.threat_update(self.cfg, network=True)
        self.assertTrue(ok, msg)
        self.assertIn("dropper.badhost.ru", self.hosts())
        st = json.load(open(A.THREAT_STATE_PATH))
        self.assertEqual(st["feeds"]["https://urlhaus.abuse.ch/downloads/hostfile/"]["status"], "cache")

    def test_non_https_feed_reported(self):
        cfg = dict(self.cfg); cfg["THREAT_DOMAIN_FEEDS"] = list(cfg["THREAT_DOMAIN_FEEDS"]) + ["http://insecure.example/list"]
        ok, msg = A.threat_update(cfg, network=True)
        st = json.load(open(A.THREAT_STATE_PATH))
        rep = st["feeds"]["http://insecure.example/list"]
        self.assertEqual(rep["status"], "failed"); self.assertIn("https", rep["error"])

    def test_too_many_domains_refused(self):
        cfg = dict(self.cfg); cfg["THREAT_MAX_DOMAINS"] = 3
        before = self.hosts()
        ok, msg = A.threat_update(cfg, network=True)
        self.assertFalse(ok); self.assertIn("THREAT_MAX_DOMAINS", msg)
        self.assertEqual(self.hosts(), before)

    def test_restore_from_cache_offline(self):
        A.threat_update(self.cfg, network=True)
        A.remove_hosts_block()
        self.assertNotIn(A.HOSTS_BEGIN, self.hosts())
        n = len(self.nft_scripts)
        self.fetch_fail.update(FEEDS)   # no network at boot
        ok, msg = A.threat_update(self.cfg, network=False)
        self.assertTrue(ok, msg)
        self.assertIn(A.HOSTS_BEGIN, self.hosts()); self.assertEqual(len(self.nft_scripts), n + 1)
        st = json.load(open(A.THREAT_STATE_PATH))
        self.assertEqual(st["fingerprint"], A.threat_fingerprint(self.cfg))

    def test_restore_with_no_cache_does_nothing(self):
        before = self.hosts()
        ok, msg = A.threat_update(self.cfg, network=False)
        self.assertFalse(ok); self.assertEqual(self.hosts(), before); self.assertEqual(self.nft_scripts, [])

    def test_domain_mode_off_and_ips_off(self):
        cfg = dict(self.cfg); cfg["THREAT_DOMAIN_MODE"] = "off"; cfg["THREAT_BLOCK_IPS"] = False
        before = self.hosts()
        ok, msg = A.threat_update(cfg, network=True)
        self.assertFalse(ok)      # nothing to apply
        self.assertEqual(self.hosts(), before); self.assertEqual(self.nft_scripts, [])

    def test_disable_switch_removes_state(self):
        A.threat_update(self.cfg, network=True)
        b = A.ThreatBlocker(self.cfg)
        cfg = dict(self.cfg); cfg["ENABLE_THREAT_BLOCK"] = False
        b.tick(cfg)
        self.assertNotIn(A.HOSTS_BEGIN, self.hosts())
        self.assertFalse(json.load(open(A.THREAT_STATE_PATH))["active"])
        b.tick(cfg)   # second tick: no-op, no crash

    def test_tick_schedule(self):
        b = A.ThreatBlocker(self.cfg)
        calls = []
        real = A.threat_update
        def spy(cfg, network=True):
            calls.append(network); return real(cfg, network)
        with mock.patch.object(A, "threat_update", spy):
            b.tick(self.cfg)                  # first tick: restore (no cache -> False) then network update
            self.assertEqual(calls, [False, True])
            b.tick(self.cfg)                  # fresh: nothing
            self.assertEqual(calls, [False, True])
            st = json.load(open(A.THREAT_STATE_PATH)); st["last_update"] = time.time() - 7 * 3600
            json.dump(st, open(A.THREAT_STATE_PATH, "w"))
            b.tick(self.cfg)                  # stale: refresh
            self.assertEqual(calls, [False, True, True])
            cfg = dict(self.cfg); cfg["THREAT_ALLOW_DOMAINS"] = ["x.example"]
            b.tick(cfg)                       # config fingerprint changed: refresh
            self.assertEqual(len(calls), 4)

    def test_restore_after_external_flush(self):
        b = A.ThreatBlocker(self.cfg)
        b.tick(self.cfg)                          # first tick: full update
        n = len(self.nft_scripts)
        present = {"v": True}
        with mock.patch.object(A, "nft_table_present", lambda: present["v"]):
            b.tick(self.cfg); self.assertEqual(len(self.nft_scripts), n)      # present -> nothing
            present["v"] = None
            b.tick(self.cfg); self.assertEqual(len(self.nft_scripts), n)      # unknown -> nothing
            present["v"] = False                                              # flushed by nftables.service
            b.tick(self.cfg); self.assertEqual(len(self.nft_scripts), n + 1)  # re-applied from cache
            self.assertIn("THREAT_RULES_MISSING", open(self.cfg["EVENT_LOG"]).read())
            b.tick(self.cfg); self.assertEqual(len(self.nft_scripts), n + 1)  # backoff (60s)
            b.next_restore = 0
            b.tick(self.cfg); self.assertEqual(len(self.nft_scripts), n + 2)

    def test_failure_backoff(self):
        self.fetch_fail.update(FEEDS)
        b = A.ThreatBlocker(self.cfg)
        calls = []
        real = A.threat_update
        def spy(cfg, network=True):
            calls.append(network); return real(cfg, network)
        with mock.patch.object(A, "threat_update", spy):
            b.tick(self.cfg); b.tick(self.cfg); b.tick(self.cfg)
        self.assertEqual(calls, [False, True])     # second/third tick back off
        self.assertIn("THREAT_UPDATE_RETRY_IN", open(self.cfg["EVENT_LOG"]).read())

    def test_lock_contention(self):
        fh = A._threat_lock()
        try:
            ok, msg = A.threat_update(self.cfg, network=True)
            self.assertFalse(ok); self.assertIn("already running", msg)
        finally:
            fh.close()


class TestConnMonitor(Base):
    def test_threat_block_lines(self):
        m = A.ConnMonitor(self.cfg)
        notes = []
        with mock.patch.object(A, "notify_desktop", lambda cfg, t, msg, urgency="normal": notes.append(msg)):
            out = ("[AISENTRY BLOCK] IN= OUT=eth0 SRC=192.168.1.5 DST=137.184.9.29 LEN=60 TOS=0x00 "
                   "PROTO=TCP SPT=41234 DPT=443 WINDOW=64240 SYN")
            inn = ("[AISENTRY BLOCK] IN=eth0 OUT= MAC=aa SRC=45.148.10.5 DST=192.168.1.5 LEN=44 "
                   "PROTO=TCP SPT=5555 DPT=22 SYN")
            icmp = "[AISENTRY BLOCK] IN=eth0 OUT= SRC=45.148.10.6 DST=192.168.1.5 PROTO=ICMP TYPE=8 CODE=0"
            for i, msg in enumerate((out, out, inn, icmp)):
                m.handle_line(self.cfg, {"MESSAGE": msg}, 1000.0 + i)
            m.handle_line(self.cfg, {"MESSAGE": out}, 2000.0)   # >10min later: notifies again
            m.handle_line(self.cfg, {"MESSAGE": "[UFW BLOCK] IN=eth0 OUT= SRC=9.9.9.9 DST=1.1.1.1 PROTO=TCP DPT=23"}, 1.0)
        ev = open(self.cfg["EVENT_LOG"]).read()
        self.assertIn("THREAT_BLOCK_OUT dst=137.184.9.29 dport=443", ev)
        self.assertIn("THREAT_BLOCK_IN src=45.148.10.5 dport=22", ev)
        self.assertIn("THREAT_BLOCK_IN src=45.148.10.6 dport=-", ev)
        self.assertIn("CONN_DENIED src=9.9.9.9", ev)
        self.assertEqual(len(notes), 2)   # rate-limited per destination, inbound never notifies


class TestConfig(Base):
    def test_config_parsing(self):
        with open(self.conf, "a") as fh:
            fh.write("THREAT_UPDATE_INTERVAL_SECONDS=0\nTHREAT_DOMAIN_MODE=Dnsmasq\nENABLE_THREAT_BLOCK=0\n"
                     "THREAT_ALLOW_DOMAINS=Example.COM. other.org\nTHREAT_MAX_DOMAINS=abc\n")
        c = A.load_config(self.conf)
        self.assertEqual(c["THREAT_UPDATE_INTERVAL_SECONDS"], 3600)
        self.assertEqual(c["THREAT_DOMAIN_MODE"], "dnsmasq")
        self.assertFalse(c["ENABLE_THREAT_BLOCK"])
        self.assertEqual(c["THREAT_ALLOW_DOMAINS"], ["example.com", "other.org"])
        self.assertEqual(c["THREAT_MAX_DOMAINS"], 500000)
        with open(self.conf, "a") as fh:
            fh.write("THREAT_DOMAIN_MODE=bogus\n")
        self.assertEqual(A.load_config(self.conf)["THREAT_DOMAIN_MODE"], "hosts")

    def test_defaults(self):
        c = A.load_config("/nonexistent")
        self.assertTrue(c["ENABLE_THREAT_BLOCK"]); self.assertEqual(len(c["THREAT_IP_FEEDS"]), 4)
        self.assertTrue(all(u.startswith("https://") for u in c["THREAT_IP_FEEDS"] + c["THREAT_DOMAIN_FEEDS"]))


class TestCli(Base):
    def run_cli(self, fn, *a):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            rc = fn(self.cfg, *a)
        return rc, buf.getvalue()

    def test_status_update_check_off(self):
        rc, out = self.run_cli(A.do_threat_status)
        self.assertIn("not active", out)
        rc, out = self.run_cli(A.do_threat_update)
        self.assertEqual(rc, 0, out); self.assertIn("fresh", out)
        rc, out = self.run_cli(A.do_threat_status)
        self.assertIn("IPv4", out); self.assertIn("6 domains blocked via hosts", out)
        rc, out = self.run_cli(A.do_threat_check, "45.148.10.5")
        self.assertIn("compromised-ips.txt", out)
        rc, out = self.run_cli(A.do_threat_check, "192.168.1.9")
        self.assertIn("PROTECTED", out)
        rc, out = self.run_cli(A.do_threat_check, "Ads.Example.com")
        self.assertIn("hostfile", out); self.assertIn("exact names only", out)
        rc, out = self.run_cli(A.do_threat_check, "good.example.org")
        self.assertIn("not found", out)
        rc, out = self.run_cli(A.do_threat_check, "not a target!")
        self.assertEqual(rc, 1)
        rc, out = self.run_cli(A.do_threat_off)
        self.assertEqual(rc, 0); self.assertIn("/etc/hosts block", out)
        self.assertNotIn(A.HOSTS_BEGIN, self.hosts())
        self.assertIn("still set", out)
        lines = A._threat_summary_lines(self.cfg)
        self.assertIn("not yet applied", lines[0])


class SentrydStatusTests(unittest.TestCase):
    """aisentryctl status reports the bundled sentryd port-scan detector."""

    def status_out(self, sentryd_present, sentryd_active):
        cfg = A.load_config("/nonexistent")
        def fake_run(cmd, *a, **k):
            # cmd = [systemctl, "is-active", "--quiet", <unit>]
            if cmd[-1] == "sentryd":
                return (0 if sentryd_active else 3), ""
            return 0, ""
        buf = io.StringIO()
        with mock.patch.object(A, "which", return_value="/bin/systemctl"), \
             mock.patch.object(A, "run_cmd", side_effect=fake_run), \
             mock.patch.object(A.os.path, "exists", side_effect=lambda p: sentryd_present if p == A.SENTRYD_BIN else os.path.lexists(p)), \
             mock.patch.object(A, "is_idle_now", return_value=True), \
             mock.patch.object(A, "get_load_average", return_value=0.1), \
             mock.patch.object(A, "read_state_json", return_value={}), \
             mock.patch.object(A, "_threat_summary_lines", return_value=[]), \
             contextlib.redirect_stdout(buf):
            A.do_status(cfg)
        return buf.getvalue()

    def test_reports_running(self):
        out = self.status_out(True, True)
        self.assertIn("port-scan detector (sentryd): running", out)

    def test_reports_not_running(self):
        out = self.status_out(True, False)
        self.assertIn("port-scan detector (sentryd): not running", out)

    def test_silent_when_binary_absent(self):
        out = self.status_out(False, False)
        self.assertNotIn("port-scan detector", out)


if __name__ == "__main__":
    unittest.main(verbosity=1)
