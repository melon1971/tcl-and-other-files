#!/usr/bin/python3
"""5.0-14: operations that switch protection off need an administrator's approval when the unprivileged half asks.
Runs both halves in one process with commands stubbed and the socket caller simulated (SO_PEERCRED uid).
Creates files under /var/lib/scanistry, /var/lib/scanistry-broker and /srv/t: throwaway container or VM only, as root.
Usage: test_approvals_5014.py path/to/scanistry.py"""
import sys, os, shutil, subprocess, importlib.util, collections, re, time
PATH = sys.argv[1]
REC = []; UFW = {'active': False}
class FakeProc:
    pid = 999998; returncode = None
    def __init__(self, argv, **kw): self.args = argv
    def poll(self): return self.returncode
    def wait(self, timeout=None): return 0
    def terminate(self): self.returncode = -15
    def kill(self): self.returncode = -9
    def communicate(self, *a, **k): return (None, None)
def fake_run(argv, input=None, stdin=None, stdout=None, stderr=None, timeout=None, check=False, text=False, **kw):
    REC.append([str(x) for x in argv]); out = b''
    if argv[:2] == ['systemctl', 'show'] and '--value' in argv: out = (argv[-1] + '\n').encode()
    if argv[:2] == ['ufw', 'status']: out = b'Status: active\n' if UFW['active'] else b'Status: inactive\n'
    if hasattr(stdout, 'write'): stdout.write(out); return subprocess.CompletedProcess(argv, 0)
    return subprocess.CompletedProcess(argv, 0, stdout=out.decode() if text else out, stderr='')
def fake_popen(argv, *a, stdout=None, **k):
    REC.append([str(x) for x in argv])
    if list(argv[:2]) == ['ufw', 'status'] and hasattr(stdout, 'write'):
        stdout.write(b'Status: active\n' if UFW['active'] else b'Status: inactive\n')
    return FakeProc(argv)
subprocess.run = fake_run; subprocess.Popen = fake_popen
subprocess.check_output = lambda *a, **k: ''
shutil.rmtree('/var/lib/scanistry', ignore_errors=True); shutil.rmtree('/var/lib/scanistry-broker', ignore_errors=True)
os.environ['SCANISTRY_INPROCESS_BROKER'] = '1'
os.makedirs('/srv/t', exist_ok=True); open('/srv/t/a.txt', 'w').write('x')
spec = importlib.util.spec_from_file_location('scanistry_appr', PATH)
m = importlib.util.module_from_spec(spec); sys.argv = [PATH]; spec.loader.exec_module(m)
m.have = lambda c: True
m.shutil.disk_usage = lambda p: collections.namedtuple('u', 'total used free')(1 << 40, 0, 1 << 40)
passed = failed = 0
def check(label, cond):
    global passed, failed
    if cond: passed += 1
    else: failed += 1; print('FAIL:', label)
WEB = m._Req(4242, 990, False); ROOT = m._Req(1, 0, False)
def as_(who, verb, **args):
    REC.clear(); m._BROKER_TLS.req = who; m._BROKER_TLS.approval = None
    try: return m.broker(verb, **args)
    finally: m._BROKER_TLS.req = None
def ran(word): return any(word in ' '.join(c) for c in REC)
def parked(r): return 'needs administrator approval' in str(r)
def pending(): return dict(m._APPROVALS)

# --- the gated operations, asked for by the unprivileged half
r = as_(WEB, 'fw.ufw.disable')
check('web: fw.ufw.disable is parked, not run', parked(r) and r[0] == 126 and not ran('disable'))
aid = m._BROKER_TLS.approval
check('the approval id is 8 hex characters and in the refusal text', bool(aid and re.fullmatch(r'[0-9a-f]{8}', aid)) and aid in r[1])
check('the refusal says nothing was changed and what to run', 'Nothing was changed' in r[1] and f'sudo scanistryctl approve {aid}' in r[1])
r2 = as_(WEB, 'fw.ufw.disable')
check('the same request asked twice gets the same id', m._BROKER_TLS.approval == aid and len(pending()) == 1)
r = as_(WEB, 'fw.ufw.allow_port', port=8080, proto='tcp')
check('web: opening a port is parked', parked(r) and not ran('allow') and '8080/tcp' in r[1])
r = as_(WEB, 'fw.ufw.unallow_port', port=8080, proto='tcp')
check('web: closing a port is not gated', not parked(r) and ran('delete'))
r = as_(WEB, 'fw.ufw.deny', target='203.0.113.9')
check('web: blocking an address is not gated', not parked(r) and ran('deny'))
r = as_(WEB, 'fw.ufw.enable')
check('web: enabling UFW is not gated', not parked(r) and ran('enable'))
r = as_(WEB, 'svc.control', unit='ufw.service', action='stop')
check('web: stopping ufw.service is parked', parked(r) and not any(c[:2] == ['systemctl', 'stop'] for c in REC))
r = as_(WEB, 'svc.control', unit='rsyslog.service', action='disable')
check('web: disabling rsyslog is parked', parked(r))
r = as_(WEB, 'svc.control', unit='clamav-daemon.service', action='start')
check('web: starting a service is not gated', not parked(r) and any(c[:2] == ['systemctl', 'start'] for c in REC))
UFW['active'] = True
r = as_(WEB, 'fw.nft.fallback_remove')
check('web: removing the fallback chain while UFW is active is routine', not parked(r) and ran('nft'))
UFW['active'] = False
r = as_(WEB, 'fw.nft.fallback_remove')
check('web: removing the fallback chain while UFW is off is parked', parked(r) and not ran('nft'))
r = as_(WEB, 'aide.accept', confirm=False)
check('web: aide.accept without confirm is not parked (it explains instead)', not parked(r) and isinstance(r, dict) and r.get('required_confirmation'))
m.AIDE_DB_NEW.parent.mkdir(parents=True, exist_ok=True); m.AIDE_DB_NEW.write_bytes(b'x' * 64)
r = as_(WEB, 'aide.accept', confirm=True)
check('web: aide.accept with confirm is parked', parked(r) and isinstance(r, dict) and r.get('ok') is False)
m.AIDE_DB_NEW.unlink()
r = as_(WEB, 'aide.accept', confirm=True)
check('web: aide.accept with no aide.db.new is refused, not parked', not parked(r) and isinstance(r, dict) and r.get('ok') is False)
r = as_(WEB, 'aide.reinit', confirm=True)
check('web: aide.reinit with confirm is parked', parked(r) and not ran('aideinit'))
r = as_(WEB, 'quarantine.file', path='/srv/t/a.txt', force=True)
check('web: forced quarantine is parked', parked(r) and os.path.exists('/srv/t/a.txt'))
r = as_(WEB, 'quarantine.file', path='/srv/t/a.txt', anyway=True)
check('web: quarantine-even-if-clean is parked', parked(r) and os.path.exists('/srv/t/a.txt'))
r = as_(WEB, 'quarantine.file', path='/srv/t/a.txt', signature='Eicar-Fake')
check('web: a signature from the unprivileged half no longer skips the scan', ran('clamscan') and isinstance(r, dict) and r.get('clean') is True and os.path.exists('/srv/t/a.txt'))

# --- requests the verb refuses anyway are refused at once, never parked (approving could not change that)
n0 = len(pending())
r = as_(WEB, 'svc.control', unit='ssh.service', action='stop')
check('web: stopping a protected unit is refused, not parked', not parked(r) and r[0] == 126 and 'protected' in r[1])
r = as_(WEB, 'svc.control', unit='bluetooth.service', action='stop')
check('web: stopping an unmanaged unit (manual control off) is refused, not parked', not parked(r) and r[0] == 126)
r = as_(WEB, 'quarantine.file', path='/etc/shadow', force=True)
check('web: forcing a never-quarantined file is refused, not parked', not parked(r) and r.get('ok') is False)
r = as_(WEB, 'quarantine.file', path='/srv/t/missing', force=True)
check('web: a missing file is refused, not parked', not parked(r) and r.get('ok') is False)
check('none of those added a pending request', len(pending()) == n0)

# --- the root-only approval verbs
r = as_(WEB, 'approval.list')
check('web: cannot list approvals', isinstance(r, dict) and 'refused' in str(r.get('error')))
r = as_(WEB, 'approval.grant', aid=aid)
check('web: cannot approve its own request', isinstance(r, dict) and r.get('ok') is False and aid in pending())
r = as_(WEB, 'approval.deny', aid=aid)
check('web: cannot deny either', r.get('ok') is False and aid in pending())
r = as_(ROOT, 'approval.list')
ids = [p['id'] for p in r.get('pending', [])]
check('root: lists every pending request with a description', aid in ids and all(p['what'] for p in r['pending']))
r = as_(ROOT, 'approval.show', aid=aid)
check('root: shows one request, described from the validated arguments', r.get('what') == 'turn the UFW firewall off' and r.get('asked_by') == 'pid 4242 uid 990')
r = as_(ROOT, 'approval.grant', aid=aid)
check('root: approving runs the parked operation', r.get('ok') is True and ran('disable'))
r = as_(ROOT, 'approval.grant', aid=aid)
check('an approval is used once', r.get('ok') is False and not ran('disable'))
port_id = next(k for k, v in pending().items() if v['verb'] == 'fw.ufw.allow_port')
r = as_(ROOT, 'approval.deny', aid=port_id)
check('root: deny drops a request', r.get('ok') is True and port_id not in pending())
r = as_(ROOT, 'approval.grant', aid='zzzz')
check('a malformed id is refused by the validator', r.get('ok') is False)
q_id = next(k for k, v in pending().items() if v['verb'] == 'quarantine.file' and v['args']['force'])
m._APPROVALS[q_id]['created'] -= m._APPROVAL_TTL + 1
r = as_(ROOT, 'approval.grant', aid=q_id)
check('an expired request cannot be approved', r.get('ok') is False and os.path.exists('/srv/t/a.txt'))
for i in range(m._APPROVAL_MAX + 5): as_(WEB, 'fw.ufw.allow_port', port=1000 + i, proto='udp')
check(f'at most {m._APPROVAL_MAX} requests wait at once', len(pending()) <= m._APPROVAL_MAX)

# --- who is not gated
r = as_(ROOT, 'fw.ufw.disable')
check('a root caller is not gated', not parked(r) and ran('disable'))
REC.clear(); m._BROKER_TLS.req = None; r = m.broker('fw.ufw.disable')
check('an in-process call (the broker itself) is not gated', not parked(r) and ran('disable'))

# --- the never-quarantine list
for p in ('/etc/apparmor.d/usr.sbin.clamd', '/var/lib/aide/aide.db', '/var/lib/clamav/main.cvd', '/home/u/.ssh/authorized_keys',
          '/root/.ssh/id_ed25519', '/etc/apt/sources.list', '/etc/rkhunter.conf', '/var/lib/scanistry-broker/x'):
    check(f'never quarantined: {p}', m._never_quarantine(p))
for p in ('/home/u/Downloads/evil.exe', '/tmp/x.sh', '/home/u/.ssh/config'):
    check(f'still quarantinable: {p}', not m._never_quarantine(p))

# --- the CLI keeps root only for the approval commands
src = open(PATH).read()
check('--approvals/--approve/--deny are exempt from dropping privileges', "_APPROVAL_FLAGS={'--approvals','--approve','--deny'}" in src)
ctl = open(os.path.join(os.path.dirname(PATH), '..', '..', 'bin', 'scanistryctl')).read()
check('scanistryctl has approvals, approve and deny', all(w in ctl for w in ('approvals)', 'approve)', 'deny)')))
print(f'{passed} passed, {failed} failed'); sys.exit(1 if failed else 0)
