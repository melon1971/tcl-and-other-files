#!/usr/bin/python3
"""5.0-20 checks, no root needed:
 1. The broker itself refuses to block the local network (allow_ips) -- an address in it, or a network that
    overlaps it (192.0.0.0/8 holds 192.168.0.0/16) -- for fw.ufw.deny and fw.nft.add, before any command runs.
    Up to 5.0-19 only block_ip() on the unprivileged side refused it, so a compromised dashboard could cut the
    machine off its own LAN. Public addresses are still blocked as before.
 2. block_ip() uses the same rule (overlap, not only subnet), so its answer and the broker's agree.
 3. POST /api/login-code needs the API token: a session cookie alone is refused (it could mint a code, trade it
    for a fresh session and repeat, outliving the session limits). The token still works.
Usage: test_5020.py path/to/scanistry.py"""
import sys, os, io, json, time, types, tempfile, email.message
os.environ['SCANISTRY_INPROCESS_BROKER'] = '1'
PATH = sys.argv[1]
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
src = open(PATH).read()
m = types.ModuleType('scanistry_5020'); m.__file__ = PATH; sys.argv = [PATH]
exec(compile(src.replace('CFG=load_conf()', 'CFG=dict(DEFAULTS)', 1), PATH, 'exec'), m.__dict__)
m.log = lambda *a, **k: None
m.incident = lambda *a, **k: None

# ---- 1. the broker refuses the local network ----
RAN = []
m._ufw = lambda args: (RAN.append(('ufw',) + tuple(args)) or (0, 'ok'))
_run = m.run
m.run = lambda cmd, *a, **k: (RAN.append(tuple(cmd)) or (0, '')) if cmd and cmd[0] == 'nft' else _run(cmd, *a, **k)
m.have = lambda c: True
m._BROKER_TLS.depth = 0
def ask(verb, target):
    RAN.clear()
    r = m.broker(verb, target=target)
    return r, list(RAN)
for verb in ('fw.ufw.deny', 'fw.nft.add'):
    for t in ('192.168.1.20', '192.168.1.0/24', '10.0.0.0/8', '192.0.0.0/8', '172.0.0.0/8', 'fd00::5', 'fd12::/32'):
        r, ran = ask(verb, t)
        check(f'{verb} {t} is refused by the broker and runs nothing',
              not ran and isinstance(r, tuple) and r[0] == 126 and 'local network' in str(r[1]))
    for t in ('203.0.113.9', '198.51.100.0/24', '2001:db8::7'):
        r, ran = ask(verb, t)
        check(f'{verb} {t} (public) still runs', bool(ran))
r, ran = ask('fw.ufw.deny', '0.0.0.0/0')
check('a range wider than /8 is still refused for its width', not ran and 'too wide' in str(r[1]))
r, ran = ask('fw.ufw.undeny', '192.168.1.20')
check('unblocking a local address still works (old blocks can be lifted)', bool(ran))

# ---- 2. block_ip agrees ----
m.firewall_active = lambda: True
m.load_blocks = lambda: {}
for t in ('172.0.0.0/8', '192.168.5.5', '10.9.0.0/16'):
    ok, msg = m.block_ip(t, 'test', 'manual', persist=False, record_incident=False)
    check(f'block_ip({t}) is refused as allowlisted', ok is False and msg == 'allowlisted')
check('_never_blocked uses the overlap rule (192.0.0.0/8)', m._never_blocked('192.0.0.0/8'))
check('_never_blocked: a public address is blockable', not m._never_blocked('203.0.113.9'))

# ---- 3. /api/login-code needs the token ----
tmp = tempfile.mkdtemp(prefix='scanistry-5020-')
m.TOKEN = m.Path(tmp) / 'api.token'; m.TOKEN.write_text('T' * 64)
m.SESSIONS_FILE = m.Path(tmp) / 'sessions.json'
m._SESSIONS['loaded'] = True; m._SESSIONS['data'] = {}
m.atomic_json = lambda p, obj: m.Path(p).write_text(json.dumps(obj))
sid = m.new_session()
def post(path, token=None, cookie=None):
    h = m.Handler.__new__(m.Handler)
    hd = email.message.Message()
    hd['Host'] = f'127.0.0.1:{m.CFG["port"]}'; hd['Content-Length'] = '2'
    if token: hd['X-Scanistry-Token'] = token
    if cookie: hd['Cookie'] = f'{m.COOKIE}={cookie}'
    h.headers = hd; h.path = path; h.rfile = io.BytesIO(b'{}')
    out = {}
    h.sendj = lambda obj, code=200: out.update(obj=obj, code=code)
    h.do_POST()
    return out
r = post('/api/login-code', cookie=sid)
check('a session cookie alone cannot mint a login code (403)', r.get('code') == 403 and not r['obj'].get('code'))
r = post('/api/login-code', token='T' * 64)
check('the API token still mints a login code', r.get('code') == 200 and bool(r['obj'].get('code')))
r = post('/api/login-code', token='X' * 64, cookie=sid)
check('a wrong token with a valid cookie is refused', r.get('code') == 403)
r = post('/api/incident/delete-all', cookie=sid)
check('the cookie still works for ordinary dashboard requests', r.get('code') == 200)

print(f'\n{"FAILED: " + str(len(F)) if F else "all passed"}')
sys.exit(1 if F else 0)
