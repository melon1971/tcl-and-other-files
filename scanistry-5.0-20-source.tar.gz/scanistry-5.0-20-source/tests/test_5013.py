#!/usr/bin/python3
"""5.0-13: apparmor-utils and libcap2-bin are hard dependencies (not recommends), and the docs say where aa-enforce comes from. No root needed.
Usage: test_5013.py path/to/scanistry.py"""
import sys, os, re
HERE = os.path.dirname(os.path.abspath(sys.argv[1])); ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
rd = lambda p: open(os.path.join(ROOT, p)).read()
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
ctl = rd('DEBIAN/control')
rec = re.search(r'^Recommends:\s*(.*)$', ctl, re.M).group(1)
dep = re.search(r'^Depends:\s*(.*)$', ctl, re.M).group(1)
dl = [d.strip() for d in dep.split(',')]
check('apparmor-utils is a hard dependency', 'apparmor-utils' in dl)
check('libcap2-bin is a hard dependency', 'libcap2-bin' in dl)
check('neither is left in Recommends', 'apparmor-utils' not in rec and 'libcap2-bin' not in rec)
check('suricata-update is still recommended', 'suricata-update' in rec)
v = re.search(r'^Version: 5\.0-(\d+)$', ctl, re.M)
check('the control file version is 5.0-13 or later', v is not None and int(v.group(1)) >= 13)
check('README.Debian says where aa-enforce comes from', 'apparmor-utils' in rd('usr/share/doc/scanistry/README.Debian') and 'aa-enforce' in rd('usr/share/doc/scanistry/README.Debian'))
check('the AppArmor profile header says where aa-enforce comes from', 'come from the apparmor-utils package' in rd('etc/apparmor.d/scanistry'))
check('the changelog exists', os.path.exists(os.path.join(ROOT, 'usr/share/doc/scanistry/CHANGELOG-5.0-13')))
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
