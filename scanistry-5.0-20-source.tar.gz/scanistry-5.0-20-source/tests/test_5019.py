#!/usr/bin/python3
"""5.0-19 checks, no root needed: the AIDE report explains links and folders that `sudo systemctl disable/enable/mask`
and `sudo update-rc.d` changed, from sudo's COMMAND= lines in the journal, instead of "Warning: not explained".
Real case (Debian 13, 2026-10-14 09:55): sudo systemctl disable --now cups-browsed, then
sudo systemctl disable --now avahi-daemon.socket avahi-daemon; the next check listed 10 unexplained rows.
The journal records, the AIDE rows and the unit files are stand-ins. Usage: test_5019.py path/to/scanistry.py"""
import sys, os, re, time, types, tempfile
os.environ['TZ'] = 'America/Chicago'; time.tzset()
os.environ['SCANISTRY_INPROCESS_BROKER'] = '1'
PATH = sys.argv[1]
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
# Load the module without root: the configuration file is root's, so start from the defaults.
src = open(PATH).read()
m = types.ModuleType('scanistry_5019'); m.__file__ = PATH; sys.argv = [PATH]
exec(compile(src.replace('CFG=load_conf()', 'CFG=dict(DEFAULTS)', 1), PATH, 'exec'), m.__dict__)
m.log = lambda *a, **k: None

T = lambda s: time.mktime(time.strptime(s, '%Y-%m-%d %H:%M:%S'))
BASE = T('2026-10-09 03:40:00'); CHECK = T('2026-10-16 03:47:32')
def sudo(ts, cmd, user='smullen', exe='/usr/bin/sudo', pre='TTY=pts/2 ; PWD=/home/smullen ; USER=root ; '):
    return {'__REALTIME_TIMESTAMP': str(int(T(ts) * 1e6)), '_PID': '1076685', '_COMM': 'sudo', '_EXE': exe,
            'MESSAGE': f' {user} : {pre}COMMAND={cmd}'}
def pid1(ts, msg):
    return {'__REALTIME_TIMESTAMP': str(int(T(ts) * 1e6)), '_PID': '1', '_COMM': 'systemd', '_EXE': '/usr/lib/systemd/systemd', 'MESSAGE': msg}
REAL = [sudo('2026-10-14 09:55:22', '/usr/bin/systemctl disable --now cups-browsed'),
        pid1('2026-10-14 09:55:23', "Reloading requested from client PID 1076690 ('systemctl') (unit session-5.scope)..."),
        sudo('2026-10-14 09:55:36', '/usr/bin/systemctl disable --now avahi-daemon.socket avahi-daemon'),
        pid1('2026-10-14 09:55:36', "Reloading requested from client PID 1076999 ('systemctl') (unit session-5.scope)...")]
UNITS = {'cups-browsed.service': '[Install]\nWantedBy=multi-user.target\n',
         'avahi-daemon.service': '[Install]\nWantedBy=multi-user.target\nAlso=avahi-daemon.socket\nAlias=dbus-org.freedesktop.Avahi.service\n',
         'avahi-daemon.socket': '[Install]\nWantedBy=sockets.target\n'}
# The 10 rows of scan-aide-20261016-034732.json.
ROWS = ([('added', f'/etc/rc{n}.d/K01cups-browsed') for n in (2, 3, 4, 5)] + [('changed', f'/etc/rc{n}.d') for n in (2, 3, 4, 5)]
        + [('changed', '/etc/systemd/system/multi-user.target.wants'), ('changed', '/etc/systemd/system/sockets.target.wants')])
MT = {'mtime': ('2026-07-20 10:00:00 -0500', '2026-10-14 09:55:36 -0500')}
DETAILS = {p: (MT if s == 'changed' else {}) for s, p in ROWS}
OWN = {f'/etc/rc{n}.d': ['init-system-helpers'] for n in (2, 3, 4, 5)}
OWN['/etc/init.d/cups-browsed'] = ['cups-browsed']

ud = tempfile.mkdtemp(prefix='scanistry-aide-units-')
for k, v in UNITS.items(): open(os.path.join(ud, k), 'w').write(v)
_open = open
OPENED = []
def fake_open(f, *a, **k):
    f2 = str(f); OPENED.append(f2)
    if re.match(r'^(?:/usr)?/lib/systemd/system/|^/etc/systemd/system/', f2):
        n = os.path.basename(f2)
        if f2.startswith('/usr/lib/') and n in UNITS: return _open(os.path.join(ud, n), *a, **k)
        raise FileNotFoundError(f2)
    return _open(f, *a, **k)
m.open = fake_open

def analyze(journal, rows=ROWS, details=DETAILS):
    m._aide_db_state = lambda: {'database': {'exists': True, 'mtime': BASE}}
    m._aide_parse = lambda path: {'entries': list(rows), 'details': details, 'ts': CHECK, 'verdict': 'changed', 'counts': {}}
    m._dpkg_owners = lambda paths: {x: OWN[x] for x in paths if x in OWN}
    m._pkg_activity = lambda: {'cups-browsed': T('2026-07-20 10:00:00'), 'init-system-helpers': T('2026-07-01 10:00:00')}
    asked = []
    def fake_journal(since, until): asked.append((since, until)); return list(journal)
    m._aide_unit_journal = fake_journal
    a = m._aide_analyze('/x')
    return {r['path']: r for r in a['records']}, a, asked

r, a, asked = analyze(REAL)
check('the journal is read for the snapshot window', asked and asked[0][0] <= BASE and asked[0][1] >= CHECK)
check('all 10 rows of the real case are explained', all(r[p]['explained'] and r[p]['lvl'] == 'info' for _, p in ROWS))
check('nothing is left unexplained in the summary', a['n_warn'] == 0 and a['n_explained'] == 10)
why = r['/etc/rc2.d/K01cups-browsed']['why']
check('the K01 link names the command, sudo, the user and the time',
      '`systemctl disable --now cups-browsed` (sudo, smullen, Oct 14 09:55' in why and 'disabled' in why)
check('the reload line from systemd is mentioned', 'systemd reloaded' in why)
check('no row advises reinstalling a package', not any('reinstall' in r[p]['fix'] for _, p in ROWS))
check('rc2.d (owned by init-system-helpers) is explained by the command, not by the package', 'cups-browsed' in r['/etc/rc2.d']['why'])
check('sockets.target.wants is explained by the avahi command (WantedBy=sockets.target)',
      'avahi-daemon.socket' in r['/etc/systemd/system/sockets.target.wants']['why'] and 'cups-browsed' not in r['/etc/systemd/system/sockets.target.wants']['why'])
mu = r['/etc/systemd/system/multi-user.target.wants']['why']
check('multi-user.target.wants names both commands', 'cups-browsed' in mu and 'avahi-daemon' in mu)

# A link that changed with no matching command must stay a warning.
rows2 = ROWS + [('added', '/etc/rc2.d/S01mystery'), ('added', '/etc/systemd/system/multi-user.target.wants/mystery.service'),
                ('changed', '/etc/systemd/system/timers.target.wants')]
r, a, _ = analyze(REAL, rows2, dict(DETAILS, **{'/etc/systemd/system/timers.target.wants': MT}))
check('a start link for a service no command named stays a warning', not r['/etc/rc2.d/S01mystery']['explained'] and r['/etc/rc2.d/S01mystery']['lvl'] == 'warn')
check('a .wants link for a unit no command named stays a warning', not r['/etc/systemd/system/multi-user.target.wants/mystery.service']['explained'])
check('a .wants folder no named unit is wanted by stays a warning', not r['/etc/systemd/system/timers.target.wants']['explained'])
check('the real rows are still explained beside them', all(r[p]['explained'] for _, p in ROWS))
r, a, _ = analyze([])
check('with no journal records the 10 rows stay warnings', a['n_warn'] == 10 and not any(r[p]['explained'] for _, p in ROWS))

# Records that must not explain anything.
fakes = [sudo('2026-10-14 09:55:22', '/usr/bin/systemctl disable --now cups-browsed', exe='/usr/bin/python3'),   # logger -t sudo
         sudo('2026-10-14 09:55:22', '/usr/bin/systemctl disable cups-browsed', pre='user NOT in sudoers ; TTY=pts/2 ; PWD=/home/x ; USER=root ; '),
         sudo('2026-10-14 09:55:22', '/usr/bin/systemctl disable cups-browsed', pre='3 incorrect password attempts ; TTY=pts/2 ; PWD=/home/x ; USER=root ; '),
         sudo('2026-10-14 09:55:22', '/usr/bin/systemctl --root=/mnt disable cups-browsed avahi-daemon.socket avahi-daemon'),
         sudo('2026-10-14 09:55:22', '/usr/bin/systemctl status cups-browsed avahi-daemon.socket avahi-daemon'),
         sudo('2026-10-14 09:55:22', '/usr/bin/cat /etc/rc2.d/K01cups-browsed avahi-daemon.socket')]
r, a, _ = analyze(fakes)
check('a forged sudo line, a refused sudo, --root, a non-changing verb and other programs explain nothing',
      a['n_warn'] == 10 and not any(r[p]['explained'] for _, p in ROWS))

# update-rc.d run directly, and mask.
r, a, _ = analyze([sudo('2026-10-14 09:55:22', '/usr/sbin/update-rc.d cups-browsed disable')],
                  [('added', '/etc/rc2.d/K01cups-browsed'), ('changed', '/etc/rc2.d'), ('added', '/etc/systemd/system/multi-user.target.wants/cups-browsed.service')],
                  {'/etc/rc2.d': MT})
check('sudo update-rc.d cups-browsed disable explains its rc links and folder',
      r['/etc/rc2.d/K01cups-browsed']['explained'] and r['/etc/rc2.d']['explained'] and 'update-rc.d cups-browsed disable' in r['/etc/rc2.d/K01cups-browsed']['why'])
check('... but not a systemd .wants link', not r['/etc/systemd/system/multi-user.target.wants/cups-browsed.service']['explained'])
r, a, _ = analyze([sudo('2026-10-14 09:55:22', '/usr/bin/systemctl mask cups-browsed.service')],
                  [('added', '/etc/systemd/system/cups-browsed.service'), ('added', '/etc/systemd/system/avahi-daemon.service')], {})
check('sudo systemctl mask explains its /dev/null link and nothing else',
      r['/etc/systemd/system/cups-browsed.service']['explained'] and 'masked' in r['/etc/systemd/system/cups-browsed.service']['why']
      and not r['/etc/systemd/system/avahi-daemon.service']['explained'])
# A change that is dangerous is never explained by a command.
r, a, _ = analyze(REAL, [('changed', '/etc/rc2.d')], {'/etc/rc2.d': {'uid': ('0', '1000')}})
check('a folder whose owner changed is still a problem', r['/etc/rc2.d']['lvl'] == 'bad')

prof = open(os.path.join(os.path.dirname(os.path.abspath(PATH)), '..', '..', '..', 'etc/apparmor.d/scanistry')).read()
web = prof[prof.index('profile scanistry-web '):prof.index('profile scanistry-broker ')]
check('scanistry-web may run journalctl and read the journal', all(x in web for x in ('/usr/bin/journalctl ix,', '/var/log/journal/** r,', '/run/log/journal/** r,')))
check('scanistry-web may read the vendor unit files (WantedBy=, Also=)', '/usr/lib/systemd/system/** r,' in web)

# scanistry-web may not read /etc/systemd/system (a masked unit's file there is /dev/null): trying would log a DENIED line in enforce mode.
check('the unit files are read from the vendor folders only, never /etc/systemd/system', OPENED and not [f for f in OPENED if f.startswith('/etc/systemd/system/')])
print(f'{len(F)} failed' if F else 'all passed')
sys.exit(1 if F else 0)
