#!/usr/bin/python3
"""5.0-16: `scanistryctl approve` and `deny` take the ID and -y in either order.

On 5.0-14 and 5.0-15, `sudo scanistryctl approve -y 66a8108d` took "-y" for the ID and failed with
"refused approval.show: aid: not an approval id (8 hex characters)"; only `approve ID -y` worked.

No root, no real broker: a stand-in broker listens on a temporary Unix socket and records what it is asked.
Usage: test_5016.py path/to/scanistry.py"""
import os, sys, socket, threading, tempfile, io, builtins, importlib.util, contextlib
os.environ['SCANISTRY_INPROCESS_BROKER'] = '1'
spec = importlib.util.spec_from_file_location('scanistry_5016', sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)

ID = '66a8108d'
calls = []
d = tempfile.mkdtemp(prefix='scanistry-5016-'); path = os.path.join(d, 'broker.sock')
srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM); srv.bind(path); srv.listen(8); srv.settimeout(0.2)
stop = threading.Event()
def serve():
    while not stop.is_set():
        try: c, _ = srv.accept()
        except socket.timeout: continue
        except OSError: return
        try:
            req, fds = m._sock_recv(c, m._BROKER_MAX_REQ)
            for f in fds: os.close(f)
            verb, args = req['verb'], req['args']; calls.append((verb, args.get('aid')))
            if args.get('aid') != ID: res = {'refused': 'aid: not an approval id (8 hex characters)'}
            elif verb == 'approval.show': res = {'result': {'id': ID, 'asked_by': 'pid 1 uid 112', 'age_seconds': 120, 'what': 'rebuild the baseline', 'verb': 'aide.reinit', 'args': {}}}
            elif verb == 'approval.grant': res = {'result': {'ok': True, 'id': ID}}
            elif verb == 'approval.deny': res = {'result': {'ok': True, 'id': ID}}
            else: res = {'refused': 'unexpected verb'}
            m._sock_send(c, res)
        finally: c.close()
threading.Thread(target=serve, daemon=True).start()
m.BROKER_SOCK = path
m.os.geteuid = lambda: 0

real_open = builtins.open
def no_tty_open(f, *a, **k):
    if f == '/dev/tty': raise OSError('no controlling terminal')
    return real_open(f, *a, **k)

def run(*argv, tty=False):
    """Run the approvals CLI as `scanistry.py --approve ...` would. Returns (rc, stdout+stderr, verbs asked)."""
    calls.clear(); out = io.StringIO()
    old = sys.argv; sys.argv = ['scanistry.py'] + list(argv)
    builtins.open = no_tty_open
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
            rc = m._main_approvals()
    finally:
        sys.argv = old; builtins.open = real_open
    return rc, out.getvalue(), list(calls)

rc, out, c = run('--approve', ID, '-y')
check('approve ID -y approves the request', rc == 0 and ('approval.grant', ID) in c)
rc, out, c = run('--approve', '-y', ID)
check('approve -y ID approves the request (the 5.0-15 failure)', rc == 0 and ('approval.grant', ID) in c and ('approval.show', '-y') not in c)
rc, out, c = run('--approve', '--yes', ID)
check('approve --yes ID approves the request', rc == 0 and ('approval.grant', ID) in c)
rc, out, c = run('--approve', ID)
check('approve ID without -y and without a terminal asks nothing, approves nothing and says what to do',
      rc == 1 and ('approval.grant', ID) not in c and 'add -y' in out)
rc, out, c = run('--approve', '-x', ID, '-y')
check('an unknown option is refused before the broker is asked', rc == 2 and 'unknown option -x' in out and not c)
rc, out, c = run('--approve', '-y')
check('approve -y with no ID prints the usage and does not ask the broker', rc == 2 and 'usage: scanistryctl approve ID' in out and not c)
rc, out, c = run('--deny', ID)
check('deny ID drops the request', rc == 0 and c == [('approval.deny', ID)])
rc, out, c = run('--deny', '-y', ID)
check('deny accepts the ID after an option too', rc == 0 and c == [('approval.deny', ID)])
rc, out, c = run('--deny')
check('deny with no ID prints the usage', rc == 2 and 'usage: scanistryctl deny ID' in out and not c)
rc, out, c = run('--approve', 'nothex1')
check("an ID the broker does not accept is reported as the broker's refusal", rc == 1 and 'not an approval id' in out)
if hasattr(m, '_approval_cli_args'):
    check('_approval_cli_args returns (id, yes, unknown options)',
          m._approval_cli_args(['x', '--approve', '-y', ID], '--approve') == (ID, True, []) and
          m._approval_cli_args(['x', '--approve', ID, '-q'], '--approve') == (ID, False, ['-q']))
else:
    check('_approval_cli_args exists', False)
src = open(os.path.join(os.path.dirname(os.path.abspath(sys.argv[1])), '..', '..', '..', 'usr/bin/scanistryctl')).read()
check('the scanistryctl wrapper passes every argument after approve/deny on', '--approve "$@"' in src and '--deny "$@"' in src)

stop.set(); srv.close()
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
