#!/usr/bin/python3
"""5.0-14 static checks: AppArmor enforce mode and its switch, the broker's narrower /run and fail-closed job profiles,
the CSP header, the new sysctls (and no end-of-line comments), and the corrected help text. No root needed.
Usage: test_5014.py path/to/scanistry.py"""
import sys, os, re, gzip, subprocess
HERE = os.path.dirname(os.path.abspath(sys.argv[1])); ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
rd = lambda p: open(os.path.join(ROOT, p)).read()
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
src = rd('usr/lib/scanistry/scanistry.py'); prof = rd('etc/apparmor.d/scanistry'); post = rd('DEBIAN/postinst')
# version
check('control version is 5.0-14 or later', re.search(r'^Version: 5\.0-(1[4-9]|[2-9][0-9])$', rd('DEBIAN/control'), re.M) is not None)
check("VERSION_FALLBACK is 5.0-14 or later", re.search(r"VERSION_FALLBACK='5\.0-(1[4-9]|[2-9][0-9])'", src) is not None)
check('the changelog exists', os.path.exists(os.path.join(ROOT, 'usr/share/doc/scanistry/CHANGELOG-5.0-14')))
# fix 2: AppArmor
check('both profiles are in enforce mode (no complain flag)', prof.count('flags=(attach_disconnected)') == 2 and 'flags=(complain' not in prof)
check('postinst honours the force-complain link', '/etc/apparmor.d/force-complain/scanistry' in post and '-r -W -C' in post)
check('postinst keeps complain mode on upgrade when this boot has ALLOWED lines', 'dpkg --compare-versions "$2" lt 5.0-14' in post and 'apparmor="ALLOWED"' in post)
check('postrm removes only its own force-complain link on purge', 'readlink /etc/apparmor.d/force-complain/scanistry' in rd('DEBIAN/postrm'))
check('scanistryctl apparmor exists and is executable', os.access(os.path.join(ROOT, 'usr/lib/scanistry/scanistry-apparmor'), os.X_OK) and 'apparmor) shift; exec /usr/lib/scanistry/scanistry-apparmor' in rd('usr/bin/scanistryctl'))
check('the daemon watches for denials from its own profiles', 'def apparmor_watch' in src and "step('apparmor watch',apparmor_watch)" in src)
for f in ('usr/lib/scanistry/scanistry-apparmor', 'usr/lib/scanistry/scanistry-broker-prep', 'usr/bin/scanistryctl', 'DEBIAN/postinst', 'DEBIAN/postrm'):
    check(f'{f} passes sh -n', subprocess.run(['sh', '-n', os.path.join(ROOT, f)]).returncode == 0)
# fix 3: broker
bu = rd('lib/systemd/system/scanistry-broker.service')
rw = re.search(r'^ReadWritePaths=(.*)$', bu, re.M).group(1).split()
check('the broker no longer has all of /run writable', '/run' not in rw and '-/run' not in rw)
check('it has exactly its three lock files and its runtime directory', set(rw) >= {'/run/scanistry', '-/run/lock/scanistry-aide.lock', '-/run/xtables.lock', '-/run/ufw.lock'} and not any(p.startswith(('/run', '-/run')) and p not in ('/run/scanistry', '-/run/lock/scanistry-aide.lock', '-/run/xtables.lock', '-/run/ufw.lock') for p in rw))
check('ExecStartPre=+ makes the lock files first', 'ExecStartPre=+/usr/lib/scanistry/scanistry-broker-prep' in bu and os.access(os.path.join(ROOT, 'usr/lib/scanistry/scanistry-broker-prep'), os.X_OK))
check('the broker profile lets it run the prep script', '/usr/lib/scanistry/scanistry-broker-prep rix,' in prof)
check("run_privileged no longer defaults to the all-capabilities profile", "else: prof='root'" not in src and "refused: no job profile for" in src)
# fix 4: CSP
check("the CSP header uses a per-load nonce and no 'unsafe-inline' for scripts",
      "script-src 'nonce-{nonce}'; script-src-attr 'none'" in src and "script-src 'unsafe-inline'" not in src and 'nonce=secrets.token_urlsafe(18)' in src)
page = src[src.index("DASHBOARD='''"):src.index("</script></body></html>'''")]
check('the page has no inline event handler attributes', not re.search(r'\bon[a-z]+=["\']', page))
check('its one <script> carries the nonce placeholder', page.count('<script') == 1 and '<script nonce="__CSP_NONCE__">' in page)
# fix 5: sysctl
sc = rd('etc/sysctl.d/60-scanistry-hardening.conf')
kv = dict(re.findall(r'^([a-z0-9_.]+)\s*=\s*(\S+)\s*$', sc, re.M))
for k, v in {'kernel.yama.ptrace_scope': '1', 'kernel.unprivileged_bpf_disabled': '1', 'net.core.bpf_jit_harden': '2',
             'net.ipv4.conf.all.rp_filter': '2', 'net.ipv4.conf.default.rp_filter': '2'}.items():
    check(f'sysctl {k} = {v}', kv.get(k) == v)
bad = [l for l in sc.split('\n') if re.match(r'^[a-z0-9_.]+[ \t]*=[ \t]*\S+[ \t]+\S', l)]
check('no sysctl line carries anything after its value (sysctl.d has no end-of-line comments): ' + (str(bad) or 'none'), not bad)
check('strict rp_filter (1) is still only a comment', 'net.ipv4.conf.all.rp_filter = 1' not in [l.strip() for l in sc.split('\n')])
# fix 6: help text
check('the help no longer says the AppArmor profile is an unloaded example', 'it is not loaded by default' not in src and '/usr/share/doc/scanistry/examples/' not in src)
check('the help explains approvals', 'sudo scanistryctl approve ID' in src)
man = gzip.open(os.path.join(ROOT, 'usr/share/man/man1/scanistryctl.1.gz'), 'rt').read()
check('the man page documents approvals, approve, deny and apparmor', all(w in man for w in ('.B approvals', 'approve', 'deny', 'apparmor')))
check('README.Debian documents approvals and the broker limits', 'Approvals (5.0-14)' in rd('usr/share/doc/scanistry/README.Debian') and 'What a compromised broker could still do' in rd('usr/share/doc/scanistry/README.Debian'))
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
