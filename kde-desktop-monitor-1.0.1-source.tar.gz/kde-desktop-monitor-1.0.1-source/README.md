Desktop System Monitor for Debian 13 (trixie)
================================================

This package provides a Plasma 6 desktop widget that behaves similarly to
Conky: it displays local system information directly on the desktop and
refreshes once per second.

Add it to the desktop:
  Right-click the KDE Plasma desktop -> Enter Edit Mode -> Add Widgets ->
  Desktop System Monitor.

Displayed data:
  CPU usage/model/cores, RAM, swap, root filesystem usage, load averages,
  uptime, kernel, Debian release, temperature and battery percentage.

Privacy:
  The collector intentionally does not read /proc/net, network interfaces,
  NetworkManager state, or IP configuration. No IP address is collected,
  stored, or displayed.

Security hardening in 1.0.1:
  - /etc/os-release is parsed as data and is never sourced/executed.
  - Collector input is validated before arithmetic or display.
  - The Plasma executable data source will not start overlapping collectors.
  - The collector uses only local read-only system information.
