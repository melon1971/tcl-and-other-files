import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.plasma5support as Plasma5Support
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root
    width: 390
    height: 430
    Layout.minimumWidth: 320
    Layout.minimumHeight: 300
    Plasmoid.preferredRepresentation: Plasmoid.fullRepresentation
    Plasmoid.title: "Desktop System Monitor"
    toolTipMainText: "Desktop System Monitor"
    toolTipSubText: "Real-time local system information"

    property bool busy: false

    property var info: ({
        OS: "Loading...",
        KERNEL: "",
        CPU: "",
        CORES: "",
        CPU_PCT: "0.0",
        RAM: "",
        SWAP: "",
        DISK: "",
        LOAD: "",
        UPTIME: "",
        TEMP: "N/A",
        BATTERY: "N/A"
    })

    function updateInfo(output) {
        var lines = output.split("\n")
        var next = {}
        for (var i = 0; i < lines.length; ++i) {
            var p = lines[i].indexOf("=")
            if (p > 0)
                next[lines[i].substring(0, p)] = lines[i].substring(p + 1).trim()
        }
        if (next.OS) {
            var merged = {
                OS: next.OS || "Loading...",
                KERNEL: next.KERNEL || "",
                CPU: next.CPU || "",
                CORES: next.CORES || "",
                CPU_PCT: next.CPU_PCT || "0.0",
                RAM: next.RAM || "",
                SWAP: next.SWAP || "",
                DISK: next.DISK || "",
                LOAD: next.LOAD || "",
                UPTIME: next.UPTIME || "",
                TEMP: next.TEMP || "N/A",
                BATTERY: next.BATTERY || "N/A"
            }
            info = merged
        }
    }

    Plasma5Support.DataSource {
        id: executable
        engine: "executable"
        connectedSources: []

        onNewData: function(sourceName, data) {
            executable.disconnectSource(sourceName)
            root.busy = false
            if (data["exit code"] === 0 && typeof data.stdout === "string")
                root.updateInfo(data.stdout)
        }

        function refresh() {
            if (root.busy)
                return
            root.busy = true
            executable.connectSource("/usr/libexec/kde-desktop-monitor/stats")
        }
    }

    Timer {
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: executable.refresh()
    }

    Rectangle {
        anchors.fill: parent
        radius: 12
        color: Qt.rgba(0.03, 0.03, 0.03, 0.82)
        border.width: 1
        border.color: Qt.rgba(1, 1, 1, 0.14)

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.largeSpacing
            spacing: Kirigami.Units.smallSpacing

            PlasmaComponents.Label {
                text: "SYSTEM MONITOR"
                font.bold: true
                font.pixelSize: Kirigami.Theme.defaultFont.pointSize + 3
                Layout.fillWidth: true
            }

            PlasmaComponents.Label {
                text: root.info.OS || ""
                elide: Text.ElideRight
                Layout.fillWidth: true
            }

            PlasmaComponents.Label {
                text: "Kernel: " + (root.info.KERNEL || "")
                Layout.fillWidth: true
            }

            PlasmaComponents.Label {
                text: "CPU: " + (root.info.CPU || "") + "  (" + (root.info.CORES || "?") + " cores)"
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }

            Rectangle { height: 1; color: Qt.rgba(1,1,1,0.12); Layout.fillWidth: true }

            PlasmaComponents.Label { text: "CPU Usage: " + (root.info.CPU_PCT || "0.0") + "%"; Layout.fillWidth: true }
            PlasmaComponents.Label { text: "Memory:    " + (root.info.RAM || ""); Layout.fillWidth: true }
            PlasmaComponents.Label { text: "Swap:      " + (root.info.SWAP || ""); Layout.fillWidth: true }
            PlasmaComponents.Label { text: "Disk (/):  " + (root.info.DISK || ""); Layout.fillWidth: true }
            PlasmaComponents.Label { text: "Load:      " + (root.info.LOAD || ""); Layout.fillWidth: true }
            PlasmaComponents.Label { text: "Uptime:    " + (root.info.UPTIME || ""); Layout.fillWidth: true }
            PlasmaComponents.Label { text: "Temperature: " + (root.info.TEMP || "N/A"); Layout.fillWidth: true }
            PlasmaComponents.Label { text: "Battery:     " + (root.info.BATTERY || "N/A"); Layout.fillWidth: true }

            Item { Layout.fillHeight: true }

            PlasmaComponents.Label {
                text: "Network addresses are not collected or displayed."
                opacity: 0.65
                font.pixelSize: Kirigami.Theme.smallFont.pixelSize
                Layout.fillWidth: true
            }
        }
    }
}
