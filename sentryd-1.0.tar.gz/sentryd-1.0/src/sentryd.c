/*
 * sentryd - PortSentry-style port scan detector with UFW integration.
 *
 * Watches every incoming TCP SYN on every interface (via an AF_PACKET raw
 * socket - no libpcap dependency), classifies each attempt as:
 *   - CONN  a SYN to a port the box is actually listening on
 *   - SCAN  a SYN to a port nothing is listening on (portsentry's classic
 *           "someone is probing me" signal)
 * Per-source-IP activity is aggregated in memory and flushed to a single
 * condensed log line per source per flush interval, instead of one line
 * per packet. Sources that cross SCAN_THRESHOLD distinct probed ports
 * inside one flush window get blocked with `ufw insert 1 deny from <ip>
 * to any`.
 *
 * No third-party libraries required: raw sockets + /proc/net/tcp{,6}.
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <poll.h>
#include <fcntl.h>
#include <ctype.h>
#include <stdarg.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/file.h>
#include <sys/random.h>

#include <net/if.h>
#include <ifaddrs.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#define SENTRYD_VERSION "1.0"
#define DEFAULT_CONF "/etc/sentryd/sentryd.conf"

/* ---------- configuration (overridable via config file) ---------- */

static struct {
    char log_dir[512];
    char log_file[128];
    char state_dir[512];
    char ignore_file[512];
    char interface[64];      /* "any" or a specific ifname */
    int  flush_interval;     /* seconds between condensed log flushes */
    int  refresh_interval;   /* seconds between re-reading listening ports */
    int  scan_threshold;     /* distinct closed ports hit -> block */
    int  scan_window;        /* seconds over which scan_threshold is evaluated -
                                 independent of flush_interval, so a slow/
                                 distributed-over-time scan that never bursts
                                 within one flush window still trips */
    int  block_enable;
    int  unblock_after;      /* seconds, 0 = never auto-unblock */
    int  idle_ttl;           /* seconds of inactivity before dropping a tracked src */
    char ufw_bin[256];
} cfg = {
    .log_dir = "/home/smullen/logfile",
    .log_file = "sentryd.log",
    .state_dir = "/var/lib/sentryd",
    .ignore_file = "/etc/sentryd/ignore.hosts",
    .interface = "any",
    .flush_interval = 60,
    .refresh_interval = 30,
    .scan_threshold = 3,
    .scan_window = 3600,
    .block_enable = 1,
    .unblock_after = 0,
    .idle_ttl = 900,
    .ufw_bin = "/usr/sbin/ufw",
};

static volatile sig_atomic_t g_reload = 0;
static volatile sig_atomic_t g_stop = 0;

/* forward declaration: defined near load_config(), used earlier by
 * ensure_log_dir()/ensure_state_dir() */
static int validate_dir_path(const char *field);

/* ---------- listening-port bitmap ---------- */

static unsigned char listening[65536];

static void refresh_listening_ports(void) {
    /* static, not a stack array: this function can run from the main loop
     * on a timer as well as from signal-driven reload paths, and there is
     * no reason to spend 64KB of stack (default thread/process stacks are
     * usually 8MB so it wasn't unsafe, just needless pressure) when a
     * single process-lifetime buffer works just as well - this function is
     * never called concurrently with itself (single-threaded daemon). */
    static unsigned char next[65536];
    memset(next, 0, sizeof(next));
    const char *files[2] = { "/proc/net/tcp", "/proc/net/tcp6" };
    for (int f = 0; f < 2; f++) {
        FILE *fp = fopen(files[f], "r");
        if (!fp) continue;
        char line[512];
        /* skip header */
        if (!fgets(line, sizeof(line), fp)) { fclose(fp); continue; }
        while (fgets(line, sizeof(line), fp)) {
            /* format: "  N: local_addr:local_port remote_addr:remote_port st ..." */
            char l_addr[128], r_addr[128], state_s[8];
            unsigned int local_port = 0;
            if (sscanf(line, " %*d: %127[^:]:%x %127[^:]:%*x %7s",
                       l_addr, &local_port, r_addr, state_s) != 4)
                continue;
            unsigned int state = (unsigned int)strtoul(state_s, NULL, 16);
            if (state == 0x0A && local_port < 65536) { /* TCP_LISTEN */
                next[local_port] = 1;
            }
        }
        fclose(fp);
    }
    memcpy(listening, next, sizeof(listening));
}

/* ---------- ignore list (CIDR, IPv4 + simple IPv6) ---------- */

typedef struct ignore_net {
    int is6;
    struct in_addr  v4;
    struct in6_addr v6;
    int prefix;
    struct ignore_net *next;
} ignore_net_t;

static ignore_net_t *g_ignores = NULL;

static void free_ignore_list(ignore_net_t *head) {
    ignore_net_t *n = head;
    while (n) { ignore_net_t *nx = n->next; free(n); n = nx; }
}

/* Builds the new ignore list into a local head and only swaps it into
 * g_ignores (freeing the old list) once the file has been fully read
 * without error. This avoids a "blind window": previously the live list
 * was wiped to NULL before fopen() was even attempted, so a transiently
 * missing/renamed ignore file (or a mid-edit save) would silently drop
 * every previously-trusted host - including the admin's own LAN - until
 * the next successful reload. On a read failure the old list is left
 * completely untouched. */
static void load_ignore_file(void) {
    FILE *fp = fopen(cfg.ignore_file, "r");
    if (!fp) return;

    ignore_net_t *new_head = NULL;
    char line[256];
    int lineno = 0;
    while (fgets(line, sizeof(line), fp)) {
        lineno++;
        char *p = line;
        while (isspace((unsigned char)*p)) p++;
        if (*p == '#' || *p == '\0' || *p == '\n') continue;
        char *nl = strpbrk(p, "\r\n");
        if (nl) *nl = '\0';
        if (*p == '\0') continue;

        char addr[256]; int prefix = -1;
        char *slash = strchr(p, '/');
        if (slash) {
            *slash = '\0';
            prefix = atoi(slash + 1);
        }
        snprintf(addr, sizeof(addr), "%s", p);

        int is6 = strchr(addr, ':') != NULL;
        int maxprefix = is6 ? 128 : 32;
        if (prefix > maxprefix) {
            fprintf(stderr, "sentryd: %s:%d: prefix /%d exceeds /%d for %s, ignoring line\n",
                    cfg.ignore_file, lineno, prefix, maxprefix, is6 ? "IPv6" : "IPv4");
            continue;
        }

        ignore_net_t *n = calloc(1, sizeof(ignore_net_t));
        if (!n) continue;
        if (is6) {
            n->is6 = 1;
            if (inet_pton(AF_INET6, addr, &n->v6) != 1) { free(n); continue; }
            n->prefix = (prefix < 0) ? 128 : prefix;
        } else {
            n->is6 = 0;
            if (inet_pton(AF_INET, addr, &n->v4) != 1) { free(n); continue; }
            n->prefix = (prefix < 0) ? 32 : prefix;
        }
        n->next = new_head;
        new_head = n;
    }
    fclose(fp);

    ignore_net_t *old_head = g_ignores;
    g_ignores = new_head;
    free_ignore_list(old_head);
}

static int ipv4_match(struct in_addr a, struct in_addr net, int prefix) {
    if (prefix <= 0) return 1;
    if (prefix >= 32) return a.s_addr == net.s_addr;
    uint32_t mask = htonl(~((1u << (32 - prefix)) - 1));
    return (a.s_addr & mask) == (net.s_addr & mask);
}

static int ipv6_match(struct in6_addr a, struct in6_addr net, int prefix) {
    if (prefix <= 0) return 1;
    if (prefix >= 128) return memcmp(&a, &net, sizeof(a)) == 0;
    int bytes = prefix / 8, rem = prefix % 8;
    if (bytes > 0 && memcmp(&a, &net, bytes) != 0) return 0;
    if (rem) {
        unsigned char mask = (unsigned char)(0xFF << (8 - rem));
        if ((a.s6_addr[bytes] & mask) != (net.s6_addr[bytes] & mask)) return 0;
    }
    return 1;
}

static int is_ignored(int is6, struct in_addr v4, struct in6_addr v6) {
    for (ignore_net_t *n = g_ignores; n; n = n->next) {
        if (n->is6 != is6) continue;
        if (is6) { if (ipv6_match(v6, n->v6, n->prefix)) return 1; }
        else     { if (ipv4_match(v4, n->v4, n->prefix)) return 1; }
    }
    return 0;
}

/* ---------- per-source aggregation table ---------- */

#define HASH_SIZE 2048
#define MAX_TRACK_PORTS 8

/* Rolling window of recent closed-port hits, kept independently of the
 * flush/logging cadence, so a source that spaces its probes out (one
 * port every few minutes, forever) still accumulates toward
 * scan_threshold instead of having its count wiped every flush_interval.
 * Fixed-size ring buffer: bounds memory per source regardless of how
 * long the scan runs; a fast scanner trips scan_threshold long before
 * this fills, a slow one just takes longer to fill it. */
#define MAX_EVENTS 64

typedef struct scan_entry {
    char ip[INET6_ADDRSTRLEN];
    time_t first_seen;
    time_t last_seen;
    time_t blocked_since;
    int window_conn;
    int window_scan;
    uint16_t ports[MAX_TRACK_PORTS];
    int port_count;
    int port_overflow;
    int blocked;

    time_t   event_ts[MAX_EVENTS];
    uint16_t event_port[MAX_EVENTS];
    int event_count;   /* valid entries, <= MAX_EVENTS */
    int event_next;    /* ring buffer write cursor */

    struct scan_entry *next;
} scan_entry_t;

static scan_entry_t *table[HASH_SIZE];

/* Per-process random seed folded into the FNV-1a hash below, so the bucket
 * an IP lands in can't be predicted from outside. Without this, an
 * FNV-1a hash with a fixed offset basis is a published, reversible
 * function of the input bytes - and this table's keys (source IPs) are
 * attacker-controlled on internet-facing scan-detection code, so a bad
 * actor who wanted to could choose IPs designed to collide into the same
 * bucket and turn every table lookup into an O(n) walk (an algorithmic-
 * complexity DoS). getrandom() failing (very old kernel, seccomp, etc.)
 * falls back to a still-varying-per-run seed rather than a hard failure. */
static unsigned g_hash_seed;

static void init_hash_seed(void) {
#ifdef __linux__
    if (getrandom(&g_hash_seed, sizeof(g_hash_seed), 0) == (ssize_t)sizeof(g_hash_seed))
        return;
#endif
    g_hash_seed = (unsigned)time(NULL) ^ (unsigned)getpid();
}

static unsigned hash_str(const char *s) {
    unsigned h = 2166136261u ^ g_hash_seed;
    while (*s) { h ^= (unsigned char)*s++; h *= 16777619u; }
    return h % HASH_SIZE;
}

static scan_entry_t *entry_get(const char *ip, int create) {
    unsigned b = hash_str(ip);
    for (scan_entry_t *e = table[b]; e; e = e->next)
        if (strcmp(e->ip, ip) == 0) return e;
    if (!create) return NULL;
    scan_entry_t *e = calloc(1, sizeof(scan_entry_t));
    if (!e) return NULL;
    snprintf(e->ip, sizeof(e->ip), "%s", ip);
    e->first_seen = time(NULL);
    e->next = table[b];
    table[b] = e;
    return e;
}

static void entry_remove(unsigned b, scan_entry_t *target) {
    scan_entry_t **pp = &table[b];
    while (*pp) {
        if (*pp == target) { *pp = target->next; free(target); return; }
        pp = &(*pp)->next;
    }
}

/* Record one closed-port hit in the rolling ring buffer. */
static void add_scan_event(scan_entry_t *e, time_t now, uint16_t port) {
    e->event_ts[e->event_next] = now;
    e->event_port[e->event_next] = port;
    e->event_next = (e->event_next + 1) % MAX_EVENTS;
    if (e->event_count < MAX_EVENTS) e->event_count++;
}

/* Count distinct closed ports hit within the last window_secs, regardless
 * of how they're spread out in time - this is the actual scan-detection
 * signal, independent of the log-flush cadence. */
static int distinct_ports_in_window(const scan_entry_t *e, time_t now, int window_secs) {
    uint16_t seen[MAX_EVENTS];
    int seen_n = 0;
    for (int i = 0; i < e->event_count; i++) {
        if (window_secs > 0 && (now - e->event_ts[i]) > window_secs) continue;
        uint16_t p = e->event_port[i];
        int dup = 0;
        for (int j = 0; j < seen_n; j++) {
            if (seen[j] == p) { dup = 1; break; }
        }
        if (!dup) seen[seen_n++] = p;
    }
    return seen_n;
}

/* ---------- logging ---------- */

static char g_logpath[1024];

static void ensure_log_dir(void) {
    /* mkdir -p cfg.log_dir. load_config()'s validate_dir_path() call
     * guarantees cfg.log_dir is a non-empty absolute path by the time we
     * get here, but a defensive check costs nothing and keeps this
     * function safe even if it's ever called from a new path that skips
     * that validation. */
    if (!validate_dir_path(cfg.log_dir)) return;
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s", cfg.log_dir);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0750) != 0 && errno != EEXIST)
                fprintf(stderr, "sentryd: mkdir %s: %s\n", tmp, strerror(errno));
            *p = '/';
        }
    }
    if (mkdir(tmp, 0750) != 0 && errno != EEXIST)
        fprintf(stderr, "sentryd: mkdir %s: %s\n", tmp, strerror(errno));
    snprintf(g_logpath, sizeof(g_logpath), "%s/%s", cfg.log_dir, cfg.log_file);
}

static void log_line(const char *fmt, ...) {
    FILE *fp = fopen(g_logpath, "a");
    if (!fp) return;
    int fd = fileno(fp);
    flock(fd, LOCK_EX);

    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y-%m-%dT%H:%M:%S%z", &tmv);
    fprintf(fp, "%s ", ts);

    va_list ap;
    va_start(ap, fmt);
    vfprintf(fp, fmt, ap);
    va_end(ap);
    fprintf(fp, "\n");

    flock(fd, LOCK_UN);
    fclose(fp);
}

/* ---------- state persistence for blocked IPs ---------- */

static char g_blockfile[1024];

static void ensure_state_dir(void) {
    if (!validate_dir_path(cfg.state_dir)) return;
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s", cfg.state_dir);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0750) != 0 && errno != EEXIST)
                fprintf(stderr, "sentryd: mkdir %s: %s\n", tmp, strerror(errno));
            *p = '/';
        }
    }
    if (mkdir(tmp, 0750) != 0 && errno != EEXIST)
        fprintf(stderr, "sentryd: mkdir %s: %s\n", tmp, strerror(errno));
    snprintf(g_blockfile, sizeof(g_blockfile), "%s/blocked.list", cfg.state_dir);
}

/* ---------- single-instance lock ---------- */

static int g_lockfd = -1;

/* Nothing previously stopped two sentryd instances running at once - a
 * systemd restart briefly overlapping old and new processes, or an admin
 * manually starting a second instance for testing. That would race
 * unprotected concurrent writes to blocked.list (persist_block/
 * persist_remove_block's read-filter-rename isn't atomic against a
 * concurrent append), and could issue duplicate/conflicting ufw rules.
 * A non-blocking exclusive flock() on a file under state_dir, held for
 * the whole process lifetime, makes a second instance fail fast and
 * loudly instead of quietly corrupting shared state. Must be called
 * after ensure_state_dir() so the directory (and hence the lock file)
 * exists, and before daemon() so the failure is visible on stderr/exit
 * code rather than lost after backgrounding. The fd is intentionally
 * inherited across the daemon() fork - flock() locks are tied to the
 * open file description, not the pid, so the child keeps holding it. */
static int acquire_run_lock(void) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/sentryd.lock", cfg.state_dir);
    int fd = open(path, O_RDWR | O_CREAT, 0640);
    if (fd < 0) {
        fprintf(stderr, "sentryd: cannot open lock file %s: %s\n", path, strerror(errno));
        return -1;
    }
    if (flock(fd, LOCK_EX | LOCK_NB) != 0) {
        if (errno == EWOULDBLOCK) {
            fprintf(stderr, "sentryd: another instance is already running (lock held on %s)\n", path);
        } else {
            fprintf(stderr, "sentryd: flock %s: %s\n", path, strerror(errno));
        }
        close(fd);
        return -1;
    }
    /* Leave a trail for anyone reading the lock file by hand. Best-effort:
     * a failed write here doesn't affect the lock itself. */
    if (ftruncate(fd, 0) == 0) {
        char pidbuf[32];
        int len = snprintf(pidbuf, sizeof(pidbuf), "%d\n", getpid());
        ssize_t w = write(fd, pidbuf, (size_t)len);
        (void)w;
    }
    g_lockfd = fd; /* kept open, and thus locked, for the rest of the process */
    return 0;
}

static void release_run_lock(void) {
    if (g_lockfd >= 0) {
        flock(g_lockfd, LOCK_UN);
        close(g_lockfd);
        g_lockfd = -1;
    }
}

static void persist_block(const char *ip) {
    FILE *fp = fopen(g_blockfile, "a");
    if (!fp) return;
    time_t now = time(NULL);
    fprintf(fp, "%s %ld\n", ip, (long)now);
    fclose(fp);
}

static void persist_remove_block(const char *ip) {
    FILE *fp = fopen(g_blockfile, "r");
    if (!fp) return;
    char tmp[1032];
    snprintf(tmp, sizeof(tmp), "%s.tmp", g_blockfile);
    FILE *out = fopen(tmp, "w");
    if (!out) { fclose(fp); return; }
    char line[256];
    while (fgets(line, sizeof(line), fp)) {
        char lip[128];
        if (sscanf(line, "%127s", lip) == 1 && strcmp(lip, ip) == 0) continue;
        fputs(line, out);
    }
    fclose(fp);
    fclose(out);
    rename(tmp, g_blockfile);
}

static void load_blocked_on_startup(void) {
    FILE *fp = fopen(g_blockfile, "r");
    if (!fp) return;
    char line[256];
    while (fgets(line, sizeof(line), fp)) {
        char ip[128]; long since = 0;
        if (sscanf(line, "%127s %ld", ip, &since) >= 1) {
            scan_entry_t *e = entry_get(ip, 1);
            if (e) { e->blocked = 1; e->blocked_since = since ? since : time(NULL);
                      e->last_seen = time(NULL); }
        }
    }
    fclose(fp);
}

/* ---------- ufw integration ---------- */

#define UFW_WAIT_TIMEOUT_SECONDS 5

/* run_ufw() is called synchronously from record_hit(), which is in the
 * hot packet-processing path - a ufw subprocess that hangs (stuck on an
 * iptables/dpkg lock held by something else, say) must never be waited on
 * unboundedly, or it wedges the entire daemon: no more packets processed,
 * signal handling delayed, scan detection stalled for every other source
 * too. Poll for exit with WNOHANG for up to UFW_WAIT_TIMEOUT_SECONDS, then
 * escalate to SIGKILL and reap it so it can never accumulate as a zombie. */
static int run_ufw(const char *action_args[], int n) {
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) {
        int devnull = open("/dev/null", O_RDWR);
        if (devnull >= 0) { dup2(devnull, STDOUT_FILENO); dup2(devnull, STDERR_FILENO); }
        char *argv[16];
        argv[0] = (char *)cfg.ufw_bin;
        int i;
        for (i = 0; i < n && i < 14; i++) argv[i + 1] = (char *)action_args[i];
        argv[i + 1] = NULL;
        execv(cfg.ufw_bin, argv);
        _exit(127);
    }

    int status = 0;
    struct timespec start, now;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (;;) {
        pid_t r = waitpid(pid, &status, WNOHANG);
        if (r == pid) return WIFEXITED(status) ? WEXITSTATUS(status) : -1;
        if (r < 0 && errno != EINTR) return -1;

        clock_gettime(CLOCK_MONOTONIC, &now);
        double elapsed = (now.tv_sec - start.tv_sec) + (now.tv_nsec - start.tv_nsec) / 1e9;
        if (elapsed >= UFW_WAIT_TIMEOUT_SECONDS) {
            kill(pid, SIGKILL);
            waitpid(pid, &status, 0); /* reap - SIGKILL always terminates it */
            fprintf(stderr, "sentryd: %s did not exit within %ds, killed\n",
                    cfg.ufw_bin, UFW_WAIT_TIMEOUT_SECONDS);
            return -1;
        }
        struct timespec ts = { .tv_sec = 0, .tv_nsec = 50 * 1000 * 1000 }; /* 50ms */
        nanosleep(&ts, NULL);
    }
}

static void ufw_block(const char *ip) {
    const char *args[] = { "insert", "1", "deny", "from", ip, "to", "any" };
    int rc = run_ufw(args, 7);
    log_line("BLOCK src=%s action=%s (ufw insert deny)", ip, rc == 0 ? "blocked" : "block_failed");
}

static void ufw_unblock(const char *ip) {
    const char *args[] = { "delete", "deny", "from", ip, "to", "any" };
    int rc = run_ufw(args, 6);
    log_line("UNBLOCK src=%s action=%s", ip, rc == 0 ? "unblocked" : "unblock_failed");
}

/* ---------- flush: write condensed lines, expire idle/blocked entries ---------- */

static void flush_and_reset(void) {
    time_t now = time(NULL);
    for (int b = 0; b < HASH_SIZE; b++) {
        scan_entry_t *e = table[b];
        while (e) {
            scan_entry_t *next = e->next;

            if (e->window_conn > 0 || e->window_scan > 0) {
                char portbuf[128] = "";
                int off = 0;
                for (int i = 0; i < e->port_count && off < (int)sizeof(portbuf) - 8; i++) {
                    off += snprintf(portbuf + off, sizeof(portbuf) - off, "%s%u",
                                     i ? "," : "", e->ports[i]);
                }
                if (e->port_overflow && off < (int)sizeof(portbuf) - 8)
                    snprintf(portbuf + off, sizeof(portbuf) - off, "+more");

                if (e->window_scan > 0) {
                    log_line("SCAN src=%s ports=%s attempts=%d action=%s",
                              e->ip, portbuf, e->window_scan,
                              e->blocked ? "blocked" : "logged");
                }
                if (e->window_conn > 0) {
                    log_line("CONN src=%s attempts=%d action=allowed",
                              e->ip, e->window_conn);
                }
                e->window_conn = 0;
                e->window_scan = 0;
                e->port_count = 0;
                e->port_overflow = 0;
            }

            if (cfg.unblock_after > 0 && e->blocked &&
                e->blocked_since > 0 &&
                (now - e->blocked_since) >= cfg.unblock_after) {
                ufw_unblock(e->ip);
                persist_remove_block(e->ip);
                e->blocked = 0;
                e->blocked_since = 0;
            }

            if (!e->blocked && (now - e->last_seen) > cfg.idle_ttl) {
                entry_remove(b, e);
            }

            e = next;
        }
    }
}

/* ---------- record a SYN observation ---------- */

static void record_hit(const char *ip, unsigned int dst_port) {
    scan_entry_t *e = entry_get(ip, 1);
    if (!e) return;
    e->last_seen = time(NULL);

    int is_open = listening[dst_port & 0xFFFF];
    if (is_open) {
        e->window_conn++;
        return;
    }

    e->window_scan++;
    int dup = 0;
    for (int i = 0; i < e->port_count; i++)
        if (e->ports[i] == dst_port) { dup = 1; break; }
    if (!dup) {
        if (e->port_count < MAX_TRACK_PORTS) e->ports[e->port_count++] = (uint16_t)dst_port;
        else e->port_overflow = 1;
    }

    /* Detection is decoupled from the logging cadence: window_scan/ports[]
     * above are only for the human-readable condensed line and reset every
     * flush_interval, but the block decision below looks at every closed-
     * port hit from this source over the last scan_window seconds, so a
     * scan spaced out slower than one flush_interval still accumulates
     * and eventually crosses scan_threshold. */
    add_scan_event(e, e->last_seen, (uint16_t)dst_port);

    if (cfg.block_enable && !e->blocked) {
        int distinct = distinct_ports_in_window(e, e->last_seen, cfg.scan_window);
        if (distinct >= cfg.scan_threshold) {
            e->blocked = 1;
            e->blocked_since = time(NULL);
            ufw_block(ip);
            persist_block(ip);
        }
    }
}

/* ---------- local address table (so we only react to traffic aimed at us) ---------- */

typedef struct local_addr {
    int is6;
    struct in_addr v4;
    struct in6_addr v6;
    struct local_addr *next;
} local_addr_t;

static local_addr_t *g_local = NULL;

static void free_local_list(local_addr_t *head) {
    local_addr_t *n = head;
    while (n) { local_addr_t *nx = n->next; free(n); n = nx; }
}

/* Same build-then-swap discipline as load_ignore_file(): the old list is
 * kept live until getifaddrs() has actually succeeded and the new list is
 * fully built. Previously g_local was wiped to NULL first, so a transient
 * getifaddrs() failure left it empty and is_local_v4()/is_local_v6() would
 * then reject every packet as "not for us" - silently blinding the whole
 * daemon until the next periodic refresh (up to refresh_interval later). */
static void refresh_local_addrs(void) {
    struct ifaddrs *ifa, *p;
    if (getifaddrs(&ifa) != 0) return;

    local_addr_t *new_head = NULL;
    for (p = ifa; p; p = p->ifa_next) {
        if (!p->ifa_addr) continue;
        if (p->ifa_flags & IFF_LOOPBACK) continue;
        local_addr_t *n2 = calloc(1, sizeof(local_addr_t));
        if (!n2) continue;
        if (p->ifa_addr->sa_family == AF_INET) {
            n2->is6 = 0;
            n2->v4 = ((struct sockaddr_in *)p->ifa_addr)->sin_addr;
        } else if (p->ifa_addr->sa_family == AF_INET6) {
            n2->is6 = 1;
            n2->v6 = ((struct sockaddr_in6 *)p->ifa_addr)->sin6_addr;
        } else {
            free(n2);
            continue;
        }
        n2->next = new_head;
        new_head = n2;
    }
    freeifaddrs(ifa);

    local_addr_t *old_head = g_local;
    g_local = new_head;
    free_local_list(old_head);
}

static int is_local_v4(struct in_addr a) {
    for (local_addr_t *n = g_local; n; n = n->next)
        if (!n->is6 && n->v4.s_addr == a.s_addr) return 1;
    return 0;
}
static int is_local_v6(struct in6_addr a) {
    for (local_addr_t *n = g_local; n; n = n->next)
        if (n->is6 && memcmp(&n->v6, &a, sizeof(a)) == 0) return 1;
    return 0;
}

/* ---------- config file parsing ---------- */

static void trim(char *s) {
    char *p = s;
    while (isspace((unsigned char)*p)) p++;
    if (p != s) memmove(s, p, strlen(p) + 1);
    size_t l = strlen(s);
    while (l > 0 && isspace((unsigned char)s[l - 1])) s[--l] = '\0';
}

/* Rejects an empty or non-absolute directory path. ensure_log_dir() and
 * ensure_state_dir() build a mutable copy and then walk it starting at
 * index 1 looking for '/' separators to mkdir -p each component; an empty
 * string only null-terminates tmp[0], leaving tmp[1..] as uninitialized
 * stack memory that the walk would then read as if it were the path -
 * undefined behavior, and in the worst case (no incidental zero byte) a
 * read past the buffer. Requiring a non-empty absolute path up front
 * closes that off entirely rather than papering over it in the walk. */
static int validate_dir_path(const char *field) {
    return field[0] == '/' && field[1] != '\0';
}

static void load_config(const char *path) {
    FILE *fp = fopen(path, "r");
    if (!fp) return;
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        char *nl = strpbrk(line, "\r\n");
        if (nl) *nl = '\0';
        char *h = strchr(line, '#');
        if (h) *h = '\0';
        trim(line);
        if (line[0] == '\0') continue;
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq = '\0';
        char *key = line, *val = eq + 1;
        trim(key); trim(val);

        if (!strcasecmp(key, "LOG_DIR")) snprintf(cfg.log_dir, sizeof(cfg.log_dir), "%s", val);
        else if (!strcasecmp(key, "LOG_FILE")) snprintf(cfg.log_file, sizeof(cfg.log_file), "%s", val);
        else if (!strcasecmp(key, "STATE_DIR")) snprintf(cfg.state_dir, sizeof(cfg.state_dir), "%s", val);
        else if (!strcasecmp(key, "IGNORE_FILE")) snprintf(cfg.ignore_file, sizeof(cfg.ignore_file), "%s", val);
        else if (!strcasecmp(key, "INTERFACE")) snprintf(cfg.interface, sizeof(cfg.interface), "%s", val);
        else if (!strcasecmp(key, "FLUSH_INTERVAL")) cfg.flush_interval = atoi(val);
        else if (!strcasecmp(key, "REFRESH_INTERVAL")) cfg.refresh_interval = atoi(val);
        else if (!strcasecmp(key, "SCAN_THRESHOLD")) cfg.scan_threshold = atoi(val);
        else if (!strcasecmp(key, "SCAN_WINDOW_SECONDS")) cfg.scan_window = atoi(val);
        else if (!strcasecmp(key, "BLOCK_ENABLE")) cfg.block_enable = atoi(val);
        else if (!strcasecmp(key, "UNBLOCK_AFTER")) cfg.unblock_after = atoi(val);
        else if (!strcasecmp(key, "IDLE_TTL")) cfg.idle_ttl = atoi(val);
        else if (!strcasecmp(key, "UFW_BIN")) snprintf(cfg.ufw_bin, sizeof(cfg.ufw_bin), "%s", val);
    }
    fclose(fp);

    /* A tracked source must survive at least as long as scan_window or a
     * slow scan's earlier hits would be reaped by idle cleanup before they
     * can accumulate toward scan_threshold, silently defeating the whole
     * point of scan_window. */
    if (cfg.idle_ttl < cfg.scan_window) cfg.idle_ttl = cfg.scan_window;

    if (!validate_dir_path(cfg.log_dir)) {
        fprintf(stderr, "sentryd: LOG_DIR '%s' must be a non-root absolute path, "
                        "falling back to /home/smullen/logfile\n", cfg.log_dir);
        snprintf(cfg.log_dir, sizeof(cfg.log_dir), "%s", "/home/smullen/logfile");
    }
    if (!validate_dir_path(cfg.state_dir)) {
        fprintf(stderr, "sentryd: STATE_DIR '%s' must be a non-root absolute path, "
                        "falling back to /var/lib/sentryd\n", cfg.state_dir);
        snprintf(cfg.state_dir, sizeof(cfg.state_dir), "%s", "/var/lib/sentryd");
    }
}

/* ---------- signal handlers ---------- */

static void on_sighup(int sig)  { (void)sig; g_reload = 1; }
static void on_sigterm(int sig) { (void)sig; g_stop = 1; }

/* ---------- packet parsing ---------- */

static void handle_packet(const unsigned char *buf, ssize_t len) {
    if (len < (ssize_t)sizeof(struct ethhdr)) return;
    const struct ethhdr *eth = (const struct ethhdr *)buf;
    uint16_t proto = ntohs(eth->h_proto);
    size_t off = sizeof(struct ethhdr);

    /* Unwrap up to two nested 802.1Q tags: a single-tagged frame (proto
     * 0x8100) is the common case, but a QinQ/double-tagged frame (an
     * outer 0x88A8 or 0x9100 service-provider tag wrapping an inner
     * 0x8100 customer tag) is a real, if uncommon, on-the-wire shape on
     * provider-bridged networks - previously only one tag was unwrapped,
     * so a double-tagged SYN's real ethertype was misread as 0x8100
     * itself and the packet was silently dropped instead of classified. */
    for (int vlan_depth = 0; vlan_depth < 2 &&
         (proto == 0x8100 || proto == 0x88A8 || proto == 0x9100); vlan_depth++) {
        if (len < (ssize_t)(off + 4)) return;
        proto = ntohs(*(const uint16_t *)(buf + off + 2));
        off += 4;
    }

    if (proto == ETH_P_IP) {
        if (len < (ssize_t)(off + sizeof(struct iphdr))) return;
        /* buf is a raw AF_PACKET receive buffer, and off is 14 (an Ethernet
         * header) or 18/22 (with one/two VLAN tags) bytes past whatever
         * alignment malloc() gave buf - never guaranteed to be a multiple
         * of 4. Reinterpret-casting buf+off straight to an IP/TCP header
         * pointer and dereferencing multi-byte members through it is
         * undefined behavior on a misaligned pointer (confirmed live by
         * UBSan against real captured traffic: "member access within
         * misaligned address ... requires 4 byte alignment"). x86 quietly
         * tolerates it at a small performance cost, but it is still UB and
         * would fault on a strict-alignment target. memcpy() into a local,
         * naturally-aligned struct sidesteps the problem entirely. */
        struct iphdr ip;
        memcpy(&ip, buf + off, sizeof(ip));
        if (ip.protocol != IPPROTO_TCP) return;
        size_t ihl = ip.ihl * 4;
        if (ihl < sizeof(struct iphdr) || len < (ssize_t)(off + ihl + sizeof(struct tcphdr))) return;
        struct tcphdr tcp;
        memcpy(&tcp, buf + off + ihl, sizeof(tcp));
        if (!(tcp.syn && !tcp.ack)) return;

        struct in_addr dst; dst.s_addr = ip.daddr;
        if (!is_local_v4(dst)) return;

        struct in_addr src; src.s_addr = ip.saddr;
        struct in6_addr dummy6;
        if (is_ignored(0, src, dummy6)) return;

        char ipstr[INET6_ADDRSTRLEN];
        inet_ntop(AF_INET, &src, ipstr, sizeof(ipstr));
        record_hit(ipstr, ntohs(tcp.dest));

    } else if (proto == ETH_P_IPV6) {
        if (len < (ssize_t)(off + sizeof(struct ip6_hdr))) return;
        struct ip6_hdr ip6;
        memcpy(&ip6, buf + off, sizeof(ip6));
        if (ip6.ip6_nxt != IPPROTO_TCP) return; /* ignore extension-header chains */
        size_t hlen = sizeof(struct ip6_hdr);
        if (len < (ssize_t)(off + hlen + sizeof(struct tcphdr))) return;
        struct tcphdr tcp;
        memcpy(&tcp, buf + off + hlen, sizeof(tcp));
        if (!(tcp.syn && !tcp.ack)) return;

        if (!is_local_v6(ip6.ip6_dst)) return;

        struct in_addr dummy4;
        if (is_ignored(1, dummy4, ip6.ip6_src)) return;

        char ipstr[INET6_ADDRSTRLEN];
        inet_ntop(AF_INET6, &ip6.ip6_src, ipstr, sizeof(ipstr));
        record_hit(ipstr, ntohs(tcp.dest));
    }
}

/* ---------- main ---------- */

static int open_raw_socket(void) {
    int fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (fd < 0) return -1;

    if (strcmp(cfg.interface, "any") != 0) {
        unsigned ifindex = if_nametoindex(cfg.interface);
        if (ifindex == 0) {
            fprintf(stderr, "sentryd: unknown interface '%s'\n", cfg.interface);
            close(fd);
            return -1;
        }
        struct sockaddr_ll sll;
        memset(&sll, 0, sizeof(sll));
        sll.sll_family = AF_PACKET;
        sll.sll_protocol = htons(ETH_P_ALL);
        sll.sll_ifindex = (int)ifindex;
        if (bind(fd, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
            close(fd);
            return -1;
        }
    }
    return fd;
}

static void usage(const char *prog) {
    fprintf(stderr, "usage: %s [-c config] [-f] [-v]\n"
                     "  -c FILE   config file (default %s)\n"
                     "  -f        stay in foreground, don't daemonize\n"
                     "  -v        print version and exit\n",
            prog, DEFAULT_CONF);
}

int main(int argc, char **argv) {
    const char *confpath = DEFAULT_CONF;
    int foreground = 0;
    int opt;
    while ((opt = getopt(argc, argv, "c:fvh")) != -1) {
        switch (opt) {
            case 'c': confpath = optarg; break;
            case 'f': foreground = 1; break;
            case 'v': printf("sentryd %s\n", SENTRYD_VERSION); return 0;
            default: usage(argv[0]); return 2;
        }
    }

    init_hash_seed();
    load_config(confpath);
    load_ignore_file();
    ensure_log_dir();
    ensure_state_dir();

    if (acquire_run_lock() != 0) {
        /* Message already printed by acquire_run_lock(). */
        return 1;
    }

    load_blocked_on_startup();
    refresh_local_addrs();
    refresh_listening_ports();

    int fd = open_raw_socket();
    if (fd < 0) {
        fprintf(stderr, "sentryd: cannot open raw socket (need CAP_NET_RAW / root): %s\n",
                strerror(errno));
        release_run_lock();
        return 1;
    }

    if (!foreground) {
        if (daemon(0, 0) != 0) {
            fprintf(stderr, "sentryd: daemon() failed: %s\n", strerror(errno));
            return 1;
        }
    }

    struct sigaction sa_term = { .sa_handler = on_sigterm };
    struct sigaction sa_hup  = { .sa_handler = on_sighup };
    sigaction(SIGTERM, &sa_term, NULL);
    sigaction(SIGINT, &sa_term, NULL);
    sigaction(SIGHUP, &sa_hup, NULL);
    signal(SIGCHLD, SIG_DFL);
    signal(SIGPIPE, SIG_IGN);

    log_line("STARTUP sentryd %s pid=%d iface=%s log_dir=%s threshold=%d/%ds flush=%ds",
              SENTRYD_VERSION, getpid(), cfg.interface, cfg.log_dir,
              cfg.scan_threshold, cfg.scan_window, cfg.flush_interval);

    time_t last_flush = time(NULL);
    time_t last_refresh = time(NULL);

    unsigned char *buf = malloc(65536);
    if (!buf) { log_line("FATAL out of memory"); return 1; }

    while (!g_stop) {
        struct pollfd pfd = { .fd = fd, .events = POLLIN };
        int timeout_ms = 1000;
        int rc = poll(&pfd, 1, timeout_ms);

        if (g_reload) {
            load_config(confpath);
            load_ignore_file();
            ensure_log_dir();
            ensure_state_dir();
            log_line("RELOAD config reloaded from %s", confpath);
            g_reload = 0;
        }

        if (rc > 0 && (pfd.revents & POLLIN)) {
            ssize_t n = recv(fd, buf, 65536, 0);
            if (n > 0) handle_packet(buf, n);
        }

        time_t now = time(NULL);
        if (now - last_refresh >= cfg.refresh_interval) {
            refresh_listening_ports();
            refresh_local_addrs();
            last_refresh = now;
        }
        if (now - last_flush >= cfg.flush_interval) {
            flush_and_reset();
            last_flush = now;
        }
    }

    flush_and_reset();
    log_line("SHUTDOWN sentryd pid=%d stopping", getpid());
    free(buf);
    close(fd);

    /* Clean, valgrind-quiet teardown: frees every list this process built
     * rather than leaving them for the OS to reclaim on exit, and keeps
     * free_ignore_list()/free_local_list() genuinely used (not dead code
     * left over from the load_ignore_file()/refresh_local_addrs() build-
     * then-swap rework) beyond just the reload path. */
    free_ignore_list(g_ignores);
    free_local_list(g_local);
    for (int b = 0; b < HASH_SIZE; b++) {
        scan_entry_t *e = table[b];
        while (e) { scan_entry_t *nx = e->next; free(e); e = nx; }
    }
    release_run_lock();
    return 0;
}
