# sentryd

A PortSentry-style port scan detector for Debian, integrated with `ufw`.
No libpcap dependency - it reads raw Ethernet frames straight off an
`AF_PACKET` socket, so the only build requirement is a C compiler and
`debhelper`.

## What it does

- Watches every interface (or one you name) for incoming TCP SYN packets,
  IPv4 and IPv6.
- Cross-checks the destination port against `/proc/net/tcp{,6}` (refreshed
  every `REFRESH_INTERVAL` seconds) to tell a real connection attempt to a
  service you're running (`CONN`) from a probe of a port nothing is
  listening on (`SCAN`) - the same signal classic portsentry used.
- Aggregates hits per source IP in memory and writes **one condensed line
  per source per `FLUSH_INTERVAL`**, not one line per packet. A source
  scanning you continuously produces one growing summary line every
  minute, not a wall of text.
- When a source hits `SCAN_THRESHOLD` distinct closed ports inside one
  flush window, it's blocked with:
  ```
  ufw insert 1 deny from <ip> to any
  ```
  and recorded in `/var/lib/sentryd/blocked.list` so it survives restarts
  and duplicate inserts are avoided.

## Log format

```
2026-09-22T20:45:00-0500 SCAN src=203.0.113.9 ports=22,3389,8080 attempts=6 action=blocked
2026-09-22T20:46:00-0500 CONN src=198.51.100.4 attempts=3 action=allowed
2026-09-22T20:47:00-0500 BLOCK src=203.0.113.9 action=blocked (ufw insert deny)
```

Default location: `/home/smullen/logfile/sentryd.log`, plus a
`logrotate.d` policy (weekly, 8 kept, compressed, 5M safety cap) as a
backstop against sustained flooding.

## Installing

A prebuilt `sentryd_1.0-3_amd64.deb` is provided alongside this source
tree - **install it directly, no build tools needed**:

```sh
sudo apt-get install ./sentryd_1.0-3_amd64.deb   # pulls in ufw, systemd
```

It's statically linked specifically so it has no glibc-version dependency
on the target box (dynamically linking on a newer build machine, e.g.
Ubuntu 24.04, pulls in GLIBC_2.38 symbols that most current Debian
releases don't ship yet - static sidesteps that entirely). It only needs
a reasonably current Linux kernel (raw AF_PACKET sockets, standard since
forever) and amd64. For any other architecture, or if you'd rather build
locally, use the source tree instead:

```sh
sudo apt-get install build-essential debhelper
dpkg-buildpackage -us -uc -b
sudo apt-get install ../sentryd_1.0-3_*.deb
```

## Configuration

Edit `/etc/sentryd/sentryd.conf` (a conffile - apt won't clobber your
edits), then `systemctl reload sentryd` (SIGHUP, re-reads config and the
ignore list without dropping tracked state).

Put anything that should never be logged or blocked - your LAN, a
monitoring host - in `/etc/sentryd/ignore.hosts`, one CIDR or bare address
per line.

Key settings (all in `sentryd.conf`, see inline comments for the rest):

| Setting          | Default                  | Meaning                                  |
|------------------|---------------------------|-------------------------------------------|
| `LOG_DIR`        | `/home/smullen/logfile`   | condensed-log directory                    |
| `FLUSH_INTERVAL` | `60`                       | seconds between condensed log writes       |
| `SCAN_THRESHOLD` | `3`                        | distinct closed ports -> treated as a scan |
| `BLOCK_ENABLE`   | `1`                        | actually call ufw, vs. log-only            |
| `UNBLOCK_AFTER`  | `0` (never)                | auto-expire a block after N seconds        |

## Managing blocks

```sh
sentryctl status         # running? tail of the log
sentryctl list           # currently blocked IPs
sentryctl block <ip>     # manual block
sentryctl unblock <ip>   # remove the ufw rule + forget it
sentryctl tail -n 100    # tail the condensed log
```

## Requirements and caveats

- `ufw` must actually be enabled (`ufw enable`) for blocks to take effect;
  `sentryd` only inserts rules, it doesn't turn ufw on.
- Runs as root: it needs `CAP_NET_RAW` to see raw frames and needs to
  invoke `ufw` (root-only) itself. This matches how portsentry always
  worked.
- The packet parser assumes Ethernet-framed interfaces (any normal NIC),
  and unwraps up to two nested 802.1Q VLAN tags (plain single-tagged
  frames and QinQ/double-tagged provider frames alike). Loopback is
  intentionally excluded from monitoring - it's not "incoming" traffic and
  would otherwise fill the log with your own local tools.
- Distinguishes closed-port probes from real connections; it doesn't
  attempt deep protocol inspection (fragmented/malformed-packet evasion).
  Slow, spread-out scans ARE caught: `SCAN_THRESHOLD` is evaluated over a
  rolling `SCAN_WINDOW_SECONDS` window (default 1 hour) that's independent
  of the log-flush cadence, so a source probing one port every few minutes
  still accumulates toward the threshold instead of having its count reset
  every `FLUSH_INTERVAL`. Raise `SCAN_WINDOW_SECONDS` further for scans
  spread out over many hours; memory per tracked source is fixed-size (a
  64-event ring buffer) regardless of the window length.
- What's still out of scope: a *distributed* scan (many different source
  IPs each probing just once or twice) isn't correlated across sources -
  each source is tracked independently, by design, so blocking one
  scanner's IP can't be triggered by a different IP's activity.
- IPv6 extension-header chains before TCP aren't walked (rare on
  scan/probe traffic); such packets are skipped rather than misparsed.

## Hardening (1.0-3)

A security/robustness audit pass fixed the following:

- **Out-of-bounds read parsing `ignore.hosts`**: a malformed IPv6 CIDR
  with a prefix greater than `/128` (e.g. a typo'd `::1/999`) caused an
  out-of-bounds memory read while matching addresses against it - proven
  with AddressSanitizer. Prefixes are now range-checked when the file is
  loaded; a line with an out-of-range prefix is rejected with a logged
  warning and the rest of the file still loads.
- **Ignore-list and local-address "blind window" on reload/refresh**:
  both the ignore list and the local-address list used to be cleared
  before the data that replaces them was confirmed available, so a
  transiently missing/unreadable `ignore.hosts` (mid-edit save, a
  dangling symlink) or a transient `getifaddrs()` failure would silently
  drop every trusted host, or make the daemon stop recognizing its own
  addresses, until the next successful refresh. Both are now built fresh
  in memory first and only swapped in once that succeeds - a failure
  leaves the previous, still-valid list untouched.
- **Single-instance lock**: nothing previously stopped two `sentryd`
  processes running against the same `STATE_DIR` at once (e.g. a systemd
  restart briefly overlapping old and new). A second instance now exits
  immediately with "another instance is already running" instead of
  racing writes to `blocked.list` or issuing duplicate ufw rules.
- **Unbounded wait on `ufw`**: blocking/unblocking calls `ufw` from the
  packet-processing hot path; an unbounded wait on it (e.g. `ufw` stuck
  on a lock held by something else) would have wedged the entire daemon.
  It's now killed and treated as a failure if it doesn't exit within 5
  seconds.
- **Misaligned header access**: the IPv4/IPv6/TCP header parser
  reinterpret-cast the raw packet buffer straight into typed header
  pointers at an offset that isn't guaranteed 4-byte aligned (14, 18 or
  22 bytes past a `malloc()`'d buffer, depending on VLAN tagging) -
  undefined behavior, silently tolerated on x86 but confirmed live with
  UBSan against real captured traffic. Headers are now copied into
  properly aligned local structs before their fields are read.
- **Undefined behavior on an empty `LOG_DIR`/`STATE_DIR`**: setting
  either to an empty string in the config caused the directory-creation
  code to read past the start of its scratch buffer. Both are now
  validated as non-root absolute paths at load time, falling back to the
  compiled-in default (with a warning) if not.
- Randomized the internal per-source-IP hash table's seed at startup
  (`getrandom()`), closing off a theoretical algorithmic-complexity
  attack from an adversary choosing colliding source IPs.
- Moved a 64KB scratch array out of the stack and into static storage,
  and cleanly frees all tracked-source/ignore-list/local-address memory
  on shutdown (previously left for the OS to reclaim).
