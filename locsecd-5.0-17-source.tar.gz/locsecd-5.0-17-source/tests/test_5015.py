#!/usr/bin/python3
"""5.0-15: locsecctl apparmor counts ALLOWED lines since the broker last started, not over the whole boot.
Runs a copy of locsec-apparmor against stand-in systemctl and journalctl (and a stand-in profile list), so it
needs no root, no AppArmor and no systemd. Usage: test_5015.py path/to/locsecd.py"""
import sys, os, re, stat, subprocess, tempfile
HERE = os.path.dirname(os.path.abspath(sys.argv[1])); ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)

src = open(os.path.join(ROOT, 'usr/lib/locsecd/locsec-apparmor')).read()
T = tempfile.mkdtemp(prefix='locsec-5015-')
os.makedirs(os.path.join(T, 'bin'))
prof = os.path.join(T, 'profiles')
open(prof, 'w').write('locsecd-web (complain)\nlocsecd-broker (complain)\n')

# The test copy: AppArmor "on", the stand-in profile list, no root check, no parser, no file changes.
t = src
t = re.sub(r'^    \[ -d /sys/kernel/security/apparmor \].*$', '    true', t, flags=re.M)
t = t.replace('/sys/kernel/security/apparmor/profiles', prof)
t = re.sub(r'^\s*\[ "\$\(id -u\)" = 0 \] \|\| die.*$', 'true', t, flags=re.M)
t = re.sub(r'^\s*command -v apparmor_parser .*$', 'true', t, flags=re.M)
t = re.sub(r'^\s*\[ -f "\$PROFILE" \] \|\| die.*$', 'true', t, flags=re.M)
t = re.sub(r'^\s*\[ -e /etc/apparmor.d/disable/locsecd \] && die.*$', 'true', t, flags=re.M)
t = re.sub(r'^        apparmor_parser .*$', '        echo PARSER-RUN', t, flags=re.M)
t = re.sub(r'^        rm -f "\$FC"$', '        echo RM-LINK', t, flags=re.M)
aa = os.path.join(T, 'aa'); open(aa, 'w').write(t)

def tool(name, body):
    p = os.path.join(T, 'bin', name); open(p, 'w').write('#!/bin/sh\n' + body)
    os.chmod(p, os.stat(p).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
tool('systemctl', 'case "$MODE_SC" in unix) echo "@1000";; none) echo "";; esac\n')
# Three ALLOWED lines from before the broker started; $AFTER more after it.
tool('journalctl', r'''line='kernel: audit: apparmor="ALLOWED" operation="open" profile="locsecd-web" name="/x"'
since=0; prev=; for a in "$@"; do [ "$prev" = --since ] && since=1; prev=$a; done
[ "$since" = 1 ] && [ "${JBAD:-0}" = 1 ] && { echo "Failed to parse timestamp" >&2; exit 1; }
[ "$since" = 1 ] || { echo "$line"; echo "$line"; echo "$line"; }
i=0; while [ $i -lt ${AFTER:-0} ]; do echo "$line"; i=$((i+1)); done
''')

def run(args, **env):
    e = dict(os.environ, PATH=os.path.join(T, 'bin') + ':' + os.environ['PATH'], **env)
    r = subprocess.run(['sh', aa] + args, env=e, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr

rc, out = run(['status'], MODE_SC='unix', AFTER='0')
check('status counts since the broker started and leaves out the older lines',
      'Since the broker started' in out and ': 0 ALLOWED' in out and 'the other 3 are from before the broker started' in out)
rc, out = run(['enforce'], MODE_SC='unix', AFTER='0')
check('enforce switches when the only ALLOWED lines are from before the broker started (the 5.0-14 upgrade case)',
      rc == 0 and 'RM-LINK' in out and 'PARSER-RUN' in out)
rc, out = run(['enforce'], MODE_SC='unix', AFTER='2')
check('enforce refuses when the profiles logged ALLOWED lines since the broker started',
      rc == 1 and 'has 2 ALLOWED line(s)' in out and 'PARSER-RUN' not in out)
rc, out = run(['enforce'], MODE_SC='none', AFTER='0')
check('enforce counts the whole boot (and refuses) when the broker start time is unknown',
      rc == 1 and 'has 3 ALLOWED line(s)' in out and 'PARSER-RUN' not in out)
rc, out = run(['enforce'], MODE_SC='unix', JBAD='1', AFTER='0')
check('enforce counts the whole boot (and refuses) when journalctl rejects the start time',
      rc == 1 and 'has 3 ALLOWED line(s)' in out and 'PARSER-RUN' not in out)
rc, out = run(['enforce', '--force'], MODE_SC='unix', AFTER='2')
check('enforce --force still switches', rc == 0 and 'PARSER-RUN' in out)
check('the helper asks systemctl for the start time in a form journalctl reads (--timestamp=unix)',
      '--timestamp=unix' in src and 'journalctl -k -b --since "$SINCE"' in src)
prof_src = open(os.path.join(ROOT, 'etc/apparmor.d/locsecd')).read()
web = prof_src[prof_src.index('profile locsecd-web'):prof_src.index('profile locsecd-broker')]
check('locsecd-web may read /var/log/dpkg.log and its rotated copies (the AIDE explanations)', re.search(r'^\s*/var/log/dpkg\.log\* r,$', web, re.M) is not None)
# 5.0-15: a LocSec scan unit that ends with a non-zero exit code is information on the Logs page, not a Problem.
import importlib.util
os.environ['LOCSEC_INPROCESS_BROKER'] = '1'
spec = importlib.util.spec_from_file_location('locsecd_5015', sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
ts = '2026-10-14T01:22:39'
def row(msg, prog='systemd'): return m._sys_explain(prog, msg, ts, msg, {})
r1 = row("locsecd-scan-p775039-3379b8c7.service: Failed with result 'exit-code'.")
check("a LocSec scan unit's \"Failed with result 'exit-code'\" is information (AIDE found changes)", r1['lvl'] == 'info' and r1['title'] == 'LocSec job finished')
r2 = row('locsecd-scan-p775039-3379b8c7.service: Main process exited, code=exited, status=7/NOTRUNNING')
check('its "Main process exited, status=7" line names the exit code', r2['lvl'] == 'info' and 'exit code 7' in r2['text'])
r3 = row("locsecd-clamav-p775039-384e3707.service: Failed with result 'exit-code'.")
check('the same for a ClamAV batch unit (exit 1 = malware found)', r3['lvl'] == 'info')
r4 = row("locsecd-scan-p775039-3379b8c7.service: Failed with result 'timeout'.")
check('a LocSec scan that timed out is still a Problem', r4['lvl'] == 'bad')
r5 = row("apache2.service: Failed with result 'exit-code'.")
check("another program's failed unit is still a Problem", r5['lvl'] == 'bad')
r6 = row("locsecd-broker.service: Failed with result 'exit-code'.")
check("LocSec's own services failing are still a Problem", r6['lvl'] == 'bad')
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
