"""5.0-17: feed_auto_block_limit is per refresh and counts only NEW blocks, so a feed longer than the limit is
blocked over several refreshes instead of stopping at the first `limit` entries for good. Only firewall failures
count toward stopping a run early; policy refusals do not, and a full block list stops it at once.
Usage: test_5017.py path/to/locsecd.py   (throwaway container; needs the locsec account)"""
import sys, importlib.util, tempfile, pathlib, json, io, os
os.environ["LOCSEC_INPROCESS_BROKER"]="1"
PATH=sys.argv[1]
spec=importlib.util.spec_from_file_location('l',PATH); m=importlib.util.module_from_spec(spec); sys.argv=[PATH]; spec.loader.exec_module(m)
d=pathlib.Path(tempfile.mkdtemp())
m.FEEDS=d/'feeds.json'; m.BLOCKS=d/'blocks.json'
if hasattr(m,'FEED_SOURCES'): m.FEED_SOURCES=d/'feed-sources.json'
m.log=lambda *a,**k: None; m.prune_expired_blocks=lambda: None
N=25; LIMIT=10
m.CFG.update(feed_urls=['https://www.spamhaus.org/drop/drop.txt'],feed_auto_block=True,auto_block=True,response_feed_block=True,feed_auto_block_limit=LIMIT)
BODY=''.join(f'10.{i}.0.0/24 ; SBL{i}\n' for i in range(1,N+1)).encode()
class R(io.BytesIO):
    def __enter__(s): return s
    def __exit__(s,*a): pass
class O:
    def open(s,req,timeout=30): return R(BODY)
m._FEED_OPENER=O()
blocked=set(); mode=['ok']
NO_BACKEND=getattr(m,'_BLOCK_NO_BACKEND','no active enforcement backend')
def fake_block(target,*a,**k):
    if mode[0]=='nobackend': return (False,NO_BACKEND)
    if mode[0]=='policy': return (False,'allowlisted')
    if mode[0]=='full': return (False,'the block list already holds 20000 automatic blocks')
    blocked.add(str(target)); return (True,'ok')
m.block_ip=fake_block
m.load_blocks=lambda: {k:{} for k in blocked}
m._block_target=lambda t: str(t)
m.max_auto_block_prefix=8
ref=[]
def run(): r=m.feed_update(); ref.append(r); return r
r=run(); assert r['blocked']==LIMIT and len(blocked)==LIMIT, ('run1',r,len(blocked))
r=run(); assert r['blocked']==LIMIT and len(blocked)==2*LIMIT, ('run2: later refreshes must keep adding',r,len(blocked))
r=run(); assert r['blocked']==N-2*LIMIT and len(blocked)==N, ('run3',r,len(blocked))
r=run(); assert r['blocked']==0 and r['already_blocked']==N, ('run4',r)
calls=[0]
orig=m.block_ip
def counting(*a,**k): calls[0]+=1; return orig(*a,**k)
m.block_ip=counting
# a refusing firewall stops after `limit` failures instead of trying the whole feed
blocked.clear(); mode[0]='nobackend'; calls[0]=0
r=run(); assert r['blocked']==0 and calls[0]==LIMIT, ('firewall failures bounded',calls[0],r)
# policy refusals (allowlisted, IPv6 off, ...) do not end the run early: every entry is looked at
mode[0]='policy'; calls[0]=0
r=run(); assert calls[0]==N, ('policy refusals must not stop the run',calls[0],r)
# a full block list stops at the first refusal
mode[0]='full'; calls[0]=0
r=run(); assert calls[0]==1, ('a full block list stops the run',calls[0],r)
# normalised range of max_auto_block_prefix (5.0-17: 1..32)
m.CFG['max_auto_block_prefix']=100000; m._normalize_config(); assert m.CFG['max_auto_block_prefix']==32, m.CFG['max_auto_block_prefix']
# unblock_ip keeps the entry when no backend confirms the rule is gone (5.0-17)
import importlib
spec2=importlib.util.spec_from_file_location('l2',PATH); u=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(u)
u.BLOCKS=d/'blocks2.json'; u.log=lambda *a,**k: None; u.incident=lambda *a,**k: None; u.have=lambda t: False
u.BLOCKS.write_text(json.dumps({'203.0.113.7':{'source':'manual','ts':0,'expires':9e12}}))
u.broker=lambda verb,**k: (1,'ERROR: Could not acquire lock')
ok,msg=u.unblock_ip('203.0.113.7')
assert not ok and '203.0.113.7' in json.loads(u.BLOCKS.read_text()), ('failed unblock must keep the entry',ok,msg)
u.broker=lambda verb,**k: (0,'Rule deleted')
ok,msg=u.unblock_ip('203.0.113.7')
assert ok and '203.0.113.7' not in json.loads(u.BLOCKS.read_text()), ('confirmed unblock removes the entry',ok,msg)
print('PASS')
