#!/usr/bin/python3
"""5.0-23: blocked domains (Scanistry's section of /etc/hosts), "Fix it" on a DNS-lookup alert, the AIDE explanation
of Scanistry's own /etc/hosts writes, and the corrected advice for outbound alerts.
Real case (Debian 13, 2026-10-21): "ET HUNTING AdFection Related Domain in DNS Lookup (tracookiepixel .xyz)", sid 2072461,
outbound UDP to the router 192.168.0.1:53, six alerts; the advice said "sudo ss -tnp | grep 192.168.0.1", which matched
the machine's own 192.168.0.102 and can never show a DNS lookup.
Runs both halves in one process with commands stubbed; the hosts helper really runs, as nobody, on a temporary file.
Creates files under /var/lib/scanistry and /var/lib/scanistry-broker: throwaway container or VM only, as root.
Usage: test_5023.py path/to/scanistry.py"""
import sys, os, shutil, subprocess, importlib.util, collections, re, time, json, hashlib, base64, tempfile
os.environ['TZ'] = 'America/Chicago'; time.tzset()
PATH = os.path.abspath(sys.argv[1])
HELPER = os.path.join(os.path.dirname(PATH), 'scanistry-hosts')
SRC = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(PATH))))
REAL_POPEN = subprocess.Popen
TMP = tempfile.mkdtemp(prefix='scanistry-5023-'); os.chmod(TMP, 0o777)
HOSTS = os.path.join(TMP, 'hosts')
# The packaged helper is root-only (0700); nobody runs a readable copy of it.
HELPER_COPY = os.path.join(TMP, 'scanistry-hosts'); shutil.copyfile(HELPER, HELPER_COPY); os.chmod(HELPER_COPY, 0o755)
BASE_HOSTS = '127.0.0.1\tlocalhost\n127.0.1.1\thomebox\n::1 localhost ip6-localhost\n'
def reset_hosts(text=BASE_HOSTS):
    with open(HOSTS, 'w') as fh: fh.write(text)
    os.chmod(HOSTS, 0o666)
reset_hosts()
REC = []
class FakeProc:
    pid = 999998; returncode = None
    def __init__(self, argv, **kw): self.args = argv
    def poll(self): return self.returncode
    def wait(self, timeout=None): return 0
    def terminate(self): self.returncode = -15
    def kill(self): self.returncode = -9
    def communicate(self, *a, **k): return (None, None)
def fake_run(argv, input=None, stdin=None, stdout=None, stderr=None, timeout=None, check=False, text=False, **kw):
    REC.append([str(x) for x in argv]); out = b''
    if argv[:2] == ['systemctl', 'show'] and '--value' in argv: out = (argv[-1] + '\n').encode()
    if hasattr(stdout, 'write'): stdout.write(out); return subprocess.CompletedProcess(argv, 0)
    return subprocess.CompletedProcess(argv, 0, stdout=out.decode() if text else out, stderr='')
subprocess.run = fake_run; subprocess.Popen = lambda argv, *a, **k: (REC.append([str(x) for x in argv]), FakeProc(argv))[1]
subprocess.check_output = lambda *a, **k: ''
shutil.rmtree('/var/lib/scanistry', ignore_errors=True); shutil.rmtree('/var/lib/scanistry-broker', ignore_errors=True)
os.environ['SCANISTRY_INPROCESS_BROKER'] = '1'
spec = importlib.util.spec_from_file_location('scanistry_5023', PATH)
m = importlib.util.module_from_spec(spec); sys.argv = [PATH]; spec.loader.exec_module(m)
m.have = lambda c: True
m.shutil.disk_usage = lambda p: collections.namedtuple('u', 'total used free')(1 << 40, 0, 1 << 40)
LOGS = []; m.log = lambda msg, level='INFO': LOGS.append(str(msg))
m._apt_source_hosts = lambda: {'deb.debian.org', 'security.debian.org', 'mirror.example.edu'}
CONF = {'block_domains': []}
m.load_conf = lambda: dict(m.DEFAULTS, **CONF)
m._dns_read_hosts = lambda: open(HOSTS).read()
UNITS = []
def fake_transient(cmd, timeout=60, prefix='', profile=None, **k):
    # The real helper, as nobody, on the temporary file (an unprivileged caller may name the file).
    UNITS.append((list(cmd), prefix, profile))
    assert m._in_broker(), 'a job unit outside a broker verb'
    with REAL_POPEN(['setpriv', '--reuid=65534', '--regid=65534', '--clear-groups', 'env', f'SCANISTRY_HOSTS_FILE={HOSTS}',
                     'python3', '-I', HELPER_COPY] + list(cmd[1:]), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True) as p:
        out, _ = p.communicate(timeout=60)
    return p.returncode, out
m._run_transient = fake_transient
passed = failed = 0
def check(label, cond):
    global passed, failed
    if cond: passed += 1
    else: failed += 1; print('FAIL:', label)
WEB = m._Req(4242, 990, False); ROOT = m._Req(1, 0, False)
def as_(who, verb, **args):
    REC.clear(); m._BROKER_TLS.req = who; m._BROKER_TLS.approval = None
    try: return m.broker(verb, **args)
    finally: m._BROKER_TLS.req = None
def section():
    return m._hosts_section(open(HOSTS).read())[0]

# --- names
check('a plain name is accepted, lower-cased, trailing dot dropped', m._domain_norm('TrAcookiePixel.XYZ.') == 'tracookiepixel.xyz')
for bad in ('localhost', 'a..b.com', '-a.com', 'a-.com', 'a.b; rm -rf /', 'x' * 64 + '.com', '1.2.3.4', 'a.b.c.123', 'ex ample.com', '', 'a.com/x'):
    check(f'not a domain: {bad[:30]!r}', m._domain_norm(bad) is None)
check('an xn-- top-level name is accepted', m._domain_norm('example.xn--p1ai') == 'example.xn--p1ai')
for d in ('deb.debian.org', 'security.debian.org', 'database.clamav.net', 'rules.emergingthreats.net', 'www.spamhaus.org',
          'feodotracker.abuse.ch', 'mirror.example.edu', 'mozilla.cloudflare-dns.com', 'archive.ubuntu.com'):
    check(f'never blocked: {d}', bool(m._dns_protected(d)))
check('an advert domain is not protected', m._dns_protected('tracookiepixel.xyz') == '')
check('a name that only ends like a protected one is not protected', m._dns_protected('notdebian.org') == '')
ok, bad = m._norm_block_domains(['Ads.Example.com', 'ads.example.com', 'bad name', 5])
check('block_domains: valid names kept once, others reported', ok == ['ads.example.com'] and len(bad) == 2)
check('block_domains defaults to an empty list', m.DEFAULTS.get('block_domains') == [])

# --- the broker verbs
for v in ('dns.list', 'dns.block', 'dns.unblock', 'dns.sync'):
    check(f'{v} is a remote verb', v in m._VERBS and m._VERBS[v]['remote'])
check('dns.block is gated, dns.unblock is not', 'dns.block' in m._GATED and 'dns.unblock' not in m._GATED)
check('the hosts job profile has no network and writes only /etc', 'PrivateNetwork=yes' in m._JOB_PROFILES['hosts']
      and 'ReadWritePaths=/etc' in m._JOB_PROFILES['hosts'] and 'ProtectSystem=strict' in m._JOB_PROFILES['hosts']
      and not any(x.startswith('CapabilityBoundingSet=~') for x in m._JOB_PROFILES['hosts']))

r = as_(WEB, 'dns.block', domain='tracookiepixel.xyz'); aid = m._BROKER_TLS.approval
check('web: blocking a domain is parked for approval, nothing run', isinstance(r, dict) and not r.get('ok') and 'needs administrator approval' in r.get('error', '') and not UNITS)
check('web: the refusal names the domain and the approve command', 'tracookiepixel.xyz' in r.get('error', '') and f'sudo scanistryctl approve {aid}' in r.get('error', ''))
check('/etc/hosts unchanged while waiting', open(HOSTS).read() == BASE_HOSTS)
r = as_(WEB, 'dns.block', domain='deb.debian.org')
check('web: a protected name is refused outright, not parked', isinstance(r, dict) and 'never blocked' in r.get('error', '') and 'approval' not in r.get('error', ''))
r = as_(WEB, 'dns.block', domain='not a name')
check('web: a malformed name is refused', isinstance(r, dict) and 'not a domain name' in r.get('error', ''))
LOGS.clear()
g = as_(ROOT, 'approval.grant', aid=aid)
check('root approves: the domain is blocked', isinstance(g, dict) and g.get('ok') and g['result'].get('ok'))
check('/etc/hosts has the section with both lines', section() == ['tracookiepixel.xyz'] and '0.0.0.0 tracookiepixel.xyz\n:: tracookiepixel.xyz\n' in open(HOSTS).read())
check('/etc/hosts keeps every other line', open(HOSTS).read().startswith(BASE_HOSTS))
check('one job unit, profile hosts', len(UNITS) == 1 and UNITS[0][2] == 'hosts' and UNITS[0][1] == 'scanistry-hosts')
check('the broker logged the write with both digests', any(m._HOSTS_WRITE.search(x) for x in LOGS))
st = json.load(open('/var/lib/scanistry-broker/blocked-domains.json'))
check('the broker keeps the block (root-only state file)', 'tracookiepixel.xyz' in st['domains']
      and (os.stat('/var/lib/scanistry-broker/blocked-domains.json').st_mode & 0o777) == 0o600)
UNITS.clear()
r = as_(WEB, 'dns.block', domain='tracookiepixel.xyz')
check('web: an already blocked domain is not parked again', isinstance(r, dict) and r.get('ok') and 'already' in r.get('message', '') and not UNITS)
r = as_(ROOT, 'dns.block', domain='b.example.org')
check('root: blocking runs at once', r.get('ok') and sorted(section()) == ['b.example.org', 'tracookiepixel.xyz'])
L = as_(WEB, 'dns.list')
check('dns.list: both, from the dashboard, in /etc/hosts, in sync', L.get('ok') and L['in_sync'] and
      [(x['name'], x['source'], x['in_hosts']) for x in L['domains']] == [('b.example.org', 'dashboard', True), ('tracookiepixel.xyz', 'dashboard', True)])
r = as_(WEB, 'dns.unblock', domain='b.example.org')
check('web: unblocking needs no approval', r.get('ok') and section() == ['tracookiepixel.xyz'])
r = as_(WEB, 'dns.unblock', domain='tracookiepixel.xyz')
check('the last unblock takes the whole section out again', r.get('ok') and open(HOSTS).read() == BASE_HOSTS)

# --- the configuration's own list
CONF['block_domains'] = ['conf.example.net', 'security.debian.org']
UNITS.clear(); r = as_(ROOT, 'dns.sync')
check('dns.sync writes block_domains from scanistry.conf; protected names in it are left out', r.get('ok') and section() == ['conf.example.net'])
L = as_(WEB, 'dns.list')
check('dns.list: the protected entry is reported as ignored', any(x['entry'] == 'security.debian.org' for x in L['ignored']))
r = as_(WEB, 'dns.unblock', domain='conf.example.net')
check('a domain from scanistry.conf cannot be unblocked from the dashboard', not r.get('ok') and 'block_domains' in r.get('error', '') and section() == ['conf.example.net'])
UNITS.clear(); r = as_(ROOT, 'dns.sync')
check('dns.sync with nothing to change starts no job unit', r.get('ok') and not UNITS)
r = as_(WEB, 'dns.block', domain='conf.example.net')
check('web: a domain already blocked by scanistry.conf is not parked', r.get('ok') and 'already' in r.get('message', ''))
CONF['block_domains'] = []; as_(ROOT, 'dns.sync')
check('taking it out of scanistry.conf and syncing removes it', open(HOSTS).read() == BASE_HOSTS)

# --- a hand-broken section: nothing is written, nothing is saved
reset_hosts(BASE_HOSTS + '# BEGIN Scanistry blocked domains\n0.0.0.0 x.example.com\n')
r = as_(ROOT, 'dns.block', domain='y.example.com')
check('a section without its END line: refused, file untouched', not r.get('ok') and open(HOSTS).read().endswith('x.example.com\n'))
check('...and the refused block is not saved', 'y.example.com' not in json.load(open('/var/lib/scanistry-broker/blocked-domains.json'))['domains'])
reset_hosts()

# --- incidents
REAL = ('ET HUNTING AdFection Related Domain in DNS Lookup (tracookiepixel .xyz) [sid 2072461, Potentially Bad Traffic] outbound UDP '
        '192.168.0.102:41234 -> 192.168.0.1:53; 6 alert(s) (not blocked: severity 2 is above the blocking level)')
inc = {'kind': 'ids-alert', 'indicator': '192.168.0.1', 'detail': REAL, 'count': 6, 'state': 'new'}
check('the real alert: the domain comes from the signature text', m._incident_domains(inc) == ['tracookiepixel.xyz'])
inc2 = dict(inc, detail=REAL.replace('6 alert(s)', '6 alert(s); domains a.tracker.example, b.tracker.example'))
check('5.0-23 detail: the domains Suricata recorded come first', m._incident_domains(inc2) == ['a.tracker.example', 'b.tracker.example'])
tcp = dict(inc, indicator='203.0.113.5', detail='ET MALWARE Foo (bad .example) [sid 1, c] outbound TCP 192.168.0.102:5000 -> 203.0.113.5:443; 1 alert(s)')
check('a TCP alert that is not a lookup has no domains', m._incident_domains(tcp) == [])
check('not an IDS incident: no domains', m._incident_domains({'kind': 'port-scan', 'detail': REAL}) == [])
check('Suricata 7 alert record: dns.query[].rrname', m._eve_dns_names({'dns': {'query': [{'rrname': 'TraCookiePixel.xyz', 'rrtype': 'A'}]}}) == ['tracookiepixel.xyz'])
check('Suricata 8 alert record: dns.queries[].rrname', m._eve_dns_names({'dns': {'version': 3, 'queries': [{'rrname': 'a.example.com'}, {'rrname': 'bad name'}]}}) == ['a.example.com'])
check('no dns part: no names', m._eve_dns_names({'http': {}}) == [] and m._eve_dns_names({'dns': 'x'}) == [])

m._DNS_MEMO.update(t=0)
check('Fix it is offered for the DNS alert (the router itself is never blocked)', m.incident_can_fix(inc) is True)
lvl, happened, did, todo = m._incident_story(inc)
check('story: names the domain, says the router is not the problem', 'tracookiepixel.xyz' in happened and 'not the problem' in happened and lvl == 'warn')
check('story: offers Fix it for the domain and says it needs approval', 'Press "Fix it" to block tracookiepixel.xyz' in todo and 'sudo scanistryctl approve' in todo)
check('story: no "ss | grep" advice for a lookup', 'grep' not in todo and 'ss -tnp' not in todo and 'tcpdump' in todo)
check('story: "did" no longer talks about the blocking level of the router', 'severity' not in did and 'does not block the DNS server' in did)
real_broker = m.broker
m.broker = lambda verb, **a: ({'ok': False, 'error': 'needs administrator approval: ...', 'approval_id': 'deadbeef'} if verb == 'dns.block' else real_broker(verb, **a))
did2, state2 = m._incident_block_domains(['tracookiepixel.xyz'], 'i1', 'investigating')
check('Fix it from the dashboard: waits for approval and says which command to run', 'sudo scanistryctl approve deadbeef' in did2 and state2 == 'investigating')
m.broker = real_broker
as_(ROOT, 'dns.block', domain='tracookiepixel.xyz'); m._DNS_MEMO.update(t=0)
check('once blocked, Fix it is no longer offered', m.incident_can_fix(inc) is False)
lvl, happened, did, todo = m._incident_story(inc)
check('once blocked, the story says so', 'Scanistry blocked tracookiepixel.xyz' in did and todo.startswith('No action needed'))
did3, state3 = m._incident_block_domains(['tracookiepixel.xyz'], 'i1', 'investigating')
check('Fix it again: already blocked, contained', 'already blocked' in did3 and state3 == 'contained')
lvl, happened, did, todo = m._incident_story(tcp)
check('outbound TCP: exact ss filter, no grep', 'sudo ss -tunp dst 203.0.113.5' in todo and 'grep' not in todo)
lvl, happened, did, todo = m._incident_story(dict(tcp, indicator='2001:db8::1'))
check('outbound IPv6: the address in brackets', 'sudo ss -tunp dst [2001:db8::1]' in todo)
lvl, happened, did, todo = m._incident_story({'kind': 'auth-probe', 'indicator': '', 'detail': ''})
check('dashboard token guessing: a port filter, not grep', "sudo ss -tnp 'dport = :8765'" in todo and 'grep' not in todo)
as_(ROOT, 'dns.unblock', domain='tracookiepixel.xyz')

# --- AIDE: Scanistry's own /etc/hosts writes
B = time.mktime(time.strptime('2026-10-20 12:00:00', '%Y-%m-%d %H:%M:%S')); NOW = B + 86400
h0 = BASE_HOSTS.encode(); h1 = h0 + b'# BEGIN ...one\n'; h2 = h1 + b'# more\n'
s256 = lambda b: hashlib.sha256(b).hexdigest(); s512 = lambda b: hashlib.sha512(b).hexdigest()
def wline(t, before, after, uid='0', unit='scanistry-broker.service'):
    msg = f'INFO domain block list: wrote /etc/hosts with 1 blocked domain(s); sha256 {s256(after)}; before sha256 {s256(before)} sha512 {s512(before)}'
    return {'__REALTIME_TIMESTAMP': str(int(t * 1e6)), 'MESSAGE': msg, '_UID': uid, '_SYSTEMD_UNIT': unit}
def story(journal, detail, current):
    m._aide_hosts_journal = lambda since, until: list(journal)
    return m._aide_hosts_story(B, NOW, detail, current=s256(current))
b64 = lambda b: base64.b64encode(hashlib.sha256(b).digest()).decode()
D = {'sha256': (b64(h0), b64(h2)), 'mtime': ('x', 'y')}
ok_, note = story([wline(B + 100, h0, h1), wline(B + 200, h1, h2)], D, h2)
check('AIDE: an unbroken chain from the snapshot to now is explained', ok_ and 'That explains this' in note and '2 time(s)' in note)
ok_, note = story([wline(B + 100, h0, h1)], {'sha512': (base64.b64encode(hashlib.sha512(h0).digest()).decode(), 'z')}, h1)
check('AIDE: a SHA-512 old checksum works too', ok_)
ok_, note = story([wline(B + 100, h0, h1)], {'sha256': (s256(h0), 'z')}, h1)
check('AIDE: an old checksum in hex works too', ok_)
ok_, note = story([wline(B + 100, h0, h1)], D, h2)
check('AIDE: changed again after Scanistry wrote it: not explained, and says so', not ok_ and 'not Scanistry' in note)
ok_, note = story([wline(B + 100, h0, h1), wline(B + 200, h2, h2 + b'x')], D, h2 + b'x')
check('AIDE: a gap between two writes is not explained', not ok_ and 'something else changed the file' in note)
ok_, note = story([wline(B + 100, h0 + b'evil\n', h1)], D, h1)
check('AIDE: a file already changed before the first write is not explained', not ok_ and 'already different' in note)
ok_, note = story([wline(B + 100, h0, h1)], {'mtime': ('x', 'y')}, h1)
check('AIDE: no readable old checksum: not explained, and says why', not ok_ and 'cannot confirm' in note)
ok_, note = story([wline(B + 100, h0, h1, uid='990')], D, h1)
check('AIDE: a line not written as root is ignored', not ok_ and note == '')
ok_, note = story([wline(B + 100, h0, h1, unit='evil.service')], D, h1)
check('AIDE: a line from another unit is ignored', not ok_ and note == '')
ok_, note = story([], D, h1)
check('AIDE: no Scanistry write since the snapshot: no note', not ok_ and note == '')
src = open(PATH).read()
check('AIDE: the journal query filters on the trusted fields', "'_SYSTEMD_UNIT=scanistry-broker.service','_UID=0'" in src)

# --- dashboard, CLI and packaging
check('dashboard: the new buttons are allowed actions', re.search(r'const ACTIONS=Object\.freeze\(\{[^}]*\bblockDomain\b[^}]*\bunblockDomainIdx\b', src) is not None)
check('dashboard: no inline handler in the new card', 'onclick' not in src[src.index('function domainsCard'):src.index('function blocksCard')])
check('dashboard: the API routes exist', "path=='/api/domains'" in src and "('/api/domain/block','/api/domain/unblock')" in src)
ctl = open(os.path.join(SRC, 'usr/bin/scanistryctl')).read()
check('scanistryctl: domains, block-domain, unblock-domain', all(x in ctl for x in ('domains) exec', 'block-domain)', 'unblock-domain)')))
check('the domain flags keep root (they only talk to the broker)', {'--domains', '--block-domain', '--unblock-domain'} <= m._DOMAIN_FLAGS)
prerm = open(os.path.join(SRC, 'DEBIAN/prerm')).read()
check('prerm (remove): takes the section out of /etc/hosts', '/usr/lib/scanistry/scanistry-hosts set' in prerm)
check('the helper is root-only', (os.stat(HELPER).st_mode & 0o777) == 0o700)
web = open(os.path.join(SRC, 'etc/apparmor.d/scanistry')).read()
check('the web profile gets no write rule for /etc/hosts', '/etc/hosts w' not in web and '/etc/hosts rw' not in web)

shutil.rmtree(TMP, ignore_errors=True)
print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)
