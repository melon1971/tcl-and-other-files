#!/usr/bin/python3
"""5.0-22 checks, no root needed: the AIDE report explains /etc/systemd/system/timers.target.wants when Scanistry's own
installer switched off the aide package's daily check (dailyaidecheck.timer). Real case (Debian 13, 2026-10-18):
scanistry 5.0-20 -> 5.0-21 at 15:42:00, the journal says "Stopped dailyaidecheck.timer - Daily AIDE check." at 15:42:00,
and the next AIDE check listed timers.target.wants (only its last-changed time) as not explained.
The journal records and the AIDE rows are stand-ins. Usage: test_5022.py path/to/scanistry.py"""
import sys, os, re, time, types
os.environ['TZ'] = 'America/Chicago'; time.tzset()
os.environ['SCANISTRY_INPROCESS_BROKER'] = '1'
PATH = sys.argv[1]
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
src = open(PATH).read()
m = types.ModuleType('scanistry_5022'); m.__file__ = PATH; sys.argv = [PATH]
exec(compile(src.replace('CFG=load_conf()', 'CFG=dict(DEFAULTS)', 1), PATH, 'exec'), m.__dict__)
m.log = lambda *a, **k: None
ORIG_JOURNAL = m._aide_timer_journal
T = lambda s: time.mktime(time.strptime(s, '%Y-%m-%d %H:%M:%S'))
BASE = T('2026-10-18 12:39:00'); CHECK = T('2026-10-18 15:52:00'); PKG = T('2026-10-18 15:42:00')
W = '/etc/systemd/system/timers.target.wants'
MT = {'mtime': ('2026-07-15 06:24:18 -0500', '2026-10-18 15:42:00 -0500')}
def pid1(ts, msg, pid='1'):
    return {'__REALTIME_TIMESTAMP': str(int(T(ts) * 1e6)), '_PID': pid, 'MESSAGE': msg}
STOP = pid1('2026-10-18 15:42:00', 'Stopped dailyaidecheck.timer - Daily AIDE check.')
def analyze(journal, rows=(('changed', W),), details=None, scanistry=PKG, owners=None):
    details = {W: MT} if details is None else details
    m._aide_db_state = lambda: {'database': {'exists': True, 'mtime': BASE}}
    m._aide_parse = lambda path: {'entries': list(rows), 'details': details, 'ts': CHECK, 'verdict': 'changed', 'counts': {}}
    m._dpkg_owners = lambda paths: dict(owners or {})
    m._pkg_activity = lambda: {'scanistry': scanistry, 'liveworld-rpg': T('2026-10-18 02:06:53')}
    m._aide_unit_story = lambda base, until: []
    asked = []
    def fake(since, until): asked.append((since, until)); return list(journal)
    m._aide_timer_journal = fake
    a = m._aide_analyze('/x')
    return {r['path']: r for r in a['records']}, a, asked

r, a, asked = analyze([STOP])
check('the real case: timers.target.wants is explained', r[W]['explained'] and r[W]['lvl'] == 'info' and a['n_warn'] == 0)
check('the note names the timer, the stop time and the install time', all(x in r[W]['why'] for x in ('dailyaidecheck.timer', '15:42', 'installed or updated')))
check('the note says how to turn the daily check back on', 'sudo systemctl enable --now dailyaidecheck.timer' in r[W]['why'])
check('the journal is read in a window around the install time', asked and asked[0][0] <= PKG - 120 and asked[0][1] >= PKG + 900)

r, a, _ = analyze([])
check('no journal line: it stays a warning', not r[W]['explained'] and r[W]['lvl'] == 'warn' and a['n_warn'] == 1)
r, a, _ = analyze([pid1('2026-10-18 15:42:00', 'Stopped apt-daily.timer - Daily apt download activities.')])
check('another timer stopping explains nothing', not r[W]['explained'])
r, a, _ = analyze([pid1('2026-10-18 15:42:00', 'dailyaidecheck.timer: Deactivated successfully.')])
check('only the "Stopped dailyaidecheck.timer" line counts', not r[W]['explained'])
r, a, _ = analyze([pid1('2026-10-18 17:30:00', 'Stopped dailyaidecheck.timer - Daily AIDE check.')])
check('a stop long after the install is not tied to it', not r[W]['explained'])
r, a, _ = analyze([pid1('2026-10-18 15:00:00', 'Stopped dailyaidecheck.timer - Daily AIDE check.')])
check('a stop long before the install is not tied to it', not r[W]['explained'])
r, a, _ = analyze([STOP], scanistry=T('2026-10-18 03:11:00'))
check('Scanistry not installed or updated since the snapshot: it stays a warning', not r[W]['explained'])
r, a, _ = analyze([STOP], scanistry=0)
check('no Scanistry in the package history: it stays a warning', not r[W]['explained'])
r, a, _ = analyze([pid1('2026-10-18 15:42:00', 'Stopped dailyaidecheck.timer - Daily AIDE check.', pid='4242')])
check('a line from a process other than systemd (PID 1) is not trusted', not r[W]['explained'])

other = '/etc/systemd/system/multi-user.target.wants'
r, a, _ = analyze([STOP], rows=(('changed', other),), details={other: MT})
check('another .wants folder is not explained by it', not r[other]['explained'])
r, a, _ = analyze([STOP], rows=(('added', W + '/mystery.timer'),), details={})
check('an unknown link added in the folder is not explained by it', not r[W + '/mystery.timer']['explained'])
r, a, _ = analyze([STOP], details={W: {'uid': ('0', '1000')}})
check('a folder whose owner changed is still a problem', r[W]['lvl'] == 'bad' and not r[W]['explained'])
r, a, _ = analyze([STOP], details={W: {'mtime': MT['mtime'], 'perm': ('drwxr-xr-x', 'drwxrwxrwx')}})
check('a folder whose permissions changed is not explained by it', not r[W]['explained'])
r, a, _ = analyze([STOP], rows=(('changed', W), ('added', '/etc/systemd/system/evil.service')), details={W: MT})
check('an unrelated unknown file beside it stays a warning', r[W]['explained'] and not r['/etc/systemd/system/evil.service']['explained'] and a['n_warn'] == 1)

# The journal reader itself: only PID 1 records, asks for dailyaidecheck, falls back when --grep is unsupported.
calls = []
import json as _json
LINES = '\n'.join(_json.dumps(x) for x in (STOP, pid1('2026-10-18 15:42:01', 'something else'), {'MESSAGE': 5}))
def fake_run(cmd, timeout=60, **k):
    calls.append(list(cmd))
    return (1, '') if '--grep' in cmd else (0, LINES)
m.run = fake_run; m.have = lambda c: True
ev = ORIG_JOURNAL(PKG - 120, PKG + 900)
check('the reader asks journalctl for systemd (PID 1) records only', calls and '_PID=1' in calls[0] and '--grep' in calls[0] and 'dailyaidecheck' in calls[0])
check('without --grep support it reads the same records unfiltered', len(calls) == 2 and '--grep' not in calls[1] and len(ev) == 2)
import inspect
check('the reader opens no file (journalctl only)', 'open(' not in inspect.getsource(ORIG_JOURNAL))

prof = open(os.path.join(os.path.dirname(os.path.abspath(PATH)), '..', '..', '..', 'etc/apparmor.d/scanistry')).read()
web = prof[prof.index('profile scanistry-web '):prof.index('profile scanistry-broker ')]
check('scanistry-web gets no rule for /etc/systemd/system', not re.search(r'^\s*/etc/systemd/system\S* r', web, re.M))
check('... nor for /var/lib/scanistry-broker', not re.search(r'^\s*/var/lib/scanistry-broker', web, re.M))
print(f'{len(F)} failed' if F else 'all passed')
sys.exit(1 if F else 0)
