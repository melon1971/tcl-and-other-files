#!/usr/bin/python3
"""5.0-21 checks, no root needed: the scanistry-web profile may read the clamd local override (the file
_aide_scanistry_file() reads for the "Added by scanistry" mark), and nothing more under /etc/apparmor.d.
Usage: test_5021.py path/to/etc/apparmor.d/scanistry path/to/scanistry.py"""
import re, sys
PROF, PY = sys.argv[1], sys.argv[2]
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
s = open(PROF).read()
i = s.index('profile scanistry-web'); j = s.index('profile scanistry-broker')
web, brk = s[i:j], s[j:]
RULE = re.compile(r'^\s*/etc/apparmor\.d/local/usr\.sbin\.clamd r,\s*$', re.M)
check('scanistry-web may read the clamd local override', bool(RULE.search(web)))
check('the rule is read only', not re.search(r'^\s*/etc/apparmor\.d/local/usr\.sbin\.clamd\s+[a-qs-z]*w', web, re.M))
check('the broker profile does not get it', not RULE.search(brk))
others = [l.strip() for l in web.splitlines() if re.match(r'^\s*/etc/apparmor\.d', l)]
check('no other file under /etc/apparmor.d in the web profile', others == ['/etc/apparmor.d/local/usr.sbin.clamd r,'])
py = open(PY).read()
check('the code reads exactly that path', "_AA_CLAMD_LOCAL='/etc/apparmor.d/local/usr.sbin.clamd'" in py)
print('%d failed' % len(F)); sys.exit(1 if F else 0)
