#!/usr/bin/python3
"""5.0-25 checks, no root needed: URLhaus without the retired keyless addresses. Real case (2026-10-24): every refresh
logged "https://urlhaus.abuse.ch/downloads/text/ could not be reached: HTTP Error 410: Gone" with the advice to check
network connectivity; abuse.ch had switched the keyless lists off on 2026-10-23. Downloads are stand-ins.
Usage: test_5025.py path/to/scanistry.py"""
import sys, os, io, json, tempfile, types
from pathlib import Path
import urllib.error
os.environ['SCANISTRY_INPROCESS_BROKER'] = '1'
PATH = sys.argv[1]
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
src = open(PATH).read()
m = types.ModuleType('scanistry_5025'); m.__file__ = PATH; sys.argv = [PATH]
exec(compile(src.replace('CFG=load_conf()', 'CFG=dict(DEFAULTS)', 1), PATH, 'exec'), m.__dict__)
LOG = []
m.log = lambda msg, level='INFO': LOG.append((level, str(msg)))
m.prune_expired_blocks = lambda: None
d = Path(tempfile.mkdtemp())
m.FEEDS = d / 'feeds.json'; m.BLOCKS = d / 'blocks.json'; m.FEED_SOURCES = d / 'feed-sources.json'
KEY = 'a1B2c3D4e5F6a7B8c9D0e1F2a3B4c5D6e7F8a9B0c1D2e3F4'
SPAM = 'https://www.spamhaus.org/drop/drop.txt'
FEODO = 'https://feodotracker.abuse.ch/downloads/ipblocklist_recommended.txt'
OLD = 'https://urlhaus.abuse.ch/downloads/text/'

def configure(**kw):
    base = {k: v for k, v in m.DEFAULTS.items()}
    base.update(kw); m.CFG.clear(); m.CFG.update(base); LOG.clear(); m._normalize_config()

# --- configuration -------------------------------------------------------------------------------------------------
configure(feed_urls=[SPAM, FEODO, OLD])
check('retired URLhaus address is dropped from feed_urls', m.CFG['feed_urls'] == [SPAM, FEODO])
check('no key: only the two working sources are fetched', [u for u, _ in m._feed_fetch_list()] == [SPAM, FEODO])
check('no key: the log says how to bring URLhaus back', any('auth.abuse.ch' in x and 'urlhaus_auth_key' in x for _, x in LOG))
configure(feed_urls=[SPAM, 'https://urlhaus.abuse.ch/downloads/text_online/'])
check('text_online is dropped too', m.CFG['feed_urls'] == [SPAM])
configure(feed_urls=[OLD])
check('only the retired address: defaults come back', m.CFG['feed_urls'] == m.DEFAULTS['feed_urls'])
configure(feed_urls=[SPAM, FEODO, OLD], urlhaus_auth_key='  ' + KEY + ' ')
fl = m._feed_fetch_list()
check('key set: URLhaus export is a third source', len(fl) == 3 and fl[2][0] == m.URLHAUS_EXPORT_LABEL)
check('key set: fetched address carries the key', fl[2][1] == f'https://urlhaus-api.abuse.ch/v2/files/exports/{KEY}/recent.csv')
check('key set: label has no key', KEY not in fl[2][0])
configure(feed_urls=[SPAM, f'https://urlhaus-api.abuse.ch/v2/files/exports/{KEY}/recent.csv'])
check('keyed address pasted into feed_urls becomes urlhaus_auth_key', m.CFG['urlhaus_auth_key'] == KEY and m.CFG['feed_urls'] == [SPAM])
check('...and the key is not in that log line', not any(KEY in x for _, x in LOG))
configure(urlhaus_auth_key='short')
check('malformed key is refused', m.CFG['urlhaus_auth_key'] == '' and len(m._feed_fetch_list()) == 2)
configure(urlhaus_auth_key=KEY + '/../x')
check('key with a path character is refused', m.CFG['urlhaus_auth_key'] == '')
check('feed kind of the export is urlhaus', m._feed_kind(m.URLHAUS_EXPORT_LABEL) == 'urlhaus')

# --- downloads -----------------------------------------------------------------------------------------------------
CSV = ('################################################################\n'
       '# abuse.ch URLhaus Database Dump (CSV - recent URLs)           #\n'
       '# id,dateadded,url,url_status,last_online,threat,tags,urlhaus_link,reporter\n'
       '"3700001","2026-10-24 10:00:05","http://9.9.9.9:44123/i","online","2026-10-24 10:00:05","malware_download","32-bit,elf,mips,Mozi","https://urlhaus.abuse.ch/url/3700001/","geenensp"\n'
       '"3700002","2026-10-24 10:01:00","https://evil.example.com/a.exe","online","2026-10-24 10:01:00","malware_download","exe","https://urlhaus.abuse.ch/url/3700002/","anonymous"\n'
       '"3700003","2026-10-20 08:00:00","http://gone.example.net/b.sh","offline","","malware_download","sh","https://urlhaus.abuse.ch/url/3700003/","anonymous"\n'
       '"3700004","2026-10-24 11:00:00","http://bad.example.org","online","2026-10-24 11:00:00","malware_download","","https://urlhaus.abuse.ch/url/3700004/","x"\n').encode()
BODY = {SPAM: b'1.2.3.0/24 ; SBL1\n', FEODO: b'# Feodo\n5.6.7.8\n'}
STATE = {'urlhaus': 'ok'}
SEEN = []
class R(io.BytesIO):
    def __enter__(s): return s
    def __exit__(s, *a): pass
class O:
    def open(s, req, timeout=30):
        SEEN.append(req.full_url)
        if 'urlhaus' in req.full_url:
            if 'urlhaus.abuse.ch/downloads' in req.full_url or STATE['urlhaus'] == '410':
                raise urllib.error.HTTPError(req.full_url, 410, 'Gone', {}, None)
            if STATE['urlhaus'] == '401': raise urllib.error.HTTPError(req.full_url, 401, 'Unauthorized', {}, None)
            if STATE['urlhaus'] == 'leak': raise OSError(f'cannot open {req.full_url}')
            return R(CSV)
        return R(BODY[req.full_url])
m._FEED_OPENER = O()

configure(feed_urls=[SPAM, FEODO], urlhaus_auth_key=KEY, feed_auto_block=False)
r = m.feed_update(); f = json.loads(m.FEEDS.read_text())
check('three of three sources reached', r.get('sources_ok', r.get('hits')) in (3, None) and not f['errors'])
check('online URLhaus hosts listed', {'evil.example.com', 'bad.example.org'} <= set(f['domains']) and '9.9.9.9/32' in f['ips'])
check('offline URLhaus rows left out', 'gone.example.net' not in f['domains'])
check('urlhaus.abuse.ch reference links are not taken for malware hosts', 'urlhaus.abuse.ch' not in f['domains'])
check('feeds.json does not contain the key', KEY not in m.FEEDS.read_text() and KEY not in m.FEED_SOURCES.read_text())

STATE['urlhaus'] = '401'; LOG.clear()
r = m.feed_update(); f = json.loads(m.FEEDS.read_text())
check('refused key: last good URLhaus copy is kept', 'evil.example.com' in f['domains'])
check('refused key: key not in log or errors', not any(KEY in x for _, x in LOG) and KEY not in m.FEEDS.read_text())
STATE['urlhaus'] = 'leak'; LOG.clear(); m.feed_update()
check('an error message that quotes the address is redacted', not any(KEY in x for _, x in LOG) and KEY not in m.FEEDS.read_text())

# --- the Logs page -------------------------------------------------------------------------------------------------
row = m._scanistry_explain(f'2026-10-24T16:22:38.120000+00:00 ERROR feed update failed {OLD}: HTTP Error 410: Gone', {})
check('the real 410 line: "Threat list retired" with the Auth-Key steps',
      row and row['title'] == 'Threat list retired' and 'urlhaus_auth_key' in row.get('fix', '') and 'auth.abuse.ch' in row.get('fix', ''))
check('the real 410 line no longer says to check network connectivity', row and 'connectivity' not in row.get('fix', ''))
row = m._scanistry_explain(f'2026-10-24T16:22:38.120000+00:00 ERROR feed update failed {SPAM}: The read operation timed out', {})
check('a timeout keeps the old title', row and row['title'] == 'Threat list download failed')
a = m._feed_http_advice('https://example.org/list.txt', 'HTTP Error 404: Not Found')
check('404 from another list: retired, change feed_urls', a and 'feed_urls' in a[1])
a = m._feed_http_advice(m.URLHAUS_EXPORT_LABEL, 'HTTP Error 401: Unauthorized')
check('401 from the export: check the key', a and 'urlhaus_auth_key' in a[1])

print('\n' + ('ALL PASS' if not F else f'{len(F)} FAILED: ' + ', '.join(F)))
sys.exit(1 if F else 0)
