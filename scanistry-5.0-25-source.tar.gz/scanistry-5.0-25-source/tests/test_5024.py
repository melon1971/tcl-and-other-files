#!/usr/bin/python3
"""5.0-24 checks, no root needed: the debsecan report moves an entry out of FIX AVAILABLE when the installed package's
Debian changelog already names the CVE. Real case (Debian 13, 2026-10-22): clamav 1.4.6+dfsg-1~deb13u1 installed by hand
from trixie-proposed-updates; debsecan --only-fixed listed 13 ClamAV CVEs for each of 6 binary packages (78 lines) and
"Update system" had nothing to install. debsecan, dpkg-query and /usr/share/doc are stand-ins.
Usage: test_5024.py path/to/scanistry.py"""
import sys, os, gzip, tempfile, types
from pathlib import Path
os.environ['SCANISTRY_INPROCESS_BROKER'] = '1'
PATH = sys.argv[1]
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
src = open(PATH).read()
m = types.ModuleType('scanistry_5024'); m.__file__ = PATH; sys.argv = [PATH]
exec(compile(src.replace('CFG=load_conf()', 'CFG=dict(DEFAULTS)', 1), PATH, 'exec'), m.__dict__)
m.log = lambda *a, **k: None
m.DEBIAN_SUITE = 'trixie'

CVES = ['CVE-2026-20031', 'CVE-2026-20213', 'CVE-2026-20214', 'CVE-2026-20215', 'CVE-2026-20216', 'CVE-2026-20217',
        'CVE-2026-20243', 'CVE-2026-20244', 'CVE-2026-20339', 'CVE-2026-20345', 'CVE-2026-20346', 'CVE-2026-20347',
        'CVE-2026-20348']
BINS = ['clamav', 'clamav-base', 'clamav-daemon', 'clamav-freshclam', 'clamdscan', 'libclamav12']
VER = '1.4.6+dfsg-1~deb13u1'
UNFIXED = [('CVE-2025-1111', 'linux-libc-dev'), ('CVE-2025-1112', 'linux-libc-dev'), ('TEMP-0000000-ABCDEF', 'vim-tiny')]

def debsecan_out(rows): return '\n'.join(f'{c} {p} (fixed)' if fx else f'{c} {p}' for c, p, fx in rows) + '\n'

def setup(changelog=None, fixed=None, unfixed=UNFIXED, dpkg=None, extra_docs=None):
    """changelog: text for /usr/share/doc/clamav/changelog.Debian.gz, or None for no changelog at all."""
    fixed = [(c, p) for p in BINS for c in CVES] if fixed is None else fixed
    d = Path(tempfile.mkdtemp(prefix='scanistry-5024-'))
    (d / 'clamav').mkdir()
    for b in BINS[1:]: (d / b).mkdir()      # the binary packages' folders exist but hold no changelog of their own
    if changelog is not None:
        with gzip.open(d / 'clamav' / 'changelog.Debian.gz', 'wt') as fh: fh.write(changelog)
    for rel, text in (extra_docs or {}).items():
        p = d / rel; p.parent.mkdir(parents=True, exist_ok=True)
        if rel.endswith('.gz'):
            with gzip.open(p, 'wt') as fh: fh.write(text)
        else: p.write_text(text)
    m._DOC_DIR = d
    every = [(c, p, True) for c, p in fixed] + [(c, p, False) for c, p in unfixed]
    def fake_scan(name, cmd, timeout=1800, **k):
        rows = [r for r in every if r[2]] if '--only-fixed' in cmd else every
        return {'name': name, 'status': 'ok', 'rc': 0, 'output': debsecan_out(rows)}
    m.scan_tool = fake_scan
    asked = []
    table = dpkg if dpkg is not None else {b: ('clamav', VER, 'ii ') for b in BINS}
    def fake_run(cmd, timeout=60, **k):
        asked.append(list(cmd))
        if cmd[0] != 'dpkg-query': return 1, 'unexpected command'
        names = cmd[cmd.index('--') + 1:]
        lines = []
        for n in names:
            if n in table: s, v, st = table[n]; lines.append(f'{n}\t{s}\t{v}\t{st}')
            else: lines.append(f'dpkg-query: no packages found matching {n}')
        return (0 if all(n in table for n in names) else 1), '\n'.join(lines) + '\n'
    m.run = fake_run
    return asked

FULL = 'clamav (1.4.6+dfsg-1~deb13u1) trixie; urgency=medium\n\n  * New upstream version 1.4.6\n' + \
       ''.join(f'    - {c} (fixed a parser bug)\n' for c in CVES) + '\n -- Maintainer <m@example.org>  Fri, 17 Oct 2026 10:00:00 +0200\n'

# The real case.
asked = setup(FULL)
r = m._debsecan_result('Debsecan')
out = r['output']
check('the real case: all 78 lines move out of FIX AVAILABLE', r['fixable'] == 0 and r['fixed_installed'] == 78)
check('nothing is waiting, so the status is Informational, not Warnings', r['status'] == 'info')
check('no FIX AVAILABLE section is printed', 'FIX AVAILABLE' not in out)
check('the ALREADY FIXED section names the source package and installed version once', out.count(f'clamav {VER}: 13 CVEs in 6 packages') == 1)
check('every one of the 13 CVEs is listed', all(c in out for c in CVES))
check('the first line gives 0 to install and 78 already fixed', out.splitlines()[0].endswith('0 have a fix available now, and 78 are already fixed in the installed version.'))
check('the unfixed packages are still counted by package', 'linux-libc-dev' in out and 'vim-tiny' in out)
check('dpkg-query was asked once, for the six packages only, after --', len(asked) == 1 and asked[0][-7:] == ['--'] + BINS)

items = m.explain_result(r)
titles = [i['title'] for i in items]
check('the summary does not say security fixes are pending', 'Security fixes pending' not in titles)
check('the summary says they are already fixed', any(i['title'].startswith('Already fixed') and '78' in i['text'] for i in items))
unf = [i for i in items if i['title'] == 'Unfixed vulnerabilities']
check('the unfixed count leaves out the already-fixed ones (3, not 81)', unf and unf[0]['text'].startswith('3 '))

# Only some of the CVEs are in the changelog.
setup(FULL.replace(CVES[-1], 'a later bug'))
r = m._debsecan_result('Debsecan')
check('a CVE the changelog does not name stays under FIX AVAILABLE, for each package', r['fixable'] == 6 and r['fixed_installed'] == 72)
check('and the status is Warnings again', r['status'] == 'warning' and 'FIX AVAILABLE' in r['output'])
check('the pending lines name that CVE', r['output'].count(f'  {CVES[-1]}  ') == 6)

# No changelog at all (dpkg path-exclude for /usr/share/doc, or a minimal image).
setup(None)
r = m._debsecan_result('Debsecan')
check('no changelog: everything stays under FIX AVAILABLE, as before', r['fixable'] == 78 and r['fixed_installed'] == 0 and r['status'] == 'warning')
check('no changelog: no ALREADY FIXED section', 'ALREADY FIXED' not in r['output'])

# A longer CVE number that only starts with the listed one does not count.
setup(FULL.replace('CVE-2026-20031 ', 'CVE-2026-200310 '))
r = m._debsecan_result('Debsecan')
check('CVE-2026-200310 in the changelog does not fix CVE-2026-20031', r['fixable'] == 6 and r['output'].count('  CVE-2026-20031  ') == 6)

# A package that is not installed (rc) or another version's state is not trusted.
tab = {b: ('clamav', VER, 'ii ') for b in BINS}; tab['clamdscan'] = ('clamav', VER, 'rc ')
setup(FULL, dpkg=tab)
r = m._debsecan_result('Debsecan')
check('a package dpkg does not list as installed (rc) keeps its lines', r['fixable'] == 13 and r['fixed_installed'] == 65)

# The binary package's own changelog, an uncompressed one and a binNMU one are read too.
fixed = [(CVES[0], 'libfoo1'), (CVES[1], 'bar'), (CVES[2], 'baz')]
setup(None, fixed=fixed, dpkg={'libfoo1': ('foo', '2.0-1+deb13u1', 'ii '), 'bar': ('bar', '1-1', 'ii '), 'baz': ('baz', '3-1+b1', 'ii ')},
      extra_docs={'foo/changelog.Debian.gz': f'foo: {CVES[0]}\n', 'bar/changelog.Debian': f'bar: {CVES[1]}\n',
                  'baz/changelog.Debian.amd64.gz': f'baz binNMU\n', 'baz/changelog.Debian.gz': f'baz: {CVES[2]}\n'})
r = m._debsecan_result('Debsecan')
check('the source package changelog, an uncompressed one and one beside a binNMU log are all read', r['fixable'] == 0 and r['fixed_installed'] == 3)

# TEMP- entries never match a changelog, and odd package names never reach dpkg-query.
asked = setup(FULL, fixed=[('TEMP-0000001-AAAAAA', 'clamav'), (CVES[0], '--admindir=/tmp/x'), (CVES[0], 'clamav')])
r = m._debsecan_result('Debsecan')
check('a TEMP- entry stays under FIX AVAILABLE', '  TEMP-0000001-AAAAAA  clamav' in r['output'] and r['fixed_installed'] == 1)
check('a package name that is not a Debian name is never passed to dpkg-query', asked and all('--admindir' not in a for a in asked[0]))

# A corrupt changelog is skipped, not fatal.
setup(None, extra_docs={'clamav/changelog.Debian.gz.bad': 'x'})
(m._DOC_DIR / 'clamav' / 'changelog.Debian.gz').write_bytes(b'\x1f\x8b\x08\x00broken')
r = m._debsecan_result('Debsecan')
check('a corrupt changelog is skipped and the lines stay pending', r['fixable'] == 78)

# Nothing fixed at all: the helper is not called.
asked = setup(FULL, fixed=[])
r = m._debsecan_result('Debsecan')
check('no fixable entries: dpkg-query is not run and the status is Informational', asked == [] and r['status'] == 'info' and r['fixed_installed'] == 0)

print(f'\n{len(F)} failed' if F else '\nall passed')
sys.exit(1 if F else 0)
