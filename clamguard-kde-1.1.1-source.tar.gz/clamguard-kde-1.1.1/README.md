# ClamGuard (KDE edition)

A PyQt5 GUI front-end for [ClamAV](https://www.clamav.net/) and
`freshclam`, built to feel native under KDE Plasma — it uses plain Qt
widgets, so it automatically follows your Plasma color scheme, icon
theme and widget style, uses native Qt file dialogs, and takes
authentication prompts through whatever polkit agent Plasma is running
(`polkit-kde-agent-1`).

This is the same application as the GTK "clamguard" package, ported to
Qt. Both editions can be installed side by side: **they share the same
configuration file, quarantine folder and scan history**
(`~/.config/clamguard/clamguard.conf`, `~/.local/share/clamguard/`), so
switching desktop environments — or just preferring one toolkit over
the other — never loses data.

As with the GTK edition, ClamGuard never wraps or hides the underlying
ClamAV tools: `clamscan`, `clamdscan` and `freshclam` all keep working
exactly as before from a terminal.

The shared config, data and quarantine directories (which can contain
scan history and actual quarantined malware samples) are created with
owner-only permissions (`0700`/`0600`), so other local accounts on a
shared machine can't read them.

## Features

- **Scan tab** — Quick scan of your home folder, full-system scan
  (via `pkexec`), or a custom file/folder picker, with live scrolling
  output, a busy progress indicator, and a stop button.
- **Update tab** — Engine version, virus database age, and
  `clamav-freshclam` service status, plus a button to run `freshclam`
  on demand, and an **Automatic Updates** control to enable/disable the
  background update service and set how often it checks (once a day
  up to every hour).
- **Quarantine tab** — Move infected files to
  `~/.local/share/clamguard/quarantine`, and later restore or
  permanently delete them.
- **History tab** — Log of past scans.
- **Preferences** — Archive scanning, PUA detection, symlink
  following, `clamd` usage, notifications, max file size, excluded
  directories.

## Repository layout

```
clamguard-kde-1.1.0/
├── src/clamguard-kde        # the application itself (single Python3/PyQt5 file)
├── clamguard-kde.desktop     # menu entry (Categories=Qt;KDE;System;Security;Utility)
├── pixmaps/clamguard-kde.svg # app icon
├── debian/                   # standard Debian packaging
├── LICENSE
└── README.md
```

## Building the .deb yourself

### Option A — proper Debian build (recommended for Debian trixie)

```sh
sudo apt update
sudo apt install debhelper dh-python python3-pyqt5 \
                  clamav clamav-freshclam policykit-1 devscripts build-essential
cd clamguard-kde-1.1.0
dpkg-buildpackage -us -uc -b
sudo apt install ../clamguard-kde_1.1.0-1_all.deb
```

### Option B — quick manual build (no debhelper required)

A pre-built package is also included/attached alongside this source
(`clamguard-kde_1.1.0-1_all.deb`), built by directly assembling the
package tree and running `dpkg-deb --build`. Prefer Option A if you
plan to redistribute the package widely.

## Installing

```sh
sudo apt install ./clamguard-kde_1.1.0-1_all.deb
```

apt will pull in `python3-pyqt5`, `clamav`, `clamav-freshclam`, and
`policykit-1` automatically. After installing, launch **ClamGuard
(KDE)** from your application launcher, or run:

```sh
clamguard-kde
```

## Which edition should I install?

- Running Plasma / a Qt-based desktop → `clamguard-kde` fits in
  visually and uses Qt's native file/message dialogs.
- Running GNOME, Xfce, or another GTK-based desktop → the `clamguard`
  package (GTK3) is the better visual fit.
- Both packages can be installed at once; they don't conflict, and
  they share config/quarantine/history as noted above.

## Using ClamAV from the terminal (unchanged)

```sh
clamscan -r ~/Downloads
sudo freshclam
sudo systemctl status clamav-freshclam
clamdscan --fdpass -r /path
```

## Uninstalling

```sh
sudo apt remove clamguard-kde
```

Shared data under `~/.local/share/clamguard` and
`~/.config/clamguard` is left in place (and still used by the GTK
edition, if installed); remove by hand for a fully clean uninstall of
both editions.

## License

GPL-3.0-or-later. See `LICENSE` and `debian/copyright`.
