// Builds LiveWorld-RPG-Guide.docx: one guide for installing and playing.
// Gameplay sections come from data.json (exported from the game's own guide.py), so they match F1 in the game.
//   node make_guide.js data.json out.docx
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, LevelFormat, Footer, Header, PageNumber, TableOfContents, PageBreak,
} = require("docx");

const [, , dataPath, outPath] = process.argv;
const D = JSON.parse(fs.readFileSync(dataPath, "utf8"));
const VER = D.version;
const DEB = `liveworld-rpg_${VER}_all.deb`;

const INK = "2B2118", GOLD = "8A6416", RULE = "C9A85A", HEAD_BG = "EFE3C6", ZEBRA = "FAF6EC", CODE_BG = "F2F2F2";
const FONT = "Arial", MONO = "Consolas";
const PAGE_W = 12240, MARGIN = 1260, CONTENT = PAGE_W - 2 * MARGIN;   // US Letter, 0.875" margins

// ------------------------------------------------------------------ helpers
const nice = (s) => s.replace(/ -> /g, " → ").replace(/ - /g, " – ").replace(/\.\.\./g, "…");

function runs(text, opts = {}) {
  // **bold** and `code` spans
  const out = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`)/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), ...opts }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, ...opts }));
    else out.push(new TextRun({ text: t.slice(1, -1), font: MONO, size: 19, ...opts }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), ...opts }));
  return out;
}
const P = (text, o = {}) => new Paragraph({ children: runs(text), spacing: { after: 120 }, ...o });
const TOC = [];
const H1 = (text, pageBreak = true) => (TOC.push([1, text]), new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: pageBreak, children: [new TextRun(text)] }));
const H2 = (text) => (TOC.push([2, text]), new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(text)] }));
const H3_ = 0;
const H3 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(text)] });
const bullet = (text) => new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { after: 80 }, children: runs(text) });
let listNo = 0;
const numbered = (items) => { const ref = `num${listNo++}`; NUM_REFS.push(ref);
  return items.map((t) => new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 80 }, children: runs(t) })); };
const NUM_REFS = [];
const code = (lines) => lines.map((l, i) => new Paragraph({
  shading: { type: ShadingType.CLEAR, fill: CODE_BG, color: "auto" },
  spacing: { before: i === 0 ? 60 : 0, after: i === lines.length - 1 ? 140 : 0 },
  indent: { left: 240, right: 240 },
  children: [new TextRun({ text: l, font: MONO, size: 19 })],
}));
const note = (text) => new Paragraph({
  spacing: { before: 60, after: 160 }, indent: { left: 240 },
  border: { left: { style: BorderStyle.SINGLE, size: 18, color: RULE, space: 8 } },
  children: runs(text),
});

const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "D8CBA8" };
function table(widths, header, rows) {
  const total = widths.reduce((a, b) => a + b, 0);
  const mk = (cells, isHead, zebra) => new TableRow({
    tableHeader: isHead,
    children: cells.map((c, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: isHead ? { type: ShadingType.CLEAR, fill: HEAD_BG, color: "auto" } : zebra ? { type: ShadingType.CLEAR, fill: ZEBRA, color: "auto" } : undefined,
      margins: { top: 70, bottom: 70, left: 110, right: 110 },
      borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
      children: [new Paragraph({ children: runs(String(c), isHead ? { bold: true } : {}) })],
    })),
  });
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    rows: [mk(header, true, false), ...rows.map((r, i) => mk(r, false, i % 2 === 1))],
  });
}
const gap = () => new Paragraph({ spacing: { after: 120 }, children: [] });

// split "LABEL. rest" / "LABEL: rest" in the in-game guide lines into a bold lead
function guideLine(s) {
  s = nice(s);
  const m = s.match(/^([A-Z][A-Z' ]{2,}[A-Z?]?[.?:])\s+(.*)$/);
  if (m) {
    const lead = m[1].charAt(0) + m[1].slice(1).toLowerCase();
    return `**${lead}** ${m[2]}`;
  }
  return s;
}

// ------------------------------------------------------------------ content
const pages = Object.fromEntries(D.pages.map(([t, lines]) => [t, lines]));
const kids = [];

// ---- title
kids.push(new Paragraph({ spacing: { before: 2200, after: 120 }, alignment: AlignmentType.LEFT,
  children: [new TextRun({ text: "LiveWorld RPG", font: FONT, size: 64, bold: true, color: INK })] }));
kids.push(new Paragraph({ spacing: { after: 240 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: RULE, space: 10 } },
  children: [new TextRun({ text: "Install & Player's Guide", font: FONT, size: 36, color: GOLD })] }));
kids.push(P(`Version ${VER} · Debian/Ubuntu package \`${DEB}\` · Updated 6 October 2026`));
kids.push(P("LiveWorld RPG is an offline, single-player fantasy RPG with isometric 2.5D graphics, written in Python with pygame. You explore a world of twenty zones and forty towns split between the Alliance and the Horde, shared with over six hundred computer-controlled adventurers. Level from 1 to 100, run dungeons and raids with AI party members, fight in battlegrounds, and gather, craft and trade."));
kids.push(P("**Part 1** covers installing, updating and removing the game. **Part 2** is the full player's guide – the same text you get with F1 in the game, plus tables for the controls, classes and zones."));
kids.push(new Paragraph({ spacing: { before: 360, after: 120 }, children: [new TextRun({ text: "Contents", bold: true, size: 28, color: INK })] }));
const TOC_AT = kids.length;

// ================================================================ PART 1
kids.push(H1("Part 1 – Installation"));
kids.push(H2("Requirements"));
kids.push(table([2200, CONTENT - 2200], ["Item", "Details"], [
  ["Operating system", "Debian, Ubuntu, Linux Mint or another Debian-based Linux. The package is architecture-independent (all), so it works on x86-64 and ARM."],
  ["Required packages", "`python3` and `python3-pygame` – installed for you when you install with apt."],
  ["Recommended", "`x11-utils` (helps the game find your screen size for full screen)."],
  ["Disk space", "About 1.5 MB for the game, plus a small save folder."],
  ["Graphics", "Any desktop. The game starts on Normal graphics and drops to Lite by itself if it runs slowly. Press F9 to switch between Lite and Normal at any time."],
]));
kids.push(gap());

kids.push(H2("Step 1 – Install the package"));
kids.push(P("Open a terminal in the folder that holds the file (usually Downloads) and run:"));
kids.push(...code(["cd ~/Downloads", `sudo apt install ./${DEB}`]));
kids.push(P("The `./` matters: it tells apt to install the local file and fetch python3-pygame for you. Type your password when asked and answer **Y** to confirm."));
kids.push(note(`**Alternative:** if you used \`sudo dpkg -i ${DEB}\` and it complained about missing dependencies, run \`sudo apt -f install\` to pull them in. You can also double-click the .deb in your file manager to open it in your software installer, then click Install.`));
kids.push(P("To check the download first, keep the SHA256SUMS file next to the package and run:"));
kids.push(...code([`sha256sum -c --ignore-missing SHA256SUMS-${VER}.txt`]));

kids.push(H2("Step 2 – Launch the game"));
kids.push(bullet("**From the menu:** open your applications menu and look for **LiveWorld RPG** under Games."));
kids.push(bullet("**From a terminal:** run `liveworld-rpg`."));
kids.push(P("A loading screen appears while the world is built. The first start takes longest; later starts use a cached world map and are faster. Only one copy of the game runs at a time – starting it again just tells you it is already open."));

kids.push(H2("Step 3 (optional) – Create a character from the terminal"));
kids.push(P("You normally create your character in the game. There is also a command-line helper:"));
kids.push(...code(["liveworld-create-character NAME Alliance|Horde CLASS [SPEC]"]));
kids.push(P("Example: `liveworld-create-character Aria Alliance Paladin Holy`. Run it with no arguments and it asks each question in turn. An existing hero keeps its name and faction."));

kids.push(H2("Updating to a newer version"));
kids.push(P(`Install the new .deb the same way (\`sudo apt install ./liveworld-rpg_<version>_all.deb\`). Your saves are kept because they live in your home folder, not in the package. Saves from before 0.36 keep your hero; if the hero stood somewhere that changed on the new world map, they wake in a town of their own side.`));

kids.push(H2("Uninstalling"));
kids.push(P("Open **Uninstall LiveWorld RPG** from the applications menu (or right-click the game's menu entry), or run:"));
kids.push(...code(["liveworld-uninstall"]));
kids.push(P("It asks whether to **Remove everything** (the game plus your characters, saves and settings) or **Keep my saves** (only the program). A running game is saved and closed first. To remove only the program by hand:"));
kids.push(...code(["sudo apt remove liveworld-rpg"]));
kids.push(P("This leaves your save data. To delete it as well, remove `~/.local/share/liveworld-rpg` and `~/.local/state/liveworld-rpg`."));

kids.push(H2("Where files go"));
kids.push(table([4300, CONTENT - 4300], ["Path", "What it holds"], [
  ["`/usr/bin/liveworld-rpg`", "Game launcher"],
  ["`/usr/bin/liveworld-create-character`", "Command-line character helper"],
  ["`/usr/bin/liveworld-uninstall`", "Uninstaller (also in the applications menu)"],
  ["`/usr/lib/liveworld-rpg/`", "Game code (Python)"],
  ["`/usr/share/doc/liveworld-rpg/GUIDE.md`", "The player's guide as plain text (the same as F1 in the game)"],
  ["`~/.local/share/liveworld-rpg/`", "Your saves, settings and world data (override with the LIVEWORLD_DATA environment variable)"],
  ["`~/.local/state/liveworld-rpg/startup.log`", "Startup log – useful when something goes wrong"],
]));
kids.push(gap());

kids.push(H2("Troubleshooting"));
kids.push(table([3000, CONTENT - 3000], ["Problem", "Fix"], [
  ["A terminal window says “python3-pygame is unavailable”", "Run `sudo apt install python3-pygame`, then start the game again."],
  ["The game closes right after starting", "Read the log: `cat ~/.local/state/liveworld-rpg/startup.log`. The last lines show the error. The launcher also opens a terminal with the log when it can."],
  ["“LiveWorld RPG is already running”", "Another copy is open with the same save. Switch to its window, or close it first."],
  ["Full screen hides the HUD under a desktop panel or top bar", "Press Esc (or the gear button) → Settings → Display, and choose Borderless or Window."],
  ["The game runs slowly", "Press F9 to switch to Lite graphics. The game also does this by itself on slow PCs."],
  ["Nights are too dark", "Raise Brightness in Settings."],
  ["The menu entry does not appear", "Log out and back in, or start the game from a terminal with `liveworld-rpg`."],
]));

// ================================================================ PART 2
kids.push(H1("Part 2 – How to Play"));
kids.push(H2("Your first ten minutes"));
kids.push(...numbered([
  "**Create a character.** Pick a name, a faction (Alliance or Horde) and one of 12 classes. Alliance heroes start at Lionsreach in Greenfields, Horde heroes at Grimhold in Ashen Vale. Both zones are levels 1–10.",
  "**Move.** Click the ground to walk, or use W A S D / arrow keys.",
  "**Fight.** Click a monster to target it and auto-attack. Tab cycles targets; Space or E attacks the nearest one. Keys 1–0 use your class skills.",
  "**Get quests.** Find the Quest Giver by the notice board in town (name ends in “(Quests)”, marked with **!**). Press F next to them. Come back to the same giver when the marker shows **?** to hand in.",
  "**Loot and heal.** Press Z to pick up loot, H for a health potion, J for a mana potion.",
  "**Spend points.** Each level gives 3 stat points (U) and 1 spell point (K).",
  "**Read the in-game guide** any time with F1.",
]));

kids.push(H2("Controls"));
const cw = [1500, Math.floor((CONTENT - 3000) / 2), 1500, CONTENT - 3000 - Math.floor((CONTENT - 3000) / 2)];
kids.push(table(cw, ["Key", "Action", "Key", "Action"], [
  ["Click / WASD / arrows", "Move", "F", "Talk, interact, gather, enter dungeons, use buildings"],
  ["Click a monster", "Target and auto-attack", "Tab", "Next target (on the map: zoom in / out)"],
  ["Space / E", "Attack target (or nearest)", "1 – 0", "Class skills"],
  ["Shift + 1 – 6", "High-level skills (levels 30–80)", "Z", "Pick up loot"],
  ["H", "Health potion", "J", "Mana potion"],
  ["V", "Eat food (out of combat)", "Y", "Buff scroll, Health Bread or Sunwine"],
  ["T", "Teleport scroll", "G", "Fish (press again when a fish bites)"],
  ["X", "Mount / dismount", "I", "Bag and equipment"],
  ["C", "Class window", "K", "Skills (ranks are raised at a Skill Shop)"],
  ["U", "Character stats", "Q", "Quest log"],
  ["M", "World map", "` (backquote)", "Collapse / expand chat"],
  ["O", "Leave a dungeon, raid or battleground (out of combat)", "N", "Skip the 60-second rest in a dungeon"],
  ["F1", "This guide", "F9", "Switch between Lite and Normal graphics"],
  ["F11", "Full screen", "Esc / gear button", "Settings (graphics, brightness, sound, display)"],
]));
kids.push(gap());

kids.push(H2("Classes and roles"));
kids.push(P("Each class wears one armour type and only its own weapon types; unusable items show red in the bag. Paladin, Shaman and Druid choose a Tank, Healer or DPS specialization. Juggernaut is a pure tank; the other classes fill a damage slot in groups."));
const ROLE = { Warrior: "Melee DPS", Ranger: "Ranged DPS", Mage: "Caster DPS", Cleric: "Caster, self-heals", Rogue: "Melee DPS",
  Berserker: "Melee DPS", Warlock: "Caster DPS", Monk: "Melee DPS", Juggernaut: "Tank" };
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
kids.push(table([1600, 3300, 1300, CONTENT - 6200], ["Class", "Role", "Armour", "Weapons"],
  D.classes.map((c) => [c,
    D.hybrid[c] ? `${D.hybrid[c].map((s) => s[1]).join(" / ")} (${D.hybrid[c].map((s) => s[0]).join(", ")})` : ROLE[c],
    cap(D.armor[c]), D.wtypes[c].map(cap).join(", ")])));
kids.push(gap());

kids.push(H2("The world and where to level"));
kids.push(P("Each side has its own zone for every 10-level band: the Alliance in the west, the Horde in the east, with the front lines in the middle. Your own side's towns are safe; the other side's towns send their City Watch after you. Zone names are coloured by difficulty: green is easy, yellow fair, red dangerous. Levelling is deliberately slow, so mix kills, quests and dungeons."));
const bands = [];
for (const [name, fac, lo, hi] of D.areas) {
  let b = bands.find((x) => x.lo === lo); if (!b) bands.push(b = { lo, hi, A: [], H: [] });
  (fac === "Alliance" ? b.A : b.H).push(name);
}
kids.push(table([1700, Math.floor((CONTENT - 1700) / 2), CONTENT - 1700 - Math.floor((CONTENT - 1700) / 2)],
  ["Levels", "Alliance zone", "Horde zone"], bands.map((b) => [`${b.lo}–${b.hi}`, b.A.join(", "), b.H.join(", ")])));
kids.push(gap());

// ---- the in-game guide, page by page (Getting started and Gear by class are covered by the tables above)
const SKIP = new Set(["Getting started", "Gear by class"]);
for (const [title, lines] of D.pages) {
  if (SKIP.has(title)) continue;
  kids.push(H2(title));
  if (title === "The Mythic weapon") {
    const steps = lines.find((l) => l.startsWith("Steps:"));
    const weapons = lines.filter((l) => /^[A-Z][a-z]+: Voidreaver/.test(l));
    for (const l of lines) if (l !== steps && !weapons.includes(l) && !l.startsWith("Progress")) kids.push(bullet(guideLine(l)));
    kids.push(H3("Steps"));
    kids.push(...numbered(steps.replace(/^Steps:\s*/, "").split(/\s*\(\d+\)\s*/).filter(Boolean).map(nice)));
    kids.push(H3("The weapon for each class"));
    kids.push(table([2400, CONTENT - 2400], ["Class", "Mythic weapon"], weapons.map((l) => l.split(": "))));
    kids.push(gap());
    const prog = lines.find((l) => l.startsWith("Progress")); if (prog) kids.push(P(nice(prog)));
    continue;
  }
  for (const l of lines) kids.push(bullet(guideLine(l)));
}

kids.push(H2("Tips"));
for (const t of [
  "Stay in zones whose name shows green or yellow; red zones will kill you quickly.",
  "Elite monsters have gold name plates and give 3× rewards, but hit much harder.",
  "Keep a Teleport scroll (T) for getting back to town, and keep your savings in the Vault – dying in the open world costs 5% of the gold you carry.",
  "Eat cooked fish (V) between fights instead of spending potions.",
  "Read your quest log (Q): it shows the distance and direction to each target zone and the town to return to.",
  "Gear is a grind on purpose: raid set pieces drop in about one clear in three, and a full Gladiator set takes about 45 won 4v4 battlegrounds or 15 won 12v12 battlegrounds.",
]) kids.push(bullet(t));

// static contents list (a Word TOC field shows empty until Word refreshes it)
kids.splice(TOC_AT, 0, ...TOC.map(([lvl, t]) => new Paragraph({
  spacing: { before: lvl === 1 ? 140 : 0, after: 30 }, indent: { left: lvl === 1 ? 0 : 360 },
  children: [new TextRun({ text: t, bold: lvl === 1, size: lvl === 1 ? 22 : 20, color: lvl === 1 ? INK : "5A4A32" })],
})));

// ------------------------------------------------------------------ document
const doc = new Document({
  creator: "LiveWorld RPG Project",
  title: `LiveWorld RPG ${VER} – Install & Player's Guide`,
  styles: {
    default: { document: { run: { font: FONT, size: 21, color: INK }, paragraph: { spacing: { line: 276 } } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 36, bold: true, color: INK },
        paragraph: { spacing: { before: 0, after: 240 }, outlineLevel: 0,
          border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: RULE, space: 6 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 28, bold: true, color: GOLD },
        paragraph: { spacing: { before: 320, after: 140 }, outlineLevel: 1, keepNext: true } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 23, bold: true, color: INK },
        paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 2, keepNext: true } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 460, hanging: 280 } } } }] },
      ...NUM_REFS.map((ref) => ({ reference: ref, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 460, hanging: 320 } } } }] })),
    ],
  },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: 15840 }, margin: { top: 1200, bottom: 1200, left: MARGIN, right: MARGIN } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: `LiveWorld RPG ${VER} – Install & Player's Guide`, size: 16, color: "8C7E66" })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "8C7E66" })] })] }) },
    children: kids,
  }],
});

Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(outPath, buf); console.log("wrote", outPath); });
