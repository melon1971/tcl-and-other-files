"""Write the game data the Word guide is built from (version, F1 guide pages, zones, classes) as JSON.
    python3 guide/export_data.py OUT.json
Run with PYTHONPATH pointing at usr/lib/liveworld-rpg."""
import json, os, sys, tempfile

os.environ.setdefault("LIVEWORLD_DATA", tempfile.mkdtemp())
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
from liveworld_rpg import guide, engine as E, rpg, game as G   # noqa: E402

json.dump({"version": G.VERSION, "pages": guide.PAGES,
           "areas": [(a[0], a[5], a[6], a[7]) for a in E.AREAS],
           "classes": list(E.CLASSES), "armor": rpg.CLASS_ARMOR, "wtypes": rpg.CLASS_WTYPES, "hybrid": E.HYBRID_SPECS},
          open(sys.argv[1], "w"), indent=1, default=str)
