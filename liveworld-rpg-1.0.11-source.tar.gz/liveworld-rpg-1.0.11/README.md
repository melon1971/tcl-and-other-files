# LiveWorld RPG – source

An offline, single-player isometric fantasy RPG in Python and pygame, packaged for Debian/Ubuntu.

## What is in here

| Path | What it is |
|---|---|
| `usr/lib/liveworld-rpg/liveworld_rpg/` | The game (Python). `game.py` is the window and drawing, `engine.py` the world simulation, `instance.py` dungeons and raids, `arena.py` battlegrounds, `guide.py` the in-game guide (F1). |
| `usr/bin/` | Launcher, command-line character creator, uninstaller. |
| `usr/share/` | Menu entries, icons, AppStream data, `GUIDE.md` (generated from `guide.py`). |
| `DEBIAN/` | Package control file, maintainer scripts, `md5sums` (generated). |
| `tests/smoke_test.py` | Headless smoke tests: package consistency, world start-up for every class, every battleground map (layout, symmetry, reachability, full matches, scoring, rewards), dungeons, raids and the heroic raid, and real rendered frames. |
| `guide/` | Builds `LiveWorld-RPG-Guide.docx` from the game's own data. |
| `build.sh` | Builds the release into `dist/`. |

## Run the game from the source

```sh
sudo apt install python3 python3-pygame
PYTHONPATH=usr/lib/liveworld-rpg python3 -m liveworld_rpg.run
```

Saves go to `~/.local/share/liveworld-rpg` (set `LIVEWORLD_DATA` to use another folder).

## Test

```sh
python3 tests/smoke_test.py               # everything, about 4 minutes
python3 tests/smoke_test.py ArenaMaps     # one group: Package, WorldBoot, ArenaMaps, ArenaMatches, Dungeons, Render
```

The tests use a throwaway save folder and SDL's dummy video and audio drivers, so they never touch your saves and need no screen.

## Build a release

```sh
./build.sh --test
```

Writes to `dist/`: the `.deb`, this source as a `.tar.gz`, `LiveWorld-RPG-Guide.docx` and `SHA256SUMS-<version>.txt`. Needs `dpkg-deb`; the guide also needs Node.js with the `docx` module (`npm install docx`) and is skipped without it.

To release a new version, change the version in `DEBIAN/control`, `VERSION` in `game.py`, `__init__.py` and the newest `<release>` in `usr/share/metainfo/liveworld-rpg.metainfo.xml`, and add a line to the changelog at the end of `DEBIAN/control`. The tests fail if these disagree.
