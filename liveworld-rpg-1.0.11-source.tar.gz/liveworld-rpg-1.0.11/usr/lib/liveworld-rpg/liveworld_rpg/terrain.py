"""0.45: numpy ground texturing.

The ground colour field (biome colour, lush/dry patches, hills) is painted by gfx.render_chunk_steps.
This module adds the fine surface on top of it, per pixel and world-aligned so it runs seamlessly
across chunks: leafy clumps with lit tips and shaded gaps on grass, grit and pebbles on soil,
a soft grain on sand and snow, and only faint ripples on water.  Everything is built once from
tileable FFT noise, then each chunk is a handful of numpy array operations (a few ms).

numpy ships with python3-pygame on Debian/Ubuntu; if it is missing, HAVE_NP is False and the
game keeps the old multiply texture.
"""
try:
    import numpy as np
    import pygame.surfarray as _sa
    HAVE_NP = True
except Exception:          # pragma: no cover - old path stays available
    np = None; _sa = None
    HAVE_NP = False

N = 512                     # texture period in screen pixels (big enough that repeats don't show)
_T = {}


def _band(rng, lo, hi, aniso=2.0):
    """Tileable noise with features between `lo` and `hi` pixels across, squashed 2:1 for the iso ground."""
    white = rng.standard_normal((N, N)).astype(np.float32)
    fy = np.fft.fftfreq(N)[:, None] * aniso      # iso: features are half as tall as they are wide
    fx = np.fft.fftfreq(N)[None, :]
    f = np.sqrt(fx * fx + fy * fy) + 1e-9
    band = ((f >= 1.0 / hi) & (f <= 1.0 / lo)).astype(np.float32)
    band = band * np.exp(-((np.log(f * lo)) ** 2) * .15)
    out = np.real(np.fft.ifft2(np.fft.fft2(white) * band)).astype(np.float32)
    out -= out.mean(); out /= (out.std() + 1e-6)
    return out


def _build():
    if _T: return _T
    rng = np.random.default_rng(4512)
    leaf = _band(rng, 2.5, 7)            # single grass clumps
    clump = _band(rng, 7, 22)            # tussocks
    mid = _band(rng, 20, 70)             # light / shade patches
    macro = _band(rng, 70, 220)          # broad swells
    grain = rng.standard_normal((N, N)).astype(np.float32)
    # grass: crisp leafy clumps (tanh keeps them punchy), dark crevices between them
    lc = np.tanh(leaf * 1.3 + clump * .55)
    crev = np.clip(-(leaf + .35 * clump) - .9, 0, 2)
    _T["grass_l"] = (1.0 + .13 * lc + .07 * mid + .05 * macro + .025 * grain - .16 * crev).astype(np.float32)
    _T["grass_t"] = lc.astype(np.float32)               # +1 lit tip, -1 shaded base: drives the hue shift
    # soil: grit, small stones (bright specks with a shadow under them), soft patches
    peb = np.clip(_band(rng, 2, 5) - 1.6, 0, 3)
    peb_sh = np.roll(peb, 2, axis=0)
    _T["dirt_l"] = (1.0 + .06 * leaf + .07 * clump + .07 * mid + .04 * macro + .05 * grain + .22 * peb - .18 * peb_sh).astype(np.float32)
    # sand / snow / paving: very soft, so bright ground stays clean and readable
    _T["soft_l"] = (1.0 + .025 * leaf + .035 * mid + .03 * macro + .02 * grain).astype(np.float32)
    # water: long soft ripples only
    rip = _band(rng, 6, 30, aniso=4.0)
    _T["water_l"] = (1.0 + .05 * rip + .03 * macro).astype(np.float32)
    return _T


def _tile(t, gx, gy, w, h):
    """The w x h window of tileable texture t that starts at world screen pixel (gx, gy)."""
    ys = (np.arange(h) + gy) % N
    xs = (np.arange(w) + gx) % N
    return t[ys[:, None], xs[None, :]]


def texture_ground(surf, gx, gy, kinds=None):
    """Apply the ground surface texture in place to an opaque Surface whose top-left is world screen pixel (gx, gy)."""
    T = _build()
    px = _sa.pixels3d(surf)                       # (w, h, 3) view, x-major like pygame
    w, h = px.shape[0], px.shape[1]
    c = px.astype(np.float32).transpose(1, 0, 2)  # (h, w, 3)
    R, G, B = c[..., 0], c[..., 1], c[..., 2]
    lum = (R * .3 + G * .59 + B * .11)
    # what kind of ground each pixel is, from its colour (soft weights, so transitions blend)
    wg = np.clip((G - (R + B) * .5 - 4) / 22.0, 0, 1)                    # green -> grass
    if kinds is not None:                                                  # surface type from the tiles themselves
        k = _sa.pixels3d(kinds).transpose(1, 0, 2).astype(np.float32) / 255.0
        ww = k[..., 0]; ws = np.maximum(k[..., 1], np.clip((lum - 200) / 30.0, 0, 1)) * (1 - wg)
    else:
        ww = np.clip((B - R - 18) / 30.0, 0, 1) * np.clip((B - G + 30) / 30.0, 0, 1)   # blue -> water
        ws = np.clip((lum - 168) / 40.0, 0, 1) * (1 - wg)                  # bright -> sand / snow / paving
    wg = wg * (1 - ws)
    wg = wg * (1 - ww); ws = ws * (1 - ww)
    wd = np.clip(1 - wg - ww - ws, 0, 1)                                   # the rest -> soil
    L = (_tile(T["grass_l"], gx, gy, w, h) * wg + _tile(T["dirt_l"], gx, gy, w, h) * wd +
         _tile(T["soft_l"], gx, gy, w, h) * ws + _tile(T["water_l"], gx, gy, w, h) * ww)
    out = c * L[..., None]
    # grass hue: lit tips lean warm yellow-green, shaded bases lean cool blue-green (D2-style depth, still bright)
    tt = _tile(T["grass_t"], gx, gy, w, h) * wg
    out[..., 0] += tt * 7.0
    out[..., 1] += tt * 9.0
    out[..., 2] -= tt * 6.0
    np.clip(out, 0, 255, out=out)
    px[...] = out.transpose(1, 0, 2).astype(np.uint8)
    del px


def enhance_sprite(spr, sat=1.14, sharp=.55):
    """0.45: finishing pass for characters and monsters - a touch more colour and a crisper edge, so figures stand out
    on the textured ground.  Works in place on a copy; returns the original if numpy is missing."""
    if not HAVE_NP: return spr
    try:
        out = spr.copy()
        px = _sa.pixels3d(out); al = _sa.pixels_alpha(out)
        c = px.astype(np.float32)
        a = al.astype(np.float32) / 255.0
        lum = (c[..., 0] * .3 + c[..., 1] * .59 + c[..., 2] * .11)[..., None]
        c = lum + (c - lum) * sat                                   # saturation
        # unsharp mask with a 3x3 box blur (alpha-weighted so the transparent edge does not bleed in)
        w = a[..., None]
        num = c * w; den = w.copy()
        bn = np.zeros_like(num); bd = np.zeros_like(den)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                bn += np.roll(np.roll(num, dx, 0), dy, 1); bd += np.roll(np.roll(den, dx, 0), dy, 1)
        blur = bn / np.maximum(bd, 1e-3)
        c = c + (c - blur) * sharp
        np.clip(c, 0, 255, out=c)
        px[...] = c.astype(np.uint8)
        del px, al
        return out
    except Exception:
        return spr
