"""Gear bonuses (0.46): magic-shop bonus gear, Forge upgrades to +5, six-piece sets, Mythic gear and the Mythic oath.

* Magic Shop gear carries a bonus ("of the Tiger": +Strength, +Agility...), stored as JSON in player_gear.affix.
  Some pieces are sold already upgraded (+1 or +2).  Each Magic Shop also sells its zone's six-piece set.
* Any piece of gear can be upgraded at the Forge, +1 to +5: +6 Power and +10% of its own bonus per level.
* Sets are six pieces - weapon, armor, helm, necklace and two rings - with 2-, 4- and 6-piece bonuses that add up.
  Families: Magic Shop zone sets, raid Regalia (raid bosses) and PvP Battlegear (War Hall Armory).
  Several sets can be active at once (e.g. 2 PvP + 4 raid).
* Mythic gear (the Voidreaver weapon, Sovereign's raid armour, Mythic Gladiator's PvP gear) has its own bonus.
* Finishing the Mythic questline grants the Oath of the Sovereign; every finished step gives a little on the way.
"""
import json, re

PCT = ("crit", "dodge", "armor_pct", "mana_regen", "hp_pct", "dmg_pct", "speed", "heal_pct")
STAT_KEYS = ("str", "agi", "int", "vit") + PCT
LABEL = {"str": "Strength", "agi": "Agility", "int": "Intellect", "vit": "Vitality", "crit": "critical strike",
         "dodge": "dodge", "armor_pct": "less damage taken", "mana_regen": "mana regeneration", "hp_pct": "max health",
         "dmg_pct": "damage", "speed": "run speed", "heal_pct": "healing"}
PRIMARY = {"Warrior": "str", "Paladin": "str", "Juggernaut": "str", "Berserker": "str",
           "Rogue": "agi", "Ranger": "agi", "Monk": "agi",
           "Mage": "int", "Warlock": "int", "Cleric": "int", "Shaman": "int", "Druid": "int"}
SET_PIECES = 6


def primary(cls):
    return PRIMARY.get(cls, "str")


def btext(b):
    """{'str': 12, 'crit': .03} -> '+12 Strength, +3.0% critical strike'."""
    out = []
    for k in STAT_KEYS:
        v = b.get(k)
        if not v: continue
        out.append(f"+{v * 100:.1f}% {LABEL[k]}" if k in PCT else f"+{int(round(v))} {LABEL[k]}")
    return ", ".join(out)


def scaled(b, m):
    return {k: (v * m if k in PCT else int(round(v * m))) for k, v in b.items()}


def add_into(out, b):
    for k, v in b.items():
        out[k] = out.get(k, 0) + v
    return out


def up_level(name):
    m = re.search(r" \+(\d+)$", name or "")
    return int(m.group(1)) if m else 0


# ------------------------------------------------------------------ Magic Shop bonuses
# suffix, {stat: weight}.  'P' is the wearer's main stat.  Flat stats get the weight x points, % stats x points x PCT_PER.
AFFIXES = (
    ("of the Bear", {"vit": 1.0, "str": .5}), ("of the Tiger", {"str": .7, "agi": .7}), ("of the Owl", {"int": 1.0, "mana_regen": .6}),
    ("of the Eagle", {"agi": .8, "crit": .5}), ("of the Whale", {"vit": .8, "hp_pct": .6}), ("of the Falcon", {"agi": .6, "speed": .6}),
    ("of Slaying", {"P": .6, "dmg_pct": .6}), ("of Precision", {"P": .5, "crit": .7}), ("of the Bastion", {"vit": .6, "armor_pct": .7}),
    ("of Evasion", {"agi": .5, "dodge": .7}), ("of the Sage", {"int": .7, "heal_pct": .8}), ("of the Champion", {"P": .6, "vit": .6}),
)
PCT_PER = .0008
RARITY_MULT = {"Common": .5, "Uncommon": .7, "Rare": 1.0, "Epic": 1.35, "Elite": 1.7, "Legendary": 2.0, "Set": 1.5, "Mythic": 2.4}


def roll_affix(rng, level, rarity, cls):
    """(suffix, bonus) for a piece of Magic Shop gear."""
    suffix, w = rng.choice(AFFIXES)
    pts = (6 + level * .55) * RARITY_MULT.get(rarity, 1.0)
    b = {}
    for k, wt in w.items():
        k = primary(cls) if k == "P" else k
        b[k] = b.get(k, 0) + (pts * wt * PCT_PER if k in PCT else max(1, int(round(pts * wt * .5))))
    return suffix, b


# ------------------------------------------------------------------ Mythic gear and the Mythic oath
def mythic_bonus(item, slot, cls):
    """Every Mythic piece has its own bonus; the Voidreaver weapon's depends on the class."""
    n = item or ""
    P = primary(cls)
    if n.startswith("Voidreaver"):
        b = {P: 40, "dmg_pct": .08, "crit": .04}
        if cls in ("Cleric", "Druid", "Shaman", "Paladin"): b["heal_pct"] = .12
        if cls in ("Juggernaut", "Warrior", "Paladin"): b["armor_pct"] = .05
        if cls in ("Rogue", "Monk", "Ranger"): b["dodge"] = .04
        if cls in ("Mage", "Warlock"): b["mana_regen"] = .35
        return b
    if n.startswith("Sovereign's"):
        return {"armor": {"vit": 30, "armor_pct": .06, "hp_pct": .05}, "helm": {P: 25, "crit": .03, "vit": 12},
                "trinket": {P: 20, "dmg_pct": .05, "mana_regen": .25}, "ring": {P: 18, "crit": .025, "dodge": .02}}.get(slot, {P: 20})
    if n.startswith("Mythic Gladiator's"):
        return {P: 16, "vit": 16, "armor_pct": .03}
    return {}


OATH_STEP = {"str": 2, "agi": 2, "int": 2, "vit": 2}                    # per finished questline step
OATH = {"str": 15, "agi": 15, "int": 15, "vit": 15, "dmg_pct": .05, "hp_pct": .05, "crit": .03}
OATH_NAME = "Oath of the Sovereign"

# ------------------------------------------------------------------ sets
ZONE_SET_WORD = {"Greenfields": "Meadowguard", "Ashen Vale": "Emberveil", "Ironwood": "Ironbark", "Frostmarch": "Rimeforged",
                 "Storm Coast": "Tidecaller", "Bloodfen": "Mirewalker", "Crownlands": "Crownsworn", "Dreadmoor": "Gravewarden",
                 "Sunscar Desert": "Sunscorched", "Ember Highlands": "Cinderborn", "Wyrmreach": "Wyrmscale", "Shadowlands": "Nightveil"}
ZONE_TIER = {"Greenfields": 1, "Ashen Vale": 1, "Ironwood": 2, "Frostmarch": 3, "Storm Coast": 4, "Bloodfen": 5, "Crownlands": 6,
             "Dreadmoor": 7, "Sunscar Desert": 8, "Ember Highlands": 9, "Wyrmreach": 10, "Shadowlands": 10}
_WORD_TIER = {w: ZONE_TIER[z] for z, w in ZONE_SET_WORD.items()}
PVP_SET_TIER = (("Mythic Gladiator's", 1.25, 4), ("Legendary Gladiator's", .95, 3), ("Gladiator's", .7, 2), ("Recruit's", .4, 1))
HEROIC_RAID = ("Voidtouched", "Voidforged", "Void Seraph")


def set_family(set_name):
    """(family, multiplier, title) for a set name, or None."""
    s = set_name or ""
    if s.endswith(" Battlegear"):
        for pre, m, _ in PVP_SET_TIER:
            if s.startswith(pre): return ("pvp", m, "PvP set")
        return ("pvp", .7, "PvP set")
    if s.endswith(" Regalia"):
        return ("raid", 1.25 if s.startswith(HEROIC_RAID) else 1.0, "Raid set")
    if s.endswith(" Set"):
        t = _WORD_TIER.get(s.split()[0])
        if t: return ("magic", .9 + .12 * t, "Magic Shop set")
    return None


def set_tiers(set_name, cls):
    """{2: bonus, 4: bonus, 6: bonus} for this set; the bonuses add up as you wear more pieces."""
    f = set_family(set_name)
    if not f: return {}
    fam, m, _ = f
    P = primary(cls)
    if fam == "raid":
        t = {2: {"dmg_pct": .08, "hp_pct": .04}, 4: {"dmg_pct": .10, "hp_pct": .06, P: 25},
             6: {"crit": .05, "armor_pct": .08, "dmg_pct": .07, "heal_pct": .10}}
    elif fam == "pvp":
        t = {2: {"vit": 20, "armor_pct": .05}, 4: {"dmg_pct": .08, P: 15}, 6: {"hp_pct": .10, "dodge": .04, "crit": .04}}
    else:
        t = {2: {P: 15}, 4: {"dmg_pct": .03, "hp_pct": .03}, 6: {"crit": .025, "dmg_pct": .04, "vit": 12}}
    return {n: scaled(b, m) for n, b in t.items()}


class BonusMixin:
    # ---------------------------------------------------------------- storage
    def _bonus_schema(self):
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(player_gear)").fetchall()}
        if "affix" not in cols:
            self.db.execute("ALTER TABLE player_gear ADD COLUMN affix TEXT DEFAULT ''")
        # PvP pieces bought before 0.46 join their tier's six-piece Battlegear set
        for pre, _, _ in PVP_SET_TIER:
            self.db.execute("UPDATE player_gear SET set_name=? WHERE source='Armory' AND set_name='' AND item LIKE ?", (f"{pre} Battlegear", pre + " %"))
        self.db.commit()

    @staticmethod
    def _affix_of(row):
        try:
            b = json.loads(row["affix"] or "{}") if "affix" in row.keys() else {}
        except (ValueError, TypeError):
            b = {}
        return {k: v for k, v in b.items() if k in STAT_KEYS and isinstance(v, (int, float))} if isinstance(b, dict) else {}

    # ---------------------------------------------------------------- one item
    def item_bonus(self, row):
        """The item's own bonus (Magic Shop bonus or Mythic bonus), grown 10% per upgrade level."""
        b = dict(self._affix_of(row))
        if row["rarity"] == "Mythic":
            add_into(b, mythic_bonus(row["item"], row["slot"], self.class_name()))
        n = up_level(row["item"])
        return scaled(b, 1 + .10 * n) if (b and n) else b

    # ---------------------------------------------------------------- sets
    def set_status(self):
        """Every set you wear at least one piece of: name, pieces, its 2/4/6 bonuses and which are active."""
        cls = self.class_name(); sets = {}
        for r in self.db.execute("SELECT set_name FROM player_gear WHERE equipped>0 AND vault=0 AND set_name<>''").fetchall():
            sets[r["set_name"]] = sets.get(r["set_name"], 0) + 1
        out = []
        for nm, n in sorted(sets.items(), key=lambda x: -x[1]):
            tiers = set_tiers(nm, cls)
            if not tiers: continue
            fam = set_family(nm)
            out.append({"set": nm, "pieces": min(n, SET_PIECES), "kind": fam[2],
                        "tiers": [{"n": k, "bonus": b, "text": btext(b), "on": n >= k} for k, b in sorted(tiers.items())]})
        return out

    def set_stats(self):
        out = {}
        for s in self.set_status():
            for t in s["tiers"]:
                if t["on"]: add_into(out, t["bonus"])
        return out

    # ---------------------------------------------------------------- Mythic questline
    def oath_status(self):
        """(steps done, steps total, bonus) for the Mythic questline of your class."""
        try:
            from .rpg import MYTHIC_STEPS
            st = self._mythic_state(); i = st.get(self.class_name(), [0, 0])[0]
        except Exception:
            return 0, 9, {}
        total = len(MYTHIC_STEPS); i = min(i, total)
        b = scaled(OATH_STEP, i) if i else {}
        if i >= total: add_into(b, OATH)
        return i, total, b

    # ---------------------------------------------------------------- everything together
    def bonus_stats(self):
        """Item bonuses + set bonuses + the Mythic oath, as {stat: value} (cached per tick and gear change)."""
        key = (self.tick, getattr(self, "_gear_ver", 0))
        c = getattr(self, "_bonus_c", None)
        if c and c[0] == key: return c[1]
        out = {}
        for r in self.db.execute("SELECT item,slot,rarity,affix FROM player_gear WHERE equipped>0 AND vault=0").fetchall():
            add_into(out, self.item_bonus(r))
        add_into(out, self.set_stats())
        add_into(out, self.oath_status()[2])
        self._bonus_c = (key, out)
        return out

    def bonus_summary(self):
        """For the HUD: one line for the strongest set plus every active set and the oath."""
        ss = self.set_status(); i, total, ob = self.oath_status()
        lines = []
        for s in ss:
            on = [t for t in s["tiers"] if t["on"]]
            lines.append(f"{s['set']} {s['pieces']}/6" + (f": {', '.join(t['text'] for t in on)}" if on else " (2 pieces for a bonus)"))
        if i >= total: lines.append(f"{OATH_NAME}: {btext(OATH)}")
        elif i: lines.append(f"Mythic questline {i}/{total}: {btext(ob)}")
        best = max(ss, key=lambda s: s["pieces"]) if ss else None
        return {"set": best["set"] if best else "", "pieces": best["pieces"] if best else 0, "damage": 1.0, "maxhp": 1.0,
                "text": lines[0] if lines else "", "lines": lines, "sets": ss} if lines else None
