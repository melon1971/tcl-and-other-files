"""LiveWorld RPG 0.46.27 - the player-to-player side of the Trade Market, mixed into engine.World.

* computer adventurers put their own spare gear up for sale: the "Buy" tab lists real bots and their gear
* you can list your own gear, herbs, materials and potions at an asking price you choose (a percentage of the fair price);
  adventurers come by over time and buy what is priced well - a bargain goes fast, an overpriced item may never sell
* a listing lasts 3 days, then comes back to your bag; the market keeps a 5% fee on every sale
"""
import random

LISTING_MAX = 8                 # open listings per player
LISTING_DAYS = 3                # a listing is returned after this many game days
DAY_TICKS = 960
FEE = .05
CHECK_EVERY = 80                # ticks between buyer visits (20 s)
GEAR_SLOTS = ("weapon", "armor", "helm", "trinket")


def sale_chance(ratio):
    """Chance per visit that someone buys, from the asking price / fair price."""
    if ratio <= .7: return .38
    if ratio <= .9: return .24
    if ratio <= 1.05: return .12
    if ratio <= 1.25: return .05
    if ratio <= 1.6: return .012
    return .002


def demand_label(ratio):
    return ("Sells fast" if ratio <= .7 else "Good price" if ratio <= .9 else "Fair price" if ratio <= 1.05
            else "Pricey" if ratio <= 1.25 else "Very pricey" if ratio <= 1.6 else "Unlikely to sell")


class MarketplaceMixin:
    # ------------------------------------------------------------ bots selling their gear
    def _bot_listings(self, t):
        """Six pieces of gear that real adventurers are selling here.  Cached per town / market period / player level band,
        so the list does not shuffle under the cursor when a bot levels up between viewing and buying."""
        per = self.day // 2; lvl = self.player["level"]
        key = (t.id, per, lvl // 5)
        cache = self.__dict__.setdefault("_bl_cache", {})
        out = cache.get(key)
        if out is not None:
            return out
        if len(cache) > 12: cache.clear()
        r = random.Random(f"BL{self._seed()}:{t.id}:{per}:{lvl // 5}")
        cands = [a for a in self.actors if a.kind == "adventurer" and a.hp > 0 and (t.faction == a.faction or t.faction not in ("Alliance", "Horde"))
                 and lvl - 14 <= a.level <= lvl + 10]
        cands.sort(key=lambda a: a.id)
        r.shuffle(cands)
        out = []
        for a in cands[:6]:
            slots = [g for g in self.npc_gear(a) if g["slot"] in GEAR_SLOTS]
            if not slots: continue
            g = r.choice(slots)
            rar = g["rarity"]; power = min(168, g["power"])
            out.append({"label": g["item"], "sub": f"{g['slot']}  P{power}  from {a.name} (Lv {a.level} {a.role})", "rarity": rar, "slot": g["slot"],
                        "power": power, "price": int(self._gear_value(rar, power) * (.9 + r.random() * .3)), "item": g["item"]})
        cache[key] = out
        return out

    # ------------------------------------------------------------ your listings
    def _mk_fair(self, t, key, row):
        """Fair price of one of your sell rows (what a buyer would normally pay)."""
        if key.startswith("x:"):
            return max(1, int(row["price"] / .4))
        return max(1, self._buy_price(t, key[2:]))

    def mk_list_rows(self, t, sell_rows, mult):
        out = []
        for row in sell_rows:
            fair = self._mk_fair(t, row["key"], row)
            ask = max(1, int(fair * mult))
            d = dict(row); d["price"] = ask; d["sub"] = f"{row['sub']}   fair {fair:,}g  -  {demand_label(ask / fair)}"
            out.append(d)
        return out

    def mk_mine_rows(self, t):
        out = []
        for L in self._mkt_state().get("mine", []):
            if L.get("town") != t.id: continue
            left = max(0, L["t0"] + LISTING_DAYS * DAY_TICKS - self.tick) / DAY_TICKS
            fair = max(1, L.get("fair", L["price"]))
            if L.get("row"):
                rw = L["row"]; label = rw["item"]; rar = rw["rarity"]; what = f"{rw['slot']}  P{rw['power']}"
            else:
                label = L["good"].split(":", 1)[-1]; rar = "Common"; what = "x1"
            d_ = {"key": f"m:{L['id']}", "label": label, "sub": f"{what}   {demand_label(L['price'] / fair)}  -  {left:.1f} days left",
                  "rarity": rar, "price": L["price"]}
            if L.get("row"): d_.update({"slot": L["row"]["slot"], "power": L["row"]["power"], "item": L["row"]["item"]})      # 0.46.37: so the row can be hovered
            out.append(d_)
        return out

    def market_list(self, key, mult=1.0):
        t = self.market_town()
        if not t: return "You must be in a town to trade."
        st = self._mkt_state()
        mine = st.setdefault("mine", [])
        if len(mine) >= LISTING_MAX: return f"You can only have {LISTING_MAX} listings open. Cancel one first."
        v = self.market_view()
        row = next((b for b in v["sell"] if b["key"] == key), None)
        if not row: return "You no longer have that."
        fair = self._mk_fair(t, key, row)
        price = max(1, int(fair * max(.3, min(3.0, mult))))
        L = {"id": st.get("next", 1), "town": t.id, "price": price, "fair": fair, "t0": self.tick}
        if key.startswith("x:"):
            g = self.db.execute("SELECT * FROM player_gear WHERE id=?", (int(key[2:]),)).fetchone()
            if g is None or g["equipped"]: return "You can't list worn gear."
            L["row"] = dict(g)
            self.db.execute("DELETE FROM player_gear WHERE id=?", (int(key[2:]),))
            label = g["item"]
        else:
            good = key[2:]
            self._inv_add(good, -1)
            L["good"] = good; label = good.split(":", 1)[-1]
        st["next"] = L["id"] + 1
        mine.append(L)
        self._mkt_save(st); self.db.commit(); self._save_player_fast()
        return f"Listed {label} for {price:,}g in {t.name} ({demand_label(price / fair).lower()})."

    def _mk_return(self, L):
        """Give a listing's item back to the player."""
        if L.get("row"):
            known = {r[1] for r in self.db.execute("PRAGMA table_info(player_gear)")}      # 0.46.33: only real columns are ever put into the SQL text
            rw = {k: v for k, v in L["row"].items() if k != "id" and k in known}
            rw["equipped"] = 0
            cols = ",".join(rw)
            self.db.execute(f"INSERT INTO player_gear({cols}) VALUES({','.join('?' * len(rw))})", tuple(rw.values()))
        elif L.get("good"):
            self._inv_add(L["good"], 1)

    def market_cancel(self, key):
        t = self.market_town()
        if not t: return "You must be in a town to trade."
        st = self._mkt_state()
        mine = st.get("mine", [])
        L = next((x for x in mine if f"m:{x['id']}" == key), None)
        if L is None: return "That listing is gone."
        if L.get("town") != t.id: return "Go back to the town where you listed it."
        mine.remove(L)
        self._mk_return(L)
        self._mkt_save(st); self.db.commit(); self._save_player_fast()
        return "Listing cancelled - the item is back in your bag."

    # ------------------------------------------------------------ buyers
    def _mkt_tick(self):
        if self.tick % CHECK_EVERY: return
        st = self._mkt_state()
        mine = st.get("mine")
        if not mine: return
        town = {t.id: t for t in self.towns}
        changed = False
        for L in list(mine):
            t = town.get(L.get("town"))
            if self.tick - L["t0"] >= LISTING_DAYS * DAY_TICKS:         # nobody wanted it: back to the bag
                mine.remove(L); self._mk_return(L); changed = True
                label = L["row"]["item"] if L.get("row") else L["good"].split(":", 1)[-1]
                self.events.append(f"Your listing of {label} in {t.name if t else 'the market'} expired and was returned to you.")
                continue
            if self.rng.random() >= sale_chance(L["price"] / max(1, L.get("fair", L["price"]))): continue
            buyers = [a for a in self.actors if a.kind == "adventurer" and a.hp > 0 and t is not None and (a.x - t.x) ** 2 + (a.y - t.y) ** 2 < 70 * 70]
            who = self.rng.choice(buyers).name if buyers else self.rng.choice(self.TRADERS)
            net = int(L["price"] * (1 - FEE))
            mine.remove(L); changed = True
            self.player["gold"] += net
            label = L["row"]["item"] if L.get("row") else L["good"].split(":", 1)[-1]
            self.events.append(f"{who} bought your {label} in {t.name if t else 'the market'} for {L['price']:,}g (+{net:,}g after the {int(FEE * 100)}% fee).")
        if changed:
            self._mkt_save(st); self.db.commit(); self._save_player_fast()
