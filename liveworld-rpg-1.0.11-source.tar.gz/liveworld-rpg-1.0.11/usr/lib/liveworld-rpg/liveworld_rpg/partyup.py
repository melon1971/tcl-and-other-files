"""LiveWorld RPG 0.44 - recruiting: click an adventurer (or a guard) and ask them to join your party.

* The person window has three tabs: Overview, Gear (what they wear) and Party (ask them to join).
* They may or may not say yes - it depends on their personality, how their level compares to yours, their health and
  whether they are busy.  A refusal makes them unwilling for a few minutes.
* Up to 3 party members follow you through the world and fight what attacks you.  In dungeons and raids they take
  the place of the AI allies (the group size stays the same, so each member means one AI ally fewer).
"""
import json
import math
import random

PARTY_MAX = 3
HEALER_CLASSES = ("Cleric", "Druid", "Shaman", "Paladin")
SLOT_ORDER = ("weapon", "armor", "helm", "trinket", "ring")
SLOT_TITLE = {"weapon": "Weapon", "armor": "Armor", "helm": "Helm", "trinket": "Necklace", "ring": "Ring"}


class PartyUpMixin:
    # ---------------------------------------------------------------- who is in the party
    def _pp_ids(self):
        v = self._jmeta("pparty", None, list)
        return [i for i in v if isinstance(i, int) and not isinstance(i, bool)]

    def _pp_save(self, ids):
        self._setmeta("pparty", json.dumps(ids))
        self.db.commit()

    def party_members(self):
        out = []
        for i in self._pp_ids():
            a = self.by_id.get(i)
            if a is not None and a.hp > 0:
                out.append(a)
        return out

    def party_snapshot(self):
        return [{"id": a.id, "name": a.name, "level": a.level, "cls": a.role, "hp": int(a.hp), "maxhp": int(a.maxhp)} for a in self.party_members()]

    def is_pmember(self, aid):
        return aid in self._pp_ids()

    # ---------------------------------------------------------------- their gear (generated from level, class and id)
    def npc_gear(self, a):
        from .rpg import RARITY_POWER
        lvl = a.level
        rar = ("Common" if lvl < 10 else "Uncommon" if lvl < 22 else "Rare" if lvl < 40 else "Epic" if lvl < 62 else "Elite" if lvl < 85 else "Legendary")
        want = getattr(a, "gear", None)
        if want in RARITY_POWER and want not in ("Set", "Mythic"):
            rar = want
        cls = a.role if a.kind == "adventurer" else "Warrior"
        rows = []
        for slot in SLOT_ORDER:
            r = random.Random(f"{a.id}:{slot}")
            try:
                nm = self.gear_word(slot, r, cls)
            except Exception:
                nm = SLOT_TITLE[slot]
            rows.append({"slot": slot, "title": SLOT_TITLE[slot], "item": f"{rar} {nm}", "rarity": rar,
                         "power": min(168, lvl * 2 + RARITY_POWER[rar] + 3 + (r.randint(0, 4)))})
        return rows

    # ---------------------------------------------------------------- asking
    def _recruitable(self, a):
        return a is not None and a.hp > 0 and (a.kind == "adventurer" or (a.kind == "npc" and a.role == "guard"))

    def join_chance(self, a):
        """(chance, reason-if-no) that a will join."""
        p = self.player
        if a.faction != p["faction"]:
            return 0.0, "will not travel with an enemy of their people"
        if a.kind == "npc":
            return .25, ""
        if a.state in ("aiduel", "defend", "fight", "duel", "offer") or (a.party and a.party != -1):
            return 0.0, "is busy right now"
        if getattr(a, "refused_until", 0) > self.tick:
            return 0.0, "has already given you an answer"
        base = {"friendly": .8, "proud": .35, "aggressive": .55, "shy": .25, "trader": .3, "explorer": .7, "guardian": .75}.get(getattr(a, "persona", "friendly"), .5)
        gap = a.level - p["level"]
        if gap > 12:
            base *= .3
        elif gap > 5:
            base *= .65
        elif gap < -25:
            base *= .45
        if a.hp < a.maxhp * .5:
            base *= .5
        return max(.03, min(.95, base)), ""

    def party_invite(self, aid):
        a = self.by_id.get(aid)
        if not self._recruitable(a):
            return "There is nobody there to ask."
        if self.inst or getattr(self, "city_raid", None):
            return "Not now - ask them out in the world."
        ids = self._pp_ids()
        if aid in ids:
            return f"{a.name} is already in your party."
        if len(self.party_members()) >= PARTY_MAX:
            return f"Your party is full ({PARTY_MAX} companions). Dismiss someone first."
        if self._pdist(a) > 8:
            return f"{a.name} is too far away."
        ch, why = self.join_chance(a)
        if ch <= 0:
            return f"{a.name} {why}."
        if self.rng.random() < ch:
            ids.append(aid)
            self._pp_save(ids)
            a.state = "pparty"; a.party = -1; a.gx = None
            if a.kind == "adventurer":
                self._say(a, "greet")
            return f"{a.name} (level {a.level} {a.role}) joins your party!"
        a.refused_until = self.tick + 1600
        if a.kind == "adventurer":
            a.say = self.rng.choice(("Not today.", "I travel alone.", "Maybe another time.", "I have my own road to walk.", "Sorry - no."))
            a.say_until = self.tick + 24; a.say_seq += 1
        return f"{a.name} declines. Try again later."

    def party_dismiss(self, aid):
        ids = self._pp_ids()
        if aid not in ids:
            return "They are not in your party."
        ids.remove(aid)
        self._pp_save(ids)
        a = self.by_id.get(aid)
        if a is not None:
            a.party = 0
            a.state = "town" if a.kind == "adventurer" else "guard"
            a.task_until = 0
            return f"{a.name} leaves your party."
        return "They leave your party."

    def party_in_instance(self):
        """(name, class) of the companions that go in with you - each one takes the place of an AI ally."""
        return [(a.name, a.role if a.kind == "adventurer" else "Warrior") for a in self.party_members()]

    # ---------------------------------------------------------------- following and fighting (world only)
    RANGED_CLASSES = ("Ranger", "Mage", "Warlock", "Cleric", "Shaman", "Druid")

    def _pp_foes(self, x, y, dist):
        """Live monsters hunting the player within dist of (x, y).  Scans the spatial grid directly: actors_near() only looks in
        the asking actor's home zone, so a companion who followed you into another zone could not see anything."""
        d2 = dist * dist; g = self._grid(); out = []
        for cx in range(int(x - dist) >> 3, (int(x + dist) >> 3) + 1):
            for cy in range(int(y - dist) >> 3, (int(y + dist) >> 3) + 1):
                for m in g.get((cx, cy), ()):
                    if m.kind == "monster" and m.target == -2 and m.hp > 0 and (m.x - x) ** 2 + (m.y - y) ** 2 <= d2:
                        out.append(m)
        return out

    def _pp_fx(self, kind, src, dst, **kw):
        q = self.__dict__.setdefault("pfx", [])
        if len(q) < 40:
            e = {"t": kind, "src": src, "dst": dst}; e.update(kw); q.append(e)

    def _pparty_tick(self):
        if self.inst:
            return
        mem = self.party_members()
        if not mem:
            return
        p = self.player
        px, py = p["x"], p["y"]
        hunted = self._pp_foes(px, py, 16)                 # everything that is after you right now
        for i, a in enumerate(mem):
            a.state = "pparty"; a.party = -1
            if self.tick % 40 == 0:
                a.hp = max(a.hp, a.maxhp * .6)
            cls = a.role if a.kind == "adventurer" else "Warrior"
            ranged = cls in self.RANGED_CLASSES
            # --- choose a target: keep the current one while it lives and is still after us, else the nearest enemy hunting you
            foe = self.by_id.get(getattr(a, "ptgt", None))
            if foe is None or foe.hp <= 0 or foe.target != -2 or (foe.x - px) ** 2 + (foe.y - py) ** 2 > 22 * 22:
                foe = None
                if hunted:
                    foe = min(hunted, key=lambda m: (m.x - a.x) ** 2 + (m.y - a.y) ** 2)
                a.ptgt = foe.id if foe is not None else None
            if foe is not None:
                want = 5.5 if ranged else 1.3
                d = math.hypot(foe.x - a.x, foe.y - a.y)
                if d > want + .4:
                    self._move(a, foe.x, foe.y, 1.0 if d > 6 else .6)
                a.timer -= 1
                reach = 7.5 if ranged else 1.9
                if d <= reach and a.timer <= 0 and foe.hp > 0:
                    a.timer = 5 if ranged else 4
                    dmg = max(1, int(self._damage(a, foe) * 1.3))
                    foe.hp -= dmg
                    self._aggro(foe)
                    self._pp_fx("shot" if ranged else "melee", a.id, foe.id, cls=cls, dmg=dmg)
                    if foe.hp <= 0:
                        self.events.append(f"{a.name} slays {foe.name.split(' #')[0]}.")
                        self._player_kill(foe)
                        a.ptgt = None
                        hunted = [m for m in hunted if m.hp > 0]
            else:
                ang = i * 2.1 + 1.0
                tx, ty = px + math.cos(ang) * 2.2, py + math.sin(ang) * 2.2
                d = math.hypot(tx - a.x, ty - a.y)
                if d > 40:
                    a.x, a.y = tx, ty
                elif d > 1.4:
                    self._move(a, tx, ty, .9 if d > 6 else .5)
            if math.hypot(px - a.x, py - a.y) > 30:        # fell behind (or chased too far): catch up
                a.x, a.y = px + math.cos(i * 2.1 + 1.0) * 2.2, py + math.sin(i * 2.1 + 1.0) * 2.2
                a.ptgt = None
            if cls in HEALER_CLASSES and self.tick % 20 == (i * 7) % 20 and p["hp"] < self._effective_maxhp() * .75 and self.tick - self.last_combat_tick < 60:
                amt = int(self._effective_maxhp() * .08)
                self._heal(amt)
                self._pp_fx("heal", a.id, "player", cls=cls, amt=amt)
