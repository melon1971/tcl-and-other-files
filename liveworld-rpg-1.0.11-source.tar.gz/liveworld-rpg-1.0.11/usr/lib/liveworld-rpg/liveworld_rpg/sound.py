"""Procedural sound for LiveWorld RPG 0.24 - no audio files needed.

Every effect and the background music are synthesised at start-up with plain Python (no numpy).
If the machine has no audio device the whole module quietly does nothing.
"""
import array
import math
import os
import random
import threading
import time

import pygame

RATE = 22050
_TAU = math.pi * 2


def _env(i, n, a=.01, r=.4):
    t = i / RATE
    d = n / RATE
    if t < a:
        return t / a
    return max(0.0, 1 - (t - a) / max(1e-3, d - a)) ** (1 + r * 3)


def _tone(freq, dur, vol=.5, wave="sine", sweep=0.0, decay=1.0):
    n = int(RATE * dur)
    out = []
    ph = 0.0
    for i in range(n):
        f = freq + sweep * (i / n)
        ph += _TAU * f / RATE
        if wave == "sine":
            v = math.sin(ph)
        elif wave == "square":
            v = 1.0 if math.sin(ph) > 0 else -1.0
            v *= .6
        elif wave == "tri":
            v = 2 / math.pi * math.asin(math.sin(ph))
        else:
            v = math.sin(ph) + .5 * math.sin(2 * ph)
        out.append(v * vol * _env(i, n, .004, decay))
    return out


def _noise(dur, vol=.4, lp=.35, decay=1.0):
    n = int(RATE * dur)
    r = random.Random(7)
    out = []
    y = 0.0
    for i in range(n):
        y += (r.uniform(-1, 1) - y) * lp
        out.append(y * vol * _env(i, n, .002, decay))
    return out


def _mix(*tracks, offsets=None):
    offsets = offsets or [0] * len(tracks)
    n = max(len(t) + int(o * RATE) for t, o in zip(tracks, offsets))
    buf = [0.0] * n
    for t, o in zip(tracks, offsets):
        s = int(o * RATE)
        for i, v in enumerate(t):
            buf[s + i] += v
    return buf


def _snd(samples, vol=1.0):
    a = array.array("h", (int(max(-1.0, min(1.0, v)) * 32000) for v in samples))
    s = pygame.mixer.Sound(buffer=a.tobytes())
    s.set_volume(vol)
    return s


def _note(semi, base=220.0):
    return base * 2 ** (semi / 12)


class Audio:
    def __init__(self, master=.8, music=.5, sfx=.8, mute=False):
        self.ok = False
        self.master, self.music_v, self.sfx_v, self.mute = master, music, sfx, mute
        self.sounds = {}
        self.last = {}
        self.music = None
        self._music_bytes = None          # 1.0.11: the music is only synthesised off-thread; the mixer itself is touched by the main thread only
        if os.environ.get("LIVEWORLD_NO_AUDIO"):
            return
        try:
            pygame.mixer.pre_init(RATE, -16, 1, 512)
            pygame.mixer.init(RATE, -16, 1, 512)
            self.ok = True
        except Exception:
            self.ok = False
            return
        try:
            self._build_sfx()
            t = threading.Timer(12.0, self._build_music); t.daemon = True; t.start()
        except Exception:
            self.ok = False

    # ------------------------------------------------------------ build
    def _build_sfx(self):
        S = self.sounds
        S["hit"] = _snd(_mix(_noise(.07, .5, .5, 1.2), _tone(150, .09, .45, "sine", -60)))
        S["crit"] = _snd(_mix(_noise(.1, .6, .6, 1.0), _tone(260, .16, .5, "tri", -120), _tone(520, .1, .25, "sine", -200)))
        S["hurt"] = _snd(_mix(_noise(.12, .5, .25, 1.0), _tone(100, .14, .5, "sine", -40)))
        S["click"] = _snd(_tone(1100, .035, .25, "square"))
        S["loot"] = _snd(_mix(_tone(_note(7), .09, .35, "tri"), _tone(_note(12), .16, .35, "tri"), offsets=[0, .08]))
        S["coin"] = _snd(_mix(_tone(1500, .06, .3, "square"), _tone(2000, .12, .3, "square"), offsets=[0, .05]))
        S["levelup"] = _snd(_mix(*[_tone(_note(s), .22, .35, "tri") for s in (0, 4, 7, 12)], offsets=[0, .1, .2, .3]))
        S["quest"] = _snd(_mix(_tone(_note(5), .12, .35, "tri"), _tone(_note(12), .3, .4, "tri"), offsets=[0, .12]))
        S["portal"] = _snd(_mix(_tone(200, .6, .4, "sine", 500, .3), _tone(305, .6, .25, "sine", 600, .3)))
        S["cast"] = _snd(_mix(_tone(300, .22, .3, "sine", 500, .6), _noise(.2, .12, .2)))
        S["splash"] = _snd(_mix(_noise(.25, .45, .15, 1.0)))
        S["bite"] = _snd(_mix(_tone(880, .08, .4, "sine"), _tone(1320, .12, .4, "sine"), offsets=[0, .07]))
        S["craft"] = _snd(_mix(_noise(.05, .6, .6, 1.5), _tone(_note(12), .25, .3, "tri"), offsets=[0, .04]))
        S["eat"] = _snd(_mix(_noise(.06, .3, .3), _noise(.06, .3, .3), offsets=[0, .12]))
        S["fanfare"] = _snd(_mix(*[_tone(_note(s), .3, .35, "tri") for s in (0, 7, 12, 16, 19)], offsets=[0, .14, .28, .42, .56]))

    def _build_music(self):
        try:
            dur = 32.0
            n = int(RATE * dur)
            prog = ((0, 3, 7, 10), (-4, 0, 3, 7), (3, 7, 10, 14), (-2, 2, 5, 9))      # Am7 - Fmaj7 - Cmaj7 - G
            seg = n // 4
            out = array.array("h", [0]) * n
            for ci, chord in enumerate(prog):
                base = 110.0
                freqs = [_note(s, base) for s in chord]
                arp = [_note(s + 12, base * 2) for s in chord]
                for i in range(seg):
                    t = (ci * seg + i) / RATE
                    k = i / seg
                    env = min(1.0, k * 6) * min(1.0, (1 - k) * 6)
                    v = 0.0
                    for j, f in enumerate(freqs):
                        v += math.sin(_TAU * f * t + math.sin(t * .3 + j) * .3) * (.11 - j * .01)
                    step = int((i / RATE) / .5) % 8
                    af = arp[[0, 2, 1, 3, 2, 1, 3, 0][step]]
                    local = ((i / RATE) % .5)
                    v += math.sin(_TAU * af * t) * .07 * math.exp(-local * 6)
                    out[ci * seg + i] = int(v * env * 26000)
                    if i % 1500 == 0:
                        time.sleep(.002)
            self._music_bytes = out.tobytes()      # handed to pump(), which runs on the main thread
        except Exception:
            pass

    def pump(self):
        """1.0.11: call every frame from the main thread. SDL_mixer is not safe to drive from two threads at once (the
        music used to be created and started from a timer thread while clicks played sounds - a crash on some PCs)."""
        mb = self._music_bytes
        if mb is None or not self.ok:
            return
        self._music_bytes = None
        try:
            snd = pygame.mixer.Sound(buffer=mb)
            self.music = snd
            self._apply_volume()
            snd.play(loops=-1)
        except Exception:
            pass

    # ------------------------------------------------------------ control
    def _apply_volume(self):
        if not self.ok:
            return
        m = 0 if self.mute else self.master
        if self.music is not None:
            try:
                self.music.set_volume(m * self.music_v * .6)
            except Exception:
                pass

    def set(self, master=None, music=None, sfx=None, mute=None):
        if master is not None:
            self.master = master
        if music is not None:
            self.music_v = music
        if sfx is not None:
            self.sfx_v = sfx
        if mute is not None:
            self.mute = mute
        self._apply_volume()

    def play(self, name, gap=.05):
        if not self.ok or self.mute:
            return
        s = self.sounds.get(name)
        if s is None:
            return
        now = time.monotonic()
        if now - self.last.get(name, 0) < gap:
            return
        self.last[name] = now
        try:
            s.set_volume(self.master * self.sfx_v)
            s.play()
        except Exception:
            pass
