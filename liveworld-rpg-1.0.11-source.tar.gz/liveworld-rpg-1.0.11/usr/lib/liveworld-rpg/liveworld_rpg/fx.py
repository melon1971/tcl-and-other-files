"""Atmosphere and lighting for LiveWorld RPG (0.17).

A quarter-resolution light map is rebuilt every frame and multiplied over the
world: time-of-day colour grading, biome tints, drifting cloud shadows, a soft
vignette and coloured light pools from lanterns, braziers, portals, lava and
spells.  On top of that sit ambient particles (fireflies, pollen, embers, ash,
spores, falling leaves, crystal glints, dungeon dust) and ambient detail.

Everything is procedural and cached, so the package still ships with no image
assets.  The whole pass costs roughly 2-4 ms per frame.
"""
import math, random, pygame
from . import gfx

LS = 4                                  # light map is 1/LS of the screen size

# ---------------------------------------------------------------- colour grade
# (hour, ambient multiply colour).  255 means "untouched"; lower is darker.
_SKY = [            # 0.23: nights are moonlit and readable instead of near-black (0.33: a touch deeper, lamps carry the light)
    (0.0, (188, 198, 236)),
    (4.0, (190, 200, 236)),
    (5.5, (196, 182, 194)),
    (6.5, (244, 214, 190)),
    (8.0, (255, 248, 234)),
    (12.0, (255, 253, 246)),
    (16.0, (255, 246, 228)),
    (17.6, (255, 228, 184)),
    (18.8, (246, 200, 166)),
    (20.0, (222, 208, 226)),
    (21.5, (190, 200, 236)),
    (24.0, (188, 198, 236)),
]
_BIOME_TINT = {
    "Ashen Vale": (246, 236, 222), "Ironwood": (236, 248, 232), "Frostmarch": (236, 244, 255),
    "Storm Coast": (244, 250, 255), "Bloodfen": (236, 244, 220), "Dreadmoor": (232, 222, 246),
    "Sunscar Desert": (255, 240, 214), "Ember Highlands": (255, 226, 206), "Wyrmreach": (230, 238, 255),
    "Shadowlands": (222, 206, 246),
}


def _lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def _mul(a, b):
    return tuple(a[i] * b[i] / 255 for i in range(3))


def sky_color(hour):
    hour %= 24
    for (h0, c0), (h1, c1) in zip(_SKY, _SKY[1:]):
        if h0 <= hour <= h1:
            t = (hour - h0) / max(1e-6, h1 - h0)
            t = t * t * (3 - 2 * t)
            return _lerp(c0, c1, t)
    return _SKY[0][1]


# ------------------------------------------------------------- cached surfaces
_LGLOW = gfx.SurfaceCache(48)      # 0.37.2: memory-capped (High's half-res light map makes large blobs)
def light_blob(r, col):
    """Radial light for the low-res light map (additive). Smooth quadratic falloff."""
    r = max(3, int(r) // 2 * 2)
    col = tuple(min(255, int(c) // 6 * 6) for c in col)
    key = (r, col)
    s = _LGLOW.get(key)
    if s is None:
        s = pygame.Surface((r * 2, r * 2))
        for i in range(r, 0, -1):
            d = i / r
            f = (1 - d * d) ** 2
            pygame.draw.circle(s, (int(col[0] * f), int(col[1] * f), int(col[2] * f)), (r, r), i)
        _LGLOW.put(key, s)
    return s


_SPARK = gfx.SurfaceCache(16)
def spark(r, col):
    """Small full-resolution additive glow used for particles and light-source halos."""
    r = max(1, int(r))
    col = tuple(min(255, max(0, int(c) // 8 * 8)) for c in col)
    key = (r, col)
    s = _SPARK.get(key)
    if s is None:
        R = r * 3
        s = pygame.Surface((R * 2, R * 2))
        for i in range(R, 0, -1):
            f = (1 - i / R) ** 2.2
            pygame.draw.circle(s, tuple(int(c * f) for c in col), (R, R), i)
        pygame.draw.circle(s, tuple(min(255, int(c * 1.0)) for c in col), (R, R), max(1, r // 2))
        _SPARK.put(key, s)
    return s


def _tileable_blobs(N, n, rmin, rmax, seed, lo, hi, blur):
    rnd = random.Random(seed)
    t = pygame.Surface((N, N)); t.fill((hi, hi, hi))
    for _ in range(n):
        x, y = rnd.randrange(N), rnd.randrange(N); r = rnd.randint(rmin, rmax)
        g = rnd.randint(lo, (lo + hi) // 2)
        for ox in (-N, 0, N):
            for oy in (-N, 0, N):
                pygame.draw.circle(t, (g, g, g), (x + ox, y + oy), r)
    small = max(4, N // blur)
    t = pygame.transform.smoothscale(t, (small, small))
    t = pygame.transform.smoothscale(t, (N, N))
    return t


class Atmosphere:
    def __init__(self, LW, LH, ls=LS, pmul=1.0):
        self.LW, self.LH = LW, LH
        self.ls = ls; self.pmul = pmul
        self.glow_cap = .08         # 0.33.1: only a faint warm lantern glow on the ground at night (was .34)
        self.lw, self.lh = LW // ls, LH // ls
        self.light = pygame.Surface((self.lw, self.lh))
        # cloud shadows: 255 = sun, ~196 = under a cloud (in light-map pixels, world anchored)
        self.clouds = _tileable_blobs(256, 26, 14, 34, 77, 150, 255, 10)
        cl = pygame.Surface((256, 256)); cl.fill((255, 255, 255))
        # remap to a narrow range so cloud shade stays subtle
        tmp = self.clouds.copy(); tmp.fill((60, 60, 60), special_flags=pygame.BLEND_RGB_MULT)
        cl.fill((195, 195, 195)); cl.blit(tmp, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
        self.clouds = cl if ls == 4 else pygame.transform.smoothscale(cl, (256 * 4 // ls, 256 * 4 // ls))
        # fog banks: inverted blobs, dimmed, added over the screen (no numpy needed), tiled 512
        fb = _tileable_blobs(512, 40, 30, 80, 91, 0, 255, 12)
        self.fog = pygame.Surface((512, 512)); self.fog.fill((255, 255, 255))
        self.fog.blit(fb, (0, 0), special_flags=pygame.BLEND_RGB_SUB)
        self.fog.fill((62, 64, 70), special_flags=pygame.BLEND_RGB_MULT)
        self.vig = {}
        self.parts = []
        self.last_cam = None
        self.rnd = random.Random(5)
        self.lite = False
        self.hq = False             # 0.37 High: glow redrawn every frame, brighter light-source halos

    # ---------------------------------------------------------- helpers
    def vignette(self, strength):
        q = int(strength * 20)
        v = self.vig.get(q)
        if v is None:
            v = pygame.Surface((self.lw, self.lh)); v.fill((255, 255, 255))
            cx, cy = self.lw / 2, self.lh / 2
            steps = 26
            for i in range(steps):
                k = i / steps
                f = 1 - (1 - k) ** 2 * (q / 20)
                g = int(255 * max(0, min(1, f)))
                rw = self.lw * (1.25 - k * .55); rh = self.lh * (1.35 - k * .6)
                pygame.draw.ellipse(v, (g, g, g), (cx - rw / 2, cy - rh / 2, rw, rh))
            # corners
            v2 = pygame.Surface((self.lw, self.lh)); g0 = int(255 * (1 - q / 20))
            v2.fill((g0, g0, g0)); v2.blit(v, (0, 0))
            v = pygame.transform.smoothscale(pygame.transform.smoothscale(v2, (self.lw // 4, self.lh // 4)), (self.lw, self.lh))
            self.vig[q] = v
        return v

    # ---------------------------------------------------------- state
    def state(self, g):
        snap = g.snap
        tick = snap.get("tick", 0)
        hour = (tick % 960) / 40.0 + ((g.t * 4) % 1) / 40.0
        area = snap.get("area", "")
        inst = bool(snap.get("instance"))
        if inst:
            amb = (224, 216, 228)
        else:
            amb = sky_color(hour)
            amb = _mul(amb, _BIOME_TINT.get(gfx.bz(area), (255, 255, 255)))
        lum = .3 * amb[0] + .59 * amb[1] + .11 * amb[2]
        dark = max(0.0, min(1.0, (252 - lum) / 70))
        if inst: dark = .6
        b = getattr(g, "brightness", 1.0) - 1.0
        if b >= 0: amb = tuple(c + (255 - c) * min(1.0, b * 1.6) for c in amb)
        else: amb = tuple(c * (1 + b * .8) for c in amb)
        return hour, inst, area, amb, dark

    # ---------------------------------------------------------- lights
    def collect_lights(self, g, dark, inst):
        """World-space lights: (x, y, z_px, radius_px, colour, intensity)."""
        p = g.w.player; now = g.t
        L = []
        px, py = p["x"], p["y"]
        # the hero carries a faint lantern so the immediate area always reads
        L.append((px, py, 30, 190 if inst else 150, (255, 226, 180), .62 if inst else .45))
        props = gfx.near_items(g.inst_props if g.in_inst else g.layout.props, px, py, 24)
        for pr in props:
            if abs(pr[0] - px) > 24 or abs(pr[1] - py) > 24: continue
            k = pr[2]
            if k == "lamp":
                fl = 1 + .06 * math.sin(now * 9 + pr[0] * 3) + .04 * math.sin(now * 23 + pr[1])
                L.append((pr[0], pr[1], 70, 120 * fl, (255, 168, 84), .95))
            elif k == "brazier":
                fl = 1 + .1 * math.sin(now * 11 + pr[0]) + .06 * math.sin(now * 27 + pr[1] * 2)
                L.append((pr[0], pr[1], 44, 250 * fl, (255, 150, 70), 1.2))
            elif k == "campfire":
                fl = 1 + .1 * math.sin(now * 12 + pr[0]) + .06 * math.sin(now * 29 + pr[1] * 2)
                L.append((pr[0], pr[1], 30, 190 * fl, (255, 146, 66), 1.05))
            elif k == "portal":
                L.append((pr[0], pr[1], 40, 140 + 10 * math.sin(now * 4), (150, 100, 255), .95))
        if not g.in_inst:
            for t in g.w.towns:
                if abs(t.x - px) < 30 and abs(t.y - py) < 30:
                    L.append((t.x, t.y, 0, 600, (255, 196, 120), .7))
            for b in gfx.near_items(g.buildings, px, py, 24):
                bx, by, spr, anc, bw, bd, kind = b
                if kind in ("house", "tower") and abs(bx - px) < 24 and abs(by - py) < 24:
                    fl = 1 + .05 * math.sin(now * 7 + bx)
                    L.append((bx + bw * .5, by + bd + .2, 10, 105 * fl, (255, 150, 70), .8))
            for d in g.w.dungeons:
                if abs(d.x - px) < 30 and abs(d.y - py) < 30:
                    col = (255, 120, 50) if d.kind in ("raid", "heroic") else (160, 100, 255)
                    L.append((d.x, d.y, 40, 160 + 12 * math.sin(now * 3 + d.x), col, .9))
            for (lx, ly) in g.visible_lava:
                L.append((lx + .5, ly + .5, 0, 70 + 8 * math.sin(now * 2 + lx * 1.7 + ly), (255, 96, 30), .7))
        for l in g.snap.get("loot", []):
            if abs(l["x"] - px) < 20 and abs(l["y"] - py) < 20 and l["rarity"] not in ("Common",):
                L.append((l["x"], l["y"], 10, 50, gfx.RARITY_COLOR.get(l["rarity"], (255, 255, 255)), .6))
        for h in g.snap.get("herbs", []):
            if abs(h["x"] - px) < 18 and abs(h["y"] - py) < 18:
                L.append((h["x"], h["y"], 10, 40, (120, 255, 150), .45))
        for a in g.snap.get("actors", []):
            if a.get("boss"):
                d = g.disp.get(a["id"])
                if d: L.append((d["x"], d["y"], 40, 160, (255, 70, 50), .7))
        # spells light the scene
        for e in g.effects:
            k = (now - e["t0"]) / max(.01, e["dur"])
            if not (0 <= k <= 1): continue
            t = e["type"]; col = e.get("col", (255, 230, 160))
            if t == "bolt":
                ta = g.disp.get(e["to"])
                if not ta: continue
                x = px + (ta["x"] - px) * k; y = py + (ta["y"] - py) * k
                L.append((x, y, 40, 110 if e.get("big") else 80, col, 1.0))
            elif t == "nova":
                L.append((e["x"], e["y"], 0, e["r"] * 40 * (.4 + k), col, 1.1 * (1 - k)))
            elif t in ("heal", "levelup"):
                L.append((px, py, 40, 150, (120, 255, 150) if t == "heal" else (255, 220, 110), 1 - k))
            elif t == "slash":
                ta = g.disp.get(e["to"])
                if ta: L.append((ta["x"], ta["y"], 30, 70, col, .7 * (1 - k)))
        return L

    # ---------------------------------------------------------- main pass
    def apply(self, g, screen):
        hour, inst, area, amb, dark = self.state(g)
        self.hour, self.dark, self.inst, self.area = hour, dark, inst, area
        lm = self.light
        lm.fill(tuple(int(c) for c in amb))
        cam = g.cam
        # 0.33: lights also add a warm glow on top (over-bright), so lamp light reads on the ground at night
        glow_on = dark > .12 and not self.lite
        if glow_on:
            gm = getattr(self, "glowmap", None)
            if gm is None or gm.get_size() != lm.get_size():
                gm = self.glowmap = pygame.Surface(lm.get_size())
            gm.fill((0, 0, 0))
        gbox = None
        # coloured light pools
        if dark > .05:
            for (x, y, z, r, col, inten) in self.collect_lights(g, dark, inst):
                sx, sy = g.to_screen(x, y)
                sy -= z * .35
                rr = r / self.ls
                if sx + r < 0 or sx - r > self.LW or sy + r < 0 or sy - r > self.LH: continue
                k = inten * dark
                c = (col[0] * k, col[1] * k, col[2] * k)
                b = light_blob(rr, c)
                # isometric: light pools are squashed ellipses on the ground
                bw, bh = b.get_size()
                bs = pygame.transform.scale(b, (bw, max(2, int(bh * .62))))
                lm.blit(bs, (sx / self.ls - bw / 2, sy / self.ls - bs.get_height() / 2), special_flags=pygame.BLEND_RGB_ADD)
                if glow_on and r < 400:
                    gr = gm.blit(bs, (sx / self.ls - bw / 2, sy / self.ls - bs.get_height() / 2), special_flags=pygame.BLEND_RGB_ADD)
                    gbox = gr if gbox is None else gbox.union(gr)
        # vignette (stronger at night and underground)
        lm.blit(self.vignette(.05 + dark * .08 + (.03 if inst else 0)), (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        screen.blit(self._upscale(lm), (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        if glow_on and gbox is not None:
            self._gflip = not getattr(self, "_gflip", False)
            gc = getattr(self, "_gcache", None)
            if self._gflip or gc is None or self.hq:
                gbox = gbox.clip(gm.get_rect())
                gc = None
                if gbox.w > 1 and gbox.h > 1:       # only rescale the part of the screen that has lights in it
                    k = int(255 * min(self.glow_cap, dark * .5))
                    sub = gm.subsurface(gbox)
                    sub.fill((k, int(k * .92), int(k * .8)), special_flags=pygame.BLEND_RGB_MULT)
                    gc = (pygame.transform.smoothscale(sub, (gbox.w * self.ls, gbox.h * self.ls)), gbox.x * self.ls, gbox.y * self.ls, cam)
                self._gcache = gc
            if gc is not None:      # on the in-between frame the cached glow is shifted with the camera
                screen.blit(gc[0], (gc[1] - (cam[0] - gc[3][0]), gc[2] - (cam[1] - gc[3][1])), special_flags=pygame.BLEND_RGB_ADD)
        else:
            self._gcache = None
        # halos on the light sources themselves (bloom-ish), only when it is dark enough to matter
        if dark > .2 and not self.lite:
            self.halos(g, screen, dark)

    def _upscale(self, lm):
        """Light map -> screen size into reused surfaces (a fresh full-screen smoothscale cost ~14 ms a frame).
        The light map is soft, so a smooth half-size pass plus a plain 2x stretch looks the same."""
        full = getattr(self, "_full", None)
        if full is None or full.get_size() != (self.LW, self.LH):
            full = self._full = pygame.Surface((self.LW, self.LH))
        half = getattr(self, "_half", None)
        if half is None or half.get_size() != (self.LW // 2, self.LH // 2):
            half = self._half = pygame.Surface((self.LW // 2, self.LH // 2))
        pygame.transform.smoothscale(lm, half.get_size(), half)
        return pygame.transform.scale(half, (self.LW, self.LH), full)

    def halos(self, g, screen, dark):
        p = g.w.player; now = g.t
        props = gfx.near_items(g.inst_props if g.in_inst else g.layout.props, p["x"], p["y"], 22)
        for pr in props:
            if abs(pr[0] - p["x"]) > 22 or abs(pr[1] - p["y"]) > 22: continue
            sx, sy = g.to_screen(pr[0], pr[1])
            if not (-60 < sx < self.LW + 60 and -120 < sy < self.LH + 60): continue
            if pr[2] == "lamp":
                fl = 1 + .08 * math.sin(now * 9 + pr[0] * 3)
                s = spark(int(7 * fl), (int(150 * dark), int(96 * dark), int(40 * dark)))
                screen.blit(s, (sx - s.get_width() // 2, sy - 62 - s.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
            elif pr[2] == "campfire":
                fl = 1 + .12 * math.sin(now * 13 + pr[0])
                s = spark(int(8 * fl), (int(160 * dark), int(86 * dark), int(30 * dark)))
                screen.blit(s, (sx - s.get_width() // 2, sy - 26 - s.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
            elif pr[2] == "brazier":
                fl = 1 + .12 * math.sin(now * 13 + pr[0])
                s = spark(int(9 * fl), (int(170 * dark), int(90 * dark), int(30 * dark)))
                screen.blit(s, (sx - s.get_width() // 2, sy - 40 - s.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
        if not g.in_inst:
            for b in gfx.near_items(g.buildings, p["x"], p["y"], 22):
                bx, by, spr, anc, bw, bd, kind = b
                if kind not in ("house", "tower") or abs(bx - p["x"]) > 22 or abs(by - p["y"]) > 22: continue
                sx, sy = g.to_screen(bx, by)
                # warm lantern points that hang from the eaves: sample bright red/orange pixels once per sprite
                for (lx, ly) in lantern_points(spr):
                    x = sx - anc[0] + lx; y = sy - anc[1] + ly
                    if -20 < x < self.LW + 20 and -20 < y < self.LH + 20:
                        fl = 1 + .1 * math.sin(now * 6 + lx + bx)
                        s = spark(int(4 * fl), (int(140 * dark), int(60 * dark), int(24 * dark)))
                        screen.blit(s, (x - s.get_width() // 2, y - s.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)

    # ---------------------------------------------------------- particles
    def particles(self, g, screen, dt):
        """World-anchored ambient motes chosen by biome and time of day."""
        p = g.w.player; now = g.t
        inst = self.inst; area = gfx.bz(self.area or ""); night = self.dark > .45
        kinds = []
        if inst:
            kinds = [("dust", 26), ("ember", 10)]
        else:
            green = area in ("Greenfields", "Crownlands", "Ironwood", "Storm Coast")
            if area == "Ember Highlands": kinds = [("ember", 46)]
            elif area == "Ashen Vale": kinds = [("ash", 46)]
            elif area in ("Bloodfen", "Dreadmoor"): kinds = [("spore", 34)] + ([("firefly", 16)] if night else [])
            elif area in ("Wyrmreach", "Shadowlands"): kinds = [("glint", 34)]
            elif area == "Frostmarch": kinds = [("flake", 60)]
            elif area == "Sunscar Desert": kinds = [("sand", 36)]
            elif green:
                kinds = [("firefly", 34)] if night else [("pollen", 30), ("leaf", 8 if area == "Ironwood" else 5)]
        want = {k: int(n * self.pmul) for k, n in kinds}
        # cull particles off screen or of the wrong kind
        keep = []
        cnt = {}
        for q in self.parts:
            sx, sy = g.to_screen(q[0], q[1])
            if q[3] not in want or not (-80 < sx < self.LW + 80 and -160 < sy - q[2] < self.LH + 80) or now - q[6] > q[7]:
                continue
            if cnt.get(q[3], 0) >= want[q[3]]: continue
            cnt[q[3]] = cnt.get(q[3], 0) + 1
            keep.append(q)
        self.parts = keep
        rnd = self.rnd
        for k, n in want.items():
            for _ in range(min(3 + int(self.pmul), n - cnt.get(k, 0))):
                # spawn somewhere on screen, in world coordinates
                sx = rnd.uniform(-40, self.LW + 40); sy = rnd.uniform(-20, self.LH + 60)
                wx, wy = g.to_world((sx, sy))
                if k == "ember" and inst:
                    br = [pr for pr in g.inst_props if pr[2] == "brazier" and abs(pr[0] - p["x"]) < 16 and abs(pr[1] - p["y"]) < 16]
                    if not br: continue
                    b = rnd.choice(br); wx, wy = b[0] + rnd.uniform(-.3, .3), b[1] + rnd.uniform(-.3, .3)
                elif gfx.tile_cached(g.layout, int(wx), int(wy))[0] == "void":
                    continue
                z = {"ember": rnd.uniform(40, 60) if inst else rnd.uniform(0, 40), "ash": rnd.uniform(60, 200), "flake": rnd.uniform(80, 240),
                     "leaf": rnd.uniform(90, 220)}.get(k, rnd.uniform(8, 70))
                life = rnd.uniform(4, 9)
                self.parts.append([wx, wy, z, k, rnd.random() * 6.28, rnd.uniform(.6, 1.4), now - (rnd.uniform(0, life * .6) if not self.last_cam else 0), life])
        self.last_cam = g.cam
        for q in self.parts:
            wx, wy, z, k, ph, sp, t0, life = q
            age = (now - t0) / life
            fade = min(1, age * 5, (1 - age) * 4)
            if fade <= 0: continue
            if k == "firefly":
                q[0] += math.sin(now * .7 * sp + ph) * dt * .5; q[1] += math.cos(now * .6 * sp + ph * 1.3) * dt * .5
                q[2] = max(6, z + math.sin(now * 1.3 + ph) * dt * 14)
                pulse = max(0, math.sin(now * 2.2 * sp + ph)) ** 2
                a = fade * (.25 + .75 * pulse)
                self._dot(g, screen, q, 3, (int(190 * a), int(255 * a), int(90 * a)))
            elif k == "pollen":
                q[0] += dt * .25 * sp; q[1] -= dt * .12; q[2] = z + math.sin(now + ph) * dt * 6
                self._dot(g, screen, q, 1, (int(120 * fade), int(116 * fade), int(80 * fade)))
            elif k == "dust":
                q[0] += math.sin(now * .3 + ph) * dt * .15; q[2] = z + dt * 3
                self._dot(g, screen, q, 1, (int(70 * fade), int(64 * fade), int(56 * fade)))
            elif k == "ember":
                q[2] = z + dt * 28 * sp; q[0] += math.sin(now * 2 + ph) * dt * .3
                hot = fade * max(0, 1 - q[2] / 220)
                self._dot(g, screen, q, 2, (int(255 * hot), int(120 * hot), int(30 * hot)))
                if q[2] > 220: q[6] = -99
            elif k == "ash":
                q[2] = z - dt * 14 * sp; q[0] += dt * .4; q[1] += math.sin(now + ph) * dt * .2
                self._flake(g, screen, q, (150, 140, 132), fade, 2)
            elif k == "flake":
                q[2] = z - dt * 26 * sp; q[0] += math.sin(now * .8 + ph) * dt * .5
                self._flake(g, screen, q, (248, 250, 255), fade, 2 if sp > 1 else 1)
            elif k == "leaf":
                q[2] = z - dt * 18 * sp; q[0] += (math.sin(now * 1.5 + ph) + .4) * dt * .9
                self._leaf(g, screen, q, fade, now)
            elif k == "spore":
                q[2] = z + math.sin(now * .9 + ph) * dt * 8 + dt * 2; q[0] += math.cos(now * .5 + ph) * dt * .2
                c = (110, 170, 60) if area == "Bloodfen" else (150, 90, 190)
                self._dot(g, screen, q, 2, tuple(int(v * fade * .8) for v in c))
            elif k == "glint":
                tw = max(0, math.sin(now * 3 * sp + ph)) ** 6
                c = (130, 200, 255) if area == "Wyrmreach" else (190, 110, 255)
                self._dot(g, screen, q, 2, tuple(int(v * fade * tw) for v in c))
            elif k == "sand":
                q[0] += dt * 1.4 * sp; q[1] -= dt * 1.4 * sp; q[2] = max(2, z + math.sin(now * 2 + ph) * dt * 10)
                sx, sy = g.to_screen(q[0], q[1]); sy -= q[2]
                c = tuple(int(v * fade) for v in (120, 100, 70))
                pygame.draw.line(screen, (min(255, 214 + c[0] // 6), min(255, 186 + c[1] // 6), 130), (sx, sy), (sx - 6, sy + 1), 1)
            if q[2] < 0: q[6] = -99

    def _dot(self, g, screen, q, r, col):
        if max(col) < 6: return
        sx, sy = g.to_screen(q[0], q[1]); sy -= q[2]
        s = spark(r, col)
        screen.blit(s, (sx - s.get_width() // 2, sy - s.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)

    def _flake(self, g, screen, q, col, fade, r):
        sx, sy = g.to_screen(q[0], q[1]); sy -= q[2]
        if fade < .3: return
        pygame.draw.circle(screen, col, (int(sx), int(sy)), r)

    def _leaf(self, g, screen, q, fade, now):
        sx, sy = g.to_screen(q[0], q[1]); sy -= q[2]
        if fade < .2: return
        ang = now * 3 * q[5] + q[4]
        c, s = math.cos(ang), math.sin(ang)
        w = 4 * abs(math.cos(now * 2 + q[4])) + 1
        pts = [(sx + c * 4, sy + s * 4 * .6), (sx - s * w * .5, sy + c * w * .3), (sx - c * 4, sy - s * 4 * .6), (sx + s * w * .5, sy - c * w * .3)]
        col = ((196, 132, 52), (170, 168, 60), (110, 150, 50))[int(q[4] * 10) % 3]
        pygame.draw.polygon(screen, col, pts)


# --------------------------------------------------------- lantern sampling
_LANT = {}
def lantern_points(spr):
    """Find the red paper lanterns painted into a building sprite (bright, saturated red/orange
    pixels) and return a few representative points, so they can glow at night."""
    key = spr                         # 0.37.2: the sprite itself, not id(spr) - ids are reused after a sprite is freed
    pts = _LANT.get(key)
    if pts is not None:
        return pts
    pts = []
    w, h = spr.get_size()
    seen = []
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            c = spr.get_at((x, y))
            if c.a > 200 and c.r > 200 and c.g < 110 and c.b < 90 and c.r - c.g > 120:
                if all(abs(x - sx) > 10 or abs(y - sy) > 10 for sx, sy in seen):
                    seen.append((x, y))
    pts = seen[:10]
    if len(_LANT) > 400: _LANT.clear()
    _LANT[key] = pts
    return pts
