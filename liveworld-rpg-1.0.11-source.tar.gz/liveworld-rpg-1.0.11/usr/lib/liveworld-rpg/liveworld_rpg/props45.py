"""0.45: redrawn props at believable sizes - dead trees, tents, barrels, crates and braziers.

Drawn at 4x with the shared gfx helpers (shaded tubes, shaded polygons, soft shadows) and scaled down, so they
match the rest of the hand-painted world.  The old versions were line art (dead trees), flat triangles (tents)
or about a person's height (barrels, crates, braziers).
"""
import math, random
import pygame
from .gfx import shade, _tube, _shp, _bez, _finish


def _shadow(S, cx, cy, w, h, a=90):
    """Soft ground shadow: stacked ellipses on their own layers so the alpha builds up toward the middle."""
    for i in range(6):
        f = 1 - i / 6
        lay = pygame.Surface((int(w * f) + 2, int(h * f) + 2), pygame.SRCALPHA)
        pygame.draw.ellipse(lay, (0, 0, 0, int(a / 5)), lay.get_rect())
        S.blit(lay, (cx - w * f / 2, cy - h * f / 2))


def _light(spr, a=60):
    """A soft dark rim (instead of a hard black outline) so the prop sits on any ground."""
    m = pygame.mask.from_surface(spr, 80)
    sil = m.to_surface(setcolor=(16, 12, 8, a), unsetcolor=(0, 0, 0, 0))
    out = pygame.Surface((spr.get_width() + 2, spr.get_height() + 2), pygame.SRCALPHA)
    for dx, dy in ((1, 2), (2, 1), (0, 1), (1, 0)):
        out.blit(sil, (dx, dy))
    out.blit(spr, (1, 1))
    return out


# ------------------------------------------------------------------ dead tree
def dead_tree(var=0):
    """A gnarled dead tree: a thick tapering trunk with root flare and bark, and branches that fork and thin out."""
    r = random.Random(4100 + var)
    S = pygame.Surface((520, 680), pygame.SRCALPHA); bx, by = 260, 650
    _shadow(S, bx + 14, by - 4, 240, 56, 100)
    bark = shade((96, 80, 66), .86 + (var % 3) * .1)
    lean = r.uniform(-30, 30)
    top = (bx + lean, by - 330)
    trunk = _bez((bx, by - 6), (bx + lean * .2 + r.uniform(-20, 20), by - 170), top, 16)
    # roots first, then the trunk over them
    for sg in (-1, 1):
        for j in range(2):
            ex = bx + sg * (44 + j * 30 + r.uniform(0, 14)); ey = by + 2 + j * 4
            _tube(S, _bez((bx + sg * 12, by - 34), (bx + sg * (30 + j * 14), by - 8), (ex, ey), 6), 26 - j * 8, 8, bark)
    _tube(S, trunk, 62, 26, bark)
    # bark furrows along the trunk
    for i in range(7):
        off = (i - 3) * 6
        pts = [(x + off * (1 - k / 16 * .55) + r.uniform(-1.5, 1.5), y) for k, (x, y) in enumerate(trunk)]
        pygame.draw.lines(S, shade(bark, .5 if i % 2 else .66), False, pts[1:-2], 2)
    # knot hole
    kx, ky = trunk[6]
    pygame.draw.ellipse(S, shade(bark, .4), (kx - 9, ky - 12, 18, 24)); pygame.draw.ellipse(S, (24, 18, 14), (kx - 6, ky - 8, 12, 17))
    # branches: forked tubes that thin out, reaching up and out
    def limb(p, ang, ln, w, depth):
        end = (p[0] + math.cos(ang) * ln, p[1] + math.sin(ang) * ln)
        mid = ((p[0] + end[0]) / 2 + r.uniform(-ln * .15, ln * .15), (p[1] + end[1]) / 2 + r.uniform(-ln * .1, ln * .1))
        pts = _bez(p, mid, end, 8)
        _tube(S, pts, w, max(3, w * .55), bark)
        if depth > 0:
            for da in (-.48, .42) if depth > 1 else (-.5, .1, .55):
                limb(end, ang + da + r.uniform(-.18, .18), ln * r.uniform(.55, .72), max(3, w * .58), depth - 1)
        else:
            for _ in range(2):    # twigs
                a2 = ang + r.uniform(-.8, .8); e2 = (end[0] + math.cos(a2) * 18, end[1] + math.sin(a2) * 18)
                pygame.draw.line(S, shade(bark, .55), end, e2, 3)
    starts = [(9, -2.35), (11, -.8), (13, -2.0), (15, -1.25), (16, -1.75)]
    for idx, a0 in starts[: 4 + var % 2]:
        p = trunk[min(idx, len(trunk) - 1)]
        limb(p, a0 + r.uniform(-.15, .15), r.uniform(90, 130), 22 if idx < 13 else 16, 2)
    # a little hanging moss on some
    if var % 3 == 1:
        for i in range(6):
            x, y = trunk[8 + i % 6][0] + r.uniform(-30, 30), trunk[8 + i % 6][1] + r.uniform(-60, 0)
            pygame.draw.lines(S, (110, 120, 80), False, [(x, y), (x + 2, y + 14), (x - 1, y + 26)], 3)
    spr = _finish(S, .25)
    return _light(spr, 50), (spr.get_width() // 2 + 1, int(by * .25) + 1)


# ------------------------------------------------------------------ tent
def tent(var=0):
    """A canvas A-frame tent seen from the iso camera: two sloping sides, an open front flap, ridge pole and guy ropes."""
    S = pygame.Surface((560, 420), pygame.SRCALPHA); cx, cy = 280, 330
    col = ((176, 60, 50), (62, 102, 170), (196, 170, 104))[var % 3]
    trim = ((230, 196, 120), (230, 220, 190), (150, 110, 60))[var % 3]
    _shadow(S, cx + 30, cy + 10, 420, 120, 110)
    # iso footprint: front edge runs left-down, the tent's length runs up-right
    L = 210; W2 = 92; H = 168
    def P(u, v, z):          # u along the length (0 front-left end .. 1 back), v across (+1 = the side facing the camera), z up (4x px)
        x = cx - 90 + u * L * .9 + v * W2 * .9
        y = cy - u * L * .45 + v * W2 * .45 - z
        return (x, y)
    ridge_f, ridge_b = P(0, 0, H), P(1, 0, H)
    # right (lit) slope and left slope
    right = [P(0, 1, 0), P(1, 1, 0), ridge_b, ridge_f]
    left = [P(0, -1, 0), ridge_f, ridge_b, P(1, -1, 0)]
    rb = P(1.32, 0, 0); pygame.draw.line(S, (190, 180, 150), ridge_b, rb, 2); pygame.draw.line(S, (90, 66, 40), rb, (rb[0], rb[1] - 12), 5)
    _shp(S, left, shade(col, .72), lo=.6, top=1.05, bot=.8)
    _shp(S, right, col, lo=.7, top=1.12, bot=.82)
    # canvas seams and sag folds
    for k in range(1, 4):
        t = k / 4
        a, b = (P(t, 1, 0), P(t, 0, H))
        pygame.draw.line(S, shade(col, .62), a, b, 3); pygame.draw.line(S, shade(col, 1.18), (a[0] - 3, a[1]), (b[0] - 3, b[1]), 2)
    # front gable (faces down-left): dark opening with tied-back flaps
    front = [P(0, 1, 0), P(0, -1, 0), ridge_f]
    _shp(S, front, shade(col, .9), lo=.7)
    door = [P(0, -.55, 0), P(0, .55, 0), P(0, 0, H * .78)]
    pygame.draw.polygon(S, (28, 20, 18), door)
    pygame.draw.polygon(S, (60, 44, 34), [P(0, -.55, 0), P(0, -.1, 0), P(0, 0, H * .7)])           # the lit floor rug inside
    for sg in (-1, 1):                                                                                     # tied flaps
        flap = [P(0, sg * .55, 0), P(0, sg * .95, 0), P(0, sg * .28, H * .64)]
        _shp(S, flap, shade(col, 1.15 if sg > 0 else .85), lo=.7)
        tie = P(0, sg * .62, H * .3); pygame.draw.circle(S, trim, (int(tie[0]), int(tie[1])), 5)
    # hem trim along the bottom and the ridge pole sticking out
    pygame.draw.line(S, trim, P(0, 1, 2), P(1, 1, 2), 5)
    pygame.draw.line(S, shade(trim, .8), P(0, -1, 2), P(1, -1, 2), 4)
    pygame.draw.line(S, (86, 60, 36), P(-.08, 0, H + 6), ridge_b, 7)
    pygame.draw.line(S, (140, 100, 60), P(-.08, 0, H + 8), ridge_b, 2)
    pole = P(-.08, 0, H + 6); pygame.draw.line(S, (86, 60, 36), pole, (pole[0], pole[1] - 40), 6)
    pygame.draw.polygon(S, shade(col, 1.1), [(pole[0], pole[1] - 40), (pole[0] + 34, pole[1] - 32), (pole[0], pole[1] - 22)])
    # guy ropes: from both ends of the ridge, and from the near corners, out to wooden pegs
    for a, b in ((ridge_f, P(-.32, 0, 0)), (P(0, 1, 6), P(-.12, 1.45, 0)), (P(1, 1, 6), P(1.12, 1.45, 0))):
        pygame.draw.line(S, (206, 196, 166), a, b, 2)
        pygame.draw.line(S, (90, 66, 40), b, (b[0], b[1] - 12), 5)
    spr = _finish(S, .25)
    return _light(spr, 45), (int(cx * .25) + 1, int(cy * .25) + 1)


# ------------------------------------------------------------------ barrel / crate / brazier
def barrel(var=0):
    """An oak barrel with bulging staves, iron hoops and a lid - about knee-to-waist height next to a person."""
    S = pygame.Surface((200, 260), pygame.SRCALPHA); bx, by = 100, 240
    _shadow(S, bx + 10, by - 4, 150, 40, 110)
    wood = shade((150, 100, 58), .9 + (var % 3) * .07)
    h = 176; rw = 62; bulge = 10
    def edge(t, side):
        return (bx + side * (rw + bulge * math.sin(math.pi * t)), by - 12 - h * t)
    body = [edge(t / 12, -1) for t in range(13)] + [edge(t / 12, 1) for t in range(12, -1, -1)]
    _shp(S, body, wood, lo=.5, hi=1.12, top=1.05, bot=.8)
    for k in range(1, 9):                                   # staves
        f = k / 9 * 2 - 1
        pts = [(bx + f * (rw + bulge * math.sin(math.pi * t / 10)) * .98, by - 12 - h * t / 10) for t in range(11)]
        pygame.draw.lines(S, shade(wood, .55), False, pts, 2)
        if k % 3 == 1: pygame.draw.lines(S, shade(wood, 1.2), False, [(x + 3, y) for x, y in pts], 1)
    for t in (.1, .3, .7, .9):                              # hoops
        y = by - 12 - h * t; wd = rw + bulge * math.sin(math.pi * t)
        pygame.draw.ellipse(S, (44, 42, 44), (bx - wd - 2, y - 7, wd * 2 + 4, 16), 6)
        pygame.draw.arc(S, (150, 150, 160), (bx - wd, y - 8, wd * 2, 16), 3.5, 5.2, 3)
    top = (bx - rw, by - 12 - h - 22, rw * 2, 44)           # lid
    pygame.draw.ellipse(S, shade(wood, .55), top)
    pygame.draw.ellipse(S, shade(wood, 1.12), (top[0] + 6, top[1] + 4, top[2] - 12, top[3] - 10))
    for k in range(-2, 3):
        pygame.draw.line(S, shade(wood, .8), (bx + k * 20, top[1] + 8), (bx + k * 20, top[1] + top[3] - 8), 2)
    pygame.draw.ellipse(S, (44, 42, 44), top, 5)
    spr = _finish(S, .25)
    return _light(spr, 50), (spr.get_width() // 2 + 1, int(by * .25) + 1)


def crate(var=0):
    """A nailed plank crate with corner battens, about knee height."""
    S = pygame.Surface((240, 240), pygame.SRCALPHA); bx, by = 120, 222
    _shadow(S, bx + 10, by - 6, 190, 50, 110)
    c = shade((176, 132, 80), .9 + (var % 3) * .06)
    s = 64; hgt = 112
    def P(u, v, z): return (bx + (u - v) * s, by + (u + v) * s * .5 - s - z)
    Lf = [P(0, 1, 0), P(1, 1, 0), P(1, 1, hgt), P(0, 1, hgt)]
    Rf = [P(1, 1, 0), P(1, 0, 0), P(1, 0, hgt), P(1, 1, hgt)]
    T = [P(0, 0, hgt), P(1, 0, hgt), P(1, 1, hgt), P(0, 1, hgt)]
    _shp(S, Lf, shade(c, .74), lo=.75, top=1.04, bot=.84); _shp(S, Rf, c, lo=.78, top=1.06, bot=.86); _shp(S, T, shade(c, 1.18), lo=.9)
    for face, base in ((Lf, shade(c, .74)), (Rf, c)):
        for k in (1, 2):                                    # plank seams
            t = k / 3
            a = (face[0][0] + (face[3][0] - face[0][0]) * t, face[0][1] + (face[3][1] - face[0][1]) * t)
            b = (face[1][0] + (face[2][0] - face[1][0]) * t, face[1][1] + (face[2][1] - face[1][1]) * t)
            pygame.draw.line(S, shade(base, .5), a, b, 3)
        for i0, i1 in ((0, 3), (1, 2)):                      # corner battens
            pygame.draw.line(S, shade(base, .62), face[i0], face[i1], 10); pygame.draw.line(S, shade(base, 1.15), (face[i0][0] + 2, face[i0][1]), (face[i1][0] + 2, face[i1][1]), 2)
        pygame.draw.line(S, shade(base, .58), face[0], face[2], 8)                                   # diagonal brace
        for p in face:
            pygame.draw.circle(S, (60, 56, 52), (int(p[0]), int(p[1])), 3)
    for k in (1, 2):
        t = k / 3; pygame.draw.line(S, shade(c, .85), (T[0][0] + (T[3][0] - T[0][0]) * t, T[0][1] + (T[3][1] - T[0][1]) * t),
                                     (T[1][0] + (T[2][0] - T[1][0]) * t, T[1][1] + (T[2][1] - T[1][1]) * t), 3)
    spr = _finish(S, .25)
    return _light(spr, 50), (spr.get_width() // 2 + 1, int(by * .25) + 1)


def brazier(var=0):
    """A standing iron fire basket on three legs, about chest height, with a live flame."""
    S = pygame.Surface((240, 420), pygame.SRCALPHA); bx, by = 120, 400
    _shadow(S, bx + 10, by - 4, 150, 40, 110)
    iron = (70, 64, 62)
    glow = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    for rr, aa in ((96, 14), (70, 22), (44, 34)): pygame.draw.circle(glow, (255, 150, 50, aa), (bx, by - 270), rr)
    S.blit(glow, (0, 0))
    for sg, dx in ((-1, -46), (1, 46), (0, 6)):             # three legs
        _tube(S, [(bx + sg * 10, by - 210), (bx + dx * .6, by - 110), (bx + dx, by - 4)], 12, 9, iron)
    pygame.draw.ellipse(S, shade(iron, .9), (bx - 40, by - 140, 80, 24), 6)    # leg ring
    bowl = [(bx - 64, by - 262), (bx + 64, by - 262), (bx + 40, by - 206), (bx - 40, by - 206)]
    _shp(S, bowl, shade(iron, 1.25), True, lo=.5)
    for k in range(1, 6):                                   # grill bars
        x = bx - 60 + k * 20
        pygame.draw.line(S, shade(iron, .55), (x, by - 262), (x * .62 + bx * .38, by - 206), 3)
    pygame.draw.ellipse(S, (40, 26, 18), (bx - 64, by - 276, 128, 30))
    pygame.draw.ellipse(S, (210, 90, 30), (bx - 54, by - 272, 108, 22))
    for (dx, hh, col) in ((-26, 70, (232, 84, 26)), (4, 108, (250, 132, 36)), (28, 64, (232, 84, 26))):
        pygame.draw.polygon(S, col, [(bx + dx - 22, by - 266), (bx + dx - 6, by - 266 - hh * .6), (bx + dx + 2, by - 266 - hh), (bx + dx + 10, by - 266 - hh * .5), (bx + dx + 24, by - 266)])
    pygame.draw.polygon(S, (255, 228, 136), [(bx - 12, by - 266), (bx, by - 266 - 64), (bx + 14, by - 266)])
    spr = _finish(S, .25)
    return _light(spr, 40), (spr.get_width() // 2 + 1, int(by * .25) + 1)


# ------------------------------------------------------------------ bushes
def bush(var=0, dry=False):
    """A full leafy shrub (or, dry=True, a twiggy dry bush with a few brown leaves), knee to waist high."""
    from .gfx import _canopy
    r = random.Random(5200 + var + (50 if dry else 0))
    S = pygame.Surface((360, 280), pygame.SRCALPHA); bx, by = 180, 252
    _shadow(S, bx + 12, by - 4, 250, 60, 110)
    if dry:
        twig = (110, 86, 60)
        for i in range(14):                         # fan of twigs
            a = -math.pi / 2 + r.uniform(-1.1, 1.1); ln = r.uniform(70, 150)
            p0 = (bx + r.uniform(-20, 20), by - 6); p1 = (p0[0] + math.cos(a) * ln, p0[1] + math.sin(a) * ln * .9)
            _tube(S, _bez(p0, ((p0[0] + p1[0]) / 2 + r.uniform(-14, 14), (p0[1] + p1[1]) / 2), p1, 6), 9, 3, twig)
            for k in range(3):
                t = r.uniform(.4, 1.0); q = (p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t)
                c = ((150, 112, 60), (176, 132, 70), (120, 90, 52))[k % 3]
                pygame.draw.ellipse(S, c, (q[0] - 7, q[1] - 4, 14, 8))
    else:
        base = shade(((62, 124, 54), (74, 130, 52), (56, 112, 66))[var % 3], .95 + r.random() * .1)
        cl = [(bx - 62, by - 64, 60), (bx + 60, by - 66, 58), (bx, by - 110, 70), (bx - 20, by - 60, 60), (bx + 24, by - 58, 60)]
        _canopy(S, bx, by - 80, 132, 82, base, r, 1.0, (16, 11), cl)
        if var % 3 == 1:                            # berries / small flowers on some bushes
            for i in range(12):
                q = (bx + r.uniform(-110, 110), by - r.uniform(40, 150))
                pygame.draw.circle(S, (196, 40, 52) if var % 2 else (240, 230, 240), (int(q[0]), int(q[1])), 5)
                pygame.draw.circle(S, (255, 200, 200), (int(q[0] - 1), int(q[1] - 2)), 2)
    spr = _finish(S, .25)
    return _light(spr, 40), (spr.get_width() // 2 + 1, int(by * .25) + 1)
