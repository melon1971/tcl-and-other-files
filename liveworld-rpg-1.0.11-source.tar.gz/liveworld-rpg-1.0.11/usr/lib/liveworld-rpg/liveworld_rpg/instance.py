"""Walkable dungeon instances with boss mechanics.

An instance is a small map that lives in a reserved strip of the world grid
(y >= WORLD_H).  The engine teleports the player in, spawns packs and bosses
as ordinary Actor objects (kind "imob") and AI party members (kind "ially"),
and runs this module's tick() every simulation step (0.25s).

Bosses use *mechanics* the player has to answer:
  fire      Rain of Fire     - red circles: move out before they burst
  interrupt Shadow Volley    - stun/charge the boss during its cast bar
  adds      Call of Legion   - boss is immune until its adds are dead
  mark      Void Mark        - a bomb on YOU: run away from your party
  breath    Dragon Breath    - cone: leave it or break line of sight on a pillar
  inferno   Inferno          - the room ignites: stand in the safe circle
  buster    Crushing Blow    - tank buster: use a defensive skill (if you tank)
  pulse     Withering Aura   - party-wide damage: heal (if you heal)
  enrage    (heroic)         - kill it before the timer runs out
"""
import math, random, heapq

TPS = 4
INST_X0 = 4
ROOM = 21          # 0.41: rooms ~60% wider so a 4- or 12-strong party isn't packed shoulder to shoulder
STEP = 30
CORR = 2           # corridor half-width: 5 tiles wide (was 3)
RS = ROOM / 13     # scale of room-relative distances vs. the old 13-tile rooms
SNAKE = [(0, 0), (1, 0), (2, 0), (2, 1), (1, 1), (0, 1), (0, 2), (1, 2), (2, 2)]
PLAN = {"dungeon": ["start", "trash", "trash", "boss", "trash", "final"],
        "raid": ["start", "trash", "boss", "trash", "boss", "trash", "final"],
        "heroic": ["start", "trash", "boss", "trash", "boss", "trash", "boss", "trash", "final"]}
# 0.19: a clean 4 (dungeon) / 12 (raid, heroic) player ladder (you count as one of the slots)
PARTY = {"dungeon": {"Tank": 1, "Healer": 1, "DPS": 2},
         "raid": {"Tank": 2, "Healer": 3, "DPS": 7},
         "heroic": {"Tank": 2, "Healer": 3, "DPS": 7}}
# 0.41: harder - tougher, harder-hitting trash in bigger packs, longer boss fights, more fire, allies interrupt less often
DIFF = {"dungeon": dict(trash_hp=5.0, boss_hp=(45, 80), dmg=3.0, fire=3, fr=.32, interrupt_ally=.30, pack=(6, 8)),
        "raid": dict(trash_hp=7.0, boss_hp=(65, 95, 140), dmg=4.2, fire=4, fr=.40, interrupt_ally=.15, pack=(8, 11)),
        "heroic": dict(trash_hp=9.5, boss_hp=(200, 280, 360, 500), dmg=6.3, fire=5, fr=.50, interrupt_ally=0.0, pack=(10, 13))}

MECH_NAMES = {"fire": "Rain of Fire", "interrupt": "Shadow Volley", "adds": "Call of the Legion", "mark": "Void Mark",
              "breath": "Dragon Breath", "inferno": "Inferno", "buster": "Crushing Blow", "pulse": "Withering Aura"}
MECH_HELP = {"fire": "Step out of the red circles.", "interrupt": "Stun or charge the boss to interrupt the cast.",
             "adds": "Kill the adds - the boss is immune while they live.", "mark": "Void Mark: run away from your party!",
             "breath": "Leave the cone, or hide behind a pillar.", "inferno": "Run into the safe circle!",
             "buster": "Tank buster: use a defensive skill (7-0).", "pulse": "Party damage: heal up."}
INTERVAL = {"fire": 11, "interrupt": 18, "mark": 24, "breath": 20, "inferno": 32, "buster": 15, "pulse": 10}
ADD_THRESH = {"dungeon": (.7, .35), "raid": (.75, .5, .25), "heroic": (.8, .6, .4, .2)}

FIRST = ["Grim", "Vorak", "Skarn", "Maldrek", "Thessa", "Ulgar", "Morwen", "Drakos", "Hexa", "Brokk", "Nyx", "Karzul", "Isolde", "Varn"]
TITLE = ["the Devourer", "the Unyielding", "Doomcaller", "the Hollow", "Bonegrinder", "the Ashen", "Soulwarden", "the Fallen",
         "Stormbringer", "the Pale", "Gravetouched", "the Ravenous", "Emberheart", "the Cursed"]
BOSS_LOOK = ["Dark Knight", "Orc", "Ogre", "Demon", "Troll", "Dragonkin", "Wraith", "Frost Giant", "Skeleton", "Cultist", "Ancient Treant", "Lava Beast"]
# 0.22: boss-only monsters.  Every dungeon, raid and heroic boss has its own sprite (see gfx.MONSTER_SPEC).
DUNGEON_BOSS_LOOKS = ["Stone Warden", "Broodmother", "Lich Kinglet", "Frost Tyrant", "Swamp Hydra", "Dread Captain",
                      "Demon Prince", "Sand Colossus", "Ember Dragon", "Wyrm Matriarch", "Shadow Lord", "Ancient Guardian"]
UNIQUE_BOSS_LOOKS = set(DUNGEON_BOSS_LOOKS) | {"Titan of Ash", "Frostwyrm Overlord", "Dread Legion General", "Sunscar Colossus",
                      "Ember Dragon Emperor", "Void Seraph", "Malachar, the Void Sovereign", "Ashmaw the Devourer",
                      "Queen Veyra of the Hollow Choir", "Warden Kaldris, Voidforged"}
ALLY_NAMES = ["Brann", "Lyra", "Gorrik", "Sela", "Thane", "Mira", "Dorn", "Ayla", "Kest", "Rhea", "Torv", "Ildra", "Bael"]
ALLY_CLASSES = {"Tank": ["Warrior", "Paladin", "Druid", "Juggernaut"], "Healer": ["Cleric", "Druid", "Shaman", "Paladin"],
                "DPS": ["Mage", "Ranger", "Rogue", "Warrior", "Shaman", "Mage", "Berserker", "Warlock", "Monk"]}
RANGED = {"Mage", "Ranger", "Cleric", "Shaman", "Warlock"}
FLOOR_TINT = {"Greenfields": (84, 88, 76), "Ashen Vale": (96, 78, 70), "Ironwood": (76, 84, 70), "Frostmarch": (92, 100, 118),
              "Storm Coast": (74, 86, 98), "Bloodfen": (86, 78, 72), "Crownlands": (96, 90, 82), "Dreadmoor": (70, 66, 84),
              "Sunscar Desert": (118, 100, 74), "Ember Highlands": (112, 70, 58), "Wyrmreach": (96, 76, 92), "Shadowlands": (62, 56, 84)}

DUNGEON_BOSS_REST = 15       # 0.44: dungeons rest only after a boss fight, and only briefly
REST_SECONDS = 60          # 0.24: after every cleared room the party recovers for a minute before the tank moves on
PORTAL_COOLDOWN = 10       # seconds between "open exit portal" casts

ACTIVE = None   # the instance the client should render (set by the engine)


def tile_info_for(x, y):
    """Used by gfx.tile_info for the reserved strip."""
    inst = ACTIVE
    if inst is None:
        return "void", (10, 10, 14)
    k = inst.floor.get((x, y))
    if k is None:
        if (x, y) in inst.pillars: k = "arena" if getattr(inst, "is_arena", False) else "room"     # 0.45: floor under the cover (drawn as stone)
        else: return "void", (10, 10, 14)
    c = inst.tint
    h = ((x * 73856093) ^ (y * 19349663)) & 255
    f = .86 + h / 255 * .22
    if k == "arena":
        r = (c[0] * f * 1.12, c[1] * f * 1.12, c[2] * f * 1.12)
    else:
        r = (c[0] * f, c[1] * f, c[2] * f)
    r = (r[0] * 1.18, r[1] * 1.18, r[2] * 1.18)     # 0.23: lighter flagstones
    return "dfloor", (int(min(255, r[0])), int(min(255, r[1])), int(min(255, r[2])))


def _dist(ax, ay, bx, by):
    return math.hypot(ax - bx, ay - by)


class Instance:
    rest_until = 0      # tick at which the post-fight rest ends (0 = no rest)
    rest_total = 0
    portal_cd = 0

    def __init__(self, w, d):
        from .engine import Actor, WORLD_H, ZONE_MONSTERS
        self.Actor = Actor
        self.w = w; self.d = d
        self.kind = d.kind if d.kind in PLAN else "dungeon"
        self.level = d.level
        self.rng = random.Random(d.id * 7919 + 13)
        self.fx = random.Random()
        self.diff = DIFF[self.kind]
        from .engine import bz
        self.tint = FLOOR_TINT.get(bz(d.area), (80, 78, 88))
        self.species = [m for m in ZONE_MONSTERS.get(d.area, ["Skeleton", "Ghoul"]) if m != "Ancient Treant"] or ["Skeleton"]
        self.floor = {}; self.walls = set(); self.pillars = set(); self.props = []
        self.rooms = []; self.actors = {}; self.hazards = []; self.nid = 900000
        self.hz = 1
        self.mark = None; self.wipes = 0; self.done = False; self.portals = []
        self.ally_deaths = 0; self.player_deaths = 0; self.stats = {"interrupts": 0, "mark_clean": 0, "fire_dodged": 0}
        self.return_pos = (d.x, d.y + 3.0)
        self.t0 = w.tick
        self.boss_ids = []; self.allies = []; self.fxq = []; self._paths = {}
        self.hint = ""; self.hint_until = 0
        self._build(WORLD_H)
        self._spawn()

    # ------------------------------------------------------------- layout
    def _build(self, WORLD_H):
        oy = WORLD_H + 3
        plan = PLAN[self.kind]
        pos = SNAKE[:len(plan)]
        centers = []
        for i, (col, row) in enumerate(pos):
            x0 = INST_X0 + col * STEP; y0 = oy + row * STEP
            typ = plan[i]
            icx, icy = x0 + ROOM // 2, y0 + ROOM // 2
            self.rooms.append({"i": i, "type": typ, "x0": x0, "y0": y0, "cx": icx + .5, "cy": icy + .5, "icx": icx, "icy": icy,
                               "mobs": [], "pulled": False, "cleared": typ == "start", "boss": None, "r": 6.5 * RS})
            centers.append((icx, icy))
            for tx in range(x0, x0 + ROOM):
                for ty in range(y0, y0 + ROOM):
                    if typ in ("boss", "final"):
                        if _dist(tx + .5, ty + .5, icx + .5, icy + .5) <= ROOM / 2 + .1:
                            self.floor[(tx, ty)] = "arena"
                    elif typ == "start":
                        if abs(tx - icx) <= 6 and abs(ty - icy) <= 6:
                            self.floor[(tx, ty)] = "floor"
                    else:
                        self.floor[(tx, ty)] = "floor"
        for (ax, ay), (bx, by) in zip(centers, centers[1:]):
            if ax == bx:
                for ty in range(min(ay, by), max(ay, by) + 1):
                    for dx in range(-CORR, CORR + 1): self.floor.setdefault((ax + dx, ty), "floor")
            else:
                for tx in range(min(ax, bx), max(ax, bx) + 1):
                    for dy in range(-CORR, CORR + 1): self.floor.setdefault((tx, ay + dy), "floor")
        # pillars: the boss rooms get four big ones (line-of-sight cover), packs rooms two decorative ones
        for r in self.rooms:
            if r["type"] in ("boss", "final"):
                for ox, oy2 in ((-6, -6), (5, -6), (-6, 5), (5, 5)):
                    for dx in (0, 1):
                        for dy in (0, 1):
                            t = (r["icx"] + ox + dx, r["icy"] + oy2 + dy)
                            if t in self.floor: self.pillars.add(t)
            elif r["type"] == "trash":
                for ox, oy2 in ((-6, -6), (6, 6), (6, -6), (-6, 6)):
                    self.pillars.add((r["icx"] + ox, r["icy"] + oy2))
        for t in self.pillars: self.floor.pop(t, None)
        for (x, y) in list(self.floor):
            pass
        for (x, y) in list(self.floor):
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    n = (x + dx, y + dy)
                    if n not in self.floor: self.walls.add(n)
        for r in self.rooms:
            if r["type"] != "start":
                for ox, oy2 in ((-8.6, -8.6), (8.6, -8.6), (-8.6, 8.6), (8.6, 8.6)):
                    p = (r["cx"] + ox, r["cy"] + oy2)
                    if (int(p[0]), int(p[1])) in self.floor: self.props.append((p[0], p[1], "brazier", 0))
        s = self.rooms[0]
        self.spawn = (s["cx"], s["cy"] + 1.0)
        self.portals = [(s["cx"], s["cy"] - 2.0)]
        self.props.append((self.portals[0][0], self.portals[0][1], "portal", 0))
        for dx in (-3.2, 3.2):
            self.props.append((s["cx"] + dx, s["cy"] - 3.4, "brazier", 0))

    def blocked_los(self, x0, y0, x1, y1):
        n = int(_dist(x0, y0, x1, y1) / .35) + 1
        for i in range(1, n):
            t = i / n
            if (int(x0 + (x1 - x0) * t), int(y0 + (y1 - y0) * t)) in self.pillars:
                return True
        return False

    # ------------------------------------------------------------- spawn
    def _new_id(self):
        self.nid += 1
        return self.nid

    def _mk(self, name, level, x, y, hp, kind="imob", role="mob", faction="Monster"):
        a = self.Actor(self._new_id(), name, faction, level, x, y, int(hp), int(hp), kind, role, "idle", -1, "Dungeon")
        a.home_xy = (x, y); a.atk_tick = -99; a.dead_tick = 0
        self.actors[a.id] = a
        return a

    def _mob_hp(self):
        return (45 + self.level * 8) * self.diff["trash_hp"]

    def _spawn(self):
        bosses = [r for r in self.rooms if r["type"] in ("boss", "final")]
        mechs = self._pick_mechs(len(bosses))
        bi = 0
        for r in self.rooms:
            if r["type"] == "trash":
                n = self.rng.randint(*self.diff["pack"])
                for k in range(n):
                    ang = self.rng.random() * math.tau; rad = self.rng.uniform(1.5, 6.5)
                    sp = self.species[k % len(self.species)]
                    a = self._mk(f"{sp} #{self.nid + 1}", self.level + self.rng.randint(0, 1), r["cx"] + math.cos(ang) * rad, r["cy"] + math.sin(ang) * rad, self._mob_hp())
                    a.room = r["i"]; a.look = sp; a.dmgm = self.diff["dmg"]
                    r["mobs"].append(a.id)
            elif r["type"] in ("boss", "final"):
                final = r["type"] == "final"
                hpm = self.diff["boss_hp"][-1] if final else self.diff["boss_hp"][min(bi, len(self.diff["boss_hp"]) - 2)]
                name, look = self._boss_name(bi, final)
                b = self._mk(name, self.level + (1 if final else 0), r["cx"], r["cy"] - 1.5, (45 + self.level * 8) * hpm, role="boss")
                b.room = r["i"]; b.look = look; b.dmgm = self.diff["dmg"] * 2.4; b.scale = 1.6 if final else 1.35
                b.mech = mechs[bi]; b.next = {m: 0 for m in b.mech}
                b.cast = None; b.adds_done = set(); b.enraged = False; b.final = final; b.pull_tick = 0; b.nextatk = 0
                b.idx = bi
                r["boss"] = b.id; self.boss_ids.append(b.id); r["mobs"].append(b.id)
                bi += 1
        self._spawn_allies()

    def _pick_mechs(self, n):
        rng = self.rng
        if self.kind == "heroic":
            return [["fire", "adds", "pulse"], ["interrupt", "breath", "mark"], ["buster", "inferno", "adds", "fire"],
                    ["mark", "interrupt", "breath", "inferno", "adds", "pulse"]][:n]
        pool_a = ["fire", "interrupt", "adds", "pulse", "breath", "buster"]
        pool_b = ["fire", "interrupt", "adds", "mark", "breath", "buster", "inferno"]
        out = []
        for i in range(n):
            last = i == n - 1
            k = {"dungeon": (1, 3), "raid": (2, 4)}[self.kind][1 if last else 0]
            if self.kind == "dungeon" and not last: k = 1
            pool = pool_b if (last or self.kind == "raid") else pool_a
            out.append(rng.sample(pool, min(k, len(pool))))
        return out

    def _boss_name(self, i, final):
        if self.kind == "heroic":
            nm = ["Ashmaw the Devourer", "Queen Veyra of the Hollow Choir", "Warden Kaldris, Voidforged", "Malachar, the Void Sovereign"][i]
            return nm, nm
        base = self.d.boss.replace(" Prime", "")
        if final and base in UNIQUE_BOSS_LOOKS:
            return self.d.boss, base                      # the dungeon's or raid's own named boss
        if self.kind == "raid" and final:
            return self.d.boss, self.rng.choice(BOSS_LOOK)
        return f"{self.rng.choice(FIRST)} {self.rng.choice(TITLE)}", self.rng.choice(BOSS_LOOK + DUNGEON_BOSS_LOOKS)

    def _spawn_allies(self):
        w = self.w; need = dict(PARTY[self.kind])
        pr = w.spec_role()
        if pr in need: need[pr] -= 1
        names = self.rng.sample(ALLY_NAMES, len(ALLY_NAMES))
        mx = w._effective_maxhp(); i = 0
        # 0.44: companions from your party take the place of AI allies - the group stays the same size
        plan = []
        for nm_, cls_ in w.party_in_instance():
            role_ = next((r_ for r_ in ("Tank", "Healer") if cls_ in ALLY_CLASSES[r_] and cls_ not in ("Paladin", "Druid") and need.get(r_, 0) > 0), None)
            if role_ is None:
                role_ = next((r_ for r_ in ("DPS", "Healer", "Tank") if need.get(r_, 0) > 0), None)
            if role_ is None: continue
            need[role_] -= 1; plan.append((role_, cls_, nm_))
        for role in ("Tank", "Healer", "DPS"):
            for _ in range(max(0, need.get(role, 0))):
                plan.append((role, self.rng.choice(ALLY_CLASSES[role]), None))
        plan.sort(key=lambda t: ("Tank", "Healer", "DPS").index(t[0]))
        for role, cls, pname in plan:
            if True:
                hp = mx * (1.7 if role == "Tank" else 1.0)
                # 0.36.1: rows of four - rows of three put the last raid members outside the 9x9 start room, inside the wall
                ax, ay = self.spawn[0] + (i % 4) - 1, self.spawn[1] + 1 + i // 4
                if (int(ax), int(ay)) not in self.floor: ax, ay = self.spawn
                a = self._mk(pname or names[i % len(names)], w.player["level"], ax, ay, hp,
                             kind="ially", role=cls, faction=w.player["faction"])
                a.rrole = role; a.cls = cls; a.dead = False; a.nextact = 0; a.slot = i
                a.atk_tick = -99; a.dead_tick = 0; a.stuck = 0; a.lastpos = (a.x, a.y)
                a.ranged = cls in RANGED or role == "Healer"
                self.allies.append(a); i += 1
        # the first Tank (ally) is the main tank unless the player tanks
        self.mt = None if pr == "Tank" else next((a for a in self.allies if a.rrole == "Tank"), None)

    # ------------------------------------------------------------- helpers
    def alive_allies(self):
        return [a for a in self.allies if not a.dead]

    def boss_actor(self):
        for r in self.rooms:
            if r["boss"] and r["pulled"]:
                b = self.actors[r["boss"]]
                if b.hp > 0: return b
        return None

    def _say(self, msg, hint=None):
        self.w.events.append(msg)
        if hint:
            self.hint = hint; self.hint_until = self.w.tick + 14


    def current_room(self):
        p = self.w.player
        best = None
        for r in self.rooms:
            if _dist(p["x"], p["y"], r["cx"], r["cy"]) <= 9 * RS and (best is None or _dist(p["x"], p["y"], r["cx"], r["cy"]) < _dist(p["x"], p["y"], best["cx"], best["cy"])):
                best = r
        return best

    def _target_for(self, m):
        """Threat: a living tank (you or the AI tank) holds almost everything; a few mobs peel onto healers/DPS until taunted back."""
        w = self.w
        pl_tank = w.spec_role() == "Tank"
        al = self.alive_allies()
        roll = self.fx.random()
        if pl_tank:
            if roll < .85 or not al: return "player"
            return self.fx.choice(al)
        tanks = [a for a in al if a.rrole == "Tank"]
        if tanks and roll < .85: return self.mt if (self.mt and not self.mt.dead) else self.fx.choice(tanks)
        if roll < .93 or not al: return "player"
        return self.fx.choice(al)

    # ------------------------------------------------------------- damage
    def hit_ally(self, a, raw, true=False):
        if a.dead: return
        if not true and a.rrole == "Tank": raw *= .55
        if not true and getattr(a, "wall_until", 0) > self.w.tick: raw *= .5       # 0.44.9: Shield Wall
        if self.kind == "heroic": raw *= 1.2
        a.hp -= int(raw)
        if a.hp <= 0:
            a.hp = 0; a.dead = True; self.ally_deaths += 1; a.dead_tick = self.w.tick
            a.state = "dead"
            self._say(f"{a.name} the {a.cls} has fallen!")

    def heal_ally(self, a, amount):
        if a.dead: return
        a.hp = min(a.maxhp, a.hp + int(amount))

    def heal_allies(self, amount_frac, boost=1.0):
        """Called when the player casts a heal: the most wounded ally is healed too."""
        al = [a for a in self.alive_allies() if a.hp < a.maxhp]
        if not al: return
        t = min(al, key=lambda a: a.hp / a.maxhp)
        self.heal_ally(t, t.maxhp * amount_frac * boost)

    def pulled_by(self, t):
        r = self.rooms[t.room] if hasattr(t, "room") else None
        if r is not None and not r["pulled"] and not r["cleared"]:
            self._pull(r)

    def near_portal(self):
        p = self.w.player
        return any(_dist(p["x"], p["y"], x, y) <= 3.2 for (x, y) in self.portals)

    def open_portal(self):
        """Conjure an exit portal beside the player (out of combat, short cooldown).  Click it or press F to leave."""
        w = self.w; p = w.player; now = w.tick
        if self.near_portal():
            return "A portal is right beside you - click it or press F to leave."
        if now - w.last_combat_tick < 20:
            return "You can't open a portal while in combat."
        if now < self.portal_cd:
            return f"The exit portal is recharging ({(self.portal_cd - now + TPS - 1) // TPS}s)."
        spot = None
        for ox, oy in ((1.7, 0), (0, 1.7), (-1.7, 0), (0, -1.7), (1.2, 1.2), (-1.2, -1.2), (0, 0)):
            x, y = p["x"] + ox, p["y"] + oy
            if self.floor.get((int(x), int(y))) is not None:
                spot = (x, y); break
        if spot is None:
            return "There is no room to open a portal here."
        self.portal_cd = now + PORTAL_COOLDOWN * TPS
        self.portals.append(spot)
        self.props.append((spot[0], spot[1], "portal", 0))
        self._say("An exit portal shimmers open beside you. Click it or press F to leave.", "Exit portal open")
        return "An exit portal opens beside you. Click it or press F to leave."

    def begin_rest(self, label, secs=REST_SECONDS):
        now = self.w.tick
        self.rest_total = secs * TPS
        self.rest_until = now + self.rest_total
        self._say(f"{label} cleared. The party rests for {secs} seconds: heal up, pick up loot, prepare. Press N to move on early.",
                  f"Rest {secs}s - heal and loot")

    def ready(self):
        """Skip the remaining rest (key N / the Ready button)."""
        now = self.w.tick
        if now >= self.rest_until:
            return "The party is already ready."
        self.rest_until = now
        return "You signal the party to move on."

    def rest_left(self):
        return max(0, (self.rest_until - self.w.tick + TPS - 1) // TPS) if self.rest_until > self.w.tick else 0

    def pre_hit(self, t):
        """False when the player cannot damage t right now (boss immune to damage while its adds live)."""
        if t.kind != "imob": return True
        if t.role == "boss" and self.boss_immune(t):
            self._say(f"{t.name} is immune while its adds live - kill them!", "Kill the adds first!")
            return False
        return True

    def boss_immune(self, b):
        return any(m.role == "add" and m.hp > 0 and m.parent == b.id for m in self.actors.values() if m.kind == "imob")

    def on_player_hit(self, t, ab):
        if t.kind != "imob" or t.role != "boss": return
        cast = getattr(t, "cast", None)
        if cast and cast.get("interruptible") and ab and (ab.get("kind") in ("stun", "charge") or ab.get("stun")):
            # nova stuns only count when the boss is inside the nova (use_ability already checked range)
            self._interrupt(t, by_player=True)

    def _interrupt(self, b, by_player):
        cast = b.cast; b.cast = None
        if by_player:
            self.stats["interrupts"] += 1
            self.w.mythic_event("interrupt")
            self._say(f"You interrupted {cast['name']}!", "Interrupted!")
        else:
            self._say(f"{b.name}'s {cast['name']} was interrupted.")
        b.nextatk = self.w.tick + 8

    # ------------------------------------------------------------- tick
    def tick(self):
        w = self.w; p = w.player; now = w.tick
        cur = self.current_room()
        party_pos = [(p["x"], p["y"])] + [(a.x, a.y) for a in self.alive_allies()]
        for r in self.rooms:
            if r["type"] == "start" or r["pulled"] or r["cleared"]: continue
            trig = False
            if r["type"] == "trash":
                for mid in r["mobs"]:
                    m = self.actors[mid]
                    if m.hp > 0 and any(_dist(x, y, m.x, m.y) < 7.5 for x, y in party_pos): trig = True
            else:
                trig = any(_dist(x, y, r["cx"], r["cy"]) <= 8.6 for x, y in party_pos)
            if any(self.actors[m].state == "fight" for m in r["mobs"]): trig = True
            if trig: self._pull(r)
        for r in self.rooms:
            if r["pulled"] and not r["cleared"]:
                self._room_ai(r)
        if self.rest_until and now >= self.rest_until:
            self.rest_until = 0
            lead = self.mt if (self.mt and not self.mt.dead) else None
            self._say(f"{lead.name} is ready and leads the way." if lead else "The rest is over.")
        self._allies_ai(cur)
        self._hazard_tick()
        self._mark_tick()
        if now % 4 == 0:
            self._ally_support()
        if len(self.fxq) > 80: self.fxq = self.fxq[-80:]

    def _pull(self, r):
        r["pulled"] = True
        for mid in r["mobs"]:
            m = self.actors[mid]
            if m.hp <= 0: continue
            m.state = "fight"; m.tgt = self._target_for(m); m.timer = self.fx.randint(2, 8)
            if m.role == "boss":
                m.pull_tick = self.w.tick
                for k in m.next: m.next[k] = self.w.tick + int(INTERVAL.get(k, 20) * TPS * .7) + self.fx.randint(0, 12)
                m.nextatk = self.w.tick + 8
                self._say(f"{m.name}: \"You dare enter this place?\"", "Boss engaged!")

    def _room_ai(self, r):
        live = [self.actors[m] for m in r["mobs"] if self.actors[m].hp > 0]
        if not live:
            r["cleared"] = True
            if r["type"] != "final" and not self.done:
                if self.kind != "dungeon":
                    self.begin_rest("The room" if r["type"] == "trash" else "The boss room")
                elif r["type"] != "trash":          # 0.44: dungeons - no rest after trash, 15 seconds after a boss
                    self.begin_rest("The boss room", DUNGEON_BOSS_REST)
            return
        for m in live:
            if m.role == "boss":
                self._boss_ai(m, r)
            else:
                self._mob_ai(m, r)

    def _tgt_pos(self, t):
        if t == "player": p = self.w.player; return p["x"], p["y"]
        return t.x, t.y

    def _step_to(self, a, tx, ty, speed, r=None):
        dx, dy = tx - a.x, ty - a.y; d = math.hypot(dx, dy)
        if d < .05: return
        left = min(speed, d)
        while left > 1e-6:
            s = min(.4, left); left -= s
            nx, ny = a.x + dx / d * s, a.y + dy / d * s
            if self.floor.get((int(nx), int(ny))) is not None:
                a.x, a.y = nx, ny
            elif self.floor.get((int(nx), int(a.y))) is not None:
                a.x = nx
            elif self.floor.get((int(a.x), int(ny))) is not None:
                a.y = ny
            else:
                break

    # ------------------------------------------------------------- navigation (0.23)
    def _clear(self, x0, y0, x1, y1):
        n = int(_dist(x0, y0, x1, y1) / .3) + 1
        for i in range(1, n + 1):
            t = i / n
            if self.floor.get((int(x0 + (x1 - x0) * t), int(y0 + (y1 - y0) * t))) is None: return False
        return True

    def _find_path(self, sx, sy, gx, gy, limit=4000):
        st = (int(sx), int(sy)); gl = (int(gx), int(gy))
        if gl not in self.floor or st == gl: return [(gx, gy)]
        openh = [(0, st)]; came = {st: None}; cost = {st: 0}; n = 0
        while openh and n < limit:
            _, cur = heapq.heappop(openh); n += 1
            if cur == gl: break
            cx, cy = cur
            for ddx, ddy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
                nb = (cx + ddx, cy + ddy)
                if nb not in self.floor: continue
                if ddx and ddy and ((cx + ddx, cy) not in self.floor or (cx, cy + ddy) not in self.floor): continue
                nc = cost[cur] + (1.414 if ddx and ddy else 1.0)
                if nc < cost.get(nb, 1e9):
                    cost[nb] = nc; came[nb] = cur
                    heapq.heappush(openh, (nc + abs(nb[0] - gl[0]) + abs(nb[1] - gl[1]), nb))
        if gl not in came: return None
        out = []; c = gl
        while c is not None and c != st:
            out.append((c[0] + .5, c[1] + .5)); c = came[c]
        out.reverse()
        if out: out[-1] = (gx, gy)
        return out

    def _nav(self, a, tx, ty, speed):
        """Walk toward (tx, ty) using a cached floor path when there is no straight line."""
        st_ = self.w.mstatus.get(a.id) if getattr(a, "kind", "") != "ally" else None      # 0.46.37: chilled enemies move at half speed
        if st_ and st_.get("slow", 0) > self.w.tick: speed *= .5
        if self.floor.get((int(tx), int(ty))) is None:
            # aim for the nearest walkable tile instead of a wall
            best = None
            for ddx in (-1, 0, 1):
                for ddy in (-1, 0, 1):
                    k = (int(tx) + ddx, int(ty) + ddy)
                    if k in self.floor and (best is None or _dist(k[0] + .5, k[1] + .5, tx, ty) < _dist(best[0] + .5, best[1] + .5, tx, ty)): best = k
            if best is None: return
            tx, ty = best[0] + .5, best[1] + .5
        if self._clear(a.x, a.y, tx, ty):
            self._paths.pop(a.id, None); self._step_to(a, tx, ty, speed); return
        now = self.w.tick
        pc = self._paths.get(a.id)
        if pc is None or pc[0] != (int(tx), int(ty)) or now - pc[1] > 12 or not pc[2]:
            path = self._find_path(a.x, a.y, tx, ty)
            if not path: self._step_to(a, tx, ty, speed); return
            pc = self._paths[a.id] = [(int(tx), int(ty)), now, path]
        path = pc[2]
        left = speed
        while path and left > 0:
            wx, wy = path[0]
            d = _dist(a.x, a.y, wx, wy)
            if d <= left + .05:
                self._step_to(a, wx, wy, d); left -= d; path.pop(0)
            else:
                self._step_to(a, wx, wy, left); left = 0

    def _mob_hit(self, m, tgt):
        w = self.w
        m.atk_tick = w.tick
        raw = (1 + m.level * 1.15) * m.dmgm * self.fx.uniform(.8, 1.25)
        if tgt == "player":
            w.damage_player(raw, m, m.id)
        else:
            self.hit_ally(tgt, raw)

    def _mob_ai(self, m, r):
        w = self.w
        if w._stunned(m): return
        tgt = getattr(m, "tgt", "player")
        if tgt != "player" and tgt.dead: tgt = m.tgt = self._target_for(m)
        tx, ty = self._tgt_pos(tgt)
        d = _dist(m.x, m.y, tx, ty)
        if d > 1.3: self._nav(m, tx, ty, .55)
        m.timer -= 1
        if d <= 1.8 and m.timer <= 0:
            m.timer = 8
            self._mob_hit(m, tgt)

    # ---------------------------------------------------------- boss logic
    def _boss_ai(self, b, r):
        w = self.w; now = w.tick
        mech = b.mech
        hpf = b.hp / b.maxhp
        # enrage (heroic): after the timer, the boss hits harder and harder
        if self.kind == "heroic":
            limit = (420 if b.final else 240) * TPS
            if now - b.pull_tick > limit and not b.enraged:
                b.enraged = True; self._say(f"{b.name} ENRAGES!", "ENRAGED - you took too long!")
        # adds phases
        if "adds" in mech:
            for th in ADD_THRESH[self.kind]:
                if hpf <= th and th not in b.adds_done:
                    b.adds_done.add(th); self._spawn_adds(b); break
        # cast in progress?
        if b.cast:
            if now >= b.cast["until"]:
                self._resolve_cast(b)
            return
        tgt = self.mt if self.mt and not self.mt.dead else "player"
        if w.spec_role() == "Tank" or not self.mt or self.mt.dead: tgt = "player" if (w.spec_role() == "Tank" or not self.alive_allies()) else (self.mt if self.mt and not self.mt.dead else "player")
        # movement: stay on the main target
        tx, ty = self._tgt_pos(tgt)
        if _dist(b.x, b.y, tx, ty) > 1.6: self._nav(b, tx, ty, .42)
        # pick a mechanic that is ready
        for k in mech:
            if now >= b.next[k]:
                if k in ("interrupt", "breath", "buster", "inferno"):
                    self._start_cast(b, k, tgt)
                    b.next[k] = now + INTERVAL[k] * TPS
                    return
                if k == "fire":
                    self._spawn_fire(b); b.next[k] = now + INTERVAL[k] * TPS
                if k == "mark" and not self.mark:
                    self._apply_mark(b); b.next[k] = now + INTERVAL[k] * TPS
                if k == "pulse":
                    self._pulse(b); b.next[k] = now + INTERVAL[k] * TPS
        # auto attack
        if now >= b.nextatk and _dist(b.x, b.y, tx, ty) < 2.4:
            b.nextatk = now + 8; b.atk_tick = now
            raw = (1 + b.level * 1.15) * b.dmgm * self.fx.uniform(.85, 1.15) * (2.2 if b.enraged else 1.0)
            if tgt == "player": w.damage_player(raw, b, b.id)
            else: self.hit_ally(tgt, raw)

    def _start_cast(self, b, k, tgt):
        w = self.w; now = w.tick
        dur = {"interrupt": 14, "breath": 10, "buster": 12, "inferno": 14}[k]
        if self.kind == "heroic": dur = int(dur * .85)
        c = {"kind": k, "name": MECH_NAMES[k], "start": now, "until": now + dur, "total": dur, "interruptible": k == "interrupt", "tgt": tgt}
        b.cast = c
        p = w.player
        if k == "breath":
            c["ang"] = math.atan2(p["y"] - b.y, p["x"] - b.x)
            self.hazards.append({"id": self._new_id(), "shape": "cone", "x": b.x, "y": b.y, "r": 16, "ang": c["ang"], "half": .55,
                                 "start": now, "until": now + dur, "kind": "breath", "boss": b.id})
            self._say(f"{b.name} inhales... Dragon Breath!", MECH_HELP["breath"])
        elif k == "inferno":
            ang = self.fx.random() * math.tau; rad = self.fx.uniform(1.5, 4.2)
            sx, sy = b.x + math.cos(ang) * rad, b.y + math.sin(ang) * rad
            r = next(rr for rr in self.rooms if rr["i"] == b.room)
            sx = max(r["cx"] - 6, min(r["cx"] + 6, sx)); sy = max(r["cy"] - 6, min(r["cy"] + 6, sy))
            self.hazards.append({"id": self._new_id(), "shape": "safe", "x": sx, "y": sy, "r": 2.6, "start": now, "until": now + dur,
                                 "kind": "inferno", "room": r["i"], "boss": b.id})
            self._say(f"{b.name} sets the room ablaze!", MECH_HELP["inferno"])
        elif k == "interrupt":
            self._say(f"{b.name} begins casting {c['name']}!", MECH_HELP["interrupt"])
        elif k == "buster":
            nm = "you" if tgt == "player" else tgt.name
            self._say(f"{b.name} winds up a Crushing Blow on {nm}!", MECH_HELP["buster"] if tgt == "player" else "")

    def _resolve_cast(self, b):
        w = self.w; p = w.player; mx = w._effective_maxhp(); c = b.cast; k = c["kind"]; b.cast = None
        b.nextatk = w.tick + 8
        if k == "interrupt":
            # allies sometimes interrupt for you on easier difficulties
            if self.fx.random() < self.diff["interrupt_ally"] and self.alive_allies():
                self._say(f"{self.fx.choice(self.alive_allies()).name} interrupts {c['name']}.")
                return
            f = .7 if self.kind == "heroic" else .5
            w.damage_player(mx * f, b, b.id, mech=True)
            for a in self.alive_allies(): self.hit_ally(a, a.maxhp * f * .8, true=True)
            self._say(f"{c['name']} hits the whole party!", "You must interrupt it with a stun!")
        elif k == "breath":
            self.hazards = [h for h in self.hazards if not (h["kind"] == "breath" and h["boss"] == b.id)]
            ang = c["ang"]
            if self._in_cone(p["x"], p["y"], b.x, b.y, ang, .55, 16) and not self.blocked_los(b.x, b.y, p["x"], p["y"]):
                w.damage_player(mx * (.75 if self.kind == "heroic" else .55), b, b.id, mech=True)
                self._say("The breath scorches you!", "Leave the cone or hide behind a pillar!")
            else:
                self._say("You avoided the breath.")
        elif k == "inferno":
            hs = [h for h in self.hazards if h["kind"] == "inferno" and h["boss"] == b.id]
            self.hazards = [h for h in self.hazards if h not in hs]
            if hs:
                h = hs[0]
                if _dist(p["x"], p["y"], h["x"], h["y"]) > h["r"]:
                    w.damage_player(mx * (.65 if self.kind == "heroic" else .45), b, b.id, mech=True)
                    self._say("The inferno burns you!", "Get inside the safe circle!")
                else:
                    self._say("You reach the safe circle.")
        elif k == "buster":
            tgt = c["tgt"]
            if tgt == "player":
                guarded = w._buff("armor") or w._buff("shield") or w._buff("dodge")
                if guarded:
                    w.damage_player(mx * .18, b, b.id, mech=True); self._say("You brace against the Crushing Blow.")
                else:
                    w.damage_player(mx * (.95 if self.kind == "heroic" else .8), b, b.id, mech=True)
                    self._say("Crushing Blow!", "Use a defensive skill (7-0) before the blow lands.")
            elif not tgt.dead:
                if self.fx.random() < .7: self.hit_ally(tgt, tgt.maxhp * .25, true=True)
                else: self.hit_ally(tgt, tgt.maxhp * .6, true=True)

    @staticmethod
    def _in_cone(px, py, bx, by, ang, half, length):
        d = _dist(px, py, bx, by)
        if d > length or d < .01: return d < .01
        da = abs((math.atan2(py - by, px - bx) - ang + math.pi) % math.tau - math.pi)
        return da <= half

    def _spawn_fire(self, b):
        w = self.w; p = w.player; now = w.tick
        r = next(rr for rr in self.rooms if rr["i"] == b.room)
        n = self.diff["fire"]
        warn = 6 if self.kind == "heroic" else 8
        spots = [(p["x"], p["y"])]
        for _ in range(n):
            ang = self.fx.random() * math.tau; rad = self.fx.uniform(0, 8.0)
            spots.append((r["cx"] + math.cos(ang) * rad, r["cy"] + math.sin(ang) * rad))
        for (x, y) in spots:
            self.hazards.append({"id": self._new_id(), "shape": "circle", "x": x, "y": y, "r": 2.2, "start": now, "until": now + warn,
                                 "kind": "fire", "boss": b.id, "dmg": self.diff["fr"]})
        self._say(f"{b.name} calls down Rain of Fire!", MECH_HELP["fire"])

    def _apply_mark(self, b):
        now = self.w.tick
        self.mark = {"start": now, "until": now + 20, "boss": b.id}
        self._say(f"{b.name} brands you with a Void Mark!", MECH_HELP["mark"])

    def _pulse(self, b):
        w = self.w; mx = w._effective_maxhp()
        f = .14 if self.kind == "heroic" else .09
        w.damage_player(mx * f, b, b.id, mech=True)
        for a in self.alive_allies(): self.hit_ally(a, a.maxhp * f, true=True)

    def _spawn_adds(self, b):
        n = {"dungeon": 4, "raid": 6, "heroic": 6}[self.kind]
        hp = self._mob_hp() * (.9 if self.kind != "heroic" else .7)
        sp = self.fx.choice(self.species)
        for k in range(n):
            ang = k / n * math.tau
            a = self._mk(f"{sp} #{self.nid + 1}", b.level - 1, b.x + math.cos(ang) * 3, b.y + math.sin(ang) * 3, hp, role="add")
            a.room = b.room; a.look = sp; a.dmgm = self.diff["dmg"] * 1.1; a.parent = b.id; a.state = "fight"; a.tgt = self._target_for(a); a.timer = 6
            self.rooms[b.room]["mobs"].append(a.id)
            self.w.by_id[a.id] = a; self.w.actors.append(a)
        self._say(f"{b.name} summons {n} {sp}s! The boss is immune until they die.", MECH_HELP["adds"])

    # ------------------------------------------------------------- hazards
    def _hazard_tick(self):
        w = self.w; now = w.tick; p = w.player; mx = w._effective_maxhp()
        keep = []
        for h in self.hazards:
            if h["kind"] == "fire":
                if now >= h["until"]:
                    if _dist(p["x"], p["y"], h["x"], h["y"]) <= h["r"]:
                        b = self.actors.get(h["boss"])
                        w.damage_player(mx * h["dmg"] * (1.6 if b and getattr(b, "enraged", False) else 1), b or self.rooms[0], h["boss"], mech=True)
                        self._say("You are burned by the fire!", "Move out of the red circles!")
                    else:
                        self.stats["fire_dodged"] += 1
                        w.mythic_event("fire_dodged")
                    h["flash"] = now + 3; h["until"] = now + 3; h["kind"] = "fireflash"
                    keep.append(h)
                else:
                    keep.append(h)
            elif h["kind"] == "fireflash":
                if now < h["until"]: keep.append(h)
            else:
                b = self.actors.get(h["boss"])
                if b and b.hp > 0 and getattr(b, "cast", None) is not None: keep.append(h)
        self.hazards = keep

    def _mark_tick(self):
        m = self.mark
        if not m: return
        w = self.w; p = w.player; now = w.tick
        if now < m["until"]: return
        mx = w._effective_maxhp(); hurt = 0
        for a in self.alive_allies():
            if _dist(a.x, a.y, p["x"], p["y"]) <= 4.5:
                self.hit_ally(a, a.maxhp * .8, true=True); hurt += 1
        w.damage_player(mx * .12, self.actors.get(m["boss"]) or self.rooms[0], m["boss"], mech=True)
        if hurt:
            self._say(f"The Void Mark explodes, hurting {hurt} of your party!", "Run away from your party BEFORE it goes off!")
        else:
            self.stats["mark_clean"] += 1; w.mythic_event("mark_clean")
            self._say("The Void Mark detonates harmlessly.")
        self.hazards.append({"id": self._new_id(), "shape": "circle", "x": p["x"], "y": p["y"], "r": 4.5, "start": now, "until": now + 3, "kind": "fireflash", "boss": 0})
        self.mark = None

    # ------------------------------------------------------------- allies (0.23 rewrite)
    # The AI party plays like a real group: the tank runs ahead to the next pack and pulls it, taunts
    # anything that peels off, DPS assist the tank's target, and the healer keeps everyone (you too) alive.
    # Everyone runs as fast as you do and paths around corners, so nobody gets left behind.
    def _live_mobs(self):
        out = []
        for r in self.rooms:
            if not r["pulled"] or r["cleared"]: continue
            out += [self.actors[m] for m in r["mobs"] if self.actors[m].hp > 0]
        return out

    def _focus(self):
        """What the party is attacking: adds first, then pulled mobs, then the boss."""
        w = self.w; p = w.player
        live = self._live_mobs()
        if not live: return None
        adds = [m for m in live if m.role == "add"]
        norm = [m for m in live if m.role == "mob"]
        boss = [m for m in live if m.role == "boss" and not self.boss_immune(m)]
        pick = adds or norm or boss
        if not pick: return None
        anchor = self.mt if (self.mt and not self.mt.dead) else None
        ax, ay = (anchor.x, anchor.y) if anchor else (p["x"], p["y"])
        return min(pick, key=lambda m: _dist(m.x, m.y, ax, ay))

    def _next_room(self):
        for r in self.rooms:
            if not r["cleared"]: return r
        return None

    def _emit(self, kind, src, dst, **kw):
        e = {"t": kind, "src": src, "dst": dst}; e.update(kw); self.fxq.append(e)

    def _ally_dmg(self, a, f):
        lvl = min(self.w.player["level"], self.level + 3)     # allies fight at the dungeon's level, not yours
        mult = {"DPS": 1.0, "Tank": .55, "Healer": .32}[a.rrole]
        if a.ranged and a.rrole == "DPS": mult *= 1.1
        base = (lvl * 3 + 40) * (1.25 if self.kind != "dungeon" else 1.0)
        burst = 1.7 if getattr(a, "burst_until", 0) > self.w.tick else 1.0       # 0.44.9: DPS cooldowns
        return int(base * mult * burst * self.fx.uniform(.85, 1.15) * (1.6 if self.fx.random() < .1 else 1.0))

    def _ally_attack(self, a, f, now):
        if getattr(f, "role", "") == "boss" and self.boss_immune(f): return
        a.atk_tick = now
        dmg = self._ally_dmg(a, f)
        self._emit("shot" if a.ranged else "melee", a.id, f.id, cls=a.cls, dmg=dmg)
        f.hp -= dmg
        if f.hp <= 0: self.mob_dead(f, by_player=False)

    def _formation(self, a, lx, ly, fx_, fy_):
        """Spot behind the leader (lx, ly) facing (fx_, fy_)."""
        dx, dy = fx_ - lx, fy_ - ly; d = math.hypot(dx, dy) or 1; dx /= d; dy /= d
        px_, py_ = -dy, dx
        row = 1 + a.slot // 3; col = (a.slot % 3) - 1
        back = 2.2 * row + (1.0 if a.rrole == "Healer" else 0)
        return lx - dx * back + px_ * col * 1.7, ly - dy * back + py_ * col * 1.7

    def _allies_ai(self, cur):
        w = self.w; p = w.player; now = w.tick
        al = self.alive_allies()
        if not al: return
        live = self._live_mobs()
        tank = self.mt if (self.mt and not self.mt.dead) else None
        player_tank = w.spec_role() == "Tank"
        focus = self._focus()
        # --- the tank's own target: the boss if one is up, else whatever is loose / nearest
        tank_tgt = None
        if tank and live:
            bosses = [m for m in live if m.role == "boss"]
            loose = [m for m in live if getattr(m, "tgt", None) is not tank and m.role != "boss"]
            if bosses: tank_tgt = bosses[0]
            elif loose: tank_tgt = min(loose, key=lambda m: _dist(m.x, m.y, tank.x, tank.y))
            else: tank_tgt = min(live, key=lambda m: _dist(m.x, m.y, tank.x, tank.y))
            # taunt: every 2 seconds pull anything that peeled off back onto the tank
            urgent = now - getattr(tank, "taunt_tick", -99) >= 4 and any(hasattr(getattr(m, "tgt", None), "rrole") and m.tgt.rrole != "Tank" for m in live)
            if now % 8 == tank.slot % 8 or urgent:
                tank.taunt_tick = now
                peeled = [m for m in live if getattr(m, "tgt", None) is not tank and _dist(m.x, m.y, tank.x, tank.y) < 11]
                if peeled:
                    for m in peeled:
                        if self.fx.random() < .85: m.tgt = tank
                    self._emit("taunt", tank.id, tank.id)
        nr = self._next_room()
        for a in al:
            # -------- keep up: teleport if hopelessly behind or stuck behind geometry
            dp = _dist(a.x, a.y, p["x"], p["y"])
            moved = _dist(a.x, a.y, a.lastpos[0], a.lastpos[1])
            a.stuck = a.stuck + 1 if (moved < .05 and dp > 4) else 0
            if dp > 22 or a.stuck > 10:
                ang = a.slot * 1.9
                for rr in (1.6, 2.4, 1.0):
                    nx, ny = p["x"] + math.cos(ang) * rr, p["y"] + math.sin(ang) * rr
                    if self.floor.get((int(nx), int(ny))) is not None:
                        a.x, a.y = nx, ny; break
                a.stuck = 0; self._paths.pop(a.id, None)
            self._ally_instincts(a, live, al, tank, now)
            tx = ty = None; speed = 1.25
            kite = self._kite_spot(a, live, al, tank) if (live and a.rrole != "Tank") else None
            if kite:
                tx, ty = kite; speed = 1.35
            elif live:
                # ================= combat
                if a.rrole == "Tank":
                    t = tank_tgt or focus
                    if t is not None:
                        if _dist(a.x, a.y, t.x, t.y) > 1.3: tx, ty = t.x, t.y; speed = 1.15
                        if now - a.atk_tick >= 4 and _dist(a.x, a.y, t.x, t.y) <= 1.9: self._ally_attack(a, t, now)
                elif a.rrole == "Healer":
                    anchor = tank or (None if player_tank else None)
                    ax_, ay_ = (anchor.x, anchor.y) if anchor else (p["x"], p["y"])
                    t = focus
                    if t is not None:
                        dx, dy = ax_ - t.x, ay_ - t.y; d = math.hypot(dx, dy) or 1
                        tx, ty = ax_ + dx / d * 4.5 + math.cos(a.slot) * 1.2, ay_ + dy / d * 4.5 + math.sin(a.slot) * 1.2
                    # heals happen in _ally_support (every second); with nothing to heal the healer smites
                    if t is not None and now - a.atk_tick >= 6 and getattr(a, "idle_heal", True) and _dist(a.x, a.y, t.x, t.y) <= 8.5:
                        self._ally_attack(a, t, now)
                else:
                    t = tank_tgt if (tank_tgt is not None and not (tank_tgt.role == "boss" and self.boss_immune(tank_tgt))) else focus
                    if t is None: t = focus
                    if t is not None:
                        if a.ranged:
                            want = 5.0
                            d = _dist(a.x, a.y, t.x, t.y)
                            if d > want + .8 or not self._clear(a.x, a.y, t.x, t.y):
                                ang = a.slot * 1.1 + 2.0
                                tx, ty = t.x + math.cos(ang) * want, t.y + math.sin(ang) * want
                            if now - a.atk_tick >= 5 and d <= 7.5: self._ally_attack(a, t, now)
                        else:
                            # melee DPS stand behind the target, opposite the tank
                            ox, oy = ((t.x - tank.x), (t.y - tank.y)) if tank else (math.cos(a.slot * 2.1), math.sin(a.slot * 2.1))
                            d0 = math.hypot(ox, oy) or 1
                            gx, gy = t.x + ox / d0 * 1.0 + math.cos(a.slot * 2.4) * .5, t.y + oy / d0 * 1.0 + math.sin(a.slot * 2.4) * .5
                            if _dist(a.x, a.y, t.x, t.y) > 1.5: tx, ty = gx, gy
                            if now - a.atk_tick >= 4 and _dist(a.x, a.y, t.x, t.y) <= 1.9: self._ally_attack(a, t, now)
            else:
                # ================= travelling: the tank leads to the next pack, everyone else keeps formation
                if a.rrole == "Tank" and a is tank and nr is not None and not self.mark:
                    hurt = any(x.hp < x.maxhp * .6 for x in al) or p["hp"] < w._effective_maxhp() * .5
                    resting = now < self.rest_until
                    if resting:
                        # 0.24: hold position beside you while everyone heals, loots and recovers
                        if dp > 4.5: tx, ty = p["x"], p["y"]; speed = .9
                    elif dp < 11 and not hurt:
                        tx, ty = nr["cx"], nr["cy"]
                        speed = 1.05
                    elif dp > 5:
                        tx, ty = p["x"], p["y"]
                elif self.mark:
                    continue
                else:
                    if tank is not None and a is not tank:
                        lx, ly = tank.x, tank.y
                        ahead = (nr["cx"], nr["cy"]) if nr is not None else (p["x"], p["y"])
                        if _dist(tank.x, tank.y, p["x"], p["y"]) > 9: lx, ly = p["x"], p["y"]
                        tx, ty = self._formation(a, lx, ly, ahead[0], ahead[1])
                    else:
                        ahead = (nr["cx"], nr["cy"]) if nr is not None else (p["x"] + 1, p["y"] + 1)
                        tx, ty = self._formation(a, p["x"], p["y"], ahead[0], ahead[1])
                    d = _dist(a.x, a.y, tx, ty)
                    speed = 1.3 if d > 3 else .7
            # never stand in a hazard
            for h in self.hazards:
                if h["shape"] == "circle" and h["kind"] == "fire" and _dist(a.x, a.y, h["x"], h["y"]) < h["r"] + .5:
                    dx, dy = a.x - h["x"], a.y - h["y"]; d = math.hypot(dx, dy) or 1
                    tx, ty = h["x"] + dx / d * (h["r"] + 1.2), h["y"] + dy / d * (h["r"] + 1.2); speed = 1.3
                elif h["shape"] == "cone" and h["kind"] == "breath" and a.rrole != "Tank" and self._in_cone(a.x, a.y, h["x"], h["y"], h["ang"], h["half"], h["r"]):
                    sx_, sy_ = -math.sin(h["ang"]), math.cos(h["ang"])
                    tx, ty = a.x + sx_ * 4, a.y + sy_ * 4; speed = 1.3
            a.lastpos = (a.x, a.y)
            if tx is not None and _dist(a.x, a.y, tx, ty) > .5:
                self._nav(a, tx, ty, speed)

    def _ally_instincts(self, a, live, al, tank, now):
        """0.44.9: each role plays like a player - tanks wall up when low, DPS pop cooldowns, interrupt and drink potions."""
        frac = a.hp / max(1, a.maxhp)
        if a.rrole == "Tank" and live and frac < .4 and now >= getattr(a, "wall_cd", 0):
            a.wall_until = now + 20; a.wall_cd = now + 100
            self._say(f"{a.name} raises a Shield Wall!"); self._emit("taunt", a.id, a.id)
        if live and frac < .35 and now >= getattr(a, "pot_cd", 0) and a.rrole != "Healer":
            a.pot_cd = now + 360; self.heal_ally(a, a.maxhp * .35)
            self._say(f"{a.name} drinks a healing potion."); self._emit("heal", a.id, a.id, amt=int(a.maxhp * .35))
        if a.rrole == "DPS" and live and now >= getattr(a, "burst_cd", 0):
            big = any(m.role == "boss" for m in live) or len(live) >= 3
            if big and any(_dist(a.x, a.y, m.x, m.y) < 9 for m in live):
                a.burst_until = now + 16; a.burst_cd = now + 90 + self.fx.randint(0, 30)
                if self.fx.random() < .35: self._say(f"{a.name} unleashes {a.cls} fury!")
        if a.rrole == "DPS":
            for m in live:
                c = getattr(m, "cast", None)
                if m.role == "boss" and c and c.get("interruptible"):
                    if "ally_int" not in c: c["ally_int"] = self.fx.random() < .55
                    if c["ally_int"] and now - c["start"] >= 5 and _dist(a.x, a.y, m.x, m.y) < (9 if a.ranged else 2.6):
                        self._say(f"{a.name} interrupts {c['name']}!"); self._interrupt(m, by_player=False); break

    def _kite_spot(self, a, live, al, tank):
        """A hurt DPS or healer that something is chewing on backs off toward the tank."""
        if a.hp > a.maxhp * .4: return None
        chasers = [m for m in live if getattr(m, "tgt", None) is a and _dist(m.x, m.y, a.x, a.y) < 4]
        if not chasers: return None
        m = min(chasers, key=lambda m: _dist(m.x, m.y, a.x, a.y))
        ax, ay = (tank.x, tank.y) if tank else (self.w.player["x"], self.w.player["y"])
        dx, dy = a.x - m.x, a.y - m.y; d = math.hypot(dx, dy) or 1
        return ((a.x + dx / d * 3 + ax) / 2, (a.y + dy / d * 3 + ay) / 2)

    def _ally_support(self):
        """Every second: AI healers heal the most wounded party member (you included).  Out of combat the party
        regenerates and the healer resurrects anyone who fell."""
        w = self.w; mx = w._effective_maxhp(); p = w.player; now = w.tick
        healers = [a for a in self.alive_allies() if a.rrole == "Healer"]
        in_combat = bool(self._live_mobs())
        for hl in healers:
            hl.idle_heal = True
            cands = [((a.hp / a.maxhp) * (.88 if a.rrole == "Tank" else 1.0), a) for a in self.alive_allies() if a.hp < a.maxhp]
            pf = p["hp"] / mx
            if pf < 1: cands.append((pf * .95, "player"))     # the player gets a little priority
            if not cands: continue
            cands.sort(key=lambda x: x[0])
            f, t = cands[0]
            if f > .92: continue
            if now - getattr(hl, "heal_tick", -99) < (3 if f < .3 else 4 if f < .45 else 6): continue
            tid = "player" if t == "player" else t.id
            cl = getattr(self, "_heal_claim", None)
            if cl and cl[0] == tid and now - cl[1] < 3: continue          # another healer already has them
            self._heal_claim = (tid, now)
            hl.heal_tick = now; hl.atk_tick = now; hl.idle_heal = False
            amt = (.34 if f < .3 else .24 if f < .45 else .16) * (1.0 if self.kind != "heroic" else .85)
            if t == "player":
                w._heal(mx * amt); self._emit("heal", hl.id, "player", amt=int(mx * amt))
            else:
                self.heal_ally(t, t.maxhp * amt); self._emit("heal", hl.id, t.id, amt=int(t.maxhp * amt))
        if not in_combat:
            for a in self.alive_allies(): a.hp = min(a.maxhp, a.hp + a.maxhp * .12)
            # resurrect the fallen a few seconds after the fight
            rezzer = healers[0] if healers else None
            for a in self.allies:
                if a.dead and now - a.dead_tick > 12:
                    a.dead = False; a.state = "idle"; a.hp = int(a.maxhp * .5)
                    who = rezzer.name if rezzer else "The party"
                    self._say(f"{who} resurrects {a.name}.")
                    if rezzer: self._emit("heal", rezzer.id, a.id, amt=0)

    # ------------------------------------------------------------- kills / death
    def player_killed(self, t):
        return self.mob_dead(t, by_player=True)

    def mob_dead(self, t, by_player=True):
        w = self.w; p = w.player
        if t.id in getattr(self, "_dead_ids", set()): return 0
        self._dead_ids = getattr(self, "_dead_ids", set()) | {t.id}
        t.hp = 0; t.state = "dead"; t.dead_tick = w.tick
        w.mstatus.pop(t.id, None)
        lvl = t.level
        mult = {"mob": 1.0, "add": .6, "boss": 8.0}[t.role]
        gold = int(lvl * w.rng.randint(1, 3) * mult * (1.6 if self.kind != "dungeon" else 1.2))       # 0.35.1: gold is a grind
        xp = int((20 + lvl * 3) * mult * 1.3)
        p["gold"] += gold; p["xp"] += xp
        if by_player: p["kills"] += 1
        w.kill_events.append({"id": t.id, "x": t.x, "y": t.y, "gold": gold, "name": t.name.split(" #")[0]})
        for m in list(self.actors.values()):
            if getattr(m, "parent", None) == t.id and m.hp > 0:
                pass
        if t.role == "boss":
            self._boss_down(t)
        elif t.role == "mob" and w.rng.random() < (.04 if self.kind == "dungeon" else .06):
            self._drop(t, "trash")
        w.mythic_event("kill_inst")
        w._level_check()
        return gold

    def _drop(self, t, tier):
        w = self.w
        w.drop_instance_loot(t.x + w.rng.uniform(-.6, .6), t.y + w.rng.uniform(-.6, .6), self.level, self.kind, tier, t.name.split(" #")[0])

    def _boss_down(self, b):
        w = self.w
        self.hazards = [h for h in self.hazards if h.get("boss") != b.id]
        if self.mark and self.mark["boss"] == b.id: self.mark = None
        for m in self.actors.values():
            if getattr(m, "parent", None) == b.id: m.hp = 0
        w.add_instance_boss_rewards(self, b)
        if b.final:
            self.done = True
            r = self.rooms[b.room]
            self.portals.append((r["cx"], r["cy"] + 3.0))
            self.props.append((r["cx"], r["cy"] + 3.0, "portal", 0))
            self._say(f"{self.d.name} cleared! A portal opens - press F next to it (or click it) to leave.", "Dungeon cleared!")
            w.add_instance_clear_rewards(self)

    def on_player_death(self):
        """Wipe: the party reforms at the entrance and the current encounter resets."""
        w = self.w; p = w.player
        self.wipes += 1; self.player_deaths += 1
        self.mark = None; self.hazards = []
        for r in self.rooms:
            if r["pulled"] and not r["cleared"]:
                r["pulled"] = False
                for mid in list(r["mobs"]):
                    m = self.actors[mid]
                    if m.role == "add":
                        m.hp = 0; r["mobs"].remove(mid); self.actors.pop(mid, None)
                        if m in w.actors: w.actors.remove(m)
                        w.by_id.pop(mid, None)
                        continue
                    if m.hp <= 0: continue          # the dead stay dead
                    m.hp = m.maxhp; m.state = "idle"; m.x, m.y = m.home_xy
                    if m.role == "boss": m.cast = None; m.enraged = False; m.adds_done = set()
        for a in self.allies:
            a.dead = False; a.hp = a.maxhp; a.state = "idle"; a.x, a.y = self.spawn[0] + (a.slot % 3) - 1, self.spawn[1] + 1 + a.slot // 3
            a.stuck = 0; a.lastpos = (a.x, a.y)
        self._paths.clear()
        p["x"], p["y"] = self.spawn
        p["hp"] = max(1, int(w._effective_maxhp() * (.5 if self.kind != "heroic" else .35)))
        w.buffs.clear()
        self.rest_total = 20 * TPS; self.rest_until = w.tick + self.rest_total
        self._say(f"Your party was wiped. You wake at the entrance. The party regroups for 20 seconds. (Wipe {self.wipes})", "Wipe!")

    # ------------------------------------------------------------- snapshot
    def snapshot(self):
        w = self.w; now = w.tick
        b = self.boss_actor()
        boss = None
        if b:
            c = b.cast
            boss = {"id": b.id, "name": b.name, "hp": max(0, b.hp), "maxhp": b.maxhp, "imm": self.boss_immune(b),
                    "enraged": b.enraged, "mechs": [MECH_NAMES[m] for m in b.mech],
                    "enrage_left": max(0, int(((420 if b.final else 240) * TPS - (now - b.pull_tick)) / TPS)) if self.kind == "heroic" else None,
                    "cast": ({"name": c["name"], "left": max(0, (c["until"] - now) / TPS), "total": c["total"] / TPS, "interruptible": c["interruptible"]} if c else None)}
        haz = [{"id": h["id"], "shape": h["shape"], "x": h["x"], "y": h["y"], "r": h["r"], "ang": h.get("ang", 0), "half": h.get("half", 0),
                "left": max(0, (h["until"] - now) / TPS), "total": max(.25, (h["until"] - h["start"]) / TPS), "kind": h["kind"]} for h in self.hazards]
        mark = None
        if self.mark:
            mark = {"left": max(0, (self.mark["until"] - now) / TPS), "total": (self.mark["until"] - self.mark["start"]) / TPS}
        party = [{"name": a.name, "role": a.rrole, "cls": a.cls, "hp": int(a.hp), "maxhp": int(a.maxhp), "dead": a.dead} for a in self.allies]
        cur = self.current_room()
        bosses = [self.actors[i] for i in self.boss_ids]
        return {"name": self.d.name, "kind": self.kind, "level": self.level, "room": (cur["i"] if cur else -1), "rooms": len(self.rooms),
                "boss": boss, "hazards": haz, "mark": mark, "party": party, "portals": self.portals, "wipes": self.wipes, "done": self.done,
                "hint": self.hint if now < self.hint_until else "", "bosses_down": sum(1 for x in bosses if x.hp <= 0), "bosses": len(bosses),
                "elapsed": int((now - self.t0) / TPS), "pillars": sorted(self.pillars),
                "rest": self.rest_left(), "rest_total": int(self.rest_total / TPS), "portal_cd": max(0, (self.portal_cd - now + TPS - 1) // TPS)}

