#!/usr/bin/env python3
import faulthandler
import traceback
faulthandler.enable()          # 1.0.11: a hard crash (segfault in a C library) now leaves a Python traceback in startup.log
from .game import main

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
