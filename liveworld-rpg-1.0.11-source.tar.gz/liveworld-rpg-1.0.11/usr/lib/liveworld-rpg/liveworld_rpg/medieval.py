"""0.45: medieval European architecture for towns and cities.

Stone cottages, half-timbered houses, thatched huts, guild halls, a castle keep for the War Hall,
round watchtowers with conical roofs, and continuous curtain walls.  Everything is drawn on the
same 2x iso canvas as the rest of gfx (gfx._IsoCanvas), cached once, and keeps the old building
footprints so placement, collision and click areas are unchanged.

Faces: in this iso view the visible walls of a box are the "front-left" face (y = y1, running
along x) and the "front-right" face (x = x1, running along y).  Light comes from the upper left,
so the front-right face is lit and the front-left face sits in light shade.
"""
import math
import pygame
from .gfx import _IsoCanvas, shade, mix, h01, _lantern

# ------------------------------------------------------------------ palettes
# 0.46.31: stone and plaster are darker so walls, cover and buildings stand out against the pale ground
def _dk(pal, f): return {k: tuple(int(c * f) for c in v) for k, v in pal.items()}
STONE = _dk({"Alliance": (150, 156, 172), "Horde": (172, 128, 120), "Neutral": (168, 156, 136), "Dungeon": (120, 116, 128)}, .6)
PLASTER = _dk({"Alliance": (212, 220, 238), "Horde": (232, 194, 184), "Neutral": (222, 206, 172), "Dungeon": (150, 146, 156)}, .7)
TIMBER = (70, 48, 32)
SLATE = {"Alliance": (56, 88, 176), "Horde": (170, 48, 42), "Neutral": (92, 96, 104), "Dungeon": (70, 66, 84)}
CLAY = (164, 74, 50)
THATCH = (196, 164, 96)
SHINGLE = (124, 88, 56)
GLASS = (255, 214, 140)
TEAM_ROOF = {"Alliance": (56, 88, 176), "Horde": (170, 48, 42)}     # 0.46.7: every Alliance city is blue, every Horde city is red


def team_roof(style, mat, rc):
    """Alliance and Horde buildings always wear their side's colour (thatch becomes clay tile)."""
    if style in TEAM_ROOF:
        return ("clay" if mat == "thatch" else mat), TEAM_ROOF[style]
    return mat, rc
LIT_F, SHADE_F = 1.0, .80          # front-right (lit) and front-left (shade) face brightness


def _lerp(a, b, t): return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)


class Face:
    """One visible wall face from world corner A to B (left to right on screen), between heights z0 and z1."""
    def __init__(self, C, A, B, z0, z1, light):
        self.C, self.A, self.B, self.z0, self.z1, self.f = C, A, B, z0, z1, light
        self.len = math.hypot(B[0] - A[0], B[1] - A[1])
    def p(self, u, z):
        x, y = _lerp(self.A, self.B, u); return self.C.P(x, y, z)
    def quad(self, u0, u1, za, zb):
        return [self.p(u0, za), self.p(u1, za), self.p(u1, zb), self.p(u0, zb)]
    def poly(self):
        return self.quad(0, 1, self.z0, self.z1)


# ------------------------------------------------------------------ wall materials
def _stone_face(F, base, seed, rows_h=7.0, rough=False):
    """Coursed ashlar (or rubble when rough): every block its own tone, lit top edge, dark mortar under it."""
    C = F.C; k = C.k
    col = shade(base, F.f)
    C.poly(F.poly(), shade(col, .62))                       # mortar colour behind the blocks
    z = F.z0; r = 0
    while z < F.z1 - .5:
        hh = rows_h * (.8 + .5 * h01(seed, r, 11)) if rough else rows_h
        zt = min(F.z1, z + hh)
        u = -h01(seed, r, 12) * .3 if r % 2 else 0.0
        j = 0
        while u < 1:
            bl = (.16 + h01(seed + r, j, 13) * .14) / max(.5, F.len) * 1.6
            u0, u1 = max(0.0, u + .006), min(1.0, u + bl - .006)
            if u1 > u0:
                v = .86 + h01(seed + j, r, 14) * .26
                tint = mix(col, (150, 140, 110), .12) if h01(seed, r * 31 + j, 15) < .2 else col
                q = F.quad(u0, u1, z + .5, zt - .5)
                C.poly(q, shade(tint, v))
                pygame.draw.line(C.S, shade(tint, v * 1.16), q[3], q[2], max(1, k // 2))       # lit top edge
                pygame.draw.line(C.S, shade(tint, v * .78), q[0], q[1], max(1, k // 2))        # shaded bottom edge
            u += bl; j += 1
        z = zt; r += 1


def _brick_face(F, base, seed):
    """Small red-brown bricks in running bond."""
    C = F.C
    col = shade(base, F.f)
    C.poly(F.poly(), shade(col, .7))
    z = F.z0; r = 0
    while z < F.z1 - .5:
        zt = min(F.z1, z + 3.2); u = -.5 * (r % 2) * .07; j = 0
        while u < 1:
            bl = .07 / max(.5, F.len) * 1.6
            u0, u1 = max(0.0, u + .004), min(1.0, u + bl - .004)
            if u1 > u0:
                C.poly(F.quad(u0, u1, z + .4, zt - .4), shade(col, .88 + h01(seed + j, r, 21) * .24))
            u += bl; j += 1
        z = zt; r += 1


def _plaster_face(F, base, seed):
    """Lime plaster with soft weathering: lighter patches, a few stains, damp at the foot."""
    C = F.C; k = C.k
    col = shade(base, F.f)
    C.poly(F.poly(), col)
    def paint(lay, off):
        for n in range(26):
            u = h01(seed, n, 31); z = F.z0 + h01(seed, n, 32) * (F.z1 - F.z0)
            x, y = F.p(u, z); r = (3 + h01(seed, n, 33) * 7) * k
            c = (255, 252, 240, 26) if n % 3 else (90, 70, 50, 22)
            pygame.draw.ellipse(lay, c, (x - off[0] - r, y - off[1] - r * .6, r * 2, r * 1.2))
        for i in range(10):              # damp / dirt rising from the ground
            a = int(60 * (1 - i / 10) ** 2)
            p0, p1 = F.p(0, F.z0 + i), F.p(1, F.z0 + i)
            pygame.draw.line(lay, (60, 48, 36, a), (p0[0] - off[0], p0[1] - off[1]), (p1[0] - off[0], p1[1] - off[1]), k)
    C.masked(F.poly(), paint)


def _timber_frame(F, seed, z0=None, z1=None, braces=True):
    """Half-timbering over plaster: sill and head beams, posts, a mid rail and diagonal braces."""
    C = F.C; k = C.k
    z0 = F.z0 if z0 is None else z0; z1 = F.z1 if z1 is None else z1
    col = shade(TIMBER, F.f + .1); hi = shade(TIMBER, F.f * 1.45)
    def beam(a, b, w):
        pygame.draw.line(C.S, col, a, b, w * k)
        pygame.draw.line(C.S, hi, (a[0], a[1] - k), (b[0], b[1] - k), max(1, k // 2))
    beam(F.p(0, z0 + 1), F.p(1, z0 + 1), 2)
    beam(F.p(0, z1 - 1), F.p(1, z1 - 1), 2)
    n = max(2, int(round(F.len / .42)))
    for i in range(n + 1):
        u = i / n
        beam(F.p(u, z0), F.p(u, z1), 2)
    zm = (z0 + z1) / 2
    beam(F.p(0, zm), F.p(1, zm), 1)
    if braces:
        for i in range(n):
            if h01(seed, i, 41) < .55:
                u0, u1 = i / n, (i + 1) / n
                if h01(seed, i, 42) < .5: beam(F.p(u0, z0 + 1), F.p(u1, zm), 1); beam(F.p(u0, zm), F.p(u1, z1 - 1), 1)
                else: beam(F.p(u1, z0 + 1), F.p(u0, zm), 1); beam(F.p(u1, zm), F.p(u0, z1 - 1), 1)


def _eave_shadow(F, depth=10):
    """Soft shadow the roof casts on the top of the wall, plus contact darkening at the foot."""
    C = F.C; k = C.k
    def paint(lay, off):
        for i in range(depth):
            a = int(110 * (1 - i / depth) ** 1.7)
            p0, p1 = F.p(0, F.z1 - i), F.p(1, F.z1 - i)
            pygame.draw.line(lay, (24, 18, 14, a), (p0[0] - off[0], p0[1] - off[1]), (p1[0] - off[0], p1[1] - off[1]), k + 1)
        for i in range(5):
            a = int(70 * (1 - i / 5))
            p0, p1 = F.p(0, F.z0 + i), F.p(1, F.z0 + i)
            pygame.draw.line(lay, (20, 16, 12, a), (p0[0] - off[0], p0[1] - off[1]), (p1[0] - off[0], p1[1] - off[1]), k)
    C.masked(F.poly(), paint)


# ------------------------------------------------------------------ openings
def window(F, u, z, wu=.16, h=14, lit=GLASS, frame=TIMBER, shutters=False, arch=False, sill=True, bars=False):
    """A leaded window: deep recess, warm glass, mullion and transom, optional shutters, arch and stone sill."""
    C = F.C; k = C.k
    u0, u1 = u - wu / 2, u + wu / 2
    out = F.quad(u0 - .015, u1 + .015, z - 1.5, z + h + 1.5)
    C.poly(out, shade(frame, F.f + .1))
    rec = F.quad(u0, u1, z, z + h)
    C.poly(rec, (30, 24, 22))
    g = F.quad(u0 + .01, u1 - .01, z + 1, z + h - 1)
    C.poly(g, shade(lit, .92 + .08 * F.f))
    hl = F.quad(u0 + .01, u0 + (u1 - u0) * .45, z + h * .45, z + h - 1)        # sky / glow sheen in the upper left pane
    C.poly(hl, shade(lit, 1.12))
    pygame.draw.line(C.S, shade(frame, .8), F.p(u, z + 1), F.p(u, z + h - 1), k)
    pygame.draw.line(C.S, shade(frame, .8), F.p(u0, z + h * .55), F.p(u1, z + h * .55), k)
    if bars:
        for t in (.25, .75):
            uu = u0 + (u1 - u0) * t; pygame.draw.line(C.S, (40, 40, 46), F.p(uu, z), F.p(uu, z + h), k)
    if arch:
        top = [F.p(u0 + (u1 - u0) * i / 8, z + h + math.sin(math.pi * i / 8) * h * .3) for i in range(9)]
        pygame.draw.polygon(C.S, shade(frame, F.f + .1), [F.p(u0 - .015, z + h)] + top + [F.p(u1 + .015, z + h)])
        pygame.draw.polygon(C.S, shade(lit, .9), [F.p(u0 + .01, z + h)] + top[1:-1] + [F.p(u1 - .01, z + h)])
    if shutters:
        sc = (60, 92, 70) if h01(int(u * 100), int(z), 51) < .5 else (110, 54, 44)
        for a, b in ((u0 - wu * .55, u0 - .015), (u1 + .015, u1 + wu * .55)):
            q = F.quad(a, b, z - 1, z + h + 1); C.poly(q, shade(sc, F.f))
            for t in (.33, .66):
                pygame.draw.line(C.S, shade(sc, F.f * .7), F.p(a, z + (h + 2) * t - 1), F.p(b, z + (h + 2) * t - 1), max(1, k // 2))
    if sill:
        C.poly(F.quad(u0 - .03, u1 + .03, z - 3, z - 1), shade((176, 170, 158), F.f))


def door(F, u, wu=.2, h=24, z=None, col=(102, 66, 38), arch=True, stone=(150, 144, 132)):
    """Planked door with iron straps under a stone arch."""
    C = F.C; k = C.k; z = F.z0 if z is None else z
    u0, u1 = u - wu / 2, u + wu / 2
    def archpts(a, b, zz, rise):
        return [F.p(a + (b - a) * i / 10, zz + math.sin(math.pi * i / 10) * rise) for i in range(11)]
    surround = [F.p(u0 - .04, z)] + archpts(u0 - .04, u1 + .04, z + h + 2, h * .32 if arch else 0) + [F.p(u1 + .04, z)]
    pygame.draw.polygon(C.S, shade(stone, F.f), surround)
    body = [F.p(u0, z)] + archpts(u0, u1, z + h, h * .28 if arch else 0) + [F.p(u1, z)]
    pygame.draw.polygon(C.S, shade(col, F.f), body)
    for i in range(1, 4):                                        # planks
        uu = u0 + (u1 - u0) * i / 4
        pygame.draw.line(C.S, shade(col, F.f * .7), F.p(uu, z), F.p(uu, z + h + (h * .2 if arch else 0) * math.sin(math.pi * i / 4)), max(1, k // 2))
    for zz in (z + h * .25, z + h * .7):                         # iron straps with studs
        pygame.draw.line(C.S, (46, 42, 40), F.p(u0, zz), F.p(u1 - (u1 - u0) * .15, zz), k + 1)
    ring = F.p(u0 + (u1 - u0) * .78, z + h * .48)
    pygame.draw.circle(C.S, (60, 56, 50), (int(ring[0]), int(ring[1])), 2 * k, max(1, k // 2))
    C.poly([F.p(u0 - .05, z), F.p(u1 + .05, z), F.p(u1 + .05, z - 2), F.p(u0 - .05, z - 2)], shade(stone, F.f * .9))   # threshold step


# ------------------------------------------------------------------ roofs
def _slope_painter(material, base, seed, k):
    """Return paint(lay, off, edge0, edge1, top0, top1) that textures one roof slope quad.
    edge0->edge1 is the eave (bottom) line, top0->top1 the ridge line above it."""
    def P(e0, e1, t0, t1, s, t):
        a = _lerp(e0, e1, s); b = _lerp(t0, t1, s); return _lerp(a, b, t)
    def paint(lay, off, e0, e1, t0, t1, f):
        sh = lambda c, v=1.0: shade(c, f * v)
        o = lambda p: (p[0] - off[0], p[1] - off[1])
        pygame.draw.polygon(lay, sh(base), [o(e0), o(e1), o(t1), o(t0)])
        if material == "thatch":
            rows = 9
            for r in range(rows):
                t = r / rows
                for i in range(int(46 + 10 * (1 - t))):
                    s = (i + h01(seed + r, i, 61)) / (46 + 10 * (1 - t))
                    ln = (.12 + h01(seed, r * 97 + i, 62) * .1)
                    a = P(e0, e1, t0, t1, s, t + .02); b = P(e0, e1, t0, t1, s + (h01(i, r, 63) - .5) * .01, min(1, t + ln))
                    v = .72 + h01(seed + i, r, 64) * .5
                    pygame.draw.line(lay, sh(base, v), o(a), o(b), max(1, k - 1 + (i % 3 == 0)))
                for i in range(30):                                 # dark tuck line under each course
                    s0, s1 = i / 30, (i + 1) / 30
                    pygame.draw.line(lay, sh(base, .55), o(P(e0, e1, t0, t1, s0, t)), o(P(e0, e1, t0, t1, s1, t)), 1)
            ov = pygame.Surface(lay.get_size(), pygame.SRCALPHA)
            for i in range(14):                                     # moss / weathered patches
                s = h01(seed, i, 65); t = h01(seed, i, 66) * .8
                c = P(e0, e1, t0, t1, s, t); r = (4 + h01(i, seed, 67) * 6) * k
                pygame.draw.ellipse(ov, (*sh((110, 112, 60)), 40), (o(c)[0] - r, o(c)[1] - r * .5, r * 2, r))
            lay.blit(ov, (0, 0))
        else:
            rows = {"slate": 12, "clay": 9, "shingle": 11}.get(material, 10)
            cols = {"slate": 22, "clay": 18, "shingle": 16}.get(material, 18)
            for r in range(rows):
                ta, tb = r / rows, (r + 1) / rows
                shift = .5 if r % 2 else 0.0
                for i in range(-1, cols + 1):
                    s0 = (i + shift) / cols; s1 = (i + 1 + shift) / cols
                    if s1 <= 0 or s0 >= 1: continue
                    s0c, s1c = max(0, s0), min(1, s1)
                    v = .84 + h01(seed + i, r, 71) * .3
                    if material == "slate" and h01(seed, r * 53 + i, 72) < .07: v *= .78
                    q = [P(e0, e1, t0, t1, s0c + .004, ta), P(e0, e1, t0, t1, s1c - .004, ta), P(e0, e1, t0, t1, s1c - .004, tb + .02), P(e0, e1, t0, t1, s0c + .004, tb + .02)]
                    pygame.draw.polygon(lay, sh(base, v), [o(p) for p in q])
                    if material == "clay":                              # rounded pantile: lit crown, dark trough
                        m0 = P(e0, e1, t0, t1, (s0c + s1c) / 2 - .008, ta); m1 = P(e0, e1, t0, t1, (s0c + s1c) / 2 - .008, tb)
                        pygame.draw.line(lay, sh(base, v * 1.25), o(m0), o(m1), k)
                        pygame.draw.line(lay, sh(base, v * .6), o(q[1]), o(q[2]), max(1, k // 2))
                # course shadow: the row above overlaps this one
                pygame.draw.line(lay, sh(base, .5), o(P(e0, e1, t0, t1, 0, ta)), o(P(e0, e1, t0, t1, 1, ta)), max(1, k // 2) + (material != "slate"))
            ov = pygame.Surface(lay.get_size(), pygame.SRCALPHA)
            for i in range(10 if material != "clay" else 5):      # lichen
                s = h01(seed, i, 75); t = h01(seed, i, 76) * .7; c = P(e0, e1, t0, t1, s, t); r = (2 + h01(i, seed, 77) * 4) * k
                pygame.draw.ellipse(ov, (*sh((150, 150, 90)), 46), (o(c)[0] - r, o(c)[1] - r * .5, r * 2, r))
            lay.blit(ov, (0, 0))
        # sheen toward the ridge, darker toward the eave (reads as a slope, not a flat card)
        ov = pygame.Surface(lay.get_size(), pygame.SRCALPHA)
        for i in range(8):
            t = i / 8
            a = P(e0, e1, t0, t1, 0, t); b = P(e0, e1, t0, t1, 1, t); a2 = P(e0, e1, t0, t1, 0, t + 1 / 8); b2 = P(e0, e1, t0, t1, 1, t + 1 / 8)
            al = int(26 * t) if t > .4 else 0
            dk = int(40 * (1 - t / .4)) if t < .4 else 0
            if al: pygame.draw.polygon(ov, (255, 250, 230, al), [o(a), o(b), o(b2), o(a2)])
            if dk: pygame.draw.polygon(ov, (20, 14, 10, dk), [o(a), o(b), o(b2), o(a2)])
        lay.blit(ov, (0, 0))
    return paint


def gable_roof(C, x0, y0, x1, y1, z, rise, material, base, seed, over=.18, axis="x", gable_wall=None):
    """A pitched gable roof over the box (x0..x1, y0..y1) with eaves at height z.
    axis="x": ridge runs along x -> the front-left slope and the right gable end are visible.
    axis="y": ridge runs along y -> the front-right slope and the left gable end are visible.
    gable_wall(face) paints the triangular gable (timber, stone...).  Returns the ridge end points."""
    k = C.k
    paint = _slope_painter(material, base, seed, k)
    thick = 6 if material == "thatch" else 3
    if axis == "x":
        yc = (y0 + y1) / 2
        e0, e1 = C.P(x0 - over, y1 + over, z), C.P(x1 + over, y1 + over, z)
        t0, t1 = C.P(x0 - over, yc, z + rise), C.P(x1 + over, yc, z + rise)
        # gable end on the lit right face (x = x1): a wall triangle, then the roof's edge over it
        tri = [C.P(x1, y1, z), C.P(x1, y0, z), C.P(x1, yc, z + rise)]
        if gable_wall: gable_wall(tri, LIT_F)
        # back slope edge seen past the gable (thin dark sliver)
        b0, b1 = C.P(x1 + over, y0 - over, z), C.P(x1 + over, yc, z + rise)
        pygame.draw.line(C.S, shade(base, .45), b0, b1, thick * k)
        quad = [e0, e1, t1, t0]; f = .92
    else:
        xc = (x0 + x1) / 2
        e0, e1 = C.P(x1 + over, y1 + over, z), C.P(x1 + over, y0 - over, z)
        t0, t1 = C.P(xc, y1 + over, z + rise), C.P(xc, y0 - over, z + rise)
        tri = [C.P(x0, y1, z), C.P(x1, y1, z), C.P(xc, y1, z + rise)]
        if gable_wall: gable_wall(tri, SHADE_F)
        b0, b1 = C.P(x0 - over, y1 + over, z), C.P(xc, y1 + over, z + rise)
        pygame.draw.line(C.S, shade(base, .45), b0, b1, thick * k)
        quad = [e0, e1, t1, t0]; f = 1.04
    def painter(lay, off): paint(lay, off, e0, e1, t0, t1, f)
    C.masked(quad, painter)
    # eave thickness and barge boards
    pygame.draw.line(C.S, shade(base, .42 * f), (e0[0], e0[1] + thick * k * .5), (e1[0], e1[1] + thick * k * .5), thick * k)
    pygame.draw.line(C.S, shade(base, 1.18 * f), e0, e1, max(1, k))
    edge = (e1, t1) if axis == "x" else (e0, t0)
    pygame.draw.line(C.S, shade(TIMBER if material != "thatch" else base, .8), edge[0], edge[1], (thick + 1) * k)
    pygame.draw.line(C.S, shade(base, 1.2), (edge[0][0] - k, edge[0][1]), (edge[1][0] - k, edge[1][1]), max(1, k // 2))
    # ridge cap
    ridge_c = shade(base, .7) if material != "thatch" else shade(base, .62)
    pygame.draw.line(C.S, ridge_c, t0, t1, (5 if material == "thatch" else 3) * k)
    pygame.draw.line(C.S, shade(ridge_c, 1.5), (t0[0], t0[1] - k), (t1[0], t1[1] - k), max(1, k // 2))
    return t0, t1


def conical_roof(C, cx, cy, r, z, rise, base, seed, material="slate", finial=True, flag=None):
    """Conical (candle-snuffer) roof for round towers: tiled bands, a lit side and a shaded side."""
    k = C.k
    n = 40
    rim = [C.P(cx + math.cos(a) * r, cy + math.sin(a) * r, z) for a in (i / n * math.tau for i in range(n))]
    apex = C.P(cx, cy, z + rise)
    for i in range(n):
        a = (i + .5) / n * math.tau
        nx, ny = math.cos(a), math.sin(a)
        lit = .62 + .5 * max(0.0, (nx * .55 + ny * .35 + .55))   # brighter facing front-right
        lit = min(1.15, lit)
        p0, p1 = rim[i], rim[(i + 1) % n]
        if (p0[1] + p1[1]) / 2 < C.P(cx, cy, z)[1] - 1: continue      # back half hidden
        pygame.draw.polygon(C.S, shade(base, lit), [p0, p1, apex])
    vis = [p for p in rim if p[1] >= C.P(cx, cy, z)[1] - 1]
    for b in range(1, 8):                                  # tile courses
        t = b / 8
        row = [_lerp(p, apex, t) for p in rim]
        rowv = [p for p, q in zip(row, rim) if q[1] >= C.P(cx, cy, z)[1] - 1]
        if len(rowv) > 1: pygame.draw.lines(C.S, shade(base, .55), False, sorted(rowv), max(1, k // 2))
    if len(vis) > 1:
        vs = sorted(vis)
        pygame.draw.lines(C.S, shade(base, .4), False, [(p[0], p[1] + k) for p in vs], 2 * k)
    if finial:
        pygame.draw.line(C.S, (60, 56, 52), apex, (apex[0], apex[1] - 16 * k), 2 * k)
        pygame.draw.circle(C.S, (200, 168, 80), (int(apex[0]), int(apex[1] - 3 * k)), 2 * k)
        if flag:
            top = (apex[0], apex[1] - 16 * k)
            pygame.draw.polygon(C.S, flag, [top, (top[0] + 16 * k, top[1] + 3 * k), (top[0] + 2 * k, top[1] + 8 * k)])
            pygame.draw.line(C.S, shade(flag, 1.3), top, (top[0] + 15 * k, top[1] + 3 * k), max(1, k // 2))
    return apex


def chimney(C, x, y, z, h, stone, seed):
    """A square stone chimney stack with a cap and soot at the top."""
    k = C.k; s = .13
    Fl = Face(C, (x - s, y + s), (x + s, y + s), z, z + h, SHADE_F)
    Fr = Face(C, (x + s, y + s), (x + s, y - s), z, z + h, LIT_F)
    for F in (Fl, Fr): _stone_face(F, stone, seed, 4.0)
    top = [C.P(x - s - .03, y - s - .03, z + h + 2), C.P(x + s + .03, y - s - .03, z + h + 2), C.P(x + s + .03, y + s + .03, z + h + 2), C.P(x - s - .03, y + s + .03, z + h + 2)]
    C.poly([C.P(x - s - .03, y + s + .03, z + h), C.P(x + s + .03, y + s + .03, z + h), top[2], top[3]], shade(stone, .7))
    C.poly([C.P(x + s + .03, y + s + .03, z + h), C.P(x + s + .03, y - s - .03, z + h), top[1], top[2]], shade(stone, .9))
    C.poly(top, shade(stone, 1.1))
    C.poly([C.P(x - s + .04, y - s + .04, z + h + 2), C.P(x + s - .04, y - s + .04, z + h + 2), C.P(x + s - .04, y + s - .04, z + h + 2), C.P(x - s + .04, y + s - .04, z + h + 2)], (30, 26, 24))


def contact_shadow(C, x0, y0, x1, y1, grow=.35, alpha=70):
    """Soft ambient-occlusion pool hugging the footprint (the sun's cast shadow is drawn by the game)."""
    k = C.k
    for i in range(6):                   # stacked layers: alpha builds up toward the walls
        g = grow * (1 - i / 6)
        pts = [C.P(x0 - g, y0 - g), C.P(x1 + g, y0 - g), C.P(x1 + g, y1 + g), C.P(x0 - g, y1 + g)]
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        bx, by = int(min(xs)), int(min(ys))
        lay = pygame.Surface((int(max(xs)) - bx + 2, int(max(ys)) - by + 2), pygame.SRCALPHA)
        pygame.draw.polygon(lay, (14, 12, 10, alpha // 5), [(p[0] - bx, p[1] - by) for p in pts])
        C.S.blit(lay, (bx, by))


def plinth(C, x0, y0, x1, y1, h, stone, seed):
    for F in (Face(C, (x0, y1), (x1, y1), 0, h, SHADE_F), Face(C, (x1, y1), (x1, y0), 0, h, LIT_F)):
        _stone_face(F, shade(stone, .85), seed, h / 2 if h > 4 else h, rough=True)
    C.poly([C.P(x0, y0, h), C.P(x1, y0, h), C.P(x1, y1, h), C.P(x0, y1, h)], shade(stone, 1.0))


# ------------------------------------------------------------------ building kinds
ROOF_FOR = {  # (material, colour) per station; colours stay distinctive so each shop is easy to find
    "forge": ("slate", (70, 72, 80)), "smithy": ("slate", (72, 82, 104)), "hut": ("thatch", THATCH),
    "press": ("clay", (150, 62, 60)), "warhall": ("slate", (120, 40, 36)), "magic": ("slate", (84, 60, 140)),
    "apothecary": ("shingle", (70, 112, 72)), "inn": ("clay", CLAY), "jeweler": ("slate", (52, 112, 124)),
    "kiln": ("clay", (130, 70, 56)), "general": ("shingle", SHINGLE), "enchanter": ("slate", (58, 72, 150)),
    "bank": ("slate", (64, 88, 70)), "stable": ("thatch", (186, 156, 88)), "market": ("clay", (52, 128, 120)), "teleport": ("slate", (40, 150, 170)),
}
WALL_FOR = {  # ground floor / upper floor style per station
    "forge": "stone", "smithy": "stone", "hut": "plank", "press": "timber", "warhall": "keep", "magic": "tower",
    "apothecary": "timber", "inn": "timber", "jeweler": "stone", "kiln": "brick", "general": "timber",
    "enchanter": "stone", "bank": "stone", "stable": "plank", "market": "timber", "teleport": "tower",
}


def _plank_face(F, base, seed):
    """Vertical weathered boards (huts, stables, barns)."""
    C = F.C; k = C.k
    col = shade(base, F.f)
    C.poly(F.poly(), col)
    n = max(4, int(F.len * 9))
    for i in range(n):
        u0, u1 = i / n, (i + 1) / n
        v = .82 + h01(seed, i, 81) * .3
        C.poly(F.quad(u0 + .002, u1 - .002, F.z0, F.z1), shade(col, v))
        pygame.draw.line(C.S, shade(col, .55), F.p(u1, F.z0), F.p(u1, F.z1), max(1, k // 2))
        if h01(seed, i, 82) < .3:     # knot
            q = F.p((u0 + u1) / 2, F.z0 + h01(i, seed, 83) * (F.z1 - F.z0))
            pygame.draw.circle(C.S, shade(col, .6), (int(q[0]), int(q[1])), max(1, k))
    for zz in (F.z0 + 3, F.z1 - 4):
        pygame.draw.line(C.S, shade(col, .62), F.p(0, zz), F.p(1, zz), 2 * k)


def walls(C, x0, y0, x1, y1, z0, z1, style, kind, seed, stone, plaster):
    """Paint the two visible faces of a building body.  Returns (left_face, right_face) for openings."""
    Fl = Face(C, (x0, y1), (x1, y1), z0, z1, SHADE_F)
    Fr = Face(C, (x1, y1), (x1, y0), z0, z1, LIT_F)
    if kind in ("stone", "keep", "tower"):
        for F in (Fl, Fr): _stone_face(F, stone, seed + (F is Fr) * 7)
    elif kind == "brick":
        for F in (Fl, Fr): _brick_face(F, (150, 80, 60), seed)
    elif kind == "plank":
        for F in (Fl, Fr): _plank_face(F, (130, 96, 64), seed)
    else:   # timber: stone ground floor, half-timbered plaster upper floor
        zs = z0 + (z1 - z0) * .45
        for F in (Fl, Fr):
            G = Face(C, F.A, F.B, z0, zs, F.f); _stone_face(G, stone, seed + 3, 6.0, rough=True)
            U = Face(C, F.A, F.B, zs, z1, F.f); _plaster_face(U, plaster, seed); _timber_frame(U, seed + (F is Fr) * 5)
            pygame.draw.line(C.S, shade(TIMBER, F.f), F.p(0, zs), F.p(1, zs), 3 * C.k)       # jetty beam
    for F in (Fl, Fr): _eave_shadow(F)
    # corner quoins: big dressed stones up the front corner
    if kind in ("stone", "timber", "keep", "brick"):
        zq = z1 if kind != "timber" else z0 + (z1 - z0) * .45
        z = z0; i = 0
        while z < zq - 1:
            hh = min(6.0, zq - z)
            ql = Fl.quad(1 - .1 * (1.3 if i % 2 else 1), 1, z + .4, z + hh - .4)
            qr = Fr.quad(0, .1 * (1 if i % 2 else 1.3), z + .4, z + hh - .4)
            C.poly(ql, shade(stone, SHADE_F * 1.08)); C.poly(qr, shade(stone, LIT_F * 1.1))
            z += hh; i += 1
    return Fl, Fr


def _gable_painter(C, kind, stone, plaster, seed):
    def paint_tri(tri, f):
        if kind in ("stone", "keep", "tower", "brick"):
            col = shade(stone if kind != "brick" else (150, 80, 60), f)
            C.poly(tri, col)
            def lines(lay, off):
                ys = [p[1] for p in tri]
                for yy in range(int(min(ys)), int(max(ys)), 7 * C.k):
                    pygame.draw.line(lay, shade(col, .7), (0, yy - off[1]), (lay.get_width(), yy - off[1]), 1)
            C.masked(tri, lines)
        elif kind == "plank":
            C.poly(tri, shade((130, 96, 64), f))
            def boards(lay, off):
                xs = [p[0] for p in tri]
                for xx in range(int(min(xs)), int(max(xs)), 5 * C.k):
                    pygame.draw.line(lay, shade((130, 96, 64), f * .6), (xx - off[0], 0), (xx - off[0], lay.get_height()), 1)
            C.masked(tri, boards)
        else:
            C.poly(tri, shade(plaster, f))
            a, b, c = tri
            pygame.draw.line(C.S, shade(TIMBER, f), a, c, 2 * C.k); pygame.draw.line(C.S, shade(TIMBER, f), b, c, 2 * C.k)
            m = _lerp(a, b, .5)
            pygame.draw.line(C.S, shade(TIMBER, f), m, c, 2 * C.k)
            pygame.draw.line(C.S, shade(TIMBER, f), _lerp(a, c, .5), _lerp(b, c, .5), 2 * C.k)
        # a small vent / owl hole in the gable
        cen = ((tri[0][0] + tri[1][0] + tri[2][0]) / 3, (tri[0][1] + tri[1][1] + tri[2][1]) / 3)
        pygame.draw.ellipse(C.S, (34, 28, 24), (cen[0] - 3 * C.k, cen[1] - 2 * C.k, 6 * C.k, 5 * C.k))
    return paint_tri


def house(style, var):
    """Town house: stone cottage, timber-framed house or thatched cottage, picked by var."""
    C = _IsoCanvas((900, 1100), (450, 860)); k = C.k
    stone = shade(STONE.get(style, STONE["Neutral"]), .95 + (var % 3) * .04)
    plaster = shade(PLASTER.get(style, PLASTER["Neutral"]), .97 + (var % 2) * .03)
    w = d = 2.0; a = .16; ph = 5
    seed = var * 17 + len(style)
    contact_shadow(C, a, a, w - a, d - a)
    plinth(C, a - .04, a - .04, w - a + .04, d - a + .04, ph, stone, seed)
    typ = ("timber", "stone", "timber", "thatch")[var % 4]
    hgt = (58, 46, 62, 40)[var % 4]
    wk = "stone" if typ == "stone" else "timber" if typ == "timber" else "plank" if style == "Horde" else "stone"
    if typ == "thatch": wk = "timber"
    Fl, Fr = walls(C, a, a, w - a, d - a, ph, hgt, style, wk, seed, stone, plaster)
    # door and windows
    door(Fl, .5, .2, 24)
    if hgt > 50:
        for u in (.18, .82): window(Fl, u, ph + 9, .14, 12, shutters=True)
        for u in (.25, .75): window(Fr, u, ph + 9, .15, 12, shutters=True)
        for u in (.22, .5, .78): window(Fl, u, hgt - 22, .12, 12, sill=False)
        for u in (.3, .7): window(Fr, u, hgt - 22, .13, 12, sill=False)
    else:
        for u in (.16, .84): window(Fl, u, ph + 11, .14, 13, shutters=True)
        window(Fr, .5, ph + 11, .2, 13, shutters=True)
    # flower box under one window
    if var % 2 == 0:
        q = Fr.quad(.17, .33, ph + 5, ph + 8); C.poly(q, (96, 66, 40))
        for j in range(6):
            fp = Fr.p(.19 + j * .025, ph + 9)
            pygame.draw.circle(C.S, ((210, 70, 90), (240, 200, 80), (190, 90, 170))[j % 3], (int(fp[0]), int(fp[1])), k + 1)
    if typ == "thatch" and style not in TEAM_ROOF:
        mat, rc = "thatch", THATCH
    elif style == "Horde":
        mat, rc = ("clay", CLAY) if var % 2 else ("shingle", SHINGLE)
    elif style == "Alliance":
        mat, rc = "slate", SLATE["Alliance"]
    else:
        mat, rc = ("slate", SLATE["Neutral"]) if var % 2 else ("clay", shade(CLAY, .95))
    axis = "x" if var % 2 == 0 else "y"
    mat, rc = team_roof(style, mat, rc)
    rise = 36 if mat == "thatch" else 34 + (var % 3) * 4
    gable_roof(C, a, a, w - a, d - a, hgt, rise, mat, rc, seed, over=.2 if mat == "thatch" else .14, axis=axis,
               gable_wall=_gable_painter(C, wk, stone, plaster, seed))
    cx_, cy_ = (w * .7, d * .5) if axis == "x" else (w * .5, d * .3)
    chimney(C, cx_, cy_, hgt + rise * .45, rise * .75, shade(stone, .9), seed)
    _lantern(C, Fl.p(.72, ph + 30), 4, .8)
    spr, anc = C.crop((0, 0, 0))
    return (spr, anc, w, d)


def round_tower(C, cx, cy, r, z0, z1, stone, seed, battlements=False):
    """A round stone tower body (cylinder) with shaded masonry and arrow slits."""
    k = C.k; n = 36
    cols = []
    for i in range(n):
        a0 = i / n * math.tau; a1 = (i + 1) / n * math.tau; am = (a0 + a1) / 2
        nx, ny = math.cos(am), math.sin(am)
        if nx + ny < -.15: continue                         # faces pointing away from the camera
        lit = .66 + .44 * max(0.0, nx * .9 + ny * .1)
        p00, p10 = C.P(cx + math.cos(a0) * r, cy + math.sin(a0) * r, z0), C.P(cx + math.cos(a1) * r, cy + math.sin(a1) * r, z0)
        p01, p11 = C.P(cx + math.cos(a0) * r, cy + math.sin(a0) * r, z1), C.P(cx + math.cos(a1) * r, cy + math.sin(a1) * r, z1)
        col = shade(stone, lit)
        C.poly([p00, p10, p11, p01], col)
        z = z0; row = 0
        while z < z1:                                      # coursed blocks
            zt = min(z1, z + 7)
            if (i + row) % 3 == 0:
                pygame.draw.line(C.S, shade(col, .66), C.P(cx + math.cos(a0) * r, cy + math.sin(a0) * r, z), C.P(cx + math.cos(a0) * r, cy + math.sin(a0) * r, zt), max(1, k // 2))
            v = .9 + h01(seed + i, row, 91) * .2
            C.poly([C.P(cx + math.cos(a0) * r, cy + math.sin(a0) * r, z + .5), C.P(cx + math.cos(a1) * r, cy + math.sin(a1) * r, z + .5),
                    C.P(cx + math.cos(a1) * r, cy + math.sin(a1) * r, zt - .5), C.P(cx + math.cos(a0) * r, cy + math.sin(a0) * r, zt - .5)], shade(col, v))
            pygame.draw.line(C.S, shade(col, .62), C.P(cx + math.cos(a0) * r, cy + math.sin(a0) * r, z), C.P(cx + math.cos(a1) * r, cy + math.sin(a1) * r, z), max(1, k // 2))
            z = zt; row += 1
        cols.append((am, lit))
    for am in (math.pi * .25 + .35, math.pi * .25 - .45):  # arrow slits
        for zz in (z0 + (z1 - z0) * .35, z0 + (z1 - z0) * .7):
            p = C.P(cx + math.cos(am) * r * 1.01, cy + math.sin(am) * r * 1.01, zz)
            pygame.draw.rect(C.S, (24, 20, 18), (p[0] - k, p[1] - 6 * k, 2 * k + 1, 12 * k))
    if battlements:
        ring = []
        for i in range(24):
            a = i / 24 * math.tau
            nx, ny = math.cos(a), math.sin(a)
            if nx + ny < -.4: continue
            if i % 2 == 0:
                a1 = a + math.tau / 24
                q = [C.P(cx + math.cos(a) * r * 1.06, cy + math.sin(a) * r * 1.06, z1), C.P(cx + math.cos(a1) * r * 1.06, cy + math.sin(a1) * r * 1.06, z1),
                     C.P(cx + math.cos(a1) * r * 1.06, cy + math.sin(a1) * r * 1.06, z1 + 8), C.P(cx + math.cos(a) * r * 1.06, cy + math.sin(a) * r * 1.06, z1 + 8)]
                C.poly(q, shade(stone, .7 + .45 * max(0.0, nx * .9)))
    # eave shadow ring under the top
    return cols


def tower(style, var):
    """City watchtower: a round stone tower with a conical slate roof and a banner."""
    C = _IsoCanvas((700, 1200), (350, 1000)); k = C.k
    stone = STONE.get(style, STONE["Neutral"])
    w = d = 1.4; cx = cy = w / 2; r = .62
    contact_shadow(C, 0, 0, w, d, .3)
    seed = 300 + var
    round_tower(C, cx, cy, r + .05, 0, 8, shade(stone, .85), seed)
    round_tower(C, cx, cy, r, 8, 92, stone, seed)
    # corbelled walkway ring
    ring = [C.P(cx + math.cos(a) * r * 1.12, cy + math.sin(a) * r * 1.12, 92) for a in (i / 40 * math.tau for i in range(41))]
    vis = [p for i, p in enumerate(ring) if math.cos(i / 40 * math.tau) + math.sin(i / 40 * math.tau) > -.5]
    if len(vis) > 2: pygame.draw.lines(C.S, shade(stone, .6), False, vis, 3 * k)
    roof_c = TEAM_ROOF.get(style, SLATE["Neutral"])
    flag = {"Alliance": (52, 92, 196), "Horde": (178, 40, 36)}.get(style, (200, 170, 70))
    conical_roof(C, cx, cy, r * 1.22, 94, 56, roof_c, seed, flag=flag)
    # windows on the lit side
    for zz in (34, 62):
        p = C.P(cx + math.cos(.5) * r * 1.01, cy + math.sin(.5) * r * 1.01, zz)
        pygame.draw.rect(C.S, (40, 30, 26), (p[0] - 4 * k, p[1] - 9 * k, 8 * k, 12 * k))
        pygame.draw.rect(C.S, GLASS, (p[0] - 3 * k, p[1] - 8 * k, 6 * k, 10 * k))
    # door
    dp = C.P(cx + math.cos(1.3) * r, cy + math.sin(1.3) * r, 8)
    pygame.draw.rect(C.S, (90, 60, 36), (dp[0] - 6 * k, dp[1] - 22 * k, 12 * k, 22 * k))
    pygame.draw.ellipse(C.S, (90, 60, 36), (dp[0] - 6 * k, dp[1] - 27 * k, 12 * k, 10 * k))
    spr, anc = C.crop((0, 0, 0))
    return (spr, anc, w, d)


def station(kind, style, decorate):
    """A shop / guild building.  decorate(C, onL, onR, w, d, a, ph, hgt) adds the shop's sign and props
    (the old per-shop decorations, kept so every shop is still recognisable)."""
    C = _IsoCanvas((900, 1200), (450, 960)); k = C.k
    stone = STONE.get(style, STONE["Neutral"]); plaster = PLASTER.get(style, PLASTER["Neutral"])
    w = d = 2.0; a = .14; ph = 6
    seed = sum(map(ord, kind)) * 3
    mat, rc = team_roof(style, *ROOF_FOR.get(kind, ("slate", SLATE["Neutral"])))
    wk = WALL_FOR.get(kind, "timber")
    hgt = {"inn": 70, "warhall": 72, "bank": 66, "magic": 64, "teleport": 66, "hut": 46, "stable": 50, "kiln": 44}.get(kind, 58)
    contact_shadow(C, a, a, w - a, d - a)
    plinth(C, 0, 0, w, d, ph, stone, seed)
    Fl, Fr = walls(C, a, a, w - a, d - a, ph, hgt, style, "stone" if wk in ("keep", "tower") else wk, seed, stone, plaster)
    def onL(t, z): return Fl.p(t, z)
    def onR(t, z): return Fr.p(t, z)
    door(Fl, .5, .2, 26, ph)
    decorate(C, onL, onR, w, d, a, ph, hgt, Fl, Fr)
    if wk == "keep":
        # War Hall: a castle keep - battlemented parapet, corner turrets, banners
        z = hgt
        for F in (Fl, Fr):
            n = 7
            for i in range(n):
                if i % 2 == 0:
                    q = F.quad(i / n, (i + 1) / n, z, z + 10)
                    C.poly(q, shade(stone, F.f * (.95 + h01(seed, i, 99) * .1)))
                    pygame.draw.line(C.S, shade(stone, F.f * 1.25), q[3], q[2], max(1, k // 2))
            pygame.draw.line(C.S, shade(stone, .55), F.p(0, z), F.p(1, z), 2 * k)
        C.poly([C.P(a, a, z), C.P(w - a, a, z), C.P(w - a, d - a, z), C.P(a, d - a, z)], shade(stone, .78))     # roof walk
        round_tower(C, w - a, d - a, .3, z - 30, z + 22, stone, seed, battlements=True)
        conical_roof(C, w - a, d - a, .36, z + 30, 30, rc, seed, flag=(178, 40, 36) if style == "Horde" else (52, 92, 196) if style == "Alliance" else (200, 170, 70))
        round_tower(C, a, d - a, .24, z - 20, z + 12, stone, seed + 1, battlements=True)
        round_tower(C, w - a, a, .24, z - 20, z + 12, stone, seed + 2, battlements=True)
    elif wk == "tower":
        # Skill Shop: a wizard's tower rising from the hall
        gable_roof(C, a, a, w - a, d - a, hgt, 30, mat, rc, seed, .14, "x", _gable_painter(C, "stone", stone, plaster, seed))
        round_tower(C, w * .62, d * .45, .34, hgt + 6, hgt + 64, shade(stone, .95), seed)
        conical_roof(C, w * .62, d * .45, .44, hgt + 64, 54, rc, seed)
    else:
        rise = {"thatch": 40, "clay": 34, "shingle": 36}.get(mat, 36)
        axis = "x" if kind not in ("inn", "bank", "general", "stable") else "y"
        gable_roof(C, a, a, w - a, d - a, hgt, rise, mat, rc, seed, over=.2 if mat == "thatch" else .15, axis=axis,
                   gable_wall=_gable_painter(C, wk, stone, plaster, seed))
        if kind in ("forge", "smithy", "kiln", "inn"):
            chimney(C, w * .72 if axis == "x" else w * .5, d * .5 if axis == "x" else d * .3, hgt + rise * .4, rise * .9 + (12 if kind in ("forge", "kiln") else 0), shade(stone, .85), seed)
    _lantern(C, Fl.p(.3, ph + 30), 4, .85); _lantern(C, Fl.p(.7, ph + 30), 4, .85)
    spr, anc = C.crop((0, 0, 0))
    return (spr, anc, w, d)


# ------------------------------------------------------------------ curtain walls
# A wall tile joins its neighbours: a stretch of wall runs from the tile's centre towards each neighbour
# (diagonal neighbours too), so a ring of tiles reads as one continuous wall instead of a staircase.
DIRS = ((1, 0), (0, 1), (-1, 0), (0, -1), (1, 1), (-1, 1), (-1, -1), (1, -1))


def wall_mask(walls_set, x, y):
    """Bitmask of neighbouring wall tiles (bits follow DIRS); a diagonal counts only when no orthogonal path joins them."""
    m = 0
    for i, (dx, dy) in enumerate(DIRS):
        if (x + dx, y + dy) in walls_set:
            if i >= 4 and ((x + dx, y) in walls_set or (x, y + dy) in walls_set): continue
            m |= 1 << i
    return m


def curtain_wall(style, mask, post=False, H=46, ruined=False):
    """One tile of city wall: thick stone runs toward each joined neighbour, a crenellated parapet with a walkway,
    and a round tower when post is True.  ruined=True (battleground cover): lower, broken merlons, rubble."""
    C = _IsoCanvas((420, 520), (210, 380)); k = C.k
    stone = STONE.get(style, STONE["Neutral"])
    T = .26 if not ruined else .3        # half thickness (tiles)
    seed = mask * 13 + len(style)
    cx = cy = .5
    runs = [(DIRS[i][0], DIRS[i][1]) for i in range(8) if mask >> i & 1]
    if not runs: runs = [(1, 0), (-1, 0)]
    # draw runs back to front: those pointing away from the camera first
    runs.sort(key=lambda v: v[0] + v[1])
    contact_shadow(C, cx - .5, cy - .5, cx + .5, cy + .5, .15, 50)
    def run_box(dx, dy):
        L = math.hypot(dx, dy) * .5 + T * .2
        ux, uy = dx / math.hypot(dx, dy), dy / math.hypot(dx, dy); nx, ny = -uy, ux
        A = (cx - nx * T, cy - ny * T); B = (cx + nx * T, cy + ny * T)
        A2 = (A[0] + ux * L, A[1] + uy * L); B2 = (B[0] + ux * L, B[1] + uy * L)
        return A, B, A2, B2, (ux, uy), (nx, ny)
    for dx, dy in runs:
        A, B, A2, B2, u, nrm = run_box(dx, dy)
        # the two long sides; only those facing the camera (normal with +x or +y) get painted as faces
        for P0, P1, side in ((A, A2, -1), (B, B2, 1)):
            nx_, ny_ = nrm[0] * side, nrm[1] * side
            if nx_ + ny_ <= 0.01: continue
            f = .74 + .3 * max(0.0, nx_ * .95 - ny_ * .1)
            Fa, Fb = (P0, P1) if (P1[0] - P1[1]) > (P0[0] - P0[1]) else (P1, P0)
            F = Face(C, Fa, Fb, 0, H, min(1.05, f))
            _stone_face(F, stone, seed + int(side * 3 + dx * 7 + dy * 11))
            for i in range(2):          # rain streaks and moss at the foot
                uu = .25 + i * .45
                pygame.draw.line(C.S, shade(stone, f * .74), F.p(uu, H - 2), F.p(uu, H * .45), max(1, k // 2))
                q = F.p(uu + .1, 0); pygame.draw.ellipse(C.S, (86, 112, 64), (q[0] - 4 * k, q[1] - 5 * k, 8 * k, 6 * k))
            _eave_shadow(F, 4)
        # end cap facing the camera at the far end of the run
        en = (u[0], u[1])
        if en[0] + en[1] > .01:
            F = Face(C, A2 if (A2[0] - A2[1]) < (B2[0] - B2[1]) else B2, B2 if (A2[0] - A2[1]) < (B2[0] - B2[1]) else A2, 0, H, .9)
            _stone_face(F, stone, seed + 5)
        # walkway on top
        C.poly([C.P(*A, H), C.P(*A2, H), C.P(*B2, H), C.P(*B, H)], shade(stone, .82))
        # merlons along both parapet edges
        n = 3
        for P0, P1 in ((A, A2), (B, B2)):
            for j in range(n):
                if ruined and h01(seed + j, int(P0[0] * 7 + P0[1] * 3), 97) < .45: continue      # broken parapet
                t0, t1 = (j + .15) / n, (j + .62) / n
                a_, b_ = _lerp(P0, P1, t0), _lerp(P0, P1, t1)
                inn = (-nrm[0] * .06 if P0 is B else nrm[0] * .06, -nrm[1] * .06 if P0 is B else nrm[1] * .06)
                a2, b2 = (a_[0] + inn[0], a_[1] + inn[1]), (b_[0] + inn[0], b_[1] + inn[1])
                front = [C.P(*a_, H), C.P(*b_, H), C.P(*b_, H + 9), C.P(*a_, H + 9)]
                C.poly(front, shade(stone, .8 if (P0 is A) else .98))
                C.poly([C.P(*a_, H + 9), C.P(*b_, H + 9), C.P(*b2, H + 9), C.P(*a2, H + 9)], shade(stone, 1.15))
                pygame.draw.polygon(C.S, shade(stone, .55), front, max(1, k // 2))
    if ruined:                           # fallen blocks at the foot
        for i in range(4):
            if h01(seed, i, 98) < .55:
                ax_, ay_ = .2 + h01(seed, i, 99) * .7, .55 + h01(i, seed, 100) * .45
                q = C.P(ax_, ay_, 0); r_ = (3 + h01(i, seed, 101) * 3) * k
                pygame.draw.ellipse(C.S, shade(stone, .55), (q[0] - r_, q[1] - r_ * .3, r_ * 2, r_ * .9))
                pygame.draw.polygon(C.S, shade(stone, .95), [(q[0] - r_, q[1]), (q[0] - r_ * .4, q[1] - r_ * 1.1), (q[0] + r_ * .8, q[1] - r_ * .8), (q[0] + r_, q[1])])
    if post:
        round_tower(C, cx, cy, .44, 0, H + 26, stone, seed, battlements=True)
        rc = TEAM_ROOF.get(style, SLATE["Neutral"])
        flag = {"Alliance": (52, 92, 196), "Horde": (178, 40, 36)}.get(style, (200, 170, 70))
        conical_roof(C, cx, cy, .52, H + 32, 40, rc, seed, flag=flag)
    spr, anc = C.crop((0, 0, 0))
    return spr, anc


def column(style="Dungeon", var=0):
    """A dungeon pillar: a fluted stone column on a square base with a carved capital (blocks line of sight)."""
    C = _IsoCanvas((300, 600), (150, 520)); k = C.k
    stone = shade(STONE.get(style, STONE["Dungeon"]), 1.0 + (var % 3) * .04)
    contact_shadow(C, .05, .05, .95, .95, .2, 60)
    plinth(C, .08, .08, .92, .92, 8, stone, 400 + var)
    round_tower(C, .5, .5, .3, 8, 86, stone, 400 + var)
    for i in range(7):                    # fluting: soft vertical grooves on the visible side
        a = -.2 + i * .28
        if math.cos(a) + math.sin(a) < 0: continue
        p0, p1 = C.P(.5 + math.cos(a) * .3, .5 + math.sin(a) * .3, 12), C.P(.5 + math.cos(a) * .3, .5 + math.sin(a) * .3, 82)
        pygame.draw.line(C.S, shade(stone, .62), p0, p1, k)
    Fl = Face(C, (.12, .88), (.88, .88), 86, 96, SHADE_F); Fr = Face(C, (.88, .88), (.88, .12), 86, 96, LIT_F)
    for F in (Fl, Fr): _stone_face(F, shade(stone, 1.05), 401 + var, 5.0)
    C.poly([C.P(.12, .12, 96), C.P(.88, .12, 96), C.P(.88, .88, 96), C.P(.12, .88, 96)], shade(stone, 1.15))
    spr, anc = C.crop((0, 0, 0))
    return spr, anc
