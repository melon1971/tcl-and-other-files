"""LiveWorld RPG 0.25 - the people of the world.

Computer-controlled adventurers that behave like other players:

* every one has a class, a random level (1-100), a gear tier (Common ... Legendary, some in full sets)
  and a personality that decides what they like to do and how they treat you;
* they travel the whole continent along the roads between towns, hunt in zones that suit their level,
  rest at inns by night, trade at the market, group up for dungeons and talk;
* some will challenge you to a duel (and some will refuse yours); duels stop at the last hit point;
* attack someone of the other faction and they fight back - to the death;
* when a town is raided, nearby adventurers of its faction rally to defend it next to you.

Mixed into engine.World; uses the World's tables and helpers through self.
"""
import time, json
import math
import random

GEAR_TIERS = ("Poor", "Common", "Uncommon", "Rare", "Epic", "Elite", "Set", "Legendary", "Mythic")
GEAR_POW = {"Poor": .82, "Mythic": 1.95, "Common": 1.0, "Uncommon": 1.08, "Rare": 1.18, "Epic": 1.32, "Elite": 1.45, "Set": 1.55, "Legendary": 1.72}
SET_KEYS = ("Ashen Titan", "Frostwyrm", "Dread Legion", "Sunscar Colossus", "Ember Dragon", "Void Seraph", "Voidtouched", "Voidforged")
SET_PIECES = ("armor", "helm", "weapon", "trinket")

PERSONAS = {
    #             title                    accept  challenge  defend  assist
    "friendly":  ("Friendly traveller",    .35,    .004,      .85,    .8),
    "proud":     ("Proud duelist",         .92,    .07,       .75,    .3),
    "aggressive": ("Hot-headed brawler",   .85,    .055,      .70,    .15),
    "shy":       ("Quiet loner",           .06,    .0,        .25,    .1),
    "trader":    ("Wandering trader",      .2,     .002,      .45,    .3),
    "explorer":  ("Restless explorer",     .45,    .01,       .55,    .5),
    "guardian":  ("Sworn protector",       .5,     .006,      1.0,    .95),
}
PERSONA_W = (("friendly", 24), ("proud", 14), ("aggressive", 10), ("shy", 12), ("trader", 12), ("explorer", 16), ("guardian", 12))

FIRST = ("Aric", "Bryn", "Cael", "Dara", "Eldon", "Fenna", "Garrick", "Hale", "Ilsa", "Joren", "Kaela", "Lorn", "Mira", "Nessa", "Orrin", "Pell",
         "Quinn", "Rook", "Sera", "Tamsin", "Ulric", "Vala", "Wren", "Yorik", "Zara", "Alden", "Brom", "Corin", "Dagny", "Edda", "Falk", "Greta",
         "Hrolf", "Ivo", "Jessa", "Kiran", "Liesel", "Magnus", "Nyra", "Osric", "Petra", "Ragna", "Soren", "Thora", "Uma", "Vesna", "Wulf",
         "Ysolde", "Ash", "Bram", "Cora", "Dain", "Elin", "Faye", "Gideon", "Holt", "Isla", "Jarek", "Kestra", "Lark", "Marek", "Niamh", "Oona",
         "Piers", "Riva", "Silas", "Tova", "Varric", "Wynne", "Xander", "Yara", "Zev", "Grakk", "Moxa", "Thrugg", "Zul'ja", "Rokhan", "Vex")
LAST = ("Ironfist", "Ashby", "Blackthorn", "Brightwater", "Coldbrook", "Dawnstar", "Emberly", "Fairwind", "Frostmane", "Greyhelm", "Hallow",
        "Hawkridge", "Kingsley", "Longstride", "Marsh", "Moonwhisper", "Oakheart", "Ravenholt", "Redmane", "Silverleaf", "Stonehand",
        "Stormborn", "Swiftarrow", "Thornwood", "Underhill", "Vale", "Westmarch", "Wildmoor", "Wolfsbane", "Yarrow", "Bloodaxe", "Skullsplitter",
        "Grimtusk", "Duskwalker", "Ironjaw", "Flamecaller", "Shadowstep", "Dragonsbane", "Hammerfall", "Brightblade")

LINES = {
    "greet": ("Hail, {p}!", "Well met, {p}.", "Safe roads, friend.", "Light keep you, {p}.", "Oi, {p}! Good hunting?", "Evening, traveller.",
              "Nice gear, {p}.", "Stay clear of the dens after dark."),
    "hunt": ("Anyone seen the den around here?", "These {m}s keep coming.", "Need a few more kills before I head back.",
             "Watch out, there's an elite near the ridge.", "Good spot for farming, this.", "Loot's been poor today..."),
    "travel": ("Heading to {t}. Long road ahead.", "Anyone else going to {t}?", "The road to {t} is safer than the wilds.",
               "I'll make {t} by nightfall.", "Never been this far from home."),
    "town": ("Prices at the market are robbing me blind.", "Anyone want to group for a dungeon?", "LFG {d}, need a healer!",
             "Selling herbs, cheap!", "Just got back from {z}. Brutal.", "The ale here is terrible.", "Has anyone seen the quest board today?",
             "WTB Spirit Essence.", "Who's the best duelist in {t}?"),
    "night": ("Time to rest by the fire.", "Too dark to hunt now.", "Wake me at dawn.", "The inn's warm tonight."),
    "defend": ("To the walls! Defend {t}!", "For {t}!", "Hold the gate!", "They will not take {t}!", "Healers, on me!"),
    "assist": ("Need a hand, {p}?", "I've got your back!", "Let's take it together!", "Hang on, {p}, I'm coming!"),
    "challenge": ("You there, {p}! Care to cross blades?", "{p}! A friendly duel, if you dare.", "Let's see what you're made of, {p}.",
                  "I challenge you, {p}! To the last hit point."),
    "accept": ("You're on!", "Ha! I accept.", "Steel yourself, {p}.", "Very well. Don't cry when you lose."),
    "decline": ("Not today, friend.", "I'm busy.", "Maybe another time.", "No thanks, I don't fight for sport.", "I'd rather not."),
    "too_strong": ("I know when I'm beaten, {p}.", "You'd flatten me. No thanks.", "Come back when I've caught up."),
    "too_weak": ("Come back when you've grown, whelp.", "You're not worth my time yet.", "Train a few more levels first."),
    "win": ("Good fight, {p}!", "Too easy.", "Better luck next time.", "Ha! Victory!"),
    "lose": ("Well fought, {p}. I yield!", "Argh, you got me.", "I yield! I yield!", "You've earned that."),
    "yield_won": ("Wise choice.", "Smart move, {p}.", "Live to fight another day."),
    "death_offer": ("{p}! Fight me - to the death!", "Only one of us walks away from this, {p}.", "For the {f}! Face me, {p}!"),
    "death_accept": ("To the death, then!", "You'll regret this, {p}.", "So be it. For the {f}!"),
    "death_decline": ("I won't spill blood for nothing.", "Not today.", "Find someone else to die for you.", "No. Walk away."),
    "outlaw": ("Outlaw! Get them!", "There's the murderer!", "You'll hang for that, {p}!"),
    "angry": ("You'll pay for that!", "Big mistake, {p}!", "So that's how it is!", "For the {f}!"),
    "idle": ("Hmm...", "I could use a new weapon.", "My feet hurt.", "Did you hear about the raid on {t}?", "One day I'll forge a Mythic."),
}

DUEL_COUNT = 12          # 3 s countdown
OFFER_TICKS = 80         # an offer stands for 20 s
OFFER_COOLDOWN = 1400    # at most one challenge every ~6 minutes
OUTLAW_TICKS = 15 * 60 * 4   # 0.38: killing another faction's character makes you an outlaw for 15 minutes
LEADER_ROLES = ("questgiver", "king", "dailygiver")   # 0.39: quest givers and rulers can be slain (enemy towns) ...
LEADER_RESPAWN = 30 * 60 * 4            # ... and return after 30 minutes
TOWN_AGGRO_TICKS = 4 * 60 * 3           # attacking a town's leaders turns its guards on you for 3 minutes
POP_TARGET = 2000
ROAMER_BASE, ROAMERS = 9000, 100      # 1.0.4: 100 wanderers (50 Alliance, 50 Horde), level 10-100, any class and gear, who roam the whole map and sometimes assault towns        # adventurers in the world


def _wpick(r, pairs):
    tot = sum(w for _, w in pairs)
    x = r.uniform(0, tot)
    for k, w in pairs:
        x -= w
        if x <= 0:
            return k
    return pairs[-1][0]


def _world_h():
    from .engine import WORLD_H
    return WORLD_H


def compute_gate_gaps(walls, towns, R):
    """1.0.8: {town id: [(angle, half_width), ...]} - the real gaps in each town's wall ring (roads wander, so these
    differ from the nominal gate angles).  `walls` is the set of wall tiles."""
    out = {}
    for t in towns:
        open_ = []
        for k in range(720):
            g = k * math.pi / 360
            c, sn = math.cos(g), math.sin(g)
            open_.append(not any((int(math.floor(t.x + c * (R + o))), int(math.floor(t.y + sn * (R + o)))) in walls for o in (-.5, 0, .5)))
        if all(open_) or not any(open_): continue
        start = open_.index(False); runs = []; cur = None
        for j in range(1, 721):
            k = (start + j) % 720
            if open_[k]:
                cur = [k, k] if cur is None else [cur[0], k]
            elif cur is not None:
                runs.append(cur); cur = None
        gaps = []
        for a0, a1 in runs:
            n = (a1 - a0) % 720 + 1; width = n * (math.pi / 360) * R
            if width >= 2.0: gaps.append((((a0 + (n - 1) / 2) % 720) * math.pi / 360, width / 2))
        if gaps: out[t.id] = gaps
    return out

class PeopleMixin:
    # ================================================================ setup / persistence
    def _people_init(self):
        from . import engine as E
        self.db.execute("CREATE TABLE IF NOT EXISTS people(id INTEGER PRIMARY KEY, gear TEXT, persona TEXT, setl TEXT, setp TEXT, "
                        "wins INTEGER DEFAULT 0, losses INTEGER DEFAULT 0, xp INTEGER DEFAULT 0)")
        self.duel = None; self.duel_offer = None; self.offer_cool = self.tick + 600; self.pfoes = {}
        try: self._outlaw_until = int(self._meta("outlaw_until", "0") or 0)
        except (TypeError, ValueError): self._outlaw_until = 0
        self._outlaw_warned = set()
        self.says = []; self._people_ready = True
        prof = {r["id"]: dict(r) for r in self.db.execute("SELECT * FROM people").fetchall()}
        advs = [a for a in self.actors if a.kind == "adventurer"]
        first_time = self._meta("people_v1") is None
        r = random.Random(f"people:{self._seed()}")
        used = {a.id for a in self.actors}
        nid = 1
        while len(advs) < POP_TARGET:
            while nid in used: nid += 1
            if nid >= 9999: break
            ar_ = E.AREAS[nid % len(E.AREAS)]             # 1.0.4: players are spread evenly over every zone
            tz_ = [t_ for t_ in self.towns if t_.area == ar_[0]]
            if r.random() < .5 and tz_:
                t = r.choice(tz_); ang = r.uniform(0, 6.283); rr = r.uniform(2, E.TOWN_PLAZA_R - 3)
                x, y = t.x + math.cos(ang) * rr, t.y + math.sin(ang) * rr
            else:
                ar = ar_; x = ar[1] + r.uniform(3, ar[3] - 3); y = ar[2] + r.uniform(3, ar[4] - 3)
            a = E.Actor(nid, "", "Alliance", 1, x, y, 100, 100, "adventurer", r.choice(E.ROLES), "town", -1, self.area(x, y)[0], r.randint(1, 20))
            self.actors.append(a); advs.append(a); used.add(nid); prof.pop(nid, None)
        for k in range(ROAMERS):             # the roamers: ids 9000-9099, always present
            rid = ROAMER_BASE + k
            if rid in used: continue
            rx, ry = r.uniform(8, E.W - 8), r.uniform(8, E.WORLD_H - 8)
            a = E.Actor(rid, "", "Alliance" if k % 2 == 0 else "Horde", r.randint(10, 100), rx, ry, 100, 100, "adventurer", r.choice(E.ROLES), "roam", -1, self.area(rx, ry)[0], r.randint(1, 20))
            self.actors.append(a); advs.append(a); used.add(rid); prof.pop(rid, None)
        remix = self._meta("people_v2") is None and not first_time
        for a in advs:
            p = prof.get(a.id)
            if remix and self._is_roamer(a):
                a.x, a.y = r.uniform(8, E.W - 8), r.uniform(8, E.WORLD_H - 8); a.home = self.area(a.x, a.y)[0]
                self._roll_person(a, r, keep_level=False)
            elif remix:                       # 1.0.4: an older save - every player is re-rolled into the zone its number belongs to
                zn = E.AREAS[a.id % len(E.AREAS)]
                if r.random() < .5 and any(t_.area == zn[0] for t_ in self.towns):
                    t_ = r.choice([t_ for t_ in self.towns if t_.area == zn[0]]); ang = r.uniform(0, 6.283); rr = r.uniform(2, E.TOWN_PLAZA_R - 3)
                    a.x, a.y = t_.x + math.cos(ang) * rr, t_.y + math.sin(ang) * rr
                else:
                    a.x = zn[1] + r.uniform(3, zn[3] - 3); a.y = zn[2] + r.uniform(3, zn[4] - 3)
                a.home = zn[0]
                self._roll_person(a, r, keep_level=False)
            elif p is None or first_time:
                self._roll_person(a, r, keep_level=False)
            else:
                a.gear = p["gear"] if p["gear"] in GEAR_POW else "Common"; a.persona = p["persona"] if p["persona"] in PERSONAS else "friendly"
                a.setl = p["setl"] or ""; a.setp = tuple(x for x in (p["setp"] or "").split(",") if x)
                a.wins = p["wins"] or 0; a.losses = p["losses"] or 0; a.pxp = p["xp"] or 0
                self._person_stats(a, heal=False)
            self._person_reset_goal(a)
        if first_time: self._setmeta("people_v1", "1")
        self._setmeta("people_v2", "1")
        self.by_id = {a.id: a for a in self.actors}
        self._people_save(); self.db.commit()

    def _roll_person(self, a, r, keep_level=True):
        """A fresh character: name, faction, level, gear and personality."""
        from . import engine as E
        zn = E.AREAS[a.id % len(E.AREAS)]                   # 1.0.4: every player belongs to a zone and never outgrows its top level
        if not keep_level:
            a.level = r.randint(10, 100) if self._is_roamer(a) else r.randint(zn[6], zn[7])
        a.faction = ("Alliance" if a.id % 2 == 0 else "Horde") if self._is_roamer(a) else r.choice(("Alliance", "Horde"))
        used = getattr(self, "_pnames", None)
        if used is None: used = self._pnames = set()
        for _ in range(30):
            nm = f"{r.choice(FIRST)} {r.choice(LAST)}"
            if nm not in used: break
        a.name = nm; used.add(nm)
        lv = a.level
        w = [("Poor", 12), ("Common", 28), ("Uncommon", 24), ("Rare", 18), ("Epic", 9), ("Elite", 5), ("Set", 3), ("Legendary", 2), ("Mythic", 1)]      # 1.0.4: every kind of gear at every level
        a.gear = _wpick(r, w)
        a.setl = ""; a.setp = ()
        if a.gear in ("Set", "Legendary", "Mythic"):
            a.setl = r.choice(SET_KEYS); n = 4 if a.gear in ("Legendary", "Mythic") else r.randint(2, 4)
            a.setp = tuple(SET_PIECES[:n])
        elif a.gear == "Elite" and r.random() < .4:
            a.setl = r.choice(SET_KEYS); a.setp = ("armor",)
        a.persona = _wpick(r, PERSONA_W)
        a.wins = 0; a.losses = 0; a.pxp = 0
        self._person_stats(a, heal=True)

    def _person_stats(self, a, heal=True):
        g = GEAR_POW.get(getattr(a, "gear", "Common"), 1.0)
        a.gpow = g
        a.maxhp = int((100 + a.level * 11) * (1 + (g - 1) * .8))
        a.hp = a.maxhp if heal else max(1, min(a.hp, a.maxhp))

    def _people_save(self):
        if not getattr(self, "_people_ready", False): return
        rows = [(a.id, getattr(a, "gear", "Common"), getattr(a, "persona", "friendly"), getattr(a, "setl", ""), ",".join(getattr(a, "setp", ())),
                 getattr(a, "wins", 0), getattr(a, "losses", 0), getattr(a, "pxp", 0)) for a in self.actors if a.kind == "adventurer"]
        self.db.execute("DELETE FROM people")
        self.db.executemany("INSERT INTO people VALUES(?,?,?,?,?,?,?,?)", rows)

    def _person_reset_goal(self, a):
        a.gx = None; a.gy = None; a.task_until = 0; a.say = ""; a.say_until = 0; a.say_seq = 0
        a.rally = -1; a.duel_with = None; a.duel_end = 0; a.atk_tick = -99; a.stuck = 0; a.last_greet = -9999
        a.challenged_day = -1; a.next_hit = 0; a.healed_t = -999
        if a.state not in ("party",): a.state = "town" if self._town_at(a.x, a.y) else "hunt"

    # ================================================================ helpers
    def _town_at(self, x, y, r=None):
        from . import engine as E
        r = r or E.TOWN_PLAZA_R
        for t in self.towns:
            if (t.x - x) ** 2 + (t.y - y) ** 2 < r * r: return t
        return None

    def _friendly_town(self, t, a):
        return t.faction == a.faction or t.faction not in ("Alliance", "Horde")

    def _say(self, a, kind, **kw):
        lines = LINES.get(kind)
        if not lines: return
        r = self.rng
        from . import engine as E
        ar = self.area(a.x, a.y)
        town = min(self.towns, key=lambda t: (t.x - a.x) ** 2 + (t.y - a.y) ** 2) if self.towns else None
        d = next((x.name for x in self.dungeons if x.kind == "dungeon" and abs(x.level - a.level) < 12), "a dungeon")
        mk = getattr(E, "ZONE_MONSTERS", {}).get(ar[0], ("monster",))
        fill = {"p": self.player.get("name", "friend"), "t": kw.get("t") or (town.name if town else "town"), "z": ar[0], "d": d,
                "m": r.choice(mk) if mk else "monster", "f": a.faction}
        txt = r.choice(lines)
        try: txt = txt.format(**fill)
        except Exception: pass
        a.say = txt; a.say_until = self.tick + 20; a.say_seq = getattr(a, "say_seq", 0) + 1

    def _near_player(self, a, d):
        p = self.player
        return (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2 <= d * d

    def _pdist(self, a):
        p = self.player
        return math.hypot(a.x - p["x"], a.y - p["y"])

    def _suit_area(self, a):
        from . import engine as E
        mine = [ar for ar in E.AREAS if ar[5] in (a.faction, "Neutral")] or E.AREAS          # 0.42: hunt in mixed zones and your own capital zone
        good = [ar for ar in mine if ar[6] - 3 <= a.level <= ar[7] + 3]
        if not good:
            under = [ar for ar in mine if ar[7] <= a.level]
            good = [max(under, key=lambda ar: ar[7])] if under else [min(mine, key=lambda ar: ar[6])]
        return self.rng.choice(good)

    def _pdmg(self, a):
        mult = {"Warrior": 1.2, "Ranger": 1.1, "Mage": 1.3, "Cleric": .85, "Rogue": 1.2, "Paladin": 1.05, "Shaman": 1.0, "Druid": 1.0,
                "Berserker": 1.35, "Warlock": 1.25, "Monk": 1.2, "Juggernaut": .9}.get(a.role, 1.0)
        return (2 + a.level * 1.25) * mult * getattr(a, "gpow", 1.0) * self.rng.uniform(.85, 1.15)

    def _ranged(self, a):
        return a.role in ("Ranger", "Mage", "Warlock", "Cleric", "Shaman", "Druid")

    def _hostile_adv(self, a):
        """Can the player attack this adventurer right now?  0.38: never without consent - only in a duel,
        an accepted fight to the death, or against someone who is attacking you (e.g. hunting you as an outlaw)."""
        if a.kind != "adventurer": return False
        if a.id in self.pfoes: return True
        d = self.duel
        return bool(d and d["id"] == a.id and d["state"] == "fight")

    # ================================================================ 0.38 outlaws
    def outlaw_left(self):
        """Ticks left on your outlaw (red name) flag."""
        return max(0, getattr(self, "_outlaw_until", 0) - self.tick)

    def _set_outlaw(self, on):
        self._outlaw_until = self.tick + OUTLAW_TICKS if on else 0
        self._outlaw_warned = set()
        self._setmeta("outlaw_until", self._outlaw_until); self.db.commit()
        if on: self.events.append("You killed another faction's champion: you are an OUTLAW for 15 minutes. Every town guard, and some adventurers, will attack you on sight.")
        else: self.events.append("You are no longer an outlaw.")

    def _guard_hostile(self, a):
        """Town guards of every faction attack an outlaw - and anyone who attacked their town's leaders (0.39)."""
        if a.kind != "npc" or a.role != "guard" or a.hp <= 0 or self.tick < getattr(a, "down_until", 0): return False
        if self.outlaw_left() > 0 or self._town_aggro_on(a): return True
        et = getattr(self, "_enemy_town_in", None)         # 0.46.27: inside an enemy town's walls, every guard of that town attacks you
        return et is not None and self._town_for_actor(a) is et

    # ================================================================ 0.39 quest givers and rulers
    def _town_aggro_on(self, a):
        ag = getattr(self, "town_aggro", None)
        if not ag: return False
        t = self._town_for_actor(a)
        return t is not None and ag.get(t.id, 0) > self.tick

    def leader_attackable(self, a):
        """Quest givers and rulers of any town of the other side (or of a town under city raid) can be attacked - a solo raid."""
        if a.kind != "npc" or a.role not in LEADER_ROLES or a.hp <= 0 or self.inst: return False
        t = self._town_for_actor(a)
        if t is None or self.town_protected(t): return False
        r = getattr(self, "city_raid", None)
        enemy = self.hostile_town(t, self.player["faction"])       # any town of the other side - a one-person raid
        return enemy or bool(r and r.get("town") == t.id)

    def leader_stats(self, a, t):
        """A leader is as tough as the top of the town's level band: a much higher-level hero can beat them alone."""
        from . import engine as E
        top = next((ar[7] for ar in E.AREAS if ar[0] == t.area), 10)
        a.level = top + 2
        a.maxhp = int(((420 + a.level * 95) if a.role == "king" else (200 + a.level * 45)) * (.55 + 1.0 * ((a.id * 2654435761 >> 9) % 100) / 100.0))      # 1.0.4: some are weaker than a hero, some tougher
        if a.hp > 0: a.hp = a.maxhp

    def leader_hit(self, a):
        t = self._town_for_actor(a)
        if t is None: return
        if not hasattr(self, "town_aggro"): self.town_aggro = {}
        if self.town_aggro.get(t.id, 0) <= self.tick:
            self.events.append(f"You attacked {a.name.split(' #')[0]} - the guards of {t.name} are coming for you!")
        self.town_aggro[t.id] = self.tick + TOWN_AGGRO_TICKS

    def leader_slain(self, a, by_player=True):
        """A quest giver or ruler falls; they return to their post in 30 minutes."""
        a.hp = 0; a.dead_until = self.tick + LEADER_RESPAWN
        self._leaders_dead()[str(a.id)] = a.dead_until; self._save_dead_leaders()
        t = self._town_for_actor(a)
        self.events.append(f"{a.name.split(' #')[0]} of {t.name if t else 'the town'} has been slain! A successor arrives in 30 minutes.")

    def _leaders_dead(self):
        d = getattr(self, "_dead_leaders", None)
        if d is None:
            try: d = json.loads(self._meta("dead_leaders", "{}") or "{}")
            except (ValueError, TypeError): d = {}
            self._dead_leaders = d = d if isinstance(d, dict) else {}
        return d

    def _save_dead_leaders(self):
        self._setmeta("dead_leaders", json.dumps(self._leaders_dead())); self.db.commit()

    def apply_dead_leaders(self):
        """On load: leaders slain less than 30 minutes ago stay gone."""
        for k, until in self._leaders_dead().items():
            a = self.by_id.get(int(k))
            if a is not None and self.tick < until: a.hp = 0; a.dead_until = until

    def _leader_tick(self):
        """Respawn slain leaders (checked every 10 s)."""
        if self.tick % 40: return
        d = self._leaders_dead()
        if not d: return
        changed = False
        for k, until in list(d.items()):
            a = self.by_id.get(int(k))
            if a is None: d.pop(k); changed = True; continue
            if self.tick >= until:
                a.hp = a.maxhp; a.dead_until = 0; d.pop(k); changed = True
                t = self._town_for_actor(a)
                if t is not None:
                    a.x, a.y = self.shop_post(t, a.role)
                    if self._near_player(a, 40): self.events.append(f"A new {'ruler' if a.role == 'king' else 'quest giver'} takes up the post in {t.name}.")
            elif a.hp > 0:
                a.hp = 0
        if changed: self._save_dead_leaders()

    FALL_PROTECT_SECS = 24 * 3600

    def _fallen(self):
        d = getattr(self, "_fallen_towns", None)
        if d is None:
            try: d = json.loads(self._meta("fallen_towns", "{}") or "{}")
            except (ValueError, TypeError): d = {}
            self._fallen_towns = d = d if isinstance(d, dict) else {}
        return d

    def town_protected(self, t):
        """1.0.4: a town (and its leaders) that has fallen cannot be raided or attacked again for 24 real hours."""
        return t is not None and self._fallen().get(str(t.id), 0) > time.time()

    def town_falls(self, t):
        """A city raid overran town t: its ruler and quest giver are slain (back in 30 minutes)."""
        if t is None: return
        d = self._fallen(); d[str(t.id)] = time.time() + self.FALL_PROTECT_SECS
        for k in [k for k, v in d.items() if v <= time.time()]: d.pop(k)
        self._setmeta("fallen_towns", json.dumps(d)); self.db.commit()
        for a in self.actors:
            if a.kind == "npc" and a.role in LEADER_ROLES and a.hp > 0 and self._town_for_actor(a) is t:
                self.leader_slain(a, by_player=False)

    def _town_defense_tick(self):
        """0.46.34: an enemy-faction adventurer inside a town's walls is attacked by that town's guards, exactly like you are."""
        by_town = {}
        for a in self.actors:
            if a.kind != "adventurer" or a.hp <= 0 or a.party or a.state in ("aiduel", "offer", "duel", "fight") or getattr(a, "in_pvp", False): continue
            if (a.id + self.tick // 4) % 3 and a.state != "assault": continue      # 1.0.4: each visitor is checked every third pass
            t = self.enemy_town_at(a.x, a.y, a.faction)
            if t is None: continue
            gl = by_town.get(t.id)
            if gl is None:      # the town's guards, found once per pass (a visitor's home zone need not match the town's)
                gl = by_town[t.id] = [g for g in self.actors if g.kind == "npc" and g.role == "guard" and g.hp > 0
                                      and self.tick >= getattr(g, "down_until", 0) and self._town_for_actor(g) is t]
            guards = [g for g in gl if g.faction != a.faction and (g.x - a.x) ** 2 + (g.y - a.y) ** 2 < 16 * 16]
            if not guards: continue
            cool = self.__dict__.setdefault("_alert_cool", {})
            if t.faction == self.player["faction"] and self._is_roamer(a) and a.state == "assault" and self.tick >= cool.get(t.id, 0):      # 1.0.4: one attacker is enough to call the global notice
                cool[t.id] = self.tick + 480; self._alert(f"ALERT: {t.name} is under attack! {a.name.split(' #')[0]} of the {a.faction} has broken into the town!")
            g = min(guards, key=lambda x: (x.x - a.x) ** 2 + (x.y - a.y) ** 2)
            d = math.hypot(g.x - a.x, g.y - a.y)
            if d > 1.4: self._step(g, a.x, a.y, .45)
            if d <= 1.9 and self.tick >= getattr(g, "next_hit", 0):
                g.next_hit = self.tick + 4; g.atk_tick = self.tick
                a.hp -= (6 + g.level * 2.4) * self.rng.uniform(.85, 1.15) * 2.0
                if self._near_player(a, 25) and self.rng.random() < .3: self.events.append(f"{g.name.split(' #')[0]}: An enemy in our town! Seize them!")
                if a.hp <= 0: self._record_kill(a, g)
            if not (self._is_roamer(a) and a.state == "assault"): a.resting = True      # the intruder runs for a friendly town to heal (see _person_think)

    def _outlaw_tick(self):
        """Guards (all of them) and some adventurers (enemy faction, or hot-headed ones of any faction) go after an outlaw."""
        p = self.player
        aggro = any(v > self.tick for v in getattr(self, "town_aggro", {}).values())
        et = None if (self.inst or p["hp"] <= 0) else self.enemy_town_at(p["x"], p["y"], p["faction"])
        self._enemy_town_in = et
        if self.outlaw_left() <= 0:
            if getattr(self, "_outlaw_until", 0): self._set_outlaw(False)
            if not aggro and et is None:
                if getattr(self, "_outlaw_warned", None): self._outlaw_warned = set()      # left the town: the guards warn you again next time
                return
        if self.inst or p["hp"] <= 0: return
        warned = getattr(self, "_outlaw_warned", None)
        if warned is None: warned = self._outlaw_warned = set()
        for g in self.actors:
            if not (self._guard_hostile(g) or (g.kind == "npc" and g.role in LEADER_ROLES and g.hp > 0 and self._town_aggro_on(g))): continue
            d = math.hypot(g.x - p["x"], g.y - p["y"])
            if d > (30 if et is not None and self._town_for_actor(g) is et else 14): continue
            if g.id not in warned:
                warned.add(g.id)
                if self.outlaw_left() > 0 or self._town_aggro_on(g): self.events.append(f"{g.name.split(' #')[0]}: Halt, outlaw!")
                else: self.events.append(f"{g.name.split(' #')[0]}: An enemy in our town! Seize them!")
            if d > 1.4: self._step(g, p["x"], p["y"], .45)
            if d <= 1.9 and self.tick >= getattr(g, "next_hit", 0):
                g.next_hit = self.tick + 4; g.atk_tick = self.tick
                self.damage_player((6 + g.level * 2.4) * self.rng.uniform(.85, 1.15), g, g.id)
                if p["hp"] <= 0: return
        if self.tick % 8 or self.outlaw_left() <= 0: return
        for a in self.actors:
            if a.kind != "adventurer" or a.hp <= 0 or a.id in self.pfoes or a.party: continue
            if a.state in ("aiduel", "duel", "defend", "offer") or (self.duel and self.duel["id"] == a.id): continue
            if self._pdist(a) > 10: continue
            enemy = a.faction != p["faction"]
            if not ((enemy and a.persona in ("aggressive", "proud")) or a.persona == "aggressive"): continue
            if self.rng.random() < .3:
                self.pfoes[a.id] = self.tick; a.state = "fight"; a.gx = None; a.next_hit = self.tick + 6
                self._say(a, "outlaw")
                self.events.append(f"{a.name} attacks you: you are an outlaw!")

    def request_fight(self, aid):
        """0.38: challenge someone of the other faction to a fight to the death. They decide."""
        a = self.by_id.get(aid)
        if not a or a.kind != "adventurer": return "There is nobody here to challenge."
        if a.faction == self.player["faction"]: return "You only fight your own side in duels."
        if a.id in self.pfoes: return f"You are already fighting {a.name}."
        if self.duel: return "You are already in a duel."
        if self.inst or getattr(self, "city_raid", None): return "Not now - there are more important fights."
        if self._pdist(a) > 8: return f"{a.name} is too far away."
        if a.state in ("aiduel", "defend") or a.party: return f"{a.name} is busy."
        if self.tick < getattr(a, "refused_until", 0): return f"{a.name} won't fight you right now."
        acc = {"aggressive": .85, "proud": .6}.get(a.persona, .2)
        gap = a.level - self.player["level"]
        if gap < -10: acc *= .2
        if a.hp < a.maxhp * .7: acc *= .4
        if self.rng.random() < acc:
            self._say(a, "death_accept"); self._start_death_fight(a); return ""
        a.refused_until = self.tick + 1200
        self._say(a, "death_decline")
        return f"{a.name} refuses to fight you."

    def _start_death_fight(self, a):
        self.pfoes[a.id] = self.tick
        a.state = "fight"; a.gx = None; a.next_hit = self.tick + 8; a.hp = max(a.hp, a.maxhp * .7)
        self.selected_target = a.id
        self.events.append(f"{a.name} (level {a.level} {a.role}) accepts: a fight to the death! Killing them makes you an outlaw.")

    # ================================================================ thinking (every 1.5 - 4 s per person)
    def _person_think(self, a):
        from . import engine as E
        a.timer = self.rng.randint(6, 16)
        if a.hp <= 0: return
        if (self.duel and self.duel["id"] == a.id) or a.id in self.pfoes or a.state in ("aiduel", "offer"): return
        r = self.rng; tick = self.tick; near = self._near_player(a, 34)
        if a.party:
            pt = self.parties.get(a.party)
            if pt is not None and pt.get("state") in ("forming", "travel") and tick - pt.setdefault("t0", tick) > 2400:
                for m in self.actors:          # the group never came together: break it up
                    if m.party == a.party: m.party = 0; m.state = "town"; m.task_until = 0; m.gx = None
                self.parties.pop(a.party, None)
                return
            a.gx = None; self._party_ai(a)
            if near and r.random() < .02: self._say(a, "town")
            return
        if a.state == "party": a.state = "town"
        # 0. 0.44.9: badly hurt - fall back to the nearest friendly town, rest there, then go back out
        if a.state not in ("aiduel", "offer", "duel", "fight") and not getattr(a, "in_pvp", False):
            if a.hp < a.maxhp * .3 and not getattr(a, "resting", False):
                a.resting = True
                if near and r.random() < .5: a.say = "I need to rest!"; a.say_until = tick + 40
            if getattr(a, "resting", False):
                own = [t for t in self.towns if self._friendly_town(t, a)] or self.towns
                t = min(own, key=lambda t: (t.x - a.x) ** 2 + (t.y - a.y) ** 2)
                if math.hypot(t.x - a.x, t.y - a.y) > E.TOWN_WALL_R * .8:
                    post = E.SHOP_POSTS["innkeeper"]
                    a.state = "town"; a.gx, a.gy = t.x + post[0] + r.uniform(-2, 2), t.y + post[1] + r.uniform(-2, 2); a.task_until = tick + 120
                else:
                    a.hp = min(a.maxhp, a.hp + a.maxhp * .1)
                    if a.hp >= a.maxhp * .85: a.resting = False; a.state = "town"; a.task_until = 0
                return
        # 1. fight whatever is next to us (raiders, monsters, and the other faction if hot-headed)
        if self._person_fight(a): return
        if self._is_roamer(a) and self._roamer_think(a): return
        # 1b. 0.44.7: stand and fight what is hunting us instead of walking away from it
        if a.hp > a.maxhp * .35 and a.state not in ("aiduel", "offer"):
            rng_ = 4.0 if self._ranged(a) else 1.2
            foes_ = [x for x in self.actors_near(a, 9) if x.kind == "monster" and x.hp > 0 and x.faction != a.faction
                     and x.target != -2 and x.level <= a.level + 4 and x.role not in E.SOLDIER_ROLES]
            if foes_:
                tg_ = min(foes_, key=lambda x: (x.x - a.x) ** 2 + (x.y - a.y) ** 2)
                ang_ = (a.id * 2.399) % 6.283
                a.gx, a.gy = tg_.x + math.cos(ang_) * rng_, tg_.y + math.sin(ang_) * rng_
                a.task_until = 0
                return
        # 2. a town under attack: rally to it
        cr = getattr(self, "city_raid", None)
        if cr:
            t = next((x for x in self.towns if x.id == cr["town"]), None)
            if a.rally != cr["start"]:
                a.rally = cr["start"]
                ok = (t is not None and self._friendly_town(t, a) and a.level >= max(6, cr.get("lvl", 1) - 15)
                      and math.hypot(a.x - cr["x"], a.y - cr["y"]) < 150 and cr.get("def_n", 0) < 16)
                if ok and r.random() < PERSONAS[a.persona][3]:
                    a.state = "defend"; cr["def_n"] = cr.get("def_n", 0) + 1
                    if near: self._say(a, "defend", t=cr["name"])
            if a.state == "defend":
                raiders = [self.by_id.get(i) for i in cr["ids"]]
                raiders = [x for x in raiders if x and x.hp > 0]
                if raiders:
                    tg = min(raiders, key=lambda x: (x.x - a.x) ** 2 + (x.y - a.y) ** 2)
                    rng_ = 4.0 if self._ranged(a) else 1.2
                    ang = (a.id * 2.399) % 6.283
                    a.gx, a.gy = tg.x + math.cos(ang) * rng_, tg.y + math.sin(ang) * rng_
                else:
                    ang = (a.id * 2.399) % 6.283
                    a.gx, a.gy = cr["x"] + math.cos(ang) * (E.TOWN_WALL_R + 2), cr["y"] + math.sin(ang) * (E.TOWN_WALL_R + 2)
                if near and r.random() < .03: self._say(a, "defend", t=cr["name"])
                return
        elif a.state == "defend":
            a.state = "town"; a.task_until = 0
        # 3. help the player fight
        p = self.player
        if (near and a.faction == p["faction"] and tick - self.last_combat_tick < 16 and not self.inst and self._pdist(a) < 14
                and r.random() < PERSONAS[a.persona][4] * .5):
            tg = self.by_id.get(getattr(self, "selected_target", None) or -1)
            if tg and tg.kind == "monster" and tg.faction != a.faction and tg.hp > 0 and math.hypot(tg.x - a.x, tg.y - a.y) < 16:
                if a.state != "assist": self._say(a, "assist")
                a.state = "assist"; a.task_until = tick + 60
                rng_ = 4.0 if self._ranged(a) else 1.2
                a.gx, a.gy = tg.x + rng_ * .7, tg.y + rng_ * .7
                return
        # 4. challenge the player to a duel
        if self._maybe_challenge(a): return
        # 5. greet the player
        if near and self._pdist(a) < 5 and a.faction == p["faction"] and tick - a.last_greet > 2400 and a.persona != "shy" and r.random() < .35:
            a.last_greet = tick; self._say(a, "greet"); return
        # 6. daily life
        hour = (tick // 40) % 24
        night = hour >= 22 or hour < 6
        if night and a.persona != "explorer" and a.state not in ("rest",):
            own = [t for t in self.towns if self._friendly_town(t, a)] or self.towns
            t = min(own, key=lambda t: (t.x - a.x) ** 2 + (t.y - a.y) ** 2)
            if math.hypot(t.x - a.x, t.y - a.y) < 120:
                post = E.SHOP_POSTS["innkeeper"]; ang = (a.id * 2.399) % 6.283; rr = 2.0 + (a.id % 5) * .7
                a.state = "rest"; a.gx, a.gy = t.x + post[0] + math.cos(ang) * rr, t.y + post[1] + math.sin(ang) * rr
                a.task_until = tick + 200
                if near and r.random() < .3: self._say(a, "night")
                return
        if a.state == "rest":
            if night:
                if near and r.random() < .02: self._say(a, "night")
                return
            a.state = "town"; a.task_until = 0
        if a.state == "aiduel": return
        if tick < a.task_until and a.gx is not None:
            if a.state == "hunt" and math.hypot(a.gx - a.x, a.gy - a.y) < 1.5:
                # arrived at the hunting ground: roam around the den
                a.gx += r.uniform(-7, 7); a.gy += r.uniform(-7, 7)
            elif a.state == "town" and math.hypot(a.gx - a.x, a.gy - a.y) < 1.0:
                t = self._town_at(a.x, a.y, E.TOWN_WALL_R)
                if t:
                    post = E.SHOP_POSTS[r.choice(("vendor", "blacksmith", "innkeeper", "marketeer", "questgiver", "stablemaster"))]
                    a.gx, a.gy = t.x + post[0] + r.uniform(-2.5, 2.5), t.y + post[1] + r.uniform(-2.5, 2.5)
                    self._maybe_ai_duel(a)
                    if r.random() < .03: self._person_upgrade(a)
            if near and r.random() < (.035 if a.persona != "shy" else .005): self._say(a, a.state if a.state in LINES else "idle")
            return
        self._new_task(a)

    def _new_task(self, a):
        """Pick the next thing this person wants to do."""
        from . import engine as E
        r = self.rng; tick = self.tick
        pr = a.persona
        if a.state == "return" and r.random() < .4: self._person_upgrade(a)      # dungeon loot
        w = {"hunt": 46, "travel": 18, "town": 20, "group": 4}
        if pr == "explorer": w["travel"] = 42
        if pr == "trader": w["town"] = 34; w["travel"] = 28; w["hunt"] = 22
        if pr in ("proud", "aggressive"): w["hunt"] = 50; w["group"] = 10
        if pr == "shy": w["group"] = 1
        task = _wpick(r, list(w.items()))
        if task == "group" and a.level >= 8:
            self._form_party(a)
            if a.party: a.gx = None; return
            task = "hunt"
        if task == "hunt":
            ar = self._suit_area(a)
            dens = self._dens(ar) if hasattr(self, "_dens") else []
            if dens:
                cx, cy = r.choice(dens)
            else:
                cx, cy = ar[1] + r.uniform(5, ar[3] - 5), ar[2] + r.uniform(5, ar[4] - 5)
            a.state = "hunt"; a.gx, a.gy = cx + r.uniform(-6, 6), cy + r.uniform(-6, 6)
            a.task_until = tick + r.randint(900, 2600)
        elif task == "travel":
            towns = [t for t in self.towns if self._friendly_town(t, a)] or self.towns
            if pr != "explorer":
                ok = [t for t in towns if (lambda ar: ar is None or ar[6] - 10 <= a.level)(next((x for x in E.AREAS if x[0] == t.area), None))]
                towns = ok or towns
            here = self._town_at(a.x, a.y, E.TOWN_WALL_R)
            towns = [t for t in towns if t is not here] or towns
            t = r.choice(towns)
            a.state = "travel"; a.dest_town = t.id
            ang = r.uniform(0, 6.283); a.gx, a.gy = t.x + math.cos(ang) * 6, t.y + math.sin(ang) * 6
            a.task_until = tick + 99999
            if self._near_player(a, 30) and r.random() < .4: self._say(a, "travel", t=t.name)
        else:
            own = [t for t in self.towns if self._friendly_town(t, a)] or self.towns
            t = min(own, key=lambda t: (t.x - a.x) ** 2 + (t.y - a.y) ** 2)
            post = E.SHOP_POSTS[r.choice(("vendor", "blacksmith", "innkeeper", "marketeer", "questgiver"))]
            a.state = "town"; a.gx, a.gy = t.x + post[0] + r.uniform(-2.5, 2.5), t.y + post[1] + r.uniform(-2.5, 2.5)
            a.task_until = tick + r.randint(500, 1500)

    def _person_upgrade(self, a):
        """Saved up and bought (or crafted) better gear."""
        i = GEAR_TIERS.index(a.gear) if a.gear in GEAR_TIERS else 0
        cap = 4 + (a.level >= 30) + (a.level >= 40) + (a.level >= 60)
        if i + 1 <= cap and self.rng.random() < .5:
            a.gear = GEAR_TIERS[i + 1]
            if a.gear in ("Set", "Legendary", "Mythic") and not a.setl:
                a.setl = self.rng.choice(SET_KEYS)
            if a.gear in ("Set", "Legendary", "Mythic"):
                a.setp = tuple(SET_PIECES[:min(4, len(a.setp) + 2)])
            self._person_stats(a, heal=False)

    def _person_fight(self, a):
        """Hit the nearest enemy in reach (monsters, raiders, the other faction for brawlers)."""
        cand = self.actors_near(a, 4.5 if self._ranged(a) else 2.6)
        foes = []
        for x in cand:
            if x.hp <= 0: continue
            if x.kind == "monster" and x.faction == a.faction: continue          # 0.35: own side's soldiers
            if x.kind == "monster" and (x.role in ("raider", "watch") or x.level <= a.level + 4 or a.state in ("defend", "assist")):
                foes.append(x)
            elif (x.kind == "adventurer" and x.faction != a.faction and a.persona == "aggressive" and x.state not in ("aiduel",)
                  and not self._town_at(a.x, a.y, 30) and not (self.duel and self.duel["id"] == x.id)):
                foes.append(x)
        if not foes: return False
        t = min(foes, key=lambda x: (x.x - a.x) ** 2 + (x.y - a.y) ** 2)
        dmg = int(self._pdmg(a) * 2.0)      # a think is ~2.5 s: two swings
        t.hp -= dmg; a.atk_tick = self.tick; a.target = t.id
        if a.state not in ("defend", "assist"): a.gx = None
        if t.hp <= 0:
            a.kills += 1
            self._record_kill(t, a)
            self._person_gain(a, t.level)
        return True

    def _person_gain(self, a, lvl, mult=3):
        """Computer players (and recruited companions) level up.  0.46.27: a kill is worth 3x the monster's level (it was 1x, which
        took ages), several levels can come at once, and every level has a chance of better gear."""
        a.pxp = getattr(a, "pxp", 0) + max(1, int(lvl * mult))
        up = 0
        from . import engine as E
        top = 100 if (a.kind != "adventurer" or self._is_roamer(a)) else E.AREAS[a.id % len(E.AREAS)][7]          # 1.0.4: bots and npcs only grow to the top level of their zone
        while a.level < min(100, top):
            need = 60 + a.level * 18
            if a.pxp < need: break
            a.pxp -= need; a.level += 1; up += 1
            if a.kind == "adventurer":
                self._person_stats(a, heal=True)
                if self.rng.random() < .35: self._person_upgrade(a)
            else:                                   # a recruited guard: no gear tier, just tougher
                a.maxhp += 11; a.hp = a.maxhp
        if up and self._near_player(a, 25): self.events.append(f"{a.name} reached level {a.level}!")

    def party_share_xp(self, lvl):
        """0.46.27: every companion in your party earns experience from what you (or any of them) kill."""
        if self.inst: return
        for m in self.party_members():
            self._person_gain(m, lvl, 2)

    # ================================================================ AI-vs-AI duels in town
    def _maybe_ai_duel(self, a):
        if a.persona not in ("proud", "aggressive") or self.rng.random() > .06: return
        mates = [x for x in self.actors_near(a, 7, "adventurer") if x.persona in ("proud", "aggressive", "explorer") and x.state == "town"
                 and not x.party and x.hp > 0 and abs(x.level - a.level) <= 15 and not (self.duel and self.duel["id"] == x.id)]
        if not mates: return
        b = self.rng.choice(mates)
        for x, y in ((a, b), (b, a)):
            x.state = "aiduel"; x.duel_with = y.id; x.duel_end = self.tick + self.rng.randint(50, 110); x.gx = None
        mx, my = (a.x + b.x) / 2, (a.y + b.y) / 2
        a.x, a.y = mx - .9, my; b.x, b.y = mx + .9, my
        if self._near_player(a, 30):
            self._say(a, "challenge"); a.say = f"{b.name}! Let's settle this."; self._say(b, "accept")

    def _ai_duel_tick(self, a):
        b = self.by_id.get(a.duel_with)
        if not b or b.state != "aiduel" or b.duel_with != a.id:
            a.state = "town"; a.duel_with = None; a.hp = max(a.hp, 1); return
        if a.id > b.id: return            # the lower id runs the bout
        if self.tick % 5 == 0:
            for x, y in ((a, b), (b, a)):
                y.hp -= int(self._pdmg(x) * .9); x.atk_tick = self.tick
        if self.tick >= a.duel_end or a.hp <= a.maxhp * .1 or b.hp <= b.maxhp * .1:
            ra, rb = a.hp / a.maxhp, b.hp / b.maxhp
            win, lose = (a, b) if ra >= rb else (b, a)
            win.wins += 1; lose.losses += 1
            self._person_gain(win, lose.level, 2)       # 0.46.27: duels teach too
            for x in (a, b):
                x.state = "town"; x.duel_with = None; x.hp = x.maxhp; x.task_until = 0
            if self._near_player(a, 32):
                win.say = self.rng.choice(("Victory!", "Ha! Too slow.", "Good bout.")); win.say_until = self.tick + 20; win.say_seq += 1
                lose.say = self.rng.choice(("I yield!", "Next time...", "Well fought.")); lose.say_until = self.tick + 20; lose.say_seq += 1
                self.events.append(f"{win.name} defeated {lose.name} in a duel.")

    # ================================================================ duels with the player
    def _player_free(self):
        p = self.player
        return (not self.inst and not self.duel and not self.duel_offer and not getattr(self, "city_raid", None) and p["hp"] > 0
                and self.tick - self.last_combat_tick > 30 and not self.player_pvp)

    def _wager(self, a):
        return max(10, min(self.player["gold"] // 10, 15 + a.level * 12))

    def _maybe_challenge(self, a):
        if self.tick < self.offer_cool or not self._player_free(): return False
        if a.challenged_day == self.day or self._pdist(a) > 9: return False
        pl = self.player["level"]
        gap = a.level - pl
        if a.persona == "aggressive":
            if gap < -12 or gap > 20: return False
        elif abs(gap) > 14: return False
        chance = PERSONAS[a.persona][2] * (1.5 if a.faction != self.player["faction"] else 1.0)
        if self.rng.random() > chance: return False
        a.challenged_day = self.day
        death = a.faction != self.player["faction"] and a.persona == "aggressive" and self.rng.random() < .5
        self.duel_offer = {"id": a.id, "until": self.tick + OFFER_TICKS, "wager": 0 if death else self._wager(a), "kind": "death" if death else "duel"}
        self.offer_cool = self.tick + OFFER_COOLDOWN
        a.state = "offer"; a.gx = None
        self._say(a, "death_offer" if death else "challenge")
        self.events.append(f"{a.name} (level {a.level} {a.role}) challenges you to " + ("a fight to the death!" if death else "a duel!"))
        return True

    def duel_respond(self, accept):
        o = self.duel_offer
        if not o: return "Nobody is challenging you."
        self.duel_offer = None
        a = self.by_id.get(o["id"])
        if not a: return "They are gone."
        if not accept:
            a.state = "town"; a.task_until = 0
            a.say = self.rng.choice(("Coward!", "Pity.", "Suit yourself.", "Another time, then.")); a.say_until = self.tick + 20; a.say_seq += 1
            return f"You decline {a.name}'s challenge."
        if o.get("kind") == "death":
            self._start_death_fight(a); return ""
        return self._start_duel(a, o["wager"])

    def request_duel(self, aid):
        """You challenge someone. They may or may not want to."""
        a = self.by_id.get(aid)
        if not a or a.kind != "adventurer": return "There is nobody here to challenge."
        if self.duel: return "You are already in a duel."
        if self.inst or getattr(self, "city_raid", None): return "Not now - there are more important fights."
        if self._pdist(a) > 8: return f"{a.name} is too far away."
        if a.state in ("aiduel", "defend") or a.party: return f"{a.name} is busy."
        if self.tick - self.last_combat_tick < 20: return "You are still in combat."
        if self.tick < getattr(a, "refused_until", 0):
            return f"{a.name} doesn't want to duel you right now."
        gap = a.level - self.player["level"]
        acc = PERSONAS[a.persona][1]
        if gap < -10 and a.persona != "aggressive":
            line = "too_strong"; acc = 0
        elif gap > 18 and a.persona != "friendly":
            line = "too_weak"; acc *= .3
        else:
            line = "decline"
        if a.hp < a.maxhp * .7: acc *= .3
        if self.rng.random() < acc:
            self._say(a, "accept")
            return self._start_duel(a, self._wager(a))
        a.refused_until = self.tick + 1200
        self._say(a, line)
        return f"{a.name} refuses the duel."

    def _start_duel(self, a, wager):
        p = self.player
        wager = max(0, min(wager, p["gold"]))
        self.duel = {"id": a.id, "state": "count", "go": self.tick + DUEL_COUNT, "wager": wager, "start": self.tick}
        a.state = "duel"; a.gx = None; a.hp = a.maxhp; a.next_hit = self.tick + DUEL_COUNT + 2
        # face off a few steps apart
        dx, dy = a.x - p["x"], a.y - p["y"]; d = math.hypot(dx, dy) or 1
        want = 4.0 if self._ranged(a) else 2.4
        a.x, a.y = p["x"] + dx / d * want, p["y"] + dy / d * want
        self.selected_target = a.id
        self.events.append(f"Duel with {a.name} (level {a.level} {a.role}, {a.gear} gear)! Wager {wager}g. Fight starts in 3...")
        return ""

    def yield_duel(self):
        if not self.duel: return "You are not dueling."
        self._end_duel(False, yielded=True)
        return "You yield the duel."

    def _end_duel(self, won, yielded=False, forfeit=False):
        d = self.duel; self.duel = None
        a = self.by_id.get(d["id"]) if d else None
        p = self.player
        if not a: return
        a.refused_until = self.tick + 2400         # "we already fought today"
        if won:
            gold = d["wager"]; xp = (40 + a.level * 14) if a.id not in self._duel_xp_today() else 0
            p["gold"] += gold; p["xp"] += xp; a.losses += 1
            self._say(a, "lose")
            self._duel_xp_today().add(a.id)
            self.events.append(f"You won the duel against {a.name}! +{gold}g" + (f" +{xp} XP." if xp else "."))
            self._level_check()
        else:
            gold = min(p["gold"], d["wager"]); p["gold"] -= gold; a.wins += 1
            self._say(a, "yield_won" if yielded else "win")
            self.events.append(f"{a.name} won the duel{' - you yielded' if yielded else ' - you ran' if forfeit else ''}. -{gold}g.")
            p["hp"] = max(p["hp"], 1)
        a.hp = a.maxhp; a.state = "town"; a.task_until = self.tick + 40; a.gx = None
        if getattr(self, "selected_target", None) == a.id: self.selected_target = None
        self.offer_cool = max(self.offer_cool, self.tick + 600)
        self._save_player_fast()

    def _duel_xp_today(self):
        if getattr(self, "_dxp_day", None) != self.day: self._dxp_day = self.day; self._dxp = set()
        return self._dxp

    def _duel_guard(self, t):
        """Called when the player's hit would kill t: a dueling opponent yields at 1 HP instead."""
        d = self.duel
        if d and d["id"] == t.id:
            t.hp = 1; self._end_duel(True); return True
        return False

    def _person_hit_by_player(self, t):
        """You attacked someone outside a duel: they fight back (to the death)."""
        if self.duel and self.duel["id"] == t.id: return
        if t.id not in self.pfoes:
            self.pfoes[t.id] = self.tick
            t.state = "fight"; t.gx = None; t.next_hit = self.tick + 3
            if t.state != "aiduel": self._say(t, "angry")

    def _strike_player(self, a, lethal):
        """One attack from a computer player at you."""
        p = self.player
        if self.is_flying() and not self.inst: return       # 1.0.4: nothing can touch a rider on a flying mount
        raw = self._pdmg(a)
        special = self.rng.random() < .16
        if special:
            raw *= 1.8
            a.say = {"Warrior": "Mortal Strike!", "Ranger": "Aimed Shot!", "Mage": "Pyroblast!", "Cleric": "Smite!", "Rogue": "Backstab!",
                     "Paladin": "Judgement!", "Shaman": "Lightning Bolt!", "Druid": "Wrath!", "Berserker": "Bloodthirst!",
                     "Warlock": "Chaos Bolt!", "Monk": "Fists of Fury!", "Juggernaut": "Shield Slam!"}.get(a.role, "Take this!")
            a.say_until = self.tick + 8; a.say_seq += 1
        a.atk_tick = self.tick; self.last_combat_tick = self.tick
        if lethal:
            self.damage_player(raw, a, a.id)
            return
        # duel: same armour / dodge / shield rules, but nobody dies
        db = self._buff("dodge")
        if self.rng.random() < (db["value"] if db else 0) + self.passive_fx("dodge"):
            self.hits_taken.append({"id": a.id, "dmg": 0, "miss": True}); return
        ab = self._buff("armor")
        red = min(.8, self.passive_fx("armor_pct") + (ab["value"] if ab else 0))
        armor = p.get("armor", 1)
        dmg = max(1, int(raw * (1 - min(.6, armor / (armor + 180.))) * (1 - red)))
        sh = self._buff("shield"); absorbed = 0
        if sh:
            absorbed = min(sh["absorb"], dmg); sh["absorb"] -= absorbed; dmg -= absorbed
        if p["hp"] - dmg <= 0:
            p["hp"] = 1; self.hits_taken.append({"id": a.id, "dmg": dmg, "absorbed": absorbed})
            self._end_duel(False); return
        p["hp"] -= dmg; self.hits_taken.append({"id": a.id, "dmg": dmg, "absorbed": absorbed})

    def _fight_player_tick(self, a, lethal):
        """Move into range and attack you: used for duels and for fights you started."""
        p = self.player
        d = self._pdist(a)
        want = 4.2 if self._ranged(a) else 1.3
        if d > want + .3:
            self._step(a, p["x"], p["y"], .42)
        elif d < want - 1.6 and self._ranged(a):
            dx, dy = a.x - p["x"], a.y - p["y"]; n = math.hypot(dx, dy) or 1
            self._step(a, a.x + dx / n, a.y + dy / n, .3)
        if self.tick >= a.next_hit and d <= want + .6:
            a.next_hit = self.tick + (5 if self._ranged(a) else 4)
            self._strike_player(a, lethal)
        # healers patch themselves up once in a while
        if a.role in ("Cleric", "Shaman", "Druid", "Paladin") and a.hp < a.maxhp * .4 and self.tick - a.healed_t > 80:
            a.healed_t = self.tick; a.hp = min(a.maxhp, a.hp + int(a.maxhp * .25))
            a.say = "Heal!"; a.say_until = self.tick + 8; a.say_seq += 1

    # ================================================================ per tick
    def _people_tick(self):
        tick = self.tick
        p = self.player
        if tick % 400 == 0 and self.parties:
            # 0.34.2: also drop groups whose members all died, respawned or left - they used to pile up forever
            live = {a.party for a in self.actors if a.party}
            for k in [k for k, v in self.parties.items() if v.get("state") == "done" or k not in live]:
                self.parties.pop(k, None)
                for d in self.dungeons:
                    if d.party == k: d.party = 0; d.active = 0
        # duel offer expiry
        o = self.duel_offer
        if o:
            a = self.by_id.get(o["id"])
            if not a or tick >= o["until"] or self.inst or self._pdist(a) > 20:
                self.duel_offer = None
                if a: a.state = "town"; a.task_until = 0
            elif a:
                self._face_wait(a)
        # the duel
        d = self.duel
        if d:
            a = self.by_id.get(d["id"])
            if not a or self.inst or p["hp"] <= 0:
                self.duel = None
                if a: a.state = "town"; a.hp = a.maxhp
            elif self._pdist(a) > 26:
                self._end_duel(False, forfeit=True)
            elif d["state"] == "count":
                if tick >= d["go"]:
                    d["state"] = "fight"; a.say = "Fight!"; a.say_until = tick + 10; a.say_seq += 1
                    self.events.append("FIGHT!")
            else:
                self._fight_player_tick(a, lethal=False)
        self._outlaw_tick(); self._leader_tick()
        if self.tick % 4 == 0 and not self.inst: self._town_defense_tick()
        # fights you started
        if self.pfoes:
            for aid, t0 in list(self.pfoes.items()):
                a = self.by_id.get(aid)
                if not a or a.hp <= 0 or self.inst or self._pdist(a) > 30 or p["hp"] <= 0:
                    self.pfoes.pop(aid, None)
                    if a and a.hp > 0: a.hp = a.maxhp; a.state = "hunt"; a.task_until = 0
                    continue
                self._fight_player_tick(a, lethal=True)
        # raid defence: defenders and raiders trade blows
        cr = getattr(self, "city_raid", None)
        if cr and tick % 3 == 0:
            raiders = [self.by_id.get(i) for i in cr["ids"]]
            raiders = [x for x in raiders if x and x.hp > 0]
            if raiders:
                defs = [x for x in self.actors if x.kind == "adventurer" and x.state == "defend" and x.hp > 0
                        and (x.x - cr["x"]) ** 2 + (x.y - cr["y"]) ** 2 < 60 * 60]
                for df in defs:
                    reach = 4.6 if self._ranged(df) else 1.9
                    tg = min(raiders, key=lambda x: (x.x - df.x) ** 2 + (x.y - df.y) ** 2)
                    if (tg.x - df.x) ** 2 + (tg.y - df.y) ** 2 <= reach * reach and tick >= df.next_hit:
                        df.next_hit = tick + 5; df.atk_tick = tick
                        tg.hp -= int(self._pdmg(df))
                        if tg.hp <= 0:
                            df.kills += 1; self._record_kill(tg, df); raiders = [x for x in raiders if x.hp > 0 and x is not tg]
                            if not raiders: break
                for rd in raiders:
                    if rd.target == -2: continue            # busy with you
                    near = [x for x in defs if (x.x - rd.x) ** 2 + (x.y - rd.y) ** 2 < 2.6 * 2.6 and x.hp > 0]
                    if near and tick % 6 == 0:
                        v = self.rng.choice(near)
                        v.hp -= int((4 + rd.level * 1.6) * (2.2 if getattr(rd, "warlord", False) else 1) * self.rng.uniform(.8, 1.2))
                        if v.hp <= 0:
                            if self._near_player(v, 60): self.events.append(f"{v.name} fell defending {cr['name']}.")
                            self._person_respawn(v)
        # movement and AI duels
        pnear2 = 34 * 34
        px, py = p["x"], p["y"]
        for a in self.actors:
            if a.kind != "adventurer": continue
            if a.state == "aiduel":
                self._ai_duel_tick(a); continue
            if a.gx is None or a.state in ("duel", "fight", "offer"): continue
            pd2 = (a.x - px) ** 2 + (a.y - py) ** 2
            slow = pd2 > 3600 and a.state != "defend"
            if slow and (tick + a.id) % 4: continue        # far from you: move in bigger, rarer steps
            dx, dy = a.gx - a.x, a.gy - a.y
            dd = dx * dx + dy * dy
            if dd < .04: continue
            tx, ty = a.gx, a.gy
            if pd2 < pnear2 and a.state in ("travel", "hunt", "roam", "town"):
                wp = self._gate_wp(a, a.gx, a.gy)         # 1.0.8: leave and enter walled towns through their gates
                if wp: tx, ty = wp
            if a.state in ("travel", "hunt", "roam", "town"):
                # 1.0.7: a bot that cannot get closer to its current target for ~10 s (40 ticks) gives up and picks a new task
                dist_ = math.hypot(tx - a.x, ty - a.y)
                if getattr(a, "_pg", None) != (tx, ty):
                    a._pg = (tx, ty); a._pbest = dist_; a._pt = tick
                elif dist_ < a._pbest - .5:
                    a._pbest = dist_; a._pt = tick
                elif tick - a._pt > 40:
                    a.gx = None; a.task_until = 0; a.stuck = 0; a._pg = None
                    continue
            far = dd > 900
            sp = .9 if (far and a.state in ("travel", "hunt", "defend", "roam", "assault")) else (.55 if a.state in ("defend", "assist", "assault") else .38)
            if pd2 < pnear2:
                self._step(a, tx, ty, sp, check=True)
            else:
                self._step(a, tx, ty, sp * (4.0 if slow else 1.0))
            if a.state == "travel" and dd < 9:
                a.task_until = 0; a.state = "town"; a.gx = None
            elif a.state == "roam" and dd < 9:
                a.task_until = 0; a.gx = None
        # speech for the HUD
        if tick % 2 == 0:
            self.says = [{"id": a.id, "say": a.say, "seq": a.say_seq} for a in self.actors
                         if a.kind == "adventurer" and a.say and a.say_until > tick and (a.x - px) ** 2 + (a.y - py) ** 2 < 900
                         and getattr(a, "say_posted", -1) != a.say_seq]

    def _gate_wp(self, a, gx, gy):
        """1.0.8: bots have no pathfinding, so they used to press against a city wall on the straight line to their goal.
        Near a walled town this returns the next waypoint through one of its gates (the gap where a road leaves), or None."""
        ga = getattr(self, "gate_gaps", None)
        if not ga or getattr(self, "inst", None): return None
        from . import engine as E
        R = E.TOWN_WALL_R
        for entering in (False, True):                       # first get out of the town we are in, then into the goal's town
            for t in self.towns:
                gates = ga.get(t.id)
                if not gates: continue
                ax, ay = a.x - t.x, a.y - t.y; ra = math.hypot(ax, ay); rg = math.hypot(gx - t.x, gy - t.y)
                if not entering:
                    if not (ra < R + 1.2 and rg > R + 1.2): continue               # leaving this town
                    inside, outside = (a.x, a.y), (gx, gy)
                else:
                    if not (rg < R - 1.2 and ra > R - 1.5): continue               # entering it
                    inside, outside = (gx, gy), (a.x, a.y)
                best = None
                for g, hw in gates:
                    c, sn = math.cos(g), math.sin(g)
                    pin = (t.x + c * (R - 4), t.y + sn * (R - 4)); pout = (t.x + c * (R + 4), t.y + sn * (R + 4))
                    cost = math.hypot(inside[0] - pin[0], inside[1] - pin[1]) + math.hypot(outside[0] - pout[0], outside[1] - pout[1])
                    if best is None or cost < best[0]: best = (cost, c, sn, pin, pout, hw)
                _, c, sn, pin, pout, hw = best
                along = ax * c + ay * sn; perp = -ax * sn + ay * c
                if along >= R - 4.5 and abs(perp) < max(.8, hw - .8):    # already in the gate channel: go straight through
                    return pin if entering else pout
                return pout if entering else pin                           # otherwise walk to the gate's mouth on our side
        return None

    def _face_wait(self, a):
        p = self.player
        d = self._pdist(a)
        if d > 3.5: self._step(a, p["x"], p["y"], .3)

    def _step(self, a, tx, ty, sp, check=False):
        dx, dy = tx - a.x, ty - a.y
        d = math.hypot(dx, dy)
        if d < .05: return
        s = min(sp, d); ux, uy = dx / d, dy / d
        ok = getattr(self, "terrain_ok", None)
        if ok is not None and a.y < _world_h() and not getattr(self, "inst", None):
            try: here = ok(a.x, a.y)
            except Exception: here = False
            if here:
                for rot in (0, .7, -.7, 1.4, -1.4):
                    c, si = math.cos(rot), math.sin(rot)
                    vx, vy = ux * c - uy * si, ux * si + uy * c
                    nx, ny = a.x + vx * s, a.y + vy * s
                    try: good = ok(nx, ny)
                    except Exception: good = True
                    if good:
                        a.x, a.y = nx, ny; a.stuck = 0; break
                else:
                    a.stuck += 1
                    if a.stuck > 12: a.gx = None; a.task_until = 0; a.stuck = 0
                self._rehome(a); return
        from . import engine as E
        a.x = max(0, min(E.W - .01, a.x + ux * s)); a.y = max(0, min(E.WORLD_H - .01, a.y + uy * s))
        self._rehome(a)

    def _rehome(self, a):
        c = (int(a.x) >> 3, int(a.y) >> 3)
        if getattr(a, "_cell", None) != c:
            a._cell = c; a.home = self.area(a.x, a.y)[0]

    # ================================================================ death and respawn
    def _is_roamer(self, a):
        return a.kind == "adventurer" and ROAMER_BASE <= a.id < ROAMER_BASE + ROAMERS

    def _roamer_think(self, a):
        """1.0.4: roamers wander the whole map; strong ones sometimes march on an enemy town and fight its guards and leaders."""
        from . import engine as E
        r = self.rng; tick = self.tick
        if a.state == "assault":
            t = next((x for x in self.towns if x.id == getattr(a, "dest_town", -1)), None)
            if t is None or self.town_protected(t) or tick >= a.task_until or a.hp < a.maxhp * .3:
                a.state = "roam"; a.task_until = 0; a.gx = None
                return False
            self._roamer_assault(a, t)
            return True
        if a.state == "roam" and tick < a.task_until and a.gx is not None: return True
        # 1.0.4: assaults are rare - one at a time in the whole world, then a quiet spell of 40 to 80 minutes
        if (a.level >= 20 and tick >= getattr(self, "_next_assault", 0) and r.random() < .1 and not getattr(a, "resting", False)
                and not any(x.state == "assault" for x in self.actors if x.kind == "adventurer" and 9000 <= x.id < 9100)):
            foes = []
            for t in self.towns:
                if t.faction not in ("Alliance", "Horde") or t.faction == a.faction or self.town_protected(t): continue
                tier = self.town_tier(t)
                if tier == "capital" and (a.level < 80 or r.random() > .3): continue
                if tier == "city" and a.level < 45: continue
                foes.append(t)
            if foes:
                t = r.choice(foes); ang = r.uniform(0, 6.283)
                a.state = "assault"; a.dest_town = t.id; a.gx, a.gy = t.x + math.cos(ang) * 8, t.y + math.sin(ang) * 8
                a.task_until = tick + 4800; self._next_assault = tick + r.randint(9600, 19200)
                return True
        a.state = "roam"; a.gx, a.gy = r.uniform(8, E.W - 8), r.uniform(8, E.WORLD_H - 8)
        a.task_until = tick + r.randint(1500, 5000)
        return True

    def _roamer_assault(self, a, t):
        """An assaulting roamer inside the town hits the nearest guard or leader (the guards hit back in _town_defense_tick)."""
        tgts = [g for g in self.actors if g.kind == "npc" and (g.role == "guard" or g.role in LEADER_ROLES) and g.hp > 0
                and self.tick >= getattr(g, "down_until", 0) and getattr(g, "dead_until", 0) <= self.tick and (g.x - t.x) ** 2 + (g.y - t.y) ** 2 < 40 * 40]
        if not tgts or (a.x - t.x) ** 2 + (a.y - t.y) ** 2 > 40 * 40: return
        g = min(tgts, key=lambda q: (q.x - a.x) ** 2 + (q.y - a.y) ** 2)
        reach = 4.6 if self._ranged(a) else 2.0
        if (g.x - a.x) ** 2 + (g.y - a.y) ** 2 > reach * reach:
            a.gx, a.gy = g.x, g.y; return
        a.atk_tick = self.tick
        g.hp -= self._pdmg(a) * 2.2
        if g.hp > 0: return
        if g.role in LEADER_ROLES:
            self.leader_slain(g, by_player=False)
            if g.role == "king":                         # the ruler has fallen: the town is taken
                self.town_falls(t); a.state = "roam"; a.task_until = 0; a.gx = None
                msg = f"{t.name} has fallen to {a.name.split(' #')[0]}, a {a.faction} champion!"
                if t.faction == self.player["faction"]: self._alert(msg)
                else: self.events.append(msg)
        else:
            self._raid_defender_slain(g, [])

    def _person_respawn(self, a, count=True):
        """A fallen adventurer wakes at the nearest friendly town (like you do)."""
        own = [t for t in self.towns if self._friendly_town(t, a)] or self.towns
        if count: a.deaths += 1
        a.party = 0; a.target = -1
        self.pfoes.pop(a.id, None)
        if self.duel and self.duel["id"] == a.id: self.duel = None
        if own:
            t = min(own, key=lambda t: (t.x - a.x) ** 2 + (t.y - a.y) ** 2)
            ang = self.rng.uniform(0, 6.283)
            a.x, a.y = t.x + math.cos(ang) * 3, t.y + math.sin(ang) * 3
        a.hp = a.maxhp; a.state = "town"; a.gx = None; a.task_until = 0; a.home = self.area(a.x, a.y)[0]; a._cell = None

    # ================================================================ for the UI
    def person_info(self, aid):
        a = self.by_id.get(aid)
        if not a or not (a.kind == "adventurer" or (a.kind == "npc" and a.role == "guard")): return None
        if a.kind == "npc":
            ch, why = self.join_chance(a)
            return {"id": a.id, "name": a.name, "level": a.level, "cls": "Guard", "faction": a.faction, "gear": "Rare", "persona": "Sworn protector",
                    "activity": "On duty", "wins": 0, "losses": 0, "kills": a.kills, "deaths": a.deaths, "hp": a.hp, "maxhp": a.maxhp, "setl": "", "setp": [],
                    "dist": round(self._pdist(a), 1), "same": a.faction == self.player["faction"], "say": "", "can_duel": False, "can_fight": False,
                    "npc": True, "gear_rows": self.npc_gear(a), "in_party": self.is_pmember(a.id), "join_pct": int(ch * 100), "join_why": why,
                    "can_invite": not self.inst and ch > 0 and not self.is_pmember(a.id) and self._pdist(a) <= 8}
        act = {"hunt": f"Hunting in {a.home}", "travel": "Travelling" + (f" to {next((t.name for t in self.towns if t.id == getattr(a, 'dest_town', -1)), '')}"),
               "town": "Taking a break in town", "rest": "Resting for the night", "defend": "Defending the town", "assist": "Fighting beside you",
               "party": "Grouped for a dungeon", "aiduel": "Dueling", "duel": "Dueling you", "fight": "Fighting you!", "offer": "Waiting for your answer"}.get(a.state, "Wandering")
        if a.party: act = "Grouped for a dungeon"
        return {"id": a.id, "name": a.name, "level": a.level, "cls": a.role, "faction": a.faction, "gear": getattr(a, "gear", "Common"),
                "persona": PERSONAS.get(getattr(a, "persona", "friendly"), PERSONAS["friendly"])[0], "activity": act,
                "wins": getattr(a, "wins", 0), "losses": getattr(a, "losses", 0), "kills": a.kills, "deaths": a.deaths,
                "hp": a.hp, "maxhp": a.maxhp, "setl": getattr(a, "setl", ""), "setp": list(getattr(a, "setp", ())),
                "dist": round(self._pdist(a), 1), "same": a.faction == self.player["faction"],
                "say": a.say if a.say and a.say_until > self.tick - 40 else "",
                "can_duel": not self.duel and not self.inst and self._pdist(a) <= 8,
                "can_fight": a.faction != self.player["faction"] and not self.duel and not self.inst and self._pdist(a) <= 8 and a.id not in self.pfoes,
                "gear_rows": self.npc_gear(a), "in_party": self.is_pmember(a.id), "join_pct": int(self.join_chance(a)[0] * 100), "join_why": self.join_chance(a)[1],
                "can_invite": not self.inst and self.join_chance(a)[0] > 0 and not self.is_pmember(a.id) and self._pdist(a) <= 8}

    def greet_person(self, aid):
        a = self.by_id.get(aid)
        if not a or a.kind != "adventurer" or not hasattr(a, "persona"): return "Nobody there."
        if a.faction != self.player["faction"] and a.persona in ("aggressive", "proud"):
            a.say = self.rng.choice(("Keep walking.", "What do you want?", f"Your kind isn't welcome, {self.player['name']}.")); a.say_until = self.tick + 20; a.say_seq += 1
        elif a.persona == "shy":
            a.say = self.rng.choice(("...hello.", "Oh! Hi.", "*nods*")); a.say_until = self.tick + 20; a.say_seq += 1
        else:
            self._say(a, "greet")
        a.say_posted = a.say_seq            # shown right away by the caller; keep it out of the chat feed
        return f"{a.name}: \"{a.say}\""

    def duel_info(self):
        d = self.duel
        if not d: return None
        a = self.by_id.get(d["id"])
        if not a: return None
        return {"id": a.id, "name": a.name, "level": a.level, "cls": a.role, "gear": getattr(a, "gear", "Common"), "hp": max(0, a.hp), "maxhp": a.maxhp,
                "state": d["state"], "count": max(0, (d["go"] - self.tick + 3) // 4), "wager": d["wager"]}

    def offer_info(self):
        o = self.duel_offer
        if not o: return None
        a = self.by_id.get(o["id"])
        if not a: return None
        return {"id": a.id, "name": a.name, "level": a.level, "cls": a.role, "gear": getattr(a, "gear", "Common"), "faction": a.faction,
                "wager": o["wager"], "left": max(0, (o["until"] - self.tick) // 4), "kind": o.get("kind", "duel")}

    def people_snapshot(self):
        cr = getattr(self, "city_raid", None)
        defenders = 0
        if cr:
            defenders = sum(1 for x in self.actors if x.kind == "adventurer" and x.state == "defend" and (x.x - cr["x"]) ** 2 + (x.y - cr["y"]) ** 2 < 70 * 70)
        return {"duel": self.duel_info(), "duel_offer": self.offer_info(), "says": self.says, "defenders": defenders}

    def person_snap_fields(self, x, d):
        """Extra fields for an adventurer in the actor snapshot."""
        d["gear"] = getattr(x, "gear", "Common"); d["setl"] = getattr(x, "setl", ""); d["setp"] = list(getattr(x, "setp", ()))
        d["atk"] = getattr(x, "atk_tick", -99)
        if x.say and x.say_until > self.tick: d["say"] = x.say; d["say_seq"] = x.say_seq
        du = self.duel
        if du and du["id"] == x.id:
            d["duel"] = True; d["hostile"] = du["state"] == "fight"
        if x.id in self.pfoes: d["hostile"] = True
        if x.state == "aiduel": d["aiduel"] = True
        if x.state == "defend": d["defending"] = True
