#!/usr/bin/env python3
"""LiveWorld RPG smoke tests.

Runs the real game code headlessly (SDL dummy video/audio) against a throwaway save
folder, so it never touches ~/.local/share/liveworld-rpg.

    python3 tests/smoke_test.py                 # everything
    python3 tests/smoke_test.py ArenaMaps       # one group
    LW_PKG=/path/to/package-root python3 tests/smoke_test.py

LW_PKG is the source tree (the folder holding DEBIAN/ and usr/); it defaults to this folder's parent.
"""
import collections, hashlib, json, math, os, re, sys, tempfile, unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = Path(os.environ.get("LW_PKG", HERE.parent)).resolve()
LIB = PKG / "usr" / "lib" / "liveworld-rpg"

os.environ["LIVEWORLD_DATA"] = tempfile.mkdtemp(prefix="lw-smoke-")
os.environ["XDG_STATE_HOME"] = tempfile.mkdtemp(prefix="lw-smoke-state-")
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
sys.path.insert(0, str(LIB))

from liveworld_rpg import arena as A, instance as I, engine as E   # noqa: E402

ALL_MODES = list(A.MODES)
CLASSES = list(E.CLASSES)


def new_world(level=20, faction="Alliance", cls="Warrior"):
    """A fresh world in its own save folder."""
    E.DATA = Path(tempfile.mkdtemp(prefix="lw-world-"))
    E.DB = E.DATA / "world.db"
    w = E.World()
    w.create_character("Smoke", faction, cls)
    w.player["level"] = level
    return w


def flood(floor, start):
    start = (int(start[0]), int(start[1]))
    seen = {start}; q = collections.deque([start])
    while q:
        x, y = q.popleft()
        for n in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if n in floor and n not in seen:
                seen.add(n); q.append(n)
    return seen


def enter(w, mode):
    """Enter an arena, first leaving whatever an earlier failed check left us in."""
    if w.inst: w.leave_instance(silent=True)
    msg = w.enter_arena(mode)
    assert isinstance(w.inst, A.Arena), msg
    return w.inst


def run_until_out(w, limit):
    n = 0
    while w.inst is not None and n < limit:
        w.update(1); n += 1
    return n


# ======================================================================= package
class Package(unittest.TestCase):
    def test_versions_agree(self):
        control = (PKG / "DEBIAN" / "control").read_text()
        deb_ver = re.search(r"^Version:\s*(\S+)", control, re.M).group(1)
        game_ver = re.search(r'^VERSION = "([^"]+)"', (LIB / "liveworld_rpg" / "game.py").read_text(), re.M).group(1)
        init_ver = re.search(r'__version__\s*=\s*"([^"]+)"', (LIB / "liveworld_rpg" / "__init__.py").read_text()).group(1)
        meta = (PKG / "usr/share/metainfo/liveworld-rpg.metainfo.xml").read_text()
        meta_ver = re.search(r'<release version="([^"]+)"', meta).group(1)
        guide_head = (PKG / "usr/share/doc/liveworld-rpg/GUIDE.md").read_text().splitlines()[0]
        self.assertEqual({deb_ver, game_ver, init_ver, meta_ver}, {deb_ver},
                         f"control {deb_ver}, game.py {game_ver}, __init__ {init_ver}, metainfo {meta_ver}")
        self.assertIn(".".join(deb_ver.split(".")[:2]), guide_head)

    def test_md5sums_cover_every_file(self):
        listed = {}
        for line in (PKG / "DEBIAN" / "md5sums").read_text().splitlines():
            h, p = line.split(None, 1); listed[p.strip()] = h
        actual = {str(f.relative_to(PKG)) for f in (PKG / "usr").rglob("*") if f.is_file() and "__pycache__" not in f.parts}
        self.assertEqual(sorted(set(listed) ^ actual), [], "files missing from / extra in md5sums")
        for p, h in listed.items():
            self.assertEqual(hashlib.md5((PKG / p).read_bytes()).hexdigest(), h, p)

    def test_guide_md_matches_ingame_guide(self):
        from liveworld_rpg import guide
        md = (PKG / "usr/share/doc/liveworld-rpg/GUIDE.md").read_text()
        body = md.split("\n", 1)[1]
        want = "".join(f"\n## {t}\n\n" + "".join(f"- {l}\n" for l in lines) for t, lines in guide.PAGES)
        self.assertEqual(body.strip(), want.strip())

    def test_launchers_and_desktop_files(self):
        for b in ("liveworld-rpg", "liveworld-create-character", "liveworld-uninstall"):
            f = PKG / "usr/bin" / b
            self.assertTrue(os.access(f, os.X_OK), b)
            self.assertTrue(f.read_text().startswith("#!/bin/sh"), b)
        for d in (PKG / "usr/share/applications").glob("*.desktop"):
            txt = d.read_text()
            exe = re.search(r"^Exec=(\S+)", txt, re.M).group(1)
            self.assertTrue((PKG / "usr/bin" / exe).exists(), f"{d.name}: {exe}")

    def test_shell_scripts(self):
        """0.37.2: every script parses with /bin/sh (dash on Debian/Ubuntu) and uses no bash-only read -p."""
        import subprocess
        for f in list((PKG / "usr/bin").iterdir()) + [PKG / "DEBIAN/postinst", PKG / "DEBIAN/postrm", PKG / "build.sh"]:
            with self.subTest(script=f.name):
                self.assertEqual(subprocess.run(["sh", "-n", str(f)]).returncode, 0)
                self.assertNotIn("read -r -p", f.read_text())


# ========================================================================= saves
class Saves(unittest.TestCase):
    """0.37.2: damaged saves and settings files never stop the game starting."""

    def test_damaged_save_is_restored_from_backup(self):
        E.DATA = Path(tempfile.mkdtemp(prefix="lw-save-")); E.DB = E.DATA / "world.db"
        w, msg = E.open_world(); self.assertIsNone(msg)
        w.create_character("Keeper", "Horde", "Monk"); w.player["gold"] = 4321; w.close()
        self.assertTrue((E.DATA / "world.db.bak").exists())
        E.DB.write_bytes(b"\0not a database" * 200)
        for s in ("-wal", "-shm"):
            if (E.DATA / ("world.db" + s)).exists(): (E.DATA / ("world.db" + s)).unlink()
        w, msg = E.open_world()
        self.assertIn("restored", msg); self.assertEqual((w.player["name"], w.player["gold"]), ("Keeper", 4321)); w.close()
        self.assertTrue(list(E.DATA.glob("world.db.damaged-*")), "the damaged file must be kept")

    def test_damaged_save_without_backup_starts_fresh(self):
        E.DATA = Path(tempfile.mkdtemp(prefix="lw-save-")); E.DB = E.DATA / "world.db"
        E.DB.write_bytes(b"garbage" * 100)
        w, msg = E.open_world()
        self.assertIn("new world", msg); self.assertFalse(w.character_created()); w.close()

    def test_bad_settings_file(self):
        from liveworld_rpg import game as G
        G.SETTINGS.write_text("[1, 2, 3]")
        self.assertEqual(G.load_settings(), {})
        G.SETTINGS.write_text(json.dumps({"brightness": "bright", "vol_master": 9, "vol_sfx": float("nan"), "quality": "High"}))
        st = G.load_settings()
        self.assertEqual(G.setting_num(st, "brightness", 1.0, .7, 1.6), 1.0)
        self.assertEqual(G.setting_num(st, "vol_master", .8, 0, 1), 1)
        self.assertEqual(G.setting_num(st, "vol_sfx", .8, 0, 1), .8)
        self.assertIn(G.default_quality(), (1, 2))
        G.SETTINGS.unlink()


# ========================================================================= 0.38 magic shop
class MagicShop(unittest.TestCase):
    """Spell ranks, stat points, passives and the hotbar layout are bought at the Skill Shop in every town."""

    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.w = new_world(level=55, cls="Warrior"); cls.w.player["gold"] = 100000
        cls.layout = gfx.WorldLayout(cls.w); cls.w.station_posts = cls.layout.stations

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def at_shop(self, on=True):
        x, y = self.w.station_posts["magic"][0]
        self.w.player["x"], self.w.player["y"] = (x + 2, y + 2) if on else (x + 40, y + 40)

    def test_every_town_has_a_magic_shop(self):
        shops = self.layout.stations.get("magic", [])
        for t in self.w.towns:
            with self.subTest(town=t.name):
                self.assertTrue(any((x - t.x) ** 2 + (y - t.y) ** 2 < 25 ** 2 for x, y in shops))

    def test_spending_only_at_the_shop_and_costs_gold(self):
        w = self.w; self.at_shop(False)
        self.assertIn("Skill Shop", w.rank_up("Cleave")); self.assertIn("Skill Shop", w.add_stat("str"))
        self.at_shop(True); g0 = w.player["gold"]; r0 = w.ability_rank("Cleave"); pts = w.rank_points_left()
        self.assertIn("rank", w.rank_up("Cleave"))
        self.assertEqual((w.ability_rank("Cleave"), w.rank_points_left()), (r0 + 1, pts - 1)); self.assertLess(w.player["gold"], g0)
        s0 = w._build()["s"]["vit"]; w.add_stat("vit", 5); self.assertEqual(w._build()["s"]["vit"], s0 + 5)

    def test_ranks_go_to_ten(self):
        w = self.w; self.at_shop(True)
        for _ in range(12): w.rank_up("Rend")
        self.assertEqual(w.ability_rank("Rend"), 10)
        self.assertIn("maximum", w.rank_up("Rend"))

    def test_passive_slots_and_choice(self):
        w = self.w; self.at_shop(True)
        for lvl, n in ((1, 1), (20, 1), (50, 1), (51, 2), (74, 2), (75, 3), (100, 3)):
            w.player["level"] = lvl; self.assertEqual(w.passive_slots(), n, lvl); self.assertEqual(len(w.equipped_passives()), n, lvl)
        w.player["level"] = 55
        for cls_, pool in E.PASSIVES.items():
            self.assertEqual(len(pool), 7, cls_)
        self.assertIn("Passive", w.equip_passive("Deep Wounds", 1))
        self.assertIn("Deep Wounds", [p["name"] for p in w.equipped_passives()])
        self.assertIn("unlocks", w.equip_passive("Warlord", 0))

    def test_hotbar_swap_moves_the_skill(self):
        w = self.w; self.at_shop(True)
        first, cap = w.ability_info()[0]["name"], w.ability_info()[10]["name"]
        self.assertIn("swapped", w.swap_slots("1", "!"))
        self.assertEqual((w.ability_info()[0]["name"], w.ability_info()[10]["name"]), (cap, first))
        w.swap_slots("1", "!")
        self.assertEqual(w.ability_info()[0]["name"], first)


# ========================================================================= 0.38 consent pvp and outlaws
class Outlaws(unittest.TestCase):
    """Other factions can't be attacked without consent; killing one makes you an outlaw that every guard attacks."""

    def setUp(self):
        self.w = new_world(level=40, faction="Alliance", cls="Warrior")
        self.foe = next(a for a in self.w.actors if a.kind == "adventurer" and a.faction == "Horde")
        p = self.w.player; self.foe.x, self.foe.y = p["x"] + 1.5, p["y"]; self.foe.party = 0; self.foe.state = "town"
        self.w._grid_tick = -1

    def tearDown(self):
        self.w.close()

    def test_no_attack_without_consent(self):
        w = self.w
        self.assertFalse(w._hostile_adv(self.foe))
        self.assertEqual(w.attack_target(self.foe.id), "Invalid enemy target.")
        self.assertNotIn(self.foe, w._enemies())

    def test_accepted_fight_then_kill_makes_outlaw(self):
        w = self.w; w._start_death_fight(self.foe)
        self.assertTrue(w._hostile_adv(self.foe))
        self.foe.hp = 1; w.player["level"] = 90
        w.attack_target(self.foe.id)
        self.assertGreater(w.outlaw_left(), 0)
        self.assertEqual(w.snapshot()["player"]["outlaw"], (w.outlaw_left() + 3) // 4)

    def test_city_raid_kills_never_make_an_outlaw(self):
        w = self.w; w._start_death_fight(self.foe)
        w.city_raid = {"x": self.foe.x, "y": self.foe.y, "ids": [], "defs": [], "town": -1}
        self.foe.hp = 1; w.player["level"] = 90
        w.attack_target(self.foe.id)
        self.assertEqual(w.outlaw_left(), 0)
        w.city_raid = None

    def test_battleground_kills_never_make_an_outlaw(self):
        w = self.w
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                inst = enter(w, mode)
                foe = next(a for a in inst.actors.values() if getattr(a, "team", "") == "red")
                foe.hp = 1; w.player["level"] = 90; w.player["x"], w.player["y"] = foe.x + 1, foe.y
                w.attack_target(foe.id)
                self.assertEqual(w.outlaw_left(), 0)
                w.leave_instance(silent=True)

    def test_guards_attack_outlaws_and_death_clears_it(self):
        w = self.w; w._set_outlaw(True)
        guard = next(a for a in w.actors if a.kind == "npc" and a.role == "guard")
        self.assertTrue(w._guard_hostile(guard))
        w.player["x"], w.player["y"] = guard.x + 1, guard.y; w.player["hp"] = 10 ** 6
        hp0 = w.player["hp"]
        for _ in range(40): w._outlaw_tick(); w.tick += 1
        self.assertLess(w.player["hp"], hp0, "guards must hit an outlaw")
        self.assertNotEqual(w.attack_target(guard.id), "Invalid enemy target.")
        guard.hp = 1; w.player["level"] = 90; w.player["x"], w.player["y"] = guard.x + 1, guard.y
        self.assertIn("Defeated", w.attack_target(guard.id))          # a beaten guard falls back (no crash)
        self.assertEqual(guard.hp, guard.maxhp)
        w._player_died(guard)
        self.assertEqual(w.outlaw_left(), 0)

    def test_outlaw_flag_survives_a_reload(self):
        w = self.w; w._set_outlaw(True); left = w.outlaw_left(); db = E.DB
        w.close(); E.DB = db
        self.w = E.World()
        self.assertAlmostEqual(self.w.outlaw_left(), left, delta=4)


# ========================================================================= 0.39 town leaders
class TownLeaders(unittest.TestCase):
    """Quest givers and rulers of enemy towns can be slain (city raids, or a strong hero alone) and return in 30 minutes."""

    def setUp(self):
        self.w = new_world(level=90, faction="Alliance", cls="Warrior")
        self.w.player["level"] = 90
        self.enemy = next(t for t in self.w.towns if t.faction == "Horde")
        self.own = next(t for t in self.w.towns if t.faction == "Alliance")

    def tearDown(self):
        self.w.close()

    def leader(self, t, role):
        return next(a for a in self.w.actors if a.kind == "npc" and a.role == role and self.w._town_for_actor(a) is t)

    def test_own_town_leaders_are_safe(self):
        self.assertFalse(self.w.leader_attackable(self.leader(self.own, "king")))

    def test_slay_enemy_quest_giver_and_respawn(self):
        w = self.w; qg = self.leader(self.enemy, "questgiver")
        self.assertTrue(w.leader_attackable(qg))
        w.player["x"], w.player["y"] = qg.x + 1, qg.y
        for _ in range(400):
            if qg.hp <= 0: break
            w.attack_target(qg.id); w.tick += 1
        self.assertLessEqual(qg.hp, 0, "a level 90 hero must beat a low town's quest giver")
        self.assertGreater(w.outlaw_left(), 0)
        self.assertTrue(any(w._guard_hostile(g) for g in w.actors if g.kind == "npc" and g.role == "guard" and w._town_for_actor(g) is self.enemy))
        w.tick = (qg.dead_until // 40 + 1) * 40; w._leader_tick()        # respawns are checked every 10 s
        self.assertEqual(qg.hp, qg.maxhp)

    def test_fallen_town_loses_its_leaders(self):
        w = self.w; w.town_falls(self.enemy)
        self.assertLessEqual(self.leader(self.enemy, "king").hp, 0)
        self.assertLessEqual(self.leader(self.enemy, "questgiver").hp, 0)

    def test_guards_are_posted(self):
        for t in self.w.towns[:5]:
            names = [a.name.split(" ")[0] + " " + a.name.split(" ")[1] for a in self.w.actors if a.kind == "npc" and a.role == "guard" and self.w._town_for_actor(a) is t]
            self.assertGreaterEqual(names.count("Gate Guard"), 4); self.assertGreaterEqual(names.count("City Patrol"), 3); self.assertGreaterEqual(names.count("Royal Guard"), 4)


# ========================================================================= 0.39 jewelcrafting
class Jewels(unittest.TestCase):
    """Jewels are cut at the Jeweler's Kiln, become rings and necklaces, and go into gear sockets."""

    def setUp(self):
        from liveworld_rpg import gfx
        self.w = new_world(level=55, cls="Warrior"); w = self.w
        w.station_posts = gfx.WorldLayout(w).stations
        w.player["gold"] = 10 ** 6; w._inv_add("Mat:Iron Ore", 300); w._inv_add("Mat:Arcane Dust", 100); w.db.commit()
        x, y = w.station_posts["kiln"][0]; w.player["x"], w.player["y"] = x + 2, y + 2

    def tearDown(self):
        self.w.close()

    def test_every_town_has_jeweler_and_kiln(self):
        for k in ("jeweler", "kiln", "apothecary", "inn", "smithy", "general", "stable", "market"):
            self.assertEqual(len(self.w.station_posts.get(k, [])), len(self.w.towns), k)

    def test_cut_craft_wear_and_socket(self):
        w = self.w
        self.assertIn("cut", w.cut_jewel("Clean Ruby")); self.assertIn("cut", w.cut_jewel("Clean Ruby")); self.assertIn("cut", w.cut_jewel("Flawless Diamond"))
        self.assertIn("unlocks", w.cut_jewel("Perfect Ruby").replace("need level", "unlocks"))
        self.assertIn("craft", w.craft_jewelry("ring|Clean Ruby"))
        w._grant_gear("Epic Runed Greatsword", "weapon", "Epic", 80, "test")
        ids = {r["item"]: r for r in w.inventory_rows()}
        gid = ids["Epic Runed Greatsword"]["id"]
        self.assertEqual(ids["Epic Runed Greatsword"]["sockets"], 0, "gear starts without sockets")
        w._inv_add("Mat:Spirit Essence", 10); w.db.commit()
        self.assertIn("opens socket 1", w.add_socket(gid))
        s0 = w.stats()["str"]
        w.equip_gear(ids["Clean Ruby Ring"]["id"]); w._gear_changed()
        self.assertEqual(w.stats()["str"], s0 + 10)
        w.equip_gear(ids["Epic Runed Greatsword"]["id"])
        c0 = w.crit_chance(); self.assertIn("set into", w.socket_jewel(ids["Epic Runed Greatsword"]["id"], "Flawless Diamond"))
        self.assertGreater(w.crit_chance(), c0)
        self.assertIn("no free socket", w.socket_jewel(ids["Epic Runed Greatsword"]["id"], "Clean Ruby"))
        self.assertIn("opens socket 2", w.add_socket(gid)); self.assertIn("opens socket 3", w.add_socket(gid))
        self.assertIn("already has 3", w.add_socket(gid))
        w.player["level"] = 5; self.assertIn("needs level", w.add_socket(ids["Clean Ruby Ring"]["id"])); w.player["level"] = 55
        self.assertIn("shatters", w.unsocket_jewel(ids["Epic Runed Greatsword"]["id"], 0))
        self.assertAlmostEqual(w.crit_chance(), c0)

    def test_two_rings(self):
        w = self.w
        for _ in range(3): w.cut_jewel("Clean Emerald"); w.craft_jewelry("ring|Clean Emerald")
        rings = [r for r in w.inventory_rows() if r["slot"] == "ring"]
        for r in rings: w.equip_gear(r["id"])
        self.assertEqual(sum(1 for r in w.inventory_rows() if r["slot"] == "ring" and r["equipped"]), 2)

    def test_kiln_needed(self):
        w = self.w; w.player["x"] += 60
        self.assertIn("Kiln", w.cut_jewel("Clean Ruby"))


# ========================================================================= 0.40 shops
class Shops(unittest.TestCase):
    """The Blacksmith sells weapons and armor, the General Store supplies, the Apothecary potions; the Forge only crafts."""

    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.w = new_world(level=30); cls.w.station_posts = gfx.WorldLayout(cls.w).stations; cls.w.place_town_npcs(); cls.w.player["gold"] = 10 ** 6

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def open(self, kind):
        w = self.w; t = w.towns[0]
        x, y = min(w.station_posts[kind], key=lambda q: (q[0] - t.x) ** 2 + (q[1] - t.y) ** 2)
        w.player["x"], w.player["y"] = x + 1.5, y + 1.5; w.talk_to = None; w.click_station = kind
        w.interact_nearby(); return w.open_ui, getattr(w, "shop_npc", None)

    def test_no_caravan_merchants(self):
        """0.40.1: the wandering Caravan Merchants are gone, and the Stable Master and Market Warden work inside their buildings."""
        self.assertFalse([a for a in self.w.actors if a.kind == "npc" and a.role == "merchant"])
        ui, _ = self.open("stable"); self.assertEqual(ui, "stable")
        ui, _ = self.open("market"); self.assertEqual(ui, "market")

    def test_blacksmith_sells_gear(self):
        ui, npc = self.open("smithy"); self.assertEqual(ui, "shop")
        tabs = {t["name"]: t["items"] for t in self.w.shop_view(npc)["tabs"]}
        self.assertTrue(tabs.get("Weapons")) ; self.assertTrue(tabs.get("Armor"))
        key = tabs["Weapons"][0]["key"]; self.assertIn("Bought", self.w.shop_buy(npc, key))

    def test_general_store_sells_supplies(self):
        ui, npc = self.open("general"); self.assertEqual(ui, "shop")
        names = [i["label"] for t in self.w.shop_view(npc)["tabs"] for i in t["items"]]
        for want in ("Scroll of Teleportation", "Fishing Bait", "Iron Ore"): self.assertIn(want, names)
        self.assertIn("Bought", self.w.shop_buy(npc, "g:Fishing Bait"))

    def test_apothecary_sells_potions(self):
        ui, npc = self.open("apothecary")
        names = [i["label"] for t in self.w.shop_view(npc)["tabs"] for i in t["items"]]
        self.assertIn("Health Potion", names); self.assertIn("Scroll of Might", names)

    def test_magic_shop_sells_zone_level_magic_items(self):
        ui, npc = self.open("enchanter"); self.assertEqual(ui, "shop")
        t = self.w.towns[0]; lo, hi = self.w._zone_band(t)
        items = [i for tab in self.w.shop_view(npc)["tabs"] if not tab.get("name", tab.get("label", "")).startswith("Zone Set") for i in tab["items"]]      # the Zone Set tab has its own "Set" rarity
        self.assertTrue(items and all(i["rarity"] in ("Rare", "Epic", "Elite") for i in items))
        lv = [int(i["sub"].split()[1]) for i in items]
        self.assertTrue(all(lo <= x <= hi for x in lv), (lo, hi, lv))
        epic = next(i for i in items if i["rarity"] == "Epic")
        self.w.shop_buy(npc, epic["key"])
        self.assertEqual(self.w.inventory_rows()[0]["sockets"] if self.w.inventory_rows()[0]["item"] == epic["item"] else max(r["sockets"] for r in self.w.inventory_rows() if r["item"] == epic["item"]), 1)

    def test_bank_opens_vault(self):
        ui, _ = self.open("bank"); self.assertEqual(ui, "vault")
        self.assertIsNotNone(self.w.vault_view())

    def test_sets_only_from_raids(self):
        rows = [r for tab in self.w._smith_recipes() for r in tab["rows"]]
        self.assertTrue(rows)
        self.assertFalse([r for r in rows if r.get("rarity") == "Set" or r.get("set_name")], "the Forge must not make set pieces")

    def test_forge_only_crafts(self):
        ui, npc = self.open("forge")
        self.assertEqual(ui, "craft"); self.assertIsNone(npc)


# ========================================================================= world
class WorldBoot(unittest.TestCase):
    def test_every_class_and_faction(self):
        for faction in ("Alliance", "Horde"):
            for cls in CLASSES:
                with self.subTest(faction=faction, cls=cls):
                    w = new_world(level=1, faction=faction, cls=cls)
                    self.assertEqual((w.player["class"], w.player["faction"]), (cls, faction))
                    self.assertTrue(w.character_created())
                    w.update(8)
                    self.assertIsNone(w.inst)
                    w.close()

    def test_world_survives_a_reload(self):
        w = new_world(level=7)
        w.player["gold"] = 1234; w._save_player_fast(); w._save_all(force=True); w.close()
        w2 = E.World()
        self.assertEqual((w2.player["name"], w2.player["level"], w2.player["gold"]), ("Smoke", 7, 1234))
        w2.close()


# ===================================================================== arena maps
class ArenaMaps(unittest.TestCase):
    """Layout checks for every battleground map - no simulation."""

    @classmethod
    def setUpClass(cls):
        cls.w = new_world(level=30)

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def build(self, mode):
        return enter(self.w, mode)

    def tearDown(self):
        if self.w.inst: self.w.leave_instance(silent=True)

    def test_mode_table(self):
        names = set()
        for mode, cfg in A.MODES.items():
            with self.subTest(mode=mode):
                self.assertIn(cfg["n"], (12, 24))
                self.assertIn(cfg.get("rules", mode), ("tdm", "ctf", "dom"))
                self.assertGreater(cfg["target"], 0); self.assertGreater(cfg["time"], 0)
                self.assertEqual(cfg["time"], 240 if cfg["n"] == 12 else 480, "battlegrounds last 4 minutes (12v12) or 8 (24v24)")
                self.assertTrue(cfg["map"] and cfg["map"] in cfg["desc"])
                names.add(cfg["map"])
        self.assertEqual(len(names), len(A.MODES), "every mode needs its own map")

    def test_objectives_on_floor_and_reachable(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                a = self.build(mode)
                reach = flood(a.floor, a.spawn)
                self.assertEqual(len(reach), len(a.floor), f"{len(a.floor) - len(reach)} floor tiles cut off")
                spots = {"blue base": a.blue_base, "red base": a.red_base, "spawn": a.spawn}
                spots.update({f"portal{i}": p for i, p in enumerate(a.portals)})
                spots.update({f"shrine{i}": s for i, s in enumerate(a.shrines)})
                spots.update({f"{t} flag": f["home"] for t, f in a.flags.items()})
                spots.update({f"point {p['n']}": (p["x"], p["y"]) for p in a.points})
                for name, (x, y) in spots.items():
                    self.assertTrue((int(x), int(y)) in reach, f"{name} at ({x:.1f},{y:.1f}) is not walkable")
                self.assertEqual(len(a.shrines), a.cfg["shrines"])
                if a.mode == "ctf": self.assertEqual(set(a.flags), {"blue", "red"})
                if a.mode == "dom": self.assertEqual(len(a.points), 7 if a.cfg["n"] >= 24 else 5)
                self.w.leave_instance(silent=True)

    def test_layout_is_mirrored_and_fixed(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                a = self.build(mode); pillars = set(a.pillars); floor = set(a.floor)
                X0, Wd = a.X0, a.Wd
                for (x, y) in floor:
                    self.assertTrue((X0 + Wd - 1 - (x - X0), y) in floor, f"map is not left/right symmetric at {(x, y)}")
                self.w.leave_instance(silent=True)
                b = self.build(mode)
                self.assertTrue(set(b.pillars) == pillars, "the same map must build the same way every time")
                self.assertGreater(len(pillars), 0, "no cover at all")
                self.w.leave_instance(silent=True)

    def test_teams_spawn_on_floor(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                a = self.build(mode); n = a.cfg["n"]
                self.assertEqual(len(a.allies), n - 1, "you fill one of your team's slots")
                self.assertEqual(len(a.reds), n)
                self.assertEqual(len({c.id for c in a.allies + a.reds}), 2 * n - 1, "duplicate actor ids")
                for c in a.allies + a.reds:
                    self.assertTrue((int(c.x), int(c.y)) in a.floor, f"{c.name} ({c.team}) spawned in a wall")
                self.assertEqual((self.w.player["x"], self.w.player["y"]), a.spawn)
                json.dumps(a.snapshot())
                self.w.leave_instance(silent=True)

    def test_twelve_a_side_roles(self):
        a = self.build("tdm12")
        roles = collections.Counter(c.rrole for c in a.reds)
        self.assertEqual(roles, {"Tank": 2, "Healer": 3, "DPS": 7})


# ================================================================= arena matches
class ArenaMatches(unittest.TestCase):
    """Plays each map to the end and checks the scoring rules."""

    def setUp(self):
        self.w = new_world(level=30)

    def tearDown(self):
        if self.w.inst: self.w.leave_instance(silent=True)
        self.w.close()

    def test_every_map_plays_to_a_result(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                w = self.w; before = {a.id for a in w.actors}; home = (w.player["x"], w.player["y"])
                a = enter(w, mode)
                ticks = run_until_out(w, int(a.cfg["time"] * I.TPS) + 200)
                self.assertIsNone(w.inst, f"{mode} still running after {ticks} ticks")
                self.assertIn(a.result, ("blue", "red", "draw"))
                self.assertTrue(w.city_result)
                self.assertEqual({x.id for x in w.actors}, before, "arena actors leaked into the world")
                self.assertEqual((w.player["x"], w.player["y"]), home, "not sent back to where you entered")
                self.assertGreater(w.player["hp"], 0)

    def test_tdm_kills_score(self):
        w = self.w; a = enter(w, "tdm12")
        a.player_killed(a.reds[0])
        self.assertEqual((a.score["blue"], a.pk), (1, 1))
        self.assertTrue(a.reds[0].dead)
        w.player["hp"] = 1; a.on_player_death()
        self.assertEqual((a.score["red"], a.pd), (1, 1))
        self.assertEqual((w.player["x"], w.player["y"]), a.spawn)
        self.assertEqual(w.player["hp"], w._effective_maxhp())

    def test_ctf_player_capture_and_drop(self):
        w = self.w; a = enter(w, "ctf12")
        for c in a.allies + a.reds: c.dead = True; c.respawn = 10 ** 9      # an empty map: only you
        w.player["x"], w.player["y"] = a.flags["red"]["home"]; a._ctf_tick()
        self.assertEqual(a.carry_player, "red")
        w.player["x"], w.player["y"] = a.flags["blue"]["home"]; a._ctf_tick()
        self.assertEqual(a.score["blue"], 1); self.assertIsNone(a.carry_player)
        self.assertEqual(a.flags["red"]["pos"], a.flags["red"]["home"])
        # dying while carrying drops the flag, and a dropped flag goes straight home (0.46.31)
        w.player["x"], w.player["y"] = a.flags["red"]["home"]; a._ctf_tick()
        a.on_player_death()
        self.assertIsNone(a.carry_player)
        self.assertIsNone(a.flags["red"]["carrier"]); self.assertEqual(a.flags["red"]["pos"], a.flags["red"]["home"])

    def test_ctf_dropped_flag_returns(self):
        w = self.w; a = enter(w, "ctf12")
        f = a.flags["blue"]; f["pos"] = (f["home"][0] + 10, f["home"][1]); f["t"] = w.tick
        for c in a.allies + a.reds: c.dead = True; c.respawn = 10 ** 9
        w.player["x"], w.player["y"] = a.red_base
        for _ in range(85): w.tick += 1; a._ctf_tick()
        self.assertEqual(f["pos"], f["home"], "a flag left on the ground must go home by itself")

    def test_ctf_carrier_drop_returns_at_once_and_target_is_three(self):
        w = self.w; a = enter(w, "ctf12")
        for c in a.allies + a.reds: c.dead = True; c.respawn = 10 ** 9
        r = a.reds[0]; r.dead = False; r.x, r.y = a.flags["blue"]["home"]
        a._ctf_tick(); self.assertIs(a.flags["blue"]["carrier"], r)
        r.x += 20; a._drop_flag(r)
        self.assertIsNone(a.flags["blue"]["carrier"]); self.assertEqual(a.flags["blue"]["pos"], a.flags["blue"]["home"])
        for m in ("ctf12", "ctf24"): self.assertEqual(A.MODES[m]["target"], 3)
        a.score["blue"] = 3; a._check_end(w.tick); self.assertTrue(a.done)

    def test_ctf_everyone_hunts_the_carrier_and_teams_are_even(self):
        w = self.w; a = enter(w, "ctf12")
        self.assertEqual(len(a.allies) + 1, len(a.reds))
        r = a.reds[0]; r.dead = False; a.flags["blue"]["carrier"] = r; r.has_flag = True      # the enemy holds our flag...
        a.allies[0].has_flag = True; a.flags["red"]["carrier"] = a.allies[0]                    # ...while we hold theirs
        for m in a.allies[1:]:
            m.hp = m.maxhp; a._decide_core(m, w.tick)
            self.assertEqual(m.plan[0], "chase", m.rrole)

    def test_dom_points_capture_and_score(self):
        for mode in ("dom12", "dom24"):
            with self.subTest(mode=mode):
                w = self.w; a = enter(w, mode)
                for c in a.allies + a.reds: c.dead = True; c.respawn = 10 ** 9
                pt = a.points[0]; w.player["x"], w.player["y"] = pt["x"], pt["y"]
                for _ in range(10): a._dom_tick()
                self.assertEqual(pt["owner"], "blue")
                s0 = a.score["blue"]
                for _ in range(4 * I.TPS): a._dom_tick()
                self.assertAlmostEqual(a.score["blue"] - s0, 4.0, msg="one owned point scores 1 per second")
                w.leave_instance(silent=True)

    def test_rewards_match_the_guide(self):
        # guide: PvP Points 120 per 12v12 win, 24 for a loss
        for mode, win_pts, loss_pts in (("tdm12", 120, 24), ("ctf12", 120, 24)):
            with self.subTest(mode=mode):
                w = self.w
                cur = lambda: w.db.execute("SELECT pvp_points FROM player_currency WHERE name=?", (w.player["name"],)).fetchone()[0]
                enter(w, mode); p0, g0 = cur(), w.player["gold"]
                w.inst._finish("blue")
                self.assertEqual(cur() - p0, win_pts); self.assertGreater(w.player["gold"], g0)
                run_until_out(w, 40); self.assertIsNone(w.inst)
                enter(w, mode); p0 = cur()
                w.inst._finish("red")
                self.assertEqual(cur() - p0, loss_pts)
                run_until_out(w, 40)

    def test_leaving_early_is_no_win_no_loss(self):
        w = self.w; r0 = w.pvp_status()["rating"]
        enter(w, "dom12"); w.update(4); w.leave_instance()
        self.assertIn("no win, no loss", w.city_result)
        self.assertEqual(w.pvp_status()["rating"], r0)

    def test_entry_rules(self):
        w = self.w
        self.assertIn("Unknown", w.enter_arena("nope"))
        w.player["level"] = 4; self.assertIn("level 5", w.enter_arena("tdm12")); self.assertIsNone(w.inst)
        w.player["level"] = 30; w.enter_arena("tdm12")
        self.assertIn("Leave your current instance", w.enter_arena("ctf12"))

    def test_mounted_player_is_dismounted(self):
        w = self.w; w.mounted = "anything"
        w.enter_arena("tdm12"); self.assertFalse(getattr(w, "mounted", None))


# ======================================================================= mana (0.46.31)
class Mana(unittest.TestCase):
    def setUp(self): self.w = new_world(level=1, cls="Mage")
    def tearDown(self): self.w.close()

    def test_max_mana_grows_with_level(self):
        w = self.w
        vals = []
        for lvl in (1, 10, 50, 90):
            w.player["level"] = lvl; vals.append(w.max_mana())
        self.assertEqual(vals[0], 100); self.assertEqual(vals, sorted(vals)); self.assertEqual(vals[1], 154)
        self.assertEqual(w.snapshot()["player"]["maxmana"], w.max_mana())

    def test_level_up_refills_mana(self):
        w = self.w; w.player["mana"] = 5; w.player["xp"] = 10 ** 9; w._level_check()
        self.assertEqual(w.player["mana"], w.max_mana()); self.assertGreater(w.max_mana(), 100)

    def test_regen_only_out_of_combat_unless_meditation(self):
        w = self.w; w.player["level"] = 30
        def regen(combat):
            w.player["mana"] = 10; w.last_combat_tick = w.tick if combat else -999
            w.update(8); return w.player["mana"]
        self.assertGreater(regen(False), 10)
        self.assertEqual(regen(True), 10)

    def test_mana_potion_scales(self):
        w = self.w; w.player["level"] = 90; w._inv_add("Mana Potion", 1); w.player["mana"] = 0
        w.use_mana_potion(); self.assertEqual(w.player["mana"], w.max_mana() // 4)


# ======================================================================= battle mounts (0.46.33)
class BattleMounts(unittest.TestCase):
    def test_battle_mount_is_battleground_only(self):
        w = new_world(level=40)
        try:
            st = w._mst(); st["riding"] = 2; st["owned"] = ["bg_wolf"]; st["active"] = "bg_wolf"; st["bg_active"] = None
            st = w._mst_save() or w._mst()
            w._mount_cache = None; st = w._mst()                      # reload: a battle mount can never be the open-world mount
            self.assertNotEqual(st["active"], "bg_wolf")
            ok, why = w.can_mount(); self.assertFalse(ok, "no open-world mount owned")
            w.mounted = "bg_wolf"; w._mount_tick(); self.assertIsNone(w.mounted, "battle mount vanishes outside battlegrounds")
            a = enter(w, "ctf12"); w.mounted = None
            self.assertEqual(w.mount(), "You mount your Recruit's Battle Wolf.")
            w.leave_instance(silent=True); w._mount_tick(); self.assertIsNone(w.mounted)
        finally: w.close()


# ======================================================================= town guards vs enemy bots (0.46.34)
class TownDefense(unittest.TestCase):
    def test_guards_attack_enemy_faction_adventurers_in_town(self):
        w = new_world(level=40, faction="Alliance")
        try:
            t = next(x for x in w.towns if x.faction == "Horde")
            bot = next(a for a in w.actors if a.kind == "adventurer" and a.faction == "Alliance" and not a.party)
            bot.x, bot.y = t.x + 2, t.y + 2; bot.hp = bot.maxhp = 2000; bot.state = "town"
            g = next(a for a in w.actors if a.kind == "npc" and a.role == "guard" and w._town_for_actor(a) is t)
            g.x, g.y = bot.x + 1, bot.y; g.hp = g.maxhp
            w.player["x"], w.player["y"] = t.x - 400, t.y; hp0 = bot.hp
            for _ in range(24): w.tick += 1; w._gtick = -1; w._town_defense_tick()
            self.assertLess(bot.hp, hp0, "a Horde guard must hit an Alliance bot inside its walls")
            # a bot of the town's own faction is left alone
            ally = next(a for a in w.actors if a.kind == "adventurer" and a.faction == "Horde" and not a.party)
            ally.x, ally.y = t.x + 2, t.y + 2; ally.hp = ally.maxhp; w.tick += 4; w._gtick = -1; w._town_defense_tick()
            self.assertEqual(ally.hp, ally.maxhp)
        finally: w.close()


# ======================================================================= waygates and raids (0.46.36)
class Waygates(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.w = new_world(level=40, faction="Alliance"); cls.w.player["gold"] = 500
        cls.layout = gfx.WorldLayout(cls.w); cls.w.station_posts = cls.layout.stations

    @classmethod
    def tearDownClass(cls): cls.w.close()

    def test_one_waygate_in_the_major_city_of_every_zone(self):
        w = self.w; ids = w.teleport_town_ids()
        self.assertEqual(len(ids), len({t.area for t in w.towns}))
        tp = [b for b in self.layout.buildings if b[2] == "teleport"]
        self.assertEqual(len(tp), len(ids), "every major city turns one existing house into its Waygate")
        for t in w.towns:
            if t.id in ids: self.assertIn(w.town_tier(t), ("capital", "city"))

    def test_teleport_costs_gold_and_a_scroll(self):
        w = self.w; w.inst = None
        mine = [t for t in w.towns if t.id in w.teleport_town_ids() and t.faction == "Alliance"]
        a, b = mine[0], mine[1]
        post = min(w.station_posts["teleport"], key=lambda q: (q[0] - a.x) ** 2 + (q[1] - a.y) ** 2)
        w.player["x"], w.player["y"] = post[0] + 1, post[1] + 1
        w._inv_add("Scroll of Teleportation", -w._inv_qty("Scroll of Teleportation"))
        self.assertIn("Scroll", w.teleport_to(b.id)); self.assertEqual(w.player["gold"], 500)
        w._inv_add("Scroll of Teleportation", 1)
        self.assertIn("carries you", w.teleport_to(b.id))
        self.assertEqual((w.player["gold"], w._inv_qty("Scroll of Teleportation")), (450, 0))
        self.assertLess(math.hypot(w.player["x"] - b.x, w.player["y"] - b.y), 40)
        self.assertEqual(w.teleport_view(), None if not w._near_station("teleport", 8) else w.teleport_view())
        enemy = next(t for t in w.towns if t.faction == "Horde" and t.id in w.teleport_town_ids())
        w.player["x"], w.player["y"] = post[0] + 1, post[1] + 1; w._inv_add("Scroll of Teleportation", 1)
        self.assertIn("cannot", w.teleport_to(enemy.id))

    def test_city_raids_are_24_a_side_and_always_full(self):
        w = self.w
        self.assertEqual(w.RAID_CAP, 24)
        t = w.towns[0]; w.city_raid = None; w.raid_call = None; w.inst = None
        w._raid_announce(t); rc = w.raid_call
        self.assertEqual(rc["cap"], 24); self.assertGreaterEqual(rc["target"], 23)
        w._raid_launch(); self.assertIsNotNone(w.city_raid)
        w._raid_spawn_wave(); self.assertGreaterEqual(len(w.city_raid["ids"]), 24)
        w._raid_end(True); w.city_raid = None


# ======================================================================= spell elements (0.46.37)
class SpellElements(unittest.TestCase):
    def test_elements_and_descriptions(self):
        by = {a["name"]: a for v in E.ABILITIES.values() for a in v}
        for name, el, word in (("Frost Nova", "cold", "slowing"), ("Deep Freeze", "cold", "freezes"), ("Meteor", "fire", "ignites"),
                               ("Lightning Bolt", "electric", "shock"), ("Earthquake", "earth", "staggers")):
            self.assertEqual(E.spell_element(by[name]), el, name)
            self.assertIn(word, E.describe_ability(by[name]), name)
        for name in ("Rapid Fire", "Blade Tempest", "Heroic Strike", "Ice Barrier"):
            self.assertEqual(E.spell_element(by[name]), "", name)

    def test_class_flavour_is_modest(self):
        by = {a["name"]: a for v in E.ABILITIES.values() for a in v}
        for name, el in (("Shadow Bolt", "shadow"), ("Smite", "holy"), ("Serpent Sting", "poison"), ("Moonfire", "poison"), ("Holy Fire", "fire")):
            self.assertEqual(E.spell_element(by[name]), el, name)
        self.assertLessEqual(E.VULN_PCT, .10); self.assertLessEqual(E.HOLY_LEECH, .06); self.assertLessEqual(E.POISON_FRAC * E.POISON_SECS, .35)
        w = new_world(level=30, cls="Warlock")
        try:
            w.player["mana"] = 999
            mob = next(a for a in w.actors if a.kind == "monster" and a.faction != w.player["faction"])
            mob.hp = mob.maxhp = 100000; w.player["x"], w.player["y"] = mob.x + 1.0, mob.y; w._gtick = -1
            ab = next(a for a in w.ability_info() if a["name"] == "Shadow Bolt" or E.spell_element(a) == "shadow")
            w.selected_target = mob.id; w.ability_cooldowns[ab["slot"]] = 0; w.use_ability(ab["slot"])
            self.assertGreater(w.mstatus[mob.id].get("vuln", 0), w.tick)
        finally: w.close()

    def test_cold_slows_and_fire_burns_in_combat(self):
        w = new_world(level=30, cls="Mage")
        try:
            w.player["mana"] = 999
            mob = next(a for a in w.actors if a.kind == "monster" and a.faction != w.player["faction"])
            mob.hp = mob.maxhp = 100000; w.player["x"], w.player["y"] = mob.x + 1.0, mob.y
            w._gtick = -1
            ab = next(i for i, a in enumerate(w.ability_info()) if a["name"] == "Deep Freeze")
            w.selected_target = mob.id; w.ability_cooldowns[w.ability_info()[ab]["slot"]] = 0
            w.use_ability(w.ability_info()[ab]["slot"])
            self.assertGreater(w.mstatus[mob.id].get("slow", 0), w.tick)
            ab = next(a for a in w.ability_info() if a["name"] == "Meteor")
            w.player["level"] = 40; w.ability_cooldowns[ab["slot"]] = 0; w.use_ability(ab["slot"])
            self.assertEqual(w.mstatus[mob.id]["dot"]["name"], "Burning")
        finally: w.close()


# ======================================================================= damaged saves (0.46.42)
class DamagedSaves(unittest.TestCase):
    def test_garbage_in_the_save_never_crashes_a_lookup(self):
        w = new_world(level=40, cls="Warrior")
        try:
            for bad in ("[]", "5", "null", '"text"', "{not json", '{"owned": "x", "active": 7, "riding": "high"}', '{"active": 3, "finished": 4}'):
                for key in ("mounts", "quests2", "mkt", "build", "mythic", "pparty", "dead_leaders"):
                    w._setmeta(key, bad)
                w._mount_cache = None; w._build_c = None; w._dead_leaders = None
                w._qs(); w._mst(); w._mkt_state(); w._build(); w._pp_ids(); w.mythic_info()
                w.can_mount(); w.market_view() if w.market_town() else None; w.teleport_view()
                self.assertIsInstance(w._mst()["owned"], list); self.assertIsInstance(w._qs()["active"], list)
        finally: w.close()

    def test_unknown_mounts_in_a_save_are_dropped(self):
        w = new_world(level=40)
        try:
            w._setmeta("mounts", json.dumps({"riding": 99, "owned": ["wolf", "nonsense", 5], "active": "nonsense"}))
            w._mount_cache = None; st = w._mst()
            self.assertEqual((st["owned"], st["active"], st["riding"]), (["wolf"], None, 0))
        finally: w.close()


# ======================================================================= dungeons
class Dungeons(unittest.TestCase):
    def test_each_instance_kind(self):
        w = new_world(level=100)
        try:
            for kind in ("dungeon", "raid", "heroic"):
                with self.subTest(kind=kind):
                    d = next(x for x in w.dungeons if x.kind == kind)
                    w.player["x"], w.player["y"] = d.x, d.y + 1
                    msg = w.enter_instance()
                    self.assertIsNotNone(w.inst, msg)
                    inst = w.inst
                    self.assertTrue((int(inst.spawn[0]), int(inst.spawn[1])) in inst.floor, "spawn in a wall")
                    reach = flood(inst.floor, inst.spawn)
                    for act in inst.actors.values():
                        self.assertTrue((int(act.x), int(act.y)) in reach, f"{act.name} unreachable at {(act.x, act.y)}")
                    for _ in range(300):
                        w.update(1)
                        if w.inst is None: break
                    json.dumps(inst.snapshot())
                    if w.inst: w.leave_instance()
                    self.assertIsNone(w.inst)
        finally:
            w.close()


# ======================================================================== render
class Render(unittest.TestCase):
    """Draws real frames through game.Game with the dummy video driver."""

    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import game as G
        cls.G = G
        cls.w = new_world(level=30)
        cls.g = G.Game(cls.w)
        cls.g.mouse = (10, 10)
        cls.g.apply_quality(1, False, False)

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def frames(self, n=6, ticks=True):
        for _ in range(n):
            if ticks: self.w.update(1)
            self.g.frame(1 / 30); self.G.present()

    def test_world_frames(self):
        for q in (0, 1, 2):
            with self.subTest(quality=q):
                self.g.apply_quality(q, False, False); self.frames()
                self.assertEqual(self.g.quality, q)
        for hour in (7.6, 12.0, 17.6, 22.0):        # 0.37 High: sun rays, sharpening and soft shadows at every time of day
            with self.subTest(hour=hour):
                self.w.tick = int(hour * 40); self.frames(3, ticks=False)
        self.g.apply_quality(1, False, False)

    def test_every_arena_map_draws(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                enter(self.w, mode)
                self.frames(8)
                self.w.inst._finish("blue"); self.frames(4)
                self.w.leave_instance(silent=True); self.frames(2)

    def test_windows_draw(self):
        for m in ("guide", "pvp", "armory", "stats", "skills", "inventory", "map", "quests", "settings", "vault"):
            with self.subTest(window=m):
                self.g.mode = m; self.frames(2, ticks=False)
        self.g.mode = "world"

    def test_clicking_a_building_opens_it(self):
        """0.36.2: no hanging signs; clicking the building itself opens its window, even with an NPC beside it."""
        self.assertFalse(hasattr(self.G, "station_plaque") or hasattr(self.G, "STATION_SIGNS"))
        g, w, p = self.g, self.w, self.w.player
        for kind, want in (("hut", ("craft", "hut")), ("forge", ("craft", "forge")), ("press", ("craft", "press")), ("warhall", ("pvp", None)), ("magic", ("magic", None)),
                           ("smithy", ("shop", None)), ("general", ("shop", None)), ("enchanter", ("shop", None)), ("bank", ("vault", None)), ("stable", ("stable", None)), ("market", ("market", None)), ("apothecary", ("shop", None)), ("jeweler", ("shop", None)), ("kiln", ("kiln", None)), ("inn", ("craft", "inn"))):
            with self.subTest(station=kind):
                posts = (w.station_posts or {}).get(kind)
                self.assertTrue(posts, f"no {kind} in town")
                p["x"], p["y"] = posts[0]; g.mode = "world"; g.pending = None
                self.frames(2, ticks=False)
                spot = None
                for rr, obj in g.hit_rects:
                    if obj[0] != "station" or obj[1] != kind: continue
                    for fx_ in range(rr.left + 2, rr.right - 2, 4):
                        for fy_ in range(rr.top + 2, rr.bottom - 2, 4):
                            top = next((o for r2, o in reversed(g.hit_rects) if r2.collidepoint((fx_, fy_))), None)
                            if top is obj: spot = (fx_, fy_); break
                        if spot: break
                    if spot: break
                self.assertIsNotNone(spot, f"{kind} building is not clickable")
                labels = [rr for rr, obj in g.hit_rects if obj[0] == "station" and obj[1] == kind and rr.height < 30]
                self.assertTrue(labels, f"{kind} has no name label")
                g.click_world(spot, 1)
                self.assertEqual(g.pending[:2], ("station", kind))
                p["x"], p["y"] = g.pending[2] + 2.4, g.pending[3] + 2.4
                g.resolve_pending()
                self.assertEqual(g.mode, want[0], f"{kind}: {g.log[-1] if getattr(g, 'log', None) else ''}")
                if want[1]: self.assertEqual(g.craft_station, want[1])
        g.mode = "world"


# ======================================================================== 1.0.11 fixes
class Fixes1011(unittest.TestCase):
    def test_slain_guards_come_back(self):
        w = new_world(level=30)
        try:
            g = next(a for a in w.actors if a.kind == "npc" and a.role == "guard")
            g.slain = True; g.down_until = w.tick + 10; w._slain_guards().add(g.id)
            for _ in range(80): w.update(1)
            self.assertFalse(g.slain)
            self.assertNotIn(g.id, w._slain_guards())
        finally:
            w.close()

    def test_audio_is_main_thread_only(self):
        from liveworld_rpg import sound
        src = (LIB / "liveworld_rpg" / "sound.py").read_text()
        self.assertNotIn("snd.play(", src.split("def _build_music")[1].split("def pump")[0])
        self.assertTrue(hasattr(sound.Audio, "pump"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
