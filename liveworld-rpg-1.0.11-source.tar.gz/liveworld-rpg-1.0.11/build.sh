#!/bin/sh
# Build a LiveWorld RPG release into dist/:
#   liveworld-rpg_<ver>_all.deb          the package (only DEBIAN/ and usr/ go in it)
#   liveworld-rpg-<ver>-source.tar.gz    this whole folder: game, packaging, tests, guide generator, this script
#   LiveWorld-RPG-Guide.docx             the install and player's guide (needs node with the "docx" module)
#   SHA256SUMS-<ver>.txt
#
#   ./build.sh            build
#   ./build.sh --test     run the smoke tests first and stop if any fail
#
# The version comes from DEBIAN/control; game.py, __init__.py and the AppStream file must agree (the tests check).
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
DIST="$HERE/dist"
VER=$(sed -n 's/^Version: *//p' "$HERE/DEBIAN/control")
LIB="$HERE/usr/lib/liveworld-rpg"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

# 1. GUIDE.md is generated from the in-game guide (F1) so the two never drift apart
PYTHONPATH="$LIB" LIVEWORLD_DATA="$TMP/data" python3 - "$HERE/usr/share/doc/liveworld-rpg/GUIDE.md" "$VER" <<'EOF'
import sys
from liveworld_rpg import guide
out, ver = sys.argv[1], sys.argv[2]
mm = ".".join(ver.split(".")[:2])
open(out, "w").write(f"# LiveWorld RPG {mm} - Player's Guide\n" + "".join(
    f"\n## {t}\n\n" + "".join(f"- {l}\n" for l in lines) for t, lines in guide.PAGES))
EOF

# 2. clean, permissions, md5sums, installed size
find "$HERE" -name __pycache__ -prune -exec rm -rf {} +
find "$HERE/DEBIAN" "$HERE/usr" -type d -exec chmod 0755 {} +
find "$HERE/usr" -type f -exec chmod 0644 {} +
chmod 0755 "$HERE"/usr/bin/* "$HERE/DEBIAN/postinst" "$HERE/DEBIAN/postrm" "$HERE/build.sh"
(cd "$HERE" && find usr -type f | LC_ALL=C sort | xargs md5sum > DEBIAN/md5sums)
chmod 0644 "$HERE/DEBIAN/control" "$HERE/DEBIAN/md5sums"
SIZE=$(du -sk "$HERE/usr" | cut -f1)
if grep -q '^Installed-Size:' "$HERE/DEBIAN/control"; then
    sed -i "s/^Installed-Size:.*/Installed-Size: $SIZE/" "$HERE/DEBIAN/control"
else
    sed -i "/^Version:/a Installed-Size: $SIZE" "$HERE/DEBIAN/control"
fi

# 3. tests
if [ "${1:-}" = "--test" ]; then
    python3 "$HERE/tests/smoke_test.py"
    find "$HERE" -name __pycache__ -prune -exec rm -rf {} +
fi

mkdir -p "$DIST"
rm -f "$DIST"/liveworld-rpg_*_all.deb "$DIST"/liveworld-rpg-*-source.tar.gz "$DIST"/SHA256SUMS-*.txt "$DIST"/*.docx

# 4. the package: only DEBIAN/ and usr/
mkdir "$TMP/pkg"; cp -a "$HERE/DEBIAN" "$HERE/usr" "$TMP/pkg/"
dpkg-deb --root-owner-group -Zxz --build "$TMP/pkg" "$DIST/liveworld-rpg_${VER}_all.deb" >/dev/null

# 5. the guide
if command -v node >/dev/null 2>&1 && node -e "require('docx')" >/dev/null 2>&1; then
    PYTHONPATH="$LIB" LIVEWORLD_DATA="$TMP/data" python3 "$HERE/guide/export_data.py" "$TMP/guide.json" >/dev/null 2>&1
    node "$HERE/guide/make_guide.js" "$TMP/guide.json" "$DIST/LiveWorld-RPG-Guide.docx" >/dev/null
else
    echo "note: node with the docx module not found - skipping LiveWorld-RPG-Guide.docx (npm install docx)" >&2
fi

# 6. the source: this folder, minus dist/
NAME=$(basename "$HERE")
tar --owner=0 --group=0 --numeric-owner --sort=name --exclude="$NAME/dist" --exclude=__pycache__ --exclude=node_modules \
    --transform "s,^$NAME,liveworld-rpg-${VER}," -C "$(dirname "$HERE")" -czf "$DIST/liveworld-rpg-${VER}-source.tar.gz" "$NAME"

# 7. checksums
(cd "$DIST" && set -- "liveworld-rpg_${VER}_all.deb" "liveworld-rpg-${VER}-source.tar.gz" && { [ -f LiveWorld-RPG-Guide.docx ] && set -- "$@" LiveWorld-RPG-Guide.docx; true; } && sha256sum -- "$@" > "SHA256SUMS-${VER}.txt")
echo "built LiveWorld RPG $VER in $DIST:"; ls -l "$DIST"
