#!/usr/bin/env python3
import traceback
from .game import main

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
