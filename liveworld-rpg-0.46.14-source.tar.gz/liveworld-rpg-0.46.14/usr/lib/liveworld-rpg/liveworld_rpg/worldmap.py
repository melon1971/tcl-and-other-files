"""0.41.1: the painted world map.

The relief map used to be painted at half a tile per pixel and stretched six times, which is why it looked blurry and
the roads were stair-stepped squares.  It is now painted from every tile, lit like a hillshaded atlas, with painted
forests and peaks, smooth road ribbons, soft shorelines, zone borders and proper town / dungeon icons.
"""
import math
import pygame
from . import gfx
from .engine import W, WORLD_H, TOWN_WALL_R

shade, mix, h01, vnoise = gfx.shade, gfx.mix, gfx.h01, gfx.vnoise

# how mountainous each base zone is (hill-shading strength) and which zones get rock / snow peaks painted in
RELIEF = {"Frostmarch": 2.1, "Wyrmreach": 2.1, "Ember Highlands": 1.8, "Shadowlands": 1.3, "Ashen Vale": 1.5,
          "Dreadmoor": 1.1, "Ironwood": 1.1, "Sunscar Desert": 1.0, "Bloodfen": .55, "Storm Coast": .7}
PEAKS = {"Frostmarch": ((236, 242, 252), (150, 170, 196)), "Wyrmreach": ((176, 184, 204), (84, 90, 116)),
         "Ember Highlands": ((150, 96, 70), (72, 40, 32)), "Ashen Vale": ((176, 154, 120), (96, 80, 62)),
         "Shadowlands": ((120, 96, 150), (52, 38, 72)), "Dreadmoor": ((130, 120, 140), (60, 54, 70))}
ROUND_TREES = {"oak", "willow", "palm", "bush", "treant"}
SPIKE_TREES = {"pine", "snowpine"}
ROCKS = {"rock", "boulders", "lavarock", "icerock", "menhir", "iceshard"}
GEMS = {"crystal", "darkcrystal"}
FACTION = {"Alliance": ((74, 128, 240), (22, 44, 110)), "Horde": ((226, 70, 58), (110, 20, 18))}


def _box_blur(g, w, h, r):
    """Separable box blur of a list-of-rows grid (keeps the hill strength from jumping at zone borders)."""
    tmp = [[0.0] * w for _ in range(h)]
    n = 2 * r + 1
    for y in range(h):
        row = g[y]; acc = sum(row[min(w - 1, max(0, i))] for i in range(-r, r + 1))
        for x in range(w):
            tmp[y][x] = acc / n
            acc += row[min(w - 1, x + r + 1)] - row[max(0, x - r)]
    out = [[0.0] * w for _ in range(h)]
    for x in range(w):
        acc = sum(tmp[min(h - 1, max(0, i))][x] for i in range(-r, r + 1))
        for y in range(h):
            out[y][x] = acc / n
            acc += tmp[min(h - 1, y + r + 1)][x] - tmp[max(0, y - r)][x]
    return out


def _poly(m, fill, pts, edge=(26, 18, 12)):
    pygame.draw.polygon(m, fill, pts)
    pygame.draw.polygon(m, edge, pts, 1)


def _rect(m, fill, r, edge=(26, 18, 12)):
    pygame.draw.rect(m, fill, r)
    pygame.draw.rect(m, edge, r, 1)


def _merlons(m, x, y, w, col, edge=(26, 18, 12)):
    """A row of crenellations sitting on a wall top at (x, y), w wide."""
    n = max(2, w // 4)
    for i in range(n):
        mx = x + int(i * (w - 3) / max(1, n - 1))
        _rect(m, col, (mx, y - 3, 3, 3), edge)


def draw_castle(m, cx, cy, faction):
    """Capital: a keep with two flanking towers, a gate and a faction banner."""
    fc, fd = FACTION.get(faction, ((230, 200, 90), (110, 84, 20)))
    stone, lit, dark = (178, 170, 156), (206, 198, 182), (112, 104, 96)
    pygame.draw.ellipse(m, shade(m.get_at((min(m.get_width() - 1, cx), min(m.get_height() - 1, cy + 8)))[:3], .5), (cx - 17, cy + 4, 34, 9))
    pygame.draw.circle(m, (30, 20, 8), (cx, cy - 2), 19, 2); pygame.draw.circle(m, fc, (cx, cy - 2), 17, 1)
    _rect(m, stone, (cx - 13, cy - 6, 26, 13)); _rect(m, dark, (cx + 5, cy - 6, 8, 13))
    for tx in (cx - 16, cx + 8):
        _rect(m, stone, (tx, cy - 13, 8, 20)); _rect(m, dark, (tx + 5, cy - 13, 3, 20)); _merlons(m, tx, cy - 13, 8, lit)
    _rect(m, lit, (cx - 6, cy - 18, 12, 25)); _rect(m, dark, (cx + 2, cy - 18, 4, 25)); _merlons(m, cx - 6, cy - 18, 12, lit)
    pygame.draw.polygon(m, (24, 14, 10), [(cx - 3, cy + 7), (cx - 3, cy + 1), (cx, cy - 2), (cx + 3, cy + 1), (cx + 3, cy + 7)])
    pygame.draw.line(m, (40, 30, 20), (cx, cy - 18), (cx, cy - 29), 1)
    _poly(m, fc, [(cx + 1, cy - 29), (cx + 9, cy - 26), (cx + 1, cy - 23)], fd)
    for wx in (cx - 12, cx + 10): pygame.draw.rect(m, (30, 24, 20), (wx + 1, cy - 9, 2, 3))


def draw_city(m, cx, cy, faction):
    """City: a walled tower with a banner."""
    fc, fd = FACTION.get(faction, ((230, 200, 90), (110, 84, 20)))
    stone, lit, dark = (184, 176, 162), (208, 200, 186), (112, 104, 96)
    pygame.draw.ellipse(m, shade(m.get_at((min(m.get_width() - 1, cx), min(m.get_height() - 1, cy + 7)))[:3], .5), (cx - 12, cy + 3, 24, 8))
    _rect(m, stone, (cx - 10, cy - 3, 20, 9)); _rect(m, dark, (cx + 3, cy - 3, 7, 9)); _merlons(m, cx - 10, cy - 3, 20, lit)
    _rect(m, lit, (cx - 5, cy - 13, 10, 19)); _rect(m, dark, (cx + 1, cy - 13, 4, 19)); _merlons(m, cx - 5, cy - 13, 10, lit)
    pygame.draw.polygon(m, (24, 14, 10), [(cx - 2, cy + 6), (cx - 2, cy + 2), (cx, cy), (cx + 2, cy + 2), (cx + 2, cy + 6)])
    pygame.draw.line(m, (40, 30, 20), (cx, cy - 13), (cx, cy - 21), 1)
    _poly(m, fc, [(cx + 1, cy - 21), (cx + 7, cy - 19), (cx + 1, cy - 16)], fd)


def draw_town(m, cx, cy, faction):
    """Town: a cottage with a faction-coloured roof."""
    fc, fd = FACTION.get(faction, ((200, 90, 60), (90, 34, 20)))
    pygame.draw.ellipse(m, shade(m.get_at((min(m.get_width() - 1, cx), min(m.get_height() - 1, cy + 5)))[:3], .5), (cx - 8, cy + 2, 16, 6))
    _rect(m, (226, 212, 180), (cx - 6, cy - 2, 12, 8)); _rect(m, (176, 160, 130), (cx + 2, cy - 2, 4, 8))
    _poly(m, fc, [(cx - 8, cy - 2), (cx, cy - 9), (cx + 8, cy - 2)], fd)
    pygame.draw.rect(m, (46, 30, 20), (cx - 1, cy + 2, 3, 4))


def draw_gate(m, dx, dy, kind):
    """Dungeon / raid / heroic raid: a gem set in a dark diamond with a faint halo."""
    col = {"raid": (255, 138, 44), "heroic": (255, 62, 62)}.get(kind, (176, 108, 255))
    lit = shade(col, 1.35); dim = shade(col, .55)
    pygame.draw.circle(m, shade(m.get_at((min(m.get_width() - 1, dx), min(m.get_height() - 1, dy)))[:3], .62), (dx, dy), 10)
    pygame.draw.polygon(m, (16, 10, 18), [(dx, dy - 9), (dx + 9, dy), (dx, dy + 9), (dx - 9, dy)])
    pygame.draw.polygon(m, dim, [(dx, dy - 7), (dx + 7, dy), (dx, dy + 7), (dx - 7, dy)])
    pygame.draw.polygon(m, col, [(dx, dy - 7), (dx + 7, dy), (dx, dy)])
    pygame.draw.polygon(m, lit, [(dx, dy - 7), (dx - 7, dy), (dx, dy)])
    pygame.draw.polygon(m, (255, 250, 236), [(dx, dy - 4), (dx + 1, dy - 1), (dx - 1, dy - 1)])
    if kind == "heroic": pygame.draw.circle(m, (255, 226, 120), (dx, dy), 10, 1)


def build(game, s, progress=None):
    """Paint the world map at `s` pixels per tile and return the Surface.  `progress(msg, 0..1)` keeps the loading screen alive."""
    lay, world = game.layout, game.w
    WH = WORLD_H
    def tick(msg, f):
        try:
            if progress: progress(msg, f)
            else: pygame.event.pump()
        except Exception:
            pass
    # ------------------------------------------------------------ 1. colour of every tile
    tc = pygame.Surface((W, WH))
    core = set()                                        # only a small paved square at each town centre; the wide plaza reads as a big disc on the map
    for t_ in world.towns:
        r_ = 5 if world.town_tier(t_) == "town" else 8
        for dy in range(-r_, r_ + 1):
            for dx in range(-r_, r_ + 1):
                if dx * dx + dy * dy <= r_ * r_: core.add((int(t_.x) + dx, int(t_.y) + dy))
    kinds = [bytearray(W) for _ in range(WH)]          # 0 land, 1 water, 2 lava
    area_of = [[None] * W for _ in range(WH)]
    for y in range(WH):
        if y % 30 == 0: tick("Painting the land...", .55 + .06 * y / WH)
        krow = kinds[y]; arow = area_of[y]
        for x in range(W):
            a = gfx.area_at(x, y); arow[x] = a[0] if a else ""
            kind, col = gfx.tile_info(lay, x, y)
            if kind == "plaza" and (x, y) not in core: kind = "road"
            if kind == "road":                          # the road itself is painted as a ribbon later; the ground stays the ground
                b_ = gfx.BIOMES.get(a[0] if a else "Greenfields", gfx.BIOMES["Greenfields"])
                col = shade(mix(b_["base"], b_["alt"], .5), gfx.GROUND_LIFT.get(a[0] if a else "", 1.0) * (.96 + h01(x, y, 3) * .08))
            elif kind == "water": krow[x] = 1
            elif kind == "lava": krow[x] = 2
            tc.set_at((x, y), shade(col, 1.12))
    # zone seams: blend the ground colour across zone borders so the land reads as one continuous map, not tiles
    tb = pygame.transform.smoothscale(pygame.transform.smoothscale(tc, (max(1, W // 10), max(1, WH // 10))), (W, WH))
    seam = []
    SM = 10
    for y in range(SM, WH - SM):
        krow = kinds[y]; arow = area_of[y]; r1 = area_of[y - SM]; r2 = area_of[y + SM]
        for x in range(SM, W - SM):
            if krow[x] or kinds[y - 2][x] or kinds[y + 2][x] or krow[x - 2] or krow[x + 2]: continue
            ar_ = arow[x]
            if ar_ != arow[x - SM] or ar_ != arow[x + SM] or ar_ != r1[x] or ar_ != r2[x]: seam.append((x, y))
    for x, y in seam:
        c0 = tc.get_at((x, y)); c1 = tb.get_at((x, y))
        tc.set_at((x, y), tuple(int(c0[i] * .2 + c1[i] * .8) for i in range(3)))
    # ------------------------------------------------------------ 2. height field (half a tile grid) and hill shading
    hw, hh = W // 2 + 2, WH // 2 + 2
    amp = [[0.0] * hw for _ in range(hh)]
    hts = [[0.0] * hw for _ in range(hh)]
    tick("Raising the hills...", .61)
    for j in range(hh):
        y = min(WH - 1, j * 2)
        for i in range(hw):
            x = min(W - 1, i * 2)
            a = area_of[y][x]
            amp[j][i] = RELIEF.get(gfx.bz(a), .8) if a else .8
            hts[j][i] = vnoise(x, y, 46, 41) * .5 + vnoise(x, y, 17, 42) * .32 + vnoise(x, y, 7, 43) * .18
    amp = _box_blur(amp, hw, hh, 5)
    rel = pygame.Surface((hw, hh))
    for j in range(hh):
        for i in range(hw):
            h0 = hts[j][i] * amp[j][i]
            nw = hts[max(0, j - 1)][max(0, i - 1)] * amp[max(0, j - 1)][max(0, i - 1)]
            se = hts[min(hh - 1, j + 1)][min(hw - 1, i + 1)] * amp[min(hh - 1, j + 1)][min(hw - 1, i + 1)]
            v = .80 + (se - nw) * 3.1 + (h0 - .45) * .16
            x = min(W - 1, i * 2); y = min(WH - 1, j * 2)
            if kinds[y][x] == 1: v = .86 + (vnoise(x, y, 6, 44) - .5) * .12           # water: no relief, a little ripple
            elif (x, y) in core: v = .94 + h01(x, y, 45) * .04    # city squares are flat
            v = max(.52, min(1.0, v))
            g = int(255 * v)
            rel.set_at((i, j), (g, g, g))
    # ------------------------------------------------------------ 3. soft shorelines and zone borders (tile resolution, smoothed up)
    shore = pygame.Surface((W, WH), pygame.SRCALPHA)
    border = pygame.Surface((W, WH), pygame.SRCALPHA)
    for y in range(1, WH - 1):
        krow = kinds[y]; up = kinds[y - 1]; dn = kinds[y + 1]; arow = area_of[y]; drow = area_of[y + 1]
        for x in range(1, W - 1):
            k = krow[x]
            if k == 2: continue
            nb = (krow[x - 1] == 1) + (krow[x + 1] == 1) + (up[x] == 1) + (dn[x] == 1)
            if k == 0 and nb: shore.set_at((x, y), (236, 220, 168, 120 + 30 * nb))            # sand
            elif k == 1 and (krow[x - 1] == 0 or krow[x + 1] == 0 or up[x] == 0 or dn[x] == 0): shore.set_at((x, y), (226, 246, 250, 150))   # foam
            if arow[x] != arow[x + 1] or arow[x] != drow[x]: border.set_at((x, y), (60, 38, 20, 40)) if (x + y) % 3 == 0 else None
    # ------------------------------------------------------------ 4. compose: smooth colour, relief, grain
    m = pygame.transform.smoothscale(tc, (W * s, WH * s))
    m.blit(pygame.transform.smoothscale(rel, (hw * 2 * s, hh * 2 * s)), (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    m.blit(pygame.transform.smoothscale(shore, (W * s, WH * s)), (0, 0))
    # 0.44.14: no grain texture over the atlas (it read as speckle)
    m.blit(pygame.transform.smoothscale(border, (W * s, WH * s)), (0, 0))
    # ------------------------------------------------------------ 4b. rivers and streams (continuous ribbons; roads cross them as bridges)
    def ribbon(pts, wd, deep, mid, foam):
        P = [(int(x * s + s / 2), int(y * s + s / 2)) for x, y in pts]
        if len(P) < 2: return
        pygame.draw.lines(m, foam, False, P, wd + 2)
        for p in P: pygame.draw.circle(m, foam, p, (wd + 2) // 2)
        pygame.draw.lines(m, deep, False, P, wd)
        for p in P: pygame.draw.circle(m, deep, p, wd // 2)
        if wd >= 4:
            pygame.draw.lines(m, mid, False, P, max(1, wd - 3))
            for p in P: pygame.draw.circle(m, mid, p, max(1, (wd - 3) // 2))
    RIVER = {"fresh": ((34, 98, 156), (66, 150, 204)), "ice": ((100, 150, 190), (176, 218, 238)), "dark": ((26, 40, 78), (56, 84, 140)), "murk": ((40, 62, 50), (76, 104, 70))}
    for pts, rk in getattr(lay, "rivers", ()):
        deep, mid = RIVER.get(rk, RIVER["fresh"]); ribbon(pts, 3 * s - 1, deep, mid, (214, 236, 240))
    for ai, a in enumerate(gfx.AREAS):                                        # decorative streams trickling from high ground to the nearest river or lake
        if gfx.bz(a[0]) in ("Sunscar Desert", "Ember Highlands"): continue
        for k in range(3):
            sd = ai * 17 + k * 5
            x = a[1] + 6 + h01(sd, 1, 331) * (a[3] - 12); y = a[2] + 4 + h01(sd, 2, 332) * (a[4] * .5)
            ang = math.pi / 2 + (h01(sd, 3, 333) - .5) * 1.2; pts = [(x, y)]
            for n in range(26):
                ang += (vnoise(x, y, 7, 334 + k) - .5) * .9 + (math.pi / 2 - ang) * .05
                x += math.cos(ang) * 2.0; y += math.sin(ang) * 2.0
                if not (a[1] + 2 < x < a[1] + a[3] - 2 and a[2] + 2 < y < a[2] + a[4] - 2): break
                if any((t_.x - x) ** 2 + (t_.y - y) ** 2 < (TOWN_WALL_R + 3) ** 2 for t_ in world.towns): break
                if (int(x), int(y)) in lay.pond_tiles: break
                pts.append((x, y))
            if len(pts) > 5: ribbon(pts, max(2, s - 1), (52, 120, 176), (96, 168, 214), (200, 226, 236))
    # ------------------------------------------------------------ 5. forests, rocks, peaks, crystals
    veg = pygame.Surface(m.get_size(), pygame.SRCALPHA)
    tick("Planting forests...", .66)
    sprites = []
    for x in range(0, W, 2):
        if x % 40 == 0: tick("Planting forests...", .66 + .05 * x / W)
        for y in range(0, WH, 2):
            an = area_of[y][x]
            if not an or kinds[y][x] or (x, y) in lay.blocked: continue
            kind_t, _ = gfx.tile_info(lay, x, y)
            if kind_t != "ground": continue
            b_ = gfx.BIOMES[an]; names = {n for n, _ in b_["decor"]}
            r = h01(x, y, 77)
            px, py = int(x * s + h01(x, y, 5) * s * 2), int(y * s + h01(x, y, 6) * s * 2)
            zb = gfx.bz(an)
            ridge = vnoise(x, y, 34, 52) * .65 + vnoise(x, y, 11, 53) * .35
            if zb in PEAKS and vnoise(x, y, 30, 51) > (.50 if RELIEF.get(zb, 1) > 1.5 else .60) and r < .30:      # ranges of painted peaks
                hi, lo = PEAKS[zb]; pw = 7 + int(h01(x, y, 8) * 6); ph = pw + 3 + int(h01(x, y, 9) * 6)
                sprites.append((py, "peak", px, py, pw, ph, hi, lo)); continue
            if zb not in ("Sunscar Desert", "Storm Coast", "Bloodfen") and ridge > .72 and r < .28:                    # mountain ranges in every green and grey zone
                pw = 6 + int(h01(x, y, 8) * 5); ph = pw + 2 + int(h01(x, y, 9) * 5)
                sprites.append((py, "peak", px, py, pw, ph, (240, 244, 250), (112, 104, 98))); continue
            forest = max(0.0, min(1.0, (vnoise(x, y, 15, 54) - .42) / .25))                                            # woods are clumped, with open meadows between
            if r < b_["density"] * (1.2 + 6.5 * forest) * (1.0 if zb != "Frostmarch" else .6) * .45:      # 0.44.14: sparser, so the atlas is not speckled
                if names & ROUND_TREES and zb not in ("Frostmarch",):
                    base = (28, 78, 36) if zb != "Storm Coast" else (62, 116, 66)
                    if zb in ("Bloodfen", "Dreadmoor"): base = (44, 70, 40)
                    sprites.append((py, "round", px, py, 3 + int(h01(x, y, 11) * 2), base))
                elif names & SPIKE_TREES:
                    snow = zb == "Frostmarch"
                    base = (30, 78, 52) if not snow else (74, 108, 100)
                    sprites.append((py, "spike", px, py, 7 + int(h01(x, y, 12) * 4), base, snow))
                elif names & ROCKS and h01(x, y, 13) > .55:
                    pygame.draw.circle(veg, (40, 36, 36, 120), (px + 1, py + 1), 2)
                    pygame.draw.circle(veg, (132, 126, 124, 235), (px, py), 2)
                    pygame.draw.circle(veg, (190, 184, 178, 235), (px - 1, py - 1), 1)
                elif names & GEMS:
                    c = (120, 190, 255) if zb == "Wyrmreach" else (180, 100, 255)
                    pygame.draw.polygon(veg, (*shade(c, .5), 240), [(px, py - 5), (px + 3, py), (px, py + 3), (px - 3, py)])
                    pygame.draw.polygon(veg, (*c, 240), [(px, py - 5), (px + 3, py), (px, py)])
                    pygame.draw.circle(veg, (255, 255, 255, 220), (px, py - 2), 1)
                elif "cactus" in names:
                    pygame.draw.line(veg, (44, 100, 56, 240), (px, py), (px, py - 4), 2)
                    pygame.draw.line(veg, (70, 132, 72, 240), (px - 1, py - 2), (px - 1, py - 3), 1)
                elif names & {"dead", "tomb", "bones", "ruin"}:
                    pygame.draw.line(veg, (48, 38, 32, 220), (px, py), (px + 1, py - 4), 1)
                    pygame.draw.line(veg, (48, 38, 32, 200), (px, py - 2), (px - 2, py - 4), 1)
    for sp in sorted(sprites, key=lambda q: q[0]):                    # back to front, so near trees and peaks overlap far ones
        k = sp[1]; px, py = sp[2], sp[3]
        if k == "round":
            rad, base = sp[4], sp[5]
            pygame.draw.circle(veg, (10, 28, 14, 90), (px + 2, py + 2), rad + 1)
            pygame.draw.line(veg, (60, 40, 24, 230), (px, py + rad), (px, py + rad + 2), 1)
            pygame.draw.circle(veg, (*shade(base, .8), 245), (px, py), rad)
            pygame.draw.circle(veg, (*shade(base, 1.45), 245), (px - 1, py - 1), max(1, rad - 1))
        elif k == "spike":
            hgt_, base, snow = sp[4], sp[5], sp[6]
            pygame.draw.polygon(veg, (10, 28, 18, 90), [(px - 3, py + 3), (px + 5, py + 3), (px + 1, py - hgt_ + 2)])
            pygame.draw.polygon(veg, (*shade(base, .8), 245), [(px - 4, py + 2), (px + 4, py + 2), (px, py - hgt_)])
            pygame.draw.polygon(veg, (*(shade(base, 1.5) if not snow else (236, 244, 252)), 245), [(px - 1, py + 2), (px + 4, py + 2), (px, py - hgt_)])
        elif k == "peak":
            pw, ph, hi, lo = sp[4], sp[5], sp[6], sp[7]
            pygame.draw.polygon(veg, (20, 16, 16, 90), [(px - pw + 3, py + 4), (px + pw + 4, py + 4), (px + 2, py - ph + 3)])
            pygame.draw.polygon(veg, (*shade(lo, .8), 250), [(px - pw, py + 2), (px, py - ph), (px + pw, py + 2)])
            pygame.draw.polygon(veg, (*lo, 250), [(px - pw, py + 2), (px, py - ph), (px + 2, py + 2)])
            cap = max(3, ph // 3)
            pygame.draw.polygon(veg, (*hi, 250), [(px - cap, py - ph + cap + 1), (px, py - ph), (px + cap, py - ph + cap + 1), (px + 1, py - ph + cap - 1)])
            pygame.draw.line(veg, (26, 20, 20, 170), (px - pw, py + 2), (px + pw, py + 2), 1)
    m.blit(veg, (0, 0))
    tick("Laying roads...", .72)
    # ------------------------------------------------------------ 6. roads: dark casing, sandy ribbon, light centre line
    for pts, width in getattr(lay, "roadlines", ()):
        P = [(int(x * s + s / 2), int(y * s + s / 2)) for x, y in pts]
        if len(P) < 2: continue
        if width < 1: continue       # 0.44.14: only the main roads on the atlas
        wd = 2 + width
        pygame.draw.lines(m, (84, 58, 32), False, P, wd + 2)
        for p in P[::3]: pygame.draw.circle(m, (84, 58, 32), p, (wd + 2) // 2)
        pygame.draw.lines(m, (208, 180, 124), False, P, wd)
        for p in P[::3]: pygame.draw.circle(m, (208, 180, 124), p, wd // 2)
        pygame.draw.lines(m, (236, 214, 160), False, P, max(1, wd - 3))
    # 0.44.20: towns and dungeons are no longer baked into the shared atlas.  The minimap adds the real streets, walls and
    # buildings (draw_town_detail), the world map adds the icons (draw_icons) - a tall castle icon on the minimap used to sit
    # up and to the right of the real town, so you looked to be outside a town you were standing in.
    return m


def draw_town_detail(m, lay, world, s, ox=0, oy=0):
    """Minimap layer: paved town squares, streets, city walls, every building and the dungeon gates, at their true tiles."""
    for (x, y) in getattr(lay, "plaza", ()):
        pygame.draw.rect(m, (168, 158, 140), (ox + x * s, oy + y * s, s, s))
    for (x, y) in getattr(lay, "street", ()):
        pygame.draw.rect(m, (132, 118, 98), (ox + x * s, oy + y * s, s, s))
    for (x, y) in getattr(lay, "walls", ()):
        pygame.draw.rect(m, (70, 62, 56), (ox + x * s, oy + y * s, s, s))
    for bx, by, bkind, style, var in lay.buildings:
        if bkind == "fountain":
            pygame.draw.circle(m, (90, 170, 220), (ox + int((bx + .5) * s), oy + int((by + .5) * s)), 3); continue
        if bkind not in ("house", "tower", "forge", "hut", "press", "warhall", "magic", "apothecary", "inn", "jeweler", "kiln", "smithy", "general", "bank", "stable", "market", "enchanter"): continue
        px, py = ox + int(bx * s), oy + int(by * s)
        roofs = {"Alliance": ((96, 118, 168), (64, 82, 128)), "Horde": ((160, 70, 52), (112, 44, 34))}.get(style, ((150, 120, 90), (104, 80, 60)))
        if bkind == "tower":
            pygame.draw.circle(m, (46, 38, 30), (px + 3, py + 3), 5); pygame.draw.circle(m, (150, 144, 136), (px + 3, py + 3), 4); pygame.draw.circle(m, roofs[0], (px + 3, py + 3), 2)
        else:
            big = bkind != "house"
            w_, h_ = (9, 8) if big else (6, 5)
            pygame.draw.rect(m, (36, 28, 22), (px - 1, py - 1, w_ + 2, h_ + 2))
            pygame.draw.rect(m, roofs[0], (px, py, w_, h_)); pygame.draw.rect(m, roofs[1], (px + w_ // 2, py, w_ - w_ // 2, h_))
            if big: pygame.draw.rect(m, (240, 214, 120), (px + 3, py + 3, 3, 2))
    for d in world.dungeons:
        draw_gate(m, ox + int(d.x * s), oy + int(d.y * s), d.kind)


def draw_icons(m, world, s, ox=0, oy=0):
    """World-map layer: a thin wall ring round cities and capitals, the town icons and the dungeon gates."""
    for t in world.towns:
        cx, cy = ox + int(t.x * s), oy + int(t.y * s); tier = world.town_tier(t)
        if tier == "town": continue                                  # villages: no ring at all
        wr = max(5, int(TOWN_WALL_R * s * (.4 if tier == "city" else .5)))   # small, thin wall for cities / capitals
        pygame.draw.circle(m, (66, 48, 30), (cx, cy), wr, 1)
    for t in world.towns:
        cx, cy = ox + int(t.x * s), oy + int(t.y * s); tier = world.town_tier(t)
        (draw_castle if tier == "capital" else draw_city if tier == "city" else draw_town)(m, cx, cy, getattr(t, "faction", ""))
    for d in world.dungeons:
        draw_gate(m, ox + int(d.x * s), oy + int(d.y * s), d.kind)
