"""LiveWorld RPG 0.24 game systems, mixed into engine.World.

* class gear rules (cloth / leather / mail / plate, class weapon types) and class-correct loot
* a slower XP curve
* settlement tiers (town / city / capital) with rulers
* real quests from quest givers (kill, gather, fish, boss, elite) and royal commissions
* fishing, cooking ("health food"), alchemy, blacksmithing with crafting materials
* the Mythic questline: exactly one mythic weapon per class
"""
import json
from .brews import BREWS, BY_KEY as BREW_KEY, BY_NAME as BREW_NAME
import math
import random
import re

# ------------------------------------------------------------------ class gear
CLASS_ARMOR = {"Mage": "cloth", "Warlock": "cloth", "Rogue": "leather", "Druid": "leather", "Monk": "leather", "Ranger": "leather",
               "Shaman": "mail", "Cleric": "mail", "Berserker": "mail", "Warrior": "plate", "Paladin": "plate", "Juggernaut": "plate"}
CLASS_WTYPES = {"Warrior": ("sword", "axe", "mace", "hammer"), "Ranger": ("bow", "dagger"), "Mage": ("staff", "wand", "dagger"),
                "Cleric": ("mace", "scepter", "staff"), "Rogue": ("dagger", "sword"), "Paladin": ("sword", "mace", "hammer", "axe"),
                "Shaman": ("totem", "axe", "mace", "staff"), "Druid": ("staff", "mace", "claws", "scepter"), "Berserker": ("axe", "sword"),
                "Warlock": ("wand", "staff", "dagger", "grimoire"), "Monk": ("staff", "fist", "claws"), "Juggernaut": ("hammer", "mace", "axe", "sword")}
ARMOR_BY_TYPE = {
    "cloth": {"armor": ("Robe", "Silk Vestments", "Mystic Robe"), "helm": ("Hood", "Circlet", "Cowl")},
    "leather": {"armor": ("Leather Jerkin", "Studded Tunic", "Hide Jerkin"), "helm": ("Leather Cap", "Hunter's Cap", "Hide Cap")},
    "mail": {"armor": ("Chain Hauberk", "Scale Hauberk", "Mail Hauberk"), "helm": ("Chain Coif", "Mail Coif", "Scale Coif")},
    "plate": {"armor": ("Plate Cuirass", "Breastplate", "Plate Cuirass"), "helm": ("Great Helm", "Plate Helm", "Greathelm")},
}
TRINKET_WORDS = ("Amulet", "Pendant", "Necklace", "Talisman", "Torc", "Locket", "Medallion")   # 0.39: the trinket slot is the necklace
from .jewels import RING_WORDS   # noqa: E402
_ARM_TOK = {"robe": "cloth", "robes": "cloth", "vestments": "cloth", "hood": "cloth", "circlet": "cloth", "cowl": "cloth", "crown": "cloth",
            "jerkin": "leather", "tunic": "leather", "leather": "leather", "cap": "leather",
            "hauberk": "mail", "coif": "mail", "mail": "mail", "chainmail": "mail",
            "cuirass": "plate", "breastplate": "plate", "plate": "plate", "helm": "plate", "greathelm": "plate"}
_WEP_TOK = {"staff": "staff", "quarterstaff": "staff", "wand": "wand", "rod": "wand", "dagger": "dagger", "daggers": "dagger",
            "stiletto": "dagger", "stilettos": "dagger", "kris": "dagger", "knife": "dagger",
            "sword": "sword", "broadsword": "sword", "longsword": "sword", "greatsword": "sword", "blade": "sword", "blades": "sword",
            "axe": "axe", "greataxe": "axe", "cleaver": "axe", "mace": "mace", "flail": "mace", "scepter": "scepter",
            "hammer": "hammer", "warhammer": "hammer", "maul": "hammer", "bow": "bow", "longbow": "bow", "crossbow": "bow",
            "totem": "totem", "claws": "claws", "wraps": "fist", "fist": "fist", "fists": "fist", "grimoire": "grimoire", "tome": "grimoire"}
CASTER_WTYPES = ("staff", "wand", "totem", "grimoire", "scepter")


def armor_type_of(name):
    for t in re.findall(r"[a-z']+", (name or "").lower()):
        if t in _ARM_TOK:
            return _ARM_TOK[t]
        for suf, k in (("plate", "plate"), ("mail", "mail"), ("helm", "plate"), ("robe", "cloth")):
            if t.endswith(suf):
                return k
    return None


def weapon_type_of(name):
    for t in re.findall(r"[a-z']+", (name or "").lower()):
        if t in _WEP_TOK:
            return _WEP_TOK[t]
    return None


def gear_usable(item, slot, cls):
    """('' if cls may use it) else the reason it cannot."""
    if slot == "weapon":
        wt = weapon_type_of(item)
        if wt is not None and wt not in CLASS_WTYPES.get(cls, ()):
            return f"A {cls} cannot wield a {wt}. Allowed: {', '.join(CLASS_WTYPES.get(cls, ()))}."
    elif slot in ("armor", "helm"):
        at = armor_type_of(item)
        want = CLASS_ARMOR.get(cls, "plate")
        if at is not None and at != want:
            return f"A {cls} can only wear {want} armor (this is {at})."
    return ""


# ------------------------------------------------------------------ XP
def xp_need(level):
    """Experience needed to leave `level` (0.24: much slower than the old level*100)."""
    return int(45 * level ** 1.5 + 100)


# ------------------------------------------------------------------ settlements
CAPITAL_IDS = {2: "Alliance", 4: "Horde"}
CAPITAL_NAMES = {2: "Lionsreach", 4: "Grimhold"}
RULER_M = ("Aldric", "Cedric", "Eirik", "Gareth", "Halric", "Joren", "Lothar", "Osric", "Rowan", "Torvald", "Varek", "Wulfric")
RULER_F = ("Brenna", "Dagna", "Fenna", "Isolde", "Kaela", "Maren", "Nessa", "Ysolde", "Seraphine", "Thalia", "Ulva", "Rhosyn")
KING_POST = (0.0, -12.6)

# ------------------------------------------------------------------ materials, fish, food
MATS = {"Mat:Cloth Scrap": 6, "Mat:Leather Scrap": 8, "Mat:Iron Ore": 10, "Mat:Arcane Dust": 30, "Mat:Spirit Essence": 200}
MAT_SOLD = ("Mat:Cloth Scrap", "Mat:Leather Scrap", "Mat:Iron Ore", "Mat:Arcane Dust")      # spirit essence only drops
FISH = ["Meadow Trout", "Ironwood Pike", "Frost Char", "Storm Mackerel", "Fen Eel", "Crown Carp", "Dusk Catfish", "Sun Perch", "Ember Koi", "Void Angler"]
FOODS = {"Food:Grilled Fish": (.025, 16), "Food:Herbed Fish Stew": (.035, 20), "Food:Angler's Feast": (.05, 24)}
FOOD_ORDER = ("Food:Angler's Feast", "Food:Herbed Fish Stew", "Food:Grilled Fish")
BUFF_ITEMS = {"Health Bread": ("bread", 0, 180, "+stats for 3 minutes"), "Sunwine": ("wine", .10, 300, "+10% max health and +40% mana regeneration for 5 minutes")}
SCROLLS = {"Scroll of Might": ("might", .20, 300, "+20% damage for 5 minutes"),
           "Scroll of Fortitude": ("armor", .20, 300, "-20% damage taken for 5 minutes"),
           "Scroll of Swiftness": ("sprint", .25, 180, "+25% movement speed for 3 minutes")}
_BEAST = {"wolf", "boar", "spider", "bear", "dire boar", "giant beetle", "yeti", "ice wolf", "scorpion", "sand wyrm", "drake", "wyvern", "harpy",
          "thunder harpy", "basilisk", "sea serpent", "mud leech", "gnoll"}
_MAGIC = {"skeleton", "ghoul", "wraith", "banshee", "bone knight", "mummy", "cultist", "swamp hag", "demon", "fire imp", "void horror", "shadow stalker",
          "elemental", "magma golem", "lava beast", "dragonkin", "ancient treant"}

# ------------------------------------------------------------------ Legendary questlines (0.44.16)
# One four-part questline per zone, handed out by the quest givers of that zone's towns (step 1 and 3 at the first town, 2 and 4 at the
# second, so you travel between them).  Part four pays a named Legendary piece of magic gear for your class, Legendary Essence and more.
LEGEND_LINES = {
    "Greenfields": ("Lionheart", "weapon", "an old knight's oath-blade, lost when the last war ended"),
    "Ashen Vale": ("Ashbrand", "weapon", "a cinder-forged weapon the first Horde chieftains swore on"),
    "Ironwood": ("Ironbark", "armor", "living-wood armour grown by druids before the kingdoms"),
    "Blackthorn Wilds": ("Thornweaver's", "helm", "a crown of black thorns that whispers to the hunt"),
    "Silverfrost": ("Rimeglass", "trinket", "a shard of the first frost that never melts"),
    "Frostmarch": ("Wintervow", "weapon", "a frozen blade left in the snow by a warrior who would not yield"),
    "Storm Coast": ("Tidecaller's", "ring", "a sea-captain's ring that calms any storm"),
    "Saltcrag Coast": ("Saltwraith", "armor", "drowned-king plate, still crusted with brine and pearls"),
    "Mirewood Fen": ("Hagbane", "helm", "the helm of a witch-hunter who never came back from the fen"),
    "Bloodfen": ("Redtide", "trinket", "a heart-shaped relic that beats in time with bloodshed"),
    "Crownlands": ("Kingsguard", "armor", "royal plate withheld from every king since the fall"),
    "Razorgrass Steppe": ("Windrider's", "weapon", "a horse-lord's weapon, said to cut the wind itself"),
    "Gravemoor": ("Graveborn", "ring", "a ring taken from the hand of the first buried king"),
    "Dreadmoor": ("Dreadwatch", "helm", "a sentinel's helm that sees what hides in the dark"),
    "Sunscar Desert": ("Sunscorch", "trinket", "a sun-disc buried with a desert emperor"),
    "Scorchsand Wastes": ("Mirage", "armor", "armour woven from heat and glass that turns aside blows"),
    "Ember Highlands": ("Emberheart", "weapon", "a blade quenched only in volcanic fire"),
    "Cinder Peaks": ("Cindersoul", "ring", "a ring of black fire from the mountain's core"),
    "Wyrmreach": ("Wyrmslayer's", "weapon", "the weapon that ended a dragon, hidden by its wielder"),
    "Shadowlands": ("Voidwalker's", "trinket", "a shard of the Void itself, bound by an old mage"),
}
LEGEND_STEPS = ("The Whisper", "The Gathering", "The Trial", "The Lair")

# ------------------------------------------------------------------ Mythic weapon
MYTHIC_STEPS = [("zonekill", 150, "Slay 150 creatures in Wyrmreach or Shadowlands."),
                ("dgboss", 6, "Defeat the final boss of a level 91-100 dungeon or raid 6 times."),
                ("hboss0", 3, "Defeat Ashmaw the Devourer in the Heroic raid 3 times."),
                ("hboss1", 3, "Defeat Queen Veyra of the Hollow Choir in the Heroic raid 3 times."),
                ("interrupt", 25, "Interrupt 25 boss casts in dungeons."),
                ("hclear", 5, "Defeat Malachar, the Void Sovereign 5 times."),
                ("arenawin", 12, "Win 12 battlegrounds."),
                ("cityraid", 4, "Help defend 4 cities from elite raids."),
                ("forge", 25000, "Bring 10 Spirit Essence, 25 Arcane Dust, 40 Iron Ore and 25,000 gold to the Forge.")]
MYTHIC_WEAPONS = {"Warrior": "Voidreaver, Blade of the Sovereign", "Ranger": "Voidreaver, Bow of the Sovereign", "Mage": "Voidreaver, Staff of the Sovereign",
                  "Cleric": "Voidreaver, Scepter of the Sovereign", "Rogue": "Voidreaver, Twin Daggers of the Sovereign",
                  "Paladin": "Voidreaver, Sword of the Sovereign", "Shaman": "Voidreaver, Totem of the Sovereign",
                  "Druid": "Voidreaver, Staff of the Hollow Star", "Berserker": "Voidreaver, Greataxe of the Sovereign",
                  "Warlock": "Voidreaver, Grimoire of the Sovereign", "Monk": "Voidreaver, Quarterstaff of the Sovereign",
                  "Juggernaut": "Voidreaver, Warhammer of the Sovereign"}
MYTHIC_FORGE_NEEDS = (("Mat:Spirit Essence", 10), ("Mat:Arcane Dust", 25), ("Mat:Iron Ore", 40))
CLASS_WORDS = {"Warrior": "Warlord", "Ranger": "Stalker", "Mage": "Arcanist", "Cleric": "Hierophant", "Rogue": "Shadowblade", "Paladin": "Lightbringer",
               "Shaman": "Stormcaller", "Druid": "Wildheart", "Berserker": "Bloodreaver", "Warlock": "Soulbinder", "Monk": "Grandmaster", "Juggernaut": "Bulwark"}
RARITY_POWER = {"Common": 0, "Uncommon": 8, "Rare": 18, "Epic": 30, "Elite": 44, "Legendary": 62, "Set": 50, "Mythic": 95}
MAX_ACTIVE_QUESTS = 6
MYTHIC_POWER = 218          # beats a fully upgraded raid weapon (168-174 + 5 upgrades of 6)


class Ev(str):
    """An event message with a unique sequence number, so the same text can show up twice."""
    seq = 0


class EventList(list):
    _n = 0

    def append(self, x):
        EventList._n += 1
        e = Ev(x)
        e.seq = EventList._n
        super().append(e)


ZONE_FLAVOR = {
 "Sunscar Desert": {"kill": ("Caravan Guard", "Drive off the {sp} stalking the caravan roads of the Sunscar Desert: slay {need}."),
                    "herb": ("Desert Medicine", "Gather {need} {t} from the dunes for the oasis healers."),
                    "fish": ("Oasis Angler", "Catch {need} fish at the Sunscar oases."),
                    "elite": ("Sandstorm Champions", "Hunt {need} Elite beasts of the burning dunes.")},
 "Storm Coast": {"kill": ("Island Defence", "Cut down {need} {sp} that threaten the palm villages of the Storm Coast."),
                 "herb": ("Tropical Remedy", "Gather {need} {t} from the jungle shore."),
                 "fish": ("Lagoon Fishing", "Catch {need} fish in the warm lagoons of the Storm Coast."),
                 "elite": ("Typhoon Hunters", "Slay {need} Elite creatures of the Storm Coast.")},
 "Bloodfen": {"kill": ("Jungle Purge", "Clear {need} {sp} out of the steaming fen."),
              "herb": ("Fen Apothecary", "Gather {need} {t} from the mangrove mire."),
              "fish": ("Swamp Fishing", "Catch {need} fish in the fen waters."),
              "elite": ("Fen Champions", "Slay {need} Elite horrors of the Bloodfen.")},
 "Frostmarch": {"kill": ("Mountain Patrol", "Clear {need} {sp} from the snowbound passes."),
                "herb": ("Frostbitten Herbs", "Gather {need} {t} from the snow ridges."),
                "fish": ("Ice Fishing", "Catch {need} fish through the Frostmarch ice."),
                "elite": ("Peak Hunters", "Slay {need} Elite creatures of the high peaks.")},
 "Ember Highlands": {"kill": ("Volcano Watch", "Slay {need} {sp} on the smouldering slopes."),
                     "herb": ("Ashen Herbalist", "Gather {need} {t} from the lava flows."),
                     "fish": ("Magma Pool Angling", "Catch {need} fish in the Ember pools."),
                     "elite": ("Cinder Champions", "Slay {need} Elite beasts of the Ember Highlands.")},
 "Wyrmreach": {"kill": ("Summit Defence", "Slay {need} {sp} circling the dragon peaks."),
               "herb": ("Skyherb Harvest", "Gather {need} {t} from the wind-scoured crags."),
               "fish": ("Highland Angler", "Catch {need} fish in the mountain tarns."),
               "elite": ("Wyrm Hunters", "Slay {need} Elite drakes and beasts of the Wyrmreach.")},
}


def _compass(dx, dy):
    ang = math.degrees(math.atan2(dy, dx)) % 360          # +y is "south" on the screen
    names = ("east", "south-east", "south", "south-west", "west", "north-west", "north", "north-east")
    return names[int((ang + 22.5) // 45) % 8]


class SystemsMixin:
    # ================================================================ class gear
    def item_usable(self, item, slot, item_class=""):
        cls = self.class_name()
        if item_class and item_class != cls:
            return f"{item} requires the {item_class} class."
        if item_class:          # 0.34.3: made for this class (raid sets say "Crown"/"Cuirass" for every class), so no armor-word check
            return ""
        return gear_usable(item, slot, cls)

    def gear_word(self, slot, rng=None, cls=None):
        rng = rng or self.rng
        cls = cls or self.class_name()
        if slot == "weapon":
            return rng.choice(self.CLASS_WEAPONS.get(cls, ("Sword",)))
        if slot in ("armor", "helm"):
            return rng.choice(ARMOR_BY_TYPE[CLASS_ARMOR.get(cls, "plate")][slot])
        if slot == "ring":
            return rng.choice(RING_WORDS)
        return rng.choice(TRINKET_WORDS)

    # ================================================================ settlements
    def town_tier(self, t):
        if t.id in CAPITAL_IDS:
            return "capital"
        return "city" if t.id % 2 == 0 else "town"

    def ruler_for(self, t):
        r = random.Random(f"ruler{self._seed()}:{t.id}")
        fem = r.random() < .5
        first = r.choice(RULER_F if fem else RULER_M)
        tier = self.town_tier(t)
        title = {"capital": "High Queen" if fem else "High King", "city": "Queen" if fem else "King", "town": "Mayor"}[tier]
        return f"{title} {first}", tier

    def town_here(self):
        p = self.player
        if self.inst:
            return None
        from . import engine as E
        t = min(self.towns, key=lambda t: (t.x - p["x"]) ** 2 + (t.y - p["y"]) ** 2)
        if (t.x - p["x"]) ** 2 + (t.y - p["y"]) ** 2 > (E.TOWN_WALL_R + 2) ** 2:
            return None
        ruler, tier = self.ruler_for(t)
        return {"id": t.id, "name": t.name, "tier": tier, "ruler": ruler, "faction": t.faction}

    # ================================================================ inventory helpers
    def _inv_rows(self, prefix):
        return [(r["item"], r["qty"]) for r in self.db.execute("SELECT item,qty FROM inventory WHERE actor_id=0 AND item LIKE ? AND qty>0 ORDER BY item", (prefix + "%",)).fetchall()]


    def gain(self, item, n=1, note=""):
        """0.45: remember a catch / gather so the client can show it (fish, herbs, ore, leather, cache finds)."""
        g = getattr(self, "_gains", None)
        if g is None: g = self._gains = []
        self._gain_seq = getattr(self, "_gain_seq", 0) + 1
        g.append({"seq": self._gain_seq, "item": item, "n": int(n), "note": note})
        del g[:-8]

    def gains_snapshot(self):
        return list(getattr(self, "_gains", ()))

    def fish_total(self):
        return sum(q for _, q in self._inv_rows("Fish:"))

    def food_total(self):
        return sum(q for _, q in self._inv_rows("Food:"))

    def _consume_any(self, prefix, n):
        for item, q in sorted(self._inv_rows(prefix), key=lambda t: -t[1]):
            t = min(q, n)
            self._inv_add(item, -t)
            n -= t
            if n <= 0:
                break

    # ================================================================ materials
    def roll_mats(self, name, level, elite):
        """Monsters leave crafting materials in your pack."""
        sp = name.lower()
        r = self.rng
        got = []
        if sp in _BEAST:
            prim = ("Mat:Leather Scrap", .6)
        elif sp in _MAGIC:
            prim = ("Mat:Arcane Dust", .4)
        else:
            prim = ("Mat:Cloth Scrap" if r.random() < .5 else "Mat:Iron Ore", .55)
        if r.random() < prim[1]:
            got.append((prim[0], 1 + (1 if level > 40 and r.random() < .3 else 0)))
        if r.random() < .22:
            got.append((r.choice(("Mat:Iron Ore", "Mat:Cloth Scrap", "Mat:Leather Scrap")), 1))
        if elite and r.random() < .6:
            got.append(("Mat:Spirit Essence", 1))
        for item, n in got:
            self._inv_add(item, n); self.gain(item, n)
        if got:
            self.db.commit()
            self.events.append("Loot: " + ", ".join(f"+{n} {i[4:]}" for i, n in got))
        return got

    # ================================================================ quests
    def _qs(self):
        try:
            st = json.loads(self._meta("quests2", "{}") or "{}")
        except Exception:
            st = {}
        st.setdefault("active", [])
        st.setdefault("taken", [])
        st.setdefault("done", 0)
        st.setdefault("finished", [])      # 0.44.14: quests handed in are gone for good
        return st

    def _qs_save(self, st):
        st["taken"] = st["taken"][-300:]
        self._setmeta("quests2", json.dumps(st))
        self.db.commit()

    def _zone_for_level(self, lvl, r):
        from . import engine as E
        ok = [a for a in E.AREAS if a[6] <= lvl <= a[7]] or [E.AREAS[-1]]
        mine = [a for a in ok if a[5] in (self.player["faction"], "Neutral")]      # 0.35: quests send you to your side's lands
        return r.choice(mine or ok)

    def quest_offers(self, t, royal=False):
        """0.44.14: every town has a FIXED set of quests, climbing through its zone's level band.  Once handed in a quest never
        returns, so a town runs dry and the player has to move on to the next town / zone."""
        from . import engine as E
        r = random.Random(f"Q{self._seed()}:{t.id}:{'k' if royal else 'g'}")
        tier = self.town_tier(t)
        n = ({"capital": 3, "city": 2, "town": 1}[tier]) if royal else {"capital": 8, "city": 6, "town": 4}[tier]
        zone = next((a for a in E.AREAS if a[0] == t.area), None) or E.AREAS[0]
        lo, hi = zone[6], zone[7]
        st = self._qs()
        gone = set(st["finished"]) | {x["id"] for x in st["active"]}
        out = [] if royal else self._line_offers(t, gone)
        for i in range(n):
            frac_ = i / max(1, n - 1)
            ql = max(1, min(100, lo + round((hi - lo) * (.5 + .5 * frac_ if royal else frac_))))
            kinds = ["kill", "kill", "herb", "fish", "kill"]
            if royal: kinds = ["elite", "kill"] + (["boss"] if ql >= 10 else [])
            elif ql >= 10: kinds.append("boss")
            kind = r.choice(kinds)
            own = zone if zone[5] in (self.player["faction"], "Neutral") else None
            ar = own if (own and r.random() < .7) else self._zone_for_level(ql, r)
            mult = 3 if royal else 1
            q = {"id": f"{t.id}:{'k' if royal else 'g'}{i}", "town": t.id, "town_name": t.name, "kind": kind, "level": ql, "area": ar[0],
                 "royal": royal, "prog": 0}
            if kind == "kill":
                sp = r.choice(E.ZONE_MONSTERS.get(ar[0], ["Wolf"]))
                need = r.randint(6, 12) + ql // 20
                q.update(target=sp, need=need, title=f"Cull the {sp}s" if not royal else f"Royal Hunt: {sp}s",
                         desc=f"Slay {need} {sp} in {ar[0]}.", gold=ql * need * 5 + 30, frac=.010 * need)
            elif kind == "elite":
                need = r.randint(2, 4)
                q.update(target="elite", need=need, title="Champion Hunt", desc=f"Slay {need} Elite creatures in {ar[0]}.",
                         gold=ql * need * 14 + 60, frac=.020 * need)
            elif kind == "herb":
                band = min(9, (ql - 1) // 10)
                hn = self.HERBS[band]
                need = r.randint(4, 8)
                q.update(target=hn, need=need, title="Herbalist's Request", desc=f"Gather {need} {hn}.", gold=ql * need * 6 + 30, frac=.012 * need)
            elif kind == "fish":
                need = r.randint(3, 6)
                q.update(target="fish", need=need, title="Fresh Catch", desc=f"Catch {need} fish at any lake or river.", gold=ql * need * 6 + 30, frac=.012 * need)
            else:
                need = 1 + (1 if ql > 40 else 0)
                q.update(target="boss", need=need, title="Break the Lair", desc=f"Defeat {need} dungeon boss{'es' if need > 1 else ''}.",
                         gold=ql * 90 * need, frac=.10 * need)
            self._flavor(q)
            q["xp"] = max(10, int(xp_need(ql) * q["frac"] * mult))
            q["gold"] = int(q["gold"] * mult)
            self._quest_loot(q)
            if q["id"] in gone:
                continue
            out.append(q)
        return out

    def _line_towns(self, zone_name):
        return sorted([x for x in self.towns if x.area == zone_name], key=lambda x: x.id)

    def _line_offers(self, t, gone):
        """0.44.16: the next unfinished part of each zone's Legendary questline, if this town is the one that hands it out."""
        from . import engine as E
        out = []
        fin = set(self._qs()["finished"])
        for zone in E.AREAS:
            zn = zone[0]
            if zn not in LEGEND_LINES:
                continue
            tw = self._line_towns(zn)
            if not tw:
                continue
            step = next((i for i in range(4) if f"L:{zn}:{i}" not in fin), None)
            if step is None:
                continue
            qid = f"L:{zn}:{step}"
            if tw[step % len(tw)].id != t.id or qid in gone:
                continue
            out.append(self._line_quest(zone, tw, step, t))
        return out

    def _line_quest(self, zone, tw, step, t):
        from . import engine as E
        zn = zone[0]; pre, slot, lore = LEGEND_LINES[zn]
        r = random.Random(f"L{self._seed()}:{zn}:{step}")
        lo, hi = zone[6], zone[7]
        ql = lo + round((hi - lo) * step / 3)
        word = self.gear_word(slot, random.Random(f"LW{self._seed()}:{zn}"))
        item = f"{pre} {word}"
        kind = ("kill", "herb", "elite", "boss")[step]
        q = {"id": f"L:{zn}:{step}", "town": t.id, "town_name": t.name, "kind": kind, "level": ql, "area": zn, "royal": False, "prog": 0,
             "line": True, "line_step": step + 1, "line_item": item, "line_slot": slot}
        nxt = tw[(step + 1) % len(tw)]
        go = f"  The tale goes on at {nxt.name}." if step < 3 else ""
        if kind == "kill":
            sp = r.choice(E.ZONE_MONSTERS.get(zn, ["Wolf"])); need = r.randint(12, 18)
            q.update(target=sp, need=need, desc=f"Rumour tells of {item}: {lore}. Thin out the {sp} in {zn}: slay {need}.{go}", frac=.03 * need / 10)
        elif kind == "herb":
            hn = self.HERBS[min(9, (ql - 1) // 10)]; need = r.randint(8, 12)
            q.update(target=hn, need=need, desc=f"A hermit knows where {item} lies, but wants {need} {hn} for her trouble.{go}", frac=.03 * need / 10)
        elif kind == "elite":
            need = r.randint(3, 4)
            q.update(target="elite", need=need, desc=f"The guardians of {item} are Elite creatures of {zn}. Slay {need} of them to be judged worthy.{go}", frac=.06 * need / 3)
        else:
            need = 2
            q.update(target="boss", need=need, desc=f"{item}: {lore}. It rests behind the dungeon bosses. Defeat {need} and claim it.", frac=.25)
        q["title"] = f"Questline - {item}: {LEGEND_STEPS[step]} ({step + 1}/4)"
        q["gold"] = int(ql * q["need"] * 7 + 80 * (step + 1))
        q["xp"] = max(10, int(xp_need(ql) * q["frac"]))
        self._quest_loot(q)
        if step == 3:
            q["rar"] = "Legendary"; q["ess"] = 2; q["xp"] = int(q["xp"] * 2); q["gold"] = int(q["gold"] * 3)
            q["bonus"] = [["Health Potion", 5], ["Mana Potion", 5], ["Mat:Spirit Essence", 3], ["Health Bread", 2]]
            q["rtext"] = f"LEGENDARY {item} ({slot}) \u2022 2 Leg. Essence \u2022 3 Spirit Ess."
        else:
            q["rtext"] = self.quest_reward_text(q)
        return q

    def _flavor(self, q):
        fl = ZONE_FLAVOR.get(q["area"], {}).get(q["kind"])
        if fl:
            q["title"] = fl[0] if not q.get("royal") else "Royal: " + fl[0]
            q["desc"] = fl[1].format(sp=q.get("target", ""), t=q.get("target", ""), need=q["need"])
        if q["kind"] == "fish" and q["area"] in ZONE_FLAVOR:
            q["zf"] = True

    def daily_offers(self, t):
        """One repeatable daily quest per zone, fresh every game day.  0.44.14: the higher the zone, the better the daily pays
        (gold and XP scale up with zone level, rarer gear, more Spirit Essence, Legendary Essence in the top zones)."""
        from . import engine as E
        lvl = self.player["level"]
        taken = set(self._qs()["taken"])
        zones = sorted([a for a in E.AREAS if a[6] <= lvl + 10 and a[5] in (self.player["faction"], "Neutral")], key=lambda a: abs((a[6] + a[7]) / 2 - lvl))[:5]
        out = []
        for ar in zones:
            r = random.Random(f"D{self._seed()}:{self.day}:{ar[0]}")
            qid = f"D:{self.day}:{ar[0]}"
            if qid in taken:
                continue
            ql = max(ar[6], min(ar[7], lvl))
            kind = r.choice(("kill", "kill", "herb", "fish", "elite"))
            q = {"id": qid, "town": t.id, "town_name": t.name, "kind": kind, "level": ql, "area": ar[0], "royal": False, "prog": 0, "daily": True}
            if kind == "kill":
                sp = r.choice(E.ZONE_MONSTERS.get(ar[0], ["Wolf"]))
                need = r.randint(8, 14)
                q.update(target=sp, need=need, title="", desc="", gold=ql * need * 8 + 60, frac=.016 * need)
            elif kind == "elite":
                need = r.randint(2, 3)
                q.update(target="elite", need=need, title="", desc="", gold=ql * need * 20 + 100, frac=.03 * need)
            elif kind == "herb":
                hn = self.HERBS[min(9, (ql - 1) // 10)]
                need = r.randint(6, 10)
                q.update(target=hn, need=need, title="", desc="", gold=ql * need * 9 + 60, frac=.018 * need)
            else:
                need = r.randint(4, 7)
                q.update(target="fish", need=need, title="", desc="", gold=ql * need * 9 + 60, frac=.018 * need, zf=True)
            fl = ZONE_FLAVOR.get(ar[0], {}).get(kind)
            if fl:
                q["title"] = fl[0]; q["desc"] = fl[1].format(sp=q["target"], t=q["target"], need=need)
            else:
                q["title"] = {"kill": "Cull the " + q["target"] + "s", "elite": "Champion Hunt", "herb": "Herbalist's Request", "fish": "Fresh Catch"}[kind]
                q["desc"] = {"kill": f"Slay {need} {q['target']} in {ar[0]}.", "elite": f"Slay {need} Elite creatures in {ar[0]}.",
                             "herb": f"Gather {need} {q['target']}.", "fish": f"Catch {need} fish in {ar[0]}."}[kind]
            q["title"] = "Daily: " + q["title"]
            zm = 1 + ql / 40.0                                # 1.0x at level 1 up to 3.5x at level 100
            q["gold"] = int(q["gold"] * zm)
            q["xp"] = max(10, int(xp_need(ql) * q["frac"] * zm))
            self._quest_loot(q)
            out.append(q)
        return out

    # ---- 0.41.1: every quest pays a piece of gear and bonus items on top of gold and XP
    QUEST_GEAR_PREFIX = ("Hero's", "Warden's", "Vanguard's", "Pathfinder's", "Champion's", "Oathkeeper's")

    def _quest_loot(self, q):
        """Decide (deterministically from the quest id) the gear rarity and the bonus items this quest pays; stored on the quest."""
        r = random.Random("QL" + str(q["id"]))
        kind = q.get("kind"); ql = q.get("level", 1)
        if q.get("royal"):
            rar = "Elite" if (ql >= 20 and r.random() < .3) else "Epic"
        elif kind == "boss":
            rar = "Epic" if r.random() < .45 else "Rare"
        elif q.get("daily"):
            epic = min(.9, .25 + ql / 120.0)                  # higher zones: more Epic, and Elite gear from level 60
            rar = "Elite" if (ql >= 60 and r.random() < (ql - 50) / 150.0) else "Epic" if r.random() < epic else "Rare"
        elif kind == "elite":
            rar = "Rare" if r.random() < .75 else "Epic"
        else:
            rar = "Rare" if r.random() < .3 else "Uncommon"
        big = bool(q.get("royal")) or kind == "boss"
        bonus = [["Health Potion", 2 + (2 if big else 0)], ["Mana Potion", 2 + (1 if big else 0)]]
        if q.get("daily") or kind == "elite" or big:
            bonus.append(["Mat:Spirit Essence", 1 + (1 if q.get("royal") else 0) + (ql // 30 if q.get("daily") else 0)])
        if big:
            bonus.append(["Health Bread", 1])
            bonus.append([r.choice(("Scroll of Might", "Scroll of Fortitude", "Scroll of Swiftness")), 1])
        elif q.get("daily"):
            bonus.append(["Scroll of Teleportation", 1])
        q["rar"] = rar
        q["bonus"] = bonus
        q["ess"] = 1 if (q.get("royal") or kind == "boss" or (q.get("daily") and ql >= 70 and r.random() < .5)) else 0        # Legendary Essence (gear upgrades)
        q["rtext"] = self.quest_reward_text(q)
        return q

    def quest_reward_text(self, q):
        """One line telling the player what a quest pays beyond gold and XP."""
        names = {"Health Potion": "Health", "Mana Potion": "Mana", "Mat:Spirit Essence": "Spirit Ess.", "Health Bread": "Bread",
                 "Scroll of Teleportation": "Teleport", "Scroll of Might": "Might", "Scroll of Fortitude": "Fortitude", "Scroll of Swiftness": "Swiftness"}
        bits = [f"{q['rar']} gear"] + [f"{n} {names.get(i, i)}" for i, n in q["bonus"]]
        if q.get("ess"):
            bits.append("1 Leg. Essence")
        return " \u2022 ".join(bits)

    def _quest_gear(self, q):
        """Hand over the quest's gear piece: for the slot you are weakest in, class-correct, a little stronger than a drop of the same level."""
        p = self.player
        rar = q["rar"]
        ql = max(1, min(100, q.get("level", p["level"])))
        if q.get("line") and q.get("line_step") == 4:       # 0.44.16: the end of a Legendary questline: a named, class-fitted piece
            power = ql * 2 + RARITY_POWER["Legendary"] + self.rng.randint(8, 16)
            self._grant_gear(q["line_item"], q["line_slot"], "Legendary", power, "Legendary questline", self.class_name(), "")
            return q["line_item"], q["line_slot"], power
        have = {}
        try:
            for row in self.db.execute("SELECT slot, MAX(power) AS mp FROM player_gear WHERE equipped>0 GROUP BY slot").fetchall():
                have[row["slot"]] = row["mp"] or 0
        except Exception:
            pass
        slots = ("weapon", "armor", "helm", "trinket", "ring")
        low = min(have.get(s, 0) for s in slots)
        slot = self.rng.choice([s for s in slots if have.get(s, 0) == low])
        power = max(3, ql * 2 + RARITY_POWER[rar] + self.rng.randint(3, 9))
        item = f"{rar} {self.rng.choice(self.QUEST_GEAR_PREFIX)} {self.gear_word(slot)}"
        cls = self.class_name() if rar in ("Epic", "Elite") else ""
        self._grant_gear(item, slot, rar, power, "Quest reward", cls, "")
        return item, slot, power

    def quest_event(self, kind, name="", area="", elite=False):
        st = self._qs()
        changed = False
        for q in st["active"]:
            if q["prog"] >= q["need"]:
                continue
            hit = False
            if kind == "kill" and q["kind"] == "kill":
                hit = (name == q["target"] and area == q["area"])
            elif kind == "kill" and q["kind"] == "elite":
                hit = elite and area == q["area"]
            elif kind == "herb" and q["kind"] == "herb":
                hit = name == q["target"]
            elif kind == "fish" and q["kind"] == "fish":
                hit = (not q.get("zf")) or area == q["area"]
            elif kind == "boss" and q["kind"] == "boss":
                hit = True
            if hit:
                q["prog"] += 1
                changed = True
                if q["prog"] >= q["need"]:
                    self.events.append(f"Quest ready: {q['title']} - return to {q['town_name']} to claim your reward.")
                else:
                    self.events.append(f"Quest: {q['title']} {q['prog']}/{q['need']}")
        if changed:
            self._qs_save(st)

    def _where(self, x, y):
        p = self.player
        dx, dy = x - p["x"], y - p["y"]
        d = math.hypot(dx, dy)
        return f"{_compass(dx, dy)}, {int(d)} tiles" if d > 12 else "right here"

    def quest_log(self):
        from . import engine as E
        out = []
        for q in self._qs()["active"]:
            t = next((t for t in self.towns if t.id == q["town"]), None)
            ar = next((a for a in E.AREAS if a[0] == q["area"]), None)
            q2 = dict(q)
            if "rtext" not in q2:
                self._quest_loot(q2)
            q2["done"] = q["prog"] >= q["need"]
            q2["town_hint"] = self._where(t.x, t.y) if t else ""
            q2["area_hint"] = self._where(ar[1] + ar[3] / 2, ar[2] + ar[4] / 2) if ar and q["kind"] in ("kill", "elite") else ""
            out.append(q2)
        return out

    def quest_marks(self):
        """Where your active quests lead: [{x, y, r, k, label}] - k is 'hunt' (glow circle round the nearest pack), 'zone', 'turn' (a ? over the town) or 'boss'."""
        c = getattr(self, "_qm_c", None)
        if c and self.tick - c[0] < 16 and not self.inst:
            return c[1]
        out = []
        if not self.inst:
            from . import engine as E
            p = self.player
            for q in self._qs()["active"]:
                label = f"{q.get('title', 'Quest')}  {q['prog']}/{q['need']}"
                if q["prog"] >= q["need"]:
                    t = next((t for t in self.towns if t.id == q["town"]), None)
                    if t is not None:
                        out.append({"x": t.x, "y": t.y, "r": 0, "k": "turn", "label": f"{q.get('title', 'Quest')} - turn in at {t.name}"})
                    continue
                ar = next((a for a in E.AREAS if a[0] == q["area"]), None)
                if ar is None:
                    continue
                k = q["kind"]
                if k in ("kill", "elite"):
                    sp = q.get("target", "")
                    pts = [a for a in self.actors if a.kind == "monster" and a.home == q["area"] and a.hp > 0 and a.role not in ("watch", "raider")
                           and ((k == "elite" and a.name.startswith("Elite ")) or (k == "kill" and sp and sp.lower() in a.name.lower()))]
                    pts.sort(key=lambda a: (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2)
                    if pts:
                        # 0.46.2: the area = every place these monsters actually are, as a few circles (their dens), nearest first
                        cl = []
                        for a in pts[:120]:
                            for c in cl:
                                if math.hypot(a.x - c["x"], a.y - c["y"]) < 18:
                                    c["m"].append((a.x, a.y)); c["x"] = sum(u for u, _ in c["m"]) / len(c["m"]); c["y"] = sum(v for _, v in c["m"]) / len(c["m"]); break
                            else:
                                cl.append({"x": a.x, "y": a.y, "m": [(a.x, a.y)]})
                        circles = [(round(c["x"], 1), round(c["y"], 1), round(min(26, max(9, max(math.hypot(u - c["x"], v - c["y"]) for u, v in c["m"]) + 6)), 1)) for c in cl[:6]]
                        out.append({"x": circles[0][0], "y": circles[0][1], "r": circles[0][2], "k": "hunt", "label": label, "circles": circles, "zone": q["area"]})
                        continue
                    out.append({"x": ar[1] + ar[3] / 2, "y": ar[2] + ar[4] / 2, "r": min(ar[3], ar[4]) / 3, "k": "zone", "label": label,
                                "rect": (ar[1], ar[2], ar[3], ar[4]), "zone": q["area"]})
                elif k == "boss":
                    ds = [d for d in self.dungeons if d.area == q["area"]] or []
                    for d in ds[:4]:
                        out.append({"x": d.x, "y": d.y, "r": 10, "k": "boss", "label": label, "circles": [(round(d.x, 1), round(d.y, 1), 10.0)], "zone": q["area"]})
                    if not ds:
                        out.append({"x": ar[1] + ar[3] / 2, "y": ar[2] + ar[4] / 2, "r": min(ar[3], ar[4]) / 3, "k": "zone", "label": label,
                                    "rect": (ar[1], ar[2], ar[3], ar[4]), "zone": q["area"]})
                else:           # herbs and fish: anywhere in the zone
                    out.append({"x": ar[1] + ar[3] / 2, "y": ar[2] + ar[4] / 2, "r": min(ar[3], ar[4]) / 3, "k": "zone", "label": label,
                                "rect": (ar[1], ar[2], ar[3], ar[4]), "zone": q["area"]})
        self._qm_c = (self.tick, out)
        return out

    def _npc_near(self, npc_id, r=9):
        a = self._shop_npc(npc_id)
        p = self.player
        if a is None or a.kind != "npc" or (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2 > r * r:
            return None
        return a

    def quest_view(self, npc_id):
        a = self._npc_near(npc_id, 10)
        if a is None or a.role not in ("questgiver", "king"):
            return None
        if self.refuse_service(a):          # 0.35: the other side's quest givers will not deal with you
            return None
        t = self._price_town(a)
        royal = a.role == "king"
        ruler, tier = self.ruler_for(t)
        log = self.quest_log()
        # 0.45.3: how much of this town's fixed work (and of the zone's Legendary questline) is already done
        st_ = self._qs(); fin_ = set(st_["finished"]); tag_ = "k" if royal else "g"
        n_tot = ({"capital": 3, "city": 2, "town": 1}[tier]) if royal else {"capital": 8, "city": 6, "town": 4}[tier]
        n_done = sum(1 for i in range(n_tot) if f"{t.id}:{tag_}{i}" in fin_)
        line_done = sum(1 for i in range(4) if f"L:{t.area}:{i}" in fin_) if t.area in LEGEND_LINES else None
        return {"npc": a.id, "name": a.name, "role": a.role, "town": t.name, "tier": tier, "ruler": ruler, "royal": royal,
                "work_done": n_done, "work_total": n_tot, "line_done": line_done, "zone": t.area,
                "offers": self.quest_offers(t, royal), "dailies": [] if royal else self.daily_offers(t), "log": log, "ready": [q for q in log if q["done"] and q["town"] == t.id],
                "slots": (len(log), MAX_ACTIVE_QUESTS), "level": self.player["level"]}

    def quest_accept(self, npc_id, qid):
        v = self.quest_view(npc_id)
        if not v:
            return "Walk up to the quest giver first."
        st = self._qs()
        if len(st["active"]) >= MAX_ACTIVE_QUESTS:
            return f"Your quest log is full ({MAX_ACTIVE_QUESTS}). Finish or abandon one."
        q = next((o for o in v["offers"] + v["dailies"] if o["id"] == qid), None)
        if not q:
            return "That quest is no longer offered."
        st["active"].append(q)
        st["taken"].append(qid)
        self._qs_save(st)
        self._qm_c = None
        try: self.quest_hunt_top_up(force=True)
        except Exception: pass
        return f"Quest accepted: {q['title']} - {q['desc']}"

    QUEST_NEAR = 10            # 0.45: quest monsters kept within reach while you hunt them
    def quest_hunt_top_up(self, force=False):
        """0.45: keep enough of the monsters your kill quests need in their zone - and near you when you are there.
        Other monsters of the zone, out of sight, are re-rolled into the quest species (never in dungeons or raids)."""
        if self.inst: return
        if not force and self.tick % 120: return
        from . import engine as E
        p = self.player
        for q in self._qs()["active"]:
            if q.get("kind") not in ("kill", "elite") or q["prog"] >= q["need"]: continue
            sp = q.get("target", ""); area = q.get("area")
            ar = next((a for a in E.AREAS if a[0] == area), None)
            if ar is None or (q["kind"] == "kill" and not sp): continue
            here = self.area(p["x"], p["y"])[0] == area
            def is_target(a):
                return a.name.startswith("Elite ") if q["kind"] == "elite" else (a.name.split(" #")[0].replace("Elite ", "") == sp)
            mobs = [a for a in self.actors if a.kind == "monster" and a.home == area and a.hp > 0 and a.role not in ("watch", "raider") and a.target != -2]
            d2 = lambda a: (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2
            have = [a for a in mobs if is_target(a) and (not here or d2(a) < 60 * 60)]
            want = self.QUEST_NEAR if here else 24
            need = min(6 if not force else 10, want - len(have))
            if need <= 0: continue
            spare = [a for a in mobs if not is_target(a) and d2(a) > 26 * 26]       # out of sight, so nothing pops in front of you
            spare.sort(key=lambda a: -d2(a))
            for a in spare[:need]:
                num = a.name.split(" #")[-1]
                if q["kind"] == "elite":
                    base = a.name.split(" #")[0].replace("Elite ", ""); a.name = f"Elite {base} #{num}"; a.maxhp = int((70 + a.level * 14) * 2.6)
                else:
                    a.name = ("Elite " if a.name.startswith("Elite ") else "") + f"{sp} #{num}"
                a.hp = a.maxhp
                if here:                       # bring it into hunting range: 28-58 tiles from you, on open ground, out of towns
                    for _ in range(12):
                        ang = self.rng.uniform(0, 6.2832); rr = self.rng.uniform(28, 58)
                        x, y = p["x"] + math.cos(ang) * rr, p["y"] + math.sin(ang) * rr
                        if not (ar[1] + 1 <= x <= ar[1] + ar[3] - 1 and ar[2] + 1 <= y <= ar[2] + ar[4] - 1): continue
                        if self._near_town(x, y, E.TOWN_EXCL_R + 2): continue
                        ok_ = getattr(self, "terrain_ok", None)
                        try:
                            if ok_ is not None and not ok_(x, y): continue
                        except Exception: pass
                        a.x, a.y = x, y; break
            self._qm_c = None

    def quest_species_bias(self, area):
        """0.45: a monster respawning in a zone where you hunt something comes back as that species half the time."""
        if self.inst: return None
        for q in self._qs()["active"]:
            if q.get("kind") == "kill" and q.get("area") == area and q["prog"] < q["need"] and q.get("target"):
                if self.rng.random() < .5: return q["target"]
        return None

    def quest_turnin(self, qid):
        from . import engine as E
        st = self._qs()
        q = next((x for x in st["active"] if x["id"] == qid), None)
        if not q:
            return "You are not on that quest."
        if q["prog"] < q["need"]:
            return "That quest is not finished yet."
        t = next((t for t in self.towns if t.id == q["town"]), None)
        p = self.player
        if t is None or (t.x - p["x"]) ** 2 + (t.y - p["y"]) ** 2 > (E.TOWN_WALL_R + 3) ** 2:
            return f"Return to {q['town_name']} to claim your reward."
        st["active"].remove(q)
        st["done"] += 1
        if not q.get("daily"): st["finished"].append(q["id"])
        self._qs_save(st)
        p["gold"] += q["gold"]
        p["xp"] += q["xp"]
        if "rar" not in q:                  # a quest taken before 0.41.1 pays out like a new one
            self._quest_loot(q)
        self._ensure_potions()
        parts = []
        for it, n in q["bonus"]:
            self._inv_add(it, n); self.gain(it, n, "Quest reward")
            parts.append(f"+{n} {it[4:] if it.startswith('Mat:') else it}")
        self.db.commit()
        gname, gslot, gpow = self._quest_gear(q)
        if q.get("ess"):
            self._add_currency(essence=q["ess"])
            parts.append(f"+{q['ess']} Legendary Essence")
        if q.get("line"):
            self.events.append(f"Questline step {q['line_step']}/4 complete: {q['line_item']}." + (" The legend is yours!" if q["line_step"] == 4 else ""))
        extra = f"  Gear: {gname} ({gslot}, power {gpow})  " + "  ".join(parts)
        self._level_check()
        self._save_player_fast()
        return f"Quest complete: {q['title']}  +{q['xp']:,} XP  +{q['gold']:,} gold.{extra}"

    def quest_abandon(self, qid):
        st = self._qs()
        q = next((x for x in st["active"] if x["id"] == qid), None)
        if not q:
            return ""
        st["active"].remove(q)
        self._qs_save(st)
        return f"Abandoned: {q['title']}."

    # ================================================================ fishing
    fishing = None

    def fish_state(self):
        f = self.fishing
        n = int(self._meta("fish_n", "0") or 0)
        skill = 1 + n // 10
        if not f:
            return {"state": "", "skill": skill, "caught": n}
        return {"state": f["state"], "skill": skill, "caught": n, "x": f["wx"], "y": f["wy"], "left": max(0, f.get("end", self.tick) - self.tick)}

    def fish_action(self):
        """One key does it all: cast, then strike when the float dips."""
        p = self.player
        f = self.fishing
        if f:
            if f["state"] == "bite":
                return self._fish_catch()
            return "Wait for the float to dip - then press G.  (Esc reels in.)"        # 0.42.5: a second G no longer throws the cast away
        if self.inst:
            return "There is no fishing in here."
        near = getattr(self, "water_near", None)
        spot = near(p["x"], p["y"]) if near else None
        if not spot:
            return "There is no water close enough. Stand beside a lake, pond or river and press G."
        if self.tick - self.last_combat_tick < 20:
            return "You cannot fish while fighting - defeat or leave the monsters first."
        if getattr(self, "mounted", None):
            self.dismount(force=True)
        n = int(self._meta("fish_n", "0") or 0)
        skill = 1 + n // 10
        rod = int(self._meta("rod", "0") or 0)
        if not self._buff("bait") and self._inv_qty("Fishing Bait") > 0:
            self._inv_add("Fishing Bait", -1)
            self.buffs["bait"] = {"name": "Lucky Bait", "kind": "bait", "until": self.tick + 300 * 4, "value": 1}
            self.events.append("You bait the hook with Lucky Bait.")
        wait = self.rng.randint(12, 36) - min(8, skill // 4) - rod * 4
        if self._buff("bait"):
            wait = int(wait * .6)
        self.fishing = {"state": "wait", "t0": self.tick, "bite": self.tick + max(6, wait), "px": p["x"], "py": p["y"], "wx": spot[0], "wy": spot[1]}
        return "You cast your line... wait for the float to dip, then press G."

    def _fish_catch(self):
        p = self.player
        self.fishing = None
        band = min(9, (self.area(p["x"], p["y"])[6] - 1) // 10)
        name = FISH[band]
        n = 1
        r = self.rng.random()
        msg = ""
        if r < .03:
            gold = 40 * max(1, p["level"])
            p["gold"] += gold
            msg = f"You hooked a Golden Carp! The innkeepers pay {gold} gold for it. "
        elif r < .11 + .03 * int(self._meta("rod", "0") or 0) + (.08 if self._buff("bait") else 0):
            n = 2
            msg = f"A Giant {name}! (counts as 2) "
        self._inv_add("Fish:" + name, n)
        self.gain("Fish:" + name, n, "Giant!" if n == 2 else "")      # 0.45: shown on screen
        if self.rng.random() < .06:          # 0.44: sunken cache - gold and crafting materials
            lv = max(1, p["level"]); gold = self.rng.randint(8, 16) * lv
            p["gold"] += gold
            mat = self.rng.choice(("Mat:Cloth Scrap", "Mat:Leather Scrap", "Mat:Iron Ore", "Mat:Arcane Dust"))
            q = self.rng.randint(1, 3)
            self._inv_add(mat, q); self.gain(mat, q, f"Sunken cache +{gold}g")
            msg += f"You fish up a sunken cache: {gold} gold and {q}x {mat[4:]}! "
            if self.rng.random() < .1:
                self._inv_add("Mat:Spirit Essence", 1); self.gain("Mat:Spirit Essence", 1); msg += "A Spirit Essence glimmers inside! "
        p["xp"] += 4 + p["level"]; self._level_check()
        cnt = int(self._meta("fish_n", "0") or 0) + 1
        self._setmeta("fish_n", cnt)
        self.db.commit()
        for _ in range(n):
            self.quest_event("fish", area=self.area(p["x"], p["y"])[0])
        if cnt % 10 == 0:
            msg += f"Your fishing skill rose to {1 + cnt // 10}! "
        return msg + f"You caught {n}x {name}."

    def fish_cancel(self, why="You stop fishing."):
        if self.fishing:
            self.fishing = None
            self.events.append(why)

    def _fish_tick(self):
        f = self.fishing
        if not f:
            return
        p = self.player
        if (p["x"] - f["px"]) ** 2 + (p["y"] - f["py"]) ** 2 > 1.6 ** 2:
            self.fish_cancel()
            return
        if self.tick - self.last_combat_tick < 8:
            self.fish_cancel("Your line snaps as combat breaks out.")
            return
        if f["state"] == "wait" and self.tick >= f["bite"]:
            n = int(self._meta("fish_n", "0") or 0)
            f["state"] = "bite"
            f["end"] = self.tick + 14 + min(6, (1 + n // 10) // 5)       # about 3.5 s to strike
            self.events.append("A fish is biting! Press G now!")
        elif f["state"] == "bite" and self.tick >= f["end"]:
            self.fishing = None
            self.events.append("The fish got away.")

    # ================================================================ food and scrolls
    def eat_food(self):
        if self.tick - self.last_combat_tick < 20:
            return "You cannot eat while fighting."
        if self._buff("food"):
            return "You are already eating."
        for item in FOOD_ORDER:
            if self._inv_qty(item) > 0:
                rate, dur = FOODS[item]
                if self.player["hp"] >= self._effective_maxhp():
                    return "Your health is already full."
                self._inv_add(item, -1)
                self.buffs["food"] = {"name": item[5:], "kind": "food", "until": self.tick + dur * 4, "value": rate, "next": self.tick + 4}
                self.db.commit()
                return f"You eat {item[5:]}: recovering {int(rate * 100)}% health per second for {dur}s (stay out of combat)."
        return "You have no food. Catch fish (G near water) and cook them at an inn."

    def _food_tick(self):
        self._brew_tick()
        b = self.buffs.get("food")
        if not b:
            return
        if self.tick - self.last_combat_tick < 8:
            self.buffs.pop("food", None)
            self.events.append("Combat interrupts your meal.")
            return
        if self.tick >= b["next"]:
            b["next"] = self.tick + 4
            self._heal(self._effective_maxhp() * b["value"])

    def use_buff_scroll(self):
        for item, (kind, val, dur, desc) in BUFF_ITEMS.items():
            if self._inv_qty(item) > 0 and not self._buff(kind):
                self._inv_add(item, -1)
                if kind == "bread":
                    val = 4 + self.player["level"] // 6
                    desc = f"+{val} to Strength, Agility, Intellect and Vitality for 3 minutes"
                self.buffs[kind] = {"name": item, "kind": kind, "until": self.tick + dur * 4, "value": val}
                self.db.commit()
                return f"{item}: {desc}."
        for item, (kind, val, dur, desc) in SCROLLS.items():
            if self._inv_qty(item) > 0 and not self._buff(kind):
                self._inv_add(item, -1)
                self.buffs[kind] = {"name": item, "kind": kind, "until": self.tick + dur * 4, "value": val}
                self.db.commit()
                return f"{item}: {desc}."
        for b in BREWS:
            if self._inv_qty("Brew:" + b["name"]) > 0 and p_lvl_ok(self, b) and not self._buff(b["kind"]):
                return self.use_brew(b["name"])
        if any(self._inv_qty(i) > 0 for i in list(SCROLLS) + list(BUFF_ITEMS)) or self.brew_counts():
            return "Those effects are already active."
        return "No buffs to use. Bake Health Bread at an inn, press Sunwine at a Wine Press, or brew scrolls (Alchemy)."

    def brew_counts(self):
        return {b["name"]: self._inv_qty("Brew:" + b["name"]) for b in BREWS if self._inv_qty("Brew:" + b["name"]) > 0}

    def use_brew(self, name):
        b = BREW_NAME.get(name)
        if not b or self._inv_qty("Brew:" + name) < 1:
            return "You have none of those."
        if self.player["level"] < b["lvl"]:
            return f"{name} needs level {b['lvl']}."
        if self._buff(b["kind"]):
            return "That kind of effect is already active."
        self._inv_add("Brew:" + name, -1)
        self.buffs[b["kind"]] = {"name": name, "kind": b["kind"], "until": self.tick + b["dur"] * 4, "value": b["value"]}
        if b["kind"] == "stealth":
            self.events.append("You fade from sight.")
        self.db.commit()
        return f"{name}: {b['desc']}."

    def _brew_tick(self):
        b = self._buff("regen")
        if b and self.tick % 4 == 0:
            self._heal(self._effective_maxhp() * b["value"])

    def scroll_counts(self):
        return {i: self._inv_qty(i) for i in list(SCROLLS) + list(BUFF_ITEMS)}

    # ================================================================ crafting
    _invc = None

    def _have(self, item):
        c = self._invc
        if c is None:
            c = self._invc = {r["item"]: r["qty"] for r in self.db.execute("SELECT item,qty FROM inventory WHERE actor_id=0").fetchall()}
        if item == "herb*":
            return sum(q for i, q in c.items() if i.startswith("Herb:"))
        if item == "fish*":
            return sum(q for i, q in c.items() if i.startswith("Fish:"))
        return c.get(item, 0)

    def _label(self, item):
        return {"herb*": "Herbs (any)", "fish*": "Fish (any)"}.get(item, item.split(":", 1)[-1])

    def _row(self, key, name, desc, needs, gold, minlvl, slot="potion", rarity="Common", extra=None):
        lvl = self.player["level"]
        nrows = [(self._label(i), self._have(i), n) for i, n in needs]
        ok = all(h >= n for _, h, n in nrows)
        why = ""
        if lvl < minlvl:
            ok = False
            why = f"Requires level {minlvl}"
        elif not ok:
            why = "Missing ingredients"
        elif self.player["gold"] < gold:
            ok = False
            why = f"Needs {gold:,} gold"
        r = {"key": key, "raw": list(needs), "name": name, "desc": desc, "needs": nrows, "gold": gold, "minlvl": minlvl, "slot": slot, "rarity": rarity, "can": ok, "why": why}
        if extra:
            r.update(extra)
        return r

    def _smith_recipes(self):
        cls = self.class_name()
        word = CLASS_WORDS[cls]
        atype = CLASS_ARMOR[cls]
        tiers = (("fine", "Fine", "Uncommon", 1, 6, 0, 0, 60), ("superior", "Superior", "Rare", 15, 12, 2, 0, 200),
                 ("exquisite", "Exquisite", "Epic", 35, 20, 5, 1, 900),     # 0.40: no set recipes - sets only drop in raids
                 ("master", "Masterwork", "Epic", 50, 26, 8, 2, 2500),      # 0.45: better gear to make as you level
                 ("heroic", "Heroic", "Elite", 60, 34, 10, 4, 7000), ("grand", "Grandmaster", "Elite", 75, 42, 14, 6, 15000),
                 ("legend", "Legendary", "Legendary", 90, 52, 20, 10, 40000), ("ascend", "Ascendant", "Legendary", 100, 64, 28, 16, 90000))
        tabs = []
        for slot, title in (("weapon", "Weapons"), ("armor", "Armor"), ("helm", "Helms"), ("trinket", "Necklaces")):
            rows = []
            for ti, (tk, tn, rar, minlvl, prim_n, dust, ess, gold) in enumerate(tiers):
                if slot == "weapon":
                    words = self.CLASS_WEAPONS.get(cls, ("Sword",))
                    base = words[ti % len(words)]
                    prim = "Mat:Arcane Dust" if weapon_type_of(base) in CASTER_WTYPES else "Mat:Iron Ore"
                elif slot == "trinket":
                    base = TRINKET_WORDS[ti % len(TRINKET_WORDS)]
                    prim = "Mat:Arcane Dust"
                else:
                    words = ARMOR_BY_TYPE[atype][slot]
                    base = words[ti % len(words)]
                    prim = {"cloth": "Mat:Cloth Scrap", "leather": "Mat:Leather Scrap"}.get(atype, "Mat:Iron Ore")
                nd = {prim: prim_n}
                if dust:
                    nd["Mat:Arcane Dust"] = nd.get("Mat:Arcane Dust", 0) + dust
                if slot == "weapon" and ti >= 1:
                    sec = "Mat:Leather Scrap" if prim == "Mat:Iron Ore" else "Mat:Cloth Scrap"
                    nd[sec] = nd.get(sec, 0) + 2 + ti
                if ess:
                    nd["Mat:Spirit Essence"] = ess
                needs = list(nd.items())
                name = f"{tn} {base}"
                setname = ""
                if rar == "Set":
                    setname = f"{word} Regalia" if tk == "set1" else f"Ascendant {word} Regalia"
                rows.append(self._row(f"sm:{slot}:{tk}", name, f"{rar} {slot}" + (f" - part of the {setname} set" if setname else ""),
                                      needs, gold, minlvl, slot="weapon" if slot == "weapon" else slot, rarity=rar,
                                      extra={"item": name, "set_name": setname,
                                             "power": min({"grand": 172, "ascend": 186}.get(tk, {"Elite": 168, "Legendary": 174}.get(rar, 160)),
                                                          self.player["level"] * 2 + RARITY_POWER[rar] + 3 + {"master": 4, "grand": 6, "ascend": 12}.get(tk, 0))}))
            tabs.append({"name": title, "rows": rows})
        tabs.append({"name": "Upgrade +5", "rows": self._upgrade_rows()})
        return tabs

    # ================================================================ 0.46 Forge upgrades: any piece of gear, +1 to +5
    FORGE_UP_POWER = 6

    def _upgrade_cost(self, r, n):
        """Materials and gold to take a piece from +n to +n+1."""
        jew = r["slot"] in ("ring", "trinket")
        nd = {("Mat:Arcane Dust" if jew else "Mat:Iron Ore"): 4 + 4 * n}
        if n >= 1: nd["Mat:Arcane Dust"] = nd.get("Mat:Arcane Dust", 0) + 2 * n
        if n >= 2: nd["Mat:Spirit Essence"] = n - 1
        gold = max(80, int(r["power"] * 10 * (n + 1) * (1.5 if r["rarity"] in ("Legendary", "Mythic", "Set") else 1.0)))
        return list(nd.items()), gold, (2 if n == 4 else 1 if n == 3 else 0)

    def _upgrade_rows(self):
        from .bonuses import btext
        rows = []
        gear = self.db.execute("SELECT * FROM player_gear WHERE vault=0 ORDER BY equipped DESC, power DESC, id DESC").fetchall()
        ess_have = self._currency()["legendary_essence"]
        for r in gear[:40]:
            base, n = self._up_split(r["item"])
            if n >= self.UPGRADE_MAX:
                row = self._row(f"up:{r['id']}", r["item"], f"{r['slot']} - fully upgraded (+{self.UPGRADE_MAX})", [], 0, 1, r["slot"], r["rarity"])
                row["can"] = False; row["why"] = "Maximum +5"
            else:
                needs, gold, ess = self._upgrade_cost(r, n)
                b = self.item_bonus(r)
                desc = f"+{n} -> +{n + 1}: Power {r['power']} -> {r['power'] + self.FORGE_UP_POWER}" + (f", bonus +10% ({btext(b)})" if b else "") \
                    + (f"  - also {ess} Legendary Essence" if ess else "") + ("  [equipped]" if r["equipped"] else "")
                row = self._row(f"up:{r['id']}", r["item"], desc, needs, gold, 1, r["slot"], r["rarity"])
                if row["can"] and ess_have < ess:
                    row["can"] = False; row["why"] = f"Needs {ess} Legendary Essence"
            row["btn"] = "Upgrade"
            rows.append(row)
        return rows

    def forge_upgrade(self, gear_id):
        r = self.db.execute("SELECT * FROM player_gear WHERE id=?", (gear_id,)).fetchone()
        if not r: return "Gear item not found."
        if r["vault"]: return f"{r['item']} is in your vault. Take it out at a Banker first."
        base, n = self._up_split(r["item"])
        if n >= self.UPGRADE_MAX: return f"{r['item']} is already +{self.UPGRADE_MAX}."
        needs, gold, ess = self._upgrade_cost(r, n)
        miss = [f"{q - self._have(it)} more {self._label(it)}" for it, q in needs if self._have(it) < q]
        if self.player["gold"] < gold: miss.append(f"{gold - self.player['gold']:,} more gold")
        if self._currency()["legendary_essence"] < ess: miss.append(f"{ess} Legendary Essence")
        if miss: return "To upgrade you still need " + ", ".join(miss) + "."
        for it, q in needs: self._inv_add(it, -q)
        self.player["gold"] -= gold
        if ess: self._add_currency(essence=-ess)
        newp = r["power"] + self.FORGE_UP_POWER; name = f"{base} +{n + 1}"
        self.db.execute("UPDATE player_gear SET item=?, power=? WHERE id=?", (name, newp, gear_id))
        if r["equipped"] and r["slot"] in ("weapon", "armor"): self.player[r["slot"]] = max(self.player[r["slot"]], newp)
        if hasattr(self, "_gear_changed"): self._gear_changed()
        self.db.commit(); self._save_player_fast()
        return f"The Forge tempers {base} to +{n + 1}: Power {r['power']} -> {newp}."

    def _alchemy_recipes(self):
        rows = [
            self._row("health", "Health Potion x2", "Restores a third of your health.", [("herb*", 2)], 0, 1, "potion"),
            self._row("mana", "Mana Potion x2", "Restores 50 mana.", [("herb*", 2)], 0, 1, "mana"),
            self._row("scroll", "Scroll of Teleportation", "Teleports you to the nearest town.", [("herb*", 4)], 25, 1, "scroll"),
            self._row("might", "Scroll of Might", SCROLLS["Scroll of Might"][3] + ".", [("herb*", 3), ("Mat:Arcane Dust", 1)], 40, 5, "scroll", "Rare"),
            self._row("fortitude", "Scroll of Fortitude", SCROLLS["Scroll of Fortitude"][3] + ".", [("herb*", 3), ("Mat:Leather Scrap", 2)], 40, 5, "scroll", "Rare"),
            self._row("weave", "Weave Cloth x3", "Spin herb fibres into Cloth Scrap for cloth armor and brews.", [("herb*", 3)], 5, 1, "scroll"),
            self._row("swiftness", "Scroll of Swiftness", SCROLLS["Scroll of Swiftness"][3] + ".", [("herb*", 3), ("Mat:Cloth Scrap", 2)], 40, 5, "scroll", "Rare"),
        ]
        return rows

    def _brew_recipes(self):
        rows = []
        for b in BREWS:
            r = self._row(b["key"], f"{b['name']} x{b['n']}", f"{b['desc']}.", b["needs"], b["gold"], b["lvl"], "potion",
                          "Common" if b["lvl"] < 20 else "Uncommon" if b["lvl"] < 45 else "Rare" if b["lvl"] < 75 else "Epic")
            r["cat"] = b["cat"]
            rows.append(r)
        return rows

    def _cooking_recipes(self):
        return [
            self._row("grill", "Grilled Fish", "Eat (V): 2.5% health per second for 16 s.", [("fish*", 1)], 0, 1, "fish"),
            self._row("stew", "Herbed Fish Stew", "Eat (V): 3.5% health per second for 20 s.", [("fish*", 2), ("herb*", 1)], 0, 1, "fish", "Uncommon"),
            self._row("bread", "Health Bread", "Use (Y): +4 and 1 per 6 levels to all stats for 3 minutes.", [("herb*", 3), ("fish*", 1)], 20, 1, "fish", "Rare"),
            self._row("feast", "Angler's Feast", "Eat (V): 5% health per second for 24 s.", [("fish*", 3), ("herb*", 2)], 40, 1, "fish", "Rare"),
        ]

    def craft_view(self, station):
        self._invc = None
        try:
            return self._craft_view(station)
        finally:
            self._invc = None

    def _hut_recipes(self):
        rod = int(self._meta("rod", "0") or 0)
        rows = [
            self._row("hut:health", "Fish Oil Tonic: Health Potion x3", "Restores a third of your health.", [("fish*", 2)], 0, 1, "potion"),
            self._row("hut:mana", "Brine Draught: Mana Potion x3", "Restores 50 mana.", [("fish*", 2)], 0, 1, "mana"),
            self._row("hut:bait", "Lucky Bait x3", "Used automatically when you cast: faster bites, more Giant fish for 5 minutes.", [("fish*", 1), ("herb*", 1)], 0, 1, "fish", "Uncommon"),
        ]
        for i, (nm, mn, needs, gold, d) in enumerate((("Hardwood Rod", 5, [("Mat:Leather Scrap", 4)], 150, "Faster bites."),
                                                      ("Reinforced Rod", 25, [("Mat:Iron Ore", 8), ("Mat:Leather Scrap", 4)], 800, "Much faster bites, more Giant fish."),
                                                      ("Master's Rod", 50, [("Mat:Arcane Dust", 8), ("Mat:Spirit Essence", 1)], 4000, "The fastest bites and the best catches."))):
            r = self._row(f"hut:rod{i + 1}", nm, "Fishing gear. " + d, needs, gold, mn, "fish", "Rare" if i < 2 else "Epic")
            if rod >= i + 1:
                r["can"] = False; r["why"] = "Owned"
            elif rod < i:
                r["can"] = False; r["why"] = "Craft the previous rod first"
            rows.append(r)
        return rows

    def _press_recipes(self):
        return [
            self._row("wp:health", "Pressed Health Potion x4", "Restores a third of your health.", [("herb*", 3)], 0, 1, "potion"),
            self._row("wp:mana", "Pressed Mana Potion x4", "Restores 50 mana.", [("herb*", 3)], 0, 1, "mana"),
            self._row("wp:wine", "Sunwine", "Use (Y): +10% max health, +40% mana regeneration for 5 minutes.", [("herb*", 5)], 30, 5, "potion", "Rare"),
            self._row("wp:bigmana", "Moonwine Mana Potion x6", "Restores 50 mana each.", [("herb*", 6), ("Mat:Arcane Dust", 1)], 40, 10, "mana", "Uncommon"),
        ]

    STATION_INFO = {"inn": ("Alchemy & Cooking", "innkeeper", None), "smith": ("Forge", "blacksmith", "forge"), "forge": ("Forge", "blacksmith", "forge"),
                    "hut": ("Fishing Hut", "fishmonger", "hut"), "press": ("Wine Press", None, "press")}
    station_posts = None          # filled in by the client: {"forge": [(x, y)], ...}

    def _near_station(self, kind, r=5.5):
        p = self.player
        return any((x - p["x"]) ** 2 + (y - p["y"]) ** 2 <= r * r for x, y in (self.station_posts or {}).get(kind, ()))

    def _station_ok(self, station):
        title, role, bld = self.STATION_INFO[station]
        return bool((role and self._near_role(role)) or (bld and self._near_station(bld)))

    def _craft_view(self, station):
        if station not in self.STATION_INFO:
            station = "smith"
        if station == "inn":
            tabs = [{"name": "Alchemy", "rows": self._alchemy_recipes()}, {"name": "Elixirs", "rows": self._brew_recipes()}, {"name": "Cooking", "rows": self._cooking_recipes()}]
        elif station in ("smith", "forge"):
            tabs = self._smith_recipes()
        elif station == "hut":
            tabs = [{"name": "Gear & Tonics", "rows": self._hut_recipes()}, {"name": "Elixirs", "rows": self._brew_recipes()}, {"name": "Cooking", "rows": self._cooking_recipes()}]
        else:
            tabs = [{"name": "Potions & Wine", "rows": self._press_recipes()}]
        return {"station": station, "title": self.STATION_INFO[station][0], "tabs": tabs, "gold": self.player["gold"], "ok": self._station_ok(station),
                "fish": self.fish_total(), "herbs": self.herb_count()}

    def _near_role(self, role, r=9):
        p = self.player
        return any(a.kind == "npc" and a.role == role and (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2 <= r * r for a in self.actors)

    def craft(self, key):
        if not isinstance(key, str): return "Unknown recipe."
        station = "smith" if key.startswith(("sm:", "up:")) else "hut" if key.startswith("hut:") else "press" if key.startswith("wp:") else "inn"
        if (key in ("grill", "stew", "feast", "bread") or key.startswith("br:")) and not self._station_ok("inn") and self._station_ok("hut"):
            station = "hut"
        if station == "smith" and self._near_station("forge"):
            station = "forge"
        if not self._station_ok(station):
            return "Stand next to the " + {"smith": "blacksmith or forge", "forge": "forge", "inn": "innkeeper", "hut": "fishing hut", "press": "wine press"}[station] + " to craft."
        v = self.craft_view(station)
        row = next((r for tab in v["tabs"] for r in tab["rows"] if r["key"] == key), None)
        if not row:
            return "Unknown recipe."
        if key.startswith("up:"):
            return self.forge_upgrade(int(key[3:]))
        if not row["can"]:
            return row["why"] + "." if row["why"] else "You cannot craft that."
        spec = {"health": ("Health Potion", 2), "mana": ("Mana Potion", 2), "scroll": ("Scroll of Teleportation", 1), "might": ("Scroll of Might", 1),
                "fortitude": ("Scroll of Fortitude", 1), "weave": ("Mat:Cloth Scrap", 3), "swiftness": ("Scroll of Swiftness", 1),
                "bread": ("Health Bread", 1), "hut:health": ("Health Potion", 3), "hut:mana": ("Mana Potion", 3), "hut:bait": ("Fishing Bait", 3),
                "wp:health": ("Health Potion", 4), "wp:mana": ("Mana Potion", 4), "wp:wine": ("Sunwine", 1), "wp:bigmana": ("Mana Potion", 6),
                "grill": ("Food:Grilled Fish", 1), "stew": ("Food:Herbed Fish Stew", 1), "feast": ("Food:Angler's Feast", 1)}
        for item, n in row["raw"]:
            if item == "herb*":
                need = n
                for nm, q in sorted(self.herb_list(), key=lambda t: -t[1]):
                    t = min(q, need)
                    self._inv_add("Herb:" + nm, -t)
                    need -= t
                    if need <= 0:
                        break
            elif item == "fish*":
                self._consume_any("Fish:", n)
            else:
                self._inv_add(item, -n)
        self.player["gold"] -= row["gold"]
        if key in BREW_KEY:
            bd = BREW_KEY[key]
            self._inv_add("Brew:" + bd["name"], bd["n"])
            msg = f"Brewed {bd['n']}x {bd['name']}. Drink it with Y or from your bag (I)."
        elif key in spec:
            out, n = spec[key]
            if "health" in key:
                self._ensure_potions()
            self._inv_add(out, n)
            msg = f"Crafted {n}x {row['name'].split(' x')[0]}."
        elif key.startswith("hut:rod"):
            self._setmeta("rod", int(key[-1]))
            msg = f"You craft the {row['name']}. Your line will bite faster."
        else:
            rar = row["rarity"]
            cls = self.class_name()
            slot = row["slot"]
            power = row["power"]
            msg = self._grant_gear(row["item"], slot, rar, power, "Crafted", cls, row.get("set_name", ""))
            msg = f"Forged {row['item']} (power {power}). Equip it from your Bag (I)."
        self.db.commit()
        self._save_player_fast()
        return msg

    # ================================================================ Mythic weapon (one per class)
    def _mythic_state(self):
        try:
            st = json.loads(self._meta("mythic", "{}"))
        except Exception:
            return {}
        if st.get("_v", 0) < 3:         # 0.24: one mythic weapon per class; the old weapon chain carries over to the current class
            old = st.get("weapon")
            st = {"_v": 3}
            if old:
                st[self.class_name()] = old
            self._setmeta("mythic", json.dumps(st))
        return st

    def mythic_info(self):
        cls = self.class_name()
        st = self._mythic_state()
        i, pr = st.get(cls, [0, 0])
        done = i >= len(MYTHIC_STEPS)
        cur = MYTHIC_STEPS[min(i, len(MYTHIC_STEPS) - 1)]
        forge = (not done and cur[0] == "forge")
        needs = [(it[4:], self._inv_qty(it), n) for it, n in MYTHIC_FORGE_NEEDS] if forge else []
        return [{"slot": "weapon", "cls": cls, "title": MYTHIC_WEAPONS[cls], "step": min(i, len(MYTHIC_STEPS)), "steps": len(MYTHIC_STEPS),
                 "text": "Forged!" if done else cur[2], "prog": pr, "need": cur[1], "done": done, "forge": forge, "needs": needs,
                 "all": [s[2] for s in MYTHIC_STEPS]}]


    def mythic_event(self, ev, **kw):
        if self.player["level"] < 91:
            return
        cls = self.class_name()
        st = self._mythic_state()
        i, pr = st.get(cls, [0, 0])
        if i >= len(MYTHIC_STEPS):
            return
        t = MYTHIC_STEPS[i][0]
        key = ev if ev != "hboss" else f"hboss{kw.get('idx', 0)}"
        if t != key or t == "forge":
            return
        pr += 1
        if pr >= MYTHIC_STEPS[i][1]:
            i += 1
            pr = 0
            nxt = "Return to the Forge to finish it!" if MYTHIC_STEPS[i][0] == "forge" else "Next: " + MYTHIC_STEPS[i][2]
            self.events.append(f"Mythic weapon quest: step complete! {nxt}")
        st[cls] = [i, pr]
        self._setmeta("mythic", json.dumps(st))
        if pr == 0 and hasattr(self, "_gear_changed"): self._gear_changed()       # 0.46: each step adds to the Oath bonus

    def _grant_mythic(self, source="Mythic Quest"):
        cls = self.class_name()
        owned = self.db.execute("SELECT 1 FROM player_gear WHERE rarity='Mythic' AND class=?", (cls,)).fetchone()
        if owned:
            return ""
        st = self._mythic_state()
        st[cls] = [len(MYTHIC_STEPS), 0]
        self._setmeta("mythic", json.dumps(st))
        if hasattr(self, "_gear_changed"): self._gear_changed()
        self.events.append("You swear the Oath of the Sovereign: +15 to every stat, +5% damage, +5% max health, +3% critical strike.")
        return self._grant_gear(MYTHIC_WEAPONS[cls], "weapon", "Mythic", MYTHIC_POWER + self.rng.randint(0, 4), source, cls, "")

    def mythic_forge(self):
        if self.player["level"] < 91:
            return ""
        cls = self.class_name()
        st = self._mythic_state()
        i, pr = st.get(cls, [0, 0])
        if i >= len(MYTHIC_STEPS) or MYTHIC_STEPS[i][0] != "forge":
            return ""
        cost = MYTHIC_STEPS[i][1]
        missing = [f"{n - self._inv_qty(it)} more {it[4:]}" for it, n in MYTHIC_FORGE_NEEDS if self._inv_qty(it) < n]
        if self.player["gold"] < cost:
            missing.append(f"{cost - self.player['gold']:,} more gold")
        if missing:
            return "The Forge can make your Mythic weapon - you still need " + ", ".join(missing) + "."
        for it, n in MYTHIC_FORGE_NEEDS:
            self._inv_add(it, -n)
        self.player["gold"] -= cost
        self.db.commit()
        msg = self._grant_mythic()
        self._save_player_fast()
        return msg

    # ================================================================ snapshot extras
    def rpg_snapshot(self):
        return {"quest_log": self.quest_log(), "food": self.food_total(), "fish_count": self.fish_total(), "fishing": self.fish_state(),
                "scrolls": self.scroll_counts(), "town_here": self.town_here(), "xp_need": xp_need(self.player["level"]),
                "mats": {k[4:]: self._inv_qty(k) for k in MATS}, "brews": self.brew_counts()}

    def inventory_goods(self):
        """Non-gear things in the pack that shops will buy: (item, qty)."""
        out = []
        for pre in ("Mat:", "Fish:", "Food:", "Brew:", "Scroll of"):
            out += self._inv_rows(pre)
        return out

    # ================================================================ 0.34 War Hall Armory
    # Raid Tokens, PvP Points and Legendary Essence were earned but never spent. The Armory spends them.
    # 0.35.1: raid and dungeon gear cannot be bought - only Gladiator gear (PvP Points) is sold, and it is a grind.
    # Raid Tokens pay for upgrades instead.
    PVP_PIECES = (("weapon", 600), ("armor", 500), ("helm", 350), ("trinket", 350))      # 0.35.1: ~45 4v4 wins or ~15 12v12 wins
    # 0.45: four tiers of PvP gear - (key, name prefix, rarity, level, wins needed, {slot: PvP Points}, power cap, power bonus over level x2)
    PVP_TIERS = (
        ("recruit", "Recruit's", "Rare", 10, 0, {"weapon": 150, "armor": 120, "helm": 90, "trinket": 90, "ring": 80, "ring2": 80}, 110, 8),
        ("glad", "Gladiator's", "Elite", 20, 0, {"weapon": 600, "armor": 500, "helm": 350, "trinket": 350, "ring": 300, "ring2": 300}, 150, 30),
        ("legend", "Legendary Gladiator's", "Legendary", 60, 25, {"weapon": 2400, "armor": 2000, "helm": 1500, "trinket": 1500, "ring": 1300, "ring2": 1300}, 182, 62),
        ("mythic", "Mythic Gladiator's", "Mythic", 90, 60, {"weapon": 6000, "armor": 5000, "helm": 4000, "trinket": 4000, "ring": 3500, "ring2": 3500}, 200, 95),
    )
    # 0.45: cheap War Hall supplies for PvP Points: (key, label, item, count, cost, level)
    PVP_SUPPLIES = (
        ("hp5", "Health Potion x5", "Health Potion", 5, 40, 1), ("mp5", "Mana Potion x5", "Mana Potion", 5, 40, 1),
        ("tp2", "Scroll of Teleportation x2", "Scroll of Teleportation", 2, 50, 1),
        ("crit", "Elixir of Deadly Aim x2", "Brew:Elixir of Deadly Aim", 2, 90, 25), ("def", "Elixir of Stoneguard x2", "Brew:Elixir of Stoneguard", 2, 90, 28),
        ("regen", "Potion of Regeneration x2", "Brew:Potion of Regeneration", 2, 70, 30), ("haste", "Potion of Swiftness x2", "Brew:Potion of Swiftness", 2, 60, 20),
        ("titan", "Elixir of the Titan x2", "Brew:Elixir of the Titan", 2, 220, 52), ("flask", "Flask of Supreme Power", "Brew:Flask of Supreme Power", 1, 600, 88),
        ("ess", "Legendary Essence", "@essence", 1, 450, 30),
    )
    UPGRADE_MAX = 5
    UPGRADE_RARITIES = ("Epic", "Elite", "Set", "Legendary")

    @staticmethod
    def _up_split(name):
        """'Foo Bar +3' -> ('Foo Bar', 3)."""
        m = re.search(r" \+(\d+)$", name or "")
        return ((name[:m.start()], int(m.group(1))) if m else (name, 0))

    def _pvp_piece_name(self, slot, tier="glad"):
        cls = self.class_name()
        pre = next((t[1] for t in self.PVP_TIERS if t[0] == tier), "Gladiator's")
        if slot == "ring2":                # 0.46: the second ring of the six-piece set always has its own name
            first = self.gear_word("ring", random.Random(f"{'glad' if tier == 'glad' else tier}{cls}ring"), cls)
            return pre + " " + next(w for w in ("Signet", "Band", "Loop") if w != first)
        return pre + " " + self.gear_word(slot, random.Random(f"{'glad' if tier == 'glad' else tier}{cls}{slot}"), cls)

    @staticmethod
    def _pvp_set_name(pre):
        return f"{pre} Battlegear"

    def _pvp_power(self, tier, slot):
        t = next(t for t in self.PVP_TIERS if t[0] == tier)
        lvl = self.player["level"]
        if tier == "mythic": return 196 + (8 if slot == "weapon" else 0)       # below the Mythic quest weapon (218)
        if slot == "ring2": slot = "ring"
        return min(t[6], lvl * 2 + t[7])

    def armory_view(self):
        if not self._near_station("warhall", 8):
            return None
        from .bonuses import btext, set_tiers
        p = self.player; c = self._currency(); cls = self.class_name()
        have = {self._up_split(r["item"])[0] for r in self.db.execute("SELECT item FROM player_gear").fetchall()}
        wins = self.pvp_status().get("wins", 0)
        pvp = []; tiers = []
        for tk, pre, rar, lvl_req, win_req, costs, cap, bonus in self.PVP_TIERS:
            rows = []
            for slot, cost in costs.items():
                item = self._pvp_piece_name(slot, tk); pw = self._pvp_power(tk, slot)
                why = "" if p["level"] >= lvl_req else f"Level {lvl_req}"
                if not why and wins < win_req: why = f"{win_req} wins ({wins})"
                rows.append({"key": f"pv:{tk}:{slot}", "item": item, "slot": "ring" if slot == "ring2" else slot, "cost": cost, "power": pw, "owned": item in have, "rarity": rar,
                             "why": why, "can": not why and c["pvp_points"] >= cost and item not in have, "set_name": self._pvp_set_name(pre),
                             "set_bonus": [f"{n} pieces: {btext(b)}" for n, b in sorted(set_tiers(self._pvp_set_name(pre), cls).items())]})
            tiers.append({"key": tk, "name": pre, "rarity": rar, "level": lvl_req, "wins": win_req, "rows": rows})
            if tk == "glad": pvp = rows
        sup = [{"key": f"su:{k}", "label": lab, "cost": cost, "level": lv, "can": p["level"] >= lv and c["pvp_points"] >= cost} for k, lab, it, n, cost, lv in self.PVP_SUPPLIES]
        try:
            from .mounts import MOUNTS, BG_ORDER
            st = self._mst()
            mts = [{"key": f"mt:{mid}", "id": mid, "name": MOUNTS[mid]["name"], "look": MOUNTS[mid]["look"], "tier": MOUNTS[mid]["tier"], "cost": MOUNTS[mid]["pvp"],
                    "wins": MOUNTS[mid]["wins"], "power": MOUNTS[mid]["power_text"], "speed": MOUNTS[mid]["speed"], "owned": mid in st["owned"],
                    "why": "" if wins >= MOUNTS[mid]["wins"] else f"{MOUNTS[mid]['wins']} wins ({wins})"} for mid in BG_ORDER]
            for m in mts: m["can"] = not m["owned"] and not m["why"] and c["pvp_points"] >= m["cost"]
        except Exception:
            mts = []
        ups = []
        for r in self.inventory_rows():
            if r["rarity"] not in self.UPGRADE_RARITIES:
                continue
            base, n = self._up_split(r["item"])
            if n >= self.UPGRADE_MAX:
                ups.append({"id": r["id"], "item": r["item"], "slot": r["slot"], "rarity": r["rarity"], "power": r["power"], "n": n, "maxed": True,
                            "ess": 0, "gold": 0, "can": False, "equipped": bool(r["equipped"])})
                continue
            ess = n + 1; gold = max(100, r["power"] * 20 * (n + 1)); tok = n + 1
            ups.append({"id": r["id"], "item": r["item"], "slot": r["slot"], "rarity": r["rarity"], "power": r["power"], "n": n, "maxed": False,
                        "ess": ess, "gold": gold, "tok": tok, "can": c["legendary_essence"] >= ess and c["raid_tokens"] >= tok and p["gold"] >= gold,
                        "equipped": bool(r["equipped"])})
        ups.sort(key=lambda u: (-int(u["equipped"]), -u["power"]))
        return {"pvp": pvp, "tiers": tiers, "supplies": sup, "mounts": mts, "wins": wins, "upgrades": ups[:8], "n_upgrades": len(ups), "cur": c,
                "gold": p["gold"], "level": p["level"], "cls": cls}

    def armory_buy(self, key):
        if not isinstance(key, str): return "Unknown item."
        v = self.armory_view()
        if v is None:
            return "Stand at the War Hall."
        p = self.player; c = v["cur"]; cls = v["cls"]
        if key.startswith("as:"):
            return "Raid gear cannot be bought. It drops from raid bosses."
        if key.startswith("pv:"):
            parts = key.split(":")
            tk, slot = (parts[1], parts[2]) if len(parts) == 3 else ("glad", parts[1])
            tier = next((t for t in v["tiers"] if t["key"] == tk), None)
            pc = next((x for x in tier["rows"] if x["key"] == f"pv:{tk}:{slot}"), None) if tier else None
            if not pc:
                return "Unknown piece."
            if pc["owned"]:
                return f"You already own {pc['item']}."
            if pc["why"]:
                return f"{pc['item']} needs {pc['why'].replace('Level', 'level')}."
            if c["pvp_points"] < pc["cost"]:
                return f"{pc['item']} costs {pc['cost']:,} PvP Points (you have {c['pvp_points']:,}). Win battlegrounds to earn more."
            self._add_currency(pvp=-pc["cost"])
            self._grant_gear(pc["item"], pc["slot"], pc["rarity"], pc["power"], "Armory", cls, pc["set_name"])
            self._save_player_fast()
            return f"Bought {pc['item']} (Power {pc['power']}) for {pc['cost']:,} PvP Points. Equip it from your Bag (I)."
        if key.startswith("su:"):
            row = next((r for r in self.PVP_SUPPLIES if r[0] == key[3:]), None)
            if not row: return "Unknown item."
            k, lab, item, n, cost, lv = row
            if p["level"] < lv: return f"{lab} needs level {lv}."
            if c["pvp_points"] < cost: return f"{lab} costs {cost} PvP Points (you have {c['pvp_points']})."
            self._add_currency(pvp=-cost)
            if item == "@essence": self._add_currency(essence=n)
            else:
                if item == "Health Potion": self._ensure_potions()
                self._inv_add(item, n)
            self.db.commit(); self._save_player_fast()
            return f"Bought {lab} for {cost} PvP Points."
        if key.startswith("mt:"):
            m = next((x for x in v["mounts"] if x["key"] == key), None)
            if not m: return "Unknown mount."
            if m["owned"]: return f"You already own the {m['name']}."
            if m["why"]: return f"The {m['name']} needs {m['why']}."
            if c["pvp_points"] < m["cost"]: return f"The {m['name']} costs {m['cost']:,} PvP Points (you have {c['pvp_points']:,})."
            self._add_currency(pvp=-m["cost"])
            st = self._mst(); st["owned"].append(m["id"]); st["active"] = m["id"]; self._mst_save(); self._save_player_fast()
            from .mounts import RIDING
            tail = "" if st["riding"] >= m["tier"] else f" You need {RIDING[m['tier']][0]} (Stable) to ride it."
            return f"The {m['name']} is yours! {m['power']} Press X to ride - it is allowed in battlegrounds.{tail}"
        return "Nothing to buy."

    def armory_upgrade(self, gear_id):
        v = self.armory_view()
        if v is None:
            return "Stand at the War Hall."
        r = self.db.execute("SELECT * FROM player_gear WHERE id=?", (gear_id,)).fetchone()
        if not r:
            return "Gear item not found."
        if r["rarity"] not in self.UPGRADE_RARITIES:
            return "Only Epic, Elite, Set and Legendary gear can be upgraded."
        base, n = self._up_split(r["item"])
        if n >= self.UPGRADE_MAX:
            return f"{r['item']} is already at its maximum (+{self.UPGRADE_MAX})."
        ess = n + 1; gold = max(100, r["power"] * 20 * (n + 1)); c = v["cur"]; p = self.player
        if c["legendary_essence"] < ess:
            return f"Upgrading to +{n + 1} needs {ess} Legendary Essence (you have {c['legendary_essence']}). Every full raid clear gives 1."
        if c["raid_tokens"] < ess:
            return f"Upgrading to +{n + 1} needs {ess} Raid Tokens (you have {c['raid_tokens']}). Every full raid clear gives 1."
        if p["gold"] < gold:
            return f"Upgrading to +{n + 1} costs {gold:,} gold."
        p["gold"] -= gold
        self._add_currency(essence=-ess, raid=-ess)
        newp = r["power"] + 6; name = f"{base} +{n + 1}"
        self.db.execute("UPDATE player_gear SET item=?, power=? WHERE id=?", (name, newp, gear_id))
        self.db.commit()
        if r["equipped"] and r["slot"] in ("weapon", "armor"):
            p[r["slot"]] = max(p[r["slot"]], newp)
        self._save_player_fast()
        return f"{base} upgraded to +{n + 1}: Power {r['power']} -> {newp} ({ess} Essence, {ess} Raid Tokens, {gold:,}g)."

    # ================================================================ 0.35 Banker vault
    # Gold in the vault is never lost when you die; gear in the vault leaves your Bag. Every Banker opens the same vault.
    VAULT_SLOTS = 200

    def _near_banker(self, r2=36):
        p = self.player
        return any(a.kind == "npc" and a.role == "banker" and (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2 <= r2 for a in self.actors)

    def vault_view(self):
        if self.inst or not self._near_banker(64):
            return None
        rows = [dict(r) for r in self.db.execute("SELECT id,slot,item,rarity,power,class,set_name FROM player_gear WHERE vault=1 ORDER BY slot,power DESC,id DESC").fetchall()]
        bag = [r for r in self.inventory_rows() if not r["equipped"]]
        return {"gold": self.player["gold"], "vault_gold": self._currency().get("vault_gold", 0), "bag": bag, "vault": rows, "cap": self.VAULT_SLOTS}

    def vault_gold(self, amount):
        """amount > 0 deposits, < 0 withdraws; 'all' / '-all' moves everything."""
        if self.vault_view() is None:
            return "Visit a Bank to use your vault."
        p = self.player; vg = self._currency().get("vault_gold", 0)
        if amount in ("all", "-all"):
            amount = p["gold"] if amount == "all" else -vg
        amount = int(amount)
        if amount > 0:
            amount = min(amount, p["gold"])
            if amount <= 0:
                return "You carry no gold to deposit."
            p["gold"] -= amount; msg = f"Deposited {amount:,}g. Vault: {vg + amount:,}g, carried: {p['gold']:,}g."
        elif amount < 0:
            amount = -min(-amount, vg)
            if amount == 0:
                return "Your vault holds no gold."
            p["gold"] -= amount; msg = f"Withdrew {-amount:,}g. Vault: {vg + amount:,}g, carried: {p['gold']:,}g."
        else:
            return ""
        self.db.execute("UPDATE player_currency SET vault_gold=vault_gold+? WHERE name=?", (amount, p["name"]))
        self._save_player_fast()            # saves carried gold and commits both in one go
        return msg

    def vault_store(self, gear_id):
        if self.vault_view() is None:
            return "Visit a Bank to use your vault."
        r = self.db.execute("SELECT * FROM player_gear WHERE id=?", (gear_id,)).fetchone()
        if not r or r["vault"]:
            return "That item is not in your Bag."
        if r["equipped"]:
            return f"Take off {r['item']} before storing it."
        n = self.db.execute("SELECT COUNT(*) FROM player_gear WHERE vault=1").fetchone()[0]
        if n >= self.VAULT_SLOTS:
            return f"Your vault is full ({self.VAULT_SLOTS} items)."
        self.db.execute("UPDATE player_gear SET vault=1 WHERE id=?", (gear_id,)); self.db.commit()
        return f"Stored {r['item']} in your vault."

    def vault_take(self, gear_id):
        if self.vault_view() is None:
            return "Visit a Bank to use your vault."
        r = self.db.execute("SELECT * FROM player_gear WHERE id=?", (gear_id,)).fetchone()
        if not r or not r["vault"]:
            return "That item is not in your vault."
        self.db.execute("UPDATE player_gear SET vault=0 WHERE id=?", (gear_id,)); self.db.commit()
        return f"Took {r['item']} from your vault."


def p_lvl_ok(w, b):
    return w.player["level"] >= b["lvl"]
