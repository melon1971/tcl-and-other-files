"""LiveWorld RPG 0.44 - elixirs, flasks and potions (data only; the effects live in engine.py / rpg.py).

Every brew is made from the herb and the fish of ONE zone band, so a higher zone means a better recipe:
band 0 Meadow Clover + Meadow Trout ... band 9 Voidlotus + Void Angler.  Extra Cloth, Leather, Arcane Dust
and Spirit Essence make the stronger ones.  Brews are drunk with Y (next unused one) or from the bag screen.
"""
HERB_NAMES = ["Meadow Clover", "Ironwood Sage", "Frostpetal", "Stormkelp", "Fenbloom", "Crownleaf", "Duskmoss", "Sunthistle", "Emberroot", "Voidlotus"]
FISH_NAMES = ["Meadow Trout", "Ironwood Pike", "Frost Char", "Storm Mackerel", "Fen Eel", "Crown Carp", "Dusk Catfish", "Sun Perch", "Ember Koi", "Void Angler"]
CLOTH, LEATHER, DUST, ESS = "Mat:Cloth Scrap", "Mat:Leather Scrap", "Mat:Arcane Dust", "Mat:Spirit Essence"

# name, buff kind, value, seconds, level, extra materials, effect text, category
_DEFS = [
    ("Elixir of Sharp Eyes", "crit", .03, 600, 5, {}, "+3% critical strike chance for 10 minutes", "Critical strike"),
    ("Elixir of Deadly Aim", "crit", .05, 600, 25, {DUST: 1}, "+5% critical strike chance for 10 minutes", "Critical strike"),
    ("Elixir of the Mongoose", "crit", .08, 600, 45, {DUST: 2}, "+8% critical strike chance for 10 minutes", "Critical strike"),
    ("Elixir of Lethality", "crit", .12, 600, 70, {DUST: 3}, "+12% critical strike chance for 10 minutes", "Critical strike"),
    ("Elixir of the Void Hunter", "crit", .16, 600, 90, {DUST: 4, ESS: 1}, "+16% critical strike chance for 10 minutes", "Critical strike"),
    ("Elixir of Ironskin", "def", .05, 600, 8, {LEATHER: 2}, "5% less damage taken for 10 minutes", "Defense"),
    ("Elixir of Stoneguard", "def", .09, 600, 28, {LEATHER: 3}, "9% less damage taken for 10 minutes", "Defense"),
    ("Elixir of the Titan", "def", .14, 600, 52, {LEATHER: 4, DUST: 2}, "14% less damage taken for 10 minutes", "Defense"),
    ("Elixir of the Unbroken", "def", .20, 600, 78, {LEATHER: 5, DUST: 3}, "20% less damage taken for 10 minutes", "Defense"),
    ("Elixir of Nimble Feet", "evade", .05, 600, 12, {CLOTH: 2}, "+5% chance to dodge attacks for 10 minutes", "Dodge"),
    ("Elixir of Shadow Dancing", "evade", .10, 600, 45, {CLOTH: 3}, "+10% chance to dodge attacks for 10 minutes", "Dodge"),
    ("Elixir of the Phantom", "evade", .16, 600, 80, {CLOTH: 4, DUST: 2}, "+16% chance to dodge attacks for 10 minutes", "Dodge"),
    ("Lesser Invisibility Potion", "stealth", 1, 30, 15, {CLOTH: 1}, "Invisible for 30 s: monsters only notice you at point-blank range. Attacking breaks it", "Invisibility"),
    ("Invisibility Potion", "stealth", 1, 60, 40, {CLOTH: 2, DUST: 1}, "Invisible for 60 s. Attacking breaks it", "Invisibility"),
    ("Greater Invisibility Potion", "stealth", 1, 120, 70, {CLOTH: 3, DUST: 2}, "Invisible for 2 minutes. Attacking breaks it", "Invisibility"),
    ("Elixir of Giants", "e_str", 12, 900, 10, {}, "+12 Strength for 15 minutes", "Stats"),
    ("Greater Elixir of Giants", "e_str", 35, 900, 55, {DUST: 2}, "+35 Strength for 15 minutes", "Stats"),
    ("Elixir of Agility", "e_agi", 12, 900, 10, {}, "+12 Agility for 15 minutes", "Stats"),
    ("Greater Elixir of Agility", "e_agi", 35, 900, 55, {DUST: 2}, "+35 Agility for 15 minutes", "Stats"),
    ("Elixir of the Sages", "e_int", 12, 900, 10, {}, "+12 Intellect for 15 minutes", "Stats"),
    ("Greater Elixir of the Sages", "e_int", 35, 900, 55, {DUST: 2}, "+35 Intellect for 15 minutes", "Stats"),
    ("Elixir of Vigor", "e_vit", 12, 900, 10, {}, "+12 Vitality for 15 minutes", "Stats"),
    ("Greater Elixir of Vigor", "e_vit", 35, 900, 55, {DUST: 2}, "+35 Vitality for 15 minutes", "Stats"),
    ("Potion of Swiftness", "haste", .20, 180, 20, {CLOTH: 1}, "+20% run speed for 3 minutes", "Utility"),
    ("Draught of Wisdom", "mreg", .8, 600, 25, {}, "+80% mana regeneration for 10 minutes", "Utility"),
    ("Potion of Regeneration", "regen", .02, 30, 30, {}, "Recover 2% health per second for 30 s, even in combat", "Utility"),
    ("Major Regeneration Potion", "regen", .035, 30, 60, {DUST: 1}, "Recover 3.5% health per second for 30 s, even in combat", "Utility"),
    ("Flask of the Titans", "hpmax", .20, 900, 85, {LEATHER: 4, DUST: 4, ESS: 1}, "+20% maximum health for 15 minutes", "Flasks"),
    ("Flask of Supreme Power", "might", .25, 900, 88, {DUST: 4, ESS: 1}, "+25% damage for 15 minutes", "Flasks"),
]


def _build():
    out = []
    for name, kind, val, dur, lvl, extra, desc, cat in _DEFS:
        band = min(9, (lvl - 1) // 10)
        needs = [("Herb:" + HERB_NAMES[band], 2 + lvl // 40), ("Fish:" + FISH_NAMES[band], 1 + lvl // 35)] + list(extra.items())
        out.append({"key": "br:" + name, "name": name, "kind": kind, "value": val, "dur": dur, "lvl": lvl, "band": band, "needs": needs,
                    "gold": 4 * lvl, "desc": desc, "cat": cat, "n": 1 if cat == "Flasks" else 2, "price": 14 + lvl * 3})
    return out


BREWS = _build()
BY_KEY = {b["key"]: b for b in BREWS}
BY_NAME = {b["name"]: b for b in BREWS}
