"""Jewelcrafting (0.39): jewels, rings and necklaces, and socketed gear.

* Jewels are cut at a Jeweler's Kiln (in every town) from Iron Ore, Arcane Dust and gold.  Five gems,
  each in five qualities that unlock with your level.
* Any piece of gear can be socketed at the kiln: up to 3 sockets, each costing materials, gold and a level.
  Setting a jewel into a socket adds its bonus while the gear is worn; taking it out again destroys the jewel.
* The kiln also makes rings and necklaces from a jewel.  You wear one necklace (the old trinket slot)
  and two rings; a ring or necklace gives its gem's bonus.
"""
import json

GEMS = {"Ruby": ("str", "Strength"), "Emerald": ("agi", "Agility"), "Sapphire": ("int", "Intellect"),
        "Topaz": ("vit", "Vitality"), "Diamond": ("crit", "critical strike chance"),
        "Onyx": ("dodge", "chance to dodge"), "Jade": ("armor_pct", "less damage taken"),
        "Opal": ("mana_regen", "mana regeneration"), "Amber": ("hp_pct", "maximum health")}
GEM_ORDER = ("Ruby", "Emerald", "Sapphire", "Topaz", "Diamond", "Onyx", "Jade", "Opal", "Amber")
QUALITIES = (("Chipped", 1, 2), ("Flawed", 15, 4), ("Clean", 30, 7), ("Flawless", 50, 11), ("Perfect", 75, 16), ("Radiant", 90, 24))   # name, level, points
QUALITY_RARITY = ("Uncommon", "Rare", "Epic", "Elite", "Legendary", "Legendary")
PCT_STATS = {"crit": .0012, "dodge": .0010, "armor_pct": .0010, "mana_regen": .008, "hp_pct": .0008}      # value per point
MAX_SOCKETS = 3
# (level, Iron Ore, Arcane Dust, Spirit Essence, gold) to open the 1st, 2nd and 3rd socket in a piece of gear
SOCKET_COSTS = ((10, 8, 2, 0, 250), (30, 20, 6, 1, 1500), (55, 40, 15, 3, 6000))
RING_WORDS = ("Band", "Ring", "Signet", "Loop", "Circlet Ring")
JEWELRY_SLOTS = ("ring", "trinket")


def jewel_key(quality, gem):
    return f"Jewel:{quality} {gem}"


def parse_jewel(name):
    """'Clean Ruby' -> (quality index, gem) or None."""
    if not isinstance(name, str): return None
    parts = name.split()
    if len(parts) != 2 or parts[1] not in GEMS: return None
    qi = next((i for i, q in enumerate(QUALITIES) if q[0] == parts[0]), None)
    return None if qi is None else (qi, parts[1])


def jewel_bonus(name, mult=1.0):
    """{stat: value} that a jewel (or a jewel-made ring/necklace, with mult) gives."""
    pj = parse_jewel(name)
    if not pj: return {}
    qi, gem = pj; stat = GEMS[gem][0]; pts = QUALITIES[qi][2] * mult
    return {stat: pts * PCT_STATS[stat]} if stat in PCT_STATS else {stat: int(round(pts))}


def bonus_text(b):
    out = []
    for k, v in b.items():
        nm = dict((s, n) for s, n in GEMS.values())[k] if k in dict((s, n) for s, n in GEMS.values()) else k
        out.append(f"+{v * 100:.1f}% {'critical strike' if k == 'crit' else nm}" if k in PCT_STATS else f"+{v} {nm}")
    return ", ".join(out)


def jewelry_bonus(item, slot):
    """Rings and necklaces made at the kiln are named '<Quality> <Gem> Ring/Pendant' and carry that gem's bonus
    (rings 1.5x, necklaces 2x).  Found rings without a gem in the name have no innate bonus - socket them instead."""
    if slot not in JEWELRY_SLOTS: return {}
    w = (item or "").split()
    if len(w) < 3: return {}
    b = jewel_bonus(" ".join(w[:2]), 1.5 if slot == "ring" else 2.0)
    pj = parse_jewel(" ".join(w[:2]))
    if b and pj and pj[0] >= 3 and "vit" not in b:          # 0.44: Flawless and better jewelry also adds Vitality
        b["vit"] = int(QUALITIES[pj[0]][2] * (.6 if slot == "ring" else .9))
    return b


def cut_cost(qi):
    """(Iron Ore, Arcane Dust, gold) to cut one jewel of quality qi."""
    return 2 + qi * 2, qi, 20 * (qi + 1) ** 2


def jewelry_cost(qi):
    """(Iron Ore, gold) - plus the jewel itself - for a ring or necklace of quality qi."""
    return 3 + qi * 2, 50 * (qi + 1) ** 2


class JewelMixin:
    # ---------------------------------------------------------------- storage
    def _jewel_schema(self):
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(player_gear)").fetchall()}
        if "sockets" not in cols:
            self.db.execute("ALTER TABLE player_gear ADD COLUMN sockets INTEGER DEFAULT -1")
        if "gems" not in cols:
            self.db.execute("ALTER TABLE player_gear ADD COLUMN gems TEXT DEFAULT '[]'")
        self.db.execute("UPDATE player_gear SET sockets=0 WHERE sockets<0")     # sockets are opened at the kiln
        self._raise_gear_power()
        self.db.commit()

    def _raise_gear_power(self):
        """0.44: raid set gear is the best non-Mythic gear and the Mythic weapon beats everything. Lift older drops once."""
        import re
        from .rpg import MYTHIC_POWER
        for r in self.db.execute("SELECT id,item,slot,rarity,power,source FROM player_gear WHERE rarity IN ('Set','Mythic')").fetchall():
            if r["rarity"] == "Mythic":
                floor = MYTHIC_POWER
            elif "Raid" in (r["source"] or ""):
                m = re.search(r" \+(\d+)$", r["item"] or "")
                floor = (168 if r["slot"] == "weapon" else 176) + 6 * (int(m.group(1)) if m else 0)
            else:
                continue
            if r["power"] < floor:
                self.db.execute("UPDATE player_gear SET power=? WHERE id=?", (floor, r["id"]))

    def _gems_of(self, row):
        try: g = json.loads(row["gems"] or "[]")
        except (ValueError, TypeError): g = []
        return [x for x in g if isinstance(x, str)] if isinstance(g, list) else []

    # ---------------------------------------------------------------- what worn jewels give
    def gear_stats(self):
        """Stat bonuses from worn rings, necklace and socketed jewels: {'str','agi','int','vit','crit'}."""
        key = (self.tick, getattr(self, "_gear_ver", 0))
        c = getattr(self, "_gear_stats_c", None)
        if c and c[0] == key: return c[1]
        out = {"str": 0, "agi": 0, "int": 0, "vit": 0, "crit": 0.0, "dodge": 0.0, "armor_pct": 0.0, "mana_regen": 0.0, "hp_pct": 0.0}
        for r in self.db.execute("SELECT item,slot,gems FROM player_gear WHERE equipped>0 AND vault=0").fetchall():
            for b in [jewelry_bonus(r["item"], r["slot"])] + [jewel_bonus(g) for g in self._gems_of(r)]:
                for k, v in b.items(): out[k] += v
        for k, v in self.bonus_stats().items():        # 0.46: Magic Shop bonuses, set bonuses, Mythic gear and the Mythic oath
            out[k] = out.get(k, 0) + v
        self._gear_stats_c = (key, out)
        return out

    def _gear_changed(self):
        self._gear_ver = getattr(self, "_gear_ver", 0) + 1

    def stats(self):
        """Your Strength, Agility, Intellect and Vitality: spent stat points plus worn jewels."""
        s = dict(self._build()["s"]); g = self.gear_stats()
        for k in ("str", "agi", "int", "vit"):
            eb = self._buff("e_" + k) if hasattr(self, "_buff") else None
            s[k] = s.get(k, 0) + g[k] + (eb["value"] if eb else 0)
        return s

    # ---------------------------------------------------------------- the kiln
    def at_kiln(self):
        return self._near_station("kiln", 6.5)

    def jewel_counts(self):
        rows = self.db.execute("SELECT item,qty FROM inventory WHERE actor_id=0 AND item LIKE 'Jewel:%' AND qty>0").fetchall()
        return {r["item"][6:]: r["qty"] for r in rows}

    def kiln_view(self):
        lvl = self.player["level"]; ore = self._inv_qty("Mat:Iron Ore"); dust = self._inv_qty("Mat:Arcane Dust"); gold = self.player["gold"]
        have = self.jewel_counts()
        cuts = []
        for qi, (q, need, pts) in enumerate(QUALITIES):
            o, d, g = cut_cost(qi)
            for gem in GEM_ORDER:
                why = (f"Level {need}" if lvl < need else f"Need {o} Iron Ore" if ore < o else f"Need {d} Arcane Dust" if dust < d
                       else f"Need {g} gold" if gold < g else "")
                cuts.append({"key": f"{q} {gem}", "quality": q, "gem": gem, "qi": qi, "ore": o, "dust": d, "gold": g, "can": not why, "why": why,
                             "have": have.get(f"{q} {gem}", 0), "bonus": bonus_text(jewel_bonus(f"{q} {gem}")), "locked": lvl < need})
        jewelry = []
        for qi, (q, need, pts) in enumerate(QUALITIES):
            o, g = jewelry_cost(qi)
            for gem in GEM_ORDER:
                for slot, word in (("ring", "Ring"), ("trinket", "Pendant")):
                    nm = f"{q} {gem} {word}"
                    why = (f"Level {need}" if lvl < need else f"Need a {q} {gem}" if not have.get(f"{q} {gem}") else
                           f"Need {o} Iron Ore" if ore < o else f"Need {g} gold" if gold < g else "")
                    jewelry.append({"key": f"{slot}|{q} {gem}", "name": nm, "slot": slot, "qi": qi, "ore": o, "gold": g, "can": not why, "why": why,
                                    "bonus": bonus_text(jewelry_bonus(nm, slot)), "locked": lvl < need, "rarity": QUALITY_RARITY[qi]})
        gear = []
        ess = self._inv_qty("Mat:Spirit Essence")
        for r in self.db.execute("SELECT id,slot,item,rarity,power,equipped,sockets,gems FROM player_gear WHERE vault=0 ORDER BY equipped DESC,power DESC,id DESC").fetchall():
            n = max(0, r["sockets"]); nxt = None
            if n < MAX_SOCKETS:
                lv, o, d, e, g = SOCKET_COSTS[n]
                why = (f"Level {lv}" if lvl < lv else f"Need {o} Iron Ore" if ore < o else f"Need {d} Arcane Dust" if dust < d
                       else f"Need {e} Spirit Essence" if ess < e else f"Need {g:,} gold" if gold < g else "")
                nxt = {"level": lv, "ore": o, "dust": d, "essence": e, "gold": g, "can": not why, "why": why}
            gear.append({"id": r["id"], "item": r["item"], "slot": r["slot"], "rarity": r["rarity"], "power": r["power"], "equipped": bool(r["equipped"]),
                         "sockets": n, "gems": self._gems_of(r), "next": nxt})
        return {"ok": self.at_kiln(), "gold": gold, "ore": ore, "dust": dust, "essence": ess, "jewels": have, "cuts": cuts, "jewelry": jewelry, "gear": gear}

    def _kiln_check(self):
        return "" if self.at_kiln() else "Stand at a Jeweler's Kiln (next to the Jeweler, in every town)."

    def cut_jewel(self, key):
        no = self._kiln_check()
        if no: return no
        pj = parse_jewel(key)
        if not pj: return "Unknown jewel."
        qi, gem = pj; q, need, _ = QUALITIES[qi]
        if self.player["level"] < need: return f"{q} jewels need level {need}."
        o, d, g = cut_cost(qi)
        if self._inv_qty("Mat:Iron Ore") < o: return f"You need {o} Iron Ore."
        if self._inv_qty("Mat:Arcane Dust") < d: return f"You need {d} Arcane Dust."
        if self.player["gold"] < g: return f"You need {g} gold."
        self._inv_add("Mat:Iron Ore", -o)
        if d: self._inv_add("Mat:Arcane Dust", -d)
        self.player["gold"] -= g; self._inv_add(jewel_key(q, gem), 1); self.db.commit(); self._save_player_fast()
        return f"You cut a {q} {gem} ({bonus_text(jewel_bonus(key))})."

    def craft_jewelry(self, key):
        no = self._kiln_check()
        if no: return no
        slot, _, jw = (key if isinstance(key, str) else "").partition("|")
        pj = parse_jewel(jw)
        if slot not in JEWELRY_SLOTS or not pj: return "Unknown recipe."
        qi, gem = pj; q, need, _ = QUALITIES[qi]
        if self.player["level"] < need: return f"{q} jewelry needs level {need}."
        if self.jewel_counts().get(jw, 0) < 1: return f"You need a {jw} - cut one first."
        o, g = jewelry_cost(qi)
        if self._inv_qty("Mat:Iron Ore") < o: return f"You need {o} Iron Ore."
        if self.player["gold"] < g: return f"You need {g} gold."
        self._inv_add("Mat:Iron Ore", -o); self._inv_add(jewel_key(q, gem), -1); self.player["gold"] -= g
        name = f"{q} {gem} {'Ring' if slot == 'ring' else 'Pendant'}"
        power = 10 + self.player["level"] + qi * 12
        self._grant_gear(name, slot, QUALITY_RARITY[qi], power, "Jeweler's Kiln")
        self._save_player_fast()
        return f"You craft a {name} ({bonus_text(jewelry_bonus(name, slot))}). Find it in your bag (I)."

    def add_socket(self, gear_id):
        """Open one more socket (up to 3) in any piece of gear: materials, gold and a level for each."""
        no = self._kiln_check()
        if no: return no
        r = self.db.execute("SELECT * FROM player_gear WHERE id=?", (gear_id,)).fetchone()
        if not r or r["vault"]: return "That gear is not in your bag."
        n = max(0, r["sockets"])
        if n >= MAX_SOCKETS: return f"{r['item']} already has {MAX_SOCKETS} sockets."
        lv, o, d, e, g = SOCKET_COSTS[n]
        if self.player["level"] < lv: return f"Opening socket {n + 1} needs level {lv}."
        for mat, q in (("Mat:Iron Ore", o), ("Mat:Arcane Dust", d), ("Mat:Spirit Essence", e)):
            if q and self._inv_qty(mat) < q: return f"Socket {n + 1} needs {q} {mat[4:]}."
        if self.player["gold"] < g: return f"Socket {n + 1} costs {g:,} gold."
        for mat, q in (("Mat:Iron Ore", o), ("Mat:Arcane Dust", d), ("Mat:Spirit Essence", e)):
            if q: self._inv_add(mat, -q)
        self.player["gold"] -= g
        self.db.execute("UPDATE player_gear SET sockets=? WHERE id=?", (n + 1, gear_id)); self.db.commit(); self._save_player_fast()
        return f"The jeweler opens socket {n + 1} in {r['item']}."

    def socket_jewel(self, gear_id, jewel):
        no = self._kiln_check()
        if no: return no
        r = self.db.execute("SELECT * FROM player_gear WHERE id=?", (gear_id,)).fetchone()
        if not r or r["vault"]: return "That gear is not in your bag."
        gems = self._gems_of(r)
        if len(gems) >= max(0, r["sockets"]): return f"{r['item']} has no free socket."
        if not parse_jewel(jewel) or self.jewel_counts().get(jewel, 0) < 1: return f"You have no {jewel}."
        cost = 10 + 15 * parse_jewel(jewel)[0]
        if self.player["gold"] < cost: return f"Setting it costs {cost} gold."
        self.player["gold"] -= cost; self._inv_add(f"Jewel:{jewel}", -1); gems.append(jewel)
        self.db.execute("UPDATE player_gear SET gems=? WHERE id=?", (json.dumps(gems), gear_id)); self.db.commit()
        self._gear_changed(); self._save_player_fast()
        return f"{jewel} set into {r['item']} ({bonus_text(jewel_bonus(jewel))})."

    def unsocket_jewel(self, gear_id, index):
        no = self._kiln_check()
        if no: return no
        r = self.db.execute("SELECT * FROM player_gear WHERE id=?", (gear_id,)).fetchone()
        if not r: return "That gear is not in your bag."
        gems = self._gems_of(r)
        if not (0 <= int(index) < len(gems)): return "That socket is empty."
        gone = gems.pop(int(index))
        self.db.execute("UPDATE player_gear SET gems=? WHERE id=?", (json.dumps(gems), gear_id)); self.db.commit()
        self._gear_changed()
        return f"The {gone} shatters as it is pried out of {r['item']}. The socket is free."
