#!/usr/bin/env python3
"""liveworld-create-character NAME Alliance|Horde CLASS [SPEC]"""
import sys
CLASSES=("Warrior","Ranger","Mage","Cleric","Rogue","Paladin","Shaman","Druid","Berserker","Warlock","Monk","Juggernaut")
def main():
 from . import engine
 name=sys.argv[1] if len(sys.argv)>1 else input("Character name: ").strip()
 faction=sys.argv[2] if len(sys.argv)>2 else input("Faction (Alliance/Horde): ").strip().title()
 class_name=sys.argv[3] if len(sys.argv)>3 else input("Class (%s): "%"/".join(CLASSES)).strip().title()
 spec=sys.argv[4] if len(sys.argv)>4 else None
 if not name or faction not in ("Alliance","Horde") or class_name not in CLASSES:
  print("Usage: liveworld-create-character NAME Alliance|Horde [%s] [Tank|Healer|DPS spec]"%"|".join(CLASSES)); return 2
 lock=engine.acquire_instance_lock()
 if lock is None:
  print("LiveWorld RPG is running. Close the game first, then run this again."); return 1
 w,msg=engine.open_world()
 if msg:print(msg)
 try:
  if w.character_created() if hasattr(w,"character_created") else False:
   w.set_class(class_name,spec) if hasattr(w,"set_class") else None
   # 0.34.2: an existing hero keeps its name and faction - say so instead of claiming they changed
   print(f"{w.player['name']} already exists ({w.player['faction']}); class changed to {class_name}.")
  else:
   w.create_character(name,faction,class_name,spec)
   print(f"Offline character set to {w.player['name']} ({w.player['faction']}, {class_name}).")
 finally:
  w.close()
 return 0
if __name__=="__main__": raise SystemExit(main())
