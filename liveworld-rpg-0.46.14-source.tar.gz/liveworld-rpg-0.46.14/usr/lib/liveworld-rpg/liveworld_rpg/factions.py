"""LiveWorld RPG 0.35 faction war, mixed into engine.World.

* every town belongs to the Alliance or the Horde; the other side is not welcome there (this holds in mixed zones too, 0.42)
* walking into an enemy town brings out its City Watch (soldiers that hunt you until you leave)
* the whole CAPITAL ZONE of a side (Greenfields, Ashen Vale) is hostile ground: the enemy's Watch hunts you anywhere inside it
* shopkeepers, quest givers, Bankers and the service buildings of an enemy town refuse you
* computer adventurers live, rest and respawn only in their own towns and are turned back at enemy walls
* city raids are faction wars: a Horde warband raids an Alliance city and the other way round
"""
import math

SIDES = ("Alliance", "Horde")
SOLDIER_CLASSES = ("Warrior", "Paladin", "Ranger", "Juggernaut", "Berserker", "Rogue")
WATCH_CLASSES = ("Warrior", "Paladin", "Juggernaut")
SOLDIER_ROLES = ("raider", "watch")
WARLORDS = {"Horde": "Warlord Grakk the Sacker", "Alliance": "High Marshal Aldren Vane"}


def other_side(f):
    return "Horde" if f == "Alliance" else "Alliance"


class FactionMixin:
    WATCH_N = 4                 # City Watch soldiers on you at once
    WATCH_EVERY = 24            # a fresh soldier every 6 s while fewer than WATCH_N are alive

    # ---------------------------------------------------------------- towns
    def enemy_town_at(self, x, y, faction, r=None):
        """The enemy town whose walls (x, y) is inside, or None."""
        from . import engine as E
        r = E.TOWN_WALL_R + 1 if r is None else r
        for t in self.towns:
            if self.hostile_town(t, faction) and (t.x - x) ** 2 + (t.y - y) ** 2 < r * r:
                return t
        return None

    def hostile_town(self, t, faction):
        """A town of the other side is hostile to you, whichever zone it stands in."""
        return t.faction in SIDES and t.faction != faction

    def capital_zone_town(self, x, y, faction):
        """Inside the other side's capital zone (anywhere, not just in a town): the nearest town of that zone, else None."""
        from . import engine as E
        for a in E.AREAS:
            if a[5] in SIDES and a[5] != faction and a[1] <= x < a[1] + a[3] and a[2] <= y < a[2] + a[4]:
                zt = [t for t in self.towns if t.area == a[0]]
                return min(zt, key=lambda t: (t.x - x) ** 2 + (t.y - y) ** 2) if zt else None
        return None

    def friendly_to(self, t, faction):
        return not self.hostile_town(t, faction)

    def refuse_service(self, n):
        """'' if this town NPC serves you, else what they say instead."""
        if n.role == "merchant":                        # caravan merchants trade with everyone
            return ""
        t = self._town_for_actor(n); f = self.player["faction"]
        if t is None or self.friendly_to(t, f):
            return ""
        return f"{n.name} glares at you. \"We do not serve the {f} in {t.name}. Leave before the Watch finds you.\""

    # ---------------------------------------------------------------- soldiers (City Watch and raid warbands)
    def _soldier(self, aid, name, faction, lvl, x, y, hp, role, look):
        from .engine import Actor
        a = Actor(aid, name, faction, lvl, x, y, hp, hp, "monster", role, "hunt", -1, self.area(x, y)[0], 0)
        a.look = look; a.warlord = False; a.scale = 1.0
        # drawn as a faction soldier (the battleground look): class, team colour, role
        a.pvp = True; a.cls = self.rng.choice(WATCH_CLASSES if role == "watch" else SOLDIER_CLASSES); a.rrole = "DPS"
        a.team = "blue" if faction == self.player["faction"] else "red"
        a.dead = False; a.has_flag = False
        return a

    def _soldier_gone(self, a):
        a.gone = True
        if a in self.actors: self.actors.remove(a)
        self.by_id.pop(a.id, None); self.mstatus.pop(a.id, None)
        w = getattr(self, "watch", None)
        if w and a.id in w["ids"]: w["ids"].remove(a.id)

    def _spawn_point(self, t, rmin, rmax):
        ok = getattr(self, "terrain_ok", None)
        for _ in range(12):
            ang = self.rng.uniform(0, 6.283); d = self.rng.uniform(rmin, rmax)
            x, y = t.x + math.cos(ang) * d, t.y + math.sin(ang) * d
            if ok is None or ok(x, y):
                return x, y
        return t.x + 1.5, t.y + 1.5

    # ---------------------------------------------------------------- City Watch
    def _watch_tick(self):
        from . import engine as E
        p = self.player; w = getattr(self, "watch", None)
        t = None if self.inst else self.enemy_town_at(p["x"], p["y"], p["faction"])
        zt = None if (self.inst or t is not None) else self.capital_zone_town(p["x"], p["y"], p["faction"])
        wt = next((x for x in self.towns if x.id == w["town"]), None) if w else None
        if zt is not None:
            t = wt if (wt is not None and wt.area == zt.area) else zt      # the enemy capital zone: its Watch hunts you anywhere
        if w:
            gone = self.inst or wt is None or (zt is None and (wt.x - p["x"]) ** 2 + (wt.y - p["y"]) ** 2 > (E.TOWN_WALL_R + 10) ** 2)
            if gone or (t is not None and t.id != w["town"]):
                self._watch_clear()
                w = None
            elif t is None:
                return                                   # just outside the walls: the soldiers still chase, none join
        if t is None:
            return
        if w is None:
            w = self.watch = {"town": t.id, "ids": [], "next": self.tick}
            tier = self.town_tier(t) if hasattr(self, "town_tier") else "town"
            self.events.append(f"You entered the {t.faction} {tier} of {t.name}. The City Watch is coming for you!" if zt is None else f"You are in {t.faction} capital land. {t.name}'s City Watch is coming for you!")
        w["ids"] = [i for i in w["ids"] if i in self.by_id and self.by_id[i].hp > 0]
        ar = self.area(t.x, t.y)
        n_watch = self.WATCH_N + ar[7] // 20                # 0.42: a level 100 city fields 9 watchmen at once, a starter village 4
        if len(w["ids"]) < n_watch and self.tick >= w["next"]:
            lvl = ar[7] + 3                                # 0.42: the Watch is tuned to its town's band, so a high-level hero can wipe a low-level town
            hp = int((45 + lvl * 8) * (3 + ar[7] // 33))       # and the high-level ones are much tougher
            x, y = self._spawn_point(t, 5, 11)
            aid = 90000 + (self.tick * 7 + len(w["ids"])) % 9000
            while aid in self.by_id: aid += 1
            look = "Orc" if t.faction == "Horde" else "Dark Knight"
            a = self._soldier(aid, f"{t.name} Watchman", t.faction, lvl, x, y, hp, "watch", look)
            self.actors.append(a); self.by_id[a.id] = a; w["ids"].append(a.id)
            self._aggro(a)
            w["next"] = self.tick + self.WATCH_EVERY

    def _watch_clear(self):
        w = getattr(self, "watch", None)
        if not w: return
        for i in list(w["ids"]):
            a = self.by_id.get(i)
            if a: self._soldier_gone(a)
        self.watch = None

    # ---------------------------------------------------------------- computer adventurers keep to their own side
    def _keep_out_of_enemy_towns(self):
        """Adventurers that wandered inside enemy walls are turned back outside (raid attackers excepted)."""
        from . import engine as E
        R = E.TOWN_WALL_R
        for t in self.towns:
            if t.faction not in SIDES: continue
            for a in self.actors:
                if a.kind != "adventurer" or a.faction == t.faction or a.hp <= 0: continue
                dx, dy = a.x - t.x, a.y - t.y; d2 = dx * dx + dy * dy
                if d2 >= R * R: continue
                if a.state in ("town", "rest", "idle", "shop") or d2 < (R * .6) ** 2:
                    self._person_respawn(a, count=False)       # never living there: back home
                else:
                    d = math.sqrt(d2) or 1
                    a.x, a.y = t.x + dx / d * (R + 2.5), t.y + dy / d * (R + 2.5); a.gx = None
                    if hasattr(a, "task_until"): a.task_until = 0

    def _leave_enemy_town_on_load(self):
        """0.35: an old save that stopped inside what is now an enemy town wakes in the nearest town of its own side."""
        p = self.player
        if self.inst or not self.character_created() or not self.enemy_town_at(p["x"], p["y"], p["faction"]):
            return
        own = [t for t in self.towns if self.friendly_to(t, p["faction"])] or self.towns
        t = min(own, key=lambda t: (t.x - p["x"]) ** 2 + (t.y - p["y"]) ** 2)
        p["x"], p["y"] = t.x + 1.5, t.y + 1.5
        self.events.append(f"That is enemy capital ground. You wake in {t.name}.")
        self._save_player_fast()

    def _faction_tick(self):
        self._watch_tick()
        if self.tick % 20 == 0: self._keep_out_of_enemy_towns()
