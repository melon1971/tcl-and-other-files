"""LiveWorld RPG 0.44 - recruiting: click an adventurer (or a guard) and ask them to join your party.

* The person window has three tabs: Overview, Gear (what they wear) and Party (ask them to join).
* They may or may not say yes - it depends on their personality, how their level compares to yours, their health and
  whether they are busy.  A refusal makes them unwilling for a few minutes.
* Up to 3 party members follow you through the world and fight what attacks you.  In dungeons and raids they take
  the place of the AI allies (the group size stays the same, so each member means one AI ally fewer).
"""
import json
import math
import random

PARTY_MAX = 3
HEALER_CLASSES = ("Cleric", "Druid", "Shaman", "Paladin")
SLOT_ORDER = ("weapon", "armor", "helm", "trinket", "ring")
SLOT_TITLE = {"weapon": "Weapon", "armor": "Armor", "helm": "Helm", "trinket": "Necklace", "ring": "Ring"}


class PartyUpMixin:
    # ---------------------------------------------------------------- who is in the party
    def _pp_ids(self):
        try:
            v = json.loads(self._meta("pparty", "[]"))
        except (ValueError, TypeError):
            v = []
        return [i for i in v if isinstance(i, int)]

    def _pp_save(self, ids):
        self._setmeta("pparty", json.dumps(ids))
        self.db.commit()

    def party_members(self):
        out = []
        for i in self._pp_ids():
            a = self.by_id.get(i)
            if a is not None and a.hp > 0:
                out.append(a)
        return out

    def party_snapshot(self):
        return [{"id": a.id, "name": a.name, "level": a.level, "cls": a.role, "hp": int(a.hp), "maxhp": int(a.maxhp)} for a in self.party_members()]

    def is_pmember(self, aid):
        return aid in self._pp_ids()

    # ---------------------------------------------------------------- their gear (generated from level, class and id)
    def npc_gear(self, a):
        from .rpg import RARITY_POWER
        lvl = a.level
        rar = ("Common" if lvl < 10 else "Uncommon" if lvl < 22 else "Rare" if lvl < 40 else "Epic" if lvl < 62 else "Elite" if lvl < 85 else "Legendary")
        want = getattr(a, "gear", None)
        if want in RARITY_POWER and want not in ("Set", "Mythic"):
            rar = want
        cls = a.role if a.kind == "adventurer" else "Warrior"
        rows = []
        for slot in SLOT_ORDER:
            r = random.Random(f"{a.id}:{slot}")
            try:
                nm = self.gear_word(slot, r, cls)
            except Exception:
                nm = SLOT_TITLE[slot]
            rows.append({"slot": slot, "title": SLOT_TITLE[slot], "item": f"{rar} {nm}", "rarity": rar,
                         "power": min(168, lvl * 2 + RARITY_POWER[rar] + 3 + (r.randint(0, 4)))})
        return rows

    # ---------------------------------------------------------------- asking
    def _recruitable(self, a):
        return a is not None and a.hp > 0 and (a.kind == "adventurer" or (a.kind == "npc" and a.role == "guard"))

    def join_chance(self, a):
        """(chance, reason-if-no) that a will join."""
        p = self.player
        if a.faction != p["faction"]:
            return 0.0, "will not travel with an enemy of their people"
        if a.kind == "npc":
            return .25, ""
        if a.state in ("aiduel", "defend", "fight", "duel", "offer") or (a.party and a.party != -1):
            return 0.0, "is busy right now"
        if getattr(a, "refused_until", 0) > self.tick:
            return 0.0, "has already given you an answer"
        base = {"friendly": .8, "proud": .35, "aggressive": .55, "shy": .25, "trader": .3, "explorer": .7, "guardian": .75}.get(getattr(a, "persona", "friendly"), .5)
        gap = a.level - p["level"]
        if gap > 12:
            base *= .3
        elif gap > 5:
            base *= .65
        elif gap < -25:
            base *= .45
        if a.hp < a.maxhp * .5:
            base *= .5
        return max(.03, min(.95, base)), ""

    def party_invite(self, aid):
        a = self.by_id.get(aid)
        if not self._recruitable(a):
            return "There is nobody there to ask."
        if self.inst or getattr(self, "city_raid", None):
            return "Not now - ask them out in the world."
        ids = self._pp_ids()
        if aid in ids:
            return f"{a.name} is already in your party."
        if len(self.party_members()) >= PARTY_MAX:
            return f"Your party is full ({PARTY_MAX} companions). Dismiss someone first."
        if self._pdist(a) > 8:
            return f"{a.name} is too far away."
        ch, why = self.join_chance(a)
        if ch <= 0:
            return f"{a.name} {why}."
        if self.rng.random() < ch:
            ids.append(aid)
            self._pp_save(ids)
            a.state = "pparty"; a.party = -1; a.gx = None
            if a.kind == "adventurer":
                self._say(a, "greet")
            return f"{a.name} (level {a.level} {a.role}) joins your party!"
        a.refused_until = self.tick + 1600
        if a.kind == "adventurer":
            a.say = self.rng.choice(("Not today.", "I travel alone.", "Maybe another time.", "I have my own road to walk.", "Sorry - no."))
            a.say_until = self.tick + 24; a.say_seq += 1
        return f"{a.name} declines. Try again later."

    def party_dismiss(self, aid):
        ids = self._pp_ids()
        if aid not in ids:
            return "They are not in your party."
        ids.remove(aid)
        self._pp_save(ids)
        a = self.by_id.get(aid)
        if a is not None:
            a.party = 0
            a.state = "town" if a.kind == "adventurer" else "guard"
            a.task_until = 0
            return f"{a.name} leaves your party."
        return "They leave your party."

    def party_in_instance(self):
        """(name, class) of the companions that go in with you - each one takes the place of an AI ally."""
        return [(a.name, a.role if a.kind == "adventurer" else "Warrior") for a in self.party_members()]

    # ---------------------------------------------------------------- following and fighting (world only)
    def _pparty_tick(self):
        if self.inst:
            return
        mem = self.party_members()
        if not mem:
            return
        p = self.player
        px, py = p["x"], p["y"]
        for i, a in enumerate(mem):
            a.state = "pparty"; a.party = -1; a.hp = max(a.hp, a.maxhp * .6) if self.tick % 40 == 0 else a.hp
            ang = i * 2.1 + 1.0
            tx, ty = px + math.cos(ang) * 2.2, py + math.sin(ang) * 2.2
            d = math.hypot(tx - a.x, ty - a.y)
            if d > 40:
                a.x, a.y = tx, ty
            elif d > 1.4:
                self._move(a, tx, ty, .9 if d > 6 else .5)
            if (self.tick + i * 2) % 6 == 0:
                best = None
                for m in self.actors_near(a, 8, "monster"):
                    if m.target == -2 and m.hp > 0 and (best is None or (m.x - a.x) ** 2 + (m.y - a.y) ** 2 < (best.x - a.x) ** 2 + (best.y - a.y) ** 2):
                        best = m
                if best is not None:
                    dmg = max(1, int(self._damage(a, best) * 1.3))
                    best.hp -= dmg
                    if best.hp <= 0:
                        self.events.append(f"{a.name} slays {best.name.split(' #')[0]}.")
                        self._player_kill(best)
            if a.role in HEALER_CLASSES and self.tick % 48 == 0 and p["hp"] < self._effective_maxhp() * .7 and self.tick - self.last_combat_tick < 40:
                self._heal(self._effective_maxhp() * .08)
