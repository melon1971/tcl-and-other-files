"""LiveWorld RPG 0.25.1 - gathering: mining ore veins and skinning beasts.

Herbs already grow wild (engine.gather_herb).  This adds:
* ore veins - rocks with metal seams scattered through every zone.  Mine them (F, or click) for
  Iron Ore; richer veins in higher zones also give Arcane Dust and, rarely, Spirit Essence;
* skinning - beasts you kill leave a carcass for a few minutes.  Skin it (F, or click) for
  Leather Scrap; elite beasts can give Spirit Essence.
Mixed into engine.World.
"""

ORE_BLOCK = 12
ORE_RESPAWN = 4 * 300          # 5 minutes
SKIN_TIME = 4 * 120            # a carcass can be skinned for 2 minutes
VEINS = (("Copper Vein", 1, 20), ("Iron Vein", 21, 45), ("Silver Vein", 46, 70), ("Gold Vein", 71, 90), ("Mithril Vein", 91, 101))
SKINNABLE = {"wolf", "boar", "spider", "bear", "dire boar", "giant beetle", "yeti", "ice wolf", "scorpion", "sand wyrm", "drake", "wyvern",
             "harpy", "thunder harpy", "basilisk", "sea serpent", "gnoll", "crocolisk", "raptor", "stag", "dire wolf", "frost bear", "lion",
             "hyena", "panther", "troll", "ogre", "lava beast", "mud leech"}


class GatherMixin:
    # ---------------------------------------------------------------- ore veins
    def _ore_taken(self):
        if not hasattr(self, "_ore_tk"): self._ore_tk = {}
        return self._ore_tk

    def _vein_at(self, bx, by):
        """Where (if anywhere) the ore vein of block (bx, by) is - fixed for a world, so it is worked out once (0.38.1)."""
        c = self.__dict__.setdefault("_vein_memo", {}); k = (bx, by)
        if k in c: return c[k]
        v = self._vein_at_calc(bx, by)
        if getattr(self, "terrain_ok", None) is not None: c[k] = v
        return v

    def _vein_at_calc(self, bx, by):
        from . import engine as E
        h = (bx * 83492791 ^ by * 2971215073 ^ (self._seed() * 7)) & 0x7fffffff
        if h % 100 >= 38: return None
        x = bx * ORE_BLOCK + 1.5 + (h >> 7) % (ORE_BLOCK - 3) + .5
        y = by * ORE_BLOCK + 1.5 + (h >> 13) % (ORE_BLOCK - 3) + .5
        if y >= E.WORLD_H or x >= E.W: return None
        if self._near_town(x, y, E.TOWN_BLOCK_R + 2): return None
        ok = getattr(self, "terrain_ok", None)
        if ok and not ok(x, y): return None
        a = self.area(x, y)
        lvl = a[6]
        name, band = VEINS[0][0], 0
        for i, (nm, lo, hi) in enumerate(VEINS):
            if lo <= lvl <= hi: name, band = nm, i
        return {"id": bx * 1000 + by, "x": x, "y": y, "name": name, "band": band}

    def veins_near(self, radius=30):
        if self.inst: return []
        p = self.player; B = ORE_BLOCK; tk = self._ore_taken(); out = []
        for bx in range(int((p["x"] - radius) // B), int((p["x"] + radius) // B) + 1):
            for by in range(int((p["y"] - radius) // B), int((p["y"] + radius) // B) + 1):
                if tk.get((bx, by), 0) > self.tick: continue
                v = self._vein_at(bx, by)
                if v: out.append(v)
        return out

    def mine_vein(self):
        p = self.player
        c = [v for v in self.veins_near(5) if (v["x"] - p["x"]) ** 2 + (v["y"] - p["y"]) ** 2 <= 2.6 ** 2]
        if not c: return ""
        v = min(c, key=lambda v: (v["x"] - p["x"]) ** 2 + (v["y"] - p["y"]) ** 2)
        r = self.rng; b = v["band"]
        got = [("Mat:Iron Ore", 1 + b // 2 + (1 if r.random() < .5 else 0))]
        if b >= 2 and r.random() < .35 + b * .1: got.append(("Mat:Arcane Dust", 1 + (1 if b >= 4 and r.random() < .4 else 0)))
        if b >= 3 and r.random() < .06 * b: got.append(("Mat:Spirit Essence", 1))
        self._ore_taken()[(v["id"] // 1000, v["id"] % 1000)] = self.tick + ORE_RESPAWN
        for item, n in got: self._inv_add(item, n); self.gain(item, n, v["name"])
        self.db.commit()
        txt = ", ".join(f"{n} {item[4:]}" for item, n in got)
        return f"You mine the {v['name']}: {txt}."

    # ---------------------------------------------------------------- skinning
    def _skins(self):
        if not hasattr(self, "_skin_list"): self._skin_list = []
        return self._skin_list

    def add_carcass(self, name, x, y, level, elite):
        from .engine import mkind
        sp = mkind(name).lower()
        if sp not in SKINNABLE: return
        sk = self._skins()
        sk.append({"id": (self.tick * 31 + len(sk)) % 10_000_000, "x": x, "y": y, "name": mkind(name), "level": level, "elite": elite,
                   "until": self.tick + SKIN_TIME})
        if len(sk) > 40: del sk[0]

    def skins_near(self, radius=30):
        if self.inst: return []
        p = self.player; t = self.tick
        sk = self._skins()
        sk[:] = [s for s in sk if s["until"] > t]
        return [s for s in sk if (s["x"] - p["x"]) ** 2 + (s["y"] - p["y"]) ** 2 <= radius * radius]

    def skin_carcass(self):
        p = self.player
        c = [s for s in self.skins_near(5) if (s["x"] - p["x"]) ** 2 + (s["y"] - p["y"]) ** 2 <= 2.6 ** 2]
        if not c: return ""
        s = min(c, key=lambda s: (s["x"] - p["x"]) ** 2 + (s["y"] - p["y"]) ** 2)
        self._skins().remove(s)
        r = self.rng
        got = [("Mat:Leather Scrap", 1 + (1 if r.random() < .55 else 0) + (1 if s["level"] > 40 else 0) + (2 if s["elite"] else 0))]
        if s["elite"] and r.random() < .3: got.append(("Mat:Spirit Essence", 1))
        for item, n in got: self._inv_add(item, n); self.gain(item, n, s["name"])
        self.db.commit()
        txt = ", ".join(f"{n} {item[4:]}" for item, n in got)
        return f"You skin the {s['name']}: {txt}."

    def gather_snapshot(self):
        return {"veins": self.veins_near(30), "skins": [{"id": s["id"], "x": s["x"], "y": s["y"], "name": s["name"]} for s in self.skins_near(30)]}
