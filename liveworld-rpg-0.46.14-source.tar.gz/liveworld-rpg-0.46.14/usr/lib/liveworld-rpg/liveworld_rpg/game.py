#!/usr/bin/env python3
"""LiveWorld RPG 0.10 — Conquer-style isometric client.

Click the ground to walk, click a monster to target it and auto-attack,
1-4 for class skills, 5 potion, 6 pick up loot.  All game rules live in
engine.py; this file only draws the world and turns input into engine calls.
"""
import math, time, re, collections, heapq, os, json, subprocess, shutil, traceback
import pygame
from .engine import MAX_RANK as MAX_RANK_UI
from .engine import World, open_world, W, H, WORLD_H, AREAS, CLASSES, HYBRID_SPECS, DATA, xp_need, WORLD_VERSION, acquire_instance_lock
from . import guide, sound
from . import gfx, fx, worldmap
def _FISH():
    from .rpg import FISH
    return FISH
from .gfx import iso, uniso, TW, TH, HTW, HTH, CS, shade, RARITY_COLOR
from .rpg import _MAGIC


def is_magic(a):
    """0.46.5: spellcasting monsters (the ones that drop Arcane Dust) are marked like elites, in violet."""
    if a.get("kind") != "monster" or a.get("boss"): return False
    nm = a.get("name", "").split(" #")[0]
    return (nm[6:] if nm.startswith("Elite ") else nm).lower() in _MAGIC

VERSION = "0.46.14"
_T0 = time.time()
def trace(msg):
    """Startup trace -> ~/.local/state/liveworld-rpg/startup.log (the launcher redirects stdout there)."""
    try: print(f"[{time.time() - _T0:7.2f}s] {msg}", flush=True)
    except Exception: pass
os.environ.setdefault("SDL_VIDEO_WINDOW_POS", "0,0")
trace(f"LiveWorld RPG {VERSION} starting, pygame {getattr(pygame.version, 'ver', '?')}")
pygame.init()
trace("pygame initialised")
LW, LH = 1280, 800
GT = 256                    # ground is cached in GT x GT screen-aligned tiles (see Game.ground_tile)

def _initial_window():
    try:
        dw, dh = pygame.display.get_desktop_sizes()[0]
    except Exception:
        dw, dh = 1280, 800
    sc = max(.4, min(1.0, (dw - 40) / LW, (dh - 120) / LH))
    return int(LW * sc), int(LH * sc)

# ---- graphics: 0 Lite, 1 Normal (0.33.3: High and Ultra were removed)
QUALITY_NAMES = ("Lite", "Normal", "High")
SETTINGS = DATA / "settings.json"
def load_settings():
    try: d = json.loads(SETTINGS.read_text())
    except Exception: return {}
    return d if isinstance(d, dict) else {}          # 0.37.2: a hand-edited or damaged file must never stop the game starting

def setting_num(st, key, default, lo, hi):
    """A number from the settings file, clamped to lo..hi (default when missing, not a number, or NaN)."""
    v = st.get(key, default)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v: return default
    return max(lo, min(hi, v))
def save_settings(d):
    try:                                            # 0.34.2: write-then-rename, so a kill mid-save can't leave half a file
        tmp = SETTINGS.with_suffix(".json.tmp"); tmp.write_text(json.dumps(d)); os.replace(tmp, SETTINGS)
    except Exception: pass
def default_quality():
    st = load_settings()
    if isinstance(st.get("quality"), int) and st["quality"] >= 0: return min(2, st["quality"])     # old Ultra saves -> High
    return 2 if strong_pc() else 1

def strong_pc():
    """0.37: 8+ CPU threads and 12 GB+ memory (e.g. a Ryzen desktop) start on High; a Celeron laptop starts on Normal."""
    try:
        with open("/proc/meminfo") as f_:
            mem_kb = next(int(l.split()[1]) for l in f_ if l.startswith("MemTotal:"))
    except Exception:
        mem_kb = 0
    return (os.cpu_count() or 1) >= 8 and mem_kb >= 12 * 1024 * 1024

FULLSCREEN = False          # True for both full-screen styles
DISPLAY = "border"          # "full" (true full screen, covers panels) | "border" (borderless, fits the desktop work area) | "window"
DISPLAY_NAMES = {"full": "Full screen", "border": "Borderless", "window": "Window"}
_DISPLAY_T = 0.0

def _desktop():
    try: return tuple(pygame.display.get_desktop_sizes()[0])
    except Exception: return (1280, 800)

def _work_area():
    """Usable desktop area (x, y, w, h) without panels / top bars, from the X11 _NET_WORKAREA hint."""
    if not shutil.which("xprop"): return None
    try:
        out = subprocess.run(["xprop", "-root", "_NET_WORKAREA"], capture_output=True, text=True, timeout=1.5).stdout
        if "=" not in out: return None
        nums = [int(v) for v in re.findall(r"-?\d+", out.split("=", 1)[1])][:4]
        dw, dh = _desktop()
        if len(nums) == 4 and 640 <= nums[2] <= dw and 480 <= nums[3] <= dh: return tuple(nums)
    except Exception:
        pass
    return None

def _sdl_window():
    try:
        from pygame._sdl2.video import Window
        return Window.from_display_module()
    except Exception:
        return None

def start_display(mode):
    """Open the game window.  mode: "full", "border" or "window" (True/False accepted from old settings)."""
    global window, FULLSCREEN, DISPLAY, _DISPLAY_T
    if mode is True: mode = "border"
    if mode is False or mode not in DISPLAY_NAMES: mode = "window" if mode is False else "border"
    if os.environ.get("LIVEWORLD_WINDOWED"): mode = "window"
    _DISPLAY_T = time.time()
    dw, dh = _desktop()
    if mode == "full":
        try:
            window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            FULLSCREEN, DISPLAY = True, "full"
            trace(f"display: full screen {window.get_size()}"); return
        except Exception as e:
            trace(f"display: full screen failed ({e}), trying borderless"); mode = "border"
    if mode == "border":
        try:
            wa = _work_area() or (0, 0, dw, dh)
            os.environ["SDL_VIDEO_WINDOW_POS"] = f"{wa[0]},{wa[1]}"
            window = pygame.display.set_mode((wa[2], wa[3]), pygame.NOFRAME)
            sw = _sdl_window()
            if sw is not None:
                try: sw.position = (wa[0], wa[1])
                except Exception: pass
            FULLSCREEN, DISPLAY = True, "border"
            trace(f"display: borderless {window.get_size()} at {wa[0]},{wa[1]}"); return
        except Exception as e:
            trace(f"display: borderless failed ({e}), using a window")
    os.environ["SDL_VIDEO_WINDOW_POS"] = "center"
    window = pygame.display.set_mode(_initial_window(), pygame.RESIZABLE)
    FULLSCREEN, DISPLAY = False, "window"
    trace(f"display: window {window.get_size()}")

def fit_borderless():
    """If the desktop pushed the borderless window under/past a panel, shrink it so every button stays on screen.
    Returns True when the window size changed."""
    global window
    if DISPLAY != "border" or time.time() - _DISPLAY_T > 6: return False
    sw = _sdl_window()
    if sw is None: return False
    try:
        x, y = sw.position
        ww, wh = pygame.display.get_surface().get_size()
        dw, dh = _desktop()
        nw, nh = min(ww, dw - max(0, x)), min(wh, dh - max(0, y))
        if (nw, nh) != (ww, wh) and nw >= 640 and nh >= 480:
            window = pygame.display.set_mode((nw, nh), pygame.NOFRAME)
            trace(f"display: borderless window was pushed to {x},{y}; resized to {nw}x{nh}")
            return True
    except Exception:
        pass
    return False

def _saved_display():
    st = load_settings()
    if st.get("display") in DISPLAY_NAMES: return st["display"]
    return "border" if st.get("fullscreen", True) else "window"

start_display(_saved_display())
screen = pygame.Surface((LW, LH))
def set_logical(w, h):
    """Resize the internal canvas (800 lines tall, scaled to the window)."""
    global LW, LH, screen
    w = max(1280, min(2560, int(w))); h = max(800, min(1440, int(h)))
    if (w, h) != (LW, LH):
        LW, LH = w, h; screen = pygame.Surface((LW, LH))
    return LW, LH
pygame.display.set_caption(f"LiveWorld RPG {VERSION}")
clock = pygame.time.Clock()

def loading(msg, frac):
    """Draw a loading screen straight onto the window so the player never stares at black while the world builds."""
    trace("loading: " + msg)
    try:
        pygame.event.pump()
        win = pygame.display.get_surface(); ww, wh = win.get_size()
        win.fill((14, 12, 16))
        f1 = pygame.font.SysFont("dejavuserif,liberationserif,georgia,serif", max(28, wh // 18), bold=True)
        f2 = pygame.font.SysFont("dejavusans,liberationsans,arial", max(14, wh // 48))
        t = f1.render("LiveWorld RPG", True, (226, 190, 96)); win.blit(t, (ww // 2 - t.get_width() // 2, wh // 2 - t.get_height() - 40))
        t = f2.render(msg, True, (230, 222, 205)); win.blit(t, (ww // 2 - t.get_width() // 2, wh // 2 + 34))
        bw = min(640, ww - 80); bx = ww // 2 - bw // 2; by = wh // 2
        pygame.draw.rect(win, (60, 50, 36), (bx - 2, by - 2, bw + 4, 22), border_radius=6)
        pygame.draw.rect(win, (30, 26, 24), (bx, by, bw, 18), border_radius=5)
        pygame.draw.rect(win, (214, 172, 62), (bx, by, max(4, int(bw * max(0.0, min(1.0, frac)))), 18), border_radius=5)
        pygame.display.flip()
    except Exception as e:
        trace(f"loading screen failed: {e}")

def _font(names, size, bold=False):
    return pygame.font.SysFont(names, size, bold=bold)
F_SM = _font("dejavusans,liberationsans,arial", 12)
F_MD = _font("dejavusans,liberationsans,arial", 14)
F_BD = _font("dejavusans,liberationsans,arial", 13, True)
F_PL = _font("dejavusans,liberationsans,arial", 11, True)
F_TI = _font("dejavuserif,liberationserif,georgia,serif", 22, True)
F_BIG = _font("dejavuserif,liberationserif,georgia,serif", 44, True)
F_DMG = _font("dejavusans,liberationsans,arial", 18, True)
F_CRIT = _font("dejavuserif,liberationserif,georgia,serif", 26, True)
F_NPC = _font("dejavusans,liberationsans,arial", 15, True)          # town NPC names (bold)
F_QM = _font("dejavuserif,liberationserif,georgia,serif", 46, True)  # quest markers

GOLD = (214, 172, 62); PARCH = (245, 232, 200); GREY = (150, 152, 160)
CLASS_INFO = {
 "Warrior": "Plate-armored fighter. Highest health, cleaves groups and finishes foes with Execute.",
 "Ranger": "Master archer. Kills from range with Aimed Shot, Multi-Shot and Trueshot.",
 "Mage": "Arcane caster. Huge burst with Meteor, Frost Nova for crowds, Ice Barrier to survive.",
 "Cleric": "Holy priest in armor. Smites the wicked and heals through any fight.",
 "Rogue": "Shadow assassin. Backstab and Shadowstep for fast, brutal kills.",
 "Paladin": "Holy knight in gold plate. Protection tanks, Holy heals, Retribution smites.",
 "Shaman": "Master of the elements. Earthwarden tanks, Restoration heals, Elemental calls lightning.",
 "Druid": "Shapeshifter of the wilds. Guardian tanks, Restoration heals, Feral rends.",
 "Berserker": "Axe-swinging brawler. Hardest single hits in the game; Bloodthirst heals you as you strike.",
 "Warlock": "Fel sorcerer. Stacks Corruption, drains life from foes and ends fights with Chaos Bolt.",
 "Juggernaut": "Walking fortress. Tower shield, warhammer and the most health in the game; always tanks.",
 "Monk": "Martial artist. Fists of Fury flurries, Flying Serpent Kick to close in, best dodge.",
}
SPECS = HYBRID_SPECS
ROLE_COL = {"Tank": (70, 110, 190), "Healer": (50, 150, 80), "DPS": (180, 60, 50)}
CLASS_ROLE = {"Warrior": "Melee DPS", "Ranger": "Ranged DPS", "Mage": "Caster DPS", "Cleric": "Caster • self-heals", "Rogue": "Melee DPS",
              "Berserker": "Melee DPS", "Warlock": "Caster DPS", "Monk": "Melee DPS", "Juggernaut": "Tank"}
_ELEM = (
    (("fire", "flame", "meteor", "ignite", "lava", "immolat", "rend", "rake"), (255, 120, 40)),
    (("frost", "ice", "freeze", "nova"), (140, 210, 255)),
    (("holy", "smite", "judgement", "crusader", "consecrat", "light", "hammer", "divine", "exorcism", "penance", "templar", "reckoning", "avenger"), (255, 220, 110)),
    (("lightning", "storm", "thunder", "chain", "shock"), (170, 200, 255)),
    (("corruption", "chaos", "drain", "soul", "dark pact", "terror", "demonic", "unending"), (130, 230, 90)),
    (("blood", "rage", "raging", "decapitat", "skull", "berserk", "unbreakable", "battle trance", "whirlwind"), (230, 60, 50)),
    (("shield slam", "thunder clap", "sunder", "shield charge", "revenge", "avalanche", "bulwark", "fortress", "unyielding", "rampart"), (200, 190, 160)),
    (("palm", "kick", "fists", "touch of", "sweep", "vivify", "brew", "karma", "diffuse"), (110, 230, 200)),
    (("arcane", "missiles", "blink"), (190, 120, 255)),
    (("shadow", "rupture", "vanish", "eviscerate", "kidney", "backstab"), (170, 90, 220)),
    (("serpent", "sting", "moon", "star", "wrath", "hurricane", "roots", "nature", "riptide", "earth", "quake"), (120, 230, 120)),
)
def element_color(name, cls="Warrior"):
    n = name.lower()
    for words, col in _ELEM:
        if any(w in n for w in words): return col
    return {"Warrior": (255, 230, 190), "Ranger": (230, 210, 160), "Mage": (180, 140, 255), "Cleric": (255, 236, 140), "Rogue": (210, 255, 210),
            "Paladin": (255, 220, 110), "Shaman": (150, 200, 255), "Druid": (140, 230, 120),
            "Berserker": (230, 70, 50), "Warlock": (130, 230, 90), "Monk": (110, 230, 200)}.get(cls, (255, 255, 255))
MELEE = ("Warrior", "Rogue", "Berserker", "Monk", "Juggernaut")
ACTOR_SCALE = 1.3

def clamp(v, lo, hi): return max(lo, min(hi, v))

_TXT = collections.OrderedDict()
def tsurf(s, color=(230, 230, 235), f=F_MD, outline=False):
    key = (s, color, id(f), outline)
    r = _TXT.get(key)
    if r is None:
        base = f.render(str(s), True, color)
        if outline:
            o = f.render(str(s), True, (0, 0, 0))
            r = pygame.Surface((base.get_width() + 2, base.get_height() + 2), pygame.SRCALPHA)
            for dx, dy in ((0, 1), (2, 1), (1, 0), (1, 2)):
                r.blit(o, (dx, dy))
            r.blit(base, (1, 1))
        else:
            r = base
        _TXT[key] = r
        if len(_TXT) > 1500:
            _TXT.popitem(last=False)
    return r

_HEAVY = collections.OrderedDict()
def heavy_text(s, x, y, color, f, thick=2, center=True):
    """Text with a thick black outline: town NPC names and quest markers."""
    key = (s, color, id(f), thick)
    r = _HEAVY.get(key)
    if r is None:
        base = f.render(str(s), True, color); o = f.render(str(s), True, (0, 0, 0))
        r = pygame.Surface((base.get_width() + thick * 2, base.get_height() + thick * 2), pygame.SRCALPHA)
        for dx in range(-thick, thick + 1):
            for dy in range(-thick, thick + 1):
                if dx or dy: r.blit(o, (thick + dx, thick + dy))
        r.blit(base, (thick, thick)); _HEAVY[key] = r
        if len(_HEAVY) > 400: _HEAVY.popitem(last=False)
    screen.blit(r, (x - r.get_width() // 2 if center else x, y)); return r

def text(s, x, y, color=(230, 230, 235), f=F_MD, outline=False, center=False, right=False):
    t = tsurf(s, color, f, outline)
    if center: x -= t.get_width() // 2
    elif right: x -= t.get_width()
    screen.blit(t, (x, y)); return t

_PANELS = collections.OrderedDict()
def _panel_surface(w, h, alpha, border):
    """0.17: gradient panel with a bevel, double gold rim and corner studs (cached)."""
    key = (w, h, alpha, tuple(border))
    s = _PANELS.get(key)
    if s is not None:
        return s
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    top, bot = (38, 32, 40), (12, 10, 14)
    for y in range(h):
        t = y / max(1, h - 1)
        c = tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3))
        pygame.draw.line(s, (*c, alpha), (0, y), (w, y))
    for k in range(int(w * h / 90)):      # fine leather grain
        gx_ = (k * 7919) % max(1, w - 8) + 4; gy_ = (k * 104729 // 3) % max(1, h - 8) + 4
        v_ = (k * 31) % 5
        s.set_at((gx_, gy_), (255, 244, 220, 14 + v_ * 3) if k % 2 else (0, 0, 0, 30 + v_ * 4))
    for k in range(5):                    # inner vignette
        pygame.draw.rect(s, (0, 0, 0, 22), s.get_rect().inflate(-6 - k * 3, -6 - k * 3), 3, border_radius=7)
    mask = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=7)
    s.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    pygame.draw.rect(s, (*shade(border, .35), 255), s.get_rect(), 3, border_radius=7)
    pygame.draw.rect(s, (*border, 255), s.get_rect().inflate(-2, -2), 1, border_radius=6)
    pygame.draw.line(s, (255, 240, 200, 40), (8, 4), (w - 9, 4))
    pygame.draw.line(s, (0, 0, 0, 90), (8, h - 5), (w - 9, h - 5))
    for cx, cy in ((5, 5), (w - 6, 5), (5, h - 6), (w - 6, h - 6)):
        pygame.draw.polygon(s, (*shade(border, 1.15), 255), [(cx, cy - 4), (cx + 4, cy), (cx, cy + 4), (cx - 4, cy)])
        pygame.draw.polygon(s, (*shade(border, .4), 255), [(cx, cy - 4), (cx + 4, cy), (cx, cy + 4), (cx - 4, cy)], 1)
    _PANELS[key] = s
    if len(_PANELS) > 120: _PANELS.popitem(last=False)
    return s

# 0.37.1: name labels for the buildings you can click (in the same style as NPC names); plain houses stay unlabelled
STATION_LABELS = {"forge": ("Forge", "Craft Weapons & Armor"), "hut": ("Fishing Hut", "Rods, Bait & Tonics"),
                  "press": ("Wine Press", "Potions & Sunwine"), "warhall": ("War Hall", "PvP & Raids"),
                  "magic": ("Skill Shop", "Skills, Spells & Stats"), "apothecary": ("Apothecary", "Potions & Remedies"),
                  "inn": ("Inn", "Alchemy & Cooking"), "jeweler": ("Jeweler", "Rings & Necklaces"), "kiln": ("Jeweler's Kiln", "Cut & Socket Jewels"),
                  "smithy": ("Blacksmith", "Weapons & Armor"), "general": ("General Store", "Supplies & Materials"),
                  "enchanter": ("Magic Shop", "Magic Items"), "bank": ("Bank", "Your Vault"),
                  "stable": ("Stable", "Riding & Mounts"),
                  "market": ("Trade Market", "Buy Cheap, Sell Dear")}

def frame_panel(rect, alpha=215, border=GOLD):
    r = pygame.Rect(rect)
    screen.blit(_panel_surface(r.width, r.height, alpha, border), r.topleft)
    return r

def bar(x, y, w, h, v, mx, col, label=None, f=F_SM):
    pygame.draw.rect(screen, (20, 18, 22), (x - 1, y - 1, w + 2, h + 2), border_radius=3)
    pygame.draw.rect(screen, shade(col, .3), (x, y, w, h), border_radius=3)
    fw = int(w * clamp(v / max(1, mx), 0, 1))
    if fw > 0:
        pygame.draw.rect(screen, col, (x, y, fw, h), border_radius=3)
        pygame.draw.rect(screen, shade(col, .72), (x, y + h - max(1, h // 3), fw, max(1, h // 3)), border_bottom_left_radius=3, border_bottom_right_radius=3)
        pygame.draw.rect(screen, shade(col, 1.35), (x + 1, y + 1, max(0, fw - 2), max(1, h // 3)), border_radius=2)
        if fw > 3: pygame.draw.line(screen, shade(col, 1.6), (x + fw - 1, y + 1), (x + fw - 1, y + h - 2))
        if w >= 60 and h >= 9:
            for tx in range(x + 24, x + fw, 24): pygame.draw.line(screen, shade(col, .62), (tx, y + 1), (tx, y + h - 2))
    if label:
        text(label, x + w // 2, y + h // 2 - f.get_height() // 2, (250, 250, 250), f, True, center=True)

_MOUSE = (-9, -9)


def button(rect, label, enabled=True, accent=False, hot=False):
    r = pygame.Rect(rect)
    if enabled and r.collidepoint(_MOUSE): hot = True
    top_c, bot_c = ((84, 66, 46), (46, 36, 26)) if enabled else ((44, 42, 44), (28, 26, 28))
    if hot and enabled: top_c, bot_c = (116, 92, 58), (66, 52, 34)
    pygame.draw.rect(screen, (14, 10, 8), r.inflate(2, 2), border_radius=6)
    pygame.draw.rect(screen, bot_c, r, border_radius=5)
    pygame.draw.rect(screen, top_c, (r.x, r.y, r.w, max(2, r.h * 55 // 100)), border_top_left_radius=5, border_top_right_radius=5)
    if enabled: pygame.draw.line(screen, (255, 236, 190), (r.x + 4, r.y + 1), (r.right - 5, r.y + 1))
    pygame.draw.line(screen, (0, 0, 0), (r.x + 3, r.bottom - 2), (r.right - 4, r.bottom - 2))
    bc = GOLD if (accent and enabled) else ((150, 126, 88) if enabled else (80, 76, 72))
    pygame.draw.rect(screen, bc, r, 1, border_radius=5)
    if enabled and r.collidepoint(_MOUSE):
        gl = pygame.Surface((r.w + 12, r.h + 12), pygame.SRCALPHA)
        pygame.draw.rect(gl, (255, 214, 120, 60), (0, 0, r.w + 12, r.h + 12), 3, border_radius=9)
        pygame.draw.rect(gl, (255, 214, 120, 110), (4, 4, r.w + 4, r.h + 4), 1, border_radius=7)
        screen.blit(gl, (r.x - 6, r.y - 6))
    text(label, r.centerx, r.centery - F_BD.get_height() // 2, PARCH if enabled else (110, 110, 115), F_BD, True if enabled else False, center=True)
    return r

def empty_slot(rr, strong=False):
    """Inset slot well: dark floor, shadow on the top/left edges, lit bottom/right lip."""
    pygame.draw.rect(screen, (14, 12, 16), rr, border_radius=8)
    pygame.draw.rect(screen, (30, 26, 32) if not strong else (38, 33, 40), rr.inflate(-4, -4), border_radius=6)
    pygame.draw.line(screen, (6, 4, 8), (rr.x + 4, rr.y + 2), (rr.right - 5, rr.y + 2), 2)
    pygame.draw.line(screen, (6, 4, 8), (rr.x + 2, rr.y + 4), (rr.x + 2, rr.bottom - 5), 2)
    pygame.draw.line(screen, (96, 80, 58), (rr.x + 5, rr.bottom - 2), (rr.right - 5, rr.bottom - 2))
    pygame.draw.line(screen, (96, 80, 58), (rr.right - 2, rr.y + 5), (rr.right - 2, rr.bottom - 5))
    pygame.draw.rect(screen, (74, 62, 46), rr, 1, border_radius=8)

def gfx_jewel_rarity(qi):
    return ("Uncommon", "Rare", "Epic", "Elite", "Legendary")[max(0, min(4, qi))]
SLOT_LABEL = {"weapon": "Weapon", "armor": "Armor", "helm": "Helm", "trinket": "Necklace", "ring": "Ring"}   # 0.39: the trinket slot is the necklace
ALLY_COL = (110, 170, 255)      # your own faction: you, its townsfolk and its adventurers (0.38: one colour for all of them)
ENEMY_COL = (255, 150, 50)      # the other faction's townsfolk and adventurers
NEUTRAL_COL = (232, 220, 190)   # neutral towns and caravans

def faction_col(a, me):
    """0.38: name colour by faction - yours, the enemy's, or neutral (battleground teams keep ally/enemy)."""
    if a.get("ally") is not None and a.get("soldier") is None and a.get("rrole"): return ALLY_COL if a.get("ally") else ENEMY_COL
    f = a.get("faction")
    if f == me.get("faction"): return ALLY_COL
    return ENEMY_COL if f in ("Alliance", "Horde") else NEUTRAL_COL
MONSTER_COL = (255, 70, 60)     # monsters

def con_color(mylvl, lvl):
    d = lvl - mylvl
    if d >= 5: return (255, 60, 50)
    if d >= 3: return (255, 150, 40)
    if d >= -2: return (255, 230, 70)
    if d >= -5: return (70, 220, 80)
    return (160, 160, 160)

def role_q(a):
    return a.get("role") in ("questgiver", "king") and a.get("faction") in (_MY_FACTION, "Neutral")      # 0.35: no markers in enemy towns

def clean_name(a):
    n = a.get("name", "?")
    n = n.split(" #")[0]
    if a.get("kind") == "adventurer":
        n = re.sub(r"\s+\d+$", "", n)
    if a.get("pmember"): n += " (party)"
    return n

def gfx_herbs():
    from .engine import World
    return World.HERBS

_MY_FACTION = "Alliance"
def is_enemy(a, me):
    # 0.38: adventurers of the other faction only after they accept a fight (or attack you); soldiers and monsters
    # by faction; battleground players by team.  Your own side's City Watch is never an enemy.
    if a.get("hostile"): return True
    if a.get("soldier") or a.get("kind") == "monster": return a.get("faction") != me.get("faction")
    if a.get("rrole") and a.get("ally") is not None: return not a.get("ally")
    return False


class Game:
    def __init__(self, w, audio=None):
        self.w = w
        self.w.terrain_ok = lambda x, y: self.walkable(x, y)
        loading("Laying out roads and towns...", .30)
        gfx.reset_world_caches()                  # 0.37.2: a new world (e.g. after deleting the hero) starts with empty tile caches
        self.layout = gfx.WorldLayout(w)
        loading("Raising buildings...", .42)
        self.chunks = collections.OrderedDict(); self.chunk_decor = {}
        self.rims = collections.OrderedDict(); self.gtiles = collections.OrderedDict(); self.chunk_jobs = {}; self._new_poses = 0
        self.gtile_partial = set(); self.placeholders = {}; self._sync_until = 0.0; self._cam_prev = None
        self.block = set()
        self.walk_cache = {}
        self.buildings = []
        for bx, by, kind, style, var in self.layout.buildings:
            spr, anc, bw, bd = gfx.building_sprite(kind, style, var)
            self.buildings.append((bx, by, spr, anc, bw, bd, kind))
            if kind in ("house", "tower") or kind in gfx.STATION_KINDS:
                for tx in range(int(bx), int(math.ceil(bx + bw))):
                    for ty in range(int(by), int(math.ceil(by + bd))):
                        self.block.add((tx, ty))
            elif kind == "fountain":
                self.block.add((int(bx), int(by)))
        self.w.station_posts = getattr(self.layout, "stations", {})
        self.w.place_town_npcs()          # 0.39: shopkeepers work inside their buildings
        self.w.gate_angles = getattr(self.layout, "gates", {})
        self.t = 0.0
        self.mode = "world" if w.character_created() else "create"
        self.messages = collections.deque(maxlen=60)
        self.msg(f"LiveWorld RPG {VERSION} — click to move, click a monster to attack.  The War Hall in every city has PvP and raids.", (255, 220, 120))
        self.target = None; self.auto = False; self.pending = None
        self.dest = None; self.click_fx = None
        self.disp = {}; self.prev = {}; self.prev_pos = {}
        self.floats = []; self.effects = []; self.cast_banner = None; self.last_mv = (1.0, -1.0)
        self.last_swing = 0; self.player_anim = {"attack": -9, "facing": 1, "moving": False}
        self.hover = None; self.hover_loot = None; self.hit_rects = []; self.loot_rects = []
        self.seen_events = collections.deque(maxlen=60)
        for e in w.events: self.seen_events.append(getattr(e, "seq", e))
        self.zone = None; self.zone_banner = None; self.death_banner = -99
        self.snap = w.snapshot(); self.t = 0.0
        loading("Drawing the world map...", .55)
        self._atlas = self._world_map_cached(3)                 # 0.44.20: terrain + roads only; each map adds its own layer
        self.minimap_base = self._atlas.copy()
        worldmap.draw_town_detail(self.minimap_base, self.layout, self.w, 3)
        try: self._big_map()
        except Exception as e: trace(f"big map failed ({e})")
        loading("Preparing the land...", .80)
        for i_, k_ in enumerate(sorted(gfx.SHADOW_DECOR | gfx.FLAT_DECOR)):      # build the common sprites now, not mid-game
            for v_ in range(3):
                try: gfx.decor_sprite(k_, v_)
                except Exception: pass
            if i_ % 6 == 0: loading("Preparing the land...", .80 + .05 * i_ / 40.0)
        self.ui_rects = {}; self.drag = None; self.inv_scroll = 0; self.tooltip = None
        self.map_view = None; self.map_drag = None; self.map_geo = None; self.map_sel = None; self.map_click = (0, (0, 0)); self.map_t = 0; self._map_cache = None
        # character creation state
        p = self.snap["player"]
        self.cc_name = p.get("name", "Adventurer") if p.get("name") != "Adventurer" else ""
        self.cc_faction = p.get("faction", "Alliance"); self.cc_class = p.get("class", "Warrior")
        try: self.chat_open = bool(load_settings().get("chat_open", True))
        except Exception: self.chat_open = True
        self._chat_seen = getattr(self, "_msg_n", 0)
        self.shake = 0.0
        self.cam = (0, 0); self.mouse = (0, 0); self.cursor = None; self.night = 0
        self.look = [0.0, 0.0]; self.look_drag = None; self._look_pp = None; self._look_back = False      # 0.40.4: hold left mouse + drag to scroll the map
        self.cc_spec = p.get("spec") or ""; self.levelup_t = -99; self.prev_level = p.get("level", 1); self.weapon_rarity = ""
        self.walls = []
        from . import medieval
        wset = set(self.layout.walls)
        for (wx, wy) in self.layout.walls:
            town = min(w.towns, key=lambda t: (t.x - wx) ** 2 + (t.y - wy) ** 2)
            style = town.faction if town.faction in ("Alliance", "Horde") else "Neutral"
            self.walls.append((wx, wy, (wx, wy) in self.layout.wall_posts, style, medieval.wall_mask(wset, wx, wy)))     # 0.45: joined walls
            self.block.add((wx, wy))
        for (px_, py_, kind, var) in self.layout.props:
            if kind in ("lamp", "barrel", "crate") or kind in gfx.SOLID_PROPS:
                self.block.add((int(px_), int(py_)))
        self.path = None; self.path_goal = None; self.path_t = -9
        self.atmo = fx.Atmosphere(LW, LH); self.quality = 1; self.dt = 1 / 60; self.ft_avg = 1 / 60; self.auto_q = True; self.slow_t = 0.0; self._shd = {}; self.mk_tab = "buy"; self.mk_scroll = 0
        self.chunk_fluids = {}; self.visible_lava = []; self.visible_water = []
        self.looks = {}; self.corpsed = {}; self.corpse_cache = {}
        self.in_inst = False; self.inst_walls = []; self.inst_props = []; self.portal_rects = []
        # 0.24: settings, sound, guide, quests, crafting
        st = load_settings()
        self.brightness = float(setting_num(st, "brightness", 1.0, .7, 1.6))
        loading("Tuning instruments...", .88)
        self.audio = audio or sound.Audio(setting_num(st, "vol_master", .8, 0, 1), setting_num(st, "vol_music", .5, 0, 1), setting_num(st, "vol_sfx", .8, 0, 1), st.get("mute") is True)
        self.full_style = st.get("full_style") if st.get("full_style") in ("full", "border") else ("full" if DISPLAY == "full" else "border")
        self.confirm_delete = False; self.want_reset = False; self.hover_node = None
        self.want_quit = False; self.sliders = {}; self.slider_drag = None
        self.guide_page = 0; self.guide_scroll = 0
        self.craft_station = "inn"; self.craft_tab = 0; self.craft_scroll = 0
        self.qg_npc = None; self.qlog_tab = "log"
        self.w.water_near = self.water_near
        self.w.water_push = lambda x, y: self.layout.pond_push(x, y) if (0 <= y < WORLD_H and hasattr(self.layout, 'pond_push')) else None

    # ------------------------------------------------------------ utils
    def msg(self, s, color=(225, 225, 230)):
        if not s: return
        s = str(s)
        if color == (225, 225, 230):
            m = re.search(r"(Common|Uncommon|Rare|Epic|Elite|Legendary|Set)\b", s)
            if s.startswith(("Picked up", "Legendary", "Raid boss")) and m:
                color = RARITY_COLOR.get(m.group(1), color)
            elif "out of range" in s or "Not enough" in s or "cooldown" in s:
                color = (255, 120, 100)
        self.messages.append((s, color, self.t)); self._msg_n = getattr(self, "_msg_n", 0) + 1
        au = getattr(self, "audio", None)
        if au is not None:
            if s.startswith("Picked up"): au.play("loot")
            elif s.startswith("Quest complete"): au.play("fanfare")
            elif s.startswith("Quest accepted"): au.play("quest")
            elif "is biting" in s: au.play("bite")
            elif s.startswith(("Crafted", "Forged", "Brewed")): au.play("craft")
            elif s.startswith("You eat"): au.play("eat")
            elif s.startswith("You cast your line"): au.play("splash")
            elif s.startswith("Level up"): au.play("levelup")

    def to_screen(self, x, y):
        sx, sy = iso(x, y)
        return sx - self.cam[0], sy - self.cam[1]

    def to_world(self, pos):
        return uniso(pos[0] + self.cam[0], pos[1] + self.cam[1])

    def walkable(self, x, y):
        k = (int(math.floor(x)), int(math.floor(y)))
        v = self.walk_cache.get(k)
        if v is None:
            if 0 <= k[0] < W and 0 <= k[1] < WORLD_H:
                self.decor(k[0] // CS, k[1] // CS)   # trees/rocks register as obstacles
            kind, _ = gfx.tile_info(self.layout, k[0], k[1])
            v = kind not in ("water", "lava", "void") and k not in self.block
            if len(self.walk_cache) > 200000: self.walk_cache.clear()     # 0.44.20: bounded (it is cheap to refill)
            self.walk_cache[k] = v
        return v

    def line_clear(self, x0, y0, x1, y1):
        d = math.hypot(x1 - x0, y1 - y0); n = int(d / .3) + 1
        for i in range(1, n + 1):
            t = i / n
            if not self.walkable(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t): return False
        return True

    def find_path(self, sx, sy, gx, gy, limit=9000):
        start = (int(sx), int(sy)); goal = (int(gx), int(gy))
        if not self.walkable(gx, gy):
            best = None
            for r in range(1, 4):
                for dx in range(-r, r + 1):
                    for dy in range(-r, r + 1):
                        c = (goal[0] + dx, goal[1] + dy)
                        if self.walkable(c[0] + .5, c[1] + .5):
                            dd = math.hypot(c[0] + .5 - sx, c[1] + .5 - sy)
                            if best is None or dd < best[0]: best = (dd, c)
                if best: break
            if not best: return None
            goal = best[1]
        openq = [(0, start)]; came = {start: None}; cost = {start: 0}; n = 0
        deadline = time.perf_counter() + .025        # 0.40.6: never freeze the game searching; fall through to the partial-path logic
        best_node = start; best_h = 1e9; partial = False
        while openq:
            _, cur = heapq.heappop(openq); n += 1
            hh = max(abs(goal[0] - cur[0]), abs(goal[1] - cur[1]))
            if hh < best_h: best_h = hh; best_node = cur
            if cur == goal or n > limit or (n & 63 == 0 and time.perf_counter() > deadline): break
            for dx, dy, c in ((1, 0, 1), (-1, 0, 1), (0, 1, 1), (0, -1, 1), (1, 1, 1.41), (1, -1, 1.41), (-1, 1, 1.41), (-1, -1, 1.41)):
                nx, ny = cur[0] + dx, cur[1] + dy
                if not self.walkable(nx + .5, ny + .5): continue
                if dx and dy and not (self.walkable(cur[0] + dx + .5, cur[1] + .5) and self.walkable(cur[0] + .5, cur[1] + dy + .5)): continue
                nc = cost[cur] + c
                if nc < cost.get((nx, ny), 1e9):
                    cost[(nx, ny)] = nc; came[(nx, ny)] = cur
                    h = max(abs(goal[0] - nx), abs(goal[1] - ny)) + .41 * min(abs(goal[0] - nx), abs(goal[1] - ny))
                    heapq.heappush(openq, (nc + h, (nx, ny)))
        if goal not in came:
            if best_node == start: return None
            goal = best_node; partial = True    # too far to search fully: head for the closest point we reached
        pts = []; c = goal
        while c is not None:
            pts.append((c[0] + .5, c[1] + .5)); c = came[c]
        pts.reverse()
        # string-pull: drop waypoints we can see past
        out = []; cx, cy = sx, sy; i = 0
        while i < len(pts):
            j = len(pts) - 1
            while j > i and not self.line_clear(cx, cy, *pts[j]): j -= 1
            out.append(pts[j]); cx, cy = pts[j]; i = j + 1
        if out and not partial: out[-1] = (gx, gy) if self.walkable(gx, gy) else out[-1]
        return out

    def water_near(self, x, y):
        """Nearest water tile within casting distance (used by fishing)."""
        if self.in_inst: return None
        for r in (1.6, 2.4, 3.2):
            for k in range(16):
                a = k / 16 * math.tau
                wx, wy = x + math.cos(a) * r, y + math.sin(a) * r
                if 0 <= wx < W and 0 <= wy < WORLD_H and gfx.tile_info(self.layout, int(wx), int(wy))[0] == "water":
                    return (wx, wy)
        return None

    def save_prefs(self):
        st = load_settings()
        st.update(brightness=round(self.brightness, 3), vol_master=self.audio.master, vol_music=self.audio.music_v, vol_sfx=self.audio.sfx_v,
                  mute=self.audio.mute, fullscreen=FULLSCREEN, display=DISPLAY, full_style=self.full_style, quality=self.quality)
        save_settings(st)

    def set_display(self, mode):
        if mode in ("full", "border"): self.full_style = mode
        start_display(mode)
        self.apply_quality(self.quality, False, False)
        self.save_prefs()
        self.msg(f"Display: {DISPLAY_NAMES[DISPLAY]}.  F11 switches between full screen and a window.", (255, 220, 120))

    def toggle_fullscreen(self):
        self.set_display("window" if FULLSCREEN else self.full_style)

    def minimize(self):
        try: pygame.display.iconify()
        except Exception: pass

    def player(self):
        return self.w.player

    def actor(self, aid):
        if aid is None: return None
        for a in self.snap["actors"]:
            if a["id"] == aid: return a
        return None

    def pdist(self, x, y):
        p = self.w.player
        return math.hypot(x - p["x"], y - p["y"])

    # ------------------------------------------------------ world map
    def _world_map_cached(self, s):
        """The relief map takes a while to paint on a 540x330 world, so it is cached on disk per world seed."""
        try: seed = self.w._meta("seed", "0")
        except Exception: seed = "0"
        path = DATA / f"worldmap_v{WORLD_VERSION}_r8_{seed}_{W}x{WORLD_H}_{s}.png"
        try:
            if path.exists():
                m = pygame.image.load(str(path)).convert()
                if m.get_size() == (W * s, WORLD_H * s):
                    trace("world map loaded from cache"); return m
        except Exception as e:
            trace(f"world map cache unreadable ({e})")
        m = self._build_world_map(s)
        try:
            for old in DATA.glob("worldmap_*.png"):
                if old != path: old.unlink()
            pygame.image.save(m, str(path))
        except Exception as e:
            trace(f"world map cache not saved ({e})")
        return m

    def _build_world_map(self, s):
        """0.41.1: the painted atlas (see worldmap.py): every tile painted, hill-shaded, with forests, peaks, road ribbons and icons."""
        return worldmap.build(self, s, loading)

    MAPC = 3        # ocean margin kept in the whole-world view (the rest is cropped so the land fills the screen)
    MG = 44          # tiles of ocean/coast drawn around the world on the big map

    def _big_map(self):
        """The world map window: the land map set on a coastline with shallows, deep sea and a few islands."""
        bm = getattr(self, "_bigmap", None)
        if bm is not None: return bm
        s = 3; MG = self.MG
        base = self._atlas
        try: seed = self.w._meta("seed", "0")
        except Exception: seed = "0"
        path = DATA / f"bigmap_v{WORLD_VERSION}_r8_{seed}_{W}x{WORLD_H}_{s}.png"
        try:
            if path.exists():
                m = pygame.image.load(str(path)).convert()
                if m.get_size() == ((W + 2 * MG) * s, (WORLD_H + 2 * MG) * s):
                    self._bigmap = m; return m
        except Exception: pass
        TWd, THd = W + 2 * MG, WORLD_H + 2 * MG
        small = pygame.Surface((TWd, THd))
        bw, bh = base.get_size()
        for gx in range(0, TWd):
            for gy in range(0, THd):
                x, y = gx - MG, gy - MG
                d = min(x, W - 1 - x, y, WORLD_H - 1 - y)
                n = (gfx.vnoise(x, y, 26, 21) - .5) * 26 + (gfx.vnoise(x, y, 9, 22) - .5) * 9
                e = d + 13 + n                       # > 0 land
                isl = gfx.vnoise(x, y, 34, 23)
                island = d < -16 and d > -MG + 6 and isl > .70 and gfx.vnoise(x, y, 11, 24) > .35
                if e > 0 or island:
                    sx_ = max(0, min(W - 1, x)); sy_ = max(0, min(WORLD_H - 1, y))
                    col = base.get_at((min(bw - 1, int(sx_ * s + 1)), min(bh - 1, int(sy_ * s + 1))))[:3]
                    if d < 0 or island:
                        # land beyond the playable edge: lowlands fading to beach
                        lo = (gfx.vnoise(x, y, 6, 25) - .5) * .30 + (gfx.vnoise(x, y, 2.4, 28) - .5) * .12
                        tint = gfx.mix((104, 146, 80), (150, 162, 96), gfx.vnoise(x, y, 11, 27))
                        col = shade(gfx.mix(col, tint, .82), .96 + lo)       # 0.41.1: no more streaks copied outward from the world edge
                    edge = e if not island else (isl - .70) * 60
                    if edge < 3.5: col = gfx.mix(col, (232, 214, 160), max(0, min(1, 1 - edge / 3.5)) * .9)   # beach
                else:
                    depth = -e if not island else 0
                    t = max(0, min(1, depth / 22))
                    col = gfx.mix((86, 168, 188), (22, 56, 104), t ** .8)
                    if depth < 2.2: col = gfx.mix(col, (214, 240, 244), .55)                           # surf
                    col = shade(col, .96 + (gfx.vnoise(x, y, 5, 26) - .5) * .12)
                small.set_at((gx, gy), col)
        m = pygame.transform.smoothscale(small, (TWd * s, THd * s))
        for gx in range(0, TWd, 2):                                       # 0.41.1: glints on the open water
            for gy in range(0, THd, 2):
                if gfx.h01(gx, gy, 31) > .22: continue
                px_, py_ = gx * s + int(gfx.h01(gx, gy, 32) * s * 2), gy * s + int(gfx.h01(gx, gy, 33) * s * 2)
                c0 = m.get_at((px_, py_))[:3]
                if c0[2] > c0[0] + 40: pygame.draw.line(m, shade(c0, 1.3), (px_, py_), (px_ + 3, py_), 1)
        # the real land is repainted at full detail on top of the coast
        ba = base.subsurface((0, 0, base.get_width() - 8, base.get_height() - 8)).convert_alpha(); F = 30
        mask = pygame.Surface(ba.get_size(), pygame.SRCALPHA); mask.fill((255, 255, 255, 0))
        for i in range(F):
            pygame.draw.rect(mask, (255, 255, 255, int(255 * (i + 1) / F)), pygame.Rect(i, i, ba.get_width() - 2 * i, ba.get_height() - 2 * i))
        ba.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        m.blit(ba, (MG * s, MG * s))
        worldmap.draw_icons(m, self.w, s, MG * s, MG * s)          # 0.44.20: town / dungeon icons only on the world map
        try:
            for old in DATA.glob("bigmap_*.png"):
                if old != path: old.unlink()
            pygame.image.save(m, str(path))
        except Exception: pass
        self._bigmap = m
        return m

    # ------------------------------------------------------ dungeons (0.12)
    _WORLD_CACHES = ("chunks", "rims", "gtiles", "gtile_partial", "placeholders", "walk_cache", "chunk_fluids", "chunk_decor")

    def set_instance(self, on):
        # 0.44.13: the open-world render caches are kept while you are in a dungeon or battleground and put back on
        # leaving, so the city draws at once instead of being rebuilt for several seconds
        was = self.in_inst; self.in_inst = on
        self.block -= getattr(self, "_inst_block", set()); self._inst_block = set()      # 0.45: the last instance's cover is not solid any more
        if on and not was:
            self._world_stash = {k: getattr(self, k) for k in self._WORLD_CACHES}
            for k in self._WORLD_CACHES:
                v = getattr(self, k); setattr(self, k, type(v)())
        elif not on and was and getattr(self, "_world_stash", None):
            for k in self._WORLD_CACHES: getattr(self, k).clear(); setattr(self, k, self._world_stash[k])
            self._world_stash = None
        else:
            for k in self._WORLD_CACHES: getattr(self, k).clear()
        self.chunk_jobs.clear()
        gfx._TILE.clear(); gfx._TILE_NR.clear()
        self.path = None; self.dest = None; self.pending = None; self.target = None; self.auto = False
        if on:
            inst = self.w.inst
            mm = pygame.Surface((W * 3, H * 3)); mm.fill((10, 10, 14))
            for (x, y), k in inst.floor.items():
                pygame.draw.rect(mm, (96, 92, 118) if k == "arena" else (70, 68, 88), (x * 3, y * 3, 3, 3))
            for (x, y) in inst.pillars: pygame.draw.rect(mm, (24, 22, 30), (x * 3, y * 3, 3, 3))
            self.inst_minimap = mm
            self.inst_walls = [(x, y, False, "Dungeon") for (x, y) in inst.walls]
            # 0.45: cover and pillars were cut out of the floor but never drawn (dark holes) - draw them as stonework and keep them solid
            from . import medieval
            pil = set(inst.pillars); arena_ = getattr(inst, "is_arena", False)
            self.inst_walls += [(x, y, False, "Cover" if arena_ else "Column", medieval.wall_mask(pil, x, y) if arena_ else (x * 7 + y) % 3) for (x, y) in pil]
            self._inst_block = set(pil); self.block |= self._inst_block
            self.inst_props = inst.props
        else:
            self.inst_walls = []; self.inst_props = []

    def draw_hazards(self):
        inst = self.snap.get("instance")
        if not inst: return
        now = self.t
        pv = inst.get("pvp")
        if pv:
            for pt in pv["points"]:
                sx, sy = self.to_screen(pt["x"], pt["y"]); rr_ = 4.6 if len(pv["points"]) > 3 else 3.4; rx = rr_ * HTW; ry = rr_ * HTH
                col = (80, 140, 255) if pt["owner"] == "blue" else (255, 90, 80) if pt["owner"] == "red" else (200, 200, 200)
                s = pygame.Surface((int(rx * 2) + 4, int(ry * 2) + 4), pygame.SRCALPHA)
                pygame.draw.ellipse(s, (*col, 60), s.get_rect()); pygame.draw.ellipse(s, (*col, 220), s.get_rect(), 3)
                screen.blit(s, (sx - rx - 2, sy - ry - 2))
                text(pt["n"], sx, sy - 10, col, F_TI, True, center=True)
            for sh in pv.get("shrines", []):
                sx, sy = self.to_screen(sh["x"], sh["y"]); rx = 2.6 * HTW; ry = 2.6 * HTH
                s = pygame.Surface((int(rx * 2) + 4, int(ry * 2) + 4), pygame.SRCALPHA)
                pulse = 40 + int(25 * math.sin(now * 3))
                pygame.draw.ellipse(s, (90, 255, 150, pulse), s.get_rect()); pygame.draw.ellipse(s, (120, 255, 170, 200), s.get_rect(), 2)
                screen.blit(s, (sx - rx - 2, sy - ry - 2))
                text("+", sx, sy - 14, (160, 255, 190), F_TI, True, center=True)
            for f in pv["flags"]:
                sx, sy = self.to_screen(f["x"], f["y"])
                col = (80, 140, 255) if f["team"] == "blue" else (255, 90, 80)
                pygame.draw.line(screen, (60, 50, 40), (sx, sy), (sx, sy - 46), 3)
                wave = math.sin(now * 6) * 3
                pygame.draw.polygon(screen, col, [(sx, sy - 46), (sx + 26, sy - 40 + wave), (sx, sy - 30)])
                pygame.draw.polygon(screen, (255, 255, 255), [(sx, sy - 46), (sx + 26, sy - 40 + wave), (sx, sy - 30)], 1)
                if not f["home"] and not f["carried"]: text("dropped", sx, sy + 4, col, F_SM, True, center=True)
        for h in inst["hazards"]:
            sx, sy = self.to_screen(h["x"], h["y"])
            k = 1 - h["left"] / h["total"]
            if h["shape"] == "circle":
                rx = h["r"] * HTW; ry = h["r"] * HTH
                if h["kind"] == "fireflash":
                    s = pygame.Surface((int(rx * 2) + 4, int(ry * 2) + 4), pygame.SRCALPHA)
                    pygame.draw.ellipse(s, (255, 150, 40, 170), s.get_rect()); screen.blit(s, (sx - rx - 2, sy - ry - 2))
                    continue
                s = pygame.Surface((int(rx * 2) + 4, int(ry * 2) + 4), pygame.SRCALPHA)
                pygame.draw.ellipse(s, (230, 50, 30, int(40 + 90 * k)), s.get_rect())
                inner = pygame.Rect(0, 0, rx * 2 * k, ry * 2 * k); inner.center = s.get_rect().center
                pygame.draw.ellipse(s, (255, 120, 40, 120), inner)
                pygame.draw.ellipse(s, (255, 80, 50, 230), s.get_rect(), 3)
                screen.blit(s, (sx - rx - 2, sy - ry - 2))
            elif h["shape"] == "safe":
                rx = h["r"] * HTW; ry = h["r"] * HTH
                s = pygame.Surface((int(rx * 2) + 6, int(ry * 2) + 6), pygame.SRCALPHA)
                pygame.draw.ellipse(s, (80, 255, 140, int(60 + 40 * math.sin(now * 8))), s.get_rect())
                pygame.draw.ellipse(s, (140, 255, 190, 240), s.get_rect(), 4)
                screen.blit(s, (sx - rx - 3, sy - ry - 3))
            elif h["shape"] == "cone":
                pts = [(sx, sy)]
                for i in range(13):
                    a = h["ang"] - h["half"] + (2 * h["half"]) * i / 12
                    wx = h["x"] + math.cos(a) * h["r"]; wy = h["y"] + math.sin(a) * h["r"]
                    pts.append(self.to_screen(wx, wy))
                s = pygame.Surface((LW, LH), pygame.SRCALPHA)
                pygame.draw.polygon(s, (255, 90, 30, int(35 + 70 * k)), pts)
                pygame.draw.polygon(s, (255, 150, 60, 220), pts, 2)
                screen.blit(s, (0, 0))
        if inst.get("mark"):
            p = self.w.player; sx, sy = self.to_screen(p["x"], p["y"])
            rr = 4.5
            pulse = 1 + .05 * math.sin(now * 14)
            rx = rr * HTW * pulse; ry = rr * HTH * pulse
            s = pygame.Surface((int(rx * 2) + 6, int(ry * 2) + 6), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (170, 60, 255, 60), s.get_rect())
            pygame.draw.ellipse(s, (200, 110, 255, 240), s.get_rect(), 3)
            screen.blit(s, (sx - rx - 3, sy - ry - 3))

    def draw_instance_hud(self):
        inst = self.snap.get("instance")
        if not inst: return
        pv = inst.get("pvp")
        if pv:
            self.draw_pvp_hud(inst, pv)
            return
        self.ui_rects["leave"] = button((LW - 330, 8, 150, 30), "Leave (O)", True, False)
        rest = inst.get("rest", 0)
        if rest and rest > 0:
            self.ui_rects["ready"] = button((LW - 170, 8, 150, 30), "Ready (N)", True, True)
            t = tsurf(f"Resting {int(rest) // 60}:{int(rest) % 60:02d} - heal, eat, loot, then press N", (150, 255, 170), F_BD, True)
            screen.blit(t, (LW // 2 - t.get_width() // 2, 100))
        # boss bar
        b = inst.get("boss")
        if b:
            w_ = 560; x = LW // 2 - w_ // 2
            frame_panel((x - 8, 8, w_ + 16, 72 if not b.get("cast") else 100), alpha=215, border=(210, 80, 60))
            text(b["name"], LW // 2, 12, (255, 220, 190), F_BD, center=True)
            col = (150, 150, 170) if b["imm"] else (200, 40, 36)
            bar(x, 34, w_, 18, b["hp"], b["maxhp"], col, f"{b['hp']:,} / {b['maxhp']:,}" + ("   IMMUNE - kill the adds!" if b["imm"] else ""))
            line = "  •  ".join(b["mechs"])
            text(line, LW // 2, 56, (210, 180, 150), F_SM, center=True)
            if b.get("enrage_left") is not None:
                col2 = (255, 90, 70) if b["enrage_left"] < 60 or b["enraged"] else (230, 200, 140)
                text(("ENRAGED!" if b["enraged"] else f"Enrage in {b['enrage_left'] // 60}:{b['enrage_left'] % 60:02d}"), x + w_, 56, col2, F_SM, right=True)
            c = b.get("cast")
            if c:
                k = 1 - c["left"] / max(.1, c["total"])
                colc = (255, 220, 80) if c["interruptible"] else (255, 120, 60)
                bar(x + 60, 76, w_ - 120, 14, k * 100, 100, colc, c["name"] + (" - INTERRUPT!" if c["interruptible"] else ""))
        # banner hint
        if inst.get("hint"):
            t = tsurf(inst["hint"], (255, 235, 140), F_CRIT, True)
            screen.blit(t, (LW // 2 - t.get_width() // 2, 130 if not b else 150))
        # mark countdown
        if inst.get("mark"):
            m = inst["mark"]
            t = tsurf(f"VOID MARK  {m['left']:.1f}s - run from your party!", (210, 140, 255), F_PL, True)
            screen.blit(t, (LW // 2 - t.get_width() // 2, 112 if not b else 176))
        # party frames
        y = 150
        text(f"{inst['name'][:30]}", 14, y - 14, (230, 200, 150), F_SM, True)
        for a in inst["party"]:
            col = {"Tank": (90, 140, 230), "Healer": (90, 210, 110), "DPS": (230, 120, 80)}.get(a["role"], (200, 200, 200))
            pygame.draw.rect(screen, (24, 22, 26), (12, y, 150, 14), border_radius=3)
            pygame.draw.rect(screen, col, (14, y + 2, 10, 10), border_radius=2)
            fw = int(122 * max(0, a["hp"]) / max(1, a["maxhp"]))
            hc = (70, 190, 90) if a["hp"] / max(1, a["maxhp"]) > .5 else (220, 170, 60) if a["hp"] / max(1, a["maxhp"]) > .25 else (220, 60, 50)
            if a["dead"]: hc = (80, 80, 84)
            pygame.draw.rect(screen, hc, (28, y + 2, fw, 10), border_radius=2)
            text(a["name"], 30, y - 1, (240, 240, 240), F_PL, True)
            y += 17
        text(f"Bosses {inst['bosses_down']}/{inst['bosses']}   Wipes {inst['wipes']}   {inst['elapsed'] // 60}:{inst['elapsed'] % 60:02d}", 14, y + 4, (200, 200, 205), F_SM, True)

    def draw_pvp_hud(self, inst, pv):
        w_ = 520; x = LW // 2 - w_ // 2
        frame_panel((x, 8, w_, 62), alpha=220, border=(210, 80, 60))
        self.ui_rects["leave"] = button((LW - 170, 8, 150, 30), "Leave (O)", True, False)
        text(pv["title"], LW // 2, 12, (255, 210, 170), F_BD, center=True)
        text(f"{pv['blue']}", LW // 2 - 80, 30, (110, 170, 255), F_BIG, center=True)
        text(f"{pv['red']}", LW // 2 + 80, 30, (255, 110, 100), F_BIG, center=True)
        tg = f"first to {pv['target']}"
        text(f"{pv['left'] // 60}:{pv['left'] % 60:02d}  -  {tg}", LW // 2, 36, PARCH, F_SM, center=True)
        text(f"Your kills {pv['pk']}  deaths {pv['pd']}", LW // 2, 52, GREY, F_SM, center=True)
        if inst.get("hint"):
            t = tsurf(inst["hint"], (255, 235, 140), F_CRIT, True); screen.blit(t, (LW // 2 - t.get_width() // 2, 96))
        if pv["protected"]: text("Respawn protection", LW // 2, 80, (140, 255, 170), F_SM, True, center=True)
        if pv.get("carry"): text(f"You carry the {pv['carry']} flag - run to your base!", LW // 2, 80, (255, 220, 90), F_BD, True, center=True)
        two = len(inst["party"]) + len(pv["foes"]) > 22          # 0.44.13: 24v24 - the two teams sit side by side and stay above the hotbar
        rh = 14 if two else 17
        def _col(title, tcol, rows, x0, foe):
            y = 150
            text(title, x0 + 2, y - 14, tcol, F_SM, True)
            for a in rows:
                pygame.draw.rect(screen, (24, 22, 26), (x0, y, 150, rh - 3), border_radius=3)
                frac = max(0, a["hp"]) / max(1, a["maxhp"])
                if foe: hc = (200, 70, 60) if not a["dead"] else (80, 80, 84)
                else:
                    hc = (70, 190, 90) if frac > .5 else (220, 170, 60) if frac > .25 else (220, 60, 50)
                    if a["dead"]: hc = (80, 80, 84)
                pygame.draw.rect(screen, hc, (x0 + 2, y + 1, int(146 * frac), rh - 7), border_radius=2)
                text(f"{a['name']} ({a['cls']})", x0 + 6, y - 2, (240, 240, 240), F_PL, True); y += rh
            return y
        y1 = _col("Your team", (140, 190, 255), inst["party"], 12, False)
        if two: _col("Enemy team", (255, 140, 130), pv["foes"], 168, True)
        if not two:
            y = y1 + 22
            text("Enemy team", 14, y - 14, (255, 140, 130), F_SM, True)
            for a in pv["foes"]:
                pygame.draw.rect(screen, (24, 22, 26), (12, y, 150, 14), border_radius=3)
                hc = (200, 70, 60) if not a["dead"] else (80, 80, 84)
                pygame.draw.rect(screen, hc, (14, y + 2, int(146 * max(0, a["hp"]) / max(1, a["maxhp"])), 10), border_radius=2)
                text(f"{a['name']} ({a['cls']})", 18, y - 1, (240, 240, 240), F_PL, True); y += 17

    def draw_city_raid(self):
        cr = self.snap.get("city_raid")
        res = self.snap.get("city_result")
        if res: self.msg(res, (255, 220, 120)); self.raid_banner = (res, self.t)
        rb = getattr(self, "raid_banner", None)
        if rb and self.t - rb[1] < 6 and not cr:
            t = tsurf(rb[0], (255, 220, 120), F_TI, True); screen.blit(t, (LW // 2 - t.get_width() // 2, 120))
        if not cr or self.snap.get("instance"): return
        r = pygame.Rect(LW // 2 - 230, 8, 460, 74)
        pygame.draw.rect(screen, (28, 14, 14), r, border_radius=8); pygame.draw.rect(screen, (210, 80, 50), r, 2, border_radius=8)
        text(f"{'ATTACKING' if cr.get('attack') else 'CITY RAID'}  -  {cr['town']}", r.centerx, r.y + 6, (255, 130, 90), F_BD, center=True)
        text(f"Wave {max(1, cr['wave'])}/{cr['waves']}   Raiders left: {cr['left']}   Adventurers: {self.snap.get('defenders', 0)}   Guards: {cr.get('defenders', 0)}   Time {cr['time'] // 60}:{cr['time'] % 60:02d}", r.centerx, r.y + 26, PARCH, F_SM, center=True)
        bar(r.x + 16, r.y + 46, r.w - 32, 16, cr["hp"], cr["maxhp"], (80, 170, 90), f"Town defence {cr['hp'] * 100 // cr['maxhp']}%")
        p = self.w.player; d = math.hypot(cr["x"] - p["x"], cr["y"] - p["y"])
        if d > 25:
            text(f"The raid is {int(d)} tiles away - press M for the map", r.centerx, r.bottom + 6, (255, 180, 120), F_SM, True, center=True)

    def draw_prompts(self):
        snap = self.snap
        dn = snap.get("dungeon_near")
        if dn:
            tag = {"heroic": "HEROIC RAID (12)", "raid": "RAID (12)", "dungeon": "Dungeon (4)"}[dn["kind"]]
            if dn["ok"]:
                msg = f"[F] Enter {dn['name']}  -  Lv {dn['level']} {tag}"; col = (255, 230, 150)
            else:
                msg = f"{dn['name']}  -  needs level {dn['need']}"; col = (255, 110, 100)
            t = tsurf(msg, col, F_BD, True); screen.blit(t, (LW // 2 - t.get_width() // 2, LH - 150))
        if not dn and not snap.get("instance"):
            hn = [h for h in snap.get("herbs", []) if self.pdist(h["x"], h["y"]) < 2.4]
            vn = [v for v in snap.get("veins", []) if self.pdist(v["x"], v["y"]) < 2.4]
            sn = [k for k in snap.get("skins", []) if self.pdist(k["x"], k["y"]) < 2.4]
            pr = (f"[F] Gather {hn[0]['name']}" if hn else f"[F] Mine {vn[0]['name']}" if vn else f"[F] Skin {sn[0]['name']}" if sn else "")
            if pr:
                t = tsurf(pr, (150, 255, 160), F_BD, True); screen.blit(t, (LW // 2 - t.get_width() // 2, LH - 150))
        if not dn and not snap.get("instance") and not any(self.pdist(h["x"], h["y"]) < 2.4 for h in snap.get("herbs", []) + snap.get("veins", []) + snap.get("skins", [])):
            try:
                if self.water_near(self.w.player["x"], self.w.player["y"]) and not snap.get("fishing"):
                    t = tsurf("[G] Fish", (150, 210, 255), F_BD, True); screen.blit(t, (LW // 2 - t.get_width() // 2, LH - 150))
            except Exception: pass
        inst = snap.get("instance")
        if inst and self.w.inst and self.w.inst.near_portal():
            t = tsurf("[F] Leave the dungeon", (190, 160, 255), F_BD, True); screen.blit(t, (LW // 2 - t.get_width() // 2, LH - 150))

    def _wh_tabs(self, r, active):
        for k, lab, x, w_, m in (("wh_pvp", "Battlegrounds", 170, 150, "pvp"), ("wh_raid", "Raids", 328, 110, "raids"), ("wh_armory", "Armory", 446, 120, "armory")):
            self.ui_rects[k] = button((r.x + x, r.y + 14, w_, 30), lab, True, active == m)

    def draw_armory(self):
        if not self.w._near_station("warhall", 9): self.mode = "world"; return
        v = self.w.armory_view()
        if v is None: self.mode = "world"; return
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 170)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 400, 40, 800, 720), alpha=240)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        text("WAR HALL", r.x + 24, r.y + 16, (255, 130, 100), F_TI)
        self._wh_tabs(r, "armory")
        c = v["cur"]
        text(f"Gold {v['gold']:,}    Raid Tokens {c['raid_tokens']}    PvP Points {c['pvp_points']}    Legendary Essence {c['legendary_essence']}", r.x + 24, r.y + 56, (255, 215, 80), F_BD)
        tab = getattr(self, "arm_tab", "pvp")
        if tab not in ("pvp", "mounts", "supply", "upg"): tab = self.arm_tab = "pvp"
        for i, (k, lab) in enumerate((("pvp", "PvP Gear"), ("mounts", "Battle Mounts"), ("supply", "Supplies"), ("upg", "Upgrade gear"))):
            self.ui_rects["armtab_" + k] = button((r.x + 24 + i * 186, r.y + 88, 178, 30), lab, True, tab == k)
        y0 = r.y + 130
        if tab == "pvp":
            # 0.45: four tiers - Recruit's (cheap), Gladiator's, Legendary Gladiator's and Mythic Gladiator's (a long grind)
            tiers = v.get("tiers") or []
            sel = getattr(self, "arm_tier", "glad")
            if sel not in [t["key"] for t in tiers]: sel = self.arm_tier = "glad"
            for i, t in enumerate(tiers):
                lab = {"recruit": "Recruit's", "glad": "Gladiator's", "legend": "Legendary", "mythic": "Mythic"}.get(t["key"], t["name"])
                self.ui_rects["armtier_" + t["key"]] = button((r.x + 24 + i * 186, y0, 178, 26), lab, True, sel == t["key"])
            t = next((t for t in tiers if t["key"] == sel), None)
            if t:
                need = f"level {t['level']}" + (f" and {t['wins']} battleground wins (you have {v.get('wins', 0)})" if t["wins"] else "")
                text(f"{t['rarity']} gear for your class - needs {need}.", r.x + 24, y0 + 34, GREY, F_SM)
                text("PvP Points: 120 per 12v12 win and 240 per 24v24 win (a loss still pays a little).", r.x + 24, r.bottom - 54, GREY, F_SM)
                y = y0 + 56
                for pc in t["rows"]:
                    box = pygame.Rect(r.x + 24, y, r.w - 48, 60)
                    rc = RARITY_COLOR.get(pc["rarity"], PARCH)
                    pygame.draw.rect(screen, (34, 28, 30), box, border_radius=6); pygame.draw.rect(screen, shade(rc, .6), box, 1, border_radius=6)
                    screen.blit(gfx.item_icon(("weapon:" + gfx.weapon_kind(pc["item"])) if pc["slot"] == "weapon" else pc["slot"], pc["rarity"], 44), (box.x + 8, box.y + 8))
                    text(pc["item"], box.x + 64, box.y + 8, rc, F_BD)
                    text(f"{pc['rarity']} {SLOT_LABEL.get(pc['slot'], pc['slot'])}   Power {pc['power']}" + (f"   -   needs {pc['why']}" if pc["why"] else ""), box.x + 64, box.y + 32,
                         (255, 150, 120) if pc["why"] else (220, 210, 200), F_SM)
                    if pc.get("set_name"): text(pc["set_name"] + " (6 pieces)", box.right - 200, box.y + 44, (60, 220, 200), F_PL, right=True)
                    if box.collidepoint(self.mouse):
                        self.tooltip = self._inv_item_lines(pc, [f"Price: {pc['cost']:,} PvP Points"] if not pc["owned"] else ["Owned"], pc["why"])
                    lab = "Owned" if pc["owned"] else f"{pc['cost']:,} PvP Points"
                    self.ui_rects[f"abuy_{pc['key']}"] = button((box.right - 190, box.y + 12, 176, 36), lab, pc["can"], pc["can"])
                    y += 66
        elif tab == "mounts":
            text("Battle mounts are the only mounts allowed in battlegrounds, and each has special powers while you ride.", r.x + 24, y0 - 2, GREY, F_SM)
            y = y0 + 22; mi = self.w.mount_info()
            for m in v.get("mounts", []):
                box = pygame.Rect(r.x + 24, y, r.w - 48, 92)
                act = mi.get("active") == m["id"]
                pygame.draw.rect(screen, (46, 38, 32) if act else (34, 28, 30), box, border_radius=6); pygame.draw.rect(screen, GOLD if act else (150, 110, 60), box, 1, border_radius=6)
                spec = dict(gfx.CLASS_SPEC.get(self.w.class_name(), gfx.CLASS_SPEC["Warrior"])); spec["cape"] = gfx.FACTION_CAPE.get(self.w.player.get("faction"))
                try:
                    spr, anc = gfx.mounted_sprite(("stb", self.w.class_name(), self.w.player.get("faction")), spec, m["look"], int(self.t * 9) % 4 if act else -1, 1, False, .5, .55, False)
                    clip = screen.get_clip(); screen.set_clip(pygame.Rect(box.x + 2, box.y + 2, 120, box.h - 4))
                    screen.blit(spr, (box.x + 62 - anc[0], box.y + 84 - anc[1])); screen.set_clip(clip)
                except Exception: pass
                text(m["name"], box.x + 130, box.y + 8, (255, 190, 120), F_BD)
                text(f"+{int(m['speed'] * 100)}% speed  -  needs {['', 'Apprentice', 'Journeyman', 'Expert', 'Master'][m['tier']]} Riding" + (f"  -  {m['why']}" if m["why"] else ""), box.x + 130, box.y + 30,
                     (255, 150, 120) if m["why"] else (220, 210, 200), F_SM)
                text(m["power"], box.x + 130, box.y + 52, (150, 220, 255), F_SM)
                if m["owned"]:
                    self.ui_rects[f"ause_{m['id']}"] = button((box.right - 190, box.y + 28, 176, 36), "Active" if act else "Use this mount", not act, False)
                else:
                    self.ui_rects[f"abuy_{m['key']}"] = button((box.right - 190, box.y + 28, 176, 36), f"{m['cost']:,} PvP Points", m["can"], m["can"])
                y += 98
        elif tab == "supply":
            text("Potions, scrolls and elixirs for PvP Points - cheap ways to spend points between big purchases.", r.x + 24, y0 - 2, GREY, F_SM)
            y = y0 + 22
            for i, su in enumerate(v.get("supplies", [])):
                col_, row_ = i % 2, i // 2
                box = pygame.Rect(r.x + 24 + col_ * 380, y + row_ * 58, 372, 52)
                pygame.draw.rect(screen, (34, 28, 30), box, border_radius=6); pygame.draw.rect(screen, (110, 90, 70), box, 1, border_radius=6)
                text(su["label"], box.x + 12, box.y + 8, PARCH, F_BD)
                text(f"Level {su['level']}+" if su["level"] > 1 else "Any level", box.x + 12, box.y + 29, GREY, F_SM)
                self.ui_rects[f"abuy_{su['key']}"] = button((box.right - 136, box.y + 10, 124, 32), f"{su['cost']} PvP", su["can"], su["can"])
        else:
            text("Epic or better gear.  Each step (+1 to +5) adds 6 power; costs Essence and Raid Tokens equal to the new level, and gold.", r.x + 24, y0 - 2, GREY, F_SM)
            y = y0 + 22
            if not v["upgrades"]:
                text("You carry no upgradeable gear yet. Clear raids and dungeons for Epic or better drops.", r.x + 24, y + 10, GREY, F_MD)
            for u in v["upgrades"]:
                box = pygame.Rect(r.x + 24, y, r.w - 48, 54)
                pygame.draw.rect(screen, (34, 28, 30), box, border_radius=6); pygame.draw.rect(screen, (90, 74, 110), box, 1, border_radius=6)
                screen.blit(gfx.item_icon(u["slot"], u["rarity"], 40), (box.x + 8, box.y + 7))
                text(u["item"] + ("  (equipped)" if u["equipped"] else ""), box.x + 58, box.y + 6, RARITY_COLOR.get(u["rarity"], PARCH), F_BD)
                text(f"{u['rarity']} {u['slot']}   Power {u['power']}", box.x + 58, box.y + 29, (220, 210, 200), F_SM)
                if box.collidepoint(self.mouse):
                    self.tooltip = self._inv_item_lines(u)
                if u["maxed"]:
                    text("MAX +5", box.right - 20, box.y + 18, (120, 255, 140), F_BD, right=True)
                else:
                    self.ui_rects[f"aupg_{u['id']}"] = button((box.right - 250, box.y + 9, 236, 36), f"+{u['n'] + 1}:  {u['ess']} Ess + {u['tok']} Tok + {u['gold']:,}g", u["can"], u["can"])
                y += 60
            if v["n_upgrades"] > len(v["upgrades"]):
                text(f"Showing your best {len(v['upgrades'])} of {v['n_upgrades']} upgradeable items.", r.x + 24, r.bottom - 54, GREY, F_SM)
        text("Where it comes from: Raid Tokens and Essence - full raid clears and won city raids.  PvP Points - battlegrounds.   Esc closes.", r.x + 24, r.bottom - 32, GREY, F_SM)

    def draw_vault(self):
        """0.35: Banker vault - safe gold and gear storage shared by every Banker."""
        v = self.w.vault_view()
        if v is None: self.mode = "world"; return
        self.dim()
        r = frame_panel((LW // 2 - 460, 40, 920, 720), alpha=240)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        text("VAULT", r.x + 24, r.y + 16, (255, 215, 80), F_TI)
        text("Gold in the vault is never lost.  Dying in the open world costs 5% of the gold you carry.  Gear is never lost.", r.x + 24, r.y + 54, GREY, F_SM)
        text(f"Carried  {v['gold']:,}g", r.x + 24, r.y + 80, PARCH, F_BD)
        text(f"In vault  {v['vault_gold']:,}g", r.x + 470, r.y + 80, (255, 215, 80), F_BD)
        for i, (lab, amt) in enumerate((("100", 100), ("1,000", 1000), ("10,000", 10000), ("All", "all"))):
            can = v["gold"] > 0
            self.ui_rects[f"vg_{amt}"] = button((r.x + 24 + i * 104, r.y + 106, 98, 30), "Deposit " + lab if i == 0 else lab, can, can and amt == "all")
            can = v["vault_gold"] > 0
            self.ui_rects[f"vg_-{amt}"] = button((r.x + 470 + i * 104, r.y + 106, 98, 30), "Take " + lab if i == 0 else lab, can, can and amt == "all")
        per = 10; top = r.y + 184
        for side, rows, x0, attr, pre, ttl in ((0, v["bag"], r.x + 24, "vb_scroll", "vs_", f"BAG  ({len(v['bag'])} items, not worn) - click to store"),
                                               (1, v["vault"], r.x + 470, "vv_scroll", "vt_", f"VAULT  ({len(v['vault'])} / {v['cap']}) - click to take")):
            text(ttl, x0, r.y + 154, GOLD, F_BD)
            sc = max(0, min(getattr(self, attr, 0), max(0, len(rows) - per))); setattr(self, attr, sc)
            if not rows:
                text("Empty." if side else "Nothing to store.", x0 + 8, top + 10, GREY, F_MD)
            for k, it in enumerate(rows[sc:sc + per]):
                box = pygame.Rect(x0, top + k * 50, 426, 46)
                hot = box.collidepoint(self.mouse)
                pygame.draw.rect(screen, (48, 40, 36) if hot else (34, 28, 30), box, border_radius=6)
                pygame.draw.rect(screen, RARITY_COLOR.get(it["rarity"], (90, 74, 110)) if hot else (80, 66, 70), box, 1, border_radius=6)
                screen.blit(gfx.item_icon(it["slot"], it["rarity"], 36), (box.x + 6, box.y + 5))
                nm = it["item"]
                while F_BD.size(nm)[0] > 330 and len(nm) > 6: nm = nm[:-1]
                if nm != it["item"]: nm = nm.rstrip() + "\u2026"
                text(nm, box.x + 50, box.y + 4, RARITY_COLOR.get(it["rarity"], PARCH), F_BD)
                text(f"{it['rarity']} {it['slot']}   Power {it['power']}", box.x + 50, box.y + 25, (200, 192, 184), F_SM)
                if hot: self.tooltip = self._inv_item_lines(it)
                text("\u2192" if side == 0 else "\u2190", box.right - 14, box.y + 12, GOLD if hot else GREY, F_BD, right=True)
                self.ui_rects[f"{pre}{it['id']}"] = box
            if len(rows) > per:
                text(f"{sc + 1}-{min(len(rows), sc + per)} of {len(rows)}  (mouse wheel)", x0, top + per * 50 + 4, GREY, F_SM)
        text("Every Banker opens the same vault.  Worn gear stays on you; take it off in the Bag (I) to store it.  Esc closes.", r.x + 24, r.bottom - 30, GREY, F_SM)

    def draw_pvp_menu(self):
        from . import arena as A
        snap = self.snap; ps = snap["pvp_status"]
        if not self.w._near_station("warhall", 9): self.mode = "world"; return
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 170)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 400, 40, 800, 720), alpha=240)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        self._wh_tabs(r, "pvp")
        text("WAR HALL", r.x + 24, r.y + 16, (255, 130, 100), F_TI)
        text(f"{ps['rank']}  -  rating {ps['rating']}   Wins {ps['wins']}   Losses {ps['losses']}", r.x + 24, r.y + 54, (230, 210, 255), F_BD)
        iw_ = r.w - 48; yy_ = r.y + 80
        for ln_ in self.wrap("12v12 or 24v24, fought in person on large maps. Your AI team-mates and the enemy are level-matched to you. Level 5+. Stand on a shrine to heal.", F_SM, iw_):
            text(ln_, r.x + 24, yy_, GREY, F_SM); yy_ += 15
        lv_ = self.w.player["level"]
        if lv_ < 5:
            msg_ = f"Battlegrounds unlock at level 5 - you are level {lv_}. Level up first (the Quick simulated matches below work at any level)."
        else:
            pn_ = getattr(self, "pvp_note", None)
            msg_ = pn_[0] if pn_ and self.t - pn_[1] < 8 else ""
        if msg_:
            for ln_ in self.wrap(msg_, F_BD, iw_):
                text(ln_, r.x + 24, yy_ + 2, (255, 120, 100), F_BD); yy_ += 17
        y = max(r.y + 116, yy_ + 8)
        for key, cfg in A.MODES.items():
            box = pygame.Rect(r.x + 24, y, r.w - 48, 62)
            pygame.draw.rect(screen, (34, 28, 30), box, border_radius=6); pygame.draw.rect(screen, (150, 70, 60), box, 1, border_radius=6)
            text(cfg["title"], box.x + 14, box.y + 6, (255, 190, 150), F_BD)
            text(cfg["desc"], box.x + 14, box.y + 26, (220, 210, 200), F_SM)
            text(f"{cfg['time'] // 60} min limit  -  win: gold, XP, PvP points, rating, sometimes a prize  -  healing shrines on the map", box.x + 14, box.y + 43, GREY, F_SM)
            self.ui_rects["arena_" + key] = button((box.right - 130, box.y + 14, 114, 34), "Enter", True, True)
            y += 68
        self.ui_rects["quicksim"] = button((r.x + 24, r.bottom - 52, 220, 34), "Quick simulated 12v12", True, False)
        self.ui_rects["quicksim12"] = button((r.x + 256, r.bottom - 52, 230, 34), "Quick simulated 24v24", True, False)
        text("Esc closes", r.right - 24, r.bottom - 40, GREY, F_SM, right=True)

    def draw_raids(self):
        if not self.w._near_station("warhall", 9): self.mode = "world"; return
        v = self.w.warhall_view()
        if v is None: self.mode = "world"; return
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 170)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 400, 40, 800, 720), alpha=240)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        self._wh_tabs(r, "raids")
        text("WAR HALL", r.x + 24, r.y + 16, (255, 130, 100), F_TI)
        text(f"Gold {v['gold']:,}", r.x + 24, r.y + 56, (255, 215, 80), F_BD)
        text("CITY RAIDS", r.x + 24, r.y + 90, GOLD, F_BD)
        cr = v["city_raid"]; box = pygame.Rect(r.x + 24, r.y + 114, r.w - 48, 110)
        pygame.draw.rect(screen, (34, 28, 30), box, border_radius=6); pygame.draw.rect(screen, (150, 70, 60), box, 1, border_radius=6)
        if cr:
            text(f"{cr['town']} ({cr.get('fac', '')}) is under {cr.get('att', '')} assault!   Wave {cr['wave']}/{cr['waves']}   Raiders left {cr['left']}   {cr['time'] // 60}:{cr['time'] % 60:02d} remaining", box.x + 14, box.y + 10, (255, 190, 150), F_BD)
            bar(box.x + 14, box.y + 38, box.w - 28, 16, cr["hp"], cr["maxhp"], (60, 170, 80), f"Gate strength {cr['hp']} / {cr['maxhp']}")
            text("Your side is attacking: go there and cut down the City Watch. Reward if the city falls (gold, XP, Raid Token, Essence)." if cr.get("attack") else
                 "Run there and kill raiders - you must take part to earn the reward (gold, XP, Raid Token, Essence, elite loot).", box.x + 14, box.y + 64, GREY, F_SM)
            text(f"Location: {self.w._where(cr['x'], cr['y'])}   -   {cr.get('defense', '')} ({cr.get('defenders', 0)} guards left)", box.x + 14, box.y + 84, (200, 210, 255), F_SM)
            if cr.get("caller"):
                self.ui_rects["raidoff"] = button((box.right - 190, box.y + 6, 176, 26), "Call off the raid", True, False)
        elif v.get("muster"):
            mu = v["muster"]; mm_, ss_ = mu["left"] // 60, mu["left"] % 60
            text(f"MUSTERING: {mu['att']} warband vs {mu['name']} ({mu['fac']}) - marches in {mm_}:{ss_:02d}", box.x + 14, box.y + 10, (255, 210, 140), F_BD)
            text(f"{'Defend' if mu['role'] == 'defend' else 'Attack'}  -  {mu['where']}  -  warband {mu['count']}/{mu['cap']} (empty places are filled with volunteers when it marches)", box.x + 14, box.y + 36, (220, 210, 200), F_SM)
            if mu["joined"]:
                text("You are in the warband.", box.x + 14, box.y + 70, (150, 240, 160), F_BD)
                self.ui_rects["raidleave"] = button((box.right - 230, box.y + 64, 216, 32), "Cancel the muster (half refund)" if mu.get("caller") else "Leave the warband", True, False)
            else:
                self.ui_rects["raidjoin"] = button((box.x + 14, box.y + 62, 200, 34), "Join the warband", not mu["full"], True)
                if mu["full"]: text("Full - a place may open.", box.x + 230, box.y + 70, (255, 180, 120), F_SM)
        else:
            text("No city is under attack right now. Raids also happen on their own every so often.", box.x + 14, box.y + 12, (220, 210, 200), F_SM)
            text(f"Send your side's warband against the nearest enemy town (level 10+) - {v['cost']} gold. Help sack it for gold, XP and Raid Tokens.", box.x + 14, box.y + 34, GREY, F_SM)
            ok = v["can_call"] and v["gold"] >= v["cost"] and v["level"] >= 10
            self.ui_rects["callraid"] = button((box.x + 14, box.y + 62, 230, 34), f"Call a city raid ({v['cost']}g)", ok, ok)
        text("RAID DUNGEONS (12 players with AI allies) - nearest first", r.x + 24, r.y + 246, GOLD, F_BD)
        y = r.y + 272
        for d in v["raids"]:
            b2 = pygame.Rect(r.x + 24, y, r.w - 48, 52)
            pygame.draw.rect(screen, (30, 28, 34), b2, border_radius=6); pygame.draw.rect(screen, (90, 74, 110), b2, 1, border_radius=6)
            tag = "HEROIC RAID" if d["kind"] == "heroic" else "RAID"
            text(d["name"], b2.x + 14, b2.y + 6, (255, 190, 120), F_BD)
            text(f"{tag}  -  level {d['level']}", b2.x + 14, b2.y + 28, (220, 210, 200), F_SM)
            text(d["where"], b2.right - 16, b2.y + 18, (200, 210, 255), F_SM, right=True)
            y += 58
        text("Walk to a raid portal and press F to enter, and F again at the exit to leave.   Esc closes.", r.x + 24, r.bottom - 32, GREY, F_SM)

    # ------------------------------------------------------ 0.38 Skill Shop
    MAGIC_TABS = (("spells", "Spells"), ("hotbar", "Hotbar"), ("passives", "Passives"), ("stats", "Stats"))

    def draw_magic(self):
        w_ = self.w
        if not w_.at_magic_shop(): self.mode = "world"; return
        snap = self.snap; p = snap["player"]; mx, my = self.mouse; bd = snap.get("build", {})
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 170)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 470, max(16, LH // 2 - 375), 940, min(750, LH - 32)), alpha=244, border=(150, 110, 230))
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        text("SKILL SHOP", r.x + 24, r.y + 14, (200, 170, 255), F_TI)
        text(f"Gold {p['gold']:,}", r.right - 116, r.y + 20, (255, 215, 80), F_BD, right=True)
        tab = getattr(self, "magic_tab", "spells")
        for i, (key, lab) in enumerate(self.MAGIC_TABS):
            rr = pygame.Rect(r.x + 24 + i * 140, r.y + 52, 132, 30)
            self.ui_rects["mt_" + key] = button(rr, lab, True, tab == key)
        y0 = r.y + 98
        if tab == "spells":
            left = bd.get("rank_left", 0)
            text(f"Spell points: {left}", r.x + 24, y0, (255, 215, 80) if left else GREY, F_BD)
            text("Each rank costs 1 spell point plus gold.  Ranks 2-5: +10% power, -4% cooldown;  ranks 6-10: +6% power, -2% cooldown.", r.x + 150, y0 + 2, GREY, F_SM)
            for i, ab in enumerate(snap["abilities"]):
                x = r.x + 24 + (i // 8) * 450; y = y0 + 28 + (i % 8) * 72
                screen.blit(gfx.ability_icon(ab, 40), (x, y))
                if ab.get("locked"):
                    o = pygame.Surface((40, 40), pygame.SRCALPHA); o.fill((0, 0, 0, 170)); screen.blit(o, (x, y))
                key_ = ab["slot"] if ab["slot"] in "1234567890" else "\u21e7" + str("!@#$%^".index(ab["slot"]) + 1)
                text(f"[{key_}] {ab['name']}", x + 50, y, PARCH if not ab.get("locked") else GREY, F_BD)
                rk = ab.get("rank", 1)
                if ab.get("locked"):
                    text(f"Unlocks at level {ab['unlock']}", x + 50, y + 18, (255, 120, 100), F_SM)
                else:
                    text(f"Rank {rk}/{MAX_RANK_UI}", x + 50, y + 18, (255, 215, 80), F_SM)
                    if rk < MAX_RANK_UI:
                        cost = w_.rank_cost(ab, rk)
                        text(f"Next: 1 point + {cost:,}g", x + 140, y + 18, GREY, F_SM)
                        rr = pygame.Rect(x + 360, y + 4, 60, 30)
                        can = left > 0 and p["gold"] >= cost
                        self.ui_rects["rank_" + ab["name"]] = button(rr, "+1", can, can)
                    else:
                        text("Maximum rank", x + 140, y + 18, (120, 255, 140), F_SM)
                ds = ab.get("desc", "")
                while F_SM.size(ds)[0] > 400 and len(ds) > 8: ds = ds[:-2].rstrip(" .,") + "\u2026" if not ds.endswith("\u2026") else ds[:-2] + "\u2026"
                text(ds, x + 50, y + 36, (200, 200, 205), F_SM)
        elif tab == "hotbar":
            text("Click a slot, then another slot, to swap the two skills (free).  Cooldowns move with the skill.", r.x + 24, y0, GREY, F_SM)
            sel = getattr(self, "magic_sel", None)
            abl = snap["abilities"]
            for i, ab in enumerate(abl):
                row = 0 if i < 10 else 1
                x = r.x + 40 + (i if i < 10 else i - 10) * 86 + (14 if (i >= 6 and i < 10) else 0); y = y0 + 40 + row * 130
                rr = pygame.Rect(x, y, 64, 64)
                screen.blit(gfx.ability_icon(ab, 64), rr)
                if ab.get("locked"):
                    o = pygame.Surface((64, 64), pygame.SRCALPHA); o.fill((0, 0, 0, 170)); screen.blit(o, rr)
                    text(f"Lv{ab['unlock']}", rr.centerx, rr.centery - 8, (220, 220, 220), F_BD, True, center=True)
                col = (120, 230, 255) if sel == ab["slot"] else ((90, 170, 230) if ab["cat"] == "defense" else GOLD)
                pygame.draw.rect(screen, col, rr.inflate(4, 4), 3 if sel == ab["slot"] else 1, border_radius=6)
                key_ = ab["slot"] if ab["slot"] in "1234567890" else "Shift+" + str("!@#$%^".index(ab["slot"]) + 1)
                text(key_, rr.centerx, rr.bottom + 6, PARCH, F_SM, True, center=True)
                nm = ab["name"] if F_SM.size(ab["name"])[0] <= 84 else ab["name"][:11] + "\u2026"
                text(nm, rr.centerx, rr.bottom + 22, GREY, F_SM, center=True)
                self.ui_rects["slot_" + ab["slot"]] = rr
            text("Keys 1-6 and 7-0 are the main bar;  Shift+1-6 is the row above it.", r.x + 24, y0 + 300, GREY, F_SM)
        elif tab == "passives":
            n = w_.passive_slots(); ps = snap.get("passives", [])
            psel = min(getattr(self, "magic_pslot", 0), max(0, n - 1))
            cost = w_.passive_cost()
            text(f"Passive slots: {n} of 2   (1 slot up to level 50, 2 from level 51)   \u2022   changing a passive costs {cost:,}g", r.x + 24, y0, GREY, F_SM)
            eq = {q["slot"]: q for q in ps if q.get("active")}
            for s_ in range(2):
                rr = pygame.Rect(r.x + 24 + s_ * 300, y0 + 26, 288, 44)
                pygame.draw.rect(screen, (34, 26, 46) if s_ < n else (24, 22, 26), rr, border_radius=8)
                pygame.draw.rect(screen, (150, 110, 230) if (s_ == psel and s_ < n) else (80, 70, 90), rr, 2 if s_ == psel else 1, border_radius=8)
                if s_ < n:
                    q = eq.get(s_)
                    text(f"Slot {s_ + 1}", rr.x + 10, rr.y + 4, GOLD, F_SM)
                    text(q["name"] if q else "(empty)", rr.x + 10, rr.y + 20, PARCH if q else GREY, F_BD)
                    self.ui_rects[f"pslot_{s_}"] = rr
                else:
                    text(f"Slot {s_ + 1}", rr.x + 10, rr.y + 4, GREY, F_SM)
                    text("Opens at level 51", rr.x + 10, rr.y + 20, GREY, F_BD)
            for i, q in enumerate(ps):
                y = y0 + 90 + i * 66
                row = pygame.Rect(r.x + 24, y, r.w - 48, 58)
                pygame.draw.rect(screen, (28, 24, 32), row, border_radius=8)
                c = (120, 255, 140) if q.get("active") else ((200, 170, 255) if q.get("unlocked") else GREY)
                pygame.draw.rect(screen, shade(c, .5), row, 1, border_radius=8)
                pygame.draw.circle(screen, shade(c, .4), (row.x + 28, row.centery), 18); pygame.draw.circle(screen, c, (row.x + 28, row.centery), 18, 2)
                text("P", row.x + 28, row.centery - 8, c, F_BD, center=True)
                text(q["name"], row.x + 58, row.y + 8, PARCH if q.get("unlocked") else GREY, F_BD)
                text(q["desc"], row.x + 58, row.y + 30, c, F_SM)
                if q.get("active"):
                    text(f"Active in slot {q['slot'] + 1}", row.right - 20, row.y + 20, (120, 255, 140), F_BD, right=True)
                elif not q.get("unlocked"):
                    text(f"Unlocks at level {q['unlock']}", row.right - 20, row.y + 20, (255, 120, 100), F_SM, right=True)
                elif n > 0:
                    can = p["gold"] >= cost
                    self.ui_rects["peq_" + q["name"]] = button((row.right - 220, row.y + 14, 200, 30), f"Equip in slot {psel + 1} ({cost:,}g)", can, can)
        else:
            left = bd.get("stat_left", 0); st = bd.get("s", {})
            text(f"Stat points to spend: {left}", r.x + 24, y0, (255, 215, 80) if left else GREY, F_BD)
            text("3 stat points every level.  Each point also costs a little gold, rising slowly with the points you have spent.", r.x + 250, y0 + 2, GREY, F_SM)
            rows = (("str", "Strength", (230, 110, 80), "+0.8% damage per point"),
                    ("agi", "Agility", (120, 220, 120), "+0.25% crit chance and +0.2% run speed per point"),
                    ("int", "Intellect", (110, 160, 255), "+0.5% healing and shields, \u22120.4% mana cost, +1% mana regeneration per point"),
                    ("vit", "Vitality", (240, 200, 90), "+8 maximum health per point"))
            y = y0 + 30
            for key, nm, col, desc in rows:
                row = pygame.Rect(r.x + 24, y, r.w - 48, 66)
                pygame.draw.rect(screen, (28, 24, 30), row, border_radius=8); pygame.draw.rect(screen, shade(col, .5), row, 1, border_radius=8)
                pygame.draw.circle(screen, shade(col, .5), (row.x + 32, row.centery), 22); pygame.draw.circle(screen, col, (row.x + 32, row.centery), 22, 3)
                text(str(st.get(key, 0)), row.x + 32, row.centery - 10, (255, 255, 255), F_BD, True, center=True)
                text(nm, row.x + 70, row.y + 8, PARCH, F_TI)
                text(desc, row.x + 70, row.y + 40, GREY, F_SM)
                for k, n in enumerate((1, 5)):
                    nn = min(n, left); cost = w_.stat_cost(max(1, nn))
                    can = left > 0 and p["gold"] >= cost
                    self.ui_rects[f"stat_{key}_{n}"] = button((row.right - 250 + k * 120, row.centery - 15, 112, 30), f"+{n} ({cost:,}g)", can, can)
                y += 74
            cost = w_.reset_cost(); can = p["gold"] >= cost
            text("Reset clears stats, spell ranks, passive choices and the hotbar layout, and gives every point back.", r.x + 24, y + 10, GREY, F_SM)
            self.ui_rects["reset"] = button((r.x + 24, y + 32, 300, 32), f"Reset build ({cost:,}g)", can)

    def magic_click(self, pos):
        w_ = self.w
        for k, rr in self.ui_top():
            if not rr.collidepoint(pos): continue
            if k == "close": self.mode = "world"
            elif k.startswith("mt_"): self.magic_tab = k[3:]; self.magic_sel = None
            elif k.startswith("rank_"): self.msg(w_.rank_up(k[5:]), (200, 170, 255))
            elif k.startswith("slot_"):
                s_ = k[5:]
                if self.magic_sel is None: self.magic_sel = s_
                elif self.magic_sel == s_: self.magic_sel = None
                else: self.msg(w_.swap_slots(self.magic_sel, s_), (200, 170, 255)); self.magic_sel = None
            elif k.startswith("pslot_"): self.magic_pslot = int(k[6:])
            elif k.startswith("peq_"): self.msg(w_.equip_passive(k[4:], getattr(self, "magic_pslot", 0)), (200, 170, 255))
            elif k.startswith("stat_"):
                _, stat, n = k.split("_"); self.msg(w_.add_stat(stat, int(n)), (200, 170, 255))
            elif k == "reset": self.msg(w_.reset_build(), (200, 170, 255))
            return

    # ------------------------------------------------------ 0.39 Jeweler's Kiln
    KILN_TABS = (("cut", "Cut Jewels"), ("jewelry", "Rings & Necklaces"), ("socket", "Socket Gear"))

    def draw_kiln(self):
        v = self.w.kiln_view()
        if not v["ok"]: self.mode = "world"; return
        mx, my = self.mouse
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 170)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 470, max(16, LH // 2 - 375), 940, min(750, LH - 32)), alpha=244, border=(90, 200, 220))
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        text("JEWELER'S KILN", r.x + 24, r.y + 14, (140, 230, 245), F_TI)
        text(f"Gold {v['gold']:,}   Ore {v['ore']}   Dust {v['dust']}   Essence {v['essence']}", r.right - 116, r.y + 20, (255, 215, 80), F_BD, right=True)
        tab = getattr(self, "kiln_tab", "cut")
        for i, (key, lab) in enumerate(self.KILN_TABS):
            self.ui_rects["kt_" + key] = button((r.x + 24 + i * 180, r.y + 52, 172, 30), lab, True, tab == key)
        y0 = r.y + 98; per = 9; self.kiln_scroll = max(0, self.kiln_scroll)
        if tab == "cut":
            text("Cut jewels from Iron Ore (mining), Arcane Dust and gold. Better qualities unlock with your level.  Wheel scrolls.", r.x + 24, y0, GREY, F_SM)
            rows = [c for c in v["cuts"] if not c["locked"]] + [c for c in v["cuts"] if c["locked"]][:5]
            self.kiln_scroll = min(self.kiln_scroll, max(0, len(rows) - per))
            for i, c in enumerate(rows[self.kiln_scroll:self.kiln_scroll + per]):
                y = y0 + 26 + i * 66; row = pygame.Rect(r.x + 24, y, r.w - 48, 58)
                pygame.draw.rect(screen, (24, 30, 34), row, border_radius=8); pygame.draw.rect(screen, (60, 110, 120), row, 1, border_radius=8)
                screen.blit(gfx.item_icon("jewel:" + c["gem"], gfx_jewel_rarity(c["qi"]), 44), (row.x + 8, row.y + 7))
                text(f"{c['quality']} {c['gem']}", row.x + 62, row.y + 6, PARCH if not c["locked"] else GREY, F_BD)
                text(f"{c['bonus']}   \u2022   you have {c['have']}", row.x + 62, row.y + 26, (140, 220, 240), F_SM)
                text(f"{c['ore']} Iron Ore" + (f", {c['dust']} Arcane Dust" if c["dust"] else "") + f", {c['gold']:,}g", row.right - 360, row.y + 8, GREY, F_SM)
                if c["why"]: text(c["why"], row.right - 360, row.y + 28, (255, 120, 100), F_SM)
                self.ui_rects["cut_" + c["key"]] = button((row.right - 120, row.y + 14, 104, 30), "Cut", c["can"], c["can"])
                if row.collidepoint(mx, my):
                    self.tooltip = self._recipe_lines({"name": f"{c['quality']} {c['gem']}", "rarity": gfx_jewel_rarity(c["qi"]), "bonus": c["bonus"], "why": c["why"],
                                                       "needs": [("Iron Ore", v["ore"], c["ore"])] + ([("Arcane Dust", v["dust"], c["dust"])] if c["dust"] else []), "gold": c["gold"]},
                                                      [f"You have {c['have']}"])
        elif tab == "jewelry":
            text("Rings (you wear two) and necklaces carry their jewel's bonus: rings 1.5x, necklaces 2x.  Each uses one jewel.", r.x + 24, y0, GREY, F_SM)
            rows = [c for c in v["jewelry"] if not c["locked"]]
            self.kiln_scroll = min(self.kiln_scroll, max(0, len(rows) - per))
            for i, c in enumerate(rows[self.kiln_scroll:self.kiln_scroll + per]):
                y = y0 + 26 + i * 66; row = pygame.Rect(r.x + 24, y, r.w - 48, 58)
                pygame.draw.rect(screen, (24, 30, 34), row, border_radius=8); pygame.draw.rect(screen, (60, 110, 120), row, 1, border_radius=8)
                screen.blit(gfx.item_icon(c["slot"], c["rarity"], 44), (row.x + 8, row.y + 7))
                text(c["name"], row.x + 62, row.y + 6, RARITY_COLOR.get(c["rarity"], PARCH), F_BD)
                text(f"{c['bonus']}   \u2022   {SLOT_LABEL[c['slot']]}", row.x + 62, row.y + 26, (140, 220, 240), F_SM)
                text(f"1 jewel, {c['ore']} Iron Ore, {c['gold']:,}g", row.right - 360, row.y + 8, GREY, F_SM)
                if c["why"]: text(c["why"], row.right - 360, row.y + 28, (255, 120, 100), F_SM)
                self.ui_rects["jw_" + c["key"]] = button((row.right - 120, row.y + 14, 104, 30), "Craft", c["can"], c["can"])
                if row.collidepoint(mx, my):
                    self.tooltip = self._recipe_lines({"name": c["name"], "rarity": c["rarity"], "slot": c["slot"], "bonus": c["bonus"], "why": c["why"],
                                                       "needs": [("Iron Ore", v["ore"], c["ore"])], "gold": c["gold"]}, ["Uses 1 jewel"])
        else:
            gear = v["gear"]
            text("Pick any piece of gear: open sockets (up to 3), then set jewels into them.  Prying a jewel out destroys it.", r.x + 24, y0, GREY, F_SM)
            if not gear: text("Your bag is empty.", r.x + 24, y0 + 30, GREY, F_BD)
            sel = getattr(self, "kiln_sel", None)
            if sel not in [g["id"] for g in gear]: sel = self.kiln_sel = gear[0]["id"] if gear else None
            self.kiln_scroll = min(self.kiln_scroll, max(0, len(gear) - 8))
            for i, g in enumerate(gear[self.kiln_scroll:self.kiln_scroll + 8]):
                rr = pygame.Rect(r.x + 24, y0 + 26 + i * 72, 430, 64)
                pygame.draw.rect(screen, (30, 40, 46) if g["id"] == sel else (24, 30, 34), rr, border_radius=8)
                pygame.draw.rect(screen, (120, 220, 240) if g["id"] == sel else (60, 110, 120), rr, 2 if g["id"] == sel else 1, border_radius=8)
                screen.blit(gfx.item_icon(g["slot"], g["rarity"], 44), (rr.x + 8, rr.y + 10))
                text(g["item"][:34], rr.x + 62, rr.y + 6, RARITY_COLOR.get(g["rarity"], PARCH), F_BD)
                text(("Worn  \u2022  " if g["equipped"] else "") + SLOT_LABEL.get(g["slot"], g["slot"]), rr.x + 62, rr.y + 26, GREY, F_SM)
                for k in range(g["sockets"]):
                    cx_ = rr.right - 24 - (g["sockets"] - 1 - k) * 28; cy_ = rr.y + 32
                    if k < len(g["gems"]):
                        screen.blit(gfx.item_icon("jewel:" + g["gems"][k].split()[1], "Rare", 12), (cx_ - 12, cy_ - 12))
                    else:
                        pygame.draw.circle(screen, (70, 84, 96), (cx_, cy_), 10, 2)
                self.ui_rects[f"ksel_{g['id']}"] = rr
                if rr.collidepoint(self.mouse): self.tooltip = self._inv_item_lines(g)
            g = next((x for x in gear if x["id"] == sel), None)
            if g:
                x0 = r.x + 480; y = y0 + 26
                text(g["item"], x0, y, RARITY_COLOR.get(g["rarity"], PARCH), F_BD); y += 26
                nx_ = g.get("next")
                if nx_:
                    cost_ = f"Lv {nx_['level']}  \u2022  {nx_['ore']} Ore, {nx_['dust']} Dust" + (f", {nx_['essence']} Essence" if nx_["essence"] else "") + f", {nx_['gold']:,}g"
                    self.ui_rects[f"kadd_{g['id']}"] = button((x0, y, 200, 30), f"Open socket {g['sockets'] + 1}", nx_["can"], nx_["can"])
                    text(cost_, x0 + 210, y + 2, GREY, F_SM)
                    if nx_["why"]: text(nx_["why"], x0 + 210, y + 17, (255, 120, 100), F_SM)
                    y += 40
                else:
                    text("All 3 sockets open.", x0, y, (120, 255, 140), F_SM); y += 24
                for k in range(g["sockets"]):
                    if k < len(g["gems"]):
                        text(f"Socket {k + 1}: {g['gems'][k]}", x0, y + 6, (150, 220, 255), F_SM)
                        self.ui_rects[f"kun_{g['id']}_{k}"] = button((x0 + 260, y, 160, 28), "Pry out (destroys it)", True, False)
                    else:
                        text(f"Socket {k + 1}: empty", x0, y + 6, GREY, F_SM)
                    y += 34
                free = len(g["gems"]) < g["sockets"]
                y += 8; text("YOUR JEWELS", x0, y, GOLD, F_BD); y += 24
                if not v["jewels"]: text("You have no jewels - cut some first.", x0, y, GREY, F_SM)
                for j, (nm, q) in enumerate(sorted(v["jewels"].items())):
                    if y > r.bottom - 50: break
                    screen.blit(gfx.item_icon("jewel:" + nm.split()[1], "Rare", 14), (x0, y))
                    text(f"{nm}  x{q}", x0 + 34, y + 6, PARCH, F_SM)
                    if free: self.ui_rects[f"kso_{g['id']}|{nm}"] = button((x0 + 260, y, 160, 28), "Set into socket", True, True)
                    y += 34

    def kiln_click(self, pos):
        w_ = self.w
        for k, rr in self.ui_top():
            if not rr.collidepoint(pos): continue
            if k == "close": self.mode = "world"
            elif k.startswith("kt_"): self.kiln_tab = k[3:]; self.kiln_scroll = 0
            elif k.startswith("cut_"): self.msg(w_.cut_jewel(k[4:]), (140, 230, 245))
            elif k.startswith("jw_"): self.msg(w_.craft_jewelry(k[3:]), (140, 230, 245))
            elif k.startswith("ksel_"): self.kiln_sel = int(k[5:])
            elif k.startswith("kadd_"): self.msg(w_.add_socket(int(k[5:])), (140, 230, 245))
            elif k.startswith("kso_"):
                gid, _, nm = k[4:].partition("|"); self.msg(w_.socket_jewel(int(gid), nm), (140, 230, 245))
            elif k.startswith("kun_"):
                _, gid, idx = k.split("_"); self.msg(w_.unsocket_jewel(int(gid), int(idx)), (255, 160, 120))
            return

    def draw_stable(self):
        from .mounts import MOUNTS, MOUNT_ORDER, RIDING
        mi = self.w.mount_info(); p = self.snap["player"]
        if not mi["near_stable"]: self.mode = "world"; return
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 170)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 470, 40, 940, 720), alpha=242)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        text("STABLE MASTER", r.x + 24, r.y + 14, (255, 215, 90), F_TI)
        text(f"Gold {p['gold']:,}", r.right - 120, r.y + 50, (255, 215, 80), F_BD, right=True)
        text("Train riding, then buy a mount. Press X anywhere outside to mount.  Tier 3-4 mounts can FLY (not in battlegrounds).", r.x + 24, r.y + 50, GREY, F_SM)
        # riding training
        text("RIDING TRAINING", r.x + 24, r.y + 78, GOLD, F_BD)
        for i, (t, (name, lvl, price, desc)) in enumerate(RIDING.items()):
            rr = pygame.Rect(r.x + 24 + i * 226, r.y + 98, 218, 74)
            know = mi["riding"] >= t; can = mi["riding"] == t - 1 and p["level"] >= lvl and p["gold"] >= price
            pygame.draw.rect(screen, (40, 52, 40) if know else (34, 30, 32), rr, border_radius=7)
            pygame.draw.rect(screen, (90, 190, 100) if know else (90, 74, 52), rr, 1, border_radius=7)
            text(name, rr.x + 10, rr.y + 6, (140, 240, 150) if know else PARCH, F_BD)
            text("Learned" if know else f"Lv {lvl}  •  {price:,} g", rr.x + 10, rr.y + 26, GREY if know else (255, 215, 90), F_SM)
            if not know:
                self.ui_rects[f"ride_{t}"] = button((rr.right - 78, rr.y + 40, 70, 26), "Train", can, can)
        # mounts
        text("MOUNTS", r.x + 24, r.y + 188, GOLD, F_BD)
        for i, mid in enumerate(MOUNT_ORDER):
            m = MOUNTS[mid]; col, row = i % 4, i // 4
            rr = pygame.Rect(r.x + 24 + col * 226, r.y + 206 + row * 168, 218, 162)
            own = mid in mi["owned"]; act = mi["active"] == mid
            pygame.draw.rect(screen, (46, 38, 32) if act else (34, 30, 32), rr, border_radius=7)
            pygame.draw.rect(screen, GOLD if act else (90, 74, 52), rr, 2 if act else 1, border_radius=7)
            spec = dict(gfx.CLASS_SPEC.get(self.w.class_name(), gfx.CLASS_SPEC["Warrior"])); spec["cape"] = gfx.FACTION_CAPE.get(p.get("faction"))
            fl = m["fly"]; fr = (int(self.t * 7) % 4) if fl else (int(self.t * 9) % 4 if act else -1)
            spr, anc = gfx.mounted_sprite(("stb", self.w.class_name(), p.get("faction")), spec, m["look"], fr, 1, False, .6, .65, fl)
            clip = screen.get_clip(); screen.set_clip(rr.inflate(-4, -4))
            screen.blit(spr, (rr.centerx - anc[0], rr.y + 84 - anc[1] - (8 if fl else 0))); screen.set_clip(clip)
            text(m["name"], rr.centerx, rr.y + 92, GOLD if act else PARCH, F_BD, center=True)
            tier_name = RIDING[m["tier"]][0]
            text(("Flying" if fl else "Ground") + f" • +{int(m['speed'] * 100)}% speed", rr.centerx, rr.y + 110, (150, 210, 255) if fl else GREY, F_SM, center=True)
            text(f"Needs {tier_name}", rr.centerx, rr.y + 126, (140, 240, 150) if mi["riding"] >= m["tier"] else (255, 130, 110), F_SM, center=True)
            if own:
                self.ui_rects[f"use_{mid}"] = button((rr.centerx - 60, rr.y + 132, 120, 28), "Active" if act else "Use this mount", not act, False)
            else:
                ok = p["gold"] >= m["price"]
                self.ui_rects[f"buy_{mid}"] = button((rr.centerx - 70, rr.y + 132, 140, 28), f"Buy  {m['price']:,} g", ok, ok)

    def draw_market(self):
        v = self.w.market_view()
        if v is None: self.mode = "world"; return
        tab = getattr(self, "mk_tab", "buy"); rows = v[tab]
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 170)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 420, 70, 840, 620), alpha=240)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        text(f"MARKET OF {v['town'].upper()}", r.x + 24, r.y + 16, (255, 215, 90), F_TI)
        text(f"Gold {v['gold']:,}", r.right - 120, r.y + 52, (255, 215, 80), F_BD, right=True)
        text("Prices shift every couple of days. Selling a lot of one good lowers its price here.", r.x + 24, r.y + 52, GREY, F_SM)
        for i, (k, lab) in enumerate((("buy", "Buy"), ("sell", "Sell"))):
            self.ui_rects["tab_" + k] = button((r.x + 24 + i * 110, r.y + 80, 100, 30), lab, True, tab == k)
        per = 11; self.mk_scroll = max(0, min(self.mk_scroll, max(0, len(rows) - per)))       # 11 rows fit above the scroll note
        y = r.y + 124
        if not rows: text("Nothing here." if tab == "buy" else "You have nothing the traders want.", r.x + 30, y + 10, GREY, F_BD)
        for row in rows[self.mk_scroll:self.mk_scroll + per]:
            box = pygame.Rect(r.x + 24, y, r.w - 48, 38)
            pygame.draw.rect(screen, (30, 30, 34), box, border_radius=5); pygame.draw.rect(screen, (70, 66, 60), box, 1, border_radius=5)
            col = gfx.RARITY_COLOR.get(row["rarity"], (230, 230, 230))
            text(row["label"], box.x + 12, box.y + 3, col, F_BD); text(row["sub"], box.x + 12, box.y + 21, GREY, F_SM)
            text(f"{row['price']:,}g", box.right - 150, box.y + 10, (255, 215, 80), F_BD, right=True)
            can = tab == "sell" or v["gold"] >= row["price"]
            self.ui_rects["do_" + row["key"]] = button((box.right - 128, box.y + 5, 112, 28), "Buy" if tab == "buy" else "Sell", can, can)
            y += 42
        if len(rows) > per: text(f"scroll for more ({self.mk_scroll + 1}-{min(len(rows), self.mk_scroll + per)} of {len(rows)})", r.centerx, r.bottom - 24, GREY, F_SM, center=True)

    # ------------------------------------------------------ 0.23 shops (Diablo-style vendor window)
    def _item_lines(self, row, selling=False):
        rc = RARITY_COLOR.get(row.get("rarity"), (230, 230, 230))
        lines = [(row["label"], rc, F_BD)]
        slot = row.get("slot", "")
        if row.get("power"):
            lines.append((f"{slot.title()}  •  Power {row['power']}", PARCH, F_SM))
            eq = (self.shop or {}).get("equipped", {}).get(slot)
            if eq and not selling:
                diff = row["power"] - eq["power"]
                lines.append((f"{'+' if diff >= 0 else ''}{diff} vs your {eq['item']}", (110, 230, 110) if diff > 0 else (230, 110, 100) if diff < 0 else GREY, F_SM))
            elif not eq and not selling and slot in ("weapon", "armor", "helm", "trinket"):
                lines.append(("Upgrade — you have nothing in this slot", (110, 230, 110), F_SM))
            if row.get("cls"): lines.append((f"Requires: {row['cls']}", GREY, F_SM))
            if row.get("bonus"): lines.append((f"Bonus: {row['bonus']}", (120, 230, 255), F_SM))
            if row.get("set_name"):
                lines.append((f"{row['set_name']} (6 pieces)", (60, 220, 200), F_SM))
                for ln_ in (row.get("set_bonus") or "").split("  |  "):
                    if ln_: lines.append((f"  {ln_.replace(':', ' pieces:', 1)}", (150, 220, 210), F_SM))
        else:
            lines.append((row.get("sub", ""), GREY, F_SM))
        lines.append((f"{'Sell' if selling else 'Buy'} price: {row['price']:,} gold", (255, 215, 80), F_SM))
        lines.append(("Click to " + ("sell" if selling else "buy"), (170, 170, 180), F_SM))
        return lines

    def _inv_item_lines(self, it_, extra=(), why=""):
        """Universal item tooltip (bag, worn gear, vault, upgrades, kiln): rarity, power, bonus, sockets, class, set and source."""
        snap = self.snap; p = snap["player"]
        col = RARITY_COLOR.get(it_["rarity"], PARCH)
        lines = [(it_["item"], col, F_BD), (f"{it_['rarity']} {SLOT_LABEL.get(it_['slot'], it_['slot'].title())}", col, F_SM), (f"Power {it_['power']}", (255, 255, 255), F_SM)]
        if it_.get("bonus"): lines.append((it_["bonus"], (120, 230, 255), F_SM))
        if it_.get("sockets"):
            gl_ = it_.get("gems", []); gb_ = it_.get("gem_bonus", [])
            for k_ in range(it_["sockets"]):
                lines.append(((f"\u25c6 {gl_[k_]}" + (f": {gb_[k_]}" if k_ < len(gb_) else "") if k_ < len(gl_) else "\u25c7 Empty socket (Jeweler's Kiln)"), (150, 220, 255) if k_ < len(gl_) else GREY, F_SM))
        if it_.get("class"): lines.append((f"Class: {it_['class']}", (255, 120, 100) if it_["class"] != p.get("class") else (200, 200, 200), F_SM))
        if it_.get("usable") is False and it_.get("why"): lines.append((it_["why"], (255, 110, 100), F_SM))
        if it_.get("set_name"):
            have_ = next((s_["pieces"] for s_ in ((snap.get("set_bonus") or {}).get("sets") or []) if s_["set"] == it_["set_name"]), 0)
            lines.append((f"{it_['set_name']}  ({have_}/6 worn)", (60, 220, 200), F_SM))
            for ln_ in it_.get("set_bonus", []):
                on_ = have_ >= int(ln_.split()[0])
                lines.append(("  " + ln_, (120, 255, 200) if on_ else (120, 120, 125), F_SM))
        if it_.get("source"): lines.append((f"Source: {it_['source']}", GREY, F_SM))
        if it_.get("equipped"): lines.append(("Equipped", (120, 255, 140), F_SM))
        for e_ in extra: lines.append((e_, (255, 215, 80), F_SM))
        if why: lines.append((f"Needs {why}", (255, 120, 100), F_SM))
        return lines

    def _icon_for(self, row):
        slot = gfx.icon_slot(row.get("label", ""), row.get("slot", "trinket"), _FISH())
        if slot == "weapon": slot = "weapon:" + gfx.weapon_kind(row.get("label", ""))
        return gfx.item_icon(slot, row.get("rarity", "Common"), 40)

    def draw_shop(self):
        nid = getattr(self, "shop_npc", None)
        v = self.w.shop_view(nid) if nid is not None else None
        if v is None: self.mode = "world"; self.shop = None; return
        self.shop = v
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 120)); screen.blit(ov, (0, 0))
        W_, H_ = 1040, 600
        r = frame_panel((LW // 2 - W_ // 2, max(40, LH // 2 - H_ // 2 - 30), W_, H_), alpha=245)
        self.ui_rects = {"close": button((r.right - 96, r.y + 12, 80, 28), "Close")}
        if v.get("can_craft"): self.ui_rects["tocraft"] = button((r.right - 196, r.y + 12, 94, 28), "Craft", True, True)
        self.shop_cells = []
        # ---- vendor side
        L = pygame.Rect(r.x + 18, r.y + 14, 560, r.h - 28)
        text(v["name"].upper(), L.x + 4, L.y, (255, 215, 90), F_TI)
        text(f"{v['title']}  —  {v['town']}", L.x + 6, L.y + 32, GREY, F_SM)
        tabs = v["tabs"]; ti = min(getattr(self, "shop_tab", 0), len(tabs) - 1); self.shop_tab = ti
        for i, tb in enumerate(tabs):
            self.ui_rects[f"stab_{i}"] = button((L.x + i * 168, L.y + 56, 160, 28), tb["name"], True, i == ti)
        grid = pygame.Rect(L.x, L.y + 94, L.w, L.h - 100)
        pygame.draw.rect(screen, (14, 12, 12), grid); pygame.draw.rect(screen, (90, 74, 46), grid, 1)
        cell = 62; cols = grid.w // cell
        items = tabs[ti]["items"] if tabs else []
        for i, row in enumerate(items):
            cx = grid.x + 6 + (i % cols) * cell; cy = grid.y + 6 + (i // cols) * (cell + 22)
            if cy + cell > grid.bottom: break
            box = pygame.Rect(cx, cy, cell - 6, cell - 6)
            afford = v["gold"] >= row["price"]
            hov = box.collidepoint(self.mouse)
            pygame.draw.rect(screen, (40, 34, 30) if hov else (26, 22, 22), box)
            pygame.draw.rect(screen, RARITY_COLOR.get(row["rarity"], (120, 120, 120)) if hov else (70, 60, 48), box, 2 if hov else 1)
            ic = self._icon_for(row)
            screen.blit(ic, (box.centerx - ic.get_width() // 2, box.centery - ic.get_height() // 2))
            if not afford:
                sh = pygame.Surface(box.size, pygame.SRCALPHA); sh.fill((120, 0, 0, 70)); screen.blit(sh, box.topleft)
            text(f"{row['price']:,}g", box.centerx, box.bottom + 2, (255, 215, 80) if afford else (200, 90, 80), F_SM, center=True)
            self.shop_cells.append((box, "buy", row))
            if hov: self.tooltip = self._item_lines(row)
        if not items: text("Sold out — come back in a day or two.", grid.x + 16, grid.y + 16, GREY, F_BD)
        # ---- player side
        R = pygame.Rect(r.x + 600, r.y + 50, r.w - 618, r.h - 64)
        text("YOUR PACK", R.x, R.y - 2, PARCH, F_BD)
        text(f"Gold  {v['gold']:,}", R.right - 4, R.y - 2, (255, 215, 80), F_BD, right=True)
        g2 = pygame.Rect(R.x, R.y + 22, R.w, R.h - 60)
        pygame.draw.rect(screen, (14, 12, 12), g2); pygame.draw.rect(screen, (90, 74, 46), g2, 1)
        cell2 = 56; cols2 = g2.w // cell2; per = cols2 * ((g2.h - 6) // cell2)
        sells = v["sell"]; self.shop_scroll = max(0, min(getattr(self, "shop_scroll", 0), max(0, (len(sells) - per + cols2 - 1) // cols2)))
        for j, row in enumerate(sells[self.shop_scroll * cols2:self.shop_scroll * cols2 + per]):
            cx = g2.x + 5 + (j % cols2) * cell2; cy = g2.y + 5 + (j // cols2) * cell2
            box = pygame.Rect(cx, cy, cell2 - 5, cell2 - 5)
            hov = box.collidepoint(self.mouse)
            pygame.draw.rect(screen, (40, 34, 30) if hov else (26, 22, 22), box)
            pygame.draw.rect(screen, RARITY_COLOR.get(row["rarity"], (120, 120, 120)) if hov else (70, 60, 48), box, 2 if hov else 1)
            ic = self._icon_for(row)
            screen.blit(ic, (box.centerx - ic.get_width() // 2, box.centery - ic.get_height() // 2))
            if row.get("sub", "").startswith("x") or "herb x" in row.get("sub", ""):
                text(row["sub"].split()[-1], box.right - 3, box.bottom - 15, PARCH, F_SM, True, right=True)
            self.shop_cells.append((box, "sell", row))
            if hov: self.tooltip = self._item_lines(row, True)
        if not sells: text("Nothing to sell.", g2.x + 12, g2.y + 12, GREY, F_SM)
        text("Equipped items are never sold.  Wheel scrolls your pack.  Esc closes.", R.x, R.bottom - 30, GREY, F_SM)
        if self.tooltip: self.draw_tooltip(self.tooltip); self.tooltip = None

    def open_world_ui(self):
        ou = getattr(self.w, "open_ui", None)
        if ou in ("market", "stable"):
            self.mode = ou; self.w.open_ui = None; self.mk_tab = "buy"; self.mk_scroll = 0
            self.dest = None; self.path = None
        elif ou == "craft":
            self.mode = "craft"; self.w.open_ui = None; self.craft_station = getattr(self.w, "craft_station", "inn"); self.craft_tab = 0; self.craft_scroll = 0
            self.shop_npc = getattr(self.w, "shop_npc", None)
            self.dest = None; self.path = None
        elif ou == "warhall":
            self.mode = "pvp"; self.w.open_ui = None; self.dest = None; self.path = None
        elif ou == "kiln":
            self.mode = "kiln"; self.w.open_ui = None; self.dest = None; self.path = None; self.kiln_tab = getattr(self, "kiln_tab", "cut"); self.kiln_sel = None; self.kiln_scroll = 0
        elif ou == "magic":
            self.mode = "magic"; self.w.open_ui = None; self.dest = None; self.path = None; self.magic_tab = getattr(self, "magic_tab", "spells"); self.magic_sel = None
        elif ou == "quests":
            self.mode = "quests"; self.w.open_ui = None; self.qg_npc = getattr(self.w, "shop_npc", None)
            self.dest = None; self.path = None
        elif ou == "shop":
            self.mode = "shop"; self.w.open_ui = None; self.shop_npc = getattr(self.w, "shop_npc", None); self.shop_tab = 0; self.shop_scroll = 0
            self.dest = None; self.path = None
        elif ou == "vault":
            self.mode = "vault"; self.w.open_ui = None; self.vb_scroll = 0; self.vv_scroll = 0
            self.dest = None; self.path = None
        elif ou == "person":
            self.mode = "person"; self.w.open_ui = None; self.person_id = getattr(self.w, "person_id", None); self.person_tab = "info"
            self.dest = None; self.path = None


    # ------------------------------------------------------ 0.24 windows
    def dim(self, a=170):
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, a)); screen.blit(ov, (0, 0))

    def wrap(self, txt, font, width):
        out = []; line = ""
        for word in str(txt).split():
            t = (line + " " + word).strip()
            if font.size(t)[0] <= width: line = t
            else:
                if line: out.append(line)
                line = word
        if line: out.append(line)
        return out or [""]

    def slider(self, key, x, y, w, val, lo, hi, label, fmt="{:.0%}"):
        text(label, x, y, PARCH, F_BD)
        rr = pygame.Rect(x + 140, y + 4, w - 140 - 70, 10)
        pygame.draw.rect(screen, (30, 26, 24), rr, border_radius=5); pygame.draw.rect(screen, (110, 92, 62), rr, 1, border_radius=5)
        k = clamp((val - lo) / (hi - lo), 0, 1)
        pygame.draw.rect(screen, (214, 172, 62), (rr.x, rr.y, int(rr.w * k), rr.h), border_radius=5)
        pygame.draw.circle(screen, (255, 236, 170), (rr.x + int(rr.w * k), rr.centery), 9); pygame.draw.circle(screen, (90, 70, 30), (rr.x + int(rr.w * k), rr.centery), 9, 2)
        text(fmt.format(val), rr.right + 16, y, GREY, F_SM)
        self.sliders[key] = (rr.inflate(24, 28), rr, lo, hi)

    def set_slider(self, key, px):
        hit, rr, lo, hi = self.sliders[key]
        v = lo + (hi - lo) * clamp((px - rr.x) / max(1, rr.w), 0, 1)
        if key == "brightness": self.brightness = round(v, 2)
        elif key == "master": self.audio.set(master=round(v, 2))
        elif key == "music": self.audio.set(music=round(v, 2))
        elif key == "sfx": self.audio.set(sfx=round(v, 2))

    def draw_settings(self):
        self.dim(175)
        r = frame_panel((LW // 2 - 310, max(20, LH // 2 - 330), 620, 660), alpha=246)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        self.sliders = {}
        text("SETTINGS", r.x + 26, r.y + 14, PARCH, F_TI)
        y = r.y + 64
        text("GRAPHICS", r.x + 26, y, GOLD, F_BD); y += 26
        for i, nm in enumerate(QUALITY_NAMES):
            self.ui_rects[f"q{i}"] = button((r.x + 26 + i * 140, y, 132, 32), nm, True, self.quality == i)
        y += 40
        desc = {0: "Lite: no particles, lowest effects. For very slow computers.", 1: "Normal: lighting, shadows and particles.",
                2: "High: sharpened picture, finer lighting, soft shadows, more particles and sun rays. For fast PCs."}[self.quality]
        text(desc, r.x + 26, y, GREY, F_SM); y += 26
        self.slider("brightness", r.x + 26, y, r.w - 52, self.brightness, .7, 1.6, "Brightness"); y += 44
        text("DISPLAY", r.x + 26, y, GOLD, F_BD); y += 26
        for i, md in enumerate(("full", "border", "window")):
            self.ui_rects["dm_" + md] = button((r.x + 26 + i * 124, y, 118, 32), DISPLAY_NAMES[md], True, DISPLAY == md)
        self.ui_rects["minimize"] = button((r.x + 404, y, 190, 32), "Minimize window", True, False)
        y += 36
        text({"full": "Full screen covers the whole monitor, panels included.  F11 = window.",
              "border": "Borderless fills the desktop but leaves your panels / top bar visible.  F11 = window.",
              "window": "A normal resizable window.  F11 = back to full screen."}[DISPLAY], r.x + 26, y, GREY, F_SM)
        y += 26
        text("SOUND", r.x + 26, y, GOLD, F_BD); y += 26
        self.slider("master", r.x + 26, y, r.w - 52, self.audio.master, 0, 1, "Master volume"); y += 34
        self.slider("music", r.x + 26, y, r.w - 52, self.audio.music_v, 0, 1, "Music"); y += 34
        self.slider("sfx", r.x + 26, y, r.w - 52, self.audio.sfx_v, 0, 1, "Sound effects"); y += 38
        self.ui_rects["mute"] = button((r.x + 26, y, 200, 32), f"Mute: {'ON' if self.audio.mute else 'OFF'}", True, self.audio.mute)
        if not self.audio.ok: text("No audio device was found.", r.x + 240, y + 8, (255, 140, 120), F_SM)
        y += 52
        text("KEYS", r.x + 26, y, GOLD, F_BD); y += 22
        for ln in ("W A S D / click: move     1-0: skills     H J T Y V: potions, scrolls, food     Z: loot     G: fish",
                   "F: talk / gather / enter     O: dungeon exit portal     N: skip the rest     X: mount     TAB: target",
                   "I bag  C class  K skills  M map  Q quests  F1 guide  F11 full screen  (PvP and raids: the War Hall in town)"):
            text(ln, r.x + 26, y, GREY, F_SM); y += 18
        y = r.bottom - 98
        nm = self.snap["player"].get("name", "")
        self.ui_rects["delchar"] = button((r.x + 26, y, 250, 32), "Delete character...", True, False)
        text(f"{nm}, level {self.snap['player'].get('level', 1)} {self.snap['player'].get('class', '')}", r.x + 290, y + 9, GREY, F_SM)
        y = r.bottom - 54
        self.ui_rects["guide"] = button((r.x + 26, y, 150, 36), "Guide  (F1)", True, False)
        self.ui_rects["resume"] = button((r.centerx - 70, y, 140, 36), "Resume", True, True)
        self.ui_rects["quit"] = button((r.right - 176, y, 150, 36), "Quit game", True, False)
        if self.confirm_delete: self.draw_delete_confirm()

    def draw_delete_confirm(self):
        """Second step of deleting a character: a modal box over the settings window."""
        self.dim(150)
        p = self.snap["player"]
        r = frame_panel((LW // 2 - 280, LH // 2 - 120, 560, 240), alpha=250, border=(220, 70, 60))
        self.ui_rects = {}
        text("DELETE CHARACTER?", r.centerx, r.y + 16, (255, 120, 100), F_TI, center=True)
        text(f"{p.get('name', '')}  -  level {p.get('level', 1)} {p.get('faction', '')} {p.get('class', '')}", r.centerx, r.y + 56, PARCH, F_BD, center=True)
        for i, ln in enumerate(("This erases the character with all gear, gold, quests, mounts and the Mythic",
                                "progress, and starts a brand-new world.  It cannot be undone.",
                                "Your settings (graphics, sound, display) are kept.")):
            text(ln, r.centerx, r.y + 86 + i * 20, (230, 210, 200) if i < 2 else GREY, F_SM, center=True)
        self.ui_rects["del_yes"] = button((r.x + 40, r.bottom - 58, 220, 38), "Delete forever", True, False)
        self.ui_rects["del_no"] = button((r.right - 260, r.bottom - 58, 220, 38), "Cancel", True, True)
        pygame.draw.rect(screen, (220, 70, 60), self.ui_rects["del_yes"], 2, border_radius=6)

    def settings_click(self, k):
        if k.startswith("q") and k[1:].isdigit():
            self.auto_q = False; self.slow_t = 0.0; self.apply_quality(int(k[1:])); self.save_prefs()
        elif k.startswith("dm_"): self.set_display(k[3:])
        elif k == "minimize": self.minimize()
        elif k == "delchar": self.confirm_delete = True
        elif k == "del_no": self.confirm_delete = False
        elif k == "del_yes": self.confirm_delete = False; self.want_reset = True
        elif k == "mute": self.audio.set(mute=not self.audio.mute); self.save_prefs()
        elif k == "guide": self.mode = "guide"
        elif k in ("resume", "close"): self.mode = "world"
        elif k == "quit": self.want_quit = True

    def draw_guide(self):
        self.dim(185)
        r = frame_panel((LW // 2 - 520, max(16, LH // 2 - 370), 1040, 740), alpha=246)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        text("PLAYER'S GUIDE", r.x + 26, r.y + 14, PARCH, F_TI)
        y = r.y + 66
        step = min(37, (r.h - 100) // len(guide.PAGES))
        for i, (title, _) in enumerate(guide.PAGES):
            self.ui_rects[f"gp{i}"] = button((r.x + 20, y + i * step, 220, step - 4), title, True, i == self.guide_page)
        title, lines = guide.PAGES[self.guide_page]
        cx = r.x + 262; cw = r.w - 262 - 26
        text(title.upper(), cx, r.y + 66, GOLD, F_TI)
        yy = r.y + 106 - self.guide_scroll
        clip = screen.get_clip(); screen.set_clip(pygame.Rect(cx - 4, r.y + 100, cw + 8, r.h - 140))
        total = 0
        for ln in lines:
            wl = self.wrap(ln, F_MD, cw - 18)
            pygame.draw.circle(screen, GOLD, (cx + 5, yy + 9), 3)
            for w_ in wl:
                text(w_, cx + 18, yy, (232, 226, 214), F_MD); yy += 20; total += 20
            yy += 8; total += 8
        screen.set_clip(clip)
        self.guide_max = max(0, total - (r.h - 150))
        text("Mouse wheel scrolls  •  F1 or Esc closes", r.x + 262, r.bottom - 26, GREY, F_SM)

    def _recipe_lines(self, row, extra=()):
        """Tooltip for a crafting / kiln recipe, in the same style as gear tooltips: what it is, what it needs, what is missing."""
        rc = RARITY_COLOR.get(row.get("rarity"), PARCH)
        lines = [(row.get("name") or row.get("item", ""), rc, F_BD)]
        slot = row.get("slot")
        if slot in SLOT_LABEL: lines.append((f"{row.get('rarity', '')} {SLOT_LABEL[slot]}".strip(), rc, F_SM))
        for ln_ in self.wrap(row.get("desc", ""), F_SM, 300)[:4]: lines.append((ln_, (220, 220, 225), F_SM))
        if row.get("bonus"): lines.append((row["bonus"], (120, 230, 255), F_SM))
        if row.get("set_name"):
            lines.append((f"{row['set_name']} (6 pieces)", (60, 220, 200), F_SM))
            lines.append(("  Six pieces, with bonuses at 2, 4 and 6 pieces.", (150, 220, 210), F_SM))
        for label, have, n in row.get("needs", ()):
            lines.append((f"{label} {have}/{n}", (130, 230, 140) if have >= n else (240, 120, 100), F_SM))
        if row.get("gold"): lines.append((f"{row['gold']:,} gold", (255, 215, 80), F_SM))
        for e_ in extra: lines.append((e_, (255, 215, 80), F_SM))
        if row.get("why"): lines.append((row["why"], (255, 120, 100), F_SM))
        return lines

    def _need_line(self, x, y, needs, gold):
        for label, have, n in needs:
            ok = have >= n
            t = f"{label} {have}/{n}"
            text(t, x, y, (130, 230, 140) if ok else (240, 120, 100), F_SM)
            x += F_SM.size(t)[0] + 16
        if gold: text(f"{gold:,} gold", x, y, (255, 215, 80), F_SM)

    def draw_craft(self):
        v = self.w.craft_view(self.craft_station)
        if not v["ok"]: self.mode = "world"; return
        self.dim(170)
        r = frame_panel((LW // 2 - 480, max(20, LH // 2 - 340), 960, 680), alpha=246)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        if self.craft_station in ("smith", "forge", "hut") and getattr(self, "shop_npc", None) is not None:
            lab_ = "Fish Market" if self.craft_station == "hut" else "Shop"
            self.ui_rects["toshop"] = button((r.right - 216, r.y + 14, 110, 28), lab_)
        text(v["title"].upper(), r.x + 26, r.y + 14, (255, 215, 90), F_TI)
        text(f"Gold {v['gold']:,}    Herbs {v['herbs']}    Fish {v['fish']}", r.x + 26, r.y + 50, (255, 215, 80), F_SM)
        tabs = v["tabs"]; self.craft_tab = min(self.craft_tab, len(tabs) - 1)
        for i, tb in enumerate(tabs):
            self.ui_rects[f"ct{i}"] = button((r.x + 26 + i * 132, r.y + 74, 124, 30), tb["name"], True, i == self.craft_tab)
        rows = tabs[self.craft_tab]["rows"]
        top = r.y + 116; rh = 74; per = (r.bottom - top - 40) // rh
        self.craft_scroll = max(0, min(self.craft_scroll, max(0, len(rows) - per)))
        for i, row in enumerate(rows[self.craft_scroll:self.craft_scroll + per]):
            box = pygame.Rect(r.x + 22, top + i * rh, r.w - 44, rh - 6)
            pygame.draw.rect(screen, (30, 28, 30), box, border_radius=6); pygame.draw.rect(screen, (90, 74, 52), box, 1, border_radius=6)
            slot = row["slot"]
            if slot == "weapon": slot = "weapon:" + gfx.weapon_kind(row["name"])
            if slot == "fish":
                ic = gfx.item_icon("fish", row["rarity"], 22)
            else:
                ic = gfx.item_icon(slot, row["rarity"], 22)
            screen.blit(ic, (box.x + 8, box.y + 12))
            text(row["name"], box.x + 66, box.y + 6, RARITY_COLOR.get(row["rarity"], PARCH), F_BD)
            text(row["desc"], box.x + 66, box.y + 24, GREY, F_SM)
            self._need_line(box.x + 66, box.y + 44, row["needs"], row["gold"])
            lab = row.get("btn", "Craft")
            self.ui_rects["cr_" + row["key"]] = button((box.right - 118, box.y + 10, 104, 30), lab, row["can"], row["can"])
            if row["why"]: text(row["why"], box.right - 14, box.y + 46, (240, 120, 100), F_SM, right=True)
            if box.collidepoint(self.mouse): self.tooltip = self._recipe_lines(row)
        if len(rows) > per: text("Mouse wheel scrolls", r.centerx, r.bottom - 24, GREY, F_SM, center=True)
        else: text("Esc closes", r.centerx, r.bottom - 24, GREY, F_SM, center=True)
        if self.tooltip: self.draw_tooltip(self.tooltip); self.tooltip = None

    def draw_quests(self):
        v = self.w.quest_view(self.qg_npc) if self.qg_npc is not None else None
        if v is None: self.mode = "world"; return
        self.dim(170)
        r = frame_panel((LW // 2 - 500, max(20, LH // 2 - 340), 1000, 680), alpha=246)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        royal = v["royal"]
        text(v["name"].upper(), r.x + 26, r.y + 14, (255, 215, 90) if royal else PARCH, F_TI)
        sub = f"{v['town']}  -  {v['tier'].title()}" + (f"   (ruled by {v['ruler']})" if not royal else "")
        text(sub, r.x + 28, r.y + 48, GREY, F_SM)
        if v.get("work_total"):             # 0.45.3: how close this town is to running dry
            wd, wt = v["work_done"], v["work_total"]
            prog = f"{'Royal commissions' if royal else 'Town work'}: {wd} of {wt} done" + ("  -  all done, move on to the next town" if wd >= wt else "")
            if v.get("line_done") is not None: prog += f"   |   {v['zone']} questline: {v['line_done']} of 4"
            text(prog, r.right - 130, r.y + 48, (140, 230, 150) if wd >= wt else (230, 210, 150), F_SM, right=True)
        text("ROYAL COMMISSIONS" if royal else "AVAILABLE WORK", r.x + 26, r.y + 76, GOLD, F_BD)
        text(f"Quest log {v['slots'][0]}/{v['slots'][1]}", r.x + 480, r.y + 76, GOLD, F_BD)
        tab = getattr(self, "qg_tab", "work")
        if not v.get("dailies"): tab = "work"
        else:
            self.ui_rects["qgt_work"] = button((r.x + 250, r.y + 70, 100, 26), "Work", True, tab == "work")
            self.ui_rects["qgt_daily"] = button((r.x + 356, r.y + 70, 116, 26), "Daily (zones)", True, tab == "daily")
        offers = v["dailies"] if tab == "daily" else v["offers"]
        y = r.y + 100
        for q in offers[:5]:
            box = pygame.Rect(r.x + 22, y, 450, 100)
            pygame.draw.rect(screen, (30, 28, 32), box, border_radius=6); pygame.draw.rect(screen, (255, 190, 70) if q.get("line") else (150, 120, 60) if q["royal"] else (90, 74, 52), box, 2 if q.get("line") else 1, border_radius=6)
            text(self.wrap(q["title"], F_BD, 430)[0], box.x + 10, box.y + 6, (255, 190, 70) if q.get("line") else (255, 220, 120) if q["royal"] else PARCH, F_BD)
            for j, ln in enumerate(self.wrap(q["desc"], F_SM, 330)[:2]): text(ln, box.x + 10, box.y + 28 + j * 16, (220, 220, 225), F_SM)
            text(f"Level {q['level']}  •  {q['xp']:,} XP  •  {q['gold']:,} gold", box.x + 10, box.y + 62, (160, 230, 160), F_SM)
            rc = {"Uncommon": (110, 220, 110), "Rare": (96, 164, 255), "Epic": (200, 120, 255), "Elite": (255, 190, 70)}.get(q.get("rar"), (200, 200, 200))
            text(self.wrap("Reward: " + q.get("rtext", ""), F_PL, 432)[0], box.x + 10, box.y + 80, rc, F_PL)
            full = v["slots"][0] >= v["slots"][1]
            self.ui_rects["acc_" + q["id"]] = button((box.right - 104, box.y + 30, 92, 32), "Accept", not full, not full)
            y += 106
        if not offers:
            for j_, ln_ in enumerate(self.wrap("Nothing left for you here - finished quests never return. Try another town.", F_BD, 440)): text(ln_, r.x + 30, y + 10 + j_ * 22, GREY, F_BD)
        # right: your quests
        x0 = r.x + 500; y = r.y + 100
        for q in v["log"]:
            box = pygame.Rect(x0, y, r.w - 500 - 22, 82)
            done = q["done"]
            pygame.draw.rect(screen, (26, 36, 28) if done else (30, 28, 32), box, border_radius=6); pygame.draw.rect(screen, (90, 190, 100) if done else (90, 74, 52), box, 1, border_radius=6)
            text(q["title"], box.x + 10, box.y + 5, (140, 240, 150) if done else PARCH, F_BD)
            text(self.wrap(q["desc"], F_SM, box.w - 130)[0], box.x + 10, box.y + 24, GREY, F_SM)
            bar(box.x + 10, box.y + 46, box.w - 130, 12, q["prog"], q["need"], (90, 190, 100) if done else (214, 172, 62), f"{q['prog']}/{q['need']}")
            text(f"From {q['town_name']}" + (f" ({q['town_hint']})" if q["town_hint"] else ""), box.x + 10, box.y + 62, (150, 160, 190), F_PL)
            if done and q["town"] == next((t.id for t in self.w.towns if t.name == v["town"]), None):
                self.ui_rects["turn_" + q["id"]] = button((box.right - 106, box.y + 24, 96, 32), "Turn in", True, True)
            y += 88
        if not v["log"]: text("You have no active quests.", x0, y + 10, GREY, F_BD)
        text("Complete a quest, then return to the town that gave it.  Esc closes.", r.centerx, r.bottom - 24, GREY, F_SM, center=True)

    def draw_quest_window(self):
        """Q: your quest log, plus the Mythic weapon questline."""
        snap = self.snap
        self.dim(170)
        r = frame_panel((LW // 2 - 470, max(20, LH // 2 - 340), 940, 680), alpha=246)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        self.ui_rects["qt_log"] = button((r.x + 26, r.y + 14, 150, 30), "Quest log", True, self.qlog_tab == "log")
        self.ui_rects["qt_myth"] = button((r.x + 186, r.y + 14, 190, 30), "Mythic weapon", True, self.qlog_tab == "myth")
        if self.qlog_tab == "log":
            log = snap.get("quest_log", [])
            text(f"Active quests {len(log)}/6.  Take quests from the Quest Givers and Kings in every city.", r.x + 28, r.y + 56, GREY, F_SM)
            y = r.y + 84
            for q in log:
                box = pygame.Rect(r.x + 22, y, r.w - 44, 80)
                done = q["done"]
                pygame.draw.rect(screen, (26, 36, 28) if done else (30, 28, 32), box, border_radius=6); pygame.draw.rect(screen, (90, 190, 100) if done else (90, 74, 52), box, 1, border_radius=6)
                if box.collidepoint(self.mouse): self.tooltip = self._quest_tip(q)
                text(q["title"] + ("  (royal)" if q.get("royal") else ""), box.x + 10, box.y + 5, (140, 240, 150) if done else PARCH, F_BD)
                dsc_ = q["desc"]
                while F_SM.size(dsc_)[0] > box.w - 24 and len(dsc_) > 8: dsc_ = dsc_[:-4].rstrip() + "\u2026"      # 0.46.11: keep inside the frame (hover for the full text)
                text(dsc_, box.x + 10, box.y + 25, (220, 220, 225), F_SM)
                bar(box.x + 10, box.y + 46, 360, 12, q["prog"], q["need"], (90, 190, 100) if done else (214, 172, 62), f"{q['prog']}/{q['need']}")
                where = f"Hand in at {q['town_name']} ({q['town_hint']})" if done else (f"Hunt in {q['area']} ({q['area_hint']})" if q.get("area_hint") else f"Return to {q['town_name']} ({q['town_hint']})")
                text(where, box.x + 10, box.y + 62, (150, 160, 190), F_SM)
                text(f"{q['xp']:,} XP  •  {q['gold']:,} gold  •  {q.get('rar', '')} gear + bonuses", box.right - 330, box.y + 8, (160, 230, 160), F_SM)
                self.ui_rects["ab_" + q["id"]] = button((box.right - 110, box.y + 40, 96, 28), "Abandon", True, False)
                y += 86
            if not log: text("No active quests. Find a Quest Giver (the notice board in any town square).", r.x + 30, y + 10, GREY, F_BD)
        else:
            m = (snap.get("mythic") or [None])[0]
            if m is None: return
            text("THE MYTHIC WEAPON", r.centerx, r.y + 56, (255, 90, 80), F_TI, center=True)
            text("One red Mythic weapon can be forged per class. Level 91+. Progress is kept for each class.", r.centerx, r.y + 90, GREY, F_SM, center=True)
            text(m["title"], r.centerx, r.y + 116, (255, 150, 120) if not m["done"] else (255, 220, 100), F_BD, center=True)
            y = r.y + 146
            for i, st_ in enumerate(m["all"]):
                col = (230, 190, 70) if i < m["step"] else ((255, 255, 255) if i == m["step"] and not m["done"] else (130, 128, 134))
                pygame.draw.circle(screen, col, (r.x + 40, y + 9), 6)
                text(f"{i + 1}. {st_}", r.x + 58, y, col, F_MD); y += 28
            y += 10
            if m["done"]: text("FORGED - your Mythic weapon is in your bag.", r.centerx, y, (255, 220, 100), F_BD, center=True)
            elif m["forge"]:
                text("Ready to forge: talk to a blacksmith in town (press F next to them) with:", r.x + 40, y, (255, 220, 110), F_BD); y += 24
                for nm, have, need_ in m["needs"]:
                    text(f"{nm}  {have}/{need_}", r.x + 60, y, (130, 230, 140) if have >= need_ else (240, 120, 100), F_MD); y += 22
                text("and 25,000 gold.", r.x + 60, y, (255, 215, 80), F_MD)
            else:
                bar(r.x + 40, y, 420, 16, m["prog"], m["need"], (200, 70, 60), f"{m['prog']} / {m['need']}")
        text("Press Q or Esc to close", r.centerx, r.bottom - 22, GREY, F_SM, center=True)

    # ------------------------------------------------------ 0.24 HUD pieces
    def _quest_tip(self, q):
        """0.46.11: hovering a quest (tracker or log) spells out what to do, with the text wrapped."""
        done = q["done"]
        lines = [(q["title"], (140, 240, 150) if done else (255, 215, 90), F_BD)]
        for para in (q["desc"],):
            cur = ""
            for wd in para.split(" "):
                if F_SM.size(cur + " " + wd)[0] > 360 and cur: lines.append((cur, (225, 225, 230), F_SM)); cur = wd
                else: cur = (cur + " " + wd) if cur else wd
            if cur: lines.append((cur, (225, 225, 230), F_SM))
        lines.append((f"Progress: {q['prog']}/{q['need']}", (214, 172, 62), F_SM))
        where = f"Hand in at {q['town_name']} ({q.get('town_hint', '')})" if done else (f"Where: {q['area']} ({q['area_hint']})" if q.get("area_hint") else f"Return to {q['town_name']} ({q.get('town_hint', '')})")
        lines.append((where, (150, 160, 190), F_SM))
        if q.get("xp"): lines.append((f"Reward: {q['xp']:,} XP, {q['gold']:,} gold, {q.get('rar', '')} gear", (160, 230, 160), F_SM))
        return lines

    def draw_quest_tracker(self):
        log = self.snap.get("quest_log", [])
        if not log or self.snap.get("instance"): return
        x = LW - 262; y = 334
        bh = 22 + sum(32 for _ in log[:5])
        bk = pygame.Surface((256, bh), pygame.SRCALPHA); pygame.draw.rect(bk, (10, 12, 20, 120), (0, 0, 256, bh), border_radius=6)
        pygame.draw.line(bk, (*GOLD, 150), (6, 17), (250, 17), 1); screen.blit(bk, (x - 2, y - 4))
        text("QUESTS", x + 4, y, GOLD, F_PL, True); y += 16
        for q in log[:5]:
            done = q["done"]
            if pygame.Rect(x - 2, y - 2, 256, 32).collidepoint(self.mouse) and not self.snap.get("instance"): self.tooltip = self._quest_tip(q)
            text(q["title"], x + 4, y, (140, 240, 150) if done else (236, 226, 200), F_PL, True); y += 14
            txt = "Complete - return to " + q["town_name"] if done else f"{q['desc']}  {q['prog']}/{q['need']}"
            while F_SM.size(txt)[0] > 238 and len(txt) > 8: txt = txt[:-4].rstrip() + "\u2026"
            text(txt, x + 10, y, (150, 220, 160) if done else (190, 190, 200), F_SM, True); y += 18

    def draw_fishing(self):
        f = self.snap.get("fishing") or {}
        st = f.get("state")
        fn_ = getattr(self, "fish_note", None)
        if fn_ and self.t - fn_[1] < 4.0 and not (st == "bite"):
            warn_ = fn_[0].startswith(("There is no", "You cannot", "Wait for", "The fish"))
            tt = tsurf(fn_[0], (255, 170, 130) if warn_ else (200, 230, 255), F_BD, True)
            screen.blit(tt, (LW // 2 - tt.get_width() // 2, LH - 180))
        if not st: return
        sx, sy = self.to_screen(f["x"], f["y"])
        t = self.t
        bite = st == "bite"
        for k in range(3):
            rr = 6 + ((t * 14 + k * 8) % 24) * (1.6 if bite else 1.0)
            pygame.draw.ellipse(screen, (200, 230, 255), (sx - rr, sy - rr * .5, rr * 2, rr), 1)
        dip = 8 if bite else int(math.sin(t * 3) * 2)
        pygame.draw.circle(screen, (230, 60, 50), (int(sx), int(sy + dip)), 4); pygame.draw.circle(screen, (255, 255, 255), (int(sx), int(sy + dip - 3)), 2)
        p = self.w.player; px, py = self.to_screen(p["x"], p["y"])
        pygame.draw.line(screen, (210, 200, 170), (px, py - 44), (sx, sy + dip), 1)
        if bite:
            tt = tsurf("FISH ON!  Press G!", (255, 240, 120), F_CRIT, True); screen.blit(tt, (LW // 2 - tt.get_width() // 2, LH // 2 - 120))
        else:
            tt = tsurf("Fishing... wait for the float to dip", (200, 230, 255), F_BD, True); screen.blit(tt, (LW // 2 - tt.get_width() // 2, LH - 150))

    # ------------------------------------------------------ ground
    def rim(self, cx, cy):
        k = (cx, cy)
        if k in self.rims:
            return self.rims[k]
        r = gfx.render_rim(self.layout, cx, cy)
        if r is not None: r = r.convert_alpha()
        self.rims[k] = r
        if len(self.rims) > 90: self.rims.popitem(last=False)
        return r

    def chunk_step(self, cx, cy, until):
        """Build chunk (cx, cy), continuing any half-done build; stop early once perf_counter() passes
        `until` (None = finish).  Returns the chunk, or None if it isn't finished yet."""
        k = (cx, cy)
        job = self.chunk_jobs.pop(k, None) or gfx.render_chunk_steps(self.layout, cx, cy)
        try:
            while True:
                next(job)
                if until is not None and time.perf_counter() > until:
                    self.chunk_jobs[k] = job; return None
        except StopIteration as done:
            c = done.value.convert_alpha()
        self.chunks[k] = c; self.placeholders.pop(k, None)
        if len(self.chunks) > 120: self.chunks.popitem(last=False)
        return c

    def placeholder(self, cx, cy):
        """0.38.1: a flat stand-in for a chunk that is still being built (each tile in its base colour),
        so walking into new land never stops the game to finish a chunk (60-200 ms on a slow CPU)."""
        k = (cx, cy)
        s = self.placeholders.get(k)
        if s is None:
            s = pygame.Surface((CS * TW, CS * TH + 2), pygame.SRCALPHA)
            for ly in range(CS):
                for lx in range(CS):
                    col = gfx.tile_cached(self.layout, cx * CS + lx, cy * CS + ly)[1]
                    px = (lx - ly) * HTW + CS * HTW; py = (lx + ly) * HTH
                    pygame.draw.polygon(s, col, [(px, py - 1), (px + HTW + 1, py + HTH), (px, py + TH + 1), (px - HTW - 1, py + HTH)])
            self.placeholders[k] = s
            if len(self.placeholders) > 60: self.placeholders.pop(next(iter(self.placeholders)))
        return s

    def ground_tile(self, tx, ty):
        """A GT x GT screen-aligned piece of the ground (chunks + sea-wall rims), composed once and cached.
        Walking then costs a few opaque blits per frame instead of ~30 alpha-blended chunk blits."""
        k = (tx, ty)
        s = self.gtiles.get(k)
        if s is not None and k not in self.gtile_partial:
            self.gtiles.move_to_end(k); return s
        hits = self._tile_chunks(tx, ty)
        need = [(cx, cy) for cx, cy, bx, by in hits if by < GT and by + CS * TH + 2 > 0]
        missing = [c for c in need if c not in self.chunks]
        if s is not None and missing and all(c in self.placeholders for c in missing) and not any(
                self.chunk_step(cx, cy, self._sync_until) is not None for cx, cy in missing[:1]):
            return s                       # still waiting on the same chunks: keep the stand-in tile, no recompose
        for cx, cy in missing:             # finish what fits in this frame's small budget; stand-ins for the rest
            if (cx, cy) not in self.chunks and time.perf_counter() < self._sync_until: self.chunk_step(cx, cy, self._sync_until)
        s = pygame.Surface((GT, GT)); s.fill((10, 12, 16)); partial = False
        for cx, cy, bx, by in hits:
            if by < GT and by + CS * TH + 2 > 0:
                c = self.chunks.get((cx, cy))
                if c is None: c = self.placeholder(cx, cy); partial = True
                s.blit(c, (bx, by))
        for cx, cy, bx, by in hits:
            r = self.rim(cx, cy)
            if r is not None: s.blit(r, (bx, by))
        self.gtiles[k] = s; self.gtiles.move_to_end(k)
        if partial: self.gtile_partial.add(k)
        else: self.gtile_partial.discard(k)
        while len(self.gtiles) > 160:
            old, _ = self.gtiles.popitem(last=False); self.gtile_partial.discard(old)
        return s

    def _tile_chunks(self, tx, ty):
        """Chunks overlapping ground tile (tx, ty), in draw order, with their offset inside the tile."""
        px0, py0 = tx * GT, ty * GT
        xs, ys = zip(*(uniso(px0 + ox, py0 + oy) for ox in (0, GT) for oy in (0, GT)))
        cx0, cx1 = int(min(xs)) // CS - 1, int(max(xs)) // CS + 1
        cy0, cy1 = int(min(ys)) // CS - 1, int(max(ys)) // CS + 1
        hits = []
        for cy in range(cy0, cy1 + 1):
            for cx in range(cx0, cx1 + 1):
                if cx < -1 or cy < -1 or cx * CS > W or cy * CS > H: continue
                if self.in_inst and cy * CS < WORLD_H: continue
                ix, iy = iso(cx * CS, cy * CS)
                bx, by = ix - CS * HTW - px0, iy - py0
                if bx >= GT or by >= GT or bx + CS * TW <= 0 or by + CS * TH + 20 <= 0: continue
                hits.append((cx, cy, bx, by))
        return hits

    def prefetch_ground(self, budget=.012):
        """Spend up to `budget` seconds a frame building the ground just outside the screen, so walking
        into new land doesn't stall for several chunk renders (60-200 ms each on a slow CPU) at once."""
        if self.dt < 1 / 45: budget += .008            # 0.38.1: a fast frame has time to spare
        spent = time.perf_counter() - getattr(self, "_frame_t0", time.perf_counter())
        budget = max(.003, min(budget, .026 - spent))   # never push a frame that is already slow past ~26 ms
        until = time.perf_counter() + budget
        cam0, cam1 = self.cam
        pc = self._cam_prev or self.cam; self._cam_prev = self.cam
        vx, vy = cam0 - pc[0], cam1 - pc[1]           # look further ahead in the direction you are walking
        ax0 = 2 if vx < -.5 else 1; ax1 = 2 if vx > .5 else 1; ay0 = 2 if vy < -.5 else 1; ay1 = 2 if vy > .5 else 1
        tx0, tx1 = math.floor(cam0 / GT) - ax0, math.floor((cam0 + LW) / GT) + ax1
        ty0, ty1 = math.floor(cam1 / GT) - ay0, math.floor((cam1 + LH) / GT) + ay1
        vis = (math.floor(cam0 / GT), math.floor((cam0 + LW) / GT), math.floor(cam1 / GT), math.floor((cam1 + LH) / GT))
        order = sorted(((tx, ty) for ty in range(ty0, ty1 + 1) for tx in range(tx0, tx1 + 1)),
                       key=lambda t: (not (vis[0] <= t[0] <= vis[1] and vis[2] <= t[1] <= vis[3]), -((t[0] - (tx0 + tx1) / 2) * vx + (t[1] - (ty0 + ty1) / 2) * vy)))
        for tx, ty in order:
                if (tx, ty) in self.gtiles and (tx, ty) not in self.gtile_partial: continue
                for cx, cy, _, _ in self._tile_chunks(tx, ty):
                    if (cx, cy) not in self.chunks:
                        if self.chunk_step(cx, cy, until) is None or time.perf_counter() > until: return
                self.ground_tile(tx, ty)
                if time.perf_counter() > until: return

    def fluids(self, cx, cy):
        k = (cx, cy)
        f = self.chunk_fluids.get(k)
        if f is None:
            water = []; lava = []
            for ty in range(cy * CS, cy * CS + CS):
                for tx in range(cx * CS, cx * CS + CS):
                    kind = gfx.tile_cached(self.layout, tx, ty)[0]
                    if kind == "water": water.append((tx, ty))
                    elif kind == "lava": lava.append((tx, ty))
            f = self.chunk_fluids[k] = (water, lava)
            if len(self.chunk_fluids) > 400: self.chunk_fluids.clear()
        return f

    def draw_fluids(self):
        """Animated glints on water and a slow pulse on lava (ground level, under sprites)."""
        now = self.t
        hr = getattr(self.atmo, "hour", 12.0) % 24
        sk = (46, 70, 96) if 8 <= hr <= 16 else (110, 56, 26) if 16 < hr <= 20 or 5 <= hr < 8 else (8, 14, 36)
        rq = tuple(c // 8 * 8 for c in sk)
        refl = self._refl.get(rq) if hasattr(self, "_refl") else None
        if refl is None:
            if not hasattr(self, "_refl"): self._refl = {}
            # 0.33: soft overlapping sky glow per water tile (a hard diamond showed the tile grid)
            refl = []
            for lvl in (1.0, .66, .33):
                r_ = pygame.Surface((TW * 3 // 2, TH * 3 // 2)); r_.fill((0, 0, 0))
                for j in range(8):
                    f = 1 - j / 8; k = .6 * lvl * (j + 1) / 8
                    pygame.draw.ellipse(r_, tuple(int(c / 3 * k) for c in rq), (TW * .75 * (1 - f), TH * .75 * (1 - f), TW * 1.5 * f, TH * 1.5 * f))
                refl.append(pygame.transform.smoothscale(pygame.transform.smoothscale(r_, (TW // 2, TH // 2)), (TW * 3 // 2, TH * 3 // 2)))
            self._refl[rq] = refl
        lite = getattr(self.atmo, "lite", False)
        ptiles = getattr(self.layout, "pond_tiles", {})
        for (x, y) in self.visible_water:
            sx, sy = self.to_screen(x + .5, y + .5)
            if not (-40 < sx < LW + 40 and -20 < sy < LH + 20): continue
            if not lite:
                pd = ptiles.get((x, y))
                lvl = 0 if not pd or pd[1] < .55 else 1 if pd[1] < .8 else 2
                screen.blit(refl[lvl], (sx - TW * 3 // 4, sy - TH * 3 // 4), special_flags=pygame.BLEND_RGB_ADD)
                hv = gfx.h01(x, y, 38)
                if hv < .035:        # lazy ripple rings
                    ph = (now * .45 + hv * 30) % 1
                    rr = 3 + ph * 18
                    pygame.draw.ellipse(screen, (int(190 * (1 - ph)) + 40, int(220 * (1 - ph)) + 30, 255), (sx - rr, sy - rr / 2, rr * 2, rr), 1)
                elif hv > .992:      # a fish leaps
                    ph = (now * .35 + hv * 90) % 1
                    if ph < .22:
                        k_ = ph / .22
                        fx_ = sx - 10 + k_ * 20; fy_ = sy - math.sin(k_ * math.pi) * 20
                        pygame.draw.ellipse(screen, (214, 224, 232), (fx_ - 5, fy_ - 2, 10, 4)); pygame.draw.polygon(screen, (170, 190, 205), [(fx_ - 5, fy_), (fx_ - 9, fy_ - 3), (fx_ - 9, fy_ + 3)])
                        if k_ > .85 or k_ < .1:
                            pygame.draw.ellipse(screen, (230, 245, 255), (sx - 10 + k_ * 20 - 8, sy - 3, 16, 6), 1)
                elif 7 <= hr <= 19 and .5 < hv < .503:      # dragonfly over the water
                    dx_ = math.sin(now * 1.7 + hv * 40) * 22; dy_ = math.cos(now * 2.3 + hv * 50) * 8 - 22
                    wf = math.sin(now * 40) * 3
                    pygame.draw.line(screen, (60, 190, 210), (sx + dx_ - 4, sy + dy_), (sx + dx_ + 4, sy + dy_), 2)
                    pygame.draw.line(screen, (210, 240, 250), (sx + dx_, sy + dy_), (sx + dx_ - 2, sy + dy_ - 3 - wf), 1); pygame.draw.line(screen, (210, 240, 250), (sx + dx_, sy + dy_), (sx + dx_ + 2, sy + dy_ - 3 + wf), 1)
            if gfx.h01(x, y, 29) < .3:          # 0.45: an occasional soft glint (two bright dashes on every tile read as rain)
                ph = now * .9 + gfx.h01(x, y, 30) * 6.28
                a = math.sin(ph)
                if a > .35:
                    ox = (gfx.h01(x, y, 32) - .5) * 30 + math.sin(ph * .5) * 4
                    oy = (gfx.h01(x, y, 34) - .5) * 12
                    w = 3 + 4 * a; c = int(60 * a)
                    pygame.draw.line(screen, (min(255, 170 + c), min(255, 210 + c // 2), 250), (sx + ox - w, sy + oy), (sx + ox + w, sy + oy), 1)
        for (x, y) in self.visible_lava:
            sx, sy = self.to_screen(x + .5, y + .5)
            if not (-40 < sx < LW + 40 and -20 < sy < LH + 20): continue
            pul = .5 + .5 * math.sin(now * 1.6 + x * 1.3 + y * .7)
            g = gfx.glow(22, (int(90 * pul) + 30, int(30 * pul) + 8, 0))
            screen.blit(pygame.transform.scale(g, (44, 22)), (sx - 22, sy - 11), special_flags=pygame.BLEND_RGB_ADD)
            if gfx.h01(x, y, 36) < .35:
                ph = (now * .5 + gfx.h01(x, y, 37)) % 1
                r = 1 + ph * 4
                pygame.draw.circle(screen, (255, int(200 - 80 * ph), 80), (int(sx + (gfx.h01(x, y, 38) - .5) * 24), int(sy - ph * 3)), int(r), 1)

    def decor(self, cx, cy):
        k = (cx, cy)
        d = self.chunk_decor.get(k)
        if d is not None: return d
        d = []
        for ty in range(cy * CS, cy * CS + CS):
            for tx in range(cx * CS, cx * CS + CS):
                if (tx, ty) in self.layout.blocked or (tx, ty) in self.layout.road: continue
                kind, _ = gfx.tile_info(self.layout, tx, ty)
                if kind != "ground": continue
                a = gfx.area_at(tx, ty)
                if not a: continue
                b = gfx.BIOMES.get(a[0])
                if gfx.h01(tx, ty, 77) >= b["density"] * (.45 + 1.3 * gfx.vnoise(tx, ty, 9, 5)): continue   # clumpy groves
                tot = sum(wt for _, wt in b["decor"]); r = gfx.h01(tx, ty, 78) * tot
                for name, wt in b["decor"]:
                    r -= wt
                    if r <= 0: break
                var = int(gfx.h01(tx, ty, 79) * 3)
                x = tx + .2 + gfx.h01(tx, ty, 80) * .6; y = ty + .2 + gfx.h01(tx, ty, 81) * .6
                d.append((x, y, name, var))
                if name in ("pine", "snowpine", "oak", "willow", "palm", "rock", "icerock", "lavarock", "mushroom", "cactus", "crystal", "darkcrystal", "tomb", "boulders", "ruin", "stump", "haystack", "iceshard", "menhir", "vent"):
                    self.block.add((tx, ty))
        self.chunk_decor[k] = d
        return d

    # ------------------------------------------------------ simulation-side updates
    def sync_actors(self, dt):
        snap = self.snap; now = self.t
        seen = set()
        mine = set()
        for h in snap.get("player_hits", []):
            mine.add(h["id"])
            d = self.disp.get(h["id"]) or self.prev_pos.get(h["id"])
            if not d: continue
            crit = h.get("crit")
            col = (255, 150, 40) if crit else ((255, 200, 120) if h.get("kind") == "dot" else (255, 240, 120))
            if crit:
                self.shake = max(self.shake, 5.0); self.effects.append({"type": "impact", "x": d["x"], "y": d["y"], "t0": now, "dur": .3, "col": (255, 190, 80)})
            elif len(self.effects) < 50 and h.get("kind") != "dot":
                self.effects.append({"type": "impact", "x": d["x"], "y": d["y"], "t0": now, "dur": .2, "col": (255, 250, 200)})
            self.floats.append({"x": d["x"], "y": d["y"], "txt": (f"{h['dmg']}!" if crit else f"{h['dmg']}"), "col": col, "t0": now,
                                "big": True, "crit": crit, "dx": (len(self.floats) % 5 - 2) * 6})
        for k in snap.get("kill_events", []):
            self.effects.append({"type": "death", "x": k["x"], "y": k["y"], "t0": now, "dur": .7})
            self.add_corpse(k["id"], k["x"], k["y"])
            p = self.w.player
            self.floats.append({"x": p["x"], "y": p["y"], "txt": f"+{k['gold']}g", "col": (255, 210, 60), "t0": now + .2, "big": False, "up": 1})
            if self.target == k["id"]:
                self.target = None; self.auto = False
                if self.pending and self.pending[0] == "cast": self.pending = None
        for a in snap["actors"]:
            aid = a["id"]; seen.add(aid)
            d = self.disp.get(aid)
            if d is None:
                self.disp[aid] = d = {"x": a["x"], "y": a["y"], "face": 1, "moving": 0, "atk": -9}
            prev = self.prev.get(aid)
            if prev:
                jump = math.hypot(a["x"] - prev[0], a["y"] - prev[1])
                if jump > 4:   # killed + respawned elsewhere by the engine
                    self.effects.append({"type": "death", "x": d["x"], "y": d["y"], "t0": now, "dur": .7})
                    if a.get("kind") == "monster": self.add_corpse(aid, d["x"], d["y"])
                    if aid == self.target:
                        self.target = None; self.auto = False
                        if self.pending and self.pending[0] == "cast": self.pending = None
                    d["x"], d["y"] = a["x"], a["y"]
                elif a.get("hp", 0) < prev[2] and aid not in mine:
                    dmg = prev[2] - a.get("hp", 0)
                    col = (255, 240, 120) if aid == self.target else (235, 235, 235)
                    self.floats.append({"x": d["x"], "y": d["y"], "txt": f"-{dmg}", "col": col, "t0": now, "big": aid == self.target})
            self.prev[aid] = (a["x"], a["y"], a.get("hp", 0))
            self.prev_pos[aid] = {"x": d["x"], "y": d["y"]}
            if a.get("dead") and not a.get("corpse"):
                self.add_corpse(aid, d["x"], d["y"])
                if self.target == aid: self.target = None; self.auto = False
            at = a.get("atk")
            if at is not None and at != d.get("atk_tick") and at > 0:
                if d.get("atk_tick") is not None: d["atk"] = now
                d["atk_tick"] = at
            dx, dy = a["x"] - d["x"], a["y"] - d["y"]
            dist = math.hypot(dx, dy)
            if dist > 6:
                d["x"], d["y"] = a["x"], a["y"]
            elif dist > .02:
                k = min(1, dt * 5)
                d["x"] += dx * k; d["y"] += dy * k
                d["moving"] = now
                sdx = dx - dy
                if abs(sdx) > .01: d["face"] = 1 if sdx > 0 else -1
        for aid in list(self.disp):
            if aid not in seen:
                self.disp.pop(aid, None); self.prev.pop(aid, None)
        if len(self.prev_pos) > 3000:          # last-known positions of actors long gone (raiders, the Watch get new ids)
            self.prev_pos = {k: v for k, v in self.prev_pos.items() if k in seen}
        if len(self.looks) > 3000:             # 0.44.20: same for the cached looks (corpses are already registered)
            self.looks = {k: v for k, v in self.looks.items() if k in seen}
        for e in snap.get("inst_fx", []):
            self.party_fx(e, now)
        for h in snap.get("hits_taken", []):
            p = self.w.player
            if h.get("miss"):
                self.floats.append({"x": p["x"], "y": p["y"], "txt": "Dodge", "col": (200, 230, 255), "t0": now, "big": False})
            else:
                if h["dmg"]: self.floats.append({"x": p["x"], "y": p["y"], "txt": f"-{h['dmg']}", "col": (255, 70, 60), "t0": now, "big": True})
                if h["dmg"] and h["dmg"] > .1 * max(1, p.get("maxhp", 100)): self.shake = max(self.shake, 4.0)
                if h["dmg"]: self.effects.append({"type": "impact", "x": p["x"], "y": p["y"], "t0": now, "dur": .25, "col": (255, 80, 70)})
                if h.get("absorbed"): self.floats.append({"x": p["x"], "y": p["y"], "txt": f"({h['absorbed']} absorbed)", "col": (150, 210, 255), "t0": now + .1, "big": False, "dx": 30})
            d = self.disp.get(h["id"])
            if d:
                d["atk"] = now
                d["face"] = 1 if (p["x"] - p["y"]) - (d["x"] - d["y"]) > 0 else -1
        # computer players talking near you
        said = getattr(self, "_said", None)
        if said is None: said = self._said = collections.deque(maxlen=200)
        for sv in snap.get("says", []):
            k = (sv["id"], sv["seq"])
            if k in said: continue
            said.append(k)
            a = self.actor(sv["id"])
            if a and self.pdist(a["x"], a["y"]) < 22: self.msg(f"{clean_name(a)}: {sv['say']}", (226, 222, 190))
        # world events
        for e in self.w.events[-12:]:
            key = getattr(e, "seq", e)
            if key in self.seen_events: continue
            self.seen_events.append(key)
            if any(k in e for k in ("hunted down", "traded with", "finished crafting", "was defeated by")): continue
            if e.startswith("You were slain"):
                self.death_banner = now; self.target = None; self.auto = False; self.dest = None; self.pending = None
                self.msg(e, (255, 90, 80))
            else:
                self.msg(e, (140, 200, 255))
        if self.target is not None and self.actor(self.target) is None:
            self.target = None; self.auto = False
        self.w.selected_target = self.target
        lvl = snap["player"]["level"]
        if lvl > self.prev_level:
            self.levelup_t = now; p = self.w.player
            self.effects.append({"type": "levelup", "x": p["x"], "y": p["y"], "t0": now, "dur": 2.0})
            self.msg(f"Level up! You are now level {lvl}.", (255, 220, 90))
            for a in snap["abilities"]:
                if a["unlock"] == lvl: self.msg(f"New skill: {a['name']} (key {a['slot'] if a['slot'] in '1234567890' else 'Shift+' + str('!@#$%^'.index(a['slot']) + 1)}).", (255, 220, 90))
        self.prev_level = lvl
        self.gear_rarity(snap)

    def gear_rarity(self, snap):
        eq = {i.get("slot"): i["rarity"] for i in reversed(snap.get("inventory", [])) if i.get("equipped")}
        self.weapon_rarity = eq.get("weapon", ""); self.armor_rarity = eq.get("armor", ""); self.helm_rarity = eq.get("helm", "")

    def prewarm_player(self):
        """Draw the hero's walk cycle on the loading screen: each new pose costs ~0.1 s on a slow CPU,
        which used to show up as stutter the first time you walked."""
        if self.mode != "world": return
        self.gear_rarity(self.snap)
        cls, spec = self.player_spec()
        rkey = self.player_key(cls, spec)
        for facing in (1, -1):
            for frame in (-1, 0, 1, 2, 3):
                gfx.character_sprite(rkey, "human", spec, frame, facing, False, 1.38)
            gfx.character_sprite(rkey, "human", spec, -1, facing, True, 1.38)

    # ------------------------------------------------------ 0.23 party combat feedback & corpses
    def ref_pos(self, ref):
        if ref == "player": p = self.w.player; return p["x"], p["y"]
        d = self.disp.get(ref)
        return (d["x"], d["y"]) if d else None

    CLASS_FX = {"Mage": (170, 120, 255), "Warlock": (120, 240, 80), "Cleric": (255, 230, 130), "Shaman": (150, 200, 255),
                "Druid": (140, 230, 120), "Paladin": (255, 220, 110), "Ranger": (230, 210, 160)}

    def party_fx(self, e, now):
        t = e.get("t"); src, dst = e.get("src"), e.get("dst")
        sd = self.disp.get(src)
        dp = self.ref_pos(dst)
        if sd and dp and src != dst:
            sdx = (dp[0] - dp[1]) - (sd["x"] - sd["y"])
            if abs(sdx) > .05: sd["face"] = 1 if sdx > 0 else -1
            sd["atk"] = now
        cls = e.get("cls", "")
        if t == "shot":
            col = self.CLASS_FX.get(cls, (230, 210, 160))
            self.effects.append({"type": "arrow" if cls == "Ranger" else "bolt", "src": src, "to": dst, "t0": now, "dur": .3, "col": col})
        elif t == "melee":
            col = {"Rogue": (210, 255, 210), "Berserker": (255, 120, 90), "Paladin": (255, 220, 110), "Monk": (110, 230, 200)}.get(cls, (255, 236, 200))
            self.effects.append({"type": "slash", "to": dst, "t0": now, "dur": .22, "col": col})
        elif t == "heal":
            self.effects.append({"type": "aheal", "src": src, "to": dst, "t0": now, "dur": .7})
            if dp and e.get("amt"):
                self.floats.append({"x": dp[0], "y": dp[1], "txt": f"+{e['amt']}", "col": (110, 255, 130), "t0": now, "big": dst == "player", "dx": 18})
        elif t == "taunt":
            self.effects.append({"type": "taunt", "src": src, "t0": now, "dur": .6})

    def add_corpse(self, aid, x, y):
        lk = self.looks.get(aid)
        if not lk or self.t - self.corpsed.get(aid, -99) < 3.5: return
        self.corpsed[aid] = self.t
        if len(self.corpsed) > 400: self.corpsed = {k: v for k, v in self.corpsed.items() if self.t - v < 4}
        face = (self.disp.get(aid) or {}).get("face", 1)
        self.effects.append({"type": "corpse", "x": x, "y": y, "t0": self.t, "dur": 3.2, "look": lk, "face": face, "id": aid})
        if len([e for e in self.effects if e["type"] == "corpse"]) > 40:
            for i, e in enumerate(self.effects):
                if e["type"] == "corpse": self.effects.pop(i); break

    def corpse_sprite(self, lk, face):
        k = (lk[0], face, round(lk[3], 2))
        c = self.corpse_cache.get(k)
        if c is None:
            key, sk, spec, sc = lk
            spr, anc = gfx.character_sprite(key, sk, spec, -1, face, False, sc)
            r = pygame.transform.rotate(spr, -82 if face > 0 else 82)
            r = pygame.transform.smoothscale(r, (r.get_width(), max(4, int(r.get_height() * .62))))
            dark = pygame.Surface(r.get_size(), pygame.SRCALPHA); dark.fill((150, 140, 140, 255))
            r = r.copy(); r.blit(dark, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            c = self.corpse_cache[k] = r
            if len(self.corpse_cache) > 120: self.corpse_cache.clear()
        return c

    def draw_corpses(self, now):
        for e in self.effects:
            if e["type"] != "corpse": continue
            k = (now - e["t0"]) / e["dur"]
            if not 0 <= k <= 1: continue
            sx, sy = self.to_screen(e["x"], e["y"])
            if sx < -120 or sx > LW + 120 or sy < -60 or sy > LH + 120: continue
            fall = min(1.0, (now - e["t0"]) / .18)
            alpha = 255 if k < .6 else int(255 * (1 - (k - .6) / .4))
            # blood pool spreading under the body
            br = int(10 + 18 * min(1, (now - e["t0"]) / .9))
            pool = pygame.Surface((br * 4, br * 2), pygame.SRCALPHA)
            pygame.draw.ellipse(pool, (70, 6, 8, int(alpha * .55)), (0, 0, br * 4, br * 2))
            pygame.draw.ellipse(pool, (110, 12, 14, int(alpha * .45)), (br * .6, br * .4, br * 2.6, br * 1.1))
            screen.blit(pool, (sx - br * 2, sy - br))
            c = self.corpse_sprite(e["look"], e["face"])
            if fall < 1:
                key, sk, spec, sc = e["look"]
                spr, anc = gfx.character_sprite(key, sk, spec, -1, e["face"], False, sc)
                spr = pygame.transform.rotate(spr, (-82 if e["face"] > 0 else 82) * fall)
                screen.blit(spr, (sx - spr.get_width() // 2, sy - spr.get_height() + 6))
                continue
            c.set_alpha(alpha)
            screen.blit(c, (sx - c.get_width() // 2, sy - c.get_height() + 8))


    def move_player(self, dt):
        p = self.w.player
        speed = 4.6 * self.snap.get("move_speed", 1.0)
        fly = self.w.is_flying()
        mvx = mvy = 0.0
        keys = pygame.key.get_pressed()
        keys_move = False
        if self.mode == "world":
            if keys[pygame.K_w] or keys[pygame.K_UP]: mvx -= 1; mvy -= 1
            if keys[pygame.K_s] or keys[pygame.K_DOWN]: mvx += 1; mvy += 1
            if keys[pygame.K_a] or keys[pygame.K_LEFT]: mvx -= 1; mvy += 1
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]: mvx += 1; mvy -= 1
            keys_move = bool(mvx or mvy)
        goal = None
        if mvx or mvy:
            self.dest = None; self.pending = None if (self.pending and self.pending[0] != "cast") else self.pending
            l = math.hypot(mvx, mvy); mvx /= l; mvy /= l
        else:
            goal = self.goal_point()
            if goal:
                gx, gy, stop = goal
                dx, dy = gx - p["x"], gy - p["y"]; d = math.hypot(dx, dy)
                if d <= stop:
                    mvx = mvy = 0; self.path = None
                    if self.dest and not self.pending: self.dest = None
                else:
                    tx, ty = gx, gy
                    if not fly and not self.line_clear(p["x"], p["y"], gx, gy):
                        gk = (int(gx), int(gy))
                        if self.path is None or self.path_goal != gk or self.t - self.path_t > 1.0 or (not self.path and self.t - self.path_t > .3):
                            self.path = self.find_path(p["x"], p["y"], gx, gy) or []
                            self.path_goal = gk; self.path_t = self.t
                            if not self.path:
                                self.msg("You can't find a way there.", GREY); self.dest = None; self.pending = None; self.auto = False
                        while self.path and math.hypot(self.path[0][0] - p["x"], self.path[0][1] - p["y"]) < .25:
                            self.path.pop(0)
                        if self.path:
                            tx, ty = self.path[0]
                    else:
                        self.path = None
                    dx, dy = tx - p["x"], ty - p["y"]; dd = math.hypot(dx, dy) or 1
                    mvx, mvy = dx / dd, dy / dd
                    speed = min(speed, (d - stop) / max(dt, 1e-3) + .01)
        if self.w.fishing:                     # 0.42.5: casting a line holds you still - no auto-walk, no walking in place; a movement key reels in
            if keys_move and self.mode == "world": self.w.fish_cancel()
            else: mvx = mvy = 0.0; self.dest = None; self.path = None; self.pending = None if (self.pending and self.pending[0] != "cast") else self.pending
        if getattr(self.w.inst, "player_down", None) and self.w.inst.player_down(): mvx = mvy = 0.0; self.dest = None; self.path = None; self.pending = None     # 0.45.5: dead - wait out the respawn
        moving = bool(mvx or mvy)
        if moving: self.last_mv = (mvx, mvy)
        px0, py0 = p["x"], p["y"]
        if moving:
            step = speed * dt
            nx, ny = p["x"] + mvx * step, p["y"] + mvy * step
            if fly and not self.in_inst: p["x"], p["y"] = nx, ny
            elif self.walkable(nx, ny): p["x"], p["y"] = nx, ny
            elif self.walkable(nx, p["y"]): p["x"] = nx
            elif self.walkable(p["x"], ny): p["y"] = ny
            else:
                self.dest = None
            p["x"] = clamp(p["x"], 0, W - .01); p["y"] = clamp(p["y"], 0, (WORLD_H - .01) if fly else (H - .01))
            sdx = mvx - mvy
            if abs(sdx) > .05: self.player_anim["facing"] = 1 if sdx > 0 else -1
        self.player_anim["moving"] = moving and (abs(p["x"] - px0) + abs(p["y"] - py0) > 1e-4)     # blocked against water or a wall: stand, don't walk in place

    def goal_point(self):
        """Where the player should walk this frame (x, y, stop-distance)."""
        cls = self.w.class_name()
        if self.pending:
            kind = self.pending[0]
            if kind == "cast":
                a = self.actor(self.target)
                if a: return a["x"], a["y"], max(1.0, self.pending[2] - .4)
                self.pending = None
            elif kind == "pickup":
                return self.pending[2], self.pending[3], .6
            elif kind in ("talk",):
                a = self.actor(self.pending[1])
                if a: return a["x"], a["y"], 1.6
                self.pending = None
            elif kind == "gather":
                return self.pending[2], self.pending[3], 1.3
            elif kind == "station":
                return self.pending[2], self.pending[3], 2.6
            elif kind == "portal":
                return self.pending[2], self.pending[3], 1.8
        if self.auto and self.target is not None:
            a = self.actor(self.target)
            if a:
                rng = 1.3 if cls in MELEE else 4.6
                return a["x"], a["y"], rng
        if self.dest:
            return self.dest[0], self.dest[1], .05
        return None

    def resolve_pending(self):
        if not self.pending: return
        kind = self.pending[0]
        if kind == "cast":
            a = self.actor(self.target)
            if not a: self.pending = None; return
            if self.pdist(a["x"], a["y"]) <= self.pending[2] - .2:
                key = self.pending[1]; self.pending = None; self.cast(key)
        elif kind == "pickup":
            if self.pdist(self.pending[2], self.pending[3]) <= .9:
                lid = self.pending[1]; self.pending = None
                self.msg(self.w.pickup_loot(lid))
        elif kind == "talk":
            a = self.actor(self.pending[1])
            if a and self.pdist(a["x"], a["y"]) <= 2.0:
                self.pending = None; self.w.talk_to = a["id"]; self.msg(self.w.interact_nearby(), (255, 230, 150)); self.open_world_ui()
        elif kind == "station":
            if self.pdist(self.pending[2], self.pending[3]) <= 3.4:
                self.w.click_station = self.pending[1]; self.pending = None; self.w.talk_to = None; self.msg(self.w.interact_nearby(), (255, 230, 150)); self.open_world_ui()
        elif kind == "gather":
            if self.pdist(self.pending[2], self.pending[3]) <= 2.0:
                self.pending = None; r = self.w.interact_nearby(); self.msg(r, (170, 255, 170)); self.open_world_ui()
                if r and not r.startswith("Nothing"): self.audio.play("loot", .1)
        elif kind == "portal":
            if self.pdist(self.pending[2], self.pending[3]) <= 2.2:
                self.pending = None
                self.msg(self.w.enter_instance(), (255, 160, 60))
        elif kind == "leave":
            if self.pdist(self.pending[2], self.pending[3]) <= 2.6:
                self.pending = None; self.msg(self.w.leave_instance(), (200, 160, 255))

    def auto_attack(self):
        if not (self.auto and self.target is not None) or self.pending: return
        a = self.actor(self.target)
        if not a or not is_enemy(a, self.w.player): self.auto = False; return
        cls = self.w.class_name(); rng = 1.6 if cls in MELEE else 4.9
        if self.pdist(a["x"], a["y"]) > rng: return
        if self.t - self.last_swing < (1.0 if cls in MELEE else 1.15): return
        self.last_swing = self.t
        self.face_toward(a)
        self.player_anim["attack"] = self.t; self.last_weapon_t = self.t
        # 0.46: a weapon hit is drawn as steel - a white swing arc in melee, a plain white shot at range -
        # so it never looks like a spell (spells are coloured, with a rune circle at your feet).
        if cls in MELEE:
            self.effects.append({"type": "swing", "to": a["id"], "t0": self.t, "dur": .26, "col": (238, 238, 246)})
        else:
            self.effects.append({"type": "arrow" if cls == "Ranger" else "shot", "from": "player", "to": a["id"], "t0": self.t, "dur": .25, "col": (236, 232, 222)})
        self.effects.append({"type": "impact", "x": a["x"], "y": a["y"], "t0": self.t + (.05 if cls in MELEE else .24), "dur": .2, "col": (245, 245, 250)})
        r = self.w.attack_target(a["id"])
        if r.startswith("Defeated"):
            self.msg(r, (255, 220, 120))
            p = self.w.player
            m = re.search(r"\+(\d+)g", r)
            if m: self.floats.append({"x": p["x"], "y": p["y"], "txt": f"+{m.group(1)}g", "col": (255, 210, 60), "t0": self.t, "big": False, "up": 1})
        elif "out of range" in r:
            pass

    def face_toward(self, a):
        p = self.w.player
        sdx = (a["x"] - a["y"]) - (p["x"] - p["y"])
        if abs(sdx) > .05: self.player_anim["facing"] = 1 if sdx > 0 else -1

    def cast(self, key):
        abil = self.snap["abilities"]
        keys = "1234567890!@#$%^"
        if key not in keys: return
        i = keys.index(key)
        if i >= len(abil): return
        ab = abil[i]
        if ab.get("locked"):
            self.msg(f"{ab['name']} unlocks at level {ab['unlock']}.", (255, 120, 100)); return
        if not ab["ready"]:
            self.msg(f"{ab['name']} is not ready yet ({ab['cooldown']}s).", (255, 120, 100)); return
        if self.w.player.get("mana", 0) < ab["mana"]:
            self.msg(f"Not enough mana for {ab['name']}.", (255, 120, 100)); return
        p = self.w.player
        a = None
        if ab["cat"] == "attack" and ab["kind"] != "nova":
            a = self.actor(self.target)
            if a is None or not is_enemy(a, p):
                a = self.nearest_enemy(ab["range"] + 6)
                if a: self.target = a["id"]; self.w.selected_target = a["id"]
            if a is None:
                self.msg(f"{ab['name']}: no enemy nearby.", (255, 120, 100)); return
            if self.pdist(a["x"], a["y"]) > ab["range"]:
                self.pending = ("cast", key, ab["range"]); self.auto = True; return
            self.face_toward(a)
        ox, oy = p["x"], p["y"]
        before = self.w.ability_cooldowns.get(key, 0)
        r = self.w.use_ability(key)
        ok = self.w.ability_cooldowns.get(key, 0) > before
        if not ok:
            self.msg(r, (255, 120, 100)); return
        self.player_anim["attack"] = self.t
        col = element_color(ab["name"], self.w.class_name())
        k = ab["kind"]
        if ab["name"] in ("Blink", "Demonic Circle") and ab["kind"] == "sprint":
            mvx_, mvy_ = self.last_mv; l_ = math.hypot(mvx_, mvy_) or 1; mvx_ /= l_; mvy_ /= l_
            dist_ = 0.0; fl_ = self.w.is_flying()
            for st_ in range(1, 15):
                nx_, ny_ = ox + mvx_ * st_ * .6, oy + mvy_ * st_ * .6
                if not (fl_ or self.walkable(nx_, ny_)): break
                dist_ = st_ * .6
            if dist_ > 1:
                p["x"], p["y"] = ox + mvx_ * dist_, oy + mvy_ * dist_; self.dest = None; self.path = None
                self.effects.append({"type": "dash", "x0": ox, "y0": oy, "x": p["x"], "y": p["y"], "t0": self.t, "dur": .45, "col": element_color(ab["name"], self.w.class_name())})
                self.cam_snap = True if hasattr(self, "cam_snap") else None
            else: self.msg("Blink: something blocks the way.", (255, 200, 120))
        self.cast_banner = (ab["name"], self.t, col, ab["cat"], key)
        self.last_spell = (ab["name"], self.t, col, key)
        self.effects.append({"type": "castfx", "x": p["x"], "y": p["y"], "t0": self.t, "dur": .6, "col": col})
        self.floats.append({"x": p["x"], "y": p["y"], "txt": ab["name"], "col": col, "t0": self.t, "big": True, "up": 1})
        if key in "!@#$%^":
            tx_, ty_ = (a["x"], a["y"]) if (a and ab["cat"] == "attack" and k != "nova") else (p["x"], p["y"])
            self.effects.append({"type": "cap", "x": tx_, "y": ty_, "t0": self.t, "dur": 1.1, "col": col})
        if ab["cat"] == "defense":
            fx = {"heal": "heal", "hot": "heal", "shield": "bubble", "armor": "ring", "dodge": "swirl", "sprint": "dust", "vanish": "smoke"}.get(k, "heal")
            self.effects.append({"type": fx, "x": p["x"], "y": p["y"], "t0": self.t, "dur": 1.0, "col": col})
            hp = re.search(r"restored (\d+)", r)
            if hp: self.floats.append({"x": p["x"], "y": p["y"], "txt": f"+{hp.group(1)}", "col": (90, 255, 110), "t0": self.t, "big": True})
            self.msg(r, (140, 230, 255)); return
        self.auto = True; self.last_swing = self.t
        if k == "nova":
            self.effects.append({"type": "nova", "x": p["x"], "y": p["y"], "t0": self.t, "dur": .6, "col": col, "r": ab["range"]})
        elif k == "charge":
            self.effects.append({"type": "dash", "x0": ox, "y0": oy, "x": p["x"], "y": p["y"], "t0": self.t, "dur": .45, "col": col})
            if a:
                self.effects.append({"type": "crescent", "to": a["id"], "t0": self.t + .1, "dur": .34, "col": col})
                self.effects.append({"type": "burst", "to": a["id"], "t0": self.t + .18, "dur": .4, "col": col, "big": True})
        elif a:
            ranged = ab["range"] > 3
            n = int(ab.get("hits", 1)) if k == "multi" else 1
            for j in range(n):
                if ranged:
                    self.effects.append({"type": "arrow" if self.w.class_name() == "Ranger" else "bolt", "from": "player", "to": a["id"], "spell": True,
                                         "t0": self.t + j * .14, "dur": .34, "col": col, "big": k in ("execute", "stun", "aoe")})
                    self.effects.append({"type": "burst", "to": a["id"], "t0": self.t + j * .14 + .32, "dur": .45, "col": col, "big": k in ("execute", "stun", "aoe")})
                else:
                    self.effects.append({"type": "crescent", "to": a["id"], "t0": self.t + j * .14, "dur": .34, "col": col})
                    self.effects.append({"type": "burst", "to": a["id"], "t0": self.t + j * .14 + .1, "dur": .4, "col": col, "big": k in ("execute", "stun")})
            if k == "aoe":
                self.effects.append({"type": "nova", "x": a["x"], "y": a["y"], "t0": self.t + (.25 if ranged else 0), "dur": .55, "col": col, "r": 2.2})
        self.msg(r)
    def nearest_enemy(self, rng=12):
        p = self.w.player; best = None; bd = rng
        for a in self.snap["actors"]:
            if not is_enemy(a, p): continue
            d = math.hypot(a["x"] - p["x"], a["y"] - p["y"])
            if d < bd: best, bd = a, d
        return best

    def cycle_target(self):
        p = self.w.player
        cands = sorted((a for a in self.snap["actors"] if is_enemy(a, p) and math.hypot(a["x"] - p["x"], a["y"] - p["y"]) < 14),
                       key=lambda a: math.hypot(a["x"] - p["x"], a["y"] - p["y"]))
        if not cands: self.msg("No enemies nearby.", GREY); return
        ids = [a["id"] for a in cands]
        i = (ids.index(self.target) + 1) % len(ids) if self.target in ids else 0
        self.target = ids[i]; self.w.selected_target = self.target

    # ------------------------------------------------------ drawing: world
    def draw_world(self):
        snap = self.snap; p = self.w.player; now = self.t
        pcx, pcy = iso(p["x"], p["y"])
        shx = shy = 0
        if self.shake > .02 and self.quality > 0:
            shx = int(math.sin(now * 91) * self.shake); shy = int(math.cos(now * 77) * self.shake)
        self.shake *= .86
        # 0.40.4: free-look. Holding the left button and dragging scrolls the view; it stays put while you stand
        # still and eases back to the hero as soon as you move (or if the button is released off-window).
        ld = self.look_drag
        if ld and not pygame.mouse.get_pressed()[0]: self.look_drag = ld = None
        pp = (p["x"], p["y"])
        if ld: self._look_back = False
        elif self._look_pp is not None and math.hypot(pp[0] - self._look_pp[0], pp[1] - self._look_pp[1]) > .02: self._look_back = True
        if self._look_back and not ld:
            if self.look[0] or self.look[1]:
                k = 1 - math.exp(-10 * min(self.dt, .1))
                self.look[0] -= self.look[0] * k; self.look[1] -= self.look[1] * k
                if abs(self.look[0]) < .5 and abs(self.look[1]) < .5: self.look = [0.0, 0.0]
            else: self._look_back = False
        self._look_pp = pp
        self.cam = (pcx - LW // 2 + shx + int(self.look[0]), pcy - LH // 2 - 30 + shy + int(self.look[1]))
        cam0, cam1 = self.cam
        self._sync_until = time.perf_counter() + .006       # 0.38.1: at most ~6 ms a frame finishing visible ground here
        for ty in range(math.floor(cam1 / GT), math.floor((cam1 + LH) / GT) + 1):
            for tx in range(math.floor(cam0 / GT), math.floor((cam0 + LW) / GT) + 1):
                screen.blit(self.ground_tile(tx, ty), (tx * GT - cam0, ty * GT - cam1))
        # visible tile range
        corners = [self.to_world(c) for c in ((0, 0), (LW, 0), (0, LH), (LW, LH))]
        xs = [c[0] for c in corners]; ys = [c[1] for c in corners]
        x0, x1 = int(min(xs)) - 2, int(max(xs)) + 3; y0, y1 = int(min(ys)) - 2, int(max(ys)) + 3
        cx0, cx1 = x0 // CS, x1 // CS; cy0, cy1 = y0 // CS, y1 // CS
        drawables = []; self.visible_water = []; self.visible_lava = []
        for cy in range(cy0, cy1 + 1):
            for cx in range(cx0, cx1 + 1):
                sx, sy = self.to_screen(cx * CS, cy * CS)
                bx = sx - CS * HTW
                if bx > LW or bx + CS * TW < 0 or sy > LH or sy + CS * TH < 0: continue
                if cx < -1 or cy < -1 or cx * CS > W or cy * CS > H:
                    continue
                if self.in_inst and cy * CS < WORLD_H: continue
                wl_, lv_ = self.fluids(cx, cy)
                if wl_: self.visible_water.extend(wl_)
                if lv_: self.visible_lava.extend(lv_)
                for it in self.decor(cx, cy):
                    ix = (it[0] - it[1]) * HTW - cam0; iy = (it[0] + it[1]) * HTH - cam1
                    if -150 < ix < LW + 150 and -40 < iy < LH + 200:       # cull off-screen decor before sorting
                        drawables.append((it[0] + it[1], 0, it))
        self.draw_fluids()
        # buildings
        for b in ([] if self.in_inst else self.buildings):
            bx, by, spr, anc, bw, bd, kind = b
            if abs(bx - p["x"]) > 30 or abs(by - p["y"]) > 30: continue
            if kind in ("house", "tower"): key = bx + by + (bw + bd) * .5
            else: key = bx + by
            drawables.append((key, 1, b))
        for d in ([] if self.in_inst else self.w.dungeons):
            if abs(d.x - p["x"]) < 30 and abs(d.y - p["y"]) < 30:
                drawables.append((d.x + d.y, 2, d))
        for wl in (self.inst_walls if self.in_inst else self.walls):
            if x0 - 2 <= wl[0] <= x1 + 2 and y0 - 2 <= wl[1] <= y1 + 2:
                drawables.append((wl[0] + wl[1] + 1, 6, wl))
        for pr in (self.inst_props if self.in_inst else self.layout.props):
            if abs(pr[0] - p["x"]) < 30 and abs(pr[1] - p["y"]) < 30:
                drawables.append((pr[0] + pr[1], 7, pr))
        for l in snap["loot"]:
            if abs(l["x"] - p["x"]) < 30 and abs(l["y"] - p["y"]) < 30:
                drawables.append((l["x"] + l["y"] - .3, 3, l))
        for h in snap.get("herbs", []):
            if abs(h["x"] - p["x"]) < 30 and abs(h["y"] - p["y"]) < 30:
                drawables.append((h["x"] + h["y"] - .2, 8, h))
        for v in snap.get("veins", []):
            if abs(v["x"] - p["x"]) < 30 and abs(v["y"] - p["y"]) < 30:
                drawables.append((v["x"] + v["y"] - .2, 9, v))
        for sk in snap.get("skins", []):
            drawables.append((sk["x"] + sk["y"] + .1, 10, sk))
        for a in snap["actors"]:
            d = self.disp.get(a["id"])
            if d: drawables.append((d["x"] + d["y"], 4, a))
        drawables.append((p["x"] + p["y"], 5, None))
        drawables.sort(key=lambda e: e[0])
        self.portal_rects = []
        self.draw_hazards()

        # ground overlays: click marker, target ring, shadows
        if self.click_fx and now - self.click_fx[2] < .6:
            sx, sy = self.to_screen(*self.click_fx[:2]); k = (now - self.click_fx[2]) / .6
            pygame.draw.ellipse(screen, (255, 230, 120), (sx - 14 * (1 - k) - 4, sy - 7 * (1 - k) - 2, 28 * (1 - k) + 8, 14 * (1 - k) + 4), 2)
        tgt = self.actor(self.target)
        if tgt:
            d = self.disp.get(tgt["id"])
            if d:
                sx, sy = self.to_screen(d["x"], d["y"])
                pulse = 1 + .08 * math.sin(now * 6)
                col = (255, 60, 50) if is_enemy(tgt, p) else (255, 230, 90)
                r = pygame.Rect(0, 0, 54 * pulse, 26 * pulse); r.center = (sx, sy)
                pygame.draw.ellipse(screen, col, r, 3)
                pygame.draw.ellipse(screen, shade(col, .6), r.inflate(10, 5), 1)
        for e in self.effects:
            if e["type"] == "nova" and now >= e["t0"]:
                k = (now - e["t0"]) / e["dur"]
                if 0 <= k <= 1:
                    sx, sy = self.to_screen(e["x"], e["y"]); rr = e["r"] * HTW * (.3 + k)
                    s = pygame.Surface((rr * 2 + 4, rr + 4), pygame.SRCALPHA)
                    pygame.draw.ellipse(s, (*e["col"], int(150 * (1 - k))), (0, 0, rr * 2 + 4, rr + 4))
                    pygame.draw.ellipse(s, (*e["col"], int(255 * (1 - k))), (0, 0, rr * 2 + 4, rr + 4), 4)
                    screen.blit(s, (sx - rr - 2, sy - rr / 2 - 2))

        self.draw_corpses(now)
        self.hit_rects = []; self.loot_rects = []; plates = []; slabels = []
        sun = self._sun(); self._shn = 0
        for key, typ, obj in drawables:
            if typ == 0:
                dx, dy, kind, var = obj
                spr, anc = gfx.decor_sprite(kind, var)
                sx, sy = self.to_screen(dx, dy)
                if -150 < sx < LW + 150 and -40 < sy < LH + 200:
                    if sun and kind in gfx.SHADOW_DECOR: self._shadow(spr, anc, sx, sy, sun)
                    screen.blit(spr, (sx - anc[0], sy - anc[1]))
            elif typ == 1:
                bx, by, spr, anc, bw, bd, kind = obj
                sx, sy = self.to_screen(bx, by)
                if sun and kind in ("house", "tower") + gfx.STATION_KINDS and kind != "warhall" and -200 < sx < LW + 200 and -100 < sy < LH + 250:
                    self._shadow(spr, anc, sx + int(bw * 8), sy + int(bd * 8), sun)
                _br = screen.blit(spr, (sx - anc[0], sy - anc[1]))
                if kind in gfx.STATION_KINDS:
                    self.hit_rects.append((_br, ("station", kind, bx + bw / 2, by + bd / 2)))
                    slabels.append((kind, sx, sy - anc[1] - (22 if kind == "warhall" else 0), bx + bw / 2, by + bd / 2))
                if kind == "house" and -100 < sx < LW + 100 and -100 < sy < LH + 200 and gfx.h01(bx, by, 77) < .6:
                    self._chimney_smoke(screen, sx - anc[0] + spr.get_width() * .68, sy - anc[1] + spr.get_height() * .12, bx * 7 + by)
            elif typ == 2:
                self.draw_portal(obj)
            elif typ == 3:
                spr = gfx.loot_sprite(obj["rarity"])
                sx, sy = self.to_screen(obj["x"], obj["y"])
                bob = math.sin(now * 3 + obj["id"]) * 2
                if obj["rarity"] in ("Rare", "Epic", "Elite", "Legendary", "Set", "Mythic") and self.quality > 0:
                    bc = gfx.RARITY_COLOR.get(obj["rarity"], (255, 255, 255)); hh = 70 if obj["rarity"] != "Rare" else 46
                    bk_ = ("beam", obj["rarity"])
                    bs_ = self._shd.get(bk_)
                    if bs_ is None:
                        bs_ = pygame.Surface((22, hh), pygame.SRCALPHA)
                        for yy in range(hh):
                            pygame.draw.line(bs_, (*bc, int(110 * (1 - yy / hh))), (6, hh - 1 - yy), (15, hh - 1 - yy))
                        self._shd[bk_] = bs_
                    screen.blit(bs_, (sx - 11, sy - hh + 6))
                r = screen.blit(spr, (sx - spr.get_width() // 2, sy - spr.get_height() + 8 + bob))
                self.loot_rects.append((r.inflate(10, 10), obj))
                if self.pdist(obj["x"], obj["y"]) < 10:
                    plates.append(("loot", sx, sy - spr.get_height() + 2, obj))
            elif typ == 9:
                spr = gfx.vein_sprite(obj["band"])
                sx, sy = self.to_screen(obj["x"], obj["y"])
                r_ = screen.blit(spr, (sx - spr.get_width() // 2, sy - spr.get_height() + 12))
                self.hit_rects.append((r_, ("node", obj)))
                if self.pdist(obj["x"], obj["y"]) < 6:
                    g_ = gfx.glow(24 + int(4 * math.sin(now * 4)), shade(gfx.VEIN_COL[obj["band"] % 5], .45))
                    screen.blit(g_, (sx - g_.get_width() // 2, sy - 18 - g_.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
                if self.pdist(obj["x"], obj["y"]) < 9 or self.hover_node == obj["id"]:
                    plates.append(("node", sx, sy - spr.get_height() + 6, obj))
            elif typ == 10:
                sx, sy = self.to_screen(obj["x"], obj["y"])
                pul = .6 + .4 * math.sin(now * 4 + obj["id"])
                pygame.draw.ellipse(screen, (int(230 * pul), int(190 * pul), int(120 * pul)), (sx - 22, sy - 9, 44, 18), 2)
                self.hit_rects.append((pygame.Rect(sx - 26, sy - 30, 52, 44), ("node", obj)))
                if self.pdist(obj["x"], obj["y"]) < 9:
                    plates.append(("node", sx, sy - 20, dict(obj, name=f"{obj['name']} carcass", skin=True)))
            elif typ == 8:
                spr = gfx.herb_sprite(obj["band"])
                sx, sy = self.to_screen(obj["x"], obj["y"])
                r_ = screen.blit(spr, (sx - spr.get_width() // 2, sy - spr.get_height() + 10))
                self.hit_rects.append((r_, ("node", obj)))
                if self.pdist(obj["x"], obj["y"]) < 7:
                    plates.append(("node", sx, sy - spr.get_height() + 8, obj))
                if self.pdist(obj["x"], obj["y"]) < 6:
                    g_ = gfx.glow(26 + int(4 * math.sin(now * 5)), (120, 255, 140))
                    screen.blit(g_, (sx - g_.get_width() // 2, sy - 22 - g_.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
            elif typ == 4:
                self.draw_actor(obj, plates)
            elif typ == 5:
                self.draw_player(plates)
            elif typ == 6:
                spr, anc = gfx.wall_sprite(obj[2], obj[3], obj[4] if len(obj) > 4 else None)
                sx, sy = self.to_screen(obj[0], obj[1])
                if -80 < sx < LW + 80 and -60 < sy < LH + 120:
                    screen.blit(spr, (sx - anc[0], sy - anc[1]))
            elif typ == 7:
                spr, anc = gfx.prop_sprite(obj[2], obj[3])
                sx, sy = self.to_screen(obj[0], obj[1])
                screen.blit(spr, (sx - anc[0], sy - anc[1]))
                if obj[2] == "portal":
                    self.portal_rects.append((pygame.Rect(sx - 30, sy - 70, 60, 74), (obj[0], obj[1])))
                    g_ = gfx.glow(int(46 + math.sin(now * 4) * 6), (70, 40, 140))
                    screen.blit(g_, (sx - g_.get_width() // 2, sy - 40 - g_.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
                elif obj[2] == "campfire":
                    fl = 1 + .14 * math.sin(now * 12 + obj[0])
                    g_ = gfx.glow(int(40 * fl), (120, 62, 20))
                    screen.blit(g_, (sx - g_.get_width() // 2, sy - 22 - g_.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
                elif obj[2] == "brazier":
                    fl = 1 + .15 * math.sin(now * 11 + obj[0])
                    g_ = gfx.glow(int(56 * fl), (140, 78, 26))
                    screen.blit(g_, (sx - g_.get_width() // 2, sy - 44 - g_.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
        # 0.46: lighting first, then spells and weapon effects on top at full brightness
        self.draw_lighting()
        # projectiles & effects in air
        for e in self.effects:
            k = (now - e["t0"]) / e["dur"]
            if k < 0 or k > 1: continue
            if e["type"] in ("arrow", "bolt"):
                tp = self.ref_pos(e["to"])
                if not tp: continue
                sp_ = self.ref_pos(e["src"]) if e.get("src") is not None else (p["x"], p["y"])
                if not sp_: continue
                sx0, sy0 = self.to_screen(*sp_); sy0 -= 34
                sx1, sy1 = self.to_screen(*tp); sy1 -= 24
                x = sx0 + (sx1 - sx0) * k; y = sy0 + (sy1 - sy0) * k - math.sin(k * math.pi) * 20
                if e["type"] == "arrow":
                    ang = math.atan2(sy1 - sy0, sx1 - sx0)
                    pygame.draw.line(screen, e["col"], (x - math.cos(ang) * 14, y - math.sin(ang) * 14), (x, y), 2)
                else:
                    rr = (14 if e.get("big") else 11) if e.get("spell") else (9 if e.get("big") else 6)
                    g = gfx.glow(rr * 4, tuple(int(c * .6) for c in e["col"]))
                    screen.blit(g, (x - rr * 4, y - rr * 4), special_flags=pygame.BLEND_RGB_ADD)
                    for tr in range(1, 8 if e.get("spell") else 4):
                        kk = max(0, k - tr * .05)
                        tx_ = sx0 + (sx1 - sx0) * kk; ty_ = sy0 + (sy1 - sy0) * kk - math.sin(kk * math.pi) * 20
                        tg_ = max(2, rr + 3 - tr); tc_ = max(0.0, .55 - tr * (.06 if e.get("spell") else .12))
                        screen.blit(gfx.glow(tg_, tuple(int(c * tc_) for c in e["col"])), (tx_ - tg_, ty_ - tg_), special_flags=pygame.BLEND_RGB_ADD)
                    s = pygame.Surface((rr * 4, rr * 4), pygame.SRCALPHA)
                    pygame.draw.circle(s, (*e["col"], 90), (rr * 2, rr * 2), rr * 2)
                    pygame.draw.circle(s, e["col"], (rr * 2, rr * 2), rr)
                    pygame.draw.circle(s, (255, 255, 255), (rr * 2, rr * 2), rr // 2)
                    screen.blit(s, (x - rr * 2, y - rr * 2))
            elif e["type"] == "shot":            # 0.46: a plain weapon shot (wand, staff, bolt) - white, small, no glow
                tp = self.ref_pos(e["to"])
                if not tp: continue
                sx0, sy0 = self.to_screen(p["x"], p["y"]); sy0 -= 34
                sx1, sy1 = self.to_screen(*tp); sy1 -= 24
                x = sx0 + (sx1 - sx0) * k; y = sy0 + (sy1 - sy0) * k
                kk = max(0, k - .18); x2 = sx0 + (sx1 - sx0) * kk; y2 = sy0 + (sy1 - sy0) * kk
                pygame.draw.line(screen, (150, 150, 160), (x2, y2), (x, y), 2)
                pygame.draw.circle(screen, (60, 60, 66), (int(x), int(y)), 4); pygame.draw.circle(screen, e["col"], (int(x), int(y)), 3)
            elif e["type"] == "swing":           # 0.46: weapon swing - a steel arc in front of you, toward the target
                ta = self.ref_pos(e["to"])
                if not ta: continue
                sx0, sy0 = self.to_screen(p["x"], p["y"]); sy0 -= 30
                sx1, sy1 = self.to_screen(*ta); sy1 -= 26
                ang = math.atan2(sy1 - sy0, sx1 - sx0)
                a0 = ang - 1.25 + k * 2.5
                arc_ = pygame.Surface((140, 140), pygame.SRCALPHA)
                pts_o = []; pts_i = []
                for i in range(9):
                    aa = a0 - i * .14
                    pts_o.append((70 + math.cos(aa) * 52, 70 + math.sin(aa) * 52 * .8)); pts_i.append((70 + math.cos(aa) * (36 + i * 1.6), 70 + math.sin(aa) * (36 + i * 1.6) * .8))
                fade = int(230 * (1 - k))
                pygame.draw.polygon(arc_, (*e["col"], max(0, fade // 2)), pts_o + pts_i[::-1])
                pygame.draw.lines(arc_, (255, 255, 255, fade), False, pts_o, 3)
                screen.blit(arc_, (sx0 + math.cos(ang) * 16 - 70, sy0 + math.sin(ang) * 12 - 70))
            elif e["type"] == "crescent":        # 0.46: melee skill - a big coloured crescent cutting through the target
                ta = self.ref_pos(e["to"])
                if not ta: continue
                sx, sy = self.to_screen(*ta); sy -= 30
                a0 = -2.6 + k * 3.0; fade = 1 - k
                cs_ = pygame.Surface((160, 160), pygame.SRCALPHA)
                pts_o = []; pts_i = []
                for i in range(12):
                    aa = a0 - i * .13; th = 4 + 14 * math.sin(i / 11 * math.pi)
                    pts_o.append((80 + math.cos(aa) * 58, 80 + math.sin(aa) * 46)); pts_i.append((80 + math.cos(aa) * (58 - th), 80 + math.sin(aa) * (46 - th * .8)))
                pygame.draw.polygon(cs_, (*e["col"], int(200 * fade)), pts_o + pts_i[::-1])
                pygame.draw.lines(cs_, (255, 255, 255, int(240 * fade)), False, pts_o, 3)
                g = gfx.glow(56, tuple(int(c * .45 * fade) for c in e["col"]))
                screen.blit(g, (sx - 56, sy - 56), special_flags=pygame.BLEND_RGB_ADD)
                screen.blit(cs_, (sx - 80, sy - 80))
            elif e["type"] == "slash":
                ta = self.ref_pos(e["to"])
                if not ta: continue
                sx, sy = self.to_screen(*ta); sy -= 26
                a0 = -2.4 + k * 2.6
                for i in range(3):
                    aa = a0 - i * .18
                    pygame.draw.line(screen, shade(e["col"], 1 - i * .25), (sx + math.cos(aa) * 8, sy + math.sin(aa) * 8), (sx + math.cos(aa) * 30, sy + math.sin(aa) * 30), 4 - i)
            elif e["type"] == "heal":
                sx, sy = self.to_screen(e["x"], e["y"])
                for i in range(8):
                    a = i / 8 * math.tau + k * 3
                    px = sx + math.cos(a) * 20; py = sy - 10 - k * 50 + math.sin(a) * 8
                    pygame.draw.circle(screen, (120, 255, 140), (int(px), int(py)), 3)
            elif e["type"] == "death":
                sx, sy = self.to_screen(e["x"], e["y"])
                for i in range(10):
                    a = i / 10 * math.tau
                    r = 6 + k * 26
                    pygame.draw.circle(screen, (200, 200, 210), (int(sx + math.cos(a) * r), int(sy - 18 + math.sin(a) * r * .6 - k * 12)), max(1, int(5 * (1 - k))))
        self.draw_fx_extra(now)
        self.effects = [e for e in self.effects if now - e["t0"] < e["dur"] + .05 or now < e["t0"]]
        if self.quality >= 2: self.draw_sun_rays(); self.sharpen_world()
        self.draw_weather()
        # name plates on top
        for kind_, sx_, top_, cx_, cy_ in slabels:
            if -150 < sx_ < LW + 150 and -40 < top_ < LH + 40:
                name_, sub_ = STATION_LABELS[kind_]
                ty_ = max(30, top_ + 4)
                for txt_, y_, col_, f_, th_ in ((sub_, ty_ - 20, (255, 215, 110), F_BD, 1), (name_, ty_, (255, 240, 205), F_NPC, 2)):
                    ts_ = heavy_text(txt_, sx_, y_, col_, f_, th_)
                    self.hit_rects.append((pygame.Rect(sx_ - ts_.get_width() // 2, y_, ts_.get_width(), ts_.get_height()), ("station", kind_, cx_, cy_)))
        for pl in plates:
            self.draw_plate(pl)
        # floating combat text
        alive = []
        for f in self.floats:
            k = (now - f["t0"]) / 1.1
            if k > 1: continue
            alive.append(f)
            d = self.disp.get(f.get("id"))
            sx, sy = self.to_screen(f["x"], f["y"])
            # Conquer-style: numbers pop in large, then arc up and drift sideways while fading
            y = sy - 74 - math.sin(min(1, k * 1.25) * math.pi * .75) * 44 - k * 10
            drift = (f.get("dx", 0) or 0) + (k * 18 * (1 if (hash(f["txt"]) & 1) else -1) if f["big"] else 0)
            fnt = F_CRIT if f.get("crit") else (F_DMG if f["big"] else F_BD)
            t_ = tsurf(f["txt"], f["col"], fnt, True)
            if f["big"] and k < .16:
                t_ = pygame.transform.rotozoom(t_, 0, (2.0 if f.get("crit") else 1.5) - k * (6.2 if f.get("crit") else 3.1))
            if k > .7:
                t_ = t_.copy(); t_.set_alpha(int(255 * (1 - (k - .7) / .3)))
            screen.blit(t_, (sx + drift + (8 if f.get("up") else 0) - t_.get_width() // 2, y))
        self.floats = alive

    def draw_fx_extra(self, now):
        """Glow effects for skills: novas, shields, dashes, level-up beams."""
        p = self.w.player
        for e in self.effects:
            k = (now - e["t0"]) / e["dur"]
            if k < 0 or k > 1: continue
            t = e["type"]
            if t == "nova":
                sx, sy = self.to_screen(e["x"], e["y"])
                g = gfx.glow(int(e["r"] * HTW * (.4 + k)), tuple(int(c * .55 * (1 - k)) for c in e["col"]))
                screen.blit(pygame.transform.scale(g, (g.get_width(), g.get_height() // 2)), (sx - g.get_width() // 2, sy - g.get_height() // 4), special_flags=pygame.BLEND_RGB_ADD)
                for ring in range(3):
                    kk = clamp(k * 1.3 - ring * .12, 0, 1)
                    if kk <= 0: continue
                    rw = e["r"] * HTW * (.2 + kk * .85)
                    rs_ = pygame.Surface((int(rw * 2) + 6, int(rw) + 6), pygame.SRCALPHA)
                    pygame.draw.ellipse(rs_, (*e["col"], int(210 * (1 - kk))), (2, 2, int(rw * 2), int(rw)), 3 - ring // 2)
                    screen.blit(rs_, (sx - rw - 3, sy - rw / 2 - 3))
                for i in range(10):
                    a = i / 10 * math.tau + k
                    rr = e["r"] * HTW * (.3 + k)
                    screen.blit(gfx.glow(6, e["col"]), (sx + math.cos(a) * rr - 6, sy + math.sin(a) * rr * .5 - 6 - k * 10), special_flags=pygame.BLEND_RGB_ADD)
            elif t in ("heal", "bubble", "ring", "swirl", "dust", "smoke", "levelup", "step", "impact"):
                if t in ("impact", "step") and "x" in e: sx, sy = self.to_screen(e["x"], e["y"])     # where it happened, not on the hero
                else: sx, sy = self.to_screen(p["x"], p["y"])
                col = e.get("col", (120, 255, 140))
                if t == "heal":
                    g = gfx.glow(46, (30, 110, 40))
                    screen.blit(g, (sx - 46, sy - 60 - 46), special_flags=pygame.BLEND_RGB_ADD)
                    for i in range(10):
                        a = i / 10 * math.tau + k * 4
                        screen.blit(gfx.glow(6, (120, 255, 140)), (sx + math.cos(a) * 22 - 6, sy - 10 - k * 80 - i * 4 + math.sin(a) * 8 - 6), special_flags=pygame.BLEND_RGB_ADD)
                    for i in range(4):
                        px_ = sx + (i - 1.5) * 14; py_ = sy - 20 - ((k + i * .22) % 1) * 70
                        pygame.draw.rect(screen, (170, 255, 190), (px_ - 1, py_ - 4, 3, 9)); pygame.draw.rect(screen, (170, 255, 190), (px_ - 4, py_ - 1, 9, 3))
                elif t == "bubble":
                    rr = int(30 + 20 * min(1, k * 3))
                    bs = pygame.Surface((rr * 2 + 4, rr * 2 + 4), pygame.SRCALPHA)
                    pygame.draw.circle(bs, (120, 190, 255, int(46 * (1 - k * .6))), (rr + 2, rr + 2), rr)
                    pygame.draw.circle(bs, (190, 230, 255, int(200 * (1 - k * .5))), (rr + 2, rr + 2), rr, 2)
                    pygame.draw.ellipse(bs, (255, 255, 255, int(150 * (1 - k))), (rr * .45, rr * .3, rr * .5, rr * .28))
                    screen.blit(bs, (sx - rr - 2, sy - 50 - rr - 2))
                elif t == "ring":
                    for i in range(3):
                        rr = 20 + i * 12 + k * 20
                        pygame.draw.ellipse(screen, (255, 210, 90), (sx - rr, sy - rr / 2, rr * 2, rr), 2)
                elif t == "swirl":
                    for i in range(12):
                        a = i / 12 * math.tau + k * 10
                        screen.blit(gfx.glow(5, (200, 255, 200)), (sx + math.cos(a) * 26 - 5, sy - 30 + math.sin(a) * 12 - i * 3 - 5), special_flags=pygame.BLEND_RGB_ADD)
                elif t == "impact":
                    rr = 6 + k * 26
                    isf = pygame.Surface((int(rr * 2) + 6, int(rr * 2) + 6), pygame.SRCALPHA)
                    pygame.draw.circle(isf, (*col, int(230 * (1 - k))), (int(rr) + 3, int(rr) + 3), int(rr), 2)
                    screen.blit(isf, (sx - rr - 3, sy - 34 - rr - 3))
                    for i in range(6):
                        a_ = i * 1.047 + e["t0"] * 7
                        screen.blit(gfx.glow(4, col), (sx + math.cos(a_) * rr * 1.3 - 4, sy - 34 + math.sin(a_) * rr * 1.3 - 4), special_flags=pygame.BLEND_RGB_ADD)
                elif t == "step":
                    r_ = int(2 + k * 4); ss_ = pygame.Surface((r_ * 2 + 2, r_ * 2 + 2), pygame.SRCALPHA)
                    pygame.draw.circle(ss_, (*e["col"], int(90 * (1 - k))), (r_ + 1, r_ + 1), r_)
                    screen.blit(ss_, (sx - r_ - 1, sy - r_ - 1 - k * 6))
                elif t == "dust":
                    for i in range(8):
                        pygame.draw.circle(screen, (200, 190, 160), (int(sx - 10 - i * 6 * k * 3), int(sy - 3 - (i % 3) * 3)), max(1, int(5 * (1 - k))))
                elif t == "smoke":
                    for i in range(14):
                        a = i / 14 * math.tau
                        rr = 10 + k * 40
                        pygame.draw.circle(screen, (90, 90, 110), (int(sx + math.cos(a) * rr), int(sy - 30 + math.sin(a) * rr * .5 - k * 20)), max(1, int(9 * (1 - k))))
                elif t == "levelup":
                    w_ = int(60 * (1 - abs(k - .3)))
                    g = gfx.glow(max(8, w_), (120, 100, 30))
                    for j in range(6):
                        screen.blit(g, (sx - g.get_width() // 2, sy - 40 - j * 40 - g.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
                    for i in range(16):
                        a = i / 16 * math.tau + k * 6
                        screen.blit(gfx.glow(6, (255, 220, 90)), (sx + math.cos(a) * 34 - 6, sy - k * 160 + math.sin(a) * 12 - 6), special_flags=pygame.BLEND_RGB_ADD)
            elif t == "aheal":
                a0 = self.ref_pos(e["src"]); a1 = self.ref_pos(e["to"])
                if not a0 or not a1: continue
                x0, y0 = self.to_screen(*a0); x1, y1 = self.to_screen(*a1); y0 -= 40; y1 -= 30
                fade = 1 - k
                for i in range(9):
                    f = i / 8
                    screen.blit(gfx.glow(8, (int(40 * fade), int(140 * fade), int(60 * fade))), (x0 + (x1 - x0) * f - 8, y0 + (y1 - y0) * f - 8 - math.sin(f * math.pi) * 18), special_flags=pygame.BLEND_RGB_ADD)
                g = gfx.glow(34, (int(30 * fade), int(110 * fade), int(40 * fade)))
                screen.blit(g, (x1 - 34, y1 - 34), special_flags=pygame.BLEND_RGB_ADD)
                for i in range(6):
                    a = i / 6 * math.tau + k * 5
                    screen.blit(gfx.glow(5, (120, 255, 140)), (x1 + math.cos(a) * 16 - 5, y1 + 10 - k * 50 + math.sin(a) * 6 - 5), special_flags=pygame.BLEND_RGB_ADD)
            elif t == "taunt":
                a0 = self.ref_pos(e["src"])
                if not a0: continue
                x0, y0 = self.to_screen(*a0)
                for i in range(2):
                    rr = 18 + (k + i * .3) * 46
                    pygame.draw.ellipse(screen, (255, 90, 60), (x0 - rr, y0 - rr * .5, rr * 2, rr), 2)
                text("!", x0, y0 - 92 - k * 10, (255, 90, 60), F_CRIT, True, center=True)
            elif t == "cap":
                sx, sy = self.to_screen(e["x"], e["y"])
                col = e["col"]; fade = 1 - k
                beam = gfx.glow(int(60 * (1 - abs(k - .25) * 1.2) + 14), tuple(int(c * .5) for c in col))
                for j in range(9):
                    screen.blit(beam, (sx - beam.get_width() // 2, sy - 20 - j * 36 * (1 - k * .3) - beam.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
                rr = 24 + k * 120
                rs_ = pygame.Surface((int(rr * 2) + 6, int(rr) + 6), pygame.SRCALPHA)
                pygame.draw.ellipse(rs_, (*col, int(230 * fade)), (2, 2, int(rr * 2), int(rr)), 4)
                pygame.draw.ellipse(rs_, (255, 255, 255, int(140 * fade)), (2 + rr * .25, 2 + rr * .12, rr * 1.5, rr * .76), 2)
                screen.blit(rs_, (sx - rr - 3, sy - rr / 2 - 3))
                for i in range(18):
                    a = i / 18 * math.tau + k * 2
                    d_ = 14 + k * 90 * (.5 + (i % 3) * .3)
                    screen.blit(gfx.glow(8, tuple(int(c * fade) for c in col)), (sx + math.cos(a) * d_ - 8, sy - 20 + math.sin(a) * d_ * .5 - k * 50 - 8), special_flags=pygame.BLEND_RGB_ADD)
                if k < .35:
                    fy_ = sy - 360 + (k / .35) * 340
                    screen.blit(gfx.glow(40, col), (sx - 40, fy_ - 40), special_flags=pygame.BLEND_RGB_ADD)
            elif t == "castfx":                  # 0.46: spell cast - a turning rune circle at your feet and light gathering in your hands
                sx, sy = self.to_screen(p["x"], p["y"]); col = e["col"]
                grow = min(1, k * 4); fade = 1 - max(0, (k - .55) / .45)
                rw = 30 + 18 * grow
                rs_ = pygame.Surface((int(rw * 2) + 8, int(rw) + 8), pygame.SRCALPHA)
                pygame.draw.ellipse(rs_, (*col, int(70 * fade)), (4, 4, int(rw * 2), int(rw)))
                pygame.draw.ellipse(rs_, (*col, int(240 * fade)), (4, 4, int(rw * 2), int(rw)), 3)
                pygame.draw.ellipse(rs_, (255, 255, 255, int(160 * fade)), (4 + rw * .3, 4 + rw * .15, rw * 1.4, rw * .7), 2)
                for i in range(6):                # runes on the ring
                    aa = i / 6 * math.tau + now * 3
                    pygame.draw.circle(rs_, (255, 255, 255, int(230 * fade)), (int(4 + rw + math.cos(aa) * rw * .85), int(4 + rw / 2 + math.sin(aa) * rw * .42)), 3)
                screen.blit(rs_, (sx - rw - 4, sy - rw / 2 - 4))
                g = gfx.glow(int(34 + 10 * math.sin(k * math.pi)), tuple(int(c * .7 * fade) for c in col))
                screen.blit(g, (sx - g.get_width() // 2, sy - 48 - g.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
                for i in range(10):              # motes rising from the circle
                    aa = i / 10 * math.tau + e["t0"] * 5
                    screen.blit(gfx.glow(5, tuple(int(c * fade) for c in col)), (sx + math.cos(aa) * rw * .8 - 5, sy + math.sin(aa) * rw * .4 - k * 70 - (i % 3) * 8 - 5), special_flags=pygame.BLEND_RGB_ADD)
            elif t == "burst":                   # 0.46: where a spell lands - a flash, a ring and flying sparks in the spell's colour
                tp = self.ref_pos(e["to"])
                if not tp: continue
                sx, sy = self.to_screen(*tp); sy -= 26; col = e["col"]; fade = 1 - k; big = 1.4 if e.get("big") else 1.0
                g = gfx.glow(int((40 + 56 * k) * big), tuple(int(c * fade) for c in col))
                screen.blit(g, (sx - g.get_width() // 2, sy - g.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
                if k < .25: screen.blit(gfx.glow(int(22 * big), (int(255 * (1 - k * 4)),) * 3), (sx - int(22 * big), sy - int(22 * big)), special_flags=pygame.BLEND_RGB_ADD)
                rr = (12 + k * 56) * big
                rs_ = pygame.Surface((int(rr * 2) + 6, int(rr * 2) + 6), pygame.SRCALPHA)
                pygame.draw.circle(rs_, (*col, int(240 * fade)), (int(rr) + 3, int(rr) + 3), int(rr), 4)
                pygame.draw.circle(rs_, (255, 255, 255, int(160 * fade)), (int(rr) + 3, int(rr) + 3), max(1, int(rr * .7)), 2)
                screen.blit(rs_, (sx - rr - 3, sy - rr - 3))
                for i in range(12):
                    aa = i / 12 * math.tau + e["t0"] * 3
                    d_ = (8 + k * 54) * big * (.7 + (i % 3) * .2)
                    screen.blit(gfx.glow(5, tuple(int(c * fade) for c in col)), (sx + math.cos(aa) * d_ - 5, sy + math.sin(aa) * d_ * .7 + k * 10 - 5), special_flags=pygame.BLEND_RGB_ADD)
            elif t == "dash":
                x0, y0 = self.to_screen(e["x0"], e["y0"]); x1, y1 = self.to_screen(e["x"], e["y"])
                for i in range(12):
                    f = i / 11
                    screen.blit(gfx.glow(10, tuple(int(c * .5 * (1 - k)) for c in e["col"])), (x0 + (x1 - x0) * f - 10, y0 + (y1 - y0) * f - 40 - 10), special_flags=pygame.BLEND_RGB_ADD)
            elif t == "slash":
                ta = self.ref_pos(e["to"])
                if ta:
                    sx, sy = self.to_screen(*ta)
                    screen.blit(gfx.glow(26, tuple(int(c * .5 * (1 - k)) for c in e["col"])), (sx - 26, sy - 40 - 26), special_flags=pygame.BLEND_RGB_ADD)
                    cs = pygame.Surface((90, 90), pygame.SRCALPHA)
                    for w_ in range(5):
                        pygame.draw.arc(cs, (*[min(255, c + 60) for c in e["col"]], int(220 * (1 - k)) // (1 + w_ // 2)), (10 + w_ * 2, 10 + w_ * 2, 70 - w_ * 4, 70 - w_ * 4), 1.0 + k * 1.2, 2.6 + k * 1.2, 5 - w_)
                    screen.blit(cs, (sx - 45, sy - 66))

    def _chimney_smoke(self, screen, x, y, seed):
        for i in range(5):
            ph = ((self.t * .35 + i / 5.0 + (seed % 13) * .07) % 1.0)
            r = int(2 + ph * 5); a = int(120 * (1 - ph))
            if a < 8: continue
            px = x + math.sin(ph * 5 + seed) * 3 + ph * 9
            py = y - ph * 34
            s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (205, 205, 210, a), (r, r), r)
            screen.blit(s, (px - r, py - r))

    def draw_portal(self, d):
        spr, anc = gfx.dungeon_sprite(d.kind)
        sx, sy = self.to_screen(d.x, d.y)
        screen.blit(spr, (sx - anc[0], sy - anc[1]))
        now = self.t
        if d.kind in ("raid", "heroic"):
            cx, cy = sx, sy - 58
            for i in range(3):
                rr = 26 - i * 7 + math.sin(now * 3 + i) * 2
                pygame.draw.ellipse(screen, ((255, 120, 40), (255, 180, 80), (255, 240, 180))[i], (cx - rr, cy - rr * 1.5, rr * 2, rr * 3), 3)
        else:
            cx, cy = sx, sy - 28
            for i in range(3):
                a = now * 2 + i * 2.1
                pygame.draw.circle(screen, (170, 110, 255), (int(cx + math.cos(a) * 9), int(cy + math.sin(a) * 12)), 3)
        r = pygame.Rect(sx - 50, sy - 100, 100, 110)
        self.hit_rects.append((r, ("portal", d)))
        if self.pdist(d.x, d.y) < 14:
            col = (255, 150, 60) if d.kind in ("raid", "heroic") else (190, 140, 255)
            label = d.name if len(d.name) < 34 else d.name[:33] + "…"
            text(label, sx, sy - (128 if d.kind in ("raid", "heroic") else 74), col, F_PL, True, center=True)
            text(f"Lv {d.level}" + ((" HEROIC" if d.kind == "heroic" else " RAID" if d.kind == "raid" else "")), sx, sy - (114 if d.kind in ("raid", "heroic") else 60), (220, 220, 220), F_PL, True, center=True)

    def cast_shadow(self, sx, sy, w, h):
        """Shadow that follows the sun: long and pointing west at dawn, short at noon, east by dusk."""
        if self.atmo.lite:
            sh = gfx.shadow_sprite(w, h); dx = 0
        else:
            hr = getattr(self.atmo, "hour", 12.0) % 24
            if 6 <= hr <= 18:
                ang = (hr - 6) / 12 * math.pi; L = 1.9 - 1.5 * math.sin(ang); dx = -math.cos(ang) * L * w * .9
            else:
                L = .3; dx = 0
            lq = round(L * 4) / 4; k = (int(w), int(h), lq)
            sh = self._shd.get(k)
            if sh is None:
                base = gfx.shadow_sprite(w, h)
                sh = pygame.transform.scale(base, (int(base.get_width() * (1 + lq * .55)), base.get_height()))
                self._shd[k] = sh
                if len(self._shd) > 200: self._shd.clear()
            dx = round(dx / 3) * 3
        screen.blit(sh, (sx + dx - sh.get_width() // 2, sy - sh.get_height() // 2))

    def draw_actor(self, a, plates):
        d = self.disp[a["id"]]; now = self.t
        sx, sy = self.to_screen(d["x"], d["y"])
        if sx < -90 or sx > LW + 90 or sy < -40 or sy > LH + 160: return
        key, sk, spec, sc = gfx.actor_look(a)
        sc *= ACTOR_SCALE
        self.looks[a["id"]] = (key, sk, spec, sc)
        if a.get("dead"):
            if a.get("corpse"):
                c = self.corpse_sprite((key, sk, spec, sc), d["face"])
                c.set_alpha(220); screen.blit(c, (sx - c.get_width() // 2, sy - c.get_height() + 8))
                plates.append(("actor", sx, sy - 30, a))
            return
        stunned = a.get("stun")
        moving = now - d["moving"] < .15 and not stunned
        frame = int(now * 8) % 4 if moving else -1
        attack = now - d["atk"] < .25
        self.cast_shadow(sx, sy, 16 * sc, 6 * sc)
        ak0 = a.get("kind")
        rk = "npc" if ak0 == "npc" else ("boss" if a.get("boss") else "enemy") if ak0 == "monster" else ("enemy" if is_enemy(a, self.w.player) else "ally")
        rg = gfx.ring_sprite(rk, max(.8, min(1.6, sc / ACTOR_SCALE)))
        screen.blit(rg, (sx - rg.get_width() // 2, sy - rg.get_height() // 2))
        got = gfx.cached_character(key, frame, d["face"], attack, sc)
        if got is None and self._new_poses >= 1:
            # a new pose costs ~0.1 s on a slow CPU: build one per frame, show a ready pose meanwhile
            got = next((c for c in (gfx.cached_character(key, f_, fc_, False, sc) for f_ in (frame, -1) for fc_ in (d["face"], -d["face"])) if c), None)
        if got is None:
            got = gfx.character_sprite(key, sk, spec, frame, d["face"], attack, sc); self._new_poses += 1
        spr, anc = got
        flying = sk in ("dragon", "wraith", "elemental")
        bob = math.sin(now * 3 + a["id"]) * 3 if flying else 0
        bx, by = sx - anc[0], sy - anc[1] + bob
        if self.target == a["id"] or self.hover == a["id"]:
            g = gfx.glow(int(max(spr.get_width(), spr.get_height()) * .55), (90, 30, 20) if is_enemy(a, self.w.player) else (70, 70, 30))
            screen.blit(g, (sx - g.get_width() // 2, by + spr.get_height() * .5 - g.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
        if a.get("boss"):
            pul = 1 + .12 * math.sin(now * 3 + a["id"])
            g = gfx.glow(int(max(spr.get_width(), spr.get_height()) * .62 * pul), (110, 20, 24))
            screen.blit(g, (sx - g.get_width() // 2, by + spr.get_height() * .55 - g.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
        elite = a.get("kind") == "monster" and a.get("name", "").startswith("Elite ")
        if elite and not a.get("boss"):
            rw = int(max(spr.get_width(), 40) * .95); ring = pygame.Surface((rw, rw // 2), pygame.SRCALPHA)
            ap = 150 + int(80 * math.sin(now * 4 + a["id"]))
            pygame.draw.ellipse(ring, (255, 210, 60, ap), ring.get_rect(), 3)
            pygame.draw.ellipse(ring, (255, 120, 30, ap // 2), ring.get_rect().inflate(-10, -5), 2)
            screen.blit(ring, (sx - rw // 2, by + spr.get_height() - rw // 4 - 6))
            pul = 1 + .1 * math.sin(now * 3.4 + a["id"])
            ge = gfx.glow(int(max(spr.get_width(), spr.get_height()) * .6 * pul), (96, 70, 10))
            screen.blit(ge, (sx - ge.get_width() // 2, by + spr.get_height() * .55 - ge.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
        magic = is_magic(a)
        if magic:
            rw = int(max(spr.get_width(), 40) * (1.1 if elite else .95)); ring = pygame.Surface((rw, rw // 2), pygame.SRCALPHA)
            ap = 150 + int(80 * math.sin(now * 3.2 + a["id"]))
            pygame.draw.ellipse(ring, (170, 90, 255, ap), ring.get_rect(), 3)
            pygame.draw.ellipse(ring, (90, 160, 255, ap // 2), ring.get_rect().inflate(-10, -5), 2)
            screen.blit(ring, (sx - rw // 2, by + spr.get_height() - rw // 4 - 6))
            pul = 1 + .1 * math.sin(now * 2.8 + a["id"])
            gm = gfx.glow(int(max(spr.get_width(), spr.get_height()) * .6 * pul), (50, 24, 96))
            screen.blit(gm, (sx - gm.get_width() // 2, by + spr.get_height() * .55 - gm.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
        screen.blit(spr, (bx, by))
        b = gfx.sprite_bounds(spr).move(bx, by)
        if magic and not a.get("boss") and not self.atmo.lite:
            for i in range(4):
                ph = (now * .5 + i / 4) % 1
                px = b.centerx + math.sin(i * 2.9 + now * 1.2) * b.width * .45; py = b.bottom - ph * b.height * 1.1
                screen.blit(gfx.glow(7, tuple(int(c * (1 - ph)) for c in (170, 110, 255))), (px - 7, py - 7), special_flags=pygame.BLEND_RGB_ADD)
        if elite and not a.get("boss") and not self.atmo.lite:
            for i in range(4):
                ph = (now * .6 + i / 4) % 1
                px = b.centerx + math.sin(i * 2.3 + now * 1.4) * b.width * .45; py = b.bottom - ph * b.height * 1.1
                screen.blit(gfx.glow(7, tuple(int(c * (1 - ph)) for c in (255, 200, 60))), (px - 7, py - 7), special_flags=pygame.BLEND_RGB_ADD)
        if a.get("boss"):
            for i in range(7):
                ph = (now * .55 + i / 7) % 1
                px = b.centerx + math.sin(i * 2.7 + now * 1.3) * b.width * .5
                py = b.bottom - ph * b.height * 1.15
                screen.blit(gfx.glow(8, tuple(int(c * (1 - ph)) for c in (230, 80, 40))), (px - 8, py - 8), special_flags=pygame.BLEND_RGB_ADD)
        if a.get("dot"):
            for i in range(3):
                ph = (now * 1.3 + i / 3 + a["id"] * .1) % 1
                px = b.centerx + math.sin(i * 2.1 + now * 2) * b.width * .3
                py = b.bottom - ph * b.height
                screen.blit(gfx.glow(6, (120, 60, 20)), (px - 6, py - 6), special_flags=pygame.BLEND_RGB_ADD)
        if stunned:
            for i in range(3):
                ang = now * 4 + i * 2.09
                px = b.centerx + math.cos(ang) * 12; py = b.top - 4 + math.sin(ang) * 4
                pygame.draw.circle(screen, (255, 240, 120), (int(px), int(py)), 3)
        self.hit_rects.append((b.inflate(10, 6), ("actor", a)))
        plates.append(("actor", sx, b.top, a))
    def quest_mark(self, a):
        """'?' when a finished quest can be handed in to this quest giver / ruler, otherwise '!'."""
        if not self.w.towns: return "!"
        t = min(self.w.towns, key=lambda t: (t.x - a["x"]) ** 2 + (t.y - a["y"]) ** 2)
        royal = a.get("role") == "king"
        for q in self.snap.get("quest_log", []):
            if q.get("done") and q.get("town") == t.id and bool(q.get("royal")) == royal: return "?"
        return "!"

    def player_key(self, cls, spec):
        """Sprite-cache key for the hero's look."""
        return ("me", cls, self.w.player.get("faction"), spec.get("tierlvl", 0), spec.get("tier"), spec.get("helmlvl", 0), spec.get("helmtier"), spec.get("setl"), spec.get("setp"))

    def player_spec(self):
        """The hero's look: class base + rarity tiers + (0.21) whichever gear-set pieces are worn."""
        p = self.w.player
        cls = self.w.class_name()
        spec = dict(gfx.CLASS_SPEC.get(cls, gfx.CLASS_SPEC["Warrior"])); spec["cape"] = gfx.FACTION_CAPE.get(p.get("faction"), (110, 110, 110))
        TL = {"Uncommon": 0, "Rare": 1, "Epic": 2, "Elite": 3, "Set": 3, "Legendary": 3, "Mythic": 3}
        ar = getattr(self, "armor_rarity", ""); hr = getattr(self, "helm_rarity", "")
        if TL.get(ar, 0) >= 1: spec["tier"] = RARITY_COLOR[ar]; spec["tierlvl"] = TL[ar]
        if TL.get(hr, 0) >= 1: spec["helmtier"] = RARITY_COLOR[hr]; spec["helmlvl"] = TL[hr]
        have = {}
        for it in self.snap.get("inventory", []):
            if it.get("equipped") and it.get("set_name"):
                k = gfx.set_key(it["set_name"])
                if k: have.setdefault(k, set()).add(it["slot"])
        if have:
            k = max(have, key=lambda x: len(have[x]))
            spec["setl"] = k; spec["setp"] = tuple(sorted(have[k]))
        return cls, spec

    def draw_set_aura(self, sx, sy, spec, now, front=False, b=None):
        sl = gfx.SET_LOOKS.get(spec.get("setl")); n = len(spec.get("setp", ()))
        if not sl or n < 2: return
        glow = sl["glow"]
        if not front:      # ground aura: pulsing pool + turning rune dots
            pul = .75 + .25 * math.sin(now * 3)
            g_ = gfx.glow(int(40 + n * 5), tuple(int(c * .5 * pul) for c in glow))
            screen.blit(pygame.transform.scale(g_, (g_.get_width(), g_.get_height() // 2)), (sx - g_.get_width() // 2, sy - g_.get_height() // 4), special_flags=pygame.BLEND_RGB_ADD)
            R = 28 + n * 2
            for i in range(8 if n >= 4 else 5):
                ang = now * .9 + i * math.tau / (8 if n >= 4 else 5)
                pygame.draw.circle(screen, tuple(min(255, int(c * .95)) for c in glow), (int(sx + math.cos(ang) * R), int(sy + math.sin(ang) * R * .5)), 2)
            return
        if self.atmo.lite or b is None: return
        for i in range(4 if n >= 4 else 2):      # orbiting sparks around the body, rising motes
            ang = now * 1.6 + i * math.tau / (4 if n >= 4 else 2)
            ox = math.cos(ang) * (b.width * .55); oy = b.centery + math.sin(ang * 1.3) * b.height * .32
            screen.blit(gfx.glow(8, tuple(int(c * .8) for c in glow)), (b.centerx + ox - 8, oy - 8), special_flags=pygame.BLEND_RGB_ADD)
        if n >= 4:
            for i in range(5):
                ph = (now * .55 + i / 5) % 1
                px = b.centerx + math.sin(i * 2.7 + now) * b.width * .4; py = b.bottom - ph * b.height * 1.2
                screen.blit(gfx.glow(5, tuple(int(c * .9 * (1 - ph)) for c in glow)), (px - 5, py - 5), special_flags=pygame.BLEND_RGB_ADD)

    def draw_player(self, plates):
        p = self.w.player; now = self.t
        sx, sy = self.to_screen(p["x"], p["y"])
        cls, spec = self.player_spec()
        frame = int(now * 9) % 4 if self.player_anim["moving"] else -1
        attack = now - self.player_anim["attack"] < .28
        mt = self.snap.get("mount") or {}
        lift = 0
        if mt.get("mounted"):
            lift = (46 + math.sin(now * 2.2) * 3) if mt.get("fly") else 0
            self.cast_shadow(sx, sy, int(34 - lift * .1), int(10 - lift * .03))
        else:
            self.cast_shadow(sx, sy, 20, 8)
        rg = gfx.ring_sprite("me")
        screen.blit(rg, (sx - rg.get_width() // 2, sy - rg.get_height() // 2))
        self.draw_set_aura(sx, sy, spec, now)
        rkey = self.player_key(cls, spec)
        if mt.get("mounted"):
            mframe = (int(now * 7) % 4) if mt.get("fly") else frame
            spr, anc = gfx.mounted_sprite(rkey, spec, mt["look"], mframe, self.player_anim["facing"], attack, 1.1, 1.12, bool(mt.get("fly")))
            if not mt.get("fly") and self.player_anim["moving"]: frame = int(now * 11) % 4
        else:
            spr, anc = gfx.character_sprite(rkey, "human", spec, frame, self.player_anim["facing"], attack, 1.38)
        bx, by = sx - anc[0], sy - anc[1] - lift
        b = gfx.sprite_bounds(spr).move(bx, by)
        # gear aura: better weapons sparkle, like Conquer's glowing gear
        wr = self.weapon_rarity
        if wr in ("Rare", "Epic", "Elite", "Set", "Legendary", "Mythic"):
            col = RARITY_COLOR.get(wr, (200, 200, 200))
            if spec.get("setl") and "weapon" in spec.get("setp", ()): col = gfx.SET_LOOKS[spec["setl"]]["glow"]
            n = {"Rare": 2, "Epic": 3, "Elite": 4, "Set": 4, "Legendary": 6, "Mythic": 8}[wr]
            for i in range(n):
                ph = (now * .7 + i / n) % 1
                px = b.centerx + math.sin(i * 2.4 + now * 1.7) * b.width * .45
                py = b.bottom - ph * b.height * 1.05
                screen.blit(gfx.glow(7, tuple(int(c * .7 * (1 - ph)) for c in col)), (px - 7, py - 7), special_flags=pygame.BLEND_RGB_ADD)
        stealth = any(x["kind"] == "vanish" for x in self.snap.get("buffs", []))
        if stealth:
            ghost = spr.copy(); ghost.set_alpha(110); screen.blit(ghost, (bx, by))
        else:
            screen.blit(spr, (bx, by))
        for bf in self.snap.get("buffs", []):
            if bf["kind"] == "shield":
                g = gfx.glow(int(b.height * .62), (30, 70, 110))
                screen.blit(g, (b.centerx - g.get_width() // 2, b.centery - g.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
                pygame.draw.ellipse(screen, (150, 210, 255), b.inflate(16, 6), 1)
            elif bf["kind"] == "armor":
                pygame.draw.ellipse(screen, (255, 210, 90), (sx - 26 - math.sin(now * 5) * 2, sy - 11, 52 + math.sin(now * 5) * 4, 22), 2)
            elif bf["kind"] == "hot":
                ph = (now * 1.5) % 1
                screen.blit(gfx.glow(8, (40, 120, 40)), (b.centerx - 8 + math.sin(now * 3) * 10, b.bottom - ph * b.height - 8), special_flags=pygame.BLEND_RGB_ADD)
        self.draw_set_aura(sx, sy, spec, now, True, b)
        plates.append(("me", sx, b.top, None))
    def draw_plate(self, pl):
        kind, sx, top, a = pl
        p = self.w.player
        if kind == "me":
            ol_ = self.snap.get("player", {}).get("outlaw", 0)      # 0.38: an outlaw's name blinks red
            text(p["name"], sx, top - 22, ((255, 50, 50) if (self.t * 2) % 1 < .5 else (120, 10, 10)) if ol_ else ALLY_COL, F_PL, True, center=True)
            bar(sx - 26, top - 8, 52, 4, p["hp"], max(1, self.snap["player"]["maxhp"]), (200, 30, 30))
            return
        if kind == "node":
            col = (210, 200, 170) if a.get("skin") else ((150, 255, 160) if "band" in a and a["name"] in gfx_herbs() else (230, 200, 150))
            text(a["name"], sx, top - 14, col, F_PL, True, center=True)
            return
        if kind == "loot":
            col = RARITY_COLOR.get(a["rarity"], (230, 230, 230))
            show = self.hover_loot == a["id"] or self.pdist(a["x"], a["y"]) < 4 or a["rarity"] not in ("Common",)
            if show: text(a["item"], sx, top - 14, col, F_PL, True, center=True)
            return
        ak = a.get("kind")
        hov = self.hover == a["id"]; tg = self.target == a["id"]
        dist = self.pdist(a["x"], a["y"])
        if ak == "monster":
            magic = is_magic(a)
            show_name = hov or tg or magic or a.get("name", "").startswith("Elite ")
            hurt = a.get("hp", 1) < a.get("maxhp", 1)
            if show_name:
                col = MONSTER_COL
                elite = a.get("name", "").startswith("Elite ")
                star = ("\u2605 " if elite else "") + ("\u25c6 " if magic else "")
                lv = a.get("level", 1); df = lv - p["level"]
                pc = (150, 150, 150) if df <= -8 else (90, 220, 100) if df <= -3 else (240, 220, 80) if df <= 2 else (255, 150, 50) if df <= 6 else (255, 50, 50)
                tw = F_PL.size(f"{star}{clean_name(a)}  Lv{lv}")[0]
                pygame.draw.circle(screen, (10, 8, 8), (int(sx - tw // 2 - 9), int(top - 15)), 5); pygame.draw.circle(screen, pc, (int(sx - tw // 2 - 9), int(top - 15)), 4)
                if elite: col = (255, 205, 70)
                elif magic: col = (190, 140, 255)
                elif a.get("aggro"): col = (255, 90, 70)
                elif a.get("temper") == "passive": col = (220, 150, 130)
                text(f"{star}{clean_name(a)}  Lv{lv}", sx, top - 22, col, F_PL, True, center=True)
            if show_name or hurt:
                bar(sx - 22, top - 7, 44, 5, a.get("hp", 1), a.get("maxhp", 1), (210, 40, 40))
                if a.get("name", "").startswith("Elite "): pygame.draw.rect(screen, (240, 200, 70), (sx - 24, top - 9, 48, 9), 1, border_radius=3)
                elif magic: pygame.draw.rect(screen, (170, 110, 255), (sx - 24, top - 9, 48, 9), 1, border_radius=3)
        elif ak == "npc":
            role = a.get("role", "")
            shop = {"vendor": "Potions & Supplies", "blacksmith": "Weapons & Armor", "merchant": "Caravan Wares", "innkeeper": "Inn \u2022 Alchemy",
                    "stablemaster": "Mounts", "questgiver": "Quest Giver", "king": "Ruler", "marketeer": "Trade Market", "fishmonger": "Fishing", "jeweler": "Jewels & Rings", "banker": "Vault"}.get(role)
            named = role != "guard"
            if hov or (named and dist < 10):
                if shop and shop != clean_name(a): heavy_text(shop, sx, top - 42, (255, 215, 110), F_BD, 1)
                if named or hov: heavy_text(clean_name(a), sx, top - 24, faction_col(a, p), F_NPC, 2)
            if role_q(a):
                bob = math.sin(self.t * 4 + a["id"]) * 4
                mark = self.quest_mark(a)
                col = (255, 214, 40) if mark == "!" else (255, 250, 120)
                pul = .8 + .2 * math.sin(self.t * 5 + a["id"])
                g = gfx.glow(34, tuple(int(c * pul) for c in (120, 90, 10)))
                screen.blit(g, (sx - g.get_width() // 2, top - 96 + bob - g.get_height() // 2 + 30), special_flags=pygame.BLEND_RGB_ADD)
                heavy_text(mark, sx, top - 96 + bob, col, F_QM, 3)
        else:
            col = faction_col(a, p)
            duel = a.get("duel") or a.get("aiduel")
            if a.get("soldier") and dist < 22:          # 0.35: City Watch and raid warbands are always marked
                lab_ = "City Watch" if a.get("soldier") == "watch" else f"{a.get('faction', '')} warband"
                text(f"{clean_name(a)}  Lv{a.get('level', '')}", sx, top - 16, col, F_PL, True, center=True)
                text(lab_, sx, top - 29, col, F_PL, True, center=True)
                bar(sx - 22, top - 4, 44, 5, a.get("hp", 1), a.get("maxhp", 1), (210, 40, 40) if is_enemy(a, p) else (60, 200, 80))
            elif hov or tg or a.get("duel"):
                text(f"{clean_name(a)} ({a.get('role', '')} {a.get('level', '')})", sx, top - 16, col, F_PL, True, center=True)
                g = a.get("gear")
                if g and g != "Common": text(f"{g} gear", sx, top - 29, RARITY_COLOR.get(g, GREY), F_PL, True, center=True)
            if duel and dist < 30:
                heavy_text("DUEL", sx, top - (44 if (hov or tg or a.get("duel")) else 30), (255, 90, 70), F_BD, 1)
            elif a.get("defending") and (hov or tg):
                text("Defender", sx, top - 42, (140, 220, 255), F_PL, True, center=True)
            if a.get("say") and dist < 26:
                self.draw_bubble(sx, top - (58 if (hov or tg or duel) else 22), a["say"])
            if a.get("ally") and a.get("hp", 1) < a.get("maxhp", 1) and not a.get("dead"):
                bar(sx - 20, top - 4, 40, 4, a.get("hp", 1), a.get("maxhp", 1), (60, 200, 80))
            elif (tg or hov) and is_enemy(a, p):
                bar(sx - 22, top - 4, 44, 5, a.get("hp", 1), a.get("maxhp", 1), (210, 40, 40))

    def draw_bubble(self, sx, y, txt):
        """Speech bubble over a computer player's head."""
        lines = self.wrap(txt, F_SM, 190)[:3]
        w_ = max(F_SM.size(l)[0] for l in lines) + 16; h_ = len(lines) * 15 + 9
        r = pygame.Rect(int(sx - w_ // 2), int(y - h_), w_, h_)
        pygame.draw.polygon(screen, (250, 244, 226), [(sx - 6, r.bottom - 1), (sx + 6, r.bottom - 1), (sx, r.bottom + 7)])
        pygame.draw.rect(screen, (250, 244, 226), r, border_radius=7); pygame.draw.rect(screen, (70, 56, 36), r, 1, border_radius=7)
        pygame.draw.line(screen, (70, 56, 36), (sx - 6, r.bottom - 1), (sx, r.bottom + 7)); pygame.draw.line(screen, (70, 56, 36), (sx + 6, r.bottom - 1), (sx, r.bottom + 7))
        for i, ln in enumerate(lines):
            text(ln, r.x + 8, r.y + 4 + i * 15, (34, 26, 18), F_SM)

    def draw_duel_hud(self):
        """Duel challenge pop-up and the duel banner."""
        snap = self.snap
        ol_ = snap.get("player", {}).get("outlaw", 0)
        if ol_ and self.mode == "world":            # 0.38: outlaw countdown
            r = frame_panel((LW // 2 - 190, 132, 380, 46), alpha=225, border=(220, 50, 50))
            col = (255, 70, 60) if (self.t * 2) % 1 < .5 else (200, 40, 40)
            text(f"OUTLAW  {ol_ // 60}:{ol_ % 60:02d}", r.centerx, r.y + 5, col, F_BD, True, center=True)
            text("Every town guard, and some adventurers, will attack you.  Dying clears it.", r.centerx, r.y + 25, GREY, F_SM, True, center=True)
        o = snap.get("duel_offer")
        if o and self.mode == "world":
            r = frame_panel((LW // 2 - 280, LH - 250, 560, 104), alpha=240, border=(230, 120, 70))
            fc = (110, 170, 255) if o["faction"] == "Alliance" else (255, 100, 90)
            death_ = o.get("kind") == "death"
            text(f"{o['name']} challenges you to " + ("a FIGHT TO THE DEATH!" if death_ else "a duel!"), r.centerx, r.y + 10, (255, 120, 100) if death_ else (255, 210, 150), F_BD, True, center=True)
            text(f"Level {o['level']} {o['cls']}  •  {o['faction']}  •  ", r.centerx - 60, r.y + 32, fc, F_SM, True, center=True)
            text(f"{o['gear']} gear", r.centerx + 90, r.y + 32, RARITY_COLOR.get(o["gear"], GREY), F_SM, True, center=True)
            text((f"Real death  •  killing them makes you an outlaw  •  {o['left']}s") if death_ else f"Wager {o['wager']}g  •  to the last hit point, nobody dies  •  {o['left']}s", r.centerx, r.y + 50, GREY, F_SM, True, center=True)
            self.ui_rects["duel_yes"] = button((r.centerx - 170, r.bottom - 34, 160, 28), "Accept", True, True)
            self.ui_rects["duel_no"] = button((r.centerx + 10, r.bottom - 34, 160, 28), "Decline", True, False)
        d = snap.get("duel")
        if d:
            r = frame_panel((LW // 2 - 200, 88, 400, 40), alpha=230, border=(230, 90, 60))
            text(f"DUEL vs {d['name']}  -  wager {d['wager']}g", r.x + 14, r.y + 12, (255, 200, 150), F_BD, True)
            self.ui_rects["duel_yield"] = button((r.right - 86, r.y + 6, 76, 28), "Yield", True, False)
            if d["state"] == "count":
                t = tsurf(str(max(1, d["count"])), (255, 230, 120), F_BIG, True); screen.blit(t, (LW // 2 - t.get_width() // 2, LH // 2 - 140))

    def draw_party(self):
        self.dim(150)
        r = frame_panel((LW // 2 - 320, LH // 2 - 220, 640, 440), alpha=246)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        text("YOUR PARTY", r.x + 24, r.y + 14, PARCH, F_TI)
        text("Click an adventurer or town guard and open the 'Add to party' tab to ask them. They may say no.", r.x + 24, r.y + 50, GREY, F_SM)
        mem = self.snap.get("pparty", [])
        y = r.y + 82
        if not mem: text("Nobody is travelling with you yet.", r.x + 24, y, PARCH, F_BD)
        for m in mem:
            rr = pygame.Rect(r.x + 24, y, r.width - 48, 62)
            pygame.draw.rect(screen, (30, 28, 34), rr, border_radius=8); pygame.draw.rect(screen, (90, 74, 52), rr, 1, border_radius=8)
            text(f"{m['name']}", rr.x + 12, rr.y + 6, (170, 240, 180), F_BD)
            text(f"Level {m['level']} {m['cls']}", rr.x + 12, rr.y + 28, GREY, F_SM)
            bar(rr.x + 200, rr.y + 12, 230, 14, m["hp"], m["maxhp"], (80, 190, 100), f"{m['hp']} / {m['maxhp']}")
            self.ui_rects["pd_%d" % m["id"]] = button((rr.right - 130, rr.y + 12, 118, 34), "Dismiss", True, False)
            y += 70
        text("In dungeons and raids each companion takes the place of one AI ally, so the group stays the same size.", r.x + 24, r.bottom - 34, (255, 230, 150), F_SM)

    def draw_person(self):
        """Click an adventurer or guard: Overview, Gear and Party tabs."""
        pid = getattr(self, "person_id", None)
        info = self.w.person_info(pid) if pid is not None else None
        if not info or info["dist"] > 14: self.mode = "world"; return
        self.dim(150)
        r = frame_panel((LW // 2 - 330, LH // 2 - 250, 660, 500), alpha=246)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        fc = (110, 170, 255) if info["faction"] == "Alliance" else (255, 100, 90)
        text(info["name"], r.x + 24, r.y + 14, fc, F_TI)
        tab = getattr(self, "person_tab", "info")
        for i_, (k_, lab_) in enumerate((("info", "Overview"), ("gear", "Gear"), ("party", "Add to party"))):
            self.ui_rects["ptab_" + k_] = button((r.x + 24 + i_ * 140, r.y + 52, 132, 30), lab_, True, tab == k_)
        top = r.y + 96
        box = pygame.Rect(r.x + 24, top, 190, 270)
        pygame.draw.rect(screen, (26, 22, 26), box, border_radius=8); pygame.draw.rect(screen, (90, 74, 52), box, 1, border_radius=8)
        a = self.actor(pid) or {"id": pid, "kind": "adventurer", "role": info["cls"], "faction": info["faction"], "level": info["level"],
                                "gear": info["gear"], "setl": info["setl"], "setp": info["setp"]}
        try:
            key, sk, spec, sc = gfx.actor_look(a)
            spr, anc = gfx.character_sprite(("pp",) + tuple(key), sk, spec, -1, 1, False, 2.6)
            screen.blit(spr, (box.centerx - anc[0], box.y + 236 - anc[1]))
        except Exception:
            pass
        x = box.right + 22; y = top + 4
        def row(label, val, col=PARCH):
            nonlocal y
            text(label, x, y, GREY, F_SM); text(val, x + 120, y, col, F_BD); y += 24
        if tab == "info":
            row("Level", f"{info['level']} {info['cls']}")
            row("Faction", info["faction"], fc)
            row("Gear", info["gear"], RARITY_COLOR.get(info["gear"], PARCH))
            if info["setl"] and info["setp"]: row("Set", f"{info['setl']}  ({len(info['setp'])}/4)", (60, 220, 200))
            row("Personality", info["persona"])
            row("Doing", info["activity"])
            if not info.get("npc"): row("Duels", f"{info['wins']} won  /  {info['losses']} lost")
            row("Kills", f"{info['kills']}   deaths {info['deaths']}")
            bar(x, y + 6, 300, 14, info["hp"], info["maxhp"], (196, 36, 40), f"{int(info['hp'])} / {int(info['maxhp'])}")
            if info.get("say"):
                sy_ = y + 32
                for i, ln in enumerate(self.wrap(f"\"{info['say']}\"", F_MD, 330)[:2]):
                    text(ln, x, sy_ + i * 19, (255, 236, 170), F_MD, True)
        elif tab == "gear":
            text(f"Level {info['level']} {info['cls']} - gear worn", x, y, PARCH, F_BD); y += 26
            for g in info.get("gear_rows", []):
                col = RARITY_COLOR.get(g["rarity"], PARCH)
                text(g["title"], x, y + 2, GREY, F_SM)
                nm = g["item"]
                while F_SM.size(nm)[0] > 215 and len(nm) > 8: nm = nm[:-2] + "\u2026"
                text(nm, x + 70, y + 2, col, F_SM)
                text(f"P{g['power']}", r.right - 28, y + 2, (255, 255, 255), F_SM, right=True)
                y += 26
            if info["gear_rows"]:
                avg = sum(g["power"] for g in info["gear_rows"]) // len(info["gear_rows"])
                text(f"Average power {avg}  (you: weapon {self.w.player['weapon']}, armor {self.w.player['armor']})", x, y + 8, (255, 230, 150), F_SM)
        else:
            n_ = len(self.snap.get("pparty", []))
            text(f"Party {n_}/3", x, y, PARCH, F_BD); y += 26
            if info["in_party"]:
                text(f"{info['name']} is travelling with you.", x, y, (150, 240, 160), F_BD); y += 24
                text("They follow, fight what attacks you and, in dungeons and raids,", x, y, GREY, F_SM); y += 16
                text("take the place of one AI ally.", x, y, GREY, F_SM); y += 22
                self.ui_rects["p_dismiss"] = button((x, y, 190, 34), "Dismiss from party", True, False)
            else:
                pct = info.get("join_pct", 0)
                why = info.get("join_why", "")
                text("Ask them to join you. They may or may not agree.", x, y, GREY, F_SM); y += 20
                if why: text(f"They {why}.", x, y, (255, 150, 120), F_BD)
                else: text(f"Chance they say yes: about {pct}%", x, y, (255, 230, 150), F_BD)
                y += 28
                for ln in ("Personality, level gap, health and whether they are busy matter.", "A refusal makes them unwilling for a while."):
                    text(ln, x, y, GREY, F_SM); y += 16
                y += 10
                self.ui_rects["p_invite"] = button((x, y, 190, 34), "Ask to join party", info.get("can_invite", False), True)
                if n_ >= 3: text("Your party is full.", x + 200, y + 9, (255, 150, 120), F_SM)
            y += 52
            for m in self.snap.get("pparty", []):
                text(f"\u2022 {m['name']}  Lv {m['level']} {m['cls']}", x, y, PARCH, F_SM); y += 16
        y = r.bottom - 54
        if tab == "info":
            self.ui_rects["p_duel"] = button((r.x + 24, y, 190, 36), "Challenge to a duel", info["can_duel"], True)
            if info["faction"] != self.w.player["faction"]:
                self.ui_rects["p_fight"] = button((r.x + 222, y, 190, 36), "Fight to the death", info.get("can_fight", False), False)
                text("Killing them makes you an outlaw for 15 minutes.", r.x + 24, y - 20, (255, 120, 100), F_SM)
            self.ui_rects["p_greet"] = button((r.x + 420, y, 90, 36), "Greet", True, False)
            text("They may say no.", r.x + 520, y + 11, GREY, F_SM)
        if info.get("npc") and tab == "info":
            for k_ in ("p_duel", "p_fight"): self.ui_rects.pop(k_, None)

    def _sun(self):
        """Shadow shear for the time of day (-3 morning .. +3 evening), 0 = no cast shadows (night, lite quality, dungeons)."""
        if self.quality < 1 or self.in_inst: return 0
        hour = (self.w.tick % 960) / 40.0
        if hour < 6.3 or hour > 18.7: return 0
        pos = (hour - 6.3) / 12.4
        sh = int(round((pos - .5) * 6))
        return sh if sh != 0 else 1
    def _shadow(self, spr, anc, sx, sy, shear):
        if self._shn > (140 if self.quality >= 2 else 70): return
        self._shn += 1
        sh, dx, dy = gfx.cast_shadow(spr, anc, shear, self.quality >= 2)
        if sh is not None: screen.blit(sh, (sx + dx, sy + dy))

    def draw_sun_rays(self):
        """0.37 High: soft warm light shafts at dawn and dusk, falling the same way as the cast shadows."""
        if self.in_inst: return
        hour = (self.w.tick % 960) / 40.0
        k = max(0.0, 1 - abs(hour - 7.6) / 1.6, 1 - abs(hour - 17.6) / 1.6)
        if k <= 0: return
        side = 0 if hour < 12 else 1
        key = (LW, LH, side)
        rays = getattr(self, "_rays", None)
        if rays is None or rays[0] != key:
            s = pygame.Surface((LW // 4, LH // 4)); w4, h4 = s.get_size()
            ox = -w4 * .1 if side == 0 else w4 * 1.1; dirx = 1 if side == 0 else -1
            for i, (a, wd, c) in enumerate(((.18, .05, 38), (.34, .08, 30), (.52, .04, 44), (.70, .07, 27), (.90, .05, 33))):
                x0 = ox + dirx * a * w4 * .55; x1 = ox + dirx * (a * w4 * .55 + w4 * .9)
                pts = [(x0, -h4 * .2), (x0 + dirx * wd * w4, -h4 * .2), (x1 + dirx * wd * w4 * 3, h4 * 1.1), (x1, h4 * 1.1)]
                pygame.draw.polygon(s, (c, int(c * .82), int(c * .55)), pts)
            s = pygame.transform.smoothscale(pygame.transform.smoothscale(s, (max(2, w4 // 6), max(2, h4 // 6))), (w4, h4))
            self._rays = rays = [key, pygame.transform.smoothscale(s, (LW, LH)), None, None]
        lv = int(k * 10) / 10.0
        if lv <= 0: return
        if rays[2] != lv:                 # one dimmed copy, rebuilt only when the strength steps (every few game minutes)
            sc = rays[3] if rays[3] is not None else pygame.Surface((LW, LH))
            sc.blit(rays[1], (0, 0)); g_ = int(255 * lv); sc.fill((g_, g_, g_), special_flags=pygame.BLEND_RGB_MULT)
            rays[2], rays[3] = lv, sc
        screen.blit(rays[3], (0, 0), special_flags=pygame.BLEND_RGB_ADD)

    def sharpen_world(self):
        """0.37 High: unsharp mask on the world (not the HUD), so the picture stays crisp when it is stretched to the screen."""
        sz = (LW, LH)
        sp = self._shp
        if sp is None or sp[0] != sz:
            amt = pygame.Surface(sz); amt.fill((118, 118, 118))          # sharpening amount (a multiply blit is far cheaper than a multiply fill)
            sp = self._shp = (sz, pygame.Surface((LW // 2, LH // 2)), pygame.Surface(sz), pygame.Surface(sz), pygame.Surface(sz), amt)
        _, half, blur, d1, d2, amt = sp
        pygame.transform.smoothscale(screen, half.get_size(), half)
        pygame.transform.smoothscale(half, sz, blur)
        d1.blit(screen, (0, 0)); d1.blit(blur, (0, 0), special_flags=pygame.BLEND_RGB_SUB)      # where the picture is brighter than its blur
        d2.blit(blur, (0, 0)); d2.blit(screen, (0, 0), special_flags=pygame.BLEND_RGB_SUB)      # where it is darker
        d1.blit(amt, (0, 0), special_flags=pygame.BLEND_RGB_MULT); d2.blit(amt, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        screen.blit(d1, (0, 0), special_flags=pygame.BLEND_RGB_ADD); screen.blit(d2, (0, 0), special_flags=pygame.BLEND_RGB_SUB)

    def draw_weather(self):
        """Low-health pulse (weather itself was removed in 0.30)."""
        p = self.snap.get("player", {}) if isinstance(self.snap, dict) else {}
        hp, mx = p.get("hp", 1), max(1, p.get("maxhp", 1))
        if self.mode == "world" and hp > 0 and hp / mx < .3:
            a = int((200 + 55 * math.sin(self.t * 5)) * (1 - hp / mx / .3))
            vg = pygame.Surface((LW, LH), pygame.SRCALPHA)
            for i in range(10):
                pygame.draw.rect(vg, (190, 20, 20, a // (i + 1) * 1), (i * 6, i * 4, LW - i * 12, LH - i * 8), 10)
            screen.blit(vg, (0, 0))

    def draw_lighting(self):
        """0.17: light map (time of day, coloured light pools, cloud shadows, vignette),
        ambient particles all live in fx.Atmosphere."""
        self.atmo.apply(self, screen)
        if not self.atmo.lite: self.atmo.particles(self, screen, self.dt)
        if self.quality > 0 and not self.in_inst:
            hz = getattr(self, "_haze", None)
            if hz is None or hz.get_size() != (LW, int(LH * .42)):
                hh = int(LH * .42); hz = pygame.Surface((LW, hh), pygame.SRCALPHA)
                for y in range(0, hh, 2): pygame.draw.rect(hz, (176, 200, 236, int(40 * (1 - y / hh) ** 1.6)), (0, y, LW, 2))
                self._haze = hz
            screen.blit(hz, (0, 0))

    # ------------------------------------------------------ HUD
    def draw_hud(self):
        snap = self.snap; p = snap["player"]; now = self.t
        self.ui_rects = {}
        mx, my = self.mouse
        self.tooltip = None
        cls = p.get("class", "Warrior")
        # ---- player frame
        frame_panel((10, 10, 320, 92))
        pygame.draw.circle(screen, (30, 26, 30), (54, 54), 36); pygame.draw.circle(screen, GOLD, (54, 54), 36, 2)
        spec = dict(gfx.CLASS_SPEC.get(cls, gfx.CLASS_SPEC["Warrior"])); spec["cape"] = gfx.FACTION_CAPE.get(p.get("faction"))
        spr, anc = gfx.character_sprite(("me", cls, p.get("faction")), "human", spec, -1, 1, False, 1.32)
        clip = screen.get_clip(); screen.set_clip(pygame.Rect(20, 20, 68, 68))
        screen.blit(spr, (54 - anc[0], 112 - anc[1] + 24)); screen.set_clip(clip)
        pygame.draw.circle(screen, (30, 26, 30), (30, 84), 14); pygame.draw.circle(screen, GOLD, (30, 84), 14, 1)
        text(p["level"], 30, 76, PARCH, F_BD, center=True)
        fc = (110, 170, 255) if p.get("faction") == "Alliance" else (255, 100, 90)
        nx = 98 + text(p["name"], 98, 16, PARCH, F_BD).get_width() + 6
        role = snap.get("spec")
        ctxt = f"{role + ' ' if role else ''}{cls}"
        text(ctxt, 312, 18, fc, F_SM, right=True)
        # faction crest after the name: a small shield, plus the faction word when it fits before the class
        fac = p.get("faction")
        if fac in ("Alliance", "Horde"):
            sh = [(nx, 17), (nx + 14, 17), (nx + 14, 25), (nx + 7, 32), (nx, 25)]
            pygame.draw.polygon(screen, gfx.FACTION_CAPE[fac], sh); pygame.draw.polygon(screen, GOLD, sh, 1)
            text(fac[0], nx + 7, 17, (255, 255, 255), F_PL, center=True)
            if nx + 18 + F_SM.size(fac)[0] <= 312 - F_SM.size(ctxt)[0] - 6:
                text(fac, nx + 18, 18, fc, F_SM)
        bar(98, 38, 212, 16, p["hp"], p["maxhp"], (196, 36, 40), f"{p['hp']} / {p['maxhp']}")
        bar(98, 58, 212, 12, p.get("mana", 100), 100, (50, 110, 220), f"{int(p.get('mana', 100))} / 100")
        if snap.get("in_combat"): text("IN COMBAT", 98, 76, (255, 90, 80), F_PL)
        elif snap.get("role"): text(f"Role: {snap['role']}", 98, 76, GREY, F_SM)
        else: text(f"Bracket {snap['level_bracket']}", 98, 76, GREY, F_SM)
        # ---- buffs under the frame
        bxp = 14
        for bf in snap.get("buffs", []):
            r = pygame.Rect(bxp, 108, 30, 30)
            col = {"shield": (90, 160, 230), "armor": (230, 180, 70), "dodge": (180, 230, 180), "hot": (90, 220, 100), "sprint": (230, 230, 150), "vanish": (130, 120, 170)}.get(bf["kind"], (200, 200, 200))
            pygame.draw.rect(screen, shade(col, .35), r, border_radius=5); pygame.draw.rect(screen, col, r, 2, border_radius=5)
            text(bf["name"][:2], r.centerx, r.y + 3, (255, 255, 255), F_PL, True, center=True)
            text(f"{bf['left']}s", r.centerx, r.y + 16, (255, 255, 255), F_SM, True, center=True)
            if r.collidepoint(mx, my):
                extra = f" — {bf['absorb']} damage left" if bf.get("absorb") is not None else ""
                self.tooltip = [(bf["name"], PARCH, F_BD), (f"{bf['left']}s remaining{extra}", GREY, F_SM)]
            bxp += 34
        # ---- party frames (recruited companions)
        py_ = 142
        for m in snap.get("pparty", [])[:3]:
            pygame.draw.rect(screen, (14, 16, 22), (10, py_, 200, 30), border_radius=5); pygame.draw.rect(screen, (90, 170, 110), (10, py_, 200, 30), 1, border_radius=5)
            text(f"{m['name'][:16]}  Lv{m['level']}", 16, py_ + 2, (170, 240, 180), F_SM)
            bar(16, py_ + 17, 188, 8, m["hp"], m["maxhp"], (80, 190, 100))
            py_ += 34
        # ---- target frame
        t = snap.get("target")
        if t and self.target is not None:
            r = frame_panel((LW // 2 - 180, 10, 360, 70))
            ta = self.actor(self.target) or t
            col = con_color(p["level"], t.get("level", 1)) if t.get("kind") != "npc" else (255, 225, 110)
            text(clean_name(t), r.x + 18, r.y + 8, col, F_BD)
            text(f"Lv {t.get('level', '?')}  {t.get('kind', '').title()}", r.right - 18, r.y + 9, GREY, F_SM, right=True)
            bar(r.x + 18, r.y + 28, r.width - 36, 15, t.get("hp", 0), t.get("maxhp", 1), (196, 36, 40), f"{t.get('hp', 0)} / {t.get('maxhp', 1)}")
            ts = snap.get("target_status") or {}
            bits = []
            if ts.get("stun"): bits.append((f"Stunned {ts['stun']}s", (255, 230, 120)))
            if ts.get("dot"): bits.append((ts["dot"], (255, 150, 80)))
            if ta and ta.get("aggro"): bits.append(("Attacking you!", (255, 120, 100)))
            if not bits: bits.append(("Auto-attack ON" if self.auto else "Click again or press 1-6 to attack", GREY))
            xx = r.x + 18
            for s_, c_ in bits:
                xx += text(s_, xx, r.y + 49, c_, F_SM).get_width() + 14
        rcall = snap.get("raid_call")
        if rcall and rcall.get("age", 0) < 60:      # 0.45: the muster banner goes away after a minute; join at the War Hall after that
            bw_ = 640; br_ = pygame.Rect(LW // 2 - bw_ // 2, 86, bw_, 58)
            pul_ = int(40 + 30 * math.sin(self.t * 4))
            bs_ = pygame.Surface(br_.size, pygame.SRCALPHA); pygame.draw.rect(bs_, (40 + pul_ // 3, 14, 12, 225), (0, 0, br_.w, br_.h), border_radius=8)
            screen.blit(bs_, br_.topleft); pygame.draw.rect(screen, (240, 190, 70), br_, 2, border_radius=8)
            side_ = "DEFEND" if rcall["role"] == "defend" else "ATTACK"
            mm_, ss_ = rcall["left"] // 60, rcall["left"] % 60
            text(f"CITY RAID  \u2022  {rcall['att']} warband vs {rcall['name']}  \u2022  starts in {mm_}:{ss_:02d}", br_.centerx, br_.y + 6, (255, 226, 150), F_BD, True, center=True)
            text(f"{side_}  \u2022  {rcall['where']}  \u2022  warband {rcall['count']}/{rcall['cap']}" + ("  \u2022  FULL - a place may open" if rcall["full"] else ""), br_.x + 14, br_.y + 32, (230, 220, 200), F_SM)
            if rcall["joined"]: text("You are in the warband", br_.right - 14, br_.y + 32, (150, 240, 160), F_BD, right=True)
            else: self.ui_rects["raidjoin"] = button((br_.right - 150, br_.y + 28, 136, 26), "Join the warband", not rcall["full"], True)
        if snap.get("pvp"):
            m = snap["pvp"]
            text(f"ARENA {m['mode']}v{m['mode']} — round {m['round']} — your HP {m['player_hp']}/{m['player_maxhp']}", LW // 2, 144, (255, 120, 120), F_BD, True, center=True)
        self.draw_gains()
        self.draw_minimap()
        # ---- chat log, above the bottom bar
        cw = 440
        lines = []
        if not self.chat_open:
            unread = max(0, getattr(self, "_msg_n", 0) - self._chat_seen)          # running count: the history itself is capped at 60
            kr = pygame.Rect(8, LH - 146 - 22, 120, 22)
            pygame.draw.rect(screen, (30, 24, 20), kr, border_radius=5); pygame.draw.rect(screen, (170, 140, 80) if unread else (90, 74, 52), kr, 1, border_radius=5)
            text("Chat  +" + (f"  ({unread} new)" if unread else ""), kr.x + 8, kr.y + 4, (255, 226, 150) if unread else PARCH, F_PL)
            self.ui_rects["chat"] = kr
            lines = []
        else:
            self._chat_seen = getattr(self, "_msg_n", 0)
        for s, col, t0 in (list(self.messages)[-12:] if self.chat_open else []):
            cur = ""
            for wd in s.split(" "):
                if F_SM.size(cur + " " + wd)[0] > cw - 24 and cur:
                    lines.append((cur, col, t0)); cur = "   " + wd
                else:
                    cur = (cur + " " + wd) if cur else wd
            lines.append((cur, col, t0))
        lines = lines[-12:]
        if not self.chat_open: lines = []
        # chat sits above the health orb so nothing covers it; it shrinks to fit and fades when idle
        ch = len(lines) * 15 + 12 + 18
        cr = pygame.Rect(8, LH - 146 - ch, cw, ch) if self.chat_open else pygame.Rect(0, 0, 0, 0)
        recent = any(now - t0 < 8 for _, _, t0 in lines)
        if self.chat_open:
            bg = pygame.Surface(cr.size, pygame.SRCALPHA); bg.fill((8, 6, 6, 165 if recent else 110)); screen.blit(bg, cr.topleft)
            pygame.draw.rect(screen, (70, 58, 40), cr, 1)
            hr = pygame.Rect(cr.x, cr.y, cr.w, 18)
            pygame.draw.rect(screen, (34, 28, 22), hr); pygame.draw.line(screen, (70, 58, 40), hr.bottomleft, hr.bottomright)
            text("Chat   (` to hide)", hr.x + 8, hr.y + 2, (190, 170, 120), F_PL)
            text("-", hr.right - 14, hr.y + 1, (255, 226, 150), F_BD, center=True)
            self.ui_rects["chat"] = hr
            y = cr.bottom - 20
            for s, col, t0 in reversed(lines):
                text(s, cr.x + 10, y, col if now - t0 < 30 else shade(col, .75), F_SM, True); y -= 15
        # ---- bottom bar
        self.draw_bottom_bar(snap, p, mx, my)
        # ---- banners
        # 0.46: what you are doing right now - a weapon attack (left click / auto-attack) or a spell (number keys)
        ls_ = getattr(self, "last_spell", None); lw_ = getattr(self, "last_weapon_t", -9)
        if self.mode == "world" and (ls_ and now - ls_[1] < 1.4 or (self.auto and self.target is not None and now - lw_ < 2.0)):
            if ls_ and now - ls_[1] < 1.4 and ls_[1] >= lw_ - .5:
                chip_, ccol_ = f"SPELL: {ls_[0]}", ls_[2]
            else:
                wpn_ = next((i_["item"] for i_ in self.snap.get("inventory", []) if i_.get("equipped") and i_.get("slot") == "weapon"), "your weapon")
                chip_, ccol_ = f"WEAPON ATTACK: {wpn_}  (left click)", (235, 235, 245)
            cs_ = tsurf(chip_, ccol_, F_BD, True)
            cbx_ = pygame.Surface((cs_.get_width() + 24, cs_.get_height() + 8), pygame.SRCALPHA)
            pygame.draw.rect(cbx_, (10, 12, 22, 170), cbx_.get_rect(), border_radius=8); pygame.draw.rect(cbx_, (*ccol_[:3], 200), cbx_.get_rect(), 2, border_radius=8)
            screen.blit(cbx_, (LW // 2 - cbx_.get_width() // 2, LH - 128)); screen.blit(cs_, (LW // 2 - cs_.get_width() // 2, LH - 124))
        cb = self.cast_banner
        if cb and now - cb[1] < 1.3:
            k_ = now - cb[1]; al = 255 if k_ < .8 else int(255 * (1.3 - k_) / .5)
            kind_ = {"attack": "Attack spell", "defense": "Defensive spell"}.get(cb[3], "Ability") + f"  -  key {cb[4].replace('!', 'Shift+1').replace('@', 'Shift+2').replace('#', 'Shift+3').replace('$', 'Shift+4').replace('%', 'Shift+5').replace('^', 'Shift+6')}"
            sb = tsurf(cb[0], cb[2], F_BIG, True).copy(); sb.set_alpha(al)
            sc = tsurf(kind_, (225, 225, 235), F_SM, True).copy(); sc.set_alpha(al)
            bx = LW // 2; by = LH - 236
            bkp = pygame.Surface((max(sb.get_width(), sc.get_width()) + 36, sb.get_height() + sc.get_height() + 10), pygame.SRCALPHA)
            pygame.draw.rect(bkp, (10, 12, 22, int(150 * al / 255)), bkp.get_rect(), border_radius=8)
            pygame.draw.rect(bkp, (*cb[2][:3], int(200 * al / 255)), bkp.get_rect(), 2, border_radius=8)
            screen.blit(bkp, (bx - bkp.get_width() // 2, by - 4))
            screen.blit(sb, (bx - sb.get_width() // 2, by)); screen.blit(sc, (bx - sc.get_width() // 2, by + sb.get_height()))
        if self.zone_banner and now - self.zone_banner[1] < 3.5:
            k = now - self.zone_banner[1]; alpha = 255 if k < 2.5 else int(255 * (3.5 - k))
            s1 = tsurf(self.zone_banner[0], (255, 230, 150), F_BIG, True).copy(); s1.set_alpha(alpha)
            screen.blit(s1, (LW // 2 - s1.get_width() // 2, 170))
            s2 = tsurf(self.zone_banner[2], (230, 230, 230), F_TI, True).copy(); s2.set_alpha(alpha)
            screen.blit(s2, (LW // 2 - s2.get_width() // 2, 224))
            # ornamental rules either side of the subtitle
            orn = pygame.Surface((LW, 12), pygame.SRCALPHA); hw = s2.get_width() // 2 + 18; spread = int(150 * min(1, k * 2))
            for sgn in (-1, 1):
                x0 = LW // 2 + sgn * hw; x1 = x0 + sgn * spread
                pygame.draw.line(orn, (*GOLD, alpha), (x0, 6), (x1, 6), 2)
                pygame.draw.polygon(orn, (255, 230, 150, alpha), [(x0, 1), (x0 + 5, 6), (x0, 11), (x0 - 5, 6)])
                pygame.draw.circle(orn, (*GOLD, alpha), (x1, 6), 2)
            screen.blit(orn, (0, 230 + s2.get_height() // 2 - 6))
        if now - self.levelup_t < 3:
            s1 = tsurf(f"LEVEL {p['level']}!", (255, 220, 90), F_BIG, True); screen.blit(s1, (LW // 2 - s1.get_width() // 2, 260))
            new = [a["name"] for a in snap["abilities"] if a["unlock"] == p["level"]] + [x["name"] for x in snap.get("passives", []) if x["unlock"] == p["level"]]
            if new:
                s2 = tsurf("New: " + ", ".join(new), (230, 230, 230), F_TI, True); screen.blit(s2, (LW // 2 - s2.get_width() // 2, 312))
        if now - self.death_banner < 3:
            s1 = tsurf("You have died", (255, 70, 60), F_BIG, True); screen.blit(s1, (LW // 2 - s1.get_width() // 2, 260))
        if self.tooltip: self.draw_tooltip(self.tooltip)
    def _slot_icon(self, kind, r, label, count, tip_title, tip_text, key, mx, my):
        """A square item slot on the bottom bar."""
        if kind == "loot":
            pygame.draw.rect(screen, (40, 34, 30), r, border_radius=6)
            ls = gfx.loot_sprite("Rare"); screen.blit(ls, (r.centerx - ls.get_width() // 2, r.centery - ls.get_height() // 2 + 2))
            pygame.draw.rect(screen, GOLD, r, 1, border_radius=6)
        elif kind == "food":
            pygame.draw.rect(screen, (34, 40, 48), r, border_radius=6)
            cx, cy = r.centerx, r.centery + 2
            pygame.draw.ellipse(screen, (120, 190, 220), (cx - 13, cy - 7, 22, 14))
            pygame.draw.polygon(screen, (90, 160, 200), [(cx + 8, cy), (cx + 16, cy - 7), (cx + 16, cy + 7)])
            pygame.draw.circle(screen, (20, 30, 40), (cx - 8, cy - 2), 2)
            pygame.draw.rect(screen, (110, 150, 90), r, 1, border_radius=6)
        else:
            screen.blit(gfx.item_icon(kind, "Common" if kind != "scroll" else "Rare", r.w), r)
        text(label, r.x + 3, r.y + 1, (255, 255, 255), F_PL, True)
        if count != "":
            text(count, r.right - 4, r.bottom - 15, (255, 255, 255), F_BD, True, right=True)
            if count == 0:
                o = pygame.Surface(r.size, pygame.SRCALPHA); o.fill((0, 0, 0, 110)); screen.blit(o, r)
        self.ui_rects[key] = r
        if r.collidepoint(mx, my): self.tooltip = [(tip_title, PARCH, F_BD), (tip_text, GREY, F_SM)]

    def draw_bottom_bar(self, snap, p, mx, my):
        bar_r = pygame.Rect(0, LH - 64, LW, 64)
        s = pygame.Surface(bar_r.size, pygame.SRCALPHA)
        for i in range(bar_r.height):
            s.fill((22 + i // 6, 18 + i // 8, 16, 235), (0, i, bar_r.width, 1))
        screen.blit(s, bar_r.topleft)
        pygame.draw.line(screen, shade(GOLD, .5), (0, bar_r.y), (LW, bar_r.y), 3)
        pygame.draw.line(screen, GOLD, (0, bar_r.y + 1), (LW, bar_r.y + 1), 1)
        # xp bar along the top edge
        need = max(1, snap.get("xp_need") or xp_need(p["level"]))
        bar(110, bar_r.y + 6, LW - 220, 6, p["xp"], need, (170, 110, 240))
        if pygame.Rect(110, bar_r.y + 2, LW - 220, 12).collidepoint(mx, my):
            self.tooltip = [(f"Experience {p['xp']:,} / {need:,}  ({int(100 * p['xp'] / need)}%)", PARCH, F_BD)]
        # orbs
        self.draw_orb(56, LH - 44, 44, p["hp"], p["maxhp"], (200, 30, 36), "HP")
        self.draw_orb(LW - 94, LH - 40, 40, p.get("mana", 100), 100, (40, 90, 220), "MP")
        # 0.44.20: the bar is laid out in labelled groups - ATTACK (1-6), DEFENSE (7-0), MASTERY (Shift+1-6), ITEMS, and a 5x2 block
        # of window buttons - and the icons grow to fill the width up to the mana orb.
        G = 10; BW = 56; BH = 19; BGAP = 2
        avail = (LW - 142) - 112
        S = int(clamp((avail - 18 * 3 - 4 * G - (5 * BW + 4 * BGAP)) / 22, 26, 36)); STP = S + 3
        y = bar_r.y + 62 - S
        mp = p.get("mana", 100)
        abil = snap["abilities"]; caps = abil[10:]
        GROUPS = (("ATTACK", (230, 96, 80), (60, 20, 18, 150)), ("DEFENSE", (96, 168, 236), (18, 34, 62, 150)),
                  ("MASTERY  \u21e7", (240, 196, 90), (60, 44, 14, 150)), ("ITEMS", (190, 190, 170), (36, 34, 30, 150)))
        def group_box(gx, n, gi):
            lab, col, bg = GROUPS[gi]
            w_ = n * STP - 3
            box = pygame.Rect(gx - 3, y - 14, w_ + 6, S + 16)
            bs = pygame.Surface(box.size, pygame.SRCALPHA); pygame.draw.rect(bs, bg, bs.get_rect(), border_radius=6)
            screen.blit(bs, box); pygame.draw.rect(screen, shade(col, .7), box, 1, border_radius=6)
            text(lab, gx, y - 13, col, F_PL, True)
            return col
        def ab_slot(ab, r, hotkey, col, kind_txt):
            screen.blit(gfx.ability_icon(ab, S), r)
            if ab.get("locked"):
                o = pygame.Surface((S, S), pygame.SRCALPHA); o.fill((0, 0, 0, 185)); screen.blit(o, r)
                text(f"Lv{ab['unlock']}", r.centerx, r.centery - 7, (200, 200, 200), F_PL, True, center=True)
            elif not ab["ready"]:
                o = pygame.Surface((S, S), pygame.SRCALPHA)
                frac = clamp(ab["cooldown"] / max(1, ab["cd"]), 0, 1)
                o.fill((0, 0, 0, 160), (0, int(S * (1 - frac)), S, int(S * frac) + 1)); o.fill((0, 0, 0, 50))
                screen.blit(o, r)
                text(ab["cooldown"], r.centerx, r.centery - 9, (255, 255, 255), F_PL, True, center=True)
            elif mp < ab["mana"]:
                o = pygame.Surface((S, S), pygame.SRCALPHA); o.fill((20, 40, 120, 130)); screen.blit(o, r)
            elif r.collidepoint(mx, my):
                screen.blit(gfx.glow(30, (50, 40, 10)), (r.centerx - 30, r.centery - 30), special_flags=pygame.BLEND_RGB_ADD)
            pygame.draw.rect(screen, col, r, 2, border_radius=6)
            text(hotkey, r.x + 3, r.y + 1, (255, 255, 255), F_PL, True)
            self.ui_rects[f"ab{ab['slot']}" if kind_txt == "Mastery" else f"ab{hotkey}"] = r
            if r.collidepoint(mx, my):
                self.tooltip = [(ab["name"] + (f"  (Shift+{hotkey[-1]})" if kind_txt == "Mastery" else f"  [{hotkey}]"), PARCH, F_BD),
                                (f"{kind_txt} \u2022 {ab['mana']} mana \u2022 {ab['cd']:g}s cooldown" + (f" \u2022 range {ab['range']:g}" if ab["range"] else ""), GREY, F_SM),
                                (ab.get("desc", ""), (220, 220, 220), F_SM)]
                if ab.get("locked"): self.tooltip.append((f"Unlocks at level {ab['unlock']}", (255, 120, 100), F_SM))
        x = 112
        for gi, (lo_, hi_) in enumerate(((0, 6), (6, 10))):
            grp = abil[lo_:hi_]
            if not grp: continue
            col = group_box(x, len(grp), gi)
            for i, ab in enumerate(grp):
                k_ = lo_ + i
                ab_slot(ab, pygame.Rect(x, y, S, S), "1234567890"[k_], col, "Attack" if gi == 0 else "Defensive")
                x += STP
            x += G
        if caps:
            col = group_box(x, len(caps), 2)
            for j, ab in enumerate(caps):
                ab_slot(ab, pygame.Rect(x, y, S, S), "\u21e7" + "123456"[j], col, "Mastery")
                x += STP
            x += G
        sc = snap.get("scrolls", {})
        items_ = (("potion", "potion", "H", snap["potions"], "Health Potion  [H]", "Restores a third of your health."),
                  ("mana", "mana", "J", snap["stock"]["mana"], "Mana Potion  [J]", "Restores 50 mana."),
                  ("scroll", "scroll", "T", snap["stock"]["scroll"], "Scroll of Teleportation  [T]", "Teleports you to the nearest town. Not usable in dungeons."),
                  ("scroll", "buffscroll", "Y", sum(sc.values()), "Buff Scroll  [Y]", "Bread " + str(sc.get("Health Bread", 0)) + " \u2022 Sunwine " + str(sc.get("Sunwine", 0)) + " \u2022 Might " + str(sc.get("Scroll of Might", 0)) + " \u2022 Fortitude " + str(sc.get("Scroll of Fortitude", 0)) + " \u2022 Swiftness " + str(sc.get("Scroll of Swiftness", 0)) + ".  Brew them at an inn."),
                  ("food", "food", "V", snap.get("food", 0), "Cooked Food  [V]", "Eat out of combat to recover health over time. Catch fish (G) and cook them at an inn."),
                  ("loot", "loot", "Z", "", "Pick up loot  [Z]", "Grab the nearest item on the ground."))
        group_box(x, len(items_), 3)
        for kind, key, lab, cnt, ttl, tip in items_:
            self._slot_icon(kind, pygame.Rect(x, y, S, S), lab, cnt, ttl, tip, key, mx, my)
            x += STP
        x += G
        btns = (("Bag I", "bag"), ("Skills K", "skills"), ("Hero C", "class"), ("Stats U", "stats"), ("Gear", "geartab"),
                ("Map M", "map"), ("Quest Q", "quest"), ("Guide F1", "guide"), ("Mats", "matstab"), ("Party", "partyw"))
        bw_ = max(BW, min(78, ((LW - 142) - x - 4 * BGAP) // 5))
        by0 = y - 14 + (S + 16 - 2 * BH - BGAP) // 2
        for j, (lab, key) in enumerate(btns):
            rr = pygame.Rect(x + (j % 5) * (bw_ + BGAP), by0 + (j // 5) * (BH + BGAP), bw_, BH)
            hot = rr.collidepoint(mx, my)
            pygame.draw.rect(screen, (84, 66, 44) if hot else (50, 40, 32), rr, border_radius=4)
            pygame.draw.rect(screen, (120, 98, 66), rr, 1, border_radius=4)
            text(lab, rr.centerx, rr.y + (BH - F_PL.get_height()) // 2, PARCH, F_PL, center=True)
            self.ui_rects[key] = rr
        # status line above the bar, right side
        ps = snap["pvp_status"]
        line = f"Gold {p['gold']:,}    {ps['rank']} {ps['rating']}    Kills {p['kills']}"
        text(line, LW - 150, bar_r.y - 38, (255, 215, 80), F_BD, True, right=True)
        # settings gear, bottom-right corner
        g = pygame.Rect(LW - 40, LH - 60, 32, 32)
        hotg = g.collidepoint(mx, my) or self.mode == "settings"
        pygame.draw.circle(screen, (84, 66, 44) if hotg else (50, 40, 32), g.center, 18); pygame.draw.circle(screen, GOLD, g.center, 18, 1)
        cx, cy = g.center
        for k in range(8):
            a_ = k / 8 * math.tau + self.t * (.5 if hotg else 0)
            pygame.draw.line(screen, PARCH, (cx + math.cos(a_) * 8, cy + math.sin(a_) * 8), (cx + math.cos(a_) * 13, cy + math.sin(a_) * 13), 3)
        pygame.draw.circle(screen, PARCH, g.center, 9, 3); pygame.draw.circle(screen, (50, 40, 32), g.center, 3)
        self.ui_rects["settings"] = g
        if hotg and self.mode != "settings": self.tooltip = [("Settings  [Esc]", PARCH, F_BD), ("Graphics, brightness, sound, full screen, minimize.", GREY, F_SM)]
        # window buttons, top-right corner: full screen and minimize
        fb = pygame.Rect(LW - 68, 4, 30, 20); mb = pygame.Rect(LW - 34, 4, 30, 20)
        for rr, key, tip in ((fb, "fullscreen", "Full screen / windowed  [F11]"), (mb, "minimize", "Minimize the window")):
            hv = rr.collidepoint(mx, my)
            pygame.draw.rect(screen, (84, 66, 44) if hv else (40, 32, 26), rr, border_radius=4); pygame.draw.rect(screen, (120, 98, 66), rr, 1, border_radius=4)
            self.ui_rects[key] = rr
            if hv: self.tooltip = [(tip, PARCH, F_BD)]
        pygame.draw.rect(screen, PARCH, (fb.x + 8, fb.y + 5, 14, 10), 1)
        pygame.draw.line(screen, PARCH, (mb.x + 9, mb.y + 14), (mb.x + 21, mb.y + 14), 2)

    def draw_orb(self, cx, cy, r, v, mx_, col, label):
        frac = clamp(v / max(1, mx_), 0, 1)
        s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        pygame.draw.circle(s, (14, 10, 12, 255), (r, r), r)
        liquid = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        top = int(r * 2 * (1 - frac))
        for yy in range(top, r * 2):
            f = (yy - top) / max(1, r * 2 - top)
            liquid.fill((*shade(col, 1.25 - f * .55), 255), (0, yy, r * 2, 1))
        wave = math.sin(self.t * 2.5) * 2
        if 0 < frac < 1:
            pygame.draw.ellipse(liquid, (*shade(col, 1.5), 255), (r * .2, top - 3 + wave, r * 1.6, 6))
        mask = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA); pygame.draw.circle(mask, (255, 255, 255, 255), (r, r), r - 3)
        liquid.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        s.blit(liquid, (0, 0))
        hl = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        pygame.draw.ellipse(hl, (255, 255, 255, 60), (r * .45, r * .25, r * .9, r * .55))
        pygame.draw.ellipse(hl, (255, 255, 255, 110), (r * .62, r * .32, r * .35, r * .18))
        s.blit(hl, (0, 0))
        screen.blit(s, (cx - r, cy - r))
        pygame.draw.circle(screen, shade(GOLD, .45), (cx, cy), r + 1, 5)
        pygame.draw.circle(screen, GOLD, (cx, cy), r + 3, 2)
        text(f"{int(v)}", cx, cy - 10, (255, 255, 255), F_DMG, True, center=True)
        text(label, cx, cy + 10, (230, 230, 230), F_PL, True, center=True)

    def draw_skillbook(self):
        snap = self.snap; mx, my = self.mouse
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 150)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 470, 24, 940, min(740, LH - 40)), alpha=240)
        cls = self.w.class_name(); spec = snap.get("spec")
        bd = snap.get("build", {})
        text(f"SKILLS \u2014 {spec + ' ' if spec else ''}{cls}", r.x + 20, r.y + 14, PARCH, F_TI)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        self.ui_rects["stats"] = button((r.right - 200, r.y + 14, 90, 28), "Stats (U)")
        text(f"Spell points: {bd.get('rank_left', 0)}", r.x + 20, r.y + 48, (255, 215, 80) if bd.get("rank_left") else GREY, F_BD)
        text(f"One point per level.  Raise skill ranks (max {MAX_RANK_UI}) at a Skill Shop, in every town.", r.x + 150, r.y + 50, GREY, F_SM)
        specs = SPECS.get(cls)
        if specs:
            text("Role:", r.x + 420, r.y + 22, GOLD, F_BD)
            for i, (n, role) in enumerate(specs):
                rr = pygame.Rect(r.x + 470 + i * 118, r.y + 14, 112, 30)
                sel = n == spec
                pygame.draw.rect(screen, ROLE_COL[role] if sel else shade(ROLE_COL[role], .35), rr, border_radius=5)
                pygame.draw.rect(screen, GOLD if sel else (90, 74, 52), rr, 2 if sel else 1, border_radius=5)
                text(f"{n}", rr.centerx, rr.y + 2, (255, 255, 255), F_PL, center=True)
                text(role, rr.centerx, rr.y + 15, (240, 240, 240), F_SM, center=True)
                self.ui_rects["spec_" + n] = rr
        ROW = 62

        def skill_cell(ab, x, y, key_label, w):
            screen.blit(gfx.ability_icon(ab, 48), (x, y))
            if ab.get("locked"):
                o = pygame.Surface((48, 48), pygame.SRCALPHA); o.fill((0, 0, 0, 170)); screen.blit(o, (x, y))
            text(f"[{key_label}] {ab['name']}", x + 58, y, PARCH if not ab.get("locked") else GREY, F_BD)
            info = f"{ab['kind'].title()} \u2022 {ab['mana']} mana \u2022 {ab['cd']:.1f}s" + (f" \u2022 range {ab['range']:g}" if ab["range"] else "")
            text(info, x + 58, y + 17, GREY, F_SM)
            ds = ab.get("desc", "")
            while F_SM.size(ds)[0] > w - 112 and len(ds) > 8: ds = ds[:-2].rstrip(" .,") + "\u2026" if not ds.endswith("\u2026") else ds[:-2] + "\u2026"
            text(ds, x + 58, y + 31, (215, 215, 215), F_SM)
            if ab.get("locked"):
                text(f"Unlocks at level {ab['unlock']}", x + w - 120, y, (255, 120, 100), F_SM)
            else:
                rk = ab.get("rank", 1)
                text(f"Rank {rk}/{MAX_RANK_UI}", x + w - 90, y + 1, (255, 215, 80), F_SM)
        for i, ab in enumerate(snap["abilities"][:10]):
            col_ = 0 if i < 6 else 1
            row = i if i < 6 else i - 6
            x = r.x + 20 + col_ * 460; y = r.y + 100 + row * ROW
            if i == 0: text("ATTACK SKILLS  (keys 1-6)", x, y - 22, GOLD, F_BD)
            if i == 6: text("DEFENSIVE SKILLS  (keys 7-0)", x, y - 22, GOLD, F_BD)
            skill_cell(ab, x, y, "1234567890"[i], 440)
        y = r.y + 100 + 4 * ROW + 6
        x = r.x + 480
        pas_ = snap.get("passives", [])
        text(f"PASSIVES  ({sum(1 for q in pas_ if q.get('active'))} of {self.w.passive_slots()} slots \u2022 choose at a Skill Shop)", x, y, GOLD, F_BD); y += 22
        for ps in [q for q in pas_ if q.get("active")] or [q for q in pas_ if not q.get("unlocked")][:1]:
            c = (120, 255, 140) if ps["active"] else GREY
            pygame.draw.circle(screen, shade(c, .4), (x + 14, y + 14), 14); pygame.draw.circle(screen, c, (x + 14, y + 14), 14, 2)
            text("P", x + 14, y + 6, c, F_BD, center=True)
            text(ps["name"], x + 38, y, PARCH if ps["active"] else GREY, F_BD)
            text(ps["desc"] + ("" if ps["active"] else f"  (level {ps['unlock']})"), x + 38, y + 16, c, F_SM)
            y += 38
        text(f"{len(pas_)} passives to choose from, unlocking at levels " + ", ".join(str(q["unlock"]) for q in pas_) + ".", x, y, GREY, F_SM)
        caps = snap["abilities"][10:]
        cy0 = r.y + 100 + 6 * ROW + 26
        pygame.draw.line(screen, shade(GOLD, .5), (r.x + 20, cy0 - 8), (r.right - 20, cy0 - 8))
        text("HIGH-LEVEL SKILLS  (Shift + 1-6)  \u2014 unlock at levels 30, 40, 50, 60, 70, 80", r.x + 20, cy0, GOLD, F_BD)
        for j, ab in enumerate(caps):
            x = r.x + 20 + (j % 2) * 460; y = cy0 + 24 + (j // 2) * ROW
            skill_cell(ab, x, y, "\u21e7" + str(j + 1), 440)
        text(f"Critical strike chance {int(snap.get('crit_chance', .05) * 100)}%  \u2022  Run speed {int(snap.get('move_speed', 1) * 100)}%",
             r.x + 20, r.bottom - 26, (220, 220, 220), F_SM)

    def draw_stats(self):
        snap = self.snap; p = snap["player"]; mx, my = self.mouse
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 150)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 400, 30, 800, 700), alpha=240)
        bd = snap.get("build", {"s": {}, "stat_left": 0, "rank_left": 0}); st = bd.get("s", {})
        ttl_ = f"CHARACTER STATS \u2014 {p['name']}, Level {p['level']} {self.w.class_name()}"
        if F_TI.size(ttl_)[0] > r.w - 250: ttl_ = f"{p['name']}, Level {p['level']} {self.w.class_name()}"      # keep clear of the Skills button
        text(ttl_, r.x + 20, r.y + 14, PARCH, F_TI)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close"), "skills": button((r.right - 210, r.y + 14, 100, 28), "Skills (K)")}
        left = bd.get("stat_left", 0)
        text(f"Stat points to spend: {left}", r.x + 20, r.y + 54, (255, 215, 80) if left else GREY, F_BD)
        text("You earn 3 stat points every level.  Spend stat and spell points at a Skill Shop, in every town.", r.x + 20, r.y + 76, GREY, F_SM)
        rows = (("str", "Strength", (230, 110, 80), "+0.8% damage per point"),
                ("agi", "Agility", (120, 220, 120), "+0.25% crit chance and +0.2% run speed per point"),
                ("int", "Intellect", (110, 160, 255), "+0.5% healing and shields, \u22120.4% mana cost, +1% mana regeneration per point"),
                ("vit", "Vitality", (240, 200, 90), "+8 maximum health per point"))
        y = r.y + 110
        for key, nm, col, desc in rows:
            row = pygame.Rect(r.x + 20, y, r.width - 40, 62)
            pygame.draw.rect(screen, (28, 24, 30), row, border_radius=8); pygame.draw.rect(screen, shade(col, .5), row, 1, border_radius=8)
            pygame.draw.circle(screen, shade(col, .5), (row.x + 32, row.centery), 22); pygame.draw.circle(screen, col, (row.x + 32, row.centery), 22, 3)
            text(str(st.get(key, 0)), row.x + 32, row.centery - 10, (255, 255, 255), F_BD, True, center=True)
            text(nm, row.x + 70, row.y + 8, PARCH, F_TI)
            text(desc, row.x + 70, row.y + 36, GREY, F_SM)
            gb_ = bd.get("g", {}).get(key, 0)
            if gb_: text(f"+{gb_} from gear", row.right - 20, row.y + 12, (120, 230, 255), F_BD, right=True)
            y += 70
        # derived values
        y += 6
        pygame.draw.line(screen, shade(GOLD, .5), (r.x + 20, y), (r.right - 20, y)); y += 10
        text("DERIVED", r.x + 20, y, GOLD, F_BD)
        w_ = self.w
        vals = (("Maximum health", f"{p['maxhp']:,}"), ("Damage bonus", f"+{w_.passive_fx('dmg_pct') * 100:.1f}%"), ("Critical strike", f"{snap.get('crit_chance', .05) * 100:.1f}%"),
                ("Run speed", f"{int(snap.get('move_speed', 1) * 100)}%"), ("Mana cost", f"\u2212{min(40, st.get('int', 0) * .4):.1f}%"), ("Mana regen", f"+{st.get('int', 0)}%"))
        for i, (lab, v) in enumerate(vals):
            text(lab, r.x + 30 + (i % 3) * 250, y + 24 + (i // 3) * 22, GREY, F_SM); text(v, r.x + 160 + (i % 3) * 250, y + 24 + (i // 3) * 22, PARCH, F_SM)
        # 0.34 round 3: what you are wearing and the set bonus it gives, right under the stats
        gy_ = y + 24 + 2 * 22 + 8
        text("EQUIPPED", r.x + 20, gy_, GOLD, F_BD)
        eqd = {i.get("slot"): i for i in snap.get("inventory", []) if i.get("equipped")}
        rgs_ = sorted((i for i in snap.get("inventory", []) if i.get("equipped") and i.get("slot") == "ring"), key=lambda i: i["id"])
        eqd["ring1"] = rgs_[0] if rgs_ else None; eqd["ring2"] = rgs_[1] if len(rgs_) > 1 else None
        for i_, (sl_, lab_) in enumerate((("weapon", "Weapon"), ("armor", "Armor"), ("helm", "Helm"), ("trinket", "Necklace"), ("ring1", "Ring 1"), ("ring2", "Ring 2"))):
            it_ = eqd.get(sl_); cx_ = r.x + 30 + (i_ % 4) * 190; gy_ += 0 if i_ != 4 else 40
            if it_:
                nm_ = it_["item"]
                if F_SM.size(nm_)[0] > 176:                    # shorten with an ellipsis, keeping any "+N" upgrade level
                    m_ = re.search(r" \+\d+$", nm_); up_ = m_.group(0) if m_ else ""; base_ = nm_[:len(nm_) - len(up_)]
                    while F_SM.size(base_ + "\u2026" + up_)[0] > 176 and len(base_) > 4: base_ = base_[:-1]
                    nm_ = base_.rstrip() + "\u2026" + up_
                text(f"{lab_}  P{it_['power']}", cx_, gy_ + 22, GREY, F_SM); text(nm_, cx_, gy_ + 38, RARITY_COLOR.get(it_["rarity"], PARCH), F_SM)
            else:
                text(f"{lab_}: empty", cx_, gy_ + 22, (110, 110, 115), F_SM)
        sb_ = snap.get("set_bonus")
        for j_, ln_ in enumerate((sb_ or {}).get("lines", [])[:3] or ["No set bonus. Wear 2, 4 or 6 pieces of one set (Magic Shop, raid bosses or the War Hall Armory)."]):
            while F_SM.size(ln_)[0] > r.width - 60 and len(ln_) > 8: ln_ = ln_[:-2] + "\u2026"
            text(ln_, r.x + 30, gy_ + 58 + j_ * 16, (60, 220, 200) if sb_ else GREY, F_SM)
        text("Resetting your build is done at a Skill Shop.", r.x + 20, r.bottom - 40, GREY, F_SM)

    TT_HOLD = 0.0; TT_FADE = 0.6        # 0.46.9: a tooltip stays while the mouse is over the item; once the mouse leaves it fades out like the chat bubbles

    def draw_tooltip(self, lines):
        mx, my = self.mouse
        w = max(tsurf(s, c, f).get_width() for s, c, f in lines) + 20
        h = sum(f.get_height() + 3 for _, _, f in lines) + 14
        x = clamp(mx + 16, 0, LW - w); y = clamp(my - h - 8, 0, LH - h)
        self._paint_tooltip(lines, x, y, w, h)
        self._tt_last = (lines, x, y, w, h, self.t, self.mode); self._tt_drawn = True; self.tooltip = None

    def flush_tooltip(self):
        """End of frame: draw any tooltip a window set but did not draw itself, else let the last one linger and fade."""
        if self.tooltip: self.draw_tooltip(self.tooltip)
        last = getattr(self, "_tt_last", None)
        if getattr(self, "_tt_drawn", False) or not last: return
        lines, x, y, w, h, t0, mode = last
        age = self.t - t0
        if mode != self.mode or age > self.TT_HOLD + self.TT_FADE: self._tt_last = None; return
        if age <= self.TT_HOLD: self._paint_tooltip(lines, x, y, w, h); return
        a = int(255 * (1 - (age - self.TT_HOLD) / self.TT_FADE))
        box = pygame.Rect(x - 4, y - 4, w + 16, h + 16).clip(screen.get_rect())
        bg = screen.subsurface(box).copy()
        self._paint_tooltip(lines, x, y, w, h)
        fg = screen.subsurface(box).copy(); fg.set_alpha(a)
        screen.blit(bg, box.topleft); screen.blit(fg, box.topleft)

    def _paint_tooltip(self, lines, x, y, w, h):
        sh_ = pygame.Surface((w + 10, h + 10), pygame.SRCALPHA); pygame.draw.rect(sh_, (0, 0, 0, 70), (0, 0, w + 10, h + 10), border_radius=10); screen.blit(sh_, (x - 2, y + 3))
        rc_ = lines[0][1] if lines and tuple(lines[0][1]) in set(map(tuple, RARITY_COLOR.values())) and tuple(lines[0][1]) != (220, 220, 220) else None
        if rc_: frame_panel((x, y, w, h), alpha=240, border=tuple(rc_))
        else: frame_panel((x, y, w, h), alpha=235)
        yy = y + 7
        for s, c, f in lines:
            text(s, x + 10, yy, c, f); yy += f.get_height() + 3

    def draw_minimap(self):
        # 0.44.20: the minimap is drawn in the same isometric projection as the screen (2:1, like iso()), so a dot up and to the
        # right on the minimap is up and to the right on screen too.  It used to be a plain 45-degree turn, which stretched the
        # up/down direction 2x, so herbs and monsters looked to be somewhere they were not.
        p = self.w.player; s = 3; R = 120; A_ = 3.0                     # A_: minimap pixels per tile along the screen's x axis
        cx, cy = LW - 138, 138
        span = int((R / A_) * 1.5) + 4
        crop = pygame.Surface((span * 2 * s, span * 2 * s)); crop.fill((10, 10, 14))
        crop.blit(self.inst_minimap if self.in_inst else self.minimap_base, (-(p["x"] - span) * s, -(p["y"] - span) * s))
        rot = pygame.transform.rotate(crop, -45)
        k_ = A_ / (.70710678 * s)
        rot = pygame.transform.scale(rot, (int(rot.get_width() * k_), int(rot.get_height() * k_ * HTH / HTW)))
        circ = pygame.Surface((R * 2, R * 2), pygame.SRCALPHA)
        circ.blit(rot, (R - rot.get_width() // 2, R - rot.get_height() // 2))
        mask = pygame.Surface((R * 2, R * 2), pygame.SRCALPHA); mask.fill((0, 0, 0, 0))
        pygame.draw.circle(mask, (255, 255, 255, 255), (R, R), R)
        circ.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        def mm(x, y):
            dx, dy = x - p["x"], y - p["y"]
            return R + (dx - dy) * A_, R + (dx + dy) * A_ * HTH / HTW
        # 0.46.2: where each active quest can be done, as a soft gold area (dens of the monsters you need, the dungeon, or the whole zone)
        if not self.in_inst and self.snap.get("quest_marks"):
            lay = pygame.Surface((R * 2, R * 2), pygame.SRCALPHA); pulse = 0.75 + .25 * math.sin(self.t * 2.2)
            for m in self.snap["quest_marks"]:
                if m["k"] == "turn": continue
                shapes = [[(x + math.cos(a_) * r_, y + math.sin(a_) * r_) for a_ in [i_ / 28 * math.tau for i_ in range(28)]] for x, y, r_ in m.get("circles", [])]
                if m.get("rect"):
                    rx, ry, rw_, rh_ = m["rect"]; shapes.append([(rx, ry), (rx + rw_, ry), (rx + rw_, ry + rh_), (rx, ry + rh_)])
                for sh_ in shapes:
                    pts_ = [mm(x, y) for x, y in sh_]
                    pygame.draw.polygon(lay, (255, 205, 60, int(70 * pulse) if m.get("rect") is None else 34), pts_)
                    pygame.draw.polygon(lay, (255, 225, 110, int(215 * pulse)), pts_, 2)
            lay.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            circ.blit(lay, (0, 0))
        # 0.44.20: monsters and herbs your active quests need are shown in white
        qkill = set(); qelite = set(); qherb = set()
        if not self.in_inst:
            try:
                for q in self.w._qs()["active"]:
                    if q["prog"] >= q["need"]: continue
                    if q["kind"] == "kill": qkill.add((q.get("target"), q.get("area")))
                    elif q["kind"] == "elite": qelite.add(q.get("area"))
                    elif q["kind"] == "herb": qherb.add(q.get("target"))
            except Exception:
                pass
        for a in self.snap["actors"]:
            px, py = mm(a["x"], a["y"])
            if (px - R) ** 2 + (py - R) ** 2 > (R - 3) ** 2: continue
            ip = (int(px), int(py))
            if a["kind"] == "monster":
                nm_ = a.get("name", "").split(" #")[0]; elite_ = nm_.startswith("Elite ")
                sp_ = nm_[6:] if elite_ else nm_
                if qkill or qelite:
                    ar_ = self.w.area(a["x"], a["y"])[0]
                    if (sp_, ar_) in qkill or (elite_ and ar_ in qelite):
                        pygame.draw.circle(circ, (20, 20, 20), ip, 4); pygame.draw.circle(circ, (255, 255, 255), ip, 3); continue
                if elite_:
                    pygame.draw.circle(circ, (20, 14, 4), ip, 5); pygame.draw.circle(circ, (255, 210, 60), ip, 4); pygame.draw.circle(circ, (255, 90, 40), ip, 2)
                elif is_magic(a):
                    pygame.draw.circle(circ, (14, 8, 28), ip, 4); pygame.draw.circle(circ, (180, 110, 255), ip, 3)
                else: pygame.draw.circle(circ, (230, 60, 50), ip, 2)
            elif a["kind"] == "npc":
                pygame.draw.circle(circ, (255, 220, 80), ip, 2)
            else:                       # other players: a small diamond in their faction colour
                col = (90, 150, 255) if a["faction"] == "Alliance" else (255, 70, 150)
                pygame.draw.polygon(circ, (10, 10, 10), [(ip[0], ip[1] - 4), (ip[0] + 4, ip[1]), (ip[0], ip[1] + 4), (ip[0] - 4, ip[1])])
                pygame.draw.polygon(circ, col, [(ip[0], ip[1] - 3), (ip[0] + 3, ip[1]), (ip[0], ip[1] + 3), (ip[0] - 3, ip[1])])
        if not self.in_inst:
            for m in self.snap.get("quest_marks", []):
                qx, qy = mm(m["x"], m["y"]); dxq, dyq = qx - R, qy - R; dq = math.hypot(dxq, dyq)
                if dq < R - 8:
                    # 0.46.2: the '?' stays on the minimap; a hunt '?' now sits on the nearest real den of the monsters you need,
                    # inside its gold area, and a zone '?' inside the outlined zone
                    pass        # big '?' quest dots removed (misleading); the gold quest areas and rim pointers stay
                elif dq > 1:        # off the dial: a gold pointer on the rim
                    ux, uy = dxq / dq, dyq / dq; bx_, by_ = R + ux * (R - 9), R + uy * (R - 9)
                    pygame.draw.polygon(circ, (255, 214, 70), [(bx_ + ux * 6, by_ + uy * 6), (bx_ - uy * 5 - ux * 4, by_ + ux * 5 - uy * 4), (bx_ + uy * 5 - ux * 4, by_ - ux * 5 - uy * 4)])
            for lst, col in ((self.snap.get("herbs", []), (90, 255, 120)), (self.snap.get("veins", []), (235, 160, 70)), (self.snap.get("skins", []), (190, 140, 90))):
                for o in lst:
                    px, py = mm(o["x"], o["y"])
                    if (px - R) ** 2 + (py - R) ** 2 > (R - 3) ** 2: continue
                    c_ = (255, 255, 255) if o.get("name") in qherb and lst is self.snap.get("herbs") else col
                    pygame.draw.rect(circ, (10, 10, 10), (int(px) - 2, int(py) - 2, 5, 5)); pygame.draw.rect(circ, c_, (int(px) - 1, int(py) - 1, 3, 3))
        pygame.draw.polygon(circ, (255, 255, 255), [(R, R - 6), (R + 5, R + 5), (R, R + 2), (R - 5, R + 5)])
        screen.blit(circ, (cx - R, cy - R))
        self.ui_rects["minimap"] = pygame.Rect(cx - R, cy - R, R * 2, R * 2)
        if (self.mouse[0] - cx) ** 2 + (self.mouse[1] - cy) ** 2 < R * R:        # 0.44.20: what the dots mean
            self.tooltip = [("Minimap", PARCH, F_BD), ("White dot / square: monster or herb your quests need", (255, 255, 255), F_SM),
                            ("Red dot: monster   Gold ring: Elite   Violet dot: Magic (drops Arcane Dust)", (240, 120, 100), F_SM), ("Yellow dot: townsfolk (shops, quest givers)", (255, 220, 80), F_SM),
                            ("Diamond: other adventurer (blue Alliance, pink Horde)", (170, 170, 255), F_SM),
                            ("Squares: green herb, orange ore, brown carcass to skin", (120, 230, 140), F_SM), ("Gold area: where a quest can be done   Gold arrow on the rim: area is off the dial", (255, 214, 70), F_SM)]
        pygame.draw.circle(screen, shade(GOLD, .5), (cx, cy), R + 2, 4); pygame.draw.circle(screen, GOLD, (cx, cy), R + 2, 1)
        pygame.draw.circle(screen, (20, 16, 10), (cx, cy), R - 2, 1)
        for ang in range(0, 360, 45):
            aa = math.radians(ang); ln = 7 if ang % 90 == 0 else 4
            pygame.draw.line(screen, GOLD, (cx + math.cos(aa) * (R + 1), cy + math.sin(aa) * (R + 1)), (cx + math.cos(aa) * (R - ln), cy + math.sin(aa) * (R - ln)), 2 if ang % 90 == 0 else 1)
        text("N", cx - 4, cy - R - 16, GOLD, F_SM, True)
        snap = self.snap
        r = frame_panel((cx - 110, cy + R + 8, 220, 44), alpha=200)
        # Conquer-style location line: zone name plus the player's map coordinates
        title = snap["area"] if self.in_inst else f"{snap['area']}  ({int(p['x'])},{int(p['y'])})"
        while F_BD.size(title)[0] > 208 and len(title) > 4: title = title[:-2].rstrip() + "…" if not title.endswith("…") else title[:-2] + "…"
        text(title, r.centerx, r.y + 5, (255, 225, 140), F_BD, center=True)
        text(f"Lv {snap['area_level']} • {snap['hour']:02d}:00 • Day {snap['day']}", r.centerx, r.y + 24, (210, 210, 215), F_SM, center=True)

    # ------------------------------------------------------ windows
    MAP_MAX = 16.0

    def _map_rects(self):
        panel = pygame.Rect(4, 2, LW - 8, LH - 6)
        return panel, pygame.Rect(panel.x + 4, panel.y + 34, panel.width - 8, panel.height - 52)

    def _map_fit(self, view):
        C = self.MAPC
        return min(view.width / (W + 2 * C), view.height / (WORLD_H + 2 * C))

    def map_set(self, cx, cy, scl):
        """Set the map window: centre (cx, cy) in big-map tiles, scale in screen px per tile. None = the whole world."""
        TWd, THd = W + 2 * self.MG, WORLD_H + 2 * self.MG
        _, view = self._map_rects(); fit = self._map_fit(view)
        scl = min(self.MAP_MAX, scl)
        self.map_t = pygame.time.get_ticks()
        if scl <= fit * 1.001: self.map_view = None; return
        hw, hh = view.width / scl / 2, view.height / scl / 2
        cx = TWd / 2 if hw * 2 >= TWd else max(hw, min(TWd - hw, cx))
        cy = THd / 2 if hh * 2 >= THd else max(hh, min(THd - hh, cy))
        self.map_view = (cx, cy, scl)

    def map_open_default(self):
        """0.44.13: the map opens zoomed in on you (about 1.5x the whole-world fit) so it fills the screen; 0 shows it all."""
        _, view = self._map_rects(); self.map_center_player(self._map_fit(view) * 1.5)

    def map_center_player(self, scl=4.5):
        p = self.w.player; self.map_sel = None
        self.map_set(p["x"] + self.MG, p["y"] + self.MG, scl)

    def _map_cur(self):
        """(cx, cy, scl) of what is on screen right now."""
        if not self.map_geo: return None
        x0, y0, scl, ox, oy, view, mw, mh = self.map_geo
        return ox + mw / scl / 2, oy + mh / scl / 2, scl

    def _map_tile(self, pos):
        """World tile under a screen point (None when the map is not up)."""
        if not self.map_geo: return None
        x0, y0, scl, ox, oy, view, mw, mh = self.map_geo
        return (pos[0] - x0) / scl + ox - self.MG, (pos[1] - y0) / scl + oy - self.MG

    def _map_zone_at(self, pos):
        t = self._map_tile(pos)
        if not t: return None
        for a in AREAS:
            if a[1] <= t[0] < a[1] + a[3] and a[2] <= t[1] < a[2] + a[4]: return a
        return None

    def _map_zone_named(self, name):
        if not name: return None
        for a in AREAS:
            if a[0] == name: return a
        return None

    def map_zoom_at(self, pos, f):
        cur = self._map_cur()
        if not cur or not self.map_geo[5].collidepoint(pos): return
        cx, cy, scl = cur; view = self.map_geo[5]
        dx, dy = pos[0] - view.centerx, pos[1] - view.centery
        bx, by = cx + dx / scl, cy + dy / scl              # the map point under the cursor stays under the cursor
        new = scl * f
        self.map_set(bx - dx / new, by - dy / new, new)

    def map_open_zone(self, pos):
        """Double-click: open the zone under the cursor (fit it to the window); on the open zone, back out; on open sea, zoom in."""
        a = self._map_zone_at(pos)
        _, view = self._map_rects()
        if a is not None:
            if self.map_sel == a[0] and self.map_view is not None:
                self.map_sel = None; self.map_view = None; self.map_t = pygame.time.get_ticks(); return
            self.map_sel = a[0]
            scl = min(view.width / (a[3] * 1.25), view.height / (a[4] * 1.25))
            self.map_set(a[1] + a[3] / 2 + self.MG, a[2] + a[4] / 2 + self.MG, scl)
        else:
            cur = self._map_cur(); t = self._map_tile(pos)
            if cur and t: self.map_set(t[0] + self.MG, t[1] + self.MG, cur[2] * 2.2)

    def map_mouse_down(self, pos, btn):
        if btn in (4, 5):
            self.map_zoom_at(pos, 1.25 if btn == 4 else 0.8); return
        if btn == 1 and self.map_geo and self.map_geo[5].collidepoint(pos):
            cur = self._map_cur()
            if cur: self.map_drag = {"start": pos, "c": cur, "moved": False}

    def map_mouse_move(self, pos):
        d = self.map_drag
        if not d: return
        dx, dy = pos[0] - d["start"][0], pos[1] - d["start"][1]
        if not d["moved"] and math.hypot(dx, dy) > 5: d["moved"] = True
        if d["moved"]:
            cx, cy, scl = d["c"]
            self.map_set(cx - dx / scl, cy - dy / scl, scl)

    def map_mouse_up(self, pos, btn):
        d = self.map_drag
        if btn != 1 or not d: return
        self.map_drag = None
        if d["moved"]: return
        now = pygame.time.get_ticks(); lt, lp = self.map_click
        if now - lt < 450 and math.hypot(pos[0] - lp[0], pos[1] - lp[1]) < 10:
            self.map_click = (0, (0, 0)); self.map_open_zone(pos)
        else:
            self.map_click = (now, pos)

    def map_pan_key(self, dx, dy):
        cur = self._map_cur()
        if not cur: return
        cx, cy, scl = cur
        if self.map_view is None: return
        self.map_set(cx + dx * 40 / scl * 3, cy + dy * 40 / scl * 3, scl)

    def _map_plate(self, txt, cx, y, col, font, bg=(12, 10, 16, 150), edge=None, pill=False):
        """0.44.18: map labels are plain text with a thin dark halo (no boxes). pill=True keeps the old box for quest tags."""
        if pill:
            w_ = font.size(txt)[0] + 12; h_ = font.get_height() + 2
            pl = pygame.Surface((w_, h_), pygame.SRCALPHA)
            pygame.draw.rect(pl, bg, (0, 0, w_, h_), border_radius=h_ // 2)
            if edge: pygame.draw.rect(pl, edge, (0, 0, w_, h_), 1, border_radius=h_ // 2)
            screen.blit(pl, (int(cx - w_ / 2), int(y - 1)))
        text(txt, cx, y, col, font, True, center=True)

    def _qmark_glyph(self, cx, cy, big=False, col=(255, 214, 70)):
        """A gold '?' badge."""
        rr = 11 if big else 8
        pygame.draw.circle(screen, (30, 22, 6), (int(cx), int(cy)), rr + 2)
        pygame.draw.circle(screen, col, (int(cx), int(cy)), rr)
        text("?", int(cx), int(cy) - (9 if big else 7), (60, 36, 4), F_BD if big else F_SM, center=True)

    def _draw_qmarks_map(self, TX, TY, scl, x0, y0, mw, mh, zoom):
        tip = None; mx, my = self.mouse
        # 0.46.2: the areas first (soft gold circles round the monsters' dens, the dungeon, or the whole zone), then the ? badges on top
        marks_ = self.snap.get("quest_marks", [])
        if marks_:
            lay = pygame.Surface((mw, mh), pygame.SRCALPHA); pulse = .75 + .25 * math.sin(self.t * 2.2)
            for m in marks_:
                if m["k"] == "turn": continue
                for x, y, r_ in m.get("circles", []):
                    c_ = (int(TX(x) - x0), int(TY(y) - y0)); rr_ = max(6, int(r_ * scl))
                    pygame.draw.circle(lay, (255, 205, 60, int(80 * pulse)), c_, rr_); pygame.draw.circle(lay, (255, 225, 110, int(230 * pulse)), c_, rr_, 3)
                if m.get("rect"):
                    rx, ry, rw_, rh_ = m["rect"]
                    rc_ = pygame.Rect(int(TX(rx) - x0), int(TY(ry) - y0), max(2, int(rw_ * scl)), max(2, int(rh_ * scl)))
                    pygame.draw.rect(lay, (255, 205, 60, 28), rc_); pygame.draw.rect(lay, (255, 225, 110, int(200 * pulse)), rc_, 3)
            screen.blit(lay, (x0, y0))
        for m in marks_:
            cx, cy = TX(m["x"]), TY(m["y"])
            if not (x0 - 80 < cx < x0 + mw + 80 and y0 - 80 < cy < y0 + mh + 80): continue
            if m["k"] == "turn":
                self._qmark_glyph(cx, cy - 18, True, (120, 235, 130))
            else:
                rad = 12      # 0.44.13: just the ? - no glowing circle, no monster dots
                self._qmark_glyph(cx, cy, zoom)
                if zoom: self._map_plate(m["label"], cx, cy + rad + 4, (255, 236, 160), F_SM, bg=(30, 22, 6, 190), edge=(255, 214, 70, 200), pill=True)
                elif m["k"] == "zone": self._map_plate(m.get("zone", ""), cx, cy + rad + 4, (255, 236, 160), F_SM, bg=(30, 22, 6, 170), edge=(255, 214, 70, 180), pill=True)
            if abs(mx - cx) < 14 and abs(my - (cy - (18 if m["k"] == "turn" else 0))) < 14:
                tip = [("Quest", (255, 214, 70), F_BD), (m["label"], (230, 230, 230), F_SM)] + ([(f"Can be done anywhere in {m['zone']}", (255, 236, 160), F_SM)] if m["k"] == "zone" and m.get("zone") else [(f"Gold area: where it can be done ({m['zone']})", (255, 236, 160), F_SM)] if m.get("zone") else [])
        return tip

    def draw_map(self):
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 190)); screen.blit(ov, (0, 0))
        MG = self.MG; big = self._big_map()
        TWd, THd = W + 2 * MG, WORLD_H + 2 * MG
        panel, view = self._map_rects()
        frame_panel(panel)
        if self.map_drag and not pygame.mouse.get_pressed()[0]: self.map_drag = None
        mv = self.map_view
        zoom = mv is not None
        p = self.w.player
        fit = self._map_fit(view)
        if zoom:
            scl = mv[2]
            vw, vh = min(TWd, view.width / scl), min(THd, view.height / scl)
            ox = max(0, min(TWd - vw, mv[0] - vw / 2)); oy = max(0, min(THd - vh, mv[1] - vh / 2))
        else:
            scl = fit; ox = oy = self.MG - self.MAPC
            vw, vh = W + 2 * self.MAPC, WORLD_H + 2 * self.MAPC
        # snap the window to whole source pixels so the picture and the markers stay lined up
        ix, iy = int(ox * 3), int(oy * 3)
        sw, sh = min(big.get_width() - ix, int(vw * 3)), min(big.get_height() - iy, int(vh * 3))
        ox, oy, vw, vh = ix / 3, iy / 3, sw / 3, sh / 3
        mw, mh = max(1, int(vw * scl)), max(1, int(vh * scl))
        x0 = view.x + (view.width - mw) // 2; y0 = view.y + (view.height - mh) // 2
        self.map_geo = (x0, y0, scl, ox, oy, view, mw, mh)
        fast = pygame.time.get_ticks() - self.map_t < 140          # cheap scaling while dragging / wheeling, smooth once it settles
        key = (ix, iy, sw, sh, mw, mh, fast)
        cache = self._map_cache
        if not cache or cache[0] != key:
            sub = big.subsurface((ix, iy, sw, sh))
            img = pygame.transform.scale(sub, (mw, mh)) if fast else pygame.transform.smoothscale(sub, (mw, mh))
            self._map_cache = cache = (key, img)
        screen.blit(cache[1], (x0, y0))
        pygame.draw.rect(screen, (24, 18, 12), (x0 - 1, y0 - 1, mw + 2, mh + 2), 2)
        def TX(x): return x0 + (x + MG - ox) * scl
        def TY(y): return y0 + (y + MG - oy) * scl
        clip = screen.get_clip(); screen.set_clip(pygame.Rect(x0, y0, mw, mh))
        text("WORLD MAP" if not zoom else "YOUR SURROUNDINGS", panel.centerx, panel.y + 10, PARCH, F_TI, center=True)
        lv = self.snap["player"].get("level", 1)
        rz = scl / max(1e-6, fit)                      # 0.44.18: how far in we are; names appear by rank so the world view stays readable
        def _show(t):
            tr = self.w.town_tier(t)
            return tr == "capital" or (tr == "city" and rz >= 2.4) or rz >= 4.2
        # label layout: town plates and icons are reserved first, then each zone name goes to the free spot nearest its middle (no overlaps)
        used = []
        for t in self.w.towns:
            if not _show(t): continue
            tx_, ty_ = TX(t.x), TY(t.y)
            tier_ = self.w.town_tier(t)
            f_ = F_BD if (zoom or tier_ == "capital") else F_SM
            wl = f_.size(t.name)[0] + 12; hl = f_.get_height() + 2
            used.append(pygame.Rect(int(tx_ - wl / 2), int(ty_ + 12 * scl / 3 + 3), wl, hl))
            used.append(pygame.Rect(int(tx_ - 12), int(ty_ - 14), 24, 28))
        for d in self.w.dungeons: used.append(pygame.Rect(int(TX(d.x) - 8), int(TY(d.y) - 8), 16, 16))
        for a in AREAS:
            ax, ay = TX(a[1] + a[3] / 2), TY(a[2] + a[4] / 2)
            if not (x0 - 60 < ax < x0 + mw + 60 and y0 - 30 < ay < y0 + mh + 30): continue
            col = (150, 235, 150) if a[7] < lv - 4 else (255, 232, 130) if a[6] <= lv + 2 else (255, 130, 110)
            nf = F_BD if not zoom else F_TI
            ntxt = a[0].upper(); ltxt = f"Lv {a[6]}-{a[7]}"
            if not zoom or rz < 3: ntxt = f"{ntxt}  {ltxt}"; ltxt = ""
            nw = nf.size(ntxt)[0] + 12; lw2 = (F_SM.size(ltxt)[0] + 12) if ltxt else 0
            bw = max(nw, lw2); bh = nf.get_height() + (F_SM.get_height() + 4 if ltxt else 2)
            zw, zh = a[3] * scl, a[4] * scl
            cands = sorted(((i_ / 10, j_ / 10) for i_ in range(-4, 5) for j_ in range(-4, 5)), key=lambda c: c[0] ** 2 + c[1] ** 2)
            best = None; bestov = 1e18
            for fx, fy in cands:
                cx2, cy2 = ax + fx * zw, ay + fy * zh
                r_ = pygame.Rect(int(cx2 - bw / 2), int(cy2 - 23), bw, bh)
                if not pygame.Rect(x0, y0, mw, mh).contains(r_): continue
                ov_ = sum(max(0, min(r_.right, u.right) - max(r_.x, u.x)) * max(0, min(r_.bottom, u.bottom) - max(r_.y, u.y)) for u in used)
                if ov_ == 0: best = (cx2, cy2, r_); break
                if ov_ < bestov: bestov = ov_; best = (cx2, cy2, r_)
            if best is None: best = (ax, ay, pygame.Rect(int(ax - bw / 2), int(ay - 23), bw, bh))
            cx2, cy2, r_ = best; used.append(r_.inflate(4, 4))
            self._map_plate(ntxt, cx2, cy2 - 22, (255, 244, 214), nf)
            if ltxt: self._map_plate(ltxt, cx2, cy2 + 10, col, F_SM)
        hov = self._map_zone_at(self.mouse) if view.collidepoint(self.mouse) and self.map_drag is None else None
        for a, wd, colr in ((hov, 1, (255, 232, 130)), (self._map_zone_named(self.map_sel), 2, (255, 255, 255))):
            if a is not None:
                pygame.draw.rect(screen, colr, (int(TX(a[1])), int(TY(a[2])), int(a[3] * scl), int(a[4] * scl)), wd)
        if self.map_sel and self._map_zone_named(self.map_sel) is not None:
            sa = self._map_zone_named(self.map_sel)
            text(f"{sa[0]}  \u2022  Level {sa[6]}-{sa[7]}  \u2022  double-click again to zoom back out", x0 + 12, y0 + 10, (255, 244, 214), F_BD, True)
        for t in self.w.towns:
            tx_, ty_ = TX(t.x), TY(t.y)
            if x0 < tx_ < x0 + mw and y0 < ty_ < y0 + mh and _show(t):
                tier_ = self.w.town_tier(t)
                self._map_plate(t.name, tx_, ty_ + 12 * scl / 3 + 4, (255, 232, 150) if tier_ == "capital" else (246, 240, 226), F_BD if (zoom or tier_ == "capital") else F_SM)
        mx, my = self.mouse; tip = None
        for t in self.w.towns:
            tx_, ty_ = TX(t.x), TY(t.y)
            if abs(mx - tx_) < 10 and abs(my - ty_) < 10:
                try: ruler = self.w.ruler_for(t)[0]
                except Exception: ruler = "?"
                tier = self.w.town_tier(t)
                tip = [(t.name, (255, 226, 130), F_BD), (f"{tier.title()} - {getattr(t, 'faction', '')}", (220, 220, 225), F_SM), (f"Ruler: {ruler}", GREY, F_SM)]
        for d in self.w.dungeons:
            dx_, dy_ = TX(d.x), TY(d.y)
            if abs(mx - dx_) < 9 and abs(my - dy_) < 9:
                tip = [(d.name, (255, 180, 100) if d.kind in ("raid", "heroic") else (200, 160, 255), F_BD),
                       (f"{d.kind.title()} \u2022 {d.size} players \u2022 Lv {d.level}", (220, 220, 225), F_SM), (f"Boss: {d.boss}", GREY, F_SM)]
        qtip = self._draw_qmarks_map(TX, TY, scl, x0, y0, mw, mh, zoom)
        if qtip: tip = qtip
        # your position: pulsing beacon, arrow and label
        px, py = TX(p["x"]), TY(p["y"])
        pulse = 8 + int(math.sin(self.t * 5) * 3)
        screen.blit(gfx.glow(26, (30, 70, 140)), (px - 26, py - 26), special_flags=pygame.BLEND_RGB_ADD)
        pygame.draw.circle(screen, (255, 255, 255), (int(px), int(py)), pulse, 2)
        pygame.draw.circle(screen, (20, 40, 90), (int(px), int(py)), 6); pygame.draw.circle(screen, (90, 170, 255), (int(px), int(py)), 4)
        lab = f"You  ({int(p['x'])}, {int(p['y'])})"
        lw_ = F_BD.size(lab)[0] + 12
        lr = pygame.Rect(int(px - lw_ / 2), int(py - 38), lw_, 20)
        pygame.draw.rect(screen, (10, 18, 40), lr, border_radius=6); pygame.draw.rect(screen, (110, 180, 255), lr, 1, border_radius=6)
        text(lab, lr.centerx, lr.y + 2, (200, 230, 255), F_BD, center=True)
        screen.set_clip(clip)
        # compass rose (isometric north is the top corner of the world)
        cx_, cy_ = x0 + mw - 44, y0 + mh - 44
        pygame.draw.circle(screen, (24, 18, 12), (cx_, cy_), 26); pygame.draw.circle(screen, GOLD, (cx_, cy_), 26, 1)
        for ang_ in (45, 135, 225, 315):
            aa_ = math.radians(ang_); pygame.draw.polygon(screen, (150, 128, 84), [(cx_ + math.cos(aa_) * 17, cy_ + math.sin(aa_) * 17), (cx_ + math.cos(aa_ + 1.57) * 4, cy_ + math.sin(aa_ + 1.57) * 4), (cx_ + math.cos(aa_ - 1.57) * 4, cy_ + math.sin(aa_ - 1.57) * 4)])
        pygame.draw.polygon(screen, (230, 70, 60), [(cx_, cy_ - 23), (cx_ + 5, cy_), (cx_ - 5, cy_)])
        pygame.draw.polygon(screen, (255, 140, 120), [(cx_, cy_ - 23), (cx_, cy_), (cx_ - 5, cy_)])
        pygame.draw.polygon(screen, (226, 220, 200), [(cx_, cy_ + 23), (cx_ + 5, cy_), (cx_ - 5, cy_)])
        pygame.draw.circle(screen, GOLD, (cx_, cy_), 3)
        text("N", cx_, cy_ - 40, PARCH, F_SM, True, center=True)
        self.ui_rects = {"close": button((panel.right - 100, panel.y + 10, 84, 28), "Close"),
                         "mapzoom": button((panel.right - 330, panel.y + 10, 220, 28), "Whole world (Tab)" if zoom else "Zoom to my location (Tab)", True, accent=True)}
        area = self.snap.get("area", "")
        text(f"You are in {area}", panel.x + 20, panel.y + 16, (180, 220, 255), F_BD)
        text("Double-click a zone to open it  \u2022  Wheel: zoom  \u2022  Drag: scroll  \u2022  Arrows: scroll  \u2022  Tab: me / world  \u2022  0: whole world  \u2022  Zoom in for more towns  \u2022  Gem: dungeon / raid (orange = raid, red = heroic)  \u2022  M or Esc: close", panel.centerx, panel.bottom - 24, GREY, F_SM, center=True)
        if tip: self.draw_tooltip(tip)

    def draw_inventory(self):
        snap = self.snap; p = snap["player"]; mx, my = self.mouse
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 150)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 440, 70, 880, 600), alpha=240)
        text("CHARACTER & BAG", r.x + 20, r.y + 14, PARCH, F_TI)
        self.ui_rects["close"] = button((r.right - 100, r.y + 14, 84, 28), "Close")
        tab = getattr(self, "inv_tab", "bag")
        inv = snap["inventory"]; self.equip_rects = []; self.inv_rects = []; hov_item = None
        if tab == "bag":      # 0.46.11: only the Bag tab shows the character and its gear slots; Gear and Mats show just their own list
            # paperdoll
            doll = pygame.Rect(r.x + 20, r.y + 56, 360, 420)
            pygame.draw.rect(screen, (26, 22, 26), doll, border_radius=8)
            pg = pygame.Surface(doll.size, pygame.SRCALPHA)
            for k in range(8):
                pygame.draw.ellipse(pg, (150, 120, 70, 9), (doll.w // 2 - 170 + k * 14, 40 + k * 10, 340 - k * 28, 340 - k * 20))
            pygame.draw.ellipse(pg, (0, 0, 0, 90), (doll.w // 2 - 70, 322, 140, 26))
            screen.blit(pg, doll.topleft)
            pygame.draw.rect(screen, (90, 74, 52), doll, 1, border_radius=8)
            cls = p.get("class", "Warrior")
            spec = self.player_spec()[1]
            spr, anc = gfx.character_sprite(("doll", cls, p.get("faction"), spec.get("tierlvl"), spec.get("helmlvl"), spec.get("setl"), spec.get("setp")), "human", spec, -1, 1, False, 3.0)
            screen.blit(spr, (doll.centerx - anc[0], doll.y + 330 - anc[1]))
            text(f"{p['name']} — Level {p['level']} {cls}", doll.centerx, doll.bottom - 54, PARCH, F_BD, center=True)
            sb = snap.get("set_bonus")
            sbt = sb["text"] if sb else "No set bonus active"
            while F_SM.size(sbt)[0] > doll.width - 16 and len(sbt) > 8: sbt = sbt[:-2].rstrip(" —+,") + "…" if not sbt.endswith("…") else sbt[:-2] + "…"
            text(sbt, doll.centerx, doll.bottom - 34, (60, 220, 200) if sb else GREY, F_SM, center=True)
            text(f"Weapon power {p['weapon']}  •  Armor {p['armor']}", doll.centerx, doll.bottom - 18, (220, 220, 220), F_SM, center=True)
            slots = (("weapon", doll.x + 14, doll.y + 40, 0), ("armor", doll.x + 14, doll.y + 140, 0), ("helm", doll.right - 78, doll.y + 40, 0),
                     ("trinket", doll.right - 78, doll.y + 140, 0), ("ring", doll.x + 14, doll.y + 240, 0), ("ring", doll.right - 78, doll.y + 240, 1))
            rings_ = sorted((i for i in inv if i["slot"] == "ring" and i["equipped"]), key=lambda i: i["id"])
            for slot, sx, sy, n_ in slots:
                rr = pygame.Rect(sx, sy, 64, 64)
                eq = (rings_[n_] if n_ < len(rings_) else None) if slot == "ring" else next((i for i in inv if i["slot"] == slot and i["equipped"]), None)
                if eq:
                    screen.blit(gfx.item_icon(slot, eq["rarity"], 64), rr)
                else:
                    empty_slot(rr, True)
                text(SLOT_LABEL.get(slot, slot.title()) + (f" {n_ + 1}" if slot == "ring" else ""), rr.centerx, rr.bottom + 2, GREY, F_SM, center=True)
                self.equip_rects.append((rr, slot))
                if rr.collidepoint(mx, my) and eq: hov_item = eq
        for i_, (k_, lab_) in enumerate((("bag", "Bag"), ("gear", "Gear"), ("mats", "Mats"))):      # 0.45: three tabs side by side (Mats sat on top of Bag)
            self.ui_rects["itab_" + k_] = button((r.x + 300 + i_ * 96, r.y + 14, 92, 28), lab_, True, tab == k_)
        if tab != "bag":
            self.draw_inv_side(r, tab, inv, p, snap)
            if hov_item and not self.drag: self.draw_tooltip(self._inv_item_lines(hov_item))
            return
        # bag grid
        bag = [i for i in inv if not i["equipped"]]
        gx, gy = r.x + 400, r.y + 56; cols = 7; size = 60
        text(f"Bag ({len(bag)} items) — click or drag to equip • wheel to scroll", gx, gy - 4, GREY, F_SM)
        self.inv_rects = []
        rows = 7; self.inv_scroll = max(0, min(self.inv_scroll, (len(bag) + cols - 1) // cols - rows)); start = self.inv_scroll * cols
        for k, it in enumerate(bag[start:start + cols * rows]):
            rr = pygame.Rect(gx + (k % cols) * (size + 4), gy + 16 + (k // cols) * (size + 4), size, size)
            if self.drag and self.drag["id"] == it["id"]:
                pygame.draw.rect(screen, (40, 36, 40), rr, border_radius=8); continue
            screen.blit(gfx.item_icon(it["slot"], it["rarity"], size), rr)
            if it.get("class") and it["class"] != p.get("class"):
                s = pygame.Surface((size, size), pygame.SRCALPHA); s.fill((160, 20, 20, 90)); screen.blit(s, rr)
            if it.get("usable") is False:
                s_ = pygame.Surface((size, size), pygame.SRCALPHA); s_.fill((170, 20, 20, 110)); screen.blit(s_, rr)
            text(it["power"], rr.right - 4, rr.bottom - 15, (255, 255, 255), F_PL, True, right=True)
            self.inv_rects.append((rr, it))
            if rr.collidepoint(mx, my): hov_item = it
        for k in range(len(bag[start:start + cols * rows]), cols * rows):
            rr = pygame.Rect(gx + (k % cols) * (size + 4), gy + 16 + (k // cols) * (size + 4), size, size)
            empty_slot(rr)
        c = snap["currency"]
        text(f"Gold {p['gold']:,}   •   Potions {snap['potions']}   •   PvP {c['pvp_points']}   •   Raid tokens {c['raid_tokens']}   •   Essence {c['legendary_essence']}", r.x + 20, r.bottom - 30, (255, 215, 80), F_SM)
        if self.drag:
            it = self.drag["item"]
            screen.blit(gfx.item_icon(it["slot"], it["rarity"], 60), (mx - 30, my - 30))
        elif hov_item:
            self.draw_tooltip(self._inv_item_lines(hov_item))

    def draw_inv_side(self, r, tab, inv, p, snap):
        mx, my = self.mouse
        gx, gy = r.x + 20, r.y + 56
        area = pygame.Rect(gx, gy, r.right - gx - 20, 480)
        pygame.draw.rect(screen, (26, 22, 26), area, border_radius=8); pygame.draw.rect(screen, (90, 74, 52), area, 1, border_radius=8)
        y = area.y + 10
        if tab == "gear":
            text("EQUIPPED GEAR", area.x + 12, y, GOLD, F_BD); y += 24
            order = ("weapon", "armor", "helm", "trinket", "ring")
            rings = sorted((i for i in inv if i["slot"] == "ring" and i["equipped"]), key=lambda i: i["id"])
            rows = []
            for sl in order:
                if sl == "ring":
                    for n_ in range(2): rows.append(("Ring %d" % (n_ + 1), rings[n_] if n_ < len(rings) else None))
                else:
                    rows.append((SLOT_LABEL.get(sl, sl.title()), next((i for i in inv if i["slot"] == sl and i["equipped"]), None)))
            for lab, it in rows:
                rr = pygame.Rect(area.x + 8, y, area.width - 16, 50)
                pygame.draw.rect(screen, (34, 30, 34), rr, border_radius=6)
                text(lab, rr.x + 8, rr.y + 4, GREY, F_SM)
                if it and rr.collidepoint(mx, my): self.tooltip = self._inv_item_lines(it)
                if it:
                    col = RARITY_COLOR.get(it["rarity"], PARCH)
                    nm = it["item"]
                    while F_BD.size(nm)[0] > rr.width - 150 and len(nm) > 8: nm = nm[:-2] + "\u2026"
                    text(nm, rr.x + 70, rr.y + 4, col, F_BD)
                    text(f"Power {it['power']}", rr.right - 8, rr.y + 4, (255, 255, 255), F_BD, right=True)
                    bits = []
                    if it.get("bonus"): bits.append(it["bonus"])
                    if it.get("sockets"):
                        gl_ = it.get("gems", []); bits.append(f"sockets {len(gl_)}/{it['sockets']}")
                    if it.get("set_name"): bits.append(it["set_name"])
                    ln = "  \u2022  ".join(bits) or it["rarity"]
                    while F_SM.size(ln)[0] > rr.width - 80 and len(ln) > 8: ln = ln[:-2] + "\u2026"
                    text(ln, rr.x + 70, rr.y + 28, (120, 230, 255) if bits else GREY, F_SM)
                else:
                    text("empty", rr.x + 70, rr.y + 14, (110, 110, 115), F_BD)
                y += 54
            g = (snap.get("build") or {}).get("g", {})
            tot = [f"Weapon power {p['weapon']}", f"Armor {p['armor']}"]
            for k_, lab_ in (("str", "Str"), ("agi", "Agi"), ("int", "Int"), ("vit", "Vit")):
                if g.get(k_): tot.append(f"+{int(g[k_])} {lab_}")
            for k_, lab_ in (("crit", "crit"), ("dodge", "dodge"), ("armor_pct", "less damage"), ("mana_regen", "mana regen"), ("hp_pct", "max health")):
                if g.get(k_): tot.append(f"+{g[k_] * 100:.1f}% {lab_}")
            text("Gear totals: " + "   ".join(tot), area.x + 12, area.bottom - 22, (255, 230, 150), F_SM)
        else:
            text("MATERIALS", area.x + 12, y, GOLD, F_BD); y += 22
            info = {"Cloth Scrap": "humanoid monsters, General Store, Weave Cloth at an inn", "Leather Scrap": "skin beast carcasses (F), General Store",
                    "Iron Ore": "mine ore veins (F), humanoids, General Store", "Arcane Dust": "undead and magical monsters, General Store",
                    "Spirit Essence": "elite monsters and raids only"}
            mats = snap.get("mats", {})
            for nm, q in mats.items():
                text(f"{nm}", area.x + 14, y, PARCH, F_BD); text(f"{q}", area.x + 150, y, (255, 230, 150), F_BD)
                text(info.get(nm, ""), area.x + 190, y + 2, GREY, F_SM); y += 22
            y += 6
            text("BREWS - click to drink (or press Y)", area.x + 12, y, GOLD, F_BD); y += 22
            from .brews import BY_NAME
            br = snap.get("brews", {})
            if not br: text("None yet. Brew elixirs at an Inn or Fishing Hut from a zone's herb and fish.", area.x + 14, y, GREY, F_SM)
            for nm, q in list(br.items())[:12]:
                b = BY_NAME.get(nm)
                rr = pygame.Rect(area.x + 8, y, area.width - 16, 24)
                hot = rr.collidepoint(mx, my)
                pygame.draw.rect(screen, (52, 44, 38) if hot else (34, 30, 34), rr, border_radius=5)
                text(f"{nm}  x{q}", rr.x + 8, rr.y + 4, PARCH, F_SM)
                if b:
                    ln = b["desc"]
                    while F_SM.size(ln)[0] > rr.width - 280 and len(ln) > 8: ln = ln[:-2] + "\u2026"
                    text(ln, rr.x + 250, rr.y + 4, GREY, F_SM)
                self.ui_rects["brew_" + nm] = rr
                y += 26

    def draw_class_window(self):
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 150)); screen.blit(ov, (0, 0))
        r = frame_panel((LW // 2 - 520, 50, 1040, 680), alpha=240)
        text("CHOOSE YOUR CLASS", r.x + 20, r.y + 14, PARCH, F_TI)
        text("Switching class changes your skills and which set gear you can wear. Level and items are kept. Paladin, Shaman and Druid pick a role in the Skills window (K).", r.x + 20, r.y + 44, GREY, F_SM)
        self.ui_rects = {"close": button((r.right - 100, r.y + 14, 84, 28), "Close")}
        self.class_cards = self._class_cards(r.x + 20, r.y + 70, self.w.class_name(), self.snap["player"].get("faction"))
    def _class_cards(self, x0, y0, selected, faction):
        cards = []; mx, my = self.mouse
        for i, c in enumerate(CLASSES):
            cols = 6; cw = 162; ch = 292
            rr = pygame.Rect(x0 + (i % cols) * (cw + 6), y0 + (i // cols) * (ch + 6), cw, ch)
            sel = c == selected; hot = rr.collidepoint(mx, my)
            pygame.draw.rect(screen, (46, 38, 32) if sel else (34, 30, 32) if not hot else (42, 36, 34), rr, border_radius=8)
            pygame.draw.rect(screen, GOLD if sel else (90, 74, 52), rr, 2 if sel else 1, border_radius=8)
            spec = dict(gfx.CLASS_SPEC[c]); spec["cape"] = gfx.FACTION_CAPE.get(faction)
            fr = int(self.t * 8) % 4 if (sel or hot) else -1
            spr, anc = gfx.character_sprite(("cc", c, faction), "human", spec, fr, 1, (sel and int(self.t * 1.5) % 3 == 2), 1.8)
            g = gfx.glow(62, (40, 32, 14) if sel else (20, 18, 16))
            screen.blit(g, (rr.centerx - 62, rr.y + 98 - 62), special_flags=pygame.BLEND_RGB_ADD)
            clip = screen.get_clip(); screen.set_clip(rr.inflate(-4, -4))
            screen.blit(spr, (rr.centerx - anc[0], rr.y + 160 - anc[1]))
            screen.set_clip(clip)
            text(c, rr.centerx, rr.y + 162, GOLD if sel else PARCH, F_TI, center=True)
            roles = "Tank • Healer • DPS" if c in SPECS else CLASS_ROLE.get(c, "DPS")
            text(roles, rr.centerx, rr.y + 190, (150, 210, 255) if c in SPECS else ROLE_COL["Tank"] if roles == "Tank" else GREY, F_PL, center=True)
            words = CLASS_INFO[c].split(); line = ""; yy = rr.y + 208
            for wd in words:
                if F_SM.size(line + " " + wd)[0] > rr.width - 20:
                    text(line, rr.x + 10, yy, (210, 210, 210), F_SM); yy += 15; line = wd
                else:
                    line = (line + " " + wd).strip()
            text(line, rr.x + 10, yy, (210, 210, 210), F_SM)
            cards.append((rr, c))
        return cards
    def draw_create(self):
        ov = pygame.Surface((LW, LH), pygame.SRCALPHA); ov.fill((0, 0, 0, 165)); screen.blit(ov, (0, 0))
        text("LIVEWORLD RPG", LW // 2, 6, (255, 220, 130), F_BIG, True, center=True)
        r = frame_panel((LW // 2 - 520, 62, 1040, 732), alpha=235)
        mx, my = self.mouse
        text("Name", r.x + 24, r.y + 12, GOLD, F_BD)
        nb = pygame.Rect(r.x + 24, r.y + 32, 260, 32)
        pygame.draw.rect(screen, (20, 18, 22), nb, border_radius=5); pygame.draw.rect(screen, GOLD, nb, 1, border_radius=5)
        cursor = "|" if int(self.t * 2) % 2 == 0 else ""
        text((self.cc_name or "") + cursor, nb.x + 10, nb.y + 7, PARCH, F_MD)
        if not self.cc_name: text("type a name…", nb.x + 16, nb.y + 7, (100, 100, 105), F_MD)
        text("Faction", r.x + 310, r.y + 12, GOLD, F_BD)
        self.ui_rects = {}
        for i, f in enumerate(("Alliance", "Horde")):
            rr = pygame.Rect(r.x + 310 + i * 130, r.y + 32, 122, 32)
            sel = self.cc_faction == f
            col = (52, 92, 196) if f == "Alliance" else (178, 40, 36)
            pygame.draw.rect(screen, col if sel else shade(col, .35), rr, border_radius=5)
            pygame.draw.rect(screen, GOLD if sel else (90, 74, 52), rr, 2 if sel else 1, border_radius=5)
            text(f, rr.centerx, rr.y + 7, (255, 255, 255), F_BD, center=True)
            self.ui_rects["fac_" + f] = rr
        specs = SPECS.get(self.cc_class)
        if specs:
            if self.cc_spec not in [n for n, _ in specs]: self.cc_spec = specs[2][0]
            text("Role", r.x + 590, r.y + 12, GOLD, F_BD)
            for i, (n, role) in enumerate(specs):
                rr = pygame.Rect(r.x + 590 + i * 140, r.y + 32, 134, 32)
                sel = n == self.cc_spec
                pygame.draw.rect(screen, ROLE_COL[role] if sel else shade(ROLE_COL[role], .35), rr, border_radius=5)
                pygame.draw.rect(screen, GOLD if sel else (90, 74, 52), rr, 2 if sel else 1, border_radius=5)
                text(f"{n} ({role})", rr.centerx, rr.y + 8, (255, 255, 255), F_PL, center=True)
                self.ui_rects["spec_" + n] = rr
        else:
            start = "Greenfields (Oakwatch)" if self.cc_faction == "Alliance" else "Ashen Vale (Ashgate)"
            text(f"Starting zone: {start}", r.x + 590, r.y + 40, GREY, F_SM)
        self.class_cards = self._class_cards(r.x + 20, r.y + 76, self.cc_class, self.cc_faction)
        eb = pygame.Rect(LW // 2 - 110, r.bottom - 50, 220, 40)
        self.ui_rects["enter"] = button(eb, "Enter World", True, True, eb.collidepoint(mx, my))
    def click_world(self, pos, button_no):
        p = self.w.player
        # loot first (small targets)
        for rr, l in reversed(self.loot_rects):
            if rr.collidepoint(pos):
                self.pending = ("pickup", l["id"], l["x"], l["y"]); self.auto = False; return
        for rr, (ptx, pty) in self.portal_rects:
            if rr.collidepoint(pos):
                self.pending = ("leave", None, ptx, pty); self.auto = False; return
        hit = None
        for rr, obj in reversed(self.hit_rects):
            if rr.collidepoint(pos):
                hit = obj; break
        if hit and hit[0] == "actor":
            a = hit[1]
            if is_enemy(a, p):
                self.auto = True
                self.target = a["id"]; self.w.selected_target = a["id"]; self.pending = None; self.dest = None
                return
            self.target = a["id"]; self.w.selected_target = a["id"]
            if a["kind"] in ("npc", "adventurer"):
                self.pending = ("talk", a["id"]); self.auto = False
            return
        if hit and hit[0] == "station":
            self.pending = ("station", hit[1], hit[2], hit[3]); self.auto = False; self.dest = None; return
        if hit and hit[0] == "portal":
            d = hit[1]; self.pending = ("portal", d, d.x, d.y); self.auto = False; return
        if hit and hit[0] == "node":
            o = hit[1]; self.pending = ("gather", o["id"], o["x"], o["y"]); self.auto = False; self.dest = None; return
        wx, wy = self.to_world(pos)
        self.dest = (clamp(wx, 0, W - .01), clamp(wy, 0, H - .01)); self.click_fx = (wx, wy, self.t)
        self.auto = False; self.pending = None

    def leave_or_portal(self):
        w = self.w
        if w.inst and w.inst.near_portal(): self.msg(w.leave_instance(), (190, 160, 255))
        else: self.msg(w.open_exit_portal(), (190, 160, 255))

    def hot(self, key):
        if key != "close": self.audio.play("click", .08)
        if key.startswith("ab"): self.cast(key[2:])
        elif key == "skills": self.mode = "skills"
        elif key == "stats": self.mode = "stats"
        elif key == "potion": self.msg(self.w.use_potion(), (120, 255, 140))
        elif key == "mana": self.msg(self.w.use_mana_potion(), (120, 170, 255))
        elif key == "scroll": self.msg(self.w.use_scroll(), (200, 160, 255))
        elif key == "loot": self.msg(self.w.pickup_loot())
        elif key == "bag": self.mode = "inventory"; self.inv_tab = "bag"
        elif key == "geartab": self.mode = "inventory"; self.inv_tab = "gear"
        elif key == "matstab": self.mode = "inventory"; self.inv_tab = "mats"
        elif key == "partyw": self.mode = "party"
        elif key == "raidjoin": self.msg(self.w.join_city_raid(), (255, 220, 120))
        elif key == "class": self.mode = "class"
        elif key == "chat":
            self.chat_open = not self.chat_open
            try: st = load_settings(); st["chat_open"] = self.chat_open; save_settings(st)
            except Exception: pass
        elif key == "map" or key == "minimap":
            self.mode = "map"; self.map_drag = None; self._map_cache = None; self.map_sel = None; self.map_geo = None
            if key == "minimap": self.map_center_player()
            else: self.map_open_default()
        elif key == "quest": self.mode = "world" if self.mode == "quest" else "quest"; self.qlog_tab = "log"
        elif key == "food": self.msg(self.w.eat_food(), (255, 220, 150))
        elif key == "buffscroll": self.msg(self.w.use_buff_scroll(), (200, 160, 255))
        elif key == "settings": self.mode = "world" if self.mode == "settings" else "settings"
        elif key == "guide": self.mode = "world" if self.mode == "guide" else "guide"
        elif key == "fullscreen": self.toggle_fullscreen()
        elif key == "minimize": self.minimize()
        elif key == "leave": self.leave_or_portal()
        elif key == "ready": self.msg(self.w.instance_ready(), (190, 230, 255))
        elif key == "fish":
            r_ = self.w.fish_action(); self.msg(r_, (200, 230, 255))
            if r_: self.fish_note = (str(r_), self.t)      # 0.46.11: the answer to G shows on screen, not only in the (collapsed) chat
        elif key == "pvp": self.mode = "world" if self.mode == "pvp" else "pvp"
        elif key == "duel_yes": self.msg(self.w.duel_respond(True), (255, 200, 140))
        elif key == "duel_no": self.msg(self.w.duel_respond(False), (220, 220, 220))
        elif key == "duel_yield": self.msg(self.w.yield_duel(), (220, 220, 220))

    def on_mouse_down(self, pos, btn):
        if self.mode == "create":
            if btn != 1: return
            for k, rr in self.ui_top():
                if rr.collidepoint(pos):
                    if k.startswith("fac_"): self.cc_faction = k[4:]
                    elif k.startswith("spec_"): self.cc_spec = k[5:]
                    elif k == "enter": self.finish_create()
                    return
            for rr, c in getattr(self, "class_cards", []):
                if rr.collidepoint(pos): self.cc_class = c
            return
        if self.mode == "class":
            if btn == 1:
                if self.ui_rects.get("close") and self.ui_rects["close"].collidepoint(pos): self.mode = "world"; return
                for rr, c in getattr(self, "class_cards", []):
                    if rr.collidepoint(pos):
                        self.msg(self.w.set_class(c), (255, 230, 120)); self.mode = "world"; return
            return
        if self.mode in ("settings", "guide", "quests", "craft", "quest", "person", "party"):
            self.window_click(pos, btn); return
        if self.mode == "map":
            if btn == 1:
                for k, rr in self.ui_top():
                    if rr.collidepoint(pos):
                        if k == "mapzoom":
                            if self.map_view is not None: self.map_view = None; self.map_sel = None
                            else: self.map_center_player()
                        elif k == "close": self.mode = "world"
                        return
            self.map_mouse_down(pos, btn)
            return
        if self.mode in ("pvp", "raids", "armory"):
            if btn == 1:
                for k, rr in self.ui_top():
                    if rr.collidepoint(pos):
                        if k == "close": self.mode = "world"
                        elif k == "wh_pvp": self.mode = "pvp"
                        elif k == "wh_raid": self.mode = "raids"
                        elif k == "wh_armory": self.mode = "armory"
                        elif k.startswith("armtab_"): self.arm_tab = k[7:]
                        elif k.startswith("armtier_"): self.arm_tier = k[8:]
                        elif k.startswith("ause_"): self.msg(self.w.set_active_mount(k[5:]), (255, 225, 130))
                        elif k.startswith("abuy_"): self.msg(self.w.armory_buy(k[5:]), (255, 225, 130))
                        elif k.startswith("aupg_"): self.msg(self.w.armory_upgrade(int(k[5:])), (255, 225, 130))
                        elif k == "callraid": self.msg(self.w.call_city_raid(), (255, 170, 90))
                        elif k == "raidjoin": self.msg(self.w.join_city_raid(), (255, 220, 120))
                        elif k == "raidleave": self.msg(self.w.leave_city_raid(), (255, 200, 140))
                        elif k == "raidoff": self.msg(self.w.call_off_city_raid(), (255, 200, 140))
                        elif k.startswith("arena_"):
                            r_ = self.w.enter_arena(k[6:]); self.msg(r_, (255, 150, 120))
                            if self.w.inst: self.mode = "world"
                            else: self.pvp_note = (r_, self.t)        # 0.40.5: a refused entry stays on screen in the menu instead of closing it
                        elif k == "quicksim": self.msg(self.w.queue_pvp(12), (255, 120, 120)); self.mode = "world"
                        elif k == "quicksim12": self.msg(self.w.queue_pvp(24), (255, 120, 120)); self.mode = "world"
                        return
            return
        if self.mode == "vault":
            if btn in (4, 5):
                d = -1 if btn == 4 else 1
                if pos[0] < LW // 2: self.vb_scroll = max(0, getattr(self, "vb_scroll", 0) + d)
                else: self.vv_scroll = max(0, getattr(self, "vv_scroll", 0) + d)
                return
            if btn == 1:
                for k, rr in self.ui_top():
                    if rr.collidepoint(pos):
                        if k == "close": self.mode = "world"
                        elif k.startswith("vg_"): self.msg(self.w.vault_gold(k[3:]), (255, 215, 80))
                        elif k.startswith("vs_"): self.msg(self.w.vault_store(int(k[3:])), (255, 225, 130))
                        elif k.startswith("vt_"): self.msg(self.w.vault_take(int(k[3:])), (255, 225, 130))
                        return
            return
        if self.mode == "magic":
            if btn == 1: self.magic_click(pos)
            return
        if self.mode == "kiln":
            if btn == 4: self.kiln_scroll = max(0, self.kiln_scroll - 1); return
            if btn == 5: self.kiln_scroll += 1; return
            if btn == 1: self.kiln_click(pos)
            return
        if self.mode == "stable":
            if btn == 1:
                for k, rr in self.ui_top():
                    if rr.collidepoint(pos):
                        if k == "close": self.mode = "world"
                        elif k.startswith("ride_"): self.msg(self.w.buy_riding(int(k[5:])), (255, 225, 130))
                        elif k.startswith("buy_"): self.msg(self.w.buy_mount(k[4:]), (255, 225, 130))
                        elif k.startswith("use_"): self.msg(self.w.set_active_mount(k[4:]), (255, 225, 130))
                        return
            return
        if self.mode == "market":
            if btn == 4: self.mk_scroll = max(0, self.mk_scroll - 1); return
            if btn == 5: self.mk_scroll += 1; return
            if btn == 1:
                for k, rr in self.ui_top():
                    if rr.collidepoint(pos):
                        if k == "close": self.mode = "world"
                        elif k.startswith("tab_"): self.mk_tab = k[4:]; self.mk_scroll = 0
                        elif k.startswith("do_"):
                            self.msg((self.w.market_buy if self.mk_tab == "buy" else self.w.market_sell)(k[3:]), (255, 225, 130))
                        return
            return
        if self.mode == "shop":
            if btn == 4: self.shop_scroll = max(0, getattr(self, "shop_scroll", 0) - 1); return
            if btn == 5: self.shop_scroll = getattr(self, "shop_scroll", 0) + 1; return
            if btn in (1, 3):
                for k, rr in self.ui_top():
                    if rr.collidepoint(pos):
                        if k == "close": self.mode = "world"
                        elif k == "tocraft": self.craft_station = "smith"; self.mode = "craft"; self.craft_tab = 0; self.craft_scroll = 0
                        elif k.startswith("stab_"): self.shop_tab = int(k[5:])
                        return
                for box, kind, row in getattr(self, "shop_cells", []):
                    if box.collidepoint(pos):
                        if kind == "buy": self.msg(self.w.shop_buy(self.shop_npc, row["key"]), (255, 225, 130))
                        else: self.msg(self.w.shop_sell(self.shop_npc, row["key"]), (255, 225, 130))
                        return
            return
        if self.mode == "skills":
            if btn != 1: return
            for k, rr in self.ui_top():
                if rr.collidepoint(pos):
                    if k == "close": self.mode = "world"
                    elif k.startswith("spec_"): self.msg(self.w.set_spec(k[5:]), (255, 230, 120))
                    elif k == "stats": self.mode = "stats"
                    return
            return
        if self.mode == "stats":
            if btn != 1: return
            for k, rr in self.ui_top():
                if rr.collidepoint(pos):
                    if k == "close": self.mode = "world"
                    elif k == "skills": self.mode = "skills"
                    return
            return
        if self.mode == "inventory":
            if btn == 4: self.inv_scroll = max(0, self.inv_scroll - 1); return
            if btn == 5: self.inv_scroll += 1; return
            if btn != 1: return
            if self.ui_rects.get("close") and self.ui_rects["close"].collidepoint(pos): self.mode = "world"; return
            for k_, rr_ in self.ui_top():
                if rr_.collidepoint(pos):
                    if k_.startswith("itab_"): self.inv_tab = k_[5:]; return
                    if k_.startswith("brew_"): self.msg(self.w.use_brew(k_[5:]), (200, 160, 255)); return
            for rr, it in (self.inv_rects if getattr(self, "inv_tab", "bag") == "bag" else []):
                if rr.collidepoint(pos):
                    self.drag = {"id": it["id"], "item": it, "start": pos}; return
            return
        # world
        if btn in (4, 5): return
        for k, rr in self.ui_top():
            if rr.collidepoint(pos):
                if btn == 1: self.hot(k)
                return
        if btn in (1, 3): self.click_world(pos, btn)       # clicks act on press (no delay)
        if btn == 1: self.look_drag = {"start": pos, "last": pos, "moved": False}      # 0.40.9: holding left and dragging scrolls the map

    def draw_gains(self):
        """0.45: a card for every fish you catch and every herb, ore or hide you gather - picture, name and count."""
        snap = self.snap
        seen = getattr(self, "_gain_seen", None)
        gl = snap.get("gains") or []
        if seen is None:                       # first frame: don't replay what was caught before the game opened
            self._gain_seen = max((g["seq"] for g in gl), default=0); self._gain_cards = []; return
        for g in gl:
            if g["seq"] > seen:
                self._gain_cards.append((g, self.t)); self._gain_seen = g["seq"]
                if g["item"].startswith("Fish:"): self.audio.play("loot", .12)
        self._gain_cards = [(g, t0) for g, t0 in self._gain_cards if self.t - t0 < 4.5][-4:]
        y = LH - 150
        for g, t0 in reversed(self._gain_cards):
            age = self.t - t0
            a = 1.0 if age < 3.6 else max(0.0, 1 - (age - 3.6) / .9)
            slide = int(max(0.0, .25 - age) / .25 * 60)
            item = g["item"]; kind, _, name = item.partition(":")
            if kind == "Gear": name = name.partition(":")[2]
            fish = kind == "Fish"
            ch = 92 if fish else 70; cw = 330
            r = pygame.Rect(LW - cw - 16 + slide, y - ch, cw, ch)
            card = pygame.Surface(r.size, pygame.SRCALPHA)
            col = {"Fish": (90, 170, 230), "Herb": (110, 210, 120)}.get(kind, (220, 180, 110))
            if kind == "Gear": col = RARITY_COLOR.get(name.split(" ")[0], col)
            pygame.draw.rect(card, (18, 16, 20, int(225 * a)), card.get_rect(), border_radius=10)
            pygame.draw.rect(card, (*col, int(255 * a)), card.get_rect(), 2, border_radius=10)
            try: ic = gfx.catch_icon(item, 64 if fish else 48)
            except Exception: ic = None
            tx = 14
            if ic is not None:
                ic = ic.copy(); ic.set_alpha(int(255 * a))
                card.blit(ic, (10, (ch - ic.get_height()) // 2)); tx = 10 + ic.get_width() + 10
            head = {"Fish": "You caught", "Herb": "You gathered"}.get(kind) or ("You picked up" if kind == "Gear" else "You mined" if ("Ore" in name or "Dust" in name) and g.get("note") and "cache" not in g["note"]
                                                                              else "You skinned" if "Leather" in name and g.get("note") else "You found")
            t1 = tsurf(head, (200, 200, 205), F_SM); t1.set_alpha(int(255 * a)); card.blit(t1, (tx, 10))
            t2 = tsurf(f"{name or item}" + (f"  x{g['n']}" if g["n"] > 1 else ""), col, F_TI if fish else F_BD, True); t2.set_alpha(int(255 * a))
            card.blit(t2, (tx, 26))
            if g.get("note"):
                t3 = tsurf(g["note"], (255, 215, 120), F_SM); t3.set_alpha(int(255 * a)); card.blit(t3, (tx, ch - 22))
            screen.blit(card, r.topleft)
            y -= ch + 8

    def ui_top(self):
        """0.45: buttons topmost-first.  Windows are drawn after the HUD, so their buttons win where they overlap it
        (the minimap's click area used to swallow clicks on a window's Close button)."""
        return list(reversed(list(self.ui_rects.items())))

    def window_click(self, pos, btn):
        """Clicks inside the 0.24 windows."""
        m = self.mode
        if m in ("guide", "craft") and btn in (4, 5):
            d = -1 if btn == 4 else 1
            if m == "guide": self.guide_scroll = max(0, min(getattr(self, "guide_max", 0), self.guide_scroll + d * 40))
            else: self.craft_scroll = max(0, self.craft_scroll + d)
            return
        if btn != 1: return
        if m == "settings" and not self.confirm_delete:
            for key, (hit, rr, lo, hi) in self.sliders.items():
                if hit.collidepoint(pos): self.slider_drag = key; self.set_slider(key, pos[0]); return
        for k, rr in self.ui_top():
            if not rr.collidepoint(pos): continue
            self.audio.play("click", .08)
            if k == "close": self.mode = "world"; self.slider_drag = None; self.confirm_delete = False; return
            if m == "settings": self.settings_click(k); return
            if m == "party":
                if k.startswith("pd_"): self.msg(self.w.party_dismiss(int(k[3:])), (255, 200, 140))
                return
            if m == "person":
                pid = getattr(self, "person_id", None)
                if k.startswith("ptab_"): self.person_tab = k[5:]
                elif k == "p_invite": self.msg(self.w.party_invite(pid), (160, 240, 255))
                elif k == "p_dismiss": self.msg(self.w.party_dismiss(pid), (255, 200, 140))
                elif k == "p_duel": self.msg(self.w.request_duel(pid), (255, 200, 140)); self.mode = "world"
                elif k == "p_fight": self.msg(self.w.request_fight(pid), (255, 140, 120)); self.mode = "world"
                elif k == "p_greet": self.msg(self.w.greet_person(pid), (230, 230, 200))
                return
            elif m == "guide":
                if k.startswith("gp"): self.guide_page = int(k[2:]); self.guide_scroll = 0
            elif m == "craft":
                if k.startswith("ct"): self.craft_tab = int(k[2:]); self.craft_scroll = 0
                elif k.startswith("cr_"): self.msg(self.w.craft(k[3:]), (160, 255, 170))
                elif k == "toshop": self.mode = "shop"; self.shop_tab = 0
            elif m == "quests":
                if k in ("qgt_work", "qgt_daily"): self.qg_tab = k[4:]
                elif k.startswith("acc_"): self.msg(self.w.quest_accept(self.qg_npc, k[4:]), (255, 230, 120))
                elif k.startswith("turn_"): self.msg(self.w.quest_turnin(k[5:]), (160, 255, 170))
            elif m == "quest":
                if k == "qt_log": self.qlog_tab = "log"
                elif k == "qt_myth": self.qlog_tab = "myth"
                elif k.startswith("ab_"): self.msg(self.w.quest_abandon(k[3:]), (255, 200, 120))
            return

    def on_mouse_move(self, pos):
        if self.mode == "map": self.map_mouse_move(pos)
        ld = self.look_drag
        if ld and self.mode == "world":
            if not ld["moved"] and math.hypot(pos[0] - ld["start"][0], pos[1] - ld["start"][1]) >= 10: ld["moved"] = True
            if ld["moved"]:
                lim_x, lim_y = LW * .5, LH * .5
                self.look[0] = max(-lim_x, min(lim_x, self.look[0] - (pos[0] - ld["last"][0])))
                self.look[1] = max(-lim_y, min(lim_y, self.look[1] - (pos[1] - ld["last"][1])))
            ld["last"] = pos
        if self.slider_drag and self.mode == "settings" and self.slider_drag in self.sliders:
            self.set_slider(self.slider_drag, pos[0])

    def on_mouse_up(self, pos, btn):
        if self.mode == "map": self.map_mouse_up(pos, btn)
        ld = self.look_drag
        if ld and btn == 1:
            self.look_drag = None
        if self.slider_drag:
            self.slider_drag = None; self.save_prefs()
        if self.mode == "inventory" and btn == 1 and self.drag:
            it = self.drag["item"]; d = self.drag; self.drag = None
            for rr, slot in getattr(self, "equip_rects", []):
                if rr.collidepoint(pos):
                    if it["slot"] == slot: self.msg(self.w.equip_gear(it["id"]))
                    else: self.msg(f"{it['item']} goes in the {SLOT_LABEL.get(it['slot'], it['slot'])} slot.", (255, 120, 100))
                    return
            if math.hypot(pos[0] - d["start"][0], pos[1] - d["start"][1]) < 6:
                self.msg(self.w.equip_gear(it["id"]))

    def finish_create(self):
        name = self.cc_name.strip() or "Adventurer"
        self.msg(self.w.create_character(name, self.cc_faction, self.cc_class, self.cc_spec or None), (255, 230, 120))
        self.msg("Tip: click a monster to attack it. Keys 1-6 attack skills, 7-0 defensive, K skill book, X mount (buy one at the Stable in town), Tab cycles targets.", (255, 220, 120))
        self.mode = "world"; self.disp = {}; self.prev = {}; self.zone = None

    def on_key(self, e):
        if self.mode == "create":
            if e.key == pygame.K_RETURN: self.finish_create()
            elif e.key == pygame.K_BACKSPACE: self.cc_name = self.cc_name[:-1]
            elif e.key == pygame.K_ESCAPE: return False
            elif e.unicode and (e.unicode.isalnum() or e.unicode in " -'") and len(self.cc_name) < 16:
                self.cc_name += e.unicode
            return True
        if e.key == pygame.K_F11: self.toggle_fullscreen(); return True
        if e.key == pygame.K_F1: self.mode = "world" if self.mode == "guide" else "guide"; return True
        if e.key == pygame.K_ESCAPE:
            if self.confirm_delete: self.confirm_delete = False
            elif self.mode != "world": self.mode = "world"; self.slider_drag = None
            elif self.target is not None: self.target = None; self.auto = False; self.pending = None
            elif self.dest: self.dest = None
            elif self.w.fishing: self.w.fish_cancel()
            else: self.mode = "settings"
            return True
        if e.key == pygame.K_F9:
            self.auto_q = False; self.slow_t = 0.0
            self.apply_quality((self.quality + 1) % len(QUALITY_NAMES))
        if e.key == pygame.K_p and self.mode == "pvp": self.mode = "world"; return True
        if e.key == pygame.K_q and self.mode in ("world", "quest"): self.mode = "world" if self.mode == "quest" else "quest"; self.qlog_tab = "log"; return True
        if e.key == pygame.K_i: self.mode = "world" if self.mode == "inventory" else "inventory"; return True
        if e.key == pygame.K_c: self.mode = "world" if self.mode == "class" else "class"; return True
        if e.key == pygame.K_m:
            self.mode = "world" if self.mode == "map" else "map"
            if self.mode == "map": self.map_drag = None; self.map_sel = None; self.map_open_default()
            return True
        if self.mode == "map":
            if e.key == pygame.K_TAB:
                if self.map_view is not None: self.map_view = None; self.map_sel = None
                else: self.map_center_player()
                return True
            if e.key in (pygame.K_LEFT, pygame.K_a): self.map_pan_key(-1, 0); return True
            if e.key in (pygame.K_RIGHT, pygame.K_d): self.map_pan_key(1, 0); return True
            if e.key in (pygame.K_UP, pygame.K_w): self.map_pan_key(0, -1); return True
            if e.key in (pygame.K_DOWN, pygame.K_s): self.map_pan_key(0, 1); return True
            if e.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS) and self.map_geo: self.map_zoom_at(self.map_geo[5].center, 1.4); return True
            if e.key in (pygame.K_MINUS, pygame.K_KP_MINUS) and self.map_geo: self.map_zoom_at(self.map_geo[5].center, 1 / 1.4); return True
            if e.key == pygame.K_0: self.map_view = None; self.map_sel = None; return True
        if e.key == pygame.K_k: self.mode = "world" if self.mode == "skills" else "skills"; return True
        if e.key == pygame.K_u: self.mode = "world" if self.mode == "stats" else "stats"; return True
        if self.mode != "world": return True
        if pygame.K_1 <= e.key <= pygame.K_6 and (e.mod & pygame.KMOD_SHIFT): self.cast("!@#$%^"[e.key - pygame.K_1])
        elif pygame.K_0 <= e.key <= pygame.K_9: self.cast(str(e.key - pygame.K_0))
        elif e.key == pygame.K_h: self.hot("potion")
        elif e.key == pygame.K_g: self.hot("fish")
        elif e.key == pygame.K_v: self.hot("food")
        elif e.key == pygame.K_y: self.hot("buffscroll")
        elif e.key == pygame.K_o and self.in_inst: self.hot("leave")
        elif e.key == pygame.K_n and self.in_inst: self.hot("ready")
        elif e.key == pygame.K_z: self.hot("loot")
        elif e.key == pygame.K_j: self.hot("mana")
        elif e.key == pygame.K_t: self.hot("scroll")
        elif e.key == pygame.K_TAB: self.cycle_target()
        elif e.key == pygame.K_SPACE or e.key == pygame.K_e:
            if self.target is None: self.cycle_target()
            if self.target is not None: self.auto = True
        elif e.key == pygame.K_x:
            self.msg(self.w.dismount() if (self.snap.get("mount") or {}).get("mounted") else self.w.mount(), (255, 230, 150))
            self.dest = None; self.path = None
        elif e.key == pygame.K_f:
            self.msg(self.w.interact_nearby(), (255, 230, 150)); self.open_world_ui()
        elif e.key == pygame.K_BACKQUOTE: self.hot("chat")
        return True

    def update_hover(self):
        self.hover = None; self.hover_loot = None
        if self.mode != "world": return
        for rr, l in reversed(self.loot_rects):
            if rr.collidepoint(self.mouse): self.hover_loot = l["id"]; return
        for rr, obj in reversed(self.hit_rects):
            if rr.collidepoint(self.mouse) and obj[0] == "actor":
                self.hover = obj[1]["id"]; return

    def apply_quality(self, q, announce=True, save=True):
        q = max(0, min(len(QUALITY_NAMES) - 1, q))
        self.quality = q
        ww, wh = pygame.display.get_surface().get_size()
        set_logical(round(800 * ww / max(1, wh)), 800)       # 800 tall, as wide as the screen's shape (no black bars)
        self.atmo = fx.Atmosphere(LW, LH, ls=2, pmul=1.8) if q >= 2 else fx.Atmosphere(LW, LH)     # 0.37 High: half-res light map, more motes
        self.atmo.lite = (q == 0); self.atmo.hq = (q >= 2); self._shp = None
        if save:
            st = load_settings(); st["quality"] = q; save_settings(st)
        if announce:
            extra = {0: "no particles or cloud shadows", 1: "lighting, shadows and particles", 2: "sharpened, finer lighting, soft shadows, sun rays"}[q]
            self.msg(f"Graphics: {QUALITY_NAMES[q]} ({extra}).  F9 changes it.", (255, 220, 120))

    def frame(self, dt):
        self._tt_drawn = False
        self._frame_t0 = time.perf_counter()
        self.t += dt; self.dt = dt; self._new_poses = 0
        global _MOUSE, _MY_FACTION; _MOUSE = self.mouse; _MY_FACTION = self.w.player.get("faction", "Alliance")
        if self.mode == "world" and self.quality > 0 and self.w is not None:
            try:
                pp = self.w.player; lp = getattr(self, "_lastp", None)
                if lp and math.hypot(pp["x"] - lp[0], pp["y"] - lp[1]) > .55 and len(self.effects) < 60:
                    kd = gfx.tile_info(self.layout, int(pp["x"]), int(pp["y"]))[0]
                    col = {"sand": (220, 200, 150), "snow": (235, 240, 250), "water": (190, 225, 255), "grass": (120, 150, 80)}.get(kd, (170, 150, 120))
                    self.effects.append({"type": "step", "x": pp["x"], "y": pp["y"], "t0": self.t, "dur": .5, "col": col})
                    self._lastp = (pp["x"], pp["y"])
                elif not lp: self._lastp = (pp["x"], pp["y"])
            except Exception: pass
        # automatic quality: a slow PC (e.g. a Celeron laptop) drops to lite effects by itself
        self.ft_avg += (min(dt, .25) - self.ft_avg) * .04
        if self.auto_q and self.quality > 0 and self.mode != "create":
            self.slow_t = self.slow_t + dt if self.ft_avg > .036 else max(0.0, self.slow_t - dt)
            if self.slow_t > 4.0:
                self.apply_quality(self.quality - 1, False, False); self.slow_t = 0.0; self.ft_avg = 1 / 60
                self.msg(f"Running slowly: graphics lowered to {QUALITY_NAMES[self.quality]} automatically (F9 to change).", (255, 220, 120))
        if self.mode == "world":
            self.move_player(dt)
            self.resolve_pending()
            self.auto_attack()
        self.snap = self.w.snapshot()
        self.snap["actors"] = [a for a in self.snap["actors"] if not a.get("hidden")]      # 0.39: shopkeepers inside buildings
        hour = self.snap.get("hour", 12)
        if 7 <= hour < 18: dark = 0
        elif 18 <= hour < 22: dark = (hour - 17) / 5 * 125
        elif 4 <= hour < 7: dark = (7 - hour) / 3 * 125
        else: dark = 125
        if self.snap.get("instance"): dark = 85
        self.night = dark
        if bool(self.snap.get("instance")) != self.in_inst: self.set_instance(bool(self.snap.get("instance")))
        self.sync_actors(dt)
        area = self.snap["area"]
        if area != self.zone:
            if self.zone is not None or self.mode == "world":
                self.zone_banner = (area, self.t, f"Level {self.snap['area_level']}")
            self.zone = area
        self.draw_world()
        self.prefetch_ground()
        if self.mode == "create":
            self.draw_create(); return
        self.draw_fishing()
        self.draw_hud(); self.draw_instance_hud(); self.draw_city_raid(); self.draw_prompts(); self.draw_quest_tracker(); self.draw_duel_hud()
        if self.mode == "inventory": self.draw_inventory()
        elif self.mode == "class": self.draw_class_window()
        elif self.mode == "map": self.draw_map()
        elif self.mode == "quest": self.draw_quest_window()
        elif self.mode == "craft": self.draw_craft()
        elif self.mode == "quests": self.draw_quests()
        elif self.mode == "settings": self.draw_settings()
        elif self.mode == "guide": self.draw_guide()
        elif self.mode == "market": self.draw_market()
        elif self.mode == "shop": self.draw_shop()
        elif self.mode == "stable": self.draw_stable()
        elif self.mode == "magic": self.draw_magic()
        elif self.mode == "kiln": self.draw_kiln()
        elif self.mode == "pvp": self.draw_pvp_menu()
        elif self.mode == "raids": self.draw_raids()
        elif self.mode == "armory": self.draw_armory()
        elif self.mode == "vault": self.draw_vault()
        elif self.mode == "skills": self.draw_skillbook()
        elif self.mode == "stats": self.draw_stats()
        elif self.mode == "person": self.draw_person()
        elif self.mode == "party": self.draw_party()
        self.flush_tooltip()
        self.update_hover()
        cur = pygame.SYSTEM_CURSOR_ARROW
        if self.mode == "world" and self.hover is not None:
            a = self.actor(self.hover)
            cur = pygame.SYSTEM_CURSOR_CROSSHAIR if (a and is_enemy(a, self.w.player)) else pygame.SYSTEM_CURSOR_HAND
        elif self.mode == "world" and self.hover_loot is not None:
            cur = pygame.SYSTEM_CURSOR_HAND
        if cur != self.cursor:
            self.cursor = cur
            try: pygame.mouse.set_system_cursor(cur)
            except Exception: pass


def _fit():
    win = pygame.display.get_surface(); ww, wh = win.get_size()
    sc = min(ww / LW, wh / LH) or 1
    sw, sh = max(1, int(LW * sc)), max(1, int(LH * sc))
    return win, sc, (ww - sw) // 2, (wh - sh) // 2, sw, sh

def to_canvas(pos):
    _, sc, ox, oy, _, _ = _fit()
    return int((pos[0] - ox) / sc), int((pos[1] - oy) / sc)

def present():
    win, sc, ox, oy, sw, sh = _fit()
    if (sw, sh) != win.get_size(): win.fill((0, 0, 0))
    if (sw, sh) == (LW, LH): win.blit(screen, (ox, oy))
    else: pygame.transform.smoothscale(screen, (sw, sh), win.subsurface((ox, oy, sw, sh)))    # straight into the window, no new surface
    pygame.display.flip()

def _graceful_exit(signum, frame):
    """0.34.2: kill / logout / Ctrl+C: leave through the normal shutdown so the world is saved."""
    global _STOP
    import signal as _sg
    for s_ in (_sg.SIGTERM, _sg.SIGINT, getattr(_sg, "SIGHUP", None)):
        if s_ is not None:
            try: _sg.signal(s_, _sg.SIG_IGN)       # a second signal must not interrupt the save
            except Exception: pass
    trace(f"signal {signum}: saving and quitting")
    if _IN_LOOP:                    # 0.37.2: let the frame finish, then leave through the normal save - never stop mid-update
        _STOP = True
    else:
        raise SystemExit(0)

_IN_LOOP = False
_STOP = False

def main():
    import signal as _sg
    lock = acquire_instance_lock()
    if lock is None:
        trace("another copy of LiveWorld RPG is already running with this save; exiting")
        loading("LiveWorld RPG is already running - switch to the open game window.", 1.0)
        time.sleep(4); pygame.quit(); return
    for s_ in (_sg.SIGTERM, _sg.SIGINT, getattr(_sg, "SIGHUP", None)):
        if s_ is not None:
            try: _sg.signal(s_, _graceful_exit)
            except Exception: pass
    loading("Opening the world...", .05)
    w, open_msg = open_world()
    if open_msg: trace("save: " + open_msg)
    global _IN_LOOP
    try:
        # 0.45: the loading steps sit inside the try, so a kill or an error while the world is being prepared
        # still closes (and saves / backs up) the world instead of leaving the database open
        loading("Waking the townsfolk...", .22)
        g = Game(w); accum = 0.; running = True
        g.apply_quality(default_quality(), False, False)
        loading("Dressing your hero...", .95)
        g.prewarm_player()
        if open_msg: g.msg(open_msg, (255, 160, 120))
        loading("Entering the world...", 1.0)
        first = True
        _IN_LOOP = True; _last_slow = [0.0]; _errs = [0, 0]
        while running and not _STOP:
            dt = min(.1, clock.tick(60) / 1000)
            _t0_loop = time.perf_counter()
            g.mouse = to_canvas(pygame.mouse.get_pos())
            for e in pygame.event.get():
                if e.type == pygame.QUIT: running = False
                elif e.type == pygame.KEYDOWN: running = g.on_key(e)
                elif e.type == pygame.VIDEORESIZE: g.apply_quality(g.quality, False, False)
                elif e.type == pygame.MOUSEBUTTONDOWN: g.on_mouse_down(to_canvas(e.pos), e.button)
                elif e.type == pygame.MOUSEBUTTONUP: g.on_mouse_up(to_canvas(e.pos), e.button)
                elif e.type == pygame.MOUSEMOTION: g.on_mouse_move(to_canvas(e.pos))
            if g.want_quit: running = False
            if fit_borderless(): g.apply_quality(g.quality, False, False)
            if g.want_reset:
                loading("Deleting the character...", .1)
                audio = g.audio; nm = w.player.get("name", "")
                w.close()
                for suf in ("", "-wal", "-shm", "-journal", ".bak"):
                    try: (DATA / ("world.db" + suf)).unlink()
                    except FileNotFoundError: pass
                for old in DATA.glob("worldmap_*.png"):
                    try: old.unlink()
                    except Exception: pass
                trace(f"character {nm!r} deleted; new world")
                loading("Creating a new world...", .3)
                w = World(); g = Game(w, audio=audio); g.apply_quality(default_quality(), False, False)
                g.msg(f"{nm} was deleted.  Create a new hero.", (255, 160, 120))
                accum = 0.0; continue
            try:
                if g.mode != "create":
                    accum += dt
                    while accum >= .25:
                        w.update(1); accum -= .25
                _t1 = time.perf_counter()
                if g.mode != "create": w.ai_pump(dt)
                g.frame(dt)
                _t2 = time.perf_counter()
                present()
                _errs[0] = 0
            except (SystemExit, KeyboardInterrupt):
                raise
            except Exception as e_:
                # 0.45: one bad frame no longer ends the session; the error is logged and play goes on.
                # Only a fault that repeats every frame for ~5 s stops the game (still saving on the way out).
                accum = 0.0; _errs[0] += 1; _t1 = _t2 = time.perf_counter()
                if _errs[1] < 20:
                    _errs[1] += 1; trace(f"frame error ({type(e_).__name__}: {e_}); continuing"); traceback.print_exc()
                if _errs[0] > 300: raise
                try: g.mode = "world" if g.mode not in ("world", "create") else g.mode
                except Exception: pass
                continue
            _t3 = time.perf_counter()
            if _t3 - _t0_loop > .12 and _t3 - _last_slow[0] > 2.0:      # 0.40.6: leave a trail for hitches in the log
                _last_slow[0] = _t3
                trace(f"slow frame {int((_t3 - _t0_loop) * 1000)} ms: events+update {int((_t1 - _t0_loop) * 1000)}, draw {int((_t2 - _t1) * 1000)}, present {int((_t3 - _t2) * 1000)}, mode {g.mode}")
            if first: trace(f"first frame drawn (mode {g.mode}, canvas {LW}x{LH}, window {pygame.display.get_surface().get_size()})"); first = False
    finally:
        _IN_LOOP = False
        for s_ in (_sg.SIGTERM, _sg.SIGINT, getattr(_sg, "SIGHUP", None)):      # nothing may interrupt the final save
            if s_ is not None:
                try: _sg.signal(s_, _sg.SIG_IGN)
                except Exception: pass
        try: w.close()
        finally: pygame.quit()

if __name__ == "__main__":
    main()
