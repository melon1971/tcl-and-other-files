# netbots.tcl v4.11 (security & bugfix release, based on v4.10 by slennox)
# Copyright 1998-2005 by slennox
# http://www.egghelp.org/

## aidle.tcl component script ##

proc ai_sendmsg {} {
  global ai_chans ai_msgbots ai_msgs botnick
  if {$ai_chans == ""} {
    set chans [channels]
  } else {
    set chans $ai_chans
  }
  if {[llength $chans] && [llength $ai_msgs]} {
    set chan [lindex $chans [rand [llength $chans]]]
    set msg [lindex $ai_msgs [rand [llength $ai_msgs]]]
    if {[validchan $chan] && [botonchan $chan]} {
      if {$ai_msgbots} {
        set botlist ""
        foreach bot [chanlist $chan b] {
          if {[string equal -nocase $bot $botnick] || [onchansplit $bot $chan]} {continue}
          lappend botlist $bot
        }
        if {$botlist != ""} {
          puthelp "PRIVMSG [lindex $botlist [rand [llength $botlist]]] :$msg"
        }
      } else {
        puthelp "PRIVMSG $chan :$msg"
      }
    }
  }
  ai_schedule
  return 0
}

# Exactly one pending ai_sendmsg (timer or utimer, depending on ai_uidle).
# Previously toggling ai_uidle with a rehash left both kinds running.
proc ai_schedule {} {
  global ai_time ai_uidle
  if {$ai_uidle} {
    nb_killtimer ai_sendmsg
    if {![string match *ai_sendmsg* [utimers]]} {
      utimer [expr {140 + [rand 40]}] ai_sendmsg
    }
  } else {
    nb_killutimer ai_sendmsg
    if {![string match *ai_sendmsg* [timers]]} {
      if {![string is integer -strict $ai_time] || $ai_time < 1} {
        set ai_time 1
      }
      timer [expr {[rand $ai_time] + 1}] ai_sendmsg
    }
  }
  return
}

set ai_chans [split [string trim $ai_chans]]

ai_schedule

return "nb_info 4.11.0"
