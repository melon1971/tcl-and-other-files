# netbots.tcl v4.11 (security & bugfix release, based on v4.10 by slennox)
# Copyright 1998-2005 by slennox
# http://www.egghelp.org/

## superbitch.tcl component script ##

proc sb_bitch {nick uhost hand chan mode opped} {
  global botnick sb_chans sb_canop sb_canopany sb_canopflags sb_checkop
  if {$mode != "+o" || ![validchan $chan]} {return 0}
  if {$sb_chans != "" && [lsearch -exact $sb_chans [string tolower $chan]] == -1} {return 0}
  if {![string equal -nocase $nick $botnick]} {
    if {![string equal -nocase $opped $botnick] && ![string equal -nocase $nick $opped] && [onchan $nick $chan] && ![wasop $opped $chan]} {
      if {![matchattr [nick2hand $opped $chan] $sb_canopflags $chan]} {
        # opped user isn't allowed ops: only sb_canopany users may do this
        if {$sb_canopany == "" || ![matchattr $hand $sb_canopany $chan]} {
          sb_punish $nick $hand $chan $opped
        }
      } elseif {($sb_canopany == "" || ![matchattr $hand $sb_canopany $chan]) && ($sb_canop == "" || ![matchattr $hand $sb_canop $chan])} {
        sb_punish $nick $hand $chan $opped
      }
    }
  } elseif {$sb_checkop && ![matchattr [nick2hand $opped $chan] o|o $chan]} {
    pushmode $chan -o $opped
    putlog "superbitch: opped non +o user $opped on $chan - reversing."
    nb_sendcmd * rbroadcast "superbitch: opped non +o user $opped on $chan - reversing."
  }
  return 0
}

proc sb_punish {nick hand chan opped} {
  global sb_note sb_remove
  if {[botisop $chan]} {
    pushmode $chan -o $opped
    pushmode $chan -o $nick
  }
  if {$sb_remove && [validuser $hand] && [matchattr $hand o|o $chan]} {
    chattr $hand -o+d|-o+d $chan
    if {[info commands sendnote] != ""} {
      foreach recipient $sb_note {
        if {[validuser $recipient]} {
          sendnote SUPERBITCH $recipient "Removed +o from $hand (opped $opped on $chan)"
        }
      }
    }
  }
  return
}

set sb_chans [split [string tolower $sb_chans]] ; set sb_note [split $sb_note]

bind mode - * sb_bitch

return "nb_info 4.11.0"
