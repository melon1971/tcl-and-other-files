# netbots.tcl v4.11 (security & bugfix release, based on v4.10 by slennox)
# Copyright 1998-2005 by slennox
# http://www.egghelp.org/

## botnetop.tcl component script ##

proc bop_jointmr {nick uhost hand chan} {
  global bop_asktmr bop_delay botnick
  if {![string equal -nocase $nick $botnick]} {
    if {![matchattr $hand b] || ![matchattr $hand o|o $chan] || [matchattr $hand d|d $chan]} {return 0}
    set stlchan [string tolower $chan]
    if {[info exists bop_asktmr($hand:$stlchan)]} {return 0}
    set bop_asktmr($hand:$stlchan) 1
    if {!$bop_delay || [bop_lowbots $chan]} {
      utimer 2 [list bop_askbot $hand $chan]
    } else {
      utimer [expr [rand $bop_delay] + 5] [list bop_askbot $hand $chan]
    }
  } else {
    bop_setneed $chan
  }
  return 0
}

proc bop_linkop {bot via} {
  if {[isbotnetnick $bot] || [isbotnetnick $via]} {
    if {![string match *bop_linkreq* [utimers]]} {
      utimer 2 bop_linkreq
    }
  }
  return 0
}

proc bop_linkreq {} {
  foreach chan [channels] {
    if {[botonchan $chan] && ![botisop $chan]} {
      bop_reqop $chan op
    }
  }
  return
}

proc bop_reqop {chan need} {
  global bop_needi
  if {![validchan $chan]} {return 0}
  if {![info exists bop_needi([string tolower $chan])]} {
    bop_setneed $chan
  }
  if {$need == "op"} {
    foreach bot [chanlist $chan b] {
      if {[isop $bot $chan] && [matchattr [set hand [nick2hand $bot $chan]] o|o $chan] && [islinked $hand]} {
        putbot $hand "reqops $chan"
      }
    }
  } else {
    bop_letmein $chan $need
  }
  return 0
}

proc bop_modeop {nick uhost hand chan mode opped} {
  global botnick
  if {$mode == "+o" && ![botisop $chan] && ![string equal -nocase $nick $botnick] && ![string equal -nocase $opped $botnick] && [matchattr [set obot [nick2hand $opped $chan]] b] && [matchattr $obot o|o $chan] && [islinked $obot]} {
    putbot $obot "reqops $chan"
  }
  return
}

proc bop_reqtmr {frombot cmd arg} {
  global bop_asktmr bop_delay
  set chan [lindex [split $arg] 0]
  if {![validchan $chan]} {return 0}
  if {![matchattr $frombot b] || ![matchattr $frombot o|o $chan] || [matchattr $frombot d|d $chan]} {return 0}
  set stlchan [string tolower $chan]
  if {[info exists bop_asktmr($frombot:$stlchan)]} {return 0}
  set bop_asktmr($frombot:$stlchan) 1
  if {!$bop_delay || [bop_lowbots $chan]} {
    utimer 2 [list bop_askbot $frombot $chan]
  } else {
    utimer [expr [rand $bop_delay] + 2] [list bop_askbot $frombot $chan]
  }
  return 0
}

proc bop_askbot {hand chan} {
  global botnick bop_asktmr
  set stlchan [string tolower $chan]
  if {[info exists bop_asktmr($hand:$stlchan)]} {
    unset bop_asktmr($hand:$stlchan)
  }
  if {![validchan $chan] || ![botonchan $chan] || ![botisop $chan]} {return 0}
  if {![islinked $hand]} {return 0}
  putbot $hand "doyawantops $chan $botnick"
  return 0
}

proc bop_doiwantops {frombot cmd arg} {
  global bop_log bop_maxreq bop_opreqs botname botnick
  set chan [lindex [split $arg] 0] ; set fromnick [lindex [split $arg] 1]
  if {![validchan $chan] || ![nb_isnick $fromnick] || ![botonchan $chan] || [botisop $chan]} {return 0}
  if {![matchattr $frombot b] || ![matchattr $frombot o|o $chan]} {return 0}
  set stlchan [string tolower $chan]
  if {![info exists bop_opreqs($stlchan)]} {
    bop_setneed $chan
  }
  if {$bop_maxreq && $bop_opreqs($stlchan) >= $bop_maxreq} {return 0}
  if {![onchan $fromnick $chan] || [onchansplit $fromnick $chan] || ![isop $fromnick $chan]} {return 0}
  if {![matchattr [nick2hand $fromnick $chan] o|o $chan]} {return 0}
  if {![islinked $frombot]} {return 0}
  putbot $frombot "yesiwantops $chan $botnick [string trimleft [lindex [split $botname !] 1] "~+-^="]"
  incr bop_opreqs($stlchan)
  if {$bop_maxreq} {
    nb_killutimer "bop_opreqsreset $stlchan"
    utimer 15 [list bop_opreqsreset $stlchan]
  }
  if {$bop_log >= 2} {
    putlog "botnetop: requested ops from $frombot on $chan"
  }
  return 0
}

proc bop_botwantsops {frombot cmd arg} {
  global bop_addhost bop_hcheck bop_log bop_osync strict-host
  set chan [lindex [split $arg] 0] ; set fromnick [lindex [split $arg] 1] ; set fromhost [lindex [split $arg] 2]
  if {![validchan $chan] || ![nb_isnick $fromnick] || ![botonchan $chan] || ![botisop $chan]} {return 0}
  if {![onchan $fromnick $chan] || [onchansplit $fromnick $chan]} {return 0}
  if {![matchattr $frombot b] || ![matchattr $frombot o|o $chan] || [matchattr $frombot d|d $chan]} {return 0}
  if {$bop_hcheck && $fromhost != "" && $fromhost != [string trimleft [getchanhost $fromnick $chan] "~+-^="]} {return 0}
  set fromhand [nick2hand $fromnick $chan]
  if {![matchattr $fromhand o|o $chan]} {
    # only learn a new host for an unknown nick - never steal a host that
    # already identifies a different user
    if {$fromhost == "" || !$bop_addhost || ($fromhand != "*" && $fromhand != "")} {return 0}
    if {[info exists strict-host] && ${strict-host} == 0} {
      set host *![string trimleft [getchanhost $fromnick $chan] "~+-^="]
    } else {
      set host *![getchanhost $fromnick $chan]
    }
    setuser $frombot HOSTS $host
    putlog "botnetop: added host $host to $frombot"
  }
  if {$bop_osync} {
    putquick "MODE $chan +o $fromnick"
  } else {
    if {[isop $fromnick $chan]} {return 0}
    pushmode $chan +o $fromnick
  }
  if {$bop_log >= 2} {
    if {$fromnick != $frombot} {
      putlog "botnetop: gave ops to $frombot (using nick $fromnick) on $chan"
    } else {
      putlog "botnetop: gave ops to $frombot on $chan"
    }
  }
  return 0
}

proc bop_letmein {chan need} {
  global botname botnick bop_log bop_needk bop_needi bop_needl bop_needu
  if {[bots] == "" || ![validchan $chan] || [botonchan $chan]} {return 0}
  set stlchan [string tolower $chan]
  if {![info exists bop_needk($stlchan)]} {
    bop_setneed $chan
  }
  switch -exact -- $need {
    "key" {
      if {$bop_needk($stlchan)} {return 0}
      set reqlist ""
      foreach bot [bots] {
        if {![matchattr $bot b] || ![matchattr $bot o|o $chan]} {continue}
        putbot $bot "wantkey $chan $botnick"
        lappend reqlist $bot
      }
      if {$bop_log >= 1 && $reqlist != ""} {
        regsub -all -- " " [join $reqlist] ", " reqlist
        putlog "botnetop: requested key for $chan from $reqlist"
      }
      set bop_needk($stlchan) 1
      utimer 30 [list set bop_needk($stlchan) 0]
    }
    "invite" {
      if {$bop_needi($stlchan)} {return 0}
      set reqlist ""
      foreach bot [bots] {
        if {![matchattr $bot b] || ![matchattr $bot o|o $chan]} {continue}
        if {[string match *!* $botname]} {
          putbot $bot "wantinvite $chan $botnick [string trimleft [lindex [split $botname !] 1] "~+-^="]"
        } else {
          putbot $bot "wantinvite $chan $botnick"
        }
        lappend reqlist $bot
      }
      if {$bop_log >= 1 && $reqlist != ""} {
        regsub -all -- " " [join $reqlist] ", " reqlist
        putlog "botnetop: requested invite to $chan from $reqlist"
      }
      set bop_needi($stlchan) 1
      utimer 30 [list set bop_needi($stlchan) 0]
    }
    "limit" {
      if {$bop_needl($stlchan)} {return 0}
      set reqlist ""
      foreach bot [bots] {
        if {![matchattr $bot b] || ![matchattr $bot o|o $chan]} {continue}
        putbot $bot "wantlimit $chan $botnick"
        lappend reqlist $bot
      }
      if {$bop_log >= 1 && $reqlist != ""} {
        regsub -all -- " " [join $reqlist] ", " reqlist
        putlog "botnetop: requested limit raise on $chan from $reqlist"
      }
      set bop_needl($stlchan) 1
      utimer 30 [list set bop_needl($stlchan) 0]
    }
    "unban" {
      if {$bop_needu($stlchan) || ![string match *!* $botname]} {return 0}
      set reqlist ""
      foreach bot [bots] {
        if {![matchattr $bot b] || ![matchattr $bot o|o $chan]} {continue}
        putbot $bot "wantunban $chan $botnick $botname"
        lappend reqlist $bot
      }
      if {$bop_log >= 1 && $reqlist != ""} {
        regsub -all -- " " [join $reqlist] ", " reqlist
        putlog "botnetop: requested unban on $chan from $reqlist"
      }
      set bop_needu($stlchan) 1
      utimer 30 [list set bop_needu($stlchan) 0]
    }
  }
  return 0
}

proc bop_botwantsin {frombot cmd arg} {
  global bop_didlimit bop_icheck bop_log bop_who
  set chan [lindex [split $arg] 0]
  if {![validchan $chan] || ![botonchan $chan]} {return 0}
  if {![matchattr $frombot b] || ![matchattr $frombot fo|fo $chan]} {return 0}
  set fromnick [lindex [split $arg] 1] ; set fromhost [lindex [split $arg] 2]
  if {$cmd != "wantkey" && ![nb_isnick $fromnick]} {return 0}
  switch -exact -- $cmd {
    "wantkey" {
      if {[string match *k* [lindex [split [getchanmode $chan]] 0]]} {
        set key [lindex [split [getchanmode $chan]] 1]
        # Key may be * (not displayed) on some networks (e.g. Undernet) if the bot splits into a +k channel unopped
        if {$key == "*"} {return 0}
        putbot $frombot "thekey $chan $key"
        if {$bop_log >= 1} {
          putlog "botnetop: gave key for $chan to $frombot"
        }
      }
    }
    "wantinvite" {
      if {![botisop $chan]} {return 0}
      if {$bop_icheck && $fromhost != ""} {
        set stlnick [string tolower $fromnick]
        if {![info exists bop_who($stlnick)]} {
          if {[array size bop_who] >= 50} {return 0}
          set bop_who($stlnick) [list $chan $frombot $fromhost]
          utimer 60 [list bop_whounset $stlnick]
        }
        putserv "WHO $fromnick"
      } else {
        putserv "INVITE $fromnick $chan"
        if {$bop_log >= 1} {
          if {$fromnick != $frombot} {
            putlog "botnetop: invited $frombot (using nick $fromnick) to $chan"
          } else {
            putlog "botnetop: invited $frombot to $chan"
          }
        }
      }
    }
    "wantlimit" {
      if {![botisop $chan]} {return 0}
      if {[info commands cl_priority] != "" && ![info exists bop_didlimit]} {
        if {$bop_log >= 1} {
          putlog "botnetop: adjusting limit on $chan as requested by $frombot"
        }
        cl_dolimit "" 0
        # calling cl_dolimit multiple times within a short period can result in multiple limit changes because of mode queue delays, hence the following bloat
        set bop_didlimit 1
        utimer 10 [list unset bop_didlimit]
      }
      # must be called even if chanlimit.tcl is present in case channel is excluded from chanlimit or cl_priority bot is lagged
      # delay to allow some time for bots with chanlimit.tcl to raise limit first, can also lessen flooding a bit in any case
      utimer [expr {10 + [rand 11]}] [list bop_raiselimit $chan $frombot]
    }
    "wantunban" {
      if {![botisop $chan]} {return 0}
      foreach ban [chanbans $chan] {
        if {[string match -nocase [lindex $ban 0] $fromhost]} {
          pushmode $chan -b [lindex $ban 0]
          if {$bop_log >= 1} {
            putlog "botnetop: unbanned $frombot on $chan"
          }
        }
      }
    }
  }
  return 0
}

proc bop_raiselimit {chan frombot} {
  global bop_log
  if {![validchan $chan] || ![botonchan $chan] || ![botisop $chan]} {return 0}
  set currlimit [nb_getlimit $chan]
  if {$currlimit > 0} {
    if {[llength [chanlist $chan]] >= $currlimit} {
      pushmode $chan +l [expr {[llength [chanlist $chan]] + 1}]
      if {$bop_log >= 1} {
        putlog "botnetop: raised limit on $chan as requested by $frombot"
      }
    }
  }
  return 0
}

proc bop_who {from keyword arg} {
  global bop_log bop_who
  set fromnick [lindex [split $arg] 5] ; set stlnick [string tolower $fromnick]
  if {[info exists bop_who($stlnick)]} {
    set chan [lindex $bop_who($stlnick) 0] ; set frombot [lindex $bop_who($stlnick) 1] ; set fromhost [lindex $bop_who($stlnick) 2]
    unset bop_who($stlnick)
    if {![validchan $chan] || ![botisop $chan]} {return 0}
    if {$fromhost == [string trimleft [lindex [split $arg] 2]@[lindex [split $arg] 3] "~+-^="]} {
      putserv "INVITE $fromnick $chan"
      if {$bop_log >= 1} {
        if {$fromnick != $frombot} {
          putlog "botnetop: invited $frombot (using nick $fromnick) to $chan"
        } else {
          putlog "botnetop: invited $frombot to $chan"
        }
      }
    }
  }
  return 0
}

proc bop_whounset {fromnick} {
  global bop_who
  if {[info exists bop_who($fromnick)]} {
    unset bop_who($fromnick)
  }
  return
}

# Only accept a key for a channel we're configured for, from a bot that is
# allowed to give it, and only while we're actually asking for one.
proc bop_joinkey {frombot cmd arg} {
  global bop_kjoin bop_needk
  set chan [lindex [split $arg] 0] ; set key [lindex [split $arg] 1]
  if {![validchan $chan] || $key == "" || [regexp -- {[,\x00-\x1f]} $key]} {return 0}
  if {![matchattr $frombot b] || ![matchattr $frombot fo|fo $chan]} {return 0}
  set stlchan [string tolower $chan]
  if {![info exists bop_kjoin($stlchan)]} {
    bop_setneed $chan
  }
  if {[botonchan $chan] || $bop_kjoin($stlchan) || !$bop_needk($stlchan)} {return 0}
  putserv "JOIN $chan $key"
  set bop_kjoin($stlchan) 1
  utimer 10 [list set bop_kjoin($stlchan) 0]
  return 0
}

proc bop_lowbots {chan} {
  global botnick
  set bots 1
  foreach bot [chanlist $chan b] {
    if {![string equal -nocase $bot $botnick] && [isop $bot $chan]} {
      incr bots
    }
  }
  if {$bots < 3} {return 1}
  return 0
}

proc bop_opreqsreset {stlchan} {
  global bop_opreqs
  set bop_opreqs($stlchan) 0
  return
}

proc bop_setneed {chan} {
  global bop_kjoin bop_needk bop_needi bop_needl bop_needu bop_opreqs
  set stlchan [string tolower $chan]
  set bop_opreqs($stlchan) 0 ; set bop_kjoin($stlchan) 0
  set bop_needk($stlchan) 0 ; set bop_needi($stlchan) 0
  set bop_needl($stlchan) 0 ; set bop_needu($stlchan) 0
  return
}

proc bop_unsetneed {nick uhost hand chan {msg ""}} {
  global botnick
  if {[string equal -nocase $nick $botnick] && ![validchan $chan]} {
    bop_dropchan [string tolower $chan]
  }
  return 0
}

proc bop_dropchan {stlchan} {
  global bop_kjoin bop_needk bop_needi bop_needl bop_needu bop_opreqs
  foreach var {bop_opreqs bop_kjoin bop_needk bop_needi bop_needl bop_needu} {
    if {[info exists ${var}($stlchan)]} {
      unset ${var}($stlchan)
    }
  }
  return
}

# Every 5 minutes: reset request throttles, and drop state for channels that
# have been removed (their part may never have been seen).
proc bop_settimer {} {
  global bop_opreqs
  foreach stlchan [array names bop_opreqs] {
    if {![validchan $stlchan]} {
      bop_dropchan $stlchan
    }
  }
  foreach chan [channels] {
    bop_setneed $chan
  }
  if {![string match *bop_settimer* [timers]]} {
    timer 5 bop_settimer
  }
  return 0
}

# Pre-1.6 versions of this script stored need-* Tcl scripts in the channel
# settings; remove any such leftovers once (only ones this script wrote).
proc bop_clearoldneeds {} {
  foreach chan [channels] {
    foreach need {op invite key limit unban} {
      if {![catch {channel get $chan need-$need} script] && [string match "bop_*" $script]} {
        catch {channel set $chan need-$need ""}
      }
    }
  }
  bop_settimer
  return
}

bind need - * bop_reqop

if {![string match *bop_clearoldneeds* [utimers]]} {
  utimer 2 bop_clearoldneeds
}

bind mode - * bop_modeop
if {!$bop_modeop} {
  unbind mode - * bop_modeop
  rename bop_modeop ""
}
bind link - * bop_linkop
if {!$bop_linkop} {
  unbind link - * bop_linkop
  rename bop_linkop ""
}
bind bot - doyawantops bop_doiwantops
bind bot - yesiwantops bop_botwantsops
bind bot - reqops bop_reqtmr
bind bot - wantkey bop_botwantsin
bind bot - wantinvite bop_botwantsin
bind bot - wantlimit bop_botwantsin
bind bot - wantunban bop_botwantsin
bind bot - thekey bop_joinkey
bind join - * bop_jointmr
bind part - * bop_unsetneed
bind raw - 352 bop_who

return "nb_info 4.11.0"
