# netbots.tcl v4.11 (security & bugfix release, based on v4.10 by slennox)
# Copyright 1998-2005 by slennox
# http://www.egghelp.org/

## repeat.tcl component script ##

# Settings are split before anything uses them (previously the reset timers
# were scheduled with the unsplit "n:secs" strings, i.e. 'utimer "" ...').
set rp_chans [split [string tolower $rp_chans]]
set rp_echans [split [string tolower $rp_echans]]
set rp_kflood [split $rp_kflood :]
set rp_bflood [split $rp_bflood :]
set rp_sflood [split $rp_sflood :]

# a flood setting is active only if both count and time are positive integers
proc rp_on {setting} {
  set count [lindex $setting 0] ; set secs [lindex $setting 1]
  if {![string is integer -strict $count] || ![string is integer -strict $secs]} {return 0}
  return [expr {$count > 0 && $secs > 0}]
}

proc rp_pubmsg {nick uhost hand chan text} {
  global botnick rp_bcount rp_bflood rp_breason rp_btime rp_efficient rp_exempt rp_kcount rp_kflood rp_kreason rp_scount rp_sflood rp_slength rp_sreason rp_warning
  set uhost [string tolower [string trimleft $uhost "~+-^="]] ; set chan [string tolower $chan] ; set text [string tolower $text]
  if {[string equal -nocase $nick $botnick] || ![validchan $chan] || ![rp_chan $chan] || [matchattr $hand $rp_exempt $chan]} {return 0}
  if {$rp_efficient} {
    # counters are wiped by the periodic reset; cap them in between
    if {[array size rp_bcount] > 5000 || [array size rp_kcount] > 5000} {return 0}
  } elseif {[llength [utimers]] > 999} {
    return 0
  }
  set key $uhost:$chan:$text
  set bon [rp_on $rp_bflood] ; set kon [rp_on $rp_kflood] ; set son [rp_on $rp_sflood]
  if {$bon} {
    if {[info exists rp_bcount($key)]} {
      incr rp_bcount($key)
    } else {
      set rp_bcount($key) 1
    }
    if {!$rp_efficient} {
      utimer [lindex $rp_bflood 1] [list rp_breset $uhost $chan $text]
    }
  }
  if {$kon} {
    if {[info exists rp_kcount($key)]} {
      incr rp_kcount($key)
    } else {
      set rp_kcount($key) 1
    }
    if {!$rp_efficient} {
      utimer [lindex $rp_kflood 1] [list rp_kreset $uhost $chan $text]
    }
  }
  if {$son && [string length $text] > $rp_slength} {
    if {[info exists rp_scount($key)]} {
      incr rp_scount($key)
    } else {
      set rp_scount($key) 1
    }
    if {!$rp_efficient} {
      utimer [lindex $rp_sflood 1] [list rp_sreset $uhost $chan $text]
    }
  }
  if {$bon && $rp_bcount($key) == [lindex $rp_bflood 0]} {
    if {[botisop $chan]} {
      putserv "KICK $chan $nick :$rp_breason"
    }
    set ban *!*[string range $uhost [string first @ $uhost] end]
    if {![matchban $ban $chan]} {
      newchanban $chan $ban repeat $rp_breason $rp_btime
    }
  } elseif {$kon && $rp_kcount($key) == [lindex $rp_kflood 0]} {
    if {![rp_mhost $nick $uhost $chan] && [botisop $chan]} {
      if {$rp_warning} {
        puthelp "PRIVMSG $chan :$nick$rp_kreason"
      } else {
        putserv "KICK $chan $nick :$rp_kreason"
      }
    }
  } elseif {[info exists rp_scount($key)] && $rp_scount($key) == [lindex $rp_sflood 0]} {
    if {![rp_mhost $nick $uhost $chan] && [botisop $chan]} {
      if {$rp_warning} {
        puthelp "PRIVMSG $chan :$nick$rp_sreason"
      } else {
        putserv "KICK $chan $nick :$rp_sreason"
      }
    }
  }
  return 0
}

proc rp_chan {chan} {
  global rp_chans rp_echans
  if {$rp_chans != ""} {
    if {[lsearch -exact $rp_chans [string tolower $chan]] == -1} {return 0}
  }
  if {$rp_echans != ""} {
    if {[lsearch -exact $rp_echans [string tolower $chan]] != -1} {return 0}
  }
  return 1
}

proc rp_pubact {nick uhost hand dest key arg} {
  if {![validchan $dest]} {return 0}
  rp_pubmsg $nick $uhost $hand $dest $arg
  return 0
}

proc rp_pubnotc {from keyword arg} {
  set nick [lindex [split $from !] 0]
  set chan [lindex [split $arg] 0]
  if {![validchan $chan] || ![onchan $nick $chan]} {return 0}
  set uhost [getchanhost $nick $chan]
  set hand [nick2hand $nick $chan]
  set text [join [lrange [split $arg] 1 end]]
  if {[string index $text 0] == ":"} {
    set text [string range $text 1 end]
  }
  rp_pubmsg $nick $uhost $hand $chan $text
  return 0
}

proc rp_mhost {nick uhost chan} {
  global rp_btime rp_mhosts rp_mreason rp_mtime
  set mhost [lindex [split $uhost @] 1]
  if {![info exists rp_mhosts($chan)]} {
    set rp_mhosts($chan) ""
  }
  if {[lsearch -exact $rp_mhosts($chan) $mhost] != -1} {
    if {[botisop $chan]} {
      putserv "KICK $chan $nick :$rp_mreason"
    }
    set ban *!*[string tolower [string range $uhost [string first @ $uhost] end]]
    if {![matchban $ban $chan]} {
      newchanban $chan $ban repeat $rp_mreason $rp_btime
    }
    return 1
  }
  lappend rp_mhosts($chan) $mhost
  utimer $rp_mtime [list rp_mhostreset $chan]
  return 0
}

proc rp_mhostreset {chan} {
  global rp_mhosts
  if {![info exists rp_mhosts($chan)]} {return 0}
  set rp_mhosts($chan) [lrange $rp_mhosts($chan) 1 end]
  if {$rp_mhosts($chan) == ""} {
    unset rp_mhosts($chan)
  }
  return 0
}

# Kill reset timers from either mode before redefining the procs, otherwise a
# rehash that toggles rp_efficient leaves timers that call the new procs with
# the wrong number of arguments.
nb_killutimer "rp_kreset*"
nb_killutimer "rp_breset*"
nb_killutimer "rp_sreset*"
foreach rp_var {rp_bcount rp_kcount rp_scount} {
  if {[info exists $rp_var]} {
    unset $rp_var
  }
}
unset rp_var

if {$rp_efficient} {

  proc rp_breset {} {
    global rp_bcount rp_bflood
    if {[info exists rp_bcount]} {
      unset rp_bcount
    }
    if {[rp_on $rp_bflood]} {
      utimer [lindex $rp_bflood 1] rp_breset
    }
    return 0
  }

  proc rp_kreset {} {
    global rp_kcount rp_kflood
    if {[info exists rp_kcount]} {
      unset rp_kcount
    }
    if {[rp_on $rp_kflood]} {
      utimer [lindex $rp_kflood 1] rp_kreset
    }
    return 0
  }

  proc rp_sreset {} {
    global rp_scount rp_sflood
    if {[info exists rp_scount]} {
      unset rp_scount
    }
    if {[rp_on $rp_sflood]} {
      utimer [lindex $rp_sflood 1] rp_sreset
    }
    return 0
  }

  if {[rp_on $rp_kflood]} {
    utimer [lindex $rp_kflood 1] rp_kreset
  }
  if {[rp_on $rp_bflood]} {
    utimer [lindex $rp_bflood 1] rp_breset
  }
  if {[rp_on $rp_sflood]} {
    utimer [lindex $rp_sflood 1] rp_sreset
  }

} else {

  proc rp_breset {uhost chan text} {
    global rp_bcount
    set key $uhost:$chan:$text
    if {[info exists rp_bcount($key)] && [incr rp_bcount($key) -1] <= 0} {
      unset rp_bcount($key)
    }
    return 0
  }

  proc rp_kreset {uhost chan text} {
    global rp_kcount
    set key $uhost:$chan:$text
    if {[info exists rp_kcount($key)] && [incr rp_kcount($key) -1] <= 0} {
      unset rp_kcount($key)
    }
    return 0
  }

  proc rp_sreset {uhost chan text} {
    global rp_scount
    set key $uhost:$chan:$text
    if {[info exists rp_scount($key)] && [incr rp_scount($key) -1] <= 0} {
      unset rp_scount($key)
    }
    return 0
  }

}

bind pubm - * rp_pubmsg
bind ctcp - ACTION rp_pubact
bind raw - NOTICE rp_pubnotc

return "nb_info 4.11.0"
