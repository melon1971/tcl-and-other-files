# LocSec 4.0

LocSec is a local host-security controller for 24/7 background operation. It
installs as the native Qt6 desktop build on Debian 12 and 13, Ubuntu 24.04 LTS, 26.04 LTS and 26.10,
Linux Mint 22, and LMDE 6 and 7 (amd64). Linux Mint 22.3 "Zena" is the reference
platform.

Note: Debsecan's vulnerability feed is keyed to Debian package versions and is
not reliable on Ubuntu/Mint, since Ubuntu ships different package versions
under the same names. On Ubuntu and Mint, Debsecan is skipped automatically and
CVE/update checks rely on `apt-get`'s Ubuntu security-pocket candidates
instead, which is accurate for this distro.

## Native desktop installation

The native GUI is a Qt6 application with the dashboard embedded through QtWebEngine.
It does not normally open an external web browser. This package makes
python3-pyqt6, python3-pyqt6.qtwebengine, rsyslog, xdg-utils and libnotify-bin
hard dependencies so an APT-aware installation pulls in the complete desktop stack.
Use `sudo apt install ./locsecd_<version>_amd64.deb` from a terminal; raw `dpkg -i` does not resolve
and download dependencies, and the GDebi graphical installer is not recommended (it can fail with a
GTK/VTE error and look frozen). The persistent tray/panel icon remains enabled through
`/etc/xdg/autostart/locsec-tray.desktop`.


- UFW integration with nftables fallback
- persistent automatic IP blocking
- built-in port-scan detection from the firewall log (replaces PortSentry; opens no ports)
- authentication success/failure monitoring with a configurable time window
- ClamAV and freshclam integration
- AIDE, Lynis, Debsecan/CVE and rkhunter scans
- tcpdump/tshark packet capture
- continuously refreshed IP/domain IOC feeds
- optional automatic enforcement of feed IP indicators
- Debian security/package update integration

## Idle scanning

Heavy scans run only after the configured load has remained below `idle_load` for
`idle_seconds`. The normal scan interval is six hours.

LocSec does not wake a suspended or hibernated computer to run scans. While a job is
running it holds a systemd-logind sleep inhibitor (and ignores lid close) so the job is
not frozen halfway; see `inhibit_sleep_during_jobs` and `inhibit_lid_switch`.

## Automatic remediation

Remediation is a fixed rule per incident type, chosen by the daemon and nothing
else. Package remediation is performed through Debian's package-management
mechanisms and is recorded as changed package versions in the update result.

Malware deletion is restricted to files already inside LocSec's quarantine area.

## Network capture

Packet captures remain local under `/var/lib/locsecd/captures` and can be opened
with Wireshark. Analyze uses a built-in, memory-safe header reader; the optional
Deep analysis runs tshark sandboxed as a throwaway unprivileged user.


3.4 adds persistent incident history, IPv4/IPv6 nftables containment, configurable automatic-response policy, IPv6 port-scan event parsing, ClamAV daemon scan preference, and reboot-required reporting after package updates.


Threat-intelligence feeds refresh twice per day by default (`feed_interval=43200`). Repeated feed indicators are deduplicated into one active incident with a count and last-seen timestamp. Investigate/Contain/Resolve actions now return an action log explaining what LocSec did, why it did it, and the relevant command/output, with an **OK** button to close the result.

Threat-intelligence feeds refresh twice per day by default (feed_interval=43200). Repeated feed indicators are deduplicated into one active incident with a count and last-seen timestamp. Investigate/Contain/Resolve actions return an action log explaining what LocSec did, why it did it, and the relevant command/output, with an OK button to close the result.

## Resource controls

LocSec 4.0.4 expires automatic firewall blocks after 30 days and removes their corresponding UFW/nftables entries. Repeated detections of an already-active block do not create another firewall rule or ban. Heavy background scans are started with low CPU priority and idle I/O.

## Incident Confirm

The Incidents page replaces the per-incident Delete button with Confirm. Confirm asks for operator confirmation, collects bounded local evidence, then performs only fixed remediation appropriate to the incident type: network containment for hostile addresses, ClamAV quarantine for detected malware, and APT package remediation for high/critical CVE findings. Each action is recorded in the incident action log and a JSON incident report.

Threat-feed entries are indicators of concern, not proof that the listed address connected to this host.

## 4.0.4 logging behavior
Threat-intelligence feed inventory is not recorded as incidents or per-IP operational log entries. Feed addresses may still be enforced by the firewall when feed blocking is enabled, but the incident stream is reserved for observed security events. Authentication logging records both successful and denied attempts in LocSec's own log (successful ones at INFO, denied ones at WARN) while `log_auth_each_attempt` is true, which is the default. Setting it to false keeps the per-attempt lines out of the log; detection, counting and automatic blocking are unaffected.


4.0.11-10 hardening: dashboard report reads are bounded by the configured report-size limits to prevent oversized JSON from exhausting system memory.

## AIDE baseline lifecycle

LocSec never overwrites an existing `/var/lib/aide/aide.db` through the normal Initialize AIDE action. If a valid active database exists, LocSec reports that AIDE is already initialized. Debian's daily AIDE job may also leave `/var/lib/aide/aide.db.new` beside it; this is a pending baseline for administrator review.

Use `locsecctl aide-accept` only after reviewing the differences. LocSec validates the pending database, makes it `root:root` mode `0600`, retains the previous active database as `aide.db.locsec-backup`, and atomically promotes the pending file. Use `locsecctl aide-reinitialize` when you intentionally want a completely fresh replacement baseline. Do not manually copy `aide.db.new` over `aide.db`.

