CIPHERPANE BROWSER SECURITY v2.7.0 (Chrome/Brave/Edge 121+ & Firefox 140+, MV3)
==========================================================================================
Formerly "AegisGate Browser Firewall & Threat Blocker". Renamed in 2.6.0; see MIGRATING below.

INSTALL (Chrome/Brave/Edge): chrome://extensions -> Developer mode -> Load unpacked -> dist/chrome
INSTALL (Firefox, temporary): about:debugging#/runtime/this-firefox -> Load Temporary Add-on -> dist/firefox/manifest.json
(dist/ is produced by "node tools/build.js"; the two folders differ only in the manifest: Chrome uses a
service worker, Firefox an event page. Ready-made zips of each ship alongside the source.)
SETTINGS: click the gear in the popup, or right-click the toolbar icon -> Options / Manage extension -> Extension options.
Firefox: grant "Access your data for all websites" in about:addons -> CipherPane -> Permissions.
TESTS:   node tests/run.js   (no dependencies; lists/rules, page-script and worker runtime tests)
VERIFY:  in the release folder (next to the zips, not inside them): sha256sum -c SHA256SUMS
         (macOS: shasum -a 256 -c SHA256SUMS). A matching hash shows the file is unchanged since packaging;
         it does not show who packaged it.

Browser security note: the manifest minimum versions are API compatibility floors, not security floors. Install current supported Chrome/Chromium/Brave/Edge and Firefox (or current Firefox ESR) updates; CipherPane cannot patch vulnerabilities in the browser engine itself.

WHAT IT DOES
- Local deceptive-URL heuristic (priority 160): blocks HTTP(S) URLs with credentials embedded in the authority.
  Local lookalike checks detect common brand typos and selected IDN homoglyphs before navigation continues.
  Hostnames are evaluated locally and are not uploaded or retained as browsing history. The navigation
  redirect is best-effort; static DNR list matches remain the synchronous block layer.
- Malware/phishing guard. Not overridable by Trust Site: the built-in rules (priority 1000) and the
  downloaded URLhaus (via curbengh) + phishing lists (priority 150). If a site is wrongly listed, switch that
  list off in Bulk Lists -> Auto-updating block lists.
- Ad/tracker blocker (built-in domains + auto-updating HaGeZi Light; StevenBlack optional), plus legacy Flash/.swf
  banner blocking (request rule + hidden Flash embeds).
- Fingerprint resistance (on by default; Trusted Sites exempt): canvas, WebGL, audio and hardware-info perturbation.
- Optional switches, off by default: block cdn.cookielaw.org; extra third-party ad-image patterns.
- Force HTTPS with HTTP fallback warning page. Trust Site does not disable the upgrade.
- Download Guard (Off / Balanced / Strict).
- Third-Party Script Blocker and Strict outbound firewall (login/payment/captcha providers exempt).
- Bulk importer (up to 100,000 domains), custom blocks (up to 20,000), live per-tab request logger.

Priority order, highest first: 1002 updater exemption, 1001 LAN exemption, 1000 built-in malware rules, 200 custom blocks,
160 deceptive-URL heuristic, 150 malware/phishing lists, 100 Trust Site, 50 optional cookielaw block, 40 other lists,
30 login/payment exemptions, 20 Strict, 10 script blocker, 6 "allow HTTP", 5 HTTPS upgrade, 1 ad rules.

MIGRATING FROM AEGISGATE
The name, the Firefox add-on ID (now cipherpane-security@local.extension) and the settings-export format
changed. Storage keys did not, so an in-place update of the same Chrome folder keeps settings. A browser that
treats this as a new extension (Firefox always does, because the ID changed; Chrome does when the unpacked folder
path differs) starts with defaults. To carry settings over: in the OLD version open Settings -> Export, then in
CipherPane open Settings -> Import. Files exported by AegisGate 2.5.x import as they are.
Remove the old AegisGate extension afterwards so the two do not both filter the same requests.

CHANGES IN 2.7.0 (ad-script fix, fingerprint resistance, optional blocks)
- Ad Scripts Loading (adblock.turtlecute.org): the 2.6.9 rules only matched scripts whose own host was the test host. The
  test's filter syntax is "/pagead.js$domain=adblock.turtlecute.org", i.e. scoped to the PAGE, so a script served from
  any other host was never blocked. Added initiator-scoped rules (ads.js, pagead.js, /widget/ads.; script/XHR/frame/other)
  next to the originals. Still limited to that test host: other sites are not affected.
  Verified in headless Chromium against a local stand-in (all three blocked, same scripts load on another host).
  NOT verified against the live test page or in Firefox.
- Fingerprint resistance (new switch, default on): a MAIN-world content script, registered through the new "scripting"
  permission and excluded on Trusted Sites.
    canvas   getImageData / toDataURL / toBlob on canvases up to 250,000 px: ~1 pixel in 32 moves one colour channel by 1
    WebGL    UNMASKED_VENDOR/RENDERER return generic strings; small readPixels get the same noise
    audio    OfflineAudioContext buffers (the usual audio fingerprint) and analyser float data get ~1e-7 noise
    hardware navigator.hardwareConcurrency capped at 4, navigator.deviceMemory reported as 8
  Not covered: installed fonts, time zone/locale, screen size, user-agent, WebRTC, speech voices. Spoofing a time zone
  consistently needs every Date/Intl path rewritten and breaks calendars and bookings, so it is not attempted.
  Applies to pages opened after the setting changes.
- Legacy Flash banners: .swf requests are blocked (never a top-level page) and Flash <object>/<embed> elements are
  hidden on every site. Browsers no longer run Flash; this only removes the empty box and the fetch.
- cdn.cookielaw.org stays allowed by default. New switch "Block cdn.cookielaw.org" (off) adds a priority-50 block; Trust
  Site (100) still overrides it, so a site you trust keeps its consent notice.
- Static images and GIFs: no failing test URL was available, so nothing broad was added. New switch "Extra ad-image
  patterns" (off): third-party images only, and only for /ads/ or /advert/ folders, banner-size names such as
  banner_300x250.gif, and pixel/beacon/tracking .gif files. Ordinary images (header-banner.jpg, team-300x250.jpg,
  spacer.gif, avatars) are covered by regression tests as not blocked.
- Malware protections untouched (rules_malware.json unchanged).
- Tests: 40 lists/rules/packaging groups, 7 fingerprint, 5 page-script, 40 runtime tests (92 total).

CHANGES IN 2.6.9 (targeted cosmetic and ad-script filter coverage)
- Added host-scoped cosmetic hiding for the two documented adblock.turtlecute.org selectors.
- Added narrowly scoped blocking for that test host’s ads.js, pagead.js and /widget/ads. script endpoints.
- cdn.cookielaw.org remains intentionally allowed by Strict/script-blocker exemptions because consent managers are needed by many sites; it is not an advertising-domain block-list entry.

CHANGES IN 2.6.8 (counter crash-window hardening)
- Download Guard “Allow once” approvals are short-lived (30 seconds), serialized, and consumed on the first matching event.
- Request logger records origin only; sensitive URL paths are not retained.
- Block counters use a session journal with an absolute commit target and idempotent recovery, preventing duplicate increments
  across the known local-commit/journal-clear crash window.
- Added regression coverage for interrupted-commit recovery. Browser storage is still not transactional.
- Download cancellation remains asynchronous and cannot guarantee pre-write interception.

CHANGES IN 2.6.7 (security remediation follow-up)
- CP-01 one-use download approval, CP-02 origin-only logging, and CP-03 session-journal counter recovery.
- The original 2.6.7 implementation could theoretically duplicate a count if termination occurred between local commit
  and journal clearing; 2.6.8 adds idempotent commit-target reconciliation.

CHANGES IN 2.6.6 (Download Guard metadata race)
- A download metadata event arriving while the first asynchronous guard check is running is no longer discarded.
  The newest browser-reported metadata is queued (bounded to 1,000 pending downloads) and rechecked after the
  first check completes. State changes also trigger a metadata refresh, allowing a completed download to be
  checked and removed if its final filename/type was not available at creation time.
- Regression test reproduces an early onCreated event followed by a risky filename arriving during the check;
  the test fails when the pending-event fix is removed.
- The no-HTTPS warning page's Back action now uses browser history or removes its current tab when no history exists.
- Startup compares persisted desired rules with live dynamic rules and repairs drift. Overlapping manual updates are coalesced into one follow-up run; abandoned updater markers are cleared after the recovery grace period. Graceful worker suspension flushes pending block counts.
- This narrows the race but cannot guarantee that every fast download is stopped before any bytes reach disk.

CHANGES IN 2.6.5 (pages blinked or stuttered with Strict / Third-Party Script Blocker on)
- Cause (from a user's Live Logger on usatoday.com): the Strict firewall and the Third-Party Script Blocker blocked scripts the
  page needs (jQuery, d3, Bootstrap, Mapbox, a consent manager, the site's own CDN). The page then half-rendered, retried and
  re-rendered, which shows as blinking. Not reproduced in a live browser.
- Strict exemptions (priority 30, https only, script/frame/XHR) now also cover code.jquery.com, cdnjs.cloudflare.com,
  stackpath/maxcdn.bootstrapcdn.com, d3js.org, api.mapbox.com and cdn.cookielaw.org. NOT exempt on purpose: cdn.jsdelivr.net,
  unpkg.com and polyfill hosts (anyone can publish there). A site's own separate CDN (for example gannett-cdn.com for
  usatoday.com) still counts as third-party: use Trust Site for such a site, or turn Strict off.
- Tests: 37 lists/rules/packaging groups, 4 page-script tests, 27 worker runtime tests.

CHANGES IN 2.6.4 (blocked pages flickered; now a stable warning page)
- Cause (from the rule set; Firefox not available for a live test): the built-in malware rules and the ad/tracker/imported
  list rules hard-blocked main-frame loads with no page to show. The browser was left with an aborted or blank load, and any
  page that retries made it blink. Every main-frame block now redirects to blocked.html; only sub-resources are still
  dropped silently. The warning page names the kind of block (threat list / your custom block / ad-tracker list /
  deceptive link / lookalike) and how to undo it. "Go back" closes the tab when there is no earlier page.
- Lookalike heuristic: the verdict no longer waits on a storage read (settings are cached), so the original page has no
  time to flash before the warning page replaces it.
- Tests: 36 lists/rules/packaging groups, 4 page-script tests, 26 worker runtime tests.
- Verified in Chromium (headless extension run: custom, list, threat, deceptive and lookalike each land on blocked.html).

CHANGES IN 2.6.3 (block-list updater fix)
- Auto-updating lists failed on every mirror with "NetworkError". The updater's downloads are third-party requests to the
  feed hosts, so Strict outbound firewall, the Third-Party Script Blocker, custom blocks or a list could block them.
  New priority-1002 allow rule: only requests started by the extension itself, only the fixed feed hosts, only
  xmlhttprequest/other. Page traffic is unaffected. (Cause inferred from the rule set; not reproduced in a live browser.)
- Fetch TypeErrors now end with "(blocked by a rule, offline, or site access not granted)".
- Firefox: grant "Access your data for all websites" or feeds without CORS headers (gitlab.io) still fail.
- Tests: 35 lists/rules/packaging groups, 3 page-script tests, 25 worker runtime tests (was 24).

CHANGES IN 2.6.2 (pentest follow-up; details: SECURITY_AUDIT_v2.6.2.txt)
- Feeds can no longer block 27 exact hosts of Google, Microsoft and Apple sign-in / mail / UI services (mail.google.com,
  accounts.google.com, www.google.com, login.microsoftonline.com, appleid.apple.com ...). The protection test now
  normalizes case and a trailing dot. User-content hosts (storage.googleapis.com, *.googleusercontent.com) stay blockable.
- Download Guard: .rdp .appinstaller .theme .themepack .website .hlp .command .terminal .scpt .scptd and more shell/disk-image
  types are Tier B; .zipx .lzma .bz .bzip2 .cpio .wim are Tier C; legacy Office, .xlsb, .pub and Access files are Tier D
  (raw-IP only, so ordinary documents from named hosts are unaffected).
- Lookalike heuristic: brands icloud, outlook, office365; more phishing keywords (share, review, renew, order, sign, ...);
  "brand.login-verify.example" and "brand.com-order-update.example" shapes are now seen. No false positives on the 87
  legitimate names in the test corpus.
- A second, different lookalike host in the same tab within 3 s of a redirect is now scored (before: skipped).
- Restored request logs honour the 500-tab cap and must carry a numeric time.
- Removed dead code: unused helper in options.js, duplicate alternation in the hosts-line regex.
- Tests: 35 lists/rules/packaging groups, 3 page-script tests, 24 worker runtime tests (was 32 / 3 / 22).

CHANGES IN 2.6.1
- Downloaded feeds can no longer block the Google UI hosts www.gstatic.com, ssl.gstatic.com, fonts.gstatic.com,
  apis.google.com and ogs.google.com (a feed line for one of them could break parts of Gmail, Chat and Meet).
  Exact hosts only: mail-ads.google.com and other ad hosts stay blockable; custom blocks are not filtered.
  Stale persisted feed entries for these hosts are dropped on the next start.

CHANGES IN 2.6.0 (rename, cleanup, hardening). Details: SECURITY_AUDIT_v2.6.0.txt
Security
- Downloaded feeds can no longer block registry suffixes such as co.uk or com.au (one bad feed line would
  otherwise block every site under the suffix).
- Extension-page CSP is now default-deny (default-src 'none', plus frame-src and worker-src).
- The block page disables its "review in Settings" button when a web page has put it in a frame.
- The no-HTTPS warning page and the worker both refuse targets that carry embedded credentials or exceed
  2,048 characters; the worker also checks the type and length of message fields before using them.
Cleanup
- Removed unused code: visualLabel and the cleanHost export, the SOURCES[].url field, an unused fetchOne
  parameter, a wrapper function and duplicated constants/age formatter in the popup and options page.
- Removed the stale 2.5.0 audit file and the duplicated changelog blocks; dist/ is no longer shipped inside
  the source zip (it is built, and shipped as the Chrome and Firefox zips).
Compatibility
- Settings exported by the old name still import.

Live-browser status: 2.7.0 was exercised in headless Chromium only (local pages, mapped hostnames). Firefox, and the
live adblock.turtlecute.org score, have not been tested.

EARLIER RELEASES (summary)
2.5.1  Feed repair: URLhaus and HaGeZi mirrors corrected (410/404), ordered mirror fallback, stale persisted
       entries can no longer block the updater's own hosts, last-known-good lists preserved on failure.
2.5.0  Settings page, new icon set, separate Chrome/Firefox manifests (tools/build.js), lookalike heuristic
       rewrite with false-positive fixes, redundant "tabs" permission removed, blocked.html parameters validated.
2.4.4  Deceptive-URL (userinfo) rule and local lookalike/homoglyph protection; six-hour default feed interval.
2.4.x  Memory and bounds hardening (log caps, streamed list parsing, session-rule cap), worker-side checks of
       the warning page, Trust Site no longer overrides downloaded threat lists, anchored LAN exemption,
       stricter Download Guard, same-host-only feed redirects, worker-restart resilience.

KNOWN LIMITS (not fixable in a browser extension)
- blocked.html is web-accessible (needed for redirects), so a site can detect that the extension is installed.
- A worker hard-killed within 0.5 s of a block can still lose that single count.
- Only the file name and MIME type the browser reports can be checked; archives are not opened.
- Block lists only know threats that were already reported. The lookalike heuristic can miss novel attacks
  and can produce false positives; its redirect is best-effort.
- This is a browser-layer filter. It does not replace an OS firewall or sandboxing, and it has had no
  independent penetration test or live-browser certification. The included tests run against a mocked
  browser API.
