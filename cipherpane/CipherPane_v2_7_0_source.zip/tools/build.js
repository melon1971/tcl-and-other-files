#!/usr/bin/env node
// CipherPane packager. Run from the project root:  node tools/build.js
// Reads manifest.json (the Chrome/Edge/Brave manifest), derives the Firefox manifest from it,
// validates that every referenced file exists, and writes clean installable folders to
//   dist/chrome/   and   dist/firefox/
// Only files the extension actually loads are copied (no tests, docs or tooling).
"use strict";
const fs = require("fs");
const path = require("path");
const ROOT = path.join(__dirname, "..");
const read = (f) => fs.readFileSync(path.join(ROOT, f), "utf8");
const problems = [];
const fail = (m) => problems.push(m);

const chrome = JSON.parse(read("manifest.json"));
if (chrome.manifest_version !== 3) fail("manifest_version must be 3");
if (!/^\d+(\.\d+){1,3}$/.test(chrome.version)) fail("bad version " + chrome.version);

// ---- Firefox manifest: event-page scripts instead of a service worker, no Chrome-only keys ----
const ff = JSON.parse(JSON.stringify(chrome));
ff.background = { scripts: ["lists.js", "reputation.js", "background.js"] };
delete ff.minimum_chrome_version;
for (const w of ff.web_accessible_resources || []) delete w.use_dynamic_url;
// Chrome's worker pulls its helpers in with importScripts; make the Chrome manifest honest about it.
if (!/importScripts\(\s*"lists\.js",\s*"reputation\.js"\s*\)/.test(read("background.js"))) fail("background.js must importScripts lists.js + reputation.js");

// ---- collect every file the extension loads ----
const files = new Set(["manifest.json"]);
const add = (f) => { if (f) files.add(f.replace(/^\//, "")); };
Object.values(chrome.icons || {}).forEach(add);
Object.values((chrome.action || {}).default_icon || {}).forEach(add);
add((chrome.action || {}).default_popup);
add((chrome.options_ui || {}).page);
add(chrome.background && chrome.background.service_worker);
ff.background.scripts.forEach(add);
((chrome.declarative_net_request || {}).rule_resources || []).forEach((r) => add(r.path));
for (const cs of chrome.content_scripts || []) { (cs.js || []).forEach(add); (cs.css || []).forEach(add); }
for (const w of chrome.web_accessible_resources || []) (w.resources || []).forEach(add);
// files registered at run time through chrome.scripting (not named in the manifest)
add("fingerprint.js");
// pages named in code (tabs.update / DNR redirects / getURL)
for (const f of ["background.js", "blocked.js", "nohttps.js", "options.js", "popup.js"]) {
  if (!fs.existsSync(path.join(ROOT, f))) continue;
  for (const m of read(f).matchAll(/(?:getURL\(|extensionPath:\s*)"\/?([\w.\/-]+\.(?:html|js|css|png|json))"/g)) add(m[1]);
}
// follow <script src> / <link href> inside every html file
for (const f of Array.from(files)) {
  if (!f.endsWith(".html") || !fs.existsSync(path.join(ROOT, f))) continue;
  for (const m of read(f).matchAll(/(?:src|href)="([^"#?:]+)"/g)) add(m[1]);
}
for (const f of files) if (!fs.existsSync(path.join(ROOT, f))) fail("missing file: " + f);

// ---- manifest sanity ----
const perms = chrome.permissions || [];
if (new Set(perms).size !== perms.length) fail("duplicate permission");
if (!(chrome.host_permissions || []).length) fail("no host_permissions");
const rr = (chrome.declarative_net_request || {}).rule_resources || [];
if (new Set(rr.map((r) => r.id)).size !== rr.length) fail("duplicate ruleset id");
for (const r of rr) {
  const rules = JSON.parse(read(r.path));
  const ids = rules.map((x) => x.id);
  if (new Set(ids).size !== ids.length) fail(r.path + ": duplicate rule ids");
  for (const x of rules) if (x.condition && x.condition.regexFilter) { try { new RegExp(x.condition.regexFilter); } catch (e) { fail(r.path + " rule " + x.id + ": bad regex"); } }
}
// CSP connect-src must cover every feed host
const csp = chrome.content_security_policy.extension_pages;
global.self = global; require(path.join(ROOT, "lists.js"));
for (const h of CipherLists.sourceHosts()) if (!csp.includes("https://" + h)) fail("CSP connect-src missing feed host " + h);
if (/'unsafe-(inline|eval)'/.test(csp)) fail("CSP allows unsafe-inline/eval");

if (problems.length) { console.error("BUILD FAILED:\n - " + problems.join("\n - ")); process.exit(1); }

function emit(name, manifest) {
  const out = path.join(ROOT, "dist", name);
  fs.rmSync(out, { recursive: true, force: true });
  for (const f of files) {
    if (f === "manifest.json") continue;
    const dst = path.join(out, f);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(path.join(ROOT, f), dst);
  }
  fs.mkdirSync(out, { recursive: true });
  fs.writeFileSync(path.join(out, "manifest.json"), JSON.stringify(manifest, null, 2) + "\n");
  console.log("wrote dist/" + name + " (" + files.size + " files)");
}
const cr = JSON.parse(JSON.stringify(chrome));
delete cr.browser_specific_settings;          // Firefox-only key
emit("chrome", cr);
emit("firefox", ff);
