// Fingerprint-script tests: runs fingerprint.js in a vm against minimal stub browser classes (not a real browser).
// Run: node tests/fingerprint.js   (also run by node tests/run.js)
"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const src = fs.readFileSync(path.join(__dirname, "..", "fingerprint.js"), "utf8");
let n = 0;
const pending = [];
const t = (name, fn) => {
  const r = fn();
  const done = () => { n++; console.log("ok -", name); };
  if (r && typeof r.then === "function") pending.push(r.then(done)); else done();
};

function makeWindow() {
  class Navigator { get hardwareConcurrency() { return 16; } get deviceMemory() { return 32; } }
  class CanvasRenderingContext2D {
    constructor(w, h) { this.w = w; this.h = h; }
    getImageData(x, y, w, h) { const d = new Uint8ClampedArray(w * h * 4); for (let i = 0; i < d.length; i += 4) { d[i] = 100; d[i + 1] = 150; d[i + 2] = 200; d[i + 3] = 255; } return { width: w, height: h, data: d }; }
    putImageData(img) { this.put = img; }
    drawImage() {}
  }
  class HTMLCanvasElement {
    constructor(w, h) { this.width = w; this.height = h; this._ctx = new CanvasRenderingContext2D(w, h); }
    getContext() { return this._ctx; }
    toDataURL() { return "data:" + (this._ctx.put ? Array.from(this._ctx.put.data).join(",") : "plain"); }
    toBlob(cb) { cb(this.toDataURL()); }
  }
  class WebGLRenderingContext {
    getParameter(p) { return p === 0x9245 ? "NVIDIA Corporation" : p === 0x9246 ? "NVIDIA GeForce RTX 9090" : "other:" + p; }
    readPixels(x, y, w, h, f, ty, dst) { dst.fill(120); }
  }
  class AudioBuffer { constructor() { this.ch = new Float32Array(1000); } getChannelData() { return this.ch; } copyFromChannel(d) { d.fill(0.25); } }
  class OfflineAudioContext { startRendering() { this.buf = new AudioBuffer(); return Promise.resolve(this.buf); } }
  class AnalyserNode { getFloatFrequencyData(a) { a.fill(-50); } }
  const created = [];
  const document = { createElement: () => { const c = new HTMLCanvasElement(0, 0); created.push(c); return c; } };
  class Document { createElement() { return document.createElement(); } }
  const win = { Navigator, CanvasRenderingContext2D, HTMLCanvasElement, WebGLRenderingContext, AudioBuffer, OfflineAudioContext, AnalyserNode, Document,
                crypto: { getRandomValues: (a) => { a[0] = 12345; return a; } }, Uint32Array, Uint8Array, Float32Array, WeakMap, WeakSet, Math, Object, Function };
  win.window = win;
  win.document = document;
  win.Document.prototype.createElement = () => new HTMLCanvasElement(0, 0);
  const ctx = vm.createContext(win);
  ctx.Function = Function;
  vm.runInContext(src, ctx, { filename: "fingerprint.js" });
  return win;
}

const diff = (a, b) => { let d = 0; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) d++; return d; };

t("hardware: core count capped at 4, memory generic", () => {
  const w = makeWindow();
  const nav = new w.Navigator();
  assert.strictEqual(nav.hardwareConcurrency, 4);
  assert.strictEqual(nav.deviceMemory, 8);
});
t("canvas getImageData: small canvases get sparse +-1 noise, alpha untouched, repeatable; large canvases untouched", () => {
  const w = makeWindow();
  const ctx = new w.CanvasRenderingContext2D(100, 100);
  const a = ctx.getImageData(0, 0, 100, 100), b = ctx.getImageData(0, 0, 100, 100);
  const base = ctx.constructor.prototype; // patched
  let changed = 0, maxDelta = 0;
  const ref = [100, 150, 200];
  for (let i = 0; i < a.data.length; i += 4) {
    assert.strictEqual(a.data[i + 3], 255, "alpha");
    for (let c = 0; c < 3; c++) { const dlt = Math.abs(a.data[i + c] - ref[c]); if (dlt) { changed++; maxDelta = Math.max(maxDelta, dlt); } }
  }
  assert(changed > 100 && changed < 1000, "sparse noise, got " + changed);
  assert.strictEqual(maxDelta, 1);
  assert.strictEqual(diff(a.data, b.data), 0, "same read twice must be identical");
  const big = ctx.getImageData(0, 0, 600, 600);
  assert.strictEqual(big.data[0], 100); assert.strictEqual(diff(big.data, big.data.map((_, i) => [100, 150, 200, 255][i % 4])), 0, "large canvas untouched");
});
t("canvas toDataURL/toBlob: output differs from the real one for small canvases, page canvas itself is not modified, large unchanged", () => {
  const w = makeWindow();
  const c = new w.HTMLCanvasElement(64, 64);
  const url = c.toDataURL();
  assert(url.startsWith("data:") && url !== "data:plain", "noisy copy used");
  assert.strictEqual(c._ctx.put, undefined, "original canvas must not be modified");
  let blob; c.toBlob((x) => { blob = x; });
  assert.strictEqual(blob, url, "toBlob and toDataURL agree");
  const big = new w.HTMLCanvasElement(800, 800);
  assert.strictEqual(big.toDataURL(), "data:plain");
});
t("WebGL: unmasked vendor/renderer generic, other parameters untouched, small readPixels perturbed", () => {
  const w = makeWindow();
  const gl = new w.WebGLRenderingContext();
  assert.strictEqual(gl.getParameter(0x9245), "Google Inc.");
  assert.strictEqual(gl.getParameter(0x9246), "ANGLE (Generic Renderer)");
  assert.strictEqual(gl.getParameter(0x1234), "other:4660");
  const px = new Uint8Array(32 * 32 * 4);
  gl.readPixels(0, 0, 32, 32, 0x1908, 0x1401, px);
  assert(px.some(v => v !== 120) && px.every(v => Math.abs(v - 120) <= 1));
  const big = new Uint8Array(4); gl.readPixels(0, 0, 1000, 1000, 0x1908, 0x1401, big);
  assert(big.every(v => v === 120));
});
t("audio: only offline-rendered buffers are perturbed, tiny magnitude, repeatable; analyser data nudged slightly", async () => {
  const w = makeWindow();
  const live = new w.AudioBuffer();
  assert(live.getChannelData(0).every(v => v === 0), "live buffers are not touched");
  const ctx = new w.OfflineAudioContext();
  const buf = await ctx.startRendering();
  const ch = buf.getChannelData(0);
  assert(ch.some(v => v !== 0) && ch.every(v => Math.abs(v) < 2e-7));
  const again = Array.from(buf.getChannelData(0));
  assert.deepStrictEqual(Array.from(ch), again, "noise applied once, repeat reads identical");
  const an = new w.AnalyserNode(); const f = new Float32Array(64); an.getFloatFrequencyData(f);
  assert(f.some(v => v !== -50) && f.every(v => Math.abs(v + 50) < 0.02));
});
t("patched functions report as native code", () => {
  const w = makeWindow();
  const s = Function.prototype.toString.call(w.HTMLCanvasElement.prototype.toDataURL);
  assert.strictEqual(s, "function toDataURL() { [native code] }");
});
t("running twice does not double-wrap", () => {
  const w = makeWindow();
  const first = w.HTMLCanvasElement.prototype.toDataURL;
  vm.runInContext(src, vm.createContext(w));   // same window object: guard flag stops a second pass
  assert.strictEqual(w.HTMLCanvasElement.prototype.toDataURL, first);
});
Promise.all(pending).then(() => console.log("\n" + n + " fingerprint tests passed")).catch(e => { console.error("FINGERPRINT TEST FAILED:", e); process.exitCode = 1; });
