// Page-script tests: runs blocked.js and nohttps.js against a minimal stub DOM (not a real browser).
// Run: node tests/pages.js   (also run by node tests/run.js)
"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const read = (f) => fs.readFileSync(path.join(__dirname, "..", f), "utf8");

function run(file, search, { framed = false, ids = [], historyLength = 1 } = {}) {
  const els = {};
  const removed = [];
  let backCount = 0;
  let closeCount = 0;
  const el = (id) => els[id] || (els[id] = { id, hidden: id === "allowBtn", disabled: false, textContent: "", listeners: {},
    addEventListener(t, f) { this.listeners[t] = f; }, classList: { add() {}, toggle() {} } });
  const card = { insertBefore() {} };
  const win = { close() { closeCount++; } };
  win.self = win;
  win.top = framed ? {} : win;
  const created = [];
  const sent = [];
  const ctx = vm.createContext({
    URL, URLSearchParams, encodeURIComponent, decodeURIComponent, console, Error, Promise,
    window: win, history: { length: historyLength, back() { backCount++; } },
    location: { search, replace() {}, href: "chrome-extension://abc/x.html" + search },
    document: {
      getElementById: el,
      querySelector: (q) => (q === ".card" ? card : q === ".card > p" ? { textContent: "" } : null),
      createElement: () => ({ className: "", textContent: "" })
    },
    chrome: {
      runtime: { getURL: (p) => "chrome-extension://abc/" + p, sendMessage: async (m) => { sent.push(m); return { ok: true }; } },
      tabs: {
        create: (o) => created.push(o),
        getCurrent: async () => ({ id: 12 }),
        remove: async (id) => { removed.push(id); }
      }
    }
  });
  vm.runInContext(read(file), ctx, { filename: file });
  return { el, created, sent, removed, get backCount() { return backCount; }, get closeCount() { return closeCount; } };
}

let n = 0;
const pending = [];
const t = (name, fn) => {
  const result = fn();
  if (result && typeof result.then === "function") {
    pending.push(result.then(() => { n++; console.log("ok -", name); }));
  } else { n++; console.log("ok -", name); }
};

t("blocked.js: 'review in Settings' appears only for a valid host on a top-level page", () => {
  const q = "?reason=lookalike&host=paypa1.com&detail=" + encodeURIComponent("look-alike characters imitating paypal");
  const top = run("blocked.js", q);
  assert.strictEqual(top.el("allowBtn").hidden, false);
  top.el("allowBtn").listeners.click();
  assert.strictEqual(top.created.length, 1);
  assert(top.created[0].url.endsWith("options.html#allow=paypa1.com"));
  const framed = run("blocked.js", q, { framed: true });
  assert.strictEqual(framed.el("allowBtn").hidden, true, "button must stay hidden inside a frame");
  const badHost = run("blocked.js", "?reason=lookalike&host=" + encodeURIComponent("<img src=x onerror=alert(1)>"));
  assert.strictEqual(badHost.el("allowBtn").hidden, true);
  const noReason = run("blocked.js", "?host=paypa1.com");
  assert.strictEqual(noReason.el("allowBtn").hidden, true);
});

t("blocked.js: every reason shows fixed text; unknown reasons keep the default; back button never throws without history", () => {
  for (const r of ["threat", "custom", "list", "deceptive", "lookalike"]) {
    const x = run("blocked.js", "?reason=" + r);
    assert(x.el("title").textContent.length > 5, r);
    assert(x.el("desc").textContent.length > 20, r);
    assert.strictEqual(x.el("allowBtn").hidden, true, r + " must not offer Allow without a host");
  }
  const bad = run("blocked.js", "?reason=__proto__");
  assert.strictEqual(bad.el("title").textContent, "");
  const x = run("blocked.js", "?reason=list");
  x.el("backBtn").listeners.click();
});

t("nohttps.js: credentials and oversized targets disable both continue buttons", () => {
  const good = run("nohttps.js", "?u=" + encodeURIComponent("http://a.example.com/") + "&s=1");
  assert.strictEqual(good.el("onceBtn").disabled, false);
  assert.strictEqual(good.el("hostName").textContent, "a.example.com");
  for (const u of ["http://user:pw@a.example.com/", "http://user@a.example.com/", "http://a.example.com/" + "x".repeat(3000), "https://a.example.com/", "javascript:alert(1)"]) {
    const r = run("nohttps.js", "?u=" + encodeURIComponent(u) + "&s=1");
    assert.strictEqual(r.el("onceBtn").disabled, true, u.slice(0, 40));
    assert.strictEqual(r.el("alwaysBtn").disabled, true, u.slice(0, 40));
  }
});

t("nohttps.js: Back navigates history or closes the current tab when history is empty", async () => {
  const noHistory = run("nohttps.js", "?u=" + encodeURIComponent("http://a.example.com/") + "&s=1");
  await noHistory.el("backBtn").listeners.click();
  assert.deepStrictEqual(noHistory.removed, [12]);
  const hasHistory = run("nohttps.js", "?u=" + encodeURIComponent("http://a.example.com/") + "&s=1", { historyLength: 2 });
  await hasHistory.el("backBtn").listeners.click();
  assert.strictEqual(hasHistory.backCount, 1);
  assert.deepStrictEqual(hasHistory.removed, []);
});

t("nohttps.js: 'always' stays disabled unless the failure was a refusal or timeout (s=1)", () => {
  const weak = run("nohttps.js", "?u=" + encodeURIComponent("http://a.example.com/") + "&s=0");
  assert.strictEqual(weak.el("alwaysBtn").disabled, true);
  assert.strictEqual(weak.el("onceBtn").disabled, false);
});

Promise.all(pending).then(() => console.log("\n" + n + " page-script tests passed")).catch(e => {
  console.error("PAGE TEST FAILED:", e);
  process.exitCode = 1;
});
