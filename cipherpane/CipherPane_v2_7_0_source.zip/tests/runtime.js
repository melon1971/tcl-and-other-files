// Runtime tests: loads the real background.js in a vm against a mocked `chrome` API, plus the
// streaming list parser. Run: node tests/runtime.js   (also run by node tests/run.js). No dependencies.
// These are unit/integration tests against a mock, not a browser test.
"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.join(__dirname, "..");
const read = f => fs.readFileSync(path.join(ROOT, f), "utf8");
const clone = x => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
const tick = (ms = 15) => new Promise(r => setTimeout(r, ms));
let passed = 0;
async function t(name, fn) { await fn(); passed++; console.log("ok -", name); }

// ---------------------------------------------------------------- chrome mock
function makeEnv(fetchImpl, opts) {
  opts = opts || {};
  const local = Object.assign({}, opts.local || {}), session = Object.assign({}, opts.session || {});
  const tabUpdates = [];
  const SESSION_QUOTA = 10 * 1024 * 1024;
  const area = (store, quota) => ({
    store,
    async get(keys) {
      if (store === local && opts.downloadGate &&
          (keys === "downloadGuard" || (Array.isArray(keys) && keys.includes("downloadGuard")) ||
           (keys && typeof keys === "object" && Object.prototype.hasOwnProperty.call(keys, "downloadGuard")))) {
        await opts.downloadGate;
      }
      if (keys == null) return clone(store);
      const out = {};
      if (typeof keys === "string") keys = [keys];
      if (Array.isArray(keys)) { for (const k of keys) if (k in store) out[k] = clone(store[k]); }
      else for (const k of Object.keys(keys)) out[k] = k in store ? clone(store[k]) : keys[k];
      return out;
    },
    async set(o) {
      const next = { ...store, ...clone(o) };
      if (quota && JSON.stringify(next).length > quota) throw new Error("QUOTA_BYTES quota exceeded");
      Object.assign(store, clone(o));
    }
  });
  const ev = () => { const fns = []; return { addListener(f) { fns.push(f); }, fns }; };
  const sessionRules = [];
  const dynamicSyncCalls = [];
  const dynamicRules = clone(opts.dynamicRules || []);
  const downloadCalls = { cancel: [], removeFile: [], erase: [] };
  const rulesetCalls = [];
  const registered = [];
  const chrome = {
    runtime: { id: "abc", getURL: p => "chrome-extension://abc/" + p, onMessage: ev(), onInstalled: ev(), onStartup: ev(), onSuspend: ev() },
    storage: { local: area(local), session: area(session, SESSION_QUOTA), onChanged: ev() },
    tabs: { query: async () => opts.tabs || [{ id: 1 }, { id: 2 }, { id: 5 }], update: async (id, p) => { tabUpdates.push([id, p && p.url]); }, onRemoved: ev(), onUpdated: ev() },
    webNavigation: { onBeforeNavigate: ev() },
    webRequest: { onCompleted: ev(), onErrorOccurred: ev(), onBeforeRedirect: ev() },
    downloads: {
      onCreated: ev(), onChanged: ev(),
      cancel: async id => { downloadCalls.cancel.push(id); },
      removeFile: async id => { downloadCalls.removeFile.push(id); },
      erase: async q => { downloadCalls.erase.push(q.id); },
      search: async q => opts.downloadSearch ? [clone(opts.downloadSearch(q.id))].filter(Boolean) : [],
      download: async () => 1
    },
    alarms: { get: async () => undefined, create: async () => {}, clear: async () => {}, onAlarm: ev() },
    action: { setBadgeText() {}, setBadgeBackgroundColor() {}, getBadgeText: async () => "" },
    declarativeNetRequest: {
      sessionRules,
      getSessionRules: async () => clone(sessionRules),
      updateSessionRules: async ({ removeRuleIds = [], addRules = [] }) => {
        for (const id of removeRuleIds) { const i = sessionRules.findIndex(r => r.id === id); if (i >= 0) sessionRules.splice(i, 1); }
        sessionRules.push(...clone(addRules));
      },
      getDynamicRules: async () => clone(dynamicRules),
      updateDynamicRules: async (args) => {
        dynamicSyncCalls.push(clone(args));
        for (const id of (args.removeRuleIds || [])) {
          const i = dynamicRules.findIndex(r => r.id === id);
          if (i >= 0) dynamicRules.splice(i, 1);
        }
        dynamicRules.push(...clone(args.addRules || []));
      },
      updateEnabledRulesets: async (a) => { rulesetCalls.push(clone(a)); }
    }
  };
  if (opts.scripting) {
    chrome.scripting = {
      getRegisteredContentScripts: async ({ ids } = {}) => clone(registered.filter(s => !ids || ids.includes(s.id))),
      registerContentScripts: async (list) => { for (const s of list) { if (registered.some(x => x.id === s.id)) throw new Error("duplicate id"); if (opts.scripting === "noFallback" && s.matchOriginAsFallback) throw new Error("matchOriginAsFallback unsupported"); registered.push(clone(s)); } },
      unregisterContentScripts: async ({ ids } = {}) => { for (const id of ids || []) { const i = registered.findIndex(s => s.id === id); if (i >= 0) registered.splice(i, 1); } }
    };
  }
  const ctx = vm.createContext({ console: { log() {}, warn() {}, error() {} }, URL, URLSearchParams, TextEncoder, TextDecoder,
    setTimeout, clearTimeout, AbortController, Response, fetch: fetchImpl || (async () => { throw new Error("no network in tests"); }), chrome });
  ctx.self = ctx;
  vm.runInContext(read("lists.js"), ctx, { filename: "lists.js" });
  vm.runInContext(read("reputation.js"), ctx, { filename: "reputation.js" });
  vm.runInContext(read("background.js"), ctx, { filename: "background.js" });
  const POPUP = "chrome-extension://abc/popup.html";
  const send = (msg, senderUrl = POPUP, id = "abc") => new Promise(res => {
    const handled = chrome.runtime.onMessage.fns[0](msg, { id, url: senderUrl }, res);
    if (handled !== true) res(undefined);   // handler declined (returned false): no response
  });
  return { chrome, local, session, sessionRules, rulesetCalls, registered, dynamicRules, dynamicSyncCalls, downloadCalls, tabUpdates, send, ctx, POPUP };
}
const NOHTTPS = (host, s) => `chrome-extension://abc/nohttps.html?u=${encodeURIComponent("http://" + host + "/")}&s=${s}`;

(async () => {
  // ------------------------------------------------------------ CP-01/02/03 remediation regressions
  await t("Download Guard approval is consumed once, not reusable", async () => {
    const env = makeEnv(null, { session: { blockedDownloads: [{ id: "once", url: "https://files.example/setup.scr", name: "setup.scr", canAllow: true }] } });
    const response = await env.send({ type: "ALLOW_DOWNLOAD", id: "once" });
    assert.strictEqual(response.ok, true);
    await tick(20);
    env.chrome.downloads.onCreated.fns[0]({ id: 51, url: "https://files.example/setup.scr", filename: "/tmp/setup.scr", mime: "application/x-msdownload" });
    await tick(20);
    env.chrome.downloads.onCreated.fns[0]({ id: 52, url: "https://files.example/setup.scr", filename: "/tmp/setup.scr", mime: "application/x-msdownload" });
    await tick(40);
    assert.deepStrictEqual(env.downloadCalls.cancel, [52]);
  });

  await t("request logger redacts sensitive URL paths to origin only", async () => {
    const env = makeEnv();
    env.chrome.webRequest.onCompleted.fns[0]({ tabId: 5, type: "main_frame", url: "https://account.example/reset/SECRET-TOKEN?x=secret" });
    const res = await env.send({ type: "GET_TAB_LOGS", tabId: 5 });
    assert.strictEqual(res.logs[0].url, "https://account.example/");
    assert(!JSON.stringify(res.logs).includes("SECRET-TOKEN"));
  });

  await t("blocked counter journal is persisted for worker restart recovery", async () => {
    const env = makeEnv();
    env.chrome.webRequest.onErrorOccurred.fns[0]({ tabId: 5, type: "script", url: "https://blocked.example/a", error: "net::ERR_BLOCKED_BY_CLIENT" });
    await tick(30);
    assert.strictEqual(env.session.pendingBlockedCount, 1);
    const restarted = makeEnv(null, { local: env.local, session: env.session });
    await tick(50);
    assert.strictEqual(restarted.local.blockedCount, 1);
    assert.strictEqual(restarted.session.pendingBlockedCount, 0);
  });

  await t("blocked counter recovery is idempotent after local commit but before journal clear", async () => {
    const env = makeEnv(null, { local: { blockedCount: 1 }, session: { pendingBlockedCount: 0, pendingBlockedTarget: 1 } });
    await tick(50);
    assert.strictEqual(env.local.blockedCount, 1, "recovery must not duplicate the already committed target");
    assert.strictEqual(env.session.pendingBlockedTarget, 0, "target marker cleared after reconciliation");
  });

  // ------------------------------------------------------------ graceful suspend / stale updater recovery
  await t("graceful worker suspend flushes pending blocked counts", async () => {
    const env = makeEnv();
    env.chrome.webRequest.onErrorOccurred.fns[0]({
      tabId: 5, type: "script", url: "https://blocked.example/a", error: "net::ERR_BLOCKED_BY_CLIENT"
    });
    env.chrome.runtime.onSuspend.fns[0]();
    await tick(40);
    assert.strictEqual(env.local.blockedCount, 1);
  });

  await t("worker startup clears an abandoned updater running marker", async () => {
    const env = makeEnv(null, { local: { autoListMeta: { running: Date.now() - 300000, lastRun: 1 } } });
    await tick(50);
    assert.strictEqual(env.local.autoListMeta.running, 0);
  });

  await t("overlapping manual updater requests coalesce into one follow-up run", async () => {
    let releaseFirst;
    let firstStarted;
    const started = new Promise(resolve => { firstStarted = resolve; });
    const firstGate = new Promise(resolve => { releaseFirst = resolve; });
    let calls = 0;
    const fetchImpl = async () => {
      calls++;
      if (calls === 1) { firstStarted(); await firstGate; }
      return new Response("0.0.0.0 tracker.example.com\n", {
        status: 200, headers: { "content-type": "text/plain", "etag": "v1" }
      });
    };
    const env = makeEnv(fetchImpl);
    env.local.sourceEnabled = { urlhaus: false, phishing: false, hagezi_light: false, stevenblack: true };
    await env.send({ type: "UPDATE_LISTS_NOW" });
    await started;
    await env.send({ type: "UPDATE_LISTS_NOW" });
    releaseFirst();
    await tick(700);
    assert(calls >= 2,
      "second run should execute after the active update rather than being lost");
  });

  // ------------------------------------------------------------ worker-start rule drift
  await t("worker startup repairs stale dynamic rules", async () => {
    const env = makeEnv(null, { dynamicRules: [{ id: 999999, priority: 1, action: { type: "block" },
      condition: { urlFilter: "||stale.example^", resourceTypes: ["main_frame"] } }] });
    await tick(60);
    assert(env.dynamicSyncCalls.length > 0);
    assert(env.dynamicSyncCalls[0].removeRuleIds.includes(999999));
    assert(env.dynamicRules.some(r => r.id !== 999999));
  });

  // ------------------------------------------------------------ download metadata race
  await t("Download Guard rechecks newest metadata received while an earlier check is busy", async () => {
    let release;
    const gate = new Promise(resolve => { release = resolve; });
    let latest = { id: 77, url: "https://files.example/download", finalUrl: "https://files.example/download",
      filename: "download", mime: "application/octet-stream" };
    const env = makeEnv(null, { downloadGate: gate, downloadSearch: () => latest });
    env.local.downloadGuard = "balanced";
    const created = env.chrome.downloads.onCreated.fns[0];
    const changed = env.chrome.downloads.onChanged.fns[0];
    created({ id: 77, url: latest.url, finalUrl: latest.finalUrl, filename: "download", mime: "" });
    await tick();
    latest = { ...latest, filename: "invoice.pdf.exe" };
    changed({ id: 77, filename: { current: latest.filename } });
    release();
    await tick(40);
    assert.deepStrictEqual(env.downloadCalls.cancel, [77]);
    assert.deepStrictEqual(env.downloadCalls.removeFile, [77]);
  });

  // ------------------------------------------------------------ request log bounds
  await t("log entries are length-bounded and per-tab capped", async () => {
    const env = makeEnv();
    const done = env.chrome.webRequest.onCompleted.fns[0];
    for (let i = 0; i < 400; i++)
      done({ tabId: 5, type: "script", url: "https://a.example/" + "x".repeat(200000) + "?q=" + i });
    const r = await env.send({ type: "GET_TAB_LOGS", tabId: 5 });
    assert.strictEqual(r.logs.length, 150);
    assert(r.logs.every(e => e.url.length <= 512 && e.host.length <= 253));
  });

  await t("tab count is capped; negative ids ignored; clear cannot create entries", async () => {
    const env = makeEnv();
    const done = env.chrome.webRequest.onCompleted.fns[0];
    done({ tabId: -1, type: "image", url: "https://a.example/x" });
    for (let id = 0; id < 1500; id++) done({ tabId: id, type: "image", url: "https://a.example/" + "y".repeat(300) });
    await env.send({ type: "CLEAR_TAB_LOGS", tabId: 99999999 });
    env.chrome.runtime.onSuspend.fns[0]();
    await tick();
    const saved = env.session.tabLogs;
    const keys = Object.keys(saved);
    assert(keys.length <= 500, "kept " + keys.length);
    assert(!("-1" in saved) && !("99999999" in saved));
    assert(JSON.stringify(saved).length < 4.6 * 1024 * 1024);
  });

  await t("flush stays inside the session quota even with worst-case entries", async () => {
    const env = makeEnv();
    const done = env.chrome.webRequest.onCompleted.fns[0];
    for (let id = 0; id < 500; id++)
      for (let i = 0; i < 150; i++) done({ tabId: id, type: "websocket", url: "https://" + "h".repeat(60) + ".example/" + "z".repeat(900) });
    let rejected = false;
    const origSet = env.chrome.storage.session.set;
    env.chrome.storage.session.set = async o => { try { return await origSet(o); } catch (e) { rejected = true; throw e; } };
    env.chrome.runtime.onSuspend.fns[0]();
    await tick(50);
    assert(!rejected, "log write exceeded the session quota");
    assert(Object.keys(env.session.tabLogs || {}).length > 0);
  });

  await t("log requests and popup-only messages from other pages are refused", async () => {
    const env = makeEnv();
    assert.strictEqual(await env.send({ type: "GET_TAB_LOGS", tabId: 1 }, NOHTTPS("a.example", 1)), undefined);
    assert.strictEqual(await env.send({ type: "GET_TAB_LOGS", tabId: 1 }, env.POPUP, "someone-else"), undefined);
    assert.strictEqual(await env.send({ type: "GET_TAB_LOGS", tabId: -5 }), undefined);
    assert.strictEqual(await env.send({ type: "GET_TAB_LOGS", tabId: 1.5 }), undefined);
  });

  // ------------------------------------------------------------ HTTP fallback gate
  await t("ALLOW_HTTP: session rules are capped, newest kept, oldest evicted", async () => {
    const env = makeEnv();
    for (let i = 0; i < 260; i++) {
      const host = `h${i}.example.com`;
      const r = await env.send({ type: "ALLOW_HTTP", host, mode: "session" }, NOHTTPS(host, 0));
      assert(r && r.ok, host);
    }
    assert(env.sessionRules.length <= 200, "rules: " + env.sessionRules.length);
    const filters = env.sessionRules.map(r => r.condition.urlFilter);
    assert(filters.includes("|http://h259.example.com^"));
    assert(!filters.includes("|http://h0.example.com^"));
  });

  await t("ALLOW_HTTP: host must match the warning page's own URL", async () => {
    const env = makeEnv();
    const r = await env.send({ type: "ALLOW_HTTP", host: "evil.example.com", mode: "session" }, NOHTTPS("a.example.com", 1));
    assert.strictEqual(r.ok, false);
    assert.strictEqual(env.sessionRules.length, 0);
  });

  await t("ALLOW_HTTP: 'always' needs the page to have offered it (s=1); modes are validated", async () => {
    const env = makeEnv();
    let r = await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "always" }, NOHTTPS("a.example.com", 0));
    assert.strictEqual(r.ok, false);
    r = await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "forever" }, NOHTTPS("a.example.com", 1));
    assert.strictEqual(r.ok, false);
    r = await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "always" }, NOHTTPS("a.example.com", 1));
    assert.strictEqual(r.ok, true);
    assert.deepStrictEqual(Array.from(env.local.httpAllowedDomains), ["a.example.com"]);
  });

  await t("ALLOW_HTTP is refused from the popup and from foreign senders", async () => {
    const env = makeEnv();
    assert.strictEqual(await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "session" }, env.POPUP), undefined);
    assert.strictEqual(await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "session" }, NOHTTPS("a.example.com", 1), "other-ext"), undefined);
  });

  await t("ALLOW_HTTP: warning-page URL with embedded credentials or an oversized target is refused", async () => {
    const env = makeEnv();
    const withCreds = `chrome-extension://abc/nohttps.html?u=${encodeURIComponent("http://user:pw@a.example.com/")}&s=1`;
    assert.strictEqual((await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "session" }, withCreds)).ok, false);
    const huge = `chrome-extension://abc/nohttps.html?u=${encodeURIComponent("http://a.example.com/" + "x".repeat(3000))}&s=1`;
    assert.strictEqual((await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "session" }, huge)).ok, false);
    assert.strictEqual(env.sessionRules.length, 0);
  });

  await t("message payloads must have the right shape (non-string host / id refused)", async () => {
    const env = makeEnv();
    const sneaky = { toString() { return "a.example.com"; } };
    assert.strictEqual((await env.send({ type: "ALLOW_HTTP", host: sneaky, mode: "session" }, NOHTTPS("a.example.com", 1))).ok, false);
    assert.strictEqual((await env.send({ type: "ALLOW_HTTP", host: "a".repeat(300) + ".com", mode: "session" }, NOHTTPS("a.example.com", 1))).ok, false);
    assert.strictEqual((await env.send({ type: "ALLOW_DOWNLOAD", id: { toString() { return "x"; } } }, env.POPUP)).ok, false);
    assert.strictEqual((await env.send({ type: "ALLOW_DOWNLOAD", id: "x".repeat(65) }, env.POPUP)).ok, false);
    assert.strictEqual(env.sessionRules.length, 0);
  });

  await t("new-install feed schedule defaults to six hours", async () => {
    const env = makeEnv();
    assert.strictEqual(vm.runInContext("DEFAULT_STATE.autoUpdateHours", env.ctx), 6);
    assert.strictEqual(vm.runInContext("clampHours(undefined)", env.ctx), 6);
  });

  // ------------------------------------------------------------ local URL heuristic
  await t("local URL heuristic blocks authority userinfo without network lookups", async () => {
    const env = makeEnv();
    const rules = vm.runInContext("buildRules(DEFAULT_STATE, false)", env.ctx);
    const suspicious = rules.filter(r => r.condition && r.condition.regexFilter === "^https?://[^/?#]*@");
    assert.strictEqual(suspicious.length, 2);
    assert(suspicious.some(r => r.condition.resourceTypes.includes("main_frame") &&
      r.action.type === "redirect"));
    assert(suspicious.some(r => r.condition.resourceTypes.includes("script") &&
      r.action.type === "block"));
    const re = new RegExp(suspicious[0].condition.regexFilter, "i");
    assert(re.test("https://trusted.example@attacker.test/login"));
    assert(!re.test("https://trusted.example/login"));
    assert(!re.test("https://attacker.test/path?next=user@example.test"));
  });

  // ------------------------------------------------------------ v2.7.0
  await t("cookielaw: allowed by default; optional block sits at priority 50 (above Strict exemption, below Trust Site)", async () => {
    const env = makeEnv();
    const build = (extra) => vm.runInContext("buildRules(Object.assign({}, DEFAULT_STATE, " + extra + "), false)", env.ctx);
    assert(!build("{}").some(r => (r.condition.requestDomains || []).includes("cdn.cookielaw.org") && r.action.type === "block"));
    assert.strictEqual(vm.runInContext("DEFAULT_STATE.blockCookieLaw", env.ctx), false);
    const on = build("{ blockCookieLaw: true, strictFirewallMode: true, trustedDomains: ['t.example.com'] }");
    const blk = on.find(r => r.action.type === "block" && (r.condition.requestDomains || []).includes("cdn.cookielaw.org"));
    assert(blk && blk.priority === 50 && !blk.condition.resourceTypes.includes("main_frame"));
    assert(blk.priority > 30 && blk.priority < 100);
    assert(on.some(r => r.priority === 100 && r.action.type === "allow"), "Trust Site rules still present above it");
  });

  await t("fingerprint script: registered in MAIN world at document_start (default on), trusted sites excluded, off removes it", async () => {
    const env = makeEnv(null, { scripting: true });
    await tick(60);   // let the worker's own startup sync finish (production only ever calls syncAllRules through the serialized queueSync)
    env.registered.length = 0;
    await vm.runInContext("syncAllRules(Object.assign({}, DEFAULT_STATE, { trustedDomains: ['ok.example.com'] }))", env.ctx);
    assert.strictEqual(env.registered.length, 1);
    const s = env.registered[0];
    assert.deepStrictEqual(s.js, ["fingerprint.js"]);
    assert.strictEqual(s.world, "MAIN"); assert.strictEqual(s.runAt, "document_start"); assert.strictEqual(s.allFrames, true);
    assert.deepStrictEqual(s.matches, ["http://*/*", "https://*/*"]);
    assert.deepStrictEqual(s.excludeMatches, ["*://*.ok.example.com/*"]);
    // trusted list changes -> re-registered with the new exclusions; unchanged -> left alone
    await vm.runInContext("syncAllRules(Object.assign({}, DEFAULT_STATE, { trustedDomains: ['ok.example.com', 'b.example.org'] }))", env.ctx);
    assert.deepStrictEqual(env.registered[0].excludeMatches, ["*://*.ok.example.com/*", "*://*.b.example.org/*"]);
    await vm.runInContext("syncAllRules(Object.assign({}, DEFAULT_STATE, { fingerprintProtection: false }))", env.ctx);
    assert.strictEqual(env.registered.length, 0);
  });

  await t("fingerprint script: falls back when matchOriginAsFallback is unsupported; missing scripting API does not break rule sync", async () => {
    const env = makeEnv(null, { scripting: "noFallback" });
    await tick(60);
    env.registered.length = 0;
    await vm.runInContext("syncAllRules(Object.assign({}, DEFAULT_STATE, {}))", env.ctx);
    assert.strictEqual(env.registered.length, 1);
    assert(!("matchOriginAsFallback" in env.registered[0]));
    const bare = makeEnv();
    await vm.runInContext("syncAllRules(Object.assign({}, DEFAULT_STATE, {}))", bare.ctx);
    assert(bare.dynamicSyncCalls.length >= 1, "dynamic rules still synced");
  });

  await t("ad-image ruleset: enabled only when the ad blocker AND the option are on", async () => {
    const env = makeEnv();
    const last = async (extra) => {
      env.rulesetCalls.length = 0;
      await vm.runInContext("syncAllRules(Object.assign({}, DEFAULT_STATE, " + extra + "))", env.ctx);
      return env.rulesetCalls[env.rulesetCalls.length - 1];
    };
    let c = await last("{}"); assert(c.disableRulesetIds.includes("ad_images_rules") && !c.enableRulesetIds.includes("ad_images_rules"));
    c = await last("{ adImageFilter: true }"); assert(c.enableRulesetIds.includes("ad_images_rules"));
    c = await last("{ adImageFilter: true, adsEnabled: false }"); assert(c.disableRulesetIds.includes("ad_images_rules"));
  });

  // ------------------------------------------------------------ v2.6.5
  await t("strict mode: library-CDN exemption (priority 30) exists, https-only, script/frame/XHR types, below the updater rule", async () => {
    const env = makeEnv();
    const state = "Object.assign({}, DEFAULT_STATE, { strictFirewallMode: true, blockThirdPartyScripts: true })";
    const rules = vm.runInContext("buildRules(" + state + ", false)", env.ctx);
    const allow30 = rules.filter(r => r.priority === 30 && r.action.type === "allow");
    const hosts = new Set(); for (const r of allow30) for (const d of (r.condition.requestDomains || [])) hosts.add(d);
    for (const h of ["code.jquery.com", "cdnjs.cloudflare.com", "d3js.org", "cdn.cookielaw.org"]) assert(hosts.has(h), h);
    for (const h of ["cdn.jsdelivr.net", "unpkg.com"]) assert(!hosts.has(h), h);
    for (const r of allow30.filter(r => (r.condition.requestDomains || []).includes("code.jquery.com"))) {
      assert.strictEqual(r.condition.urlFilter, "|https:");
      assert(!(r.condition.resourceTypes || []).includes("main_frame"));
    }
  });

  // ------------------------------------------------------------ v2.6.4
  await t("no dynamic rule hard-blocks a main frame; every main-frame block redirects to the warning page", async () => {
    const env = makeEnv();
    const state = "Object.assign({}, DEFAULT_STATE, { strictFirewallMode: true, blockThirdPartyScripts: true, customBlockedDomains: ['c.example.com'], " +
      "bulkBlockedDomains: ['b.example.com'], autoLists: { urlhaus: ['t.example.com'], hagezi: ['a.example.com'] }, trustedDomains: ['ok.example.com'] })";
    const rules = vm.runInContext("buildRules(" + state + ", false)", env.ctx);
    for (const r of rules) if (r.action.type === "block") assert(!(r.condition.resourceTypes || []).includes("main_frame"), JSON.stringify(r).slice(0, 120));
    const reasons = new Set(rules.filter(r => r.action.type === "redirect").map(r => r.action.redirect.extensionPath));
    for (const x of ["custom", "threat", "list", "deceptive"]) assert(reasons.has("/blocked.html?reason=" + x), x);
  });

  // ------------------------------------------------------------ v2.6.3
  await t("updater exemption: allow rule above Strict/custom/list blocks, limited to extension-initiated feed requests", async () => {
    const env = makeEnv();
    const rules = vm.runInContext("buildRules(Object.assign({}, DEFAULT_STATE, { strictFirewallMode: true, blockThirdPartyScripts: true }), false)", env.ctx);
    const r = rules.find(x => x.priority === 1002);
    assert(r && r.action.type === "allow");
    assert.strictEqual(JSON.stringify(r.condition.initiatorDomains), '["abc"]');
    for (const h of ["malware-filter.gitlab.io", "curbengh.github.io", "urlhaus-filter.pages.dev", "phishing-filter.pages.dev",
                     "cdn.jsdelivr.net", "raw.githubusercontent.com"]) assert(r.condition.requestDomains.includes(h), h);
    assert(r.condition.resourceTypes.every(x => x === "xmlhttprequest" || x === "other"));
    assert(!r.condition.resourceTypes.includes("main_frame"));
    const top = Math.max(...rules.filter(x => x.priority !== 1002).map(x => x.priority));
    assert(top < 1002);
  });

  // ------------------------------------------------------------ v2.6.2
  await t("lookalike redirect: same host is not redirected twice, a different lookalike in the same tab still is", async () => {
    const env = makeEnv();
    const nav = (url) => env.chrome.webNavigation.onBeforeNavigate.fns[0]({ frameId: 0, tabId: 7, url });
    nav("https://paypa1.com/"); await tick(30);
    assert.strictEqual(env.tabUpdates.length, 1);
    nav("https://paypa1.com/again"); await tick(30);
    assert.strictEqual(env.tabUpdates.length, 1, "same host inside the window is not redirected again");
    nav("https://rnicrosoft.com/"); await tick(30);
    assert.strictEqual(env.tabUpdates.length, 2, "a second, different lookalike must still be scored");
    assert(/host=rnicrosoft\.com/.test(env.tabUpdates[1][1]));
  });
  await t("restored tab logs: tab cap holds and entries without a numeric time are dropped", async () => {
    const good = { status: "ALLOWED", host: "a.example", type: "image", url: "https://a.example/", time: 1 };
    const seed = {};
    for (let i = 1; i <= 800; i++) seed[i] = [good];
    seed[801] = [good, { status: "ALLOWED", host: "a.example", type: "image", url: "https://a.example/x" }];
    const tabs = Array.from({ length: 801 }, (_, i) => ({ id: i + 1 }));
    const env = makeEnv(null, { session: { tabLogs: seed }, tabs });
    await tick(60);
    const r = await env.send({ type: "GET_TAB_LOGS", tabId: 801 });
    assert.strictEqual(r.logs.length, 1, "entry without time dropped");
    const inMemory = vm.runInContext("Object.keys(tabLogs).length", env.ctx);
    assert(inMemory <= 500, "restore must respect the 500-tab cap in memory, kept " + inMemory);
  });

  // ------------------------------------------------------------ updater: bodies are never left unread
  const hosts = n => Array.from({ length: n }, (_, i) => `0.0.0.0 d${i}.badhost.example`).join("\n");
  function trackedBody(text, status, headers, url) {
    const state = { cancelled: false };
    const enc = new TextEncoder().encode(text || "");
    const stream = new ReadableStream({
      start(c) { c.enqueue(enc); c.close(); },
      cancel() { state.cancelled = true; }
    });
    const resp = new Response(status === 304 ? null : stream, { status, headers });
    if (url) Object.defineProperty(resp, "url", { value: url });
    return { resp, state };
  }
  async function runUpdate(responses, initial, onFetch) {
    let env;
    env = makeEnv(async (u) => {
      if (onFetch) onFetch(env, u);
      const handler = responses[u];
      if (!handler) throw new Error("unmocked URL " + u);
      return handler();
    });
    if (initial) Object.assign(env.local, clone(initial));
    await env.send({ type: "UPDATE_LISTS_NOW" });
    for (let i = 0; i < 200; i++) {
      await tick(10);
      const m = env.local.autoListMeta;
      if (m && m.lastRun && !m.running) break;
    }
    return env;
  }

  await t("updater: HTTP errors, foreign redirects and HTML pages cancel the body", async () => {
    const e500 = trackedBody("oops", 500, {});
    const away = trackedBody(hosts(5), 200, {}, "https://evil.example/hostfile");
    const html = trackedBody("<html>portal</html>", 200, { "content-type": "text/html" });
    await runUpdate({
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": () => e500.resp,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": () => away.resp,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": () => html.resp,
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => trackedBody("", 404, {}).resp,
      "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 404, {}).resp,
      "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": () => trackedBody("", 404, {}).resp
    });
    assert(e500.state.cancelled, "500 body left unread");
    assert(away.state.cancelled, "redirected body left unread");
    assert(html.state.cancelled, "html body left unread");
  });

  await t("updater: good feed is parsed from the stream, protected domains dropped", async () => {
    const ok = trackedBody("# hosts\n" + hosts(2000) + "\n0.0.0.0 www.github.com\n0.0.0.0 github.com\n", 200, { "content-type": "text/plain", etag: "\"v1\"" });
    const env = await runUpdate({
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": () => ok.resp,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp,
      "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp,
      "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp,
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => trackedBody("", 500, {}).resp
    });
    const list = env.local.autoLists.urlhaus;
    assert.strictEqual(list.length, 2001);                // 2000 + www.github.com (subdomains stay blockable)
    assert(!list.includes("github.com"));
    assert.strictEqual(env.local.autoListMeta.sources.urlhaus.etag, "\"v1\"");
  });

  await t("updater: a poisoned feed line for a registry suffix (co.uk) is dropped", async () => {
    const ok = trackedBody("# hosts\n" + hosts(50) + "\n0.0.0.0 co.uk\n0.0.0.0 com.au\n0.0.0.0 shop.co.uk\n", 200, { "content-type": "text/plain" });
    const none = () => trackedBody("", 500, {}).resp;
    const env = await runUpdate({
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => ok.resp,
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": none,
      "https://urlhaus-filter.pages.dev/urlhaus-filter-hosts-online.txt": none,
      "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": none,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": none,
      "https://phishing-filter.pages.dev/phishing-filter-hosts.txt": none,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": none,
      "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": none
    });
    const list = env.local.autoLists.urlhaus;
    assert(!list.includes("co.uk") && !list.includes("com.au"));
    assert(list.includes("shop.co.uk"));                  // a real site under the suffix stays blockable
  });

  await t("updater: migrates stale persisted source-host blocks before attempting feeds", async () => {
    const fail = () => trackedBody("", 503, {}).resp;
    const responses = {
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": fail,
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": fail,
      "https://urlhaus-filter.pages.dev/urlhaus-filter-hosts-online.txt": fail,
      "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": fail,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": fail,
      "https://phishing-filter.pages.dev/phishing-filter-hosts.txt": fail,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": fail,
      "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": fail
    };
    const firstFetchState = [];
    const env = await runUpdate(responses, {
      autoLists: {
        urlhaus: ["github.io", "gitlab.io", "githubusercontent.com", "jsdelivr.net", "pages.dev", "safe.example"],
        phishing: ["malware-filter.gitlab.io", "safe-phish.example"]
      }
    }, (e, url) => {
      if (!firstFetchState.length) firstFetchState.push({
        url, lists: clone(e.local.autoLists), synced: e.dynamicSyncCalls.length > 0
      });
    });
    assert.deepStrictEqual(firstFetchState[0].lists.urlhaus, ["safe.example"]);
    assert.deepStrictEqual(firstFetchState[0].lists.phishing, ["safe-phish.example"]);
    assert(firstFetchState[0].synced, "stale DNR rules were not rebuilt before fetching");
    assert.deepStrictEqual(env.local.autoLists.urlhaus, ["safe.example"]);
    assert.deepStrictEqual(env.local.autoLists.phishing, ["safe-phish.example"]);
  });

  await t("updater: a dead primary mirror (410) falls through to the next mirror", async () => {
    const dead = trackedBody("gone", 410, {});
    const ok = trackedBody("0.0.0.0 a1.example.com\n0.0.0.0 a2.example.com\n", 200, { "content-type": "text/plain" });
    const calls = [];
    const env = await runUpdate({
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => { calls.push("m1"); return dead.resp; },
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": () => { calls.push("m2"); return ok.resp; },
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp, "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp, "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp
    });
    assert.deepStrictEqual(calls, ["m1", "m2"]);
    assert(dead.state.cancelled);
    assert.deepStrictEqual(env.local.autoLists.urlhaus, ["a1.example.com", "a2.example.com"]);
    const meta = env.local.autoListMeta.sources.urlhaus;
    assert(meta.ok && meta.url === "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt");
  });

  await t("updater: every mirror failing reports each host and keeps the old list", async () => {
    const env = await runUpdate({
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": () => trackedBody("", 410, {}).resp, "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => trackedBody("", 404, {}).resp,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp, "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp, "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp
    });
    const m = env.local.autoListMeta.sources.urlhaus;
    assert(!m.ok && /curbengh\.github\.io: HTTP 410/.test(m.error) && /malware-filter\.gitlab\.io: HTTP 404/.test(m.error), m.error);
  });

  // ------------------------------------------------------------ streaming parser
  const L = vm.runInContext("CipherLists", makeEnv().ctx);
  // hooks.open = leave the stream open after the chunks, like a body that is still downloading
  const streamOf = (chunks, hooks) => new Response(new ReadableStream({
    start(c) { for (const ch of chunks) c.enqueue(typeof ch === "string" ? new TextEncoder().encode(ch) : ch); if (!(hooks && hooks.open)) c.close(); },
    cancel() { if (hooks) hooks.cancelled = true; }
  }));

  await t("stream parser: lines split across chunks, CRLF, no trailing newline", async () => {
    const r = streamOf(["0.0.0.0 ads.ex", "ample.com\r\n||t.exa", "mple.net^\n", "plain.example.org"]);
    const out = await L.parseResponseDomains(r, 1e6, { max: 100 });
    assert.deepStrictEqual(Array.from(out), ["ads.example.com", "t.example.net", "plain.example.org"]);
  });

  await t("stream parser: multi-byte characters split across chunks decode correctly", async () => {
    const bytes = new TextEncoder().encode("0.0.0.0 b\u00fccher.example.com\n");   // ü is 2 bytes
    const r = streamOf([bytes.slice(0, 10), bytes.slice(10)]);
    assert.deepStrictEqual(Array.from(await L.parseResponseDomains(r, 1e6, {})), ["xn--bcher-kva.example.com"]);
  });

  await t("stream parser: same result as the one-shot parser on a large mixed list", async () => {
    const lines = [];
    for (let i = 0; i < 60000; i++) lines.push(i % 7 === 0 ? `||t${i}.example.net^` : i % 11 === 0 ? `# c${i}` : i % 13 === 0 ? `@@||ok${i}.example.com^` : `0.0.0.0 h${i}.example.com`);
    const text = lines.join("\n");
    const bytes = new TextEncoder().encode(text);
    const chunks = []; let p = 0, k = 1;
    while (p < bytes.length) { const n = 1 + ((k = (k * 48271) % 2147483647) % 9000); chunks.push(bytes.slice(p, p + n)); p += n; }
    const streamed = await L.parseResponseDomains(streamOf(chunks), 1e8, { max: 100000 });
    assert.deepStrictEqual(Array.from(streamed), Array.from(L.parseFilterLines(text, { max: 100000 })));
  });

  await t("stream parser: newline-free body is not buffered; byte cap and max stop the read", async () => {
    const hooks = { cancelled: false, open: true };
    const blob = new Uint8Array(5 * 1024 * 1024).fill(97);
    assert.deepStrictEqual(Array.from(await L.parseResponseDomains(streamOf([blob]), 1e8, {})), []);
    await assert.rejects(L.parseResponseDomains(streamOf([blob, blob]), 6 * 1024 * 1024, {}), /list too large/);
    const many = [Array.from({ length: 1000 }, (_, i) => `0.0.0.0 m${i}.example.com`).join("\n")];
    const r = await L.parseResponseDomains(streamOf(many, hooks), 1e8, { max: 10 });
    assert.strictEqual(r.length, 10);
    await tick();
    assert(hooks.cancelled, "body not cancelled after max reached");
    const big = new Response("x", { headers: { "content-length": String(1e9) } });
    await assert.rejects(L.parseResponseDomains(big, 1e6, {}), /list too large/);
  });

  console.log("\n" + passed + " runtime tests passed");
})().catch(e => { console.error("RUNTIME TEST FAILED:", e); process.exit(1); });
