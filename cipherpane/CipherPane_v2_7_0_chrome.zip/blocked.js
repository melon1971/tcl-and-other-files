// blocked.html is web-accessible (DNR redirects to it), so any web page can open it with any query
// string. Treat every parameter as untrusted: show only text that matches what CipherPane itself produces.
// A web page can embed this page in a frame. Nothing here may be clickable from inside one.
// This page never navigates by itself, reloads or retries: it is a stable stop screen.
const framed = window.self !== window.top;
const params = new URLSearchParams(location.search);
const HOST_RE = /^[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?$/;
const DETAIL_RE = /^(look-alike characters imitating |brand name split with hyphens: |lookalike spelling of |brand name with a phishing keyword: |brand-name subdomain impersonation of |brand name on a high-abuse TLD: )[a-z]{3,20}$|^label mixes Latin and Cyrillic\/Greek letters$/;

// Fixed texts only; the "reason" parameter just selects one of them.
const REASONS = {
  threat: ["Dangerous page blocked",
    "This address is on a malware, phishing or cryptominer list (built-in or auto-updating). Nothing was loaded from it.",
    "If a site is wrongly listed, switch that list off in Settings > Bulk Lists."],
  custom: ["Page blocked by your rules",
    "This address is on your own custom block list. Nothing was loaded from it.",
    "Remove it in Settings > Custom blocks if you want it back."],
  list: ["Page blocked (ad / tracker list)",
    "This address is on an ad, tracker or imported block list. Nothing was loaded from it.",
    "Switch the list off in Settings > Bulk Lists if this is a site you want."],
  deceptive: ["Deceptive link blocked",
    "This link hides its real destination behind a fake login name (user@host). That is a common phishing trick.",
    "Nothing was loaded."],
  lookalike: ["Possible fake site blocked",
    "CipherPane detected a likely brand-impersonation domain and stopped this navigation before it continued.",
    "The check is a local heuristic and can be wrong."]
};
const reason = Object.prototype.hasOwnProperty.call(REASONS, params.get("reason")) ? params.get("reason") : null;
const set = (id, text) => { const e = document.getElementById(id); if (e) e.textContent = text; };

if (reason) {
  set("title", REASONS[reason][0]);
  set("desc", REASONS[reason][1]);
  set("why", REASONS[reason][2]);
}

if (reason === "lookalike") {
  const host = (params.get("host") || "").toLowerCase();
  const detail = params.get("detail") || "";
  const okHost = HOST_RE.test(host);
  const d = document.getElementById("detail");
  if (d) {
    d.textContent = "Local phishing heuristic: " + (DETAIL_RE.test(detail) ? detail : "suspicious lookalike domain") +
      " (" + (okHost ? host : "unknown host") + ").";
    d.hidden = false;
  }
  const allow = document.getElementById("allowBtn");
  if (allow && okHost && !framed) {
    allow.hidden = false;
    allow.addEventListener("click", () => {
      try { chrome.tabs.create({ url: chrome.runtime.getURL("options.html#allow=" + encodeURIComponent(host)) }); } catch (e) {}
    });
  }
}

document.getElementById("backBtn").addEventListener("click", () => {
  // With no earlier page in this tab (the blocked link opened a new tab) there is nothing to go back to.
  if (history.length > 1) { history.back(); return; }
  try { chrome.tabs.getCurrent((t) => { if (t && t.id !== undefined) chrome.tabs.remove(t.id); }); } catch (e) {}
});
