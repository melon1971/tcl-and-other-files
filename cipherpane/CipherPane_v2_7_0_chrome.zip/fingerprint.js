// CipherPane fingerprint resistance (2.7.0). Registered by the background worker as a MAIN-world content script
// (document_start, all frames, http/https only, minus Trusted Sites) while the setting is on. Page-visible values are
// perturbed so that fingerprinting scripts get a per-page-load value that does not match their database, while
// ordinary pages keep working:
//   canvas   - 2D getImageData / toDataURL / toBlob on small canvases (<= 250,000 px): sparse +-1 colour-channel changes
//   WebGL    - UNMASKED_VENDOR/RENDERER report generic strings; readPixels on small reads gets the same sparse noise
//   audio    - OfflineAudioContext rendered buffers and AnalyserNode float data get ~1e-7 noise (inaudible)
//   hardware - navigator.hardwareConcurrency capped at 4, navigator.deviceMemory reported as 8
// NOT covered: installed fonts, time zone / locale, screen size, user-agent strings, WebRTC, speech voices. See the manual.
// This is noise, not a certified anti-fingerprinting engine; a determined script can still detect that noise exists.
(function () {
  "use strict";
  if (window.__cipherpaneFp) return;
  try { Object.defineProperty(window, "__cipherpaneFp", { value: 1, enumerable: false }); } catch (e) { return; }

  var MAX_PIXELS = 250000;
  var seed = 0;
  try { var a = new Uint32Array(1); crypto.getRandomValues(a); seed = a[0] >>> 0; } catch (e) { seed = (Math.random() * 4294967296) >>> 0; }
  if (!seed) seed = 0x9e3779b9;

  // Stateless hash of (seed, index): the same position always gets the same decision, so repeating a draw
  // inside one page load gives identical output (a script comparing two reads sees no instability).
  function h(i) {
    var x = (seed ^ Math.imul(i + 1, 0x9e3779b1)) >>> 0;
    x = Math.imul(x ^ (x >>> 16), 0x85ebca6b) >>> 0;
    x = Math.imul(x ^ (x >>> 13), 0xc2b2ae35) >>> 0;
    return (x ^ (x >>> 16)) >>> 0;
  }

  // ---- make replacements look like native functions ----
  var natives = new WeakMap();
  var origToString = Function.prototype.toString;
  function mask(fn, orig, name) {
    try { natives.set(fn, "function " + (name || (orig && orig.name) || "") + "() { [native code] }"); } catch (e) {}
    return fn;
  }
  try {
    var ts = function toString() {
      var s = natives.get(this);
      return s !== undefined ? s : origToString.call(this);
    };
    natives.set(ts, "function toString() { [native code] }");
    Function.prototype.toString = ts;
  } catch (e) {}

  function wrap(proto, name, make) {
    try {
      if (!proto) return;
      var d = Object.getOwnPropertyDescriptor(proto, name);
      if (!d || typeof d.value !== "function") return;
      var orig = d.value;
      var rep = make(orig);
      mask(rep, orig, name);
      Object.defineProperty(proto, name, { value: rep, writable: d.writable, configurable: d.configurable, enumerable: d.enumerable });
    } catch (e) {}
  }
  function wrapGetter(proto, name, make) {
    try {
      if (!proto) return;
      var d = Object.getOwnPropertyDescriptor(proto, name);
      if (!d || typeof d.get !== "function") return;
      var orig = d.get;
      var rep = make(orig);
      mask(rep, orig, "get " + name);
      Object.defineProperty(proto, name, { get: rep, set: d.set, configurable: d.configurable, enumerable: d.enumerable });
    } catch (e) {}
  }

  // ---- canvas ----
  // data: RGBA bytes. Roughly 1 pixel in 48 gets one colour channel moved by 1; alpha is never changed and fully
  // transparent pixels are skipped.
  function noiseRGBA(data) {
    var n = data.length >>> 2;
    for (var p = 0; p < n; p++) {
      var r = h(p);
      if ((r & 63) > 1) continue;                 // ~1/32 of pixels
      var o = p << 2;
      if (data[o + 3] === 0) continue;
      var c = (r >>> 8) % 3, v = data[o + c];
      data[o + c] = (r & 0x100000) ? (v < 255 ? v + 1 : v - 1) : (v > 0 ? v - 1 : v + 1);
    }
  }
  var CRC = window.CanvasRenderingContext2D, ORC = window.OffscreenCanvasRenderingContext2D;
  var origGetImageData = CRC && CRC.prototype.getImageData;
  var origCreateElement = Document.prototype.createElement;

  function small(w, h2) { return w > 0 && h2 > 0 && w * h2 <= MAX_PIXELS; }

  if (CRC) wrap(CRC.prototype, "getImageData", function (orig) {
    return function getImageData(sx, sy, sw, sh) {
      var img = orig.apply(this, arguments);
      try { if (img && img.data && small(img.width, img.height)) noiseRGBA(img.data); } catch (e) {}
      return img;
    };
  });
  if (ORC) wrap(ORC.prototype, "getImageData", function (orig) {
    return function getImageData(sx, sy, sw, sh) {
      var img = orig.apply(this, arguments);
      try { if (img && img.data && small(img.width, img.height)) noiseRGBA(img.data); } catch (e) {}
      return img;
    };
  });

  // toDataURL / toBlob: noise a copy, never the page's own canvas.
  function noisyCopy(canvas) {
    if (!origGetImageData || !small(canvas.width, canvas.height)) return null;
    try {
      var c2 = origCreateElement.call(document, "canvas");
      c2.width = canvas.width; c2.height = canvas.height;
      var x = c2.getContext("2d");
      if (!x) return null;
      x.drawImage(canvas, 0, 0);
      var img = origGetImageData.call(x, 0, 0, c2.width, c2.height);
      noiseRGBA(img.data);
      x.putImageData(img, 0, 0);
      return c2;
    } catch (e) { return null; }       // tainted canvas etc.: fall through to the untouched original
  }
  var HCE = window.HTMLCanvasElement;
  if (HCE) {
    wrap(HCE.prototype, "toDataURL", function (orig) {
      return function toDataURL() {
        var c = noisyCopy(this);
        return orig.apply(c || this, arguments);
      };
    });
    wrap(HCE.prototype, "toBlob", function (orig) {
      return function toBlob() {
        var c = noisyCopy(this);
        return orig.apply(c || this, arguments);
      };
    });
  }

  // ---- WebGL ----
  var UNMASKED_VENDOR = 0x9245, UNMASKED_RENDERER = 0x9246;
  function patchGL(Ctx) {
    if (!Ctx) return;
    var P = Ctx.prototype;
    wrap(P, "getParameter", function (orig) {
      return function getParameter(pname) {
        if (pname === UNMASKED_VENDOR) return "Google Inc.";
        if (pname === UNMASKED_RENDERER) return "ANGLE (Generic Renderer)";
        return orig.apply(this, arguments);
      };
    });
    wrap(P, "readPixels", function (orig) {
      return function readPixels(x, y, w, hh, format, type, dst) {
        var r = orig.apply(this, arguments);
        try {
          if (dst && dst instanceof Uint8Array && format === 0x1908 && type === 0x1401 && small(w, hh)) noiseRGBA(dst);
        } catch (e) {}
        return r;
      };
    });
  }
  patchGL(window.WebGLRenderingContext);
  patchGL(window.WebGL2RenderingContext);

  // ---- audio ----
  var done = new WeakSet();            // channel arrays already perturbed
  var offline = new WeakSet();         // AudioBuffers produced by OfflineAudioContext
  function noiseFloats(arr, salt) {
    var n = arr.length;
    for (var i = 0; i < n; i += 100) {   // sparse: enough to change a summed fingerprint, far below audibility
      var r = h(i + salt);
      arr[i] += ((r & 0xffff) / 65535 - 0.5) * 2e-7;
    }
  }
  var AB = window.AudioBuffer, OAC = window.OfflineAudioContext;
  if (OAC) wrap(OAC.prototype, "startRendering", function (orig) {
    return function startRendering() {
      var p = orig.apply(this, arguments);
      try { if (p && typeof p.then === "function") p.then(function (b) { try { offline.add(b); } catch (e) {} }, function () {}); } catch (e) {}
      return p;
    };
  });
  try {
    var OCE = window.OfflineAudioCompletionEvent;
    if (OCE) wrapGetter(OCE.prototype, "renderedBuffer", function (orig) {
      return function () { var b = orig.call(this); try { offline.add(b); } catch (e) {} return b; };
    });
  } catch (e) {}
  if (AB) {
    wrap(AB.prototype, "getChannelData", function (orig) {
      return function getChannelData(ch) {
        var arr = orig.apply(this, arguments);
        try { if (offline.has(this) && !done.has(arr)) { done.add(arr); noiseFloats(arr, ch | 0); } } catch (e) {}
        return arr;
      };
    });
    wrap(AB.prototype, "copyFromChannel", function (orig) {
      return function copyFromChannel(dest, ch) {
        var r = orig.apply(this, arguments);
        try { if (offline.has(this) && dest && dest.length) noiseFloats(dest, ch | 0); } catch (e) {}
        return r;
      };
    });
  }
  var AN = window.AnalyserNode;
  if (AN) wrap(AN.prototype, "getFloatFrequencyData", function (orig) {
    return function getFloatFrequencyData(arr) {
      var r = orig.apply(this, arguments);
      try { for (var i = 0; i < arr.length; i += 7) arr[i] += ((h(i) & 0xffff) / 65535 - 0.5) * 0.02; } catch (e) {}
      return r;
    };
  });

  // ---- hardware ----
  var N = window.Navigator;
  if (N) {
    wrapGetter(N.prototype, "hardwareConcurrency", function (orig) {
      return function () { var v = orig.call(this); return typeof v === "number" && v > 4 ? 4 : v; };
    });
    wrapGetter(N.prototype, "deviceMemory", function () { return function () { return 8; }; });
  }
})();
