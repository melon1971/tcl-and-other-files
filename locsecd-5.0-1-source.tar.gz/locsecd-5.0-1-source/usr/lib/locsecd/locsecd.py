#!/usr/bin/python3
# LocSec -- local host security daemon and dashboard.
# Copyright (C) 2025-2026 LocSec Project
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <https://www.gnu.org/licenses/>.
import os, sys, json, time, re, stat, errno, ipaddress, struct, socket, subprocess, threading, queue, urllib.request, urllib.error, urllib.parse, hashlib, signal, hmac, tempfile, shutil, fcntl, uuid, secrets, shlex, ssl
from pathlib import Path
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import pwd, grp, array, select, inspect, functools, types

# ---------------------------------------------------------------------------
# Two processes (4.0.11-91).
#
#   broker  `locsecd.py --broker`, root, locsecd-broker.service. It runs the
#           privilege broker's verbs for the other half over a Unix socket and
#           does nothing else: no dashboard, no parsing of logs, feeds or
#           packet captures, no network access.
#   web     everything else (the dashboard and its API, monitoring, threat
#           feeds, the scheduler, every parser), as the unprivileged user
#           "locsec", locsecd.service. Anything it needs root for, it asks
#           the broker for by verb name.
#   local   both in one process (LOCSEC_INPROCESS_BROKER=1). For tests only.
#
# A bug in a parser or in the dashboard now gives an attacker the locsec
# account and the verbs, not root.
# ---------------------------------------------------------------------------
ROLE=('broker' if '--broker' in sys.argv else
      'local' if os.environ.get('LOCSEC_INPROCESS_BROKER')=='1' else 'web')
WEB_USER='locsec'
# adm: auth.log, syslog, ufw.log. systemd-journal: the journal.
WEB_GROUPS=('adm','systemd-journal')
BROKER_SOCK='/run/locsecd/broker.sock'

def _web_ids():
    """(uid, gid, [supplementary gids]) of the unprivileged account, or None."""
    try: pw=pwd.getpwnam(WEB_USER)
    except KeyError: return None
    extra=[]
    for g in WEB_GROUPS:
        try: extra.append(grp.getgrnam(g).gr_gid)
        except KeyError: pass
    return pw.pw_uid,pw.pw_gid,extra

def _drop_privileges():
    ids=_web_ids()
    if ids is None:
        print(f'locsecd: the {WEB_USER} account does not exist; reinstall the package (sudo apt install --reinstall locsecd)',file=sys.stderr)
        sys.exit(1)
    uid,gid,extra=ids
    os.setgroups([gid]+extra); os.setgid(gid); os.setuid(uid)
    try: os.setuid(0)
    except PermissionError: pass
    else:
        print('locsecd: could not drop root privileges; refusing to continue',file=sys.stderr); sys.exit(1)
    os.environ['HOME']='/nonexistent'; os.environ['USER']=os.environ['LOGNAME']=WEB_USER
    os.umask(0o077)

# `sudo locsecctl scan` and friends start this file as root. It becomes locsec before any other line
# runs, so a one-shot job writes its reports and incidents as the account that owns them, and asks the
# broker for everything else exactly as the service does.
if ROLE=='web' and os.geteuid()==0 and not ({'--broker-verbs','--help','-h'} & set(sys.argv)):
    _drop_privileges()

APP='locsecd'
VERSION_FALLBACK='5.0-1'

def _installed_version():
    try:
        p=subprocess.run(['dpkg-query','-W','-f=${Version}',APP],text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=3,check=False)
        v=p.stdout.strip()
        if p.returncode==0 and v and re.fullmatch(r'[0-9A-Za-z.+:~_-]+',v):
            return v
    except Exception:
        pass
    return VERSION_FALLBACK

VERSION=_installed_version()

def _os_release():
    info={}
    try:
        for line in Path('/etc/os-release').read_text().splitlines():
            if '=' in line:
                k,_,v=line.partition('='); info[k]=v.strip().strip('"')
    except Exception: pass
    return info

_OS=_os_release()
# Debian proper, or a Debian-based derivative that is not Ubuntu-based --
# LMDE reports ID=linuxmint (like regular Mint) but ID_LIKE=debian, and its
# packages are Debian's, so debsecan's Debian feed applies to it. Regular Mint
# and other Ubuntu derivatives carry "ubuntu" in ID_LIKE.
_ID_LIKE=_OS.get('ID_LIKE','').split()
IS_DEBIAN_NATIVE = _OS.get('ID')=='debian' or ('debian' in _ID_LIKE and 'ubuntu' not in _ID_LIKE and _OS.get('ID')!='ubuntu')
# LMDE's VERSION_CODENAME is its own (faye, gigi); DEBIAN_CODENAME is the suite.
DEBIAN_SUITE = (_OS.get('DEBIAN_CODENAME') or _OS.get('VERSION_CODENAME') or 'trixie') if IS_DEBIAN_NATIVE else 'trixie'
ETC=Path('/etc/locsecd')
STATE=Path('/var/lib/locsecd')
LOG=Path('/var/log/locsecd/locsecd.log')
# Log sources selectable from the GUI's Logs page. Each is read-only tailed
# server-side; the key is what the GUI passes as ?source=. Only files that
# exist and are readable at request time are ever offered/returned.
#
# Every source also names a systemd-journal fallback ('jargs', plus 'jfilter'
# for a substring the journal has no field for). A host without rsyslog (the
# package now depends on it, but it can be removed) has no auth.log, syslog or ufw.log, and the
# page showed nearly every source as "not found" while the same records sat in the journal.
# The file is still preferred when present.
LOG_SOURCES={
    'locsecd':   {'label':'LocSec (locsecd.log)',        'paths':[Path('/var/log/locsecd/locsecd.log')],
                  'jargs':['-u','locsecd.service'],'jlabel':'-u locsecd'},
    'auth':      {'label':'Authentication (auth.log)',    'paths':[Path('/var/log/auth.log')],
                  # Same field given twice is OR'd by journalctl: auth (4) or authpriv (10).
                  'jargs':['SYSLOG_FACILITY=4','SYSLOG_FACILITY=10'],'jlabel':'auth, authpriv'},
    'rkhunter':  {'label':'rkhunter',                     'paths':[Path('/var/log/rkhunter.log')],
                  'hint':'rkhunter writes this file on its first run; run rkhunter from the Scans page'},
    'clamav':    {'label':'ClamAV (freshclam)',           'paths':[Path('/var/log/clamav/freshclam.log')],
                  'jargs':['-u','clamav-freshclam.service'],'jlabel':'-u clamav-freshclam'},
    # The newest LocSec AIDE check (reports/aide-full-*.txt) comes first; see
    # _source_paths(). aide.log is only written by the aide package's own daily
    # check, which LocSec switches off from 4.0.11-65.
    'aide':      {'label':'AIDE (latest check)',          'paths':[Path('/var/log/aide/aide.log')],
                  'jargs':['-u','dailyaidecheck.service'],'jlabel':'-u dailyaidecheck',
                  'hint':'AIDE has not run yet; press "AIDE" on the Scans page'},
    'ufw':       {'label':'UFW (kernel firewall log)',    'paths':[Path('/var/log/ufw.log')],
                  'jargs':['_TRANSPORT=kernel'],'jfilter':('[UFW ','[LOCSEC BLOCK]'),
                  'jregex':r'kernel: \[(?:UFW|LOCSEC) [A-Z ]+\] IN=\S* OUT=\S* (?:MAC=\S* )?SRC=\S+ DST=','jlabel':'kernel, [UFW ...] and [LOCSEC BLOCK] lines, all boots',
                  'hint':'UFW logs only when logging is on (sudo ufw logging low) and something has been denied'},
    'syslog':    {'label':'System log (syslog)',          'paths':[Path('/var/log/syslog')],
                  'jargs':[],'jlabel':'all messages'},
    # Suricata alerts. eve.json mixes alerts with flow, dns, http, tls and stats records (usually well over
    # 99% of it), so this source is not a plain tail: /api/logs reads the file backwards and keeps only the
    # alert records (see ids_recent_alerts). fast.log is the one-line-per-alert format, used if eve.json is absent.
    # The eve.json path follows ids_eve_path; see _source_paths().
    'suricata':  {'label':'Suricata alerts (eve.json)',   'paths':[Path('/var/log/suricata/eve.json'),Path('/var/log/suricata/fast.log')],
                  'hint':'Suricata is not installed or has not written an alert log yet; see Threat Intelligence'},
    'suricata-engine':{'label':'Suricata engine (suricata.log)','paths':[Path('/var/log/suricata/suricata.log')],
                  'jargs':['-u','suricata.service'],'jlabel':'-u suricata',
                  'hint':'Suricata is not installed'},
}
TOKEN=STATE/'api.token'
CONF=ETC/'locsecd.conf'
BLOCKS=STATE/'blocks.json'
FEEDS=STATE/'feeds.json'
REPORTS=STATE/'reports'
CAPTURES=STATE/'captures'
# Root-only state lives outside /var/lib/locsecd, which belongs to the unprivileged half: it could rename
# a subdirectory there and put its own in place, and a quarantine restore writes back to whatever path the
# vault records.
BROKER_DIR=Path('/var/lib/locsecd-broker')
BROKER_WORK=BROKER_DIR/'work'
QUAR=BROKER_DIR/'quarantine'
AUTHSEEN=STATE/'auth_seen.json'
SECURITYSEEN=STATE/'security_seen.json'
JOURNALSTATE=STATE/'journal_cursor.json'
# When each scheduled job last ran. The scheduler used to read this from the
# report files' times only; reports are now deleted after
# report_retention_days, so the times are kept here as well.
JOBRUNS=STATE/'job_runs.json'
INCIDENTS=STATE/'incidents.jsonl'
INCIDENT_ACTIONS=STATE/'incident-actions.jsonl'
LOCK=threading.RLock()
class _JobLock:
    """The maintenance-job lock, plus a record of which job holds it.

    A refused request used to say only "another maintenance job is already
    running", with no way to tell a ten-second feed refresh from a three-hour
    AIDE check short of reading the journal."""
    def __init__(self):
        self._lock=threading.Lock(); self._meta=threading.Lock(); self.job=None
    def acquire(self,blocking=True,timeout=-1,job='maintenance job',origin='dashboard'):
        if not self._lock.acquire(blocking,timeout): return False
        with self._meta: self.job={'name':str(job),'origin':str(origin),'since':time.time()}
        # Keep the computer awake for the length of a real job (not the ten-second
        # feed refresh). This never wakes a machine that is already asleep.
        if str(job) not in _NO_INHIBIT_JOBS:
            try: SLEEP_INHIBIT.start(f'LocSec: {job}')
            except Exception: pass
        return True
    def release(self):
        try: SLEEP_INHIBIT.stop()
        except Exception: pass
        with self._meta: self.job=None
        self._lock.release()
    def current(self):
        with self._meta: return dict(self.job) if self.job else None
    def busy_message(self):
        j=self.current()
        if not j: return 'another maintenance job is already running'
        mins=int(max(0,time.time()-j['since'])//60)
        started=datetime.fromtimestamp(j['since']).strftime('%H:%M')
        ago='under a minute' if mins<1 else (f'{mins} min' if mins<120 else f'{mins//60} h {mins%60} min')
        return (f'another maintenance job is already running: {j["name"]} ({j["origin"]}), '
                f'started {started}, running for {ago}. Only one runs at a time; try again when it finishes.')

JOB_LOCK=_JobLock()

# Jobs too short to be worth holding a sleep inhibitor for.
_NO_INHIBIT_JOBS={'Threat-feed update'}

class _SleepInhibitor:
    """Hold a systemd-logind inhibitor lock while a maintenance job runs.

    Without it, closing the lid (or the idle timer) suspends the computer in the
    middle of an AIDE or ClamAV run, and the run just freezes until the next wake.
    The lock is held by a small `systemd-inhibit ... sleep N` child: stopping the
    child releases the lock, and if locsecd is killed the unit's control-group
    kill takes the child with it. N is a cap (6 h), so a stuck job cannot keep
    the machine awake for ever; it is longer than the longest per-tool timeout.

    This only STOPS a running computer from sleeping. It never wakes one that is
    already suspended or hibernated: nothing here sets an RTC alarm or a timer.
    Controlled by inhibit_sleep_during_jobs (default true) and inhibit_lid_switch
    (default true: lid close is ignored while a job runs; false: only idle/menu
    suspend is held off and the lid still suspends the machine)."""
    MAX_SECONDS=21600
    def __init__(self):
        self._lock=threading.Lock(); self._held=False; self._warned=False
    def start(self,why='LocSec maintenance job'):
        if not CFG.get('inhibit_sleep_during_jobs',True): return
        if not have('systemd-inhibit'): return
        what='sleep:handle-lid-switch' if CFG.get('inhibit_lid_switch',True) else 'sleep'
        with self._lock:
            if self._held: return
            # The broker runs systemd-inhibit for this process and ends it on stop() or when this process is gone.
            self._held=bool(broker('power.inhibit_start',what=what,why=str(why)))
            if not self._held and not self._warned:
                self._warned=True; log('sleep inhibitor not started; the computer may still suspend during jobs','WARN')
    def stop(self):
        with self._lock:
            if not self._held: return
            self._held=False
        broker('power.inhibit_stop')
    def active(self):
        with self._lock: return self._held

SLEEP_INHIBIT=_SleepInhibitor()
AIDE_LOCK_PATH=Path('/run/lock/locsecd-aide.lock')
AIDE_DB=Path('/var/lib/aide/aide.db')
AIDE_DB_NEW=Path('/var/lib/aide/aide.db.new')
MAX_BODY=1024*1024
MAX_FEED_BYTES=8*1024*1024

class _HTTPSOnlyRedirect(urllib.request.HTTPRedirectHandler):
    # The HTTPS-only rule for feeds must hold across redirects too: urllib would
    # otherwise follow an https:// feed to an http:// location.
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urllib.parse.urlparse(newurl).scheme!='https':
            raise urllib.error.HTTPError(newurl,code,'redirect to a non-HTTPS URL refused',headers,fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)
_FEED_OPENER=urllib.request.build_opener(_HTTPSOnlyRedirect)
COOKIE='locsec_session'
# The dashboard is served over HTTPS with a certificate made for this machine by
# /usr/lib/locsecd/locsec-tls (run by the installer; the daemon's sandbox cannot
# write under /etc/ssl, so it never creates one itself). The private key is in a
# root-only directory; the public half is world-readable so the desktop window can
# pin it before it hands over the API token.
TLS_KEY='/etc/locsecd/dashboard.key'
TLS_CERT='/etc/ssl/locsecd/dashboard.crt'
CAPTURE_LOCK=threading.Lock()
ACTIVE_CAPTURES=[]
MAX_CONCURRENT_CAPTURES=3
MIN_CAPTURE_FREE_BYTES=1024*1024*1024      # refuse to start a new capture below 1GB free
HARD_MIN_CAPTURE_FREE_BYTES=256*1024*1024  # kill an in-progress capture below 256MB free

# systemd-run spawns apt-get/unattended-upgrade/freshclam (run_privileged())
# and aideinit (aide_init()) as *sibling* transient units, deliberately outside
# locsecd.service's own cgroup, so they can get capabilities our own
# CapabilityBoundingSet denies us. That means locsecd.service's cgroup-kill on
# stop/restart (KillMode=control-group) does NOT reach them: without this
# tracking, a locsecd restart/kill mid-job would leave the transient unit
# running unsupervised, orphaned from JOB_LOCK/the AIDE flock, able to race a
# freshly-started locsecd doing the same job again. Track every such unit name
# so _shutdown_handler can explicitly stop it too.
INFLIGHT_PRIV_UNITS={}     # unit name -> pid of the client it was started for
INFLIGHT_LOCK=threading.Lock()

def _run_transient(cmd, timeout=60, input_text=None, prefix='locsecd-priv', props=None, head=0, save_to=None, tail=20000, stdin_path=None, stdin_fd=None):
    # Shared helper for run_privileged()/aide_init()/the scan jobs: run cmd in a
    # named transient unit and track the unit name for shutdown-time cleanup.
    # Never silently fall back to an ordinary root subprocess: doing so would
    # bypass the transient-unit boundary and could turn a constrained LocSec
    # operation into an unconstrained root operation.
    #
    # A transient unit is a sibling of locsecd.service managed by PID 1, so it
    # gets NONE of this daemon's sandboxing: full capability set, the real
    # (host) mount namespace, a writable /etc and /usr, visible /lib/modules,
    # and no MemoryMax of ours. That is exactly what apt/freshclam/aideinit
    # need to sandbox themselves as _apt/clamav, what Lynis and rkhunter need
    # to audit the real system rather than our sandboxed view of it, and what
    # clamdscan needs so the file descriptors it hands to clamd (AppArmor-
    # confined) resolve to real paths instead of "disconnected path" denials.
    if not _in_broker():
        log(f'privilege broker: refused a transient unit outside a broker verb ({str(list(cmd)[:1])[:80]}) from {_caller()}; this is a LocSec bug','ERROR')
        _BROKER_REFUSALS['n']+=1
        return 126,'refused: privileged jobs may only be started through the privilege broker'
    if not have('systemd-run'):
        # Failing closed is deliberate. The caller may be running as root, but
        # the operation was designed to execute in a separate systemd unit with
        # explicit lifecycle and resource controls. Running it directly would
        # silently weaken that security boundary.
        return 126, 'systemd-run is required for this privileged job; refusing to bypass the systemd security boundary'
    # The owning daemon's pid is part of the name, so a later instance can tell
    # which units a dead predecessor left running (see _sweep_orphan_units).
    unit=f'{prefix}-p{os.getpid()}-{uuid.uuid4().hex[:8]}.service'
    req=_req()
    with INFLIGHT_LOCK:
        # Shutdown stops the units in flight once; one started after that would
        # be outside every cgroup we kill, so refuse to start new ones. The same
        # for a request whose client has hung up.
        if _cancelled(): return 130,'service is stopping'
        # Owner: the client process the unit was started for, so stopping "my jobs" stops only its own.
        INFLIGHT_PRIV_UNITS[unit]=_client_pid()
        if req is not None: req.units.add(unit)
    try:
        args=['systemd-run','--pipe','--wait','--collect','--quiet',
              f'--unit={unit}',
              '--property=CapabilityBoundingSet=~','--property=AmbientCapabilities=~',
              '--setenv=DEBIAN_FRONTEND=noninteractive',
              # Belt and braces: even if we lose track of this unit, systemd itself ends it.
              f'--property=RuntimeMaxSec={int(timeout)+120}',
              # Restrictions no job here needs to give up (kernel modules, kernel log,
              # namespaces and the like are left alone because Lynis and rkhunter read them).
              '--property=LockPersonality=yes','--property=RestrictRealtime=yes','--property=ProtectClock=yes',
              '--property=ProtectHostname=yes','--property=SystemCallArchitectures=native']
        # Bound to the service that asked for it (locsecd.service), so stopping or restarting LocSec ends its
        # scans. In the broker, the client says whether it is that service; lying only unbinds its own job.
        bind=req.bind if req is not None else DAEMON_MODE
        if bind and not unit.startswith(_APT_UNIT_PREFIX):
            args+=['--property=BindsTo=locsecd.service','--property=After=locsecd.service']
        for pr in (props or []): args.append('--property='+str(pr))
        rc,out=run(args+list(cmd), timeout, input_text, head=head, save_to=save_to, tail=tail, stdin_path=stdin_path, stdin_fd=stdin_fd)
        if rc==124 and not unit.startswith(_APT_UNIT_PREFIX):
            # Our timeout only killed the systemd-run *client*; the unit itself
            # would otherwise keep running unsupervised. Stop it explicitly.
            # Never an apt/dpkg unit: killing dpkg mid-run leaves packages
            # half-configured; RuntimeMaxSec still ends it if it truly hangs.
            try: subprocess.run(['systemctl','stop',unit], timeout=30, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            except Exception: pass
        return rc,out
    finally:
        with INFLIGHT_LOCK:
            INFLIGHT_PRIV_UNITS.pop(unit,None)
            if req is not None: req.units.discard(unit)

_APT_UNIT_PREFIX='locsecd-apt-'
# Set by main() for the long-running service. Its transient units are bound to it, so
# systemd stops them when locsecd.service stops, restarts or is killed: the cgroup kill
# reaches the systemd-run client first and the in-flight list is empty by the time
# server() would stop them. apt/dpkg units are never bound (a half-run dpkg is worse).
DAEMON_MODE=False

def _stop_inflight_priv_units():
    # Called on shutdown: cgroup-kill on locsecd.service cannot reach these
    # sibling transient units, so stop them explicitly rather than leaving
    # scans running unsupervised after we exit. One non-blocking call: systemd
    # finishes the stops after we are gone, so a slow unit cannot eat the
    # stop timeout. apt/dpkg units are left to finish -- stopping one mid-run
    # is how dpkg ends up needing "dpkg --configure -a".
    broker('jobs.stop_inflight')

def _sweep_orphan_units():
    # A SIGKILL, OOM kill or crash skips the shutdown path, so the scans the
    # dead instance started keep running -- and it held the AIDE lock, which
    # died with it, so a new instance could start a second aideinit racing the
    # first. Stop every LocSec unit whose owning pid is gone. apt units are
    # left to finish (see _stop_inflight_priv_units).
    if not have('systemctl'): return
    # The broker starts every job unit, so it is the one that sweeps them, once at its own start.
    if ROLE=='web': return
    rc,out=run(['systemctl','list-units','--type=service','--state=active,activating','--plain','--no-legend','--no-pager','locsecd-*'],15)
    if rc!=0: return
    stale=[]
    for line in out.splitlines():
        u=(line.split() or [''])[0]
        if not u.endswith('.service') or u in ('locsecd.service','locsecd-broker.service') or u.startswith(_APT_UNIT_PREFIX): continue
        m=re.search(r'-p(\d+)-[0-9a-f]{8}\.service$',u)
        if m and m.group(1)!=str(os.getpid()) and Path(f'/proc/{m.group(1)}').exists(): continue   # a live locsecctl run
        if m and m.group(1)==str(os.getpid()): continue
        stale.append(u)
    if stale:
        broker('jobs.stop_stale',units=stale[:200])
        log(f'stopped {len(stale)} scan unit(s) left running by a previous LocSec instance: {", ".join(stale[:10])}','WARN')

def _reap_captures():
    # Drop finished/dead tcpdump processes from the tracking list; called with
    # CAPTURE_LOCK held. Guards against the list growing stale if a capture's
    # own stop-timer thread hasn't run yet but the process already exited.
    for p in list(ACTIVE_CAPTURES):
        if p.poll() is not None: ACTIVE_CAPTURES.remove(p)

def _prepare_dirs():
    """Create this half's own directories, mode 0700 (the package creates the shared ones). Best-effort:
    a missing directory surfaces at first use with a clearer error than a traceback at import."""
    own={'broker':(BROKER_DIR,BROKER_WORK,QUAR),
         'web':(STATE,REPORTS,CAPTURES),
         'local':(STATE,REPORTS,CAPTURES,BROKER_DIR,BROKER_WORK,QUAR)}[ROLE]
    for p in own:
        try: p.mkdir(parents=True,exist_ok=True)
        except OSError: pass
        try:
            # chmod by path would follow a symbolic link planted in place of the directory.
            if not os.path.islink(p): os.chmod(p,0o700)
        except OSError: pass
    if ROLE!='broker':
        try: LOG.parent.mkdir(parents=True,exist_ok=True)
        except OSError: pass
_prepare_dirs()

DEFAULTS={
 'listen':'127.0.0.1','port':8765,'idle_load':1.0,'idle_seconds':600,
 'allow_manual_service_control':False,
 'auth_threshold':5,'auth_window':900,'feed_interval':43200,
 # AIDE/Lynis/Debsecan/rkhunter/ports+fw/CVE run once a week each,
 # staggered scan_stagger_seconds apart so a week's worth of scans doesn't
 # land on the same day. ClamAV is on its own daily interval instead (see
 # clamav_scan_interval) since a rootkit/audit cadence that's fine weekly is
 # too slow for antivirus. update_interval is the separate apt-security-patch
 # cadence (twice a day), independent of the weekly scan schedule.
 # scan_stagger_seconds defaults to a full day (not an hour) so the six
 # weekly jobs land on six different calendar days rather than clustering
 # within a few hours of each other. scan_jobs_per_day is the actual
 # enforcement of that spacing: even if several jobs become overdue at once
 # (e.g. after the host was busy/offline for days), at most this many weekly
 # jobs are allowed to start per calendar day -- the rest simply wait for
 # the next day(s) rather than firing back-to-back the moment the machine
 # goes idle.
 'scan_interval':604800,'clamav_scan_interval':86400,'scan_stagger_seconds':86400,'scan_jobs_per_day':1,'clamav_batch_size':20000,'scan_nice':10,
 'update_interval':43200,'defs_update_interval':86400,
 'feed_auto_block':True,'feed_auto_block_limit':500,'update_security_only':True,
 'auto_block':True,'auto_update':True,'max_auto_block_prefix':8,'include_phased_updates':False,
 'ipv6_auto_block':True,'incident_retention':10000,'event_poll_seconds':60,'block_ttl_days':30,'incident_ttl_days':30,
 'dashboard_report_max_mb':100,'max_report_count':100,'max_capture_count':20,
 # Hold off suspend (and, optionally, the lid-close suspend) while a maintenance job runs. Never wakes a sleeping PC.
 'inhibit_sleep_during_jobs':True,'inhibit_lid_switch':True,
 # Per-tool wall-clock limits (seconds). AIDE on a large home directory legitimately needs well over an
 # hour (Debian's own daily check was measured at ~80 min), so its default is 3h.
 'aide_scan_timeout':10800,'lynis_timeout':3600,'clamav_timeout':7200,
 # ClamAV only scans these paths (default: users' home directories). Everything else on the system is
 # covered by package verification (AIDE/debsums-style) and rkhunter, not by an antivirus walk of /usr.
 'clamav_scan_paths':['/home'],'clamav_max_file_mb':100,'clamav_extra_excludes':[],'rkhunter_ignore':[],
 # report_retention_days: every file under reports/ (scan, CVE and update
 # reports, and the full AIDE outputs) is deleted once it is this many days
 # old, so reports never fill the disk. retention_days still covers captures
 # and LocSec's rotated log files.
 'retention_days':14,'report_retention_days':7,'log_auth_each_attempt':True,'log_network_denials':True,'log_app_connection_failures':True,
 'notify_on':{'virus-found':True,'rootkit-warning':True,'block':False,'login-failure':False,'port-scan':True,'ids-alert':True,'firewall-fallback':True},
 'response_auth_block':True,'response_feed_block':True,
 # Port-scan detection reads the firewall's own "denied" log lines (UFW's, or
 # the fallback firewall's below) and blocks a source that probes scan_ports
 # different ports within scan_window seconds. UFW rate-limits its logging to
 # a burst of 10 lines, so scan_ports must stay below that to see a fast scan.
 'scan_detect':True,'response_scan_block':True,'scan_ports':8,'scan_window':600,
 # A scan block is short and rate-limited: the source address of a probe can be forged, so a
 # forged scan must not be able to lock out many hosts, or one host for long.
 'scan_block_hours':24,'scan_block_max_per_hour':10,
 # Network intrusion signatures: LocSec reads the alerts Suricata (a separate package that LocSec depends on) writes to
 # eve.json. ids_block_severity is the highest Suricata severity number that may be blocked automatically
 # (1 = high only, 0 = never block, only record); ids_incident_severity is the highest one recorded at all.
 'capture_deep_analysis':True,
 'ids_enabled':True,'ids_eve_path':'/var/log/suricata/eve.json','ids_response_block':True,
 'ids_block_severity':1,'ids_incident_severity':2,'ids_block_hours':24,'ids_block_max_per_hour':10,
 'ids_rules_update':True,'ids_ignore_sids':[],
 # Keep Suricata's capture interface (af-packet in suricata.yaml) on the interface the default route uses, and
 # make sure the rules suricata-update downloads are the ones loaded. Done by locsec-suricata-setup, which only
 # replaces the package default (eth0), an interface that no longer exists, or a value LocSec wrote itself.
 'ids_auto_configure':True,
 # When UFW is installed but not enabled, LocSec installs its own nftables
 # default-deny input chain until UFW is enabled again. Ports listed here stay
 # reachable while it is on.
 'fallback_firewall':True,'fallback_allow_tcp':[],'fallback_allow_udp':[],
 'feed_urls':['https://www.spamhaus.org/drop/drop.txt','https://feodotracker.abuse.ch/downloads/ipblocklist_recommended.txt'],
 'allow_ips':['127.0.0.0/8','10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','::1/128','fc00::/7'],
}

_LOG_RATE={'minute':0,'n':0,'dropped':0}
_LOG_RATE_LOCK=threading.Lock()
_LOG_MAX_PER_MIN=600

def log(msg, level='INFO'):
    # One record per line. A newline inside a message split it into stray rows on the Logs
    # page (the empty "Heads up"), and text quoted from another log could forge an entry.
    msg=re.sub(r'[\r\n]+',' | ',str(msg)).strip()[:8000]
    # At most _LOG_MAX_PER_MIN lines a minute: every attempt of a brute force, every
    # dropped packet and every connection failure ends up here, and logrotate only
    # runs once a day. ERROR lines always get through.
    now=datetime.now(timezone.utc); minute=int(time.time()//60); note=None
    with _LOG_RATE_LOCK:
        r=_LOG_RATE
        if r['minute']!=minute:
            if r['dropped']: note=f"{now.isoformat()} WARN log flood: {r['dropped']} lines were not written in the previous minute (more than {_LOG_MAX_PER_MIN})"
            r.update(minute=minute,n=0,dropped=0)
        r['n']+=1
        if r['n']>_LOG_MAX_PER_MIN and level!='ERROR':
            r['dropped']+=1; return
    line=f"{now.isoformat()} {level} {msg}"
    if ROLE=='broker':
        # The broker writes nothing under the unprivileged half's directories; its log is the journal
        # (journalctl -u locsecd-broker).
        try: print(f'{level} {msg}',file=sys.stderr,flush=True)
        except Exception: pass
        return
    try:
        if note: append_line(LOG, note, 0o640)
        append_line(LOG, line, 0o640)
    except NameError:
        # Called while the module is still loading (configuration checks run before append_line is
        # defined): keep the line, print it for the journal, and write it once main() starts.
        _EARLY_LOG.append(line)
        try: print(line,file=sys.stderr,flush=True)
        except Exception: pass
    except Exception: pass
_EARLY_LOG=[]
def _flush_early_log():
    while _EARLY_LOG:
        try: append_line(LOG,_EARLY_LOG.pop(0),0o640)
        except Exception: break


_CONF_MAX=1<<20
def _conf_trusted(path):
    """The configuration decides what a root daemon blocks, downloads and runs, so it is only read when it can
    only have been written by root: a regular file (not a symbolic link) owned by root, not writable by group or
    others, in a directory with the same properties. Anything else is ignored and the defaults are used."""
    try:
        st=os.lstat(path); dst=os.stat(os.path.dirname(path) or '/')
    except OSError as e: return f'cannot be checked: {e}'
    if not stat.S_ISREG(st.st_mode): return 'is not a regular file (a symbolic link or something else)'
    if st.st_uid!=0: return f'is owned by uid {st.st_uid}, not root'
    if st.st_mode&0o022: return f'is writable by group or others (mode {stat.S_IMODE(st.st_mode):04o})'
    if dst.st_uid!=0 or dst.st_mode&0o022: return 'its directory is not owned by root or is writable by group or others'
    if st.st_size>_CONF_MAX: return f'is larger than {_CONF_MAX} bytes'
    return ''

def load_conf():
    cfg=dict(DEFAULTS)
    if CONF.exists():
        # Both halves read it, and both only trust a file root wrote.
        why=_conf_trusted(str(CONF))
        if why:
            log(f'{CONF} {why}; it is ignored and the built-in defaults are used. Fix with: '
                f'sudo chown root:{WEB_USER} {CONF} && sudo chmod 0640 {CONF}','ERROR')
            return cfg
        try:
            fd=os.open(str(CONF),os.O_RDONLY|os.O_NOFOLLOW)
            with os.fdopen(fd,'rb') as fh: raw=fh.read(_CONF_MAX+1)
            data=json.loads(raw.decode('utf-8'))
            if isinstance(data,dict): cfg.update(data)
        except Exception as e: log(f'configuration parse error: {e}','ERROR')
    return cfg
CFG=load_conf()
LISTEN_ADDR='127.0.0.1'

def _normalize_config():
    # Clamp operator-controlled numeric settings so malformed JSON cannot
    # create zero/negative timers, invalid ports, or unbounded report limits.
    int_rules={
        'port':(1,65535,8765),'auth_threshold':(1,100000,5),'auth_window':(15,604800,900),
        'feed_interval':(60,2592000,43200),'scan_interval':(300,31536000,604800),
        'clamav_scan_interval':(300,31536000,86400),'scan_stagger_seconds':(0,604800,86400),
        'scan_jobs_per_day':(1,10,1),
        'clamav_batch_size':(500,500000,20000),
        'update_interval':(300,31536000,43200),
        'defs_update_interval':(300,31536000,86400),'event_poll_seconds':(15,3600,60),
        'idle_seconds':(30,86400,600),'incident_retention':(100,100000,10000),
        'retention_days':(1,3650,14),'ids_rules_min_hours':(1,168,6),'report_retention_days':(1,3650,7),'block_ttl_days':(1,3650,30),'incident_ttl_days':(1,3650,30),
        'max_auto_block_prefix':(1,100000,8),
        'feed_auto_block_limit':(0,10000,500),
        'dashboard_report_max_mb':(1,1024,100),'max_report_count':(10,1000,100),
        'aide_scan_timeout':(300,259200,10800),'lynis_timeout':(60,86400,3600),'clamav_timeout':(60,259200,7200),
        'clamav_max_file_mb':(1,4096,100),
        'max_capture_count':(1,100,20),'scan_nice':(-20,19,10),
        'scan_ports':(3,1000,8),'scan_window':(60,86400,600),
        'scan_block_hours':(1,720,24),'scan_block_max_per_hour':(1,1000,10)
    }
    for k,(lo,hi,default) in int_rules.items():
        try: v=int(CFG.get(k,default))
        except Exception: v=default
        CFG[k]=max(lo,min(hi,v))
    try: v=float(CFG.get('idle_load',1.0)); CFG['idle_load']=max(0.01,min(100.0,v))
    except Exception: CFG['idle_load']=1.0
    # The dashboard is a root control panel, so it is reachable from this
    # machine only. "listen" stays in the configuration so the address is
    # visible, but it is pinned: any other value is replaced by 127.0.0.1, and
    # the log says so, rather than exposing the API to the network.
    lv=CFG.get('listen')
    if lv not in ('127.0.0.1','localhost'):
        log(f'listen={lv!r} in {CONF} is not allowed: the dashboard only listens on {LISTEN_ADDR}','WARN')
    CFG['listen']=LISTEN_ADDR
    if not isinstance(CFG.get('feed_urls'),list): CFG['feed_urls']=list(DEFAULTS['feed_urls'])
    # HTTPS only: a feed fetched over plain HTTP can be rewritten in transit,
    # and whoever rewrites it chooses what this machine blocks.
    dropped=[x for x in CFG['feed_urls'][:32] if isinstance(x,str) and x.startswith('http://')]
    if dropped: log(f'ignoring {len(dropped)} feed URL(s) that are not HTTPS: {", ".join(str(d)[:120] for d in dropped)}','WARN')
    CFG['feed_urls']=[str(x)[:2048] for x in CFG['feed_urls'][:32] if isinstance(x,str) and x.startswith('https://')]
    if not CFG['feed_urls']: CFG['feed_urls']=list(DEFAULTS['feed_urls'])
    # clamav_scan_paths: absolute paths only; anything malformed falls back to /home.
    sp=CFG.get('clamav_scan_paths')
    if not isinstance(sp,list): sp=list(DEFAULTS['clamav_scan_paths'])
    sp=[str(x)[:1024] for x in sp[:32] if isinstance(x,str) and x.startswith('/')]
    CFG['clamav_scan_paths']=sp or list(DEFAULTS['clamav_scan_paths'])
    for k in ('clamav_extra_excludes','rkhunter_ignore'):
        if not isinstance(CFG.get(k),list): CFG[k]=[]
        CFG[k]=[str(x)[:512] for x in CFG[k][:128] if isinstance(x,str)]
    for k in ('fallback_allow_tcp','fallback_allow_udp'):
        v=CFG.get(k); ports=[]
        for x in (v if isinstance(v,list) else [])[:64]:
            try: n=int(x)
            except Exception: continue
            if 1<=n<=65535 and n not in ports: ports.append(n)
        CFG[k]=ports
    for k in ('scan_detect','response_scan_block','fallback_firewall','allow_manual_service_control'):
        if not isinstance(CFG.get(k),bool): CFG[k]=DEFAULTS[k]
    for k in ('ids_enabled','ids_response_block','ids_rules_update','ids_auto_configure'):
        if not isinstance(CFG.get(k),bool): CFG[k]=DEFAULTS[k]
    for k,lo,hi in (('ids_block_severity',0,3),('ids_incident_severity',1,4),('ids_block_hours',1,720),('ids_block_max_per_hour',1,200)):
        try: v=int(CFG.get(k,DEFAULTS[k]))
        except (TypeError,ValueError): v=DEFAULTS[k]
        CFG[k]=min(hi,max(lo,v))
    p=CFG.get('ids_eve_path')
    # LocSec runs as root and shows this file's contents on the dashboard, so it may only name a file under
    # /var/log/ (checked after resolving symbolic links and ".."): a configuration mistake must not turn the
    # Logs page into a way to read /etc/shadow or a private key.
    ok=False
    if isinstance(p,str) and p.startswith('/') and len(p)<=512 and '\x00' not in p:
        try: ok=os.path.realpath(p).startswith('/var/log/')
        except (OSError,ValueError): ok=False
    if not ok and p!=DEFAULTS['ids_eve_path']:
        log(f'ids_eve_path {str(p)[:200]!r} refused: it must be a file under /var/log/; using {DEFAULTS["ids_eve_path"]}','WARN')
    CFG['ids_eve_path']=str(p) if ok else DEFAULTS['ids_eve_path']
    sids=[]
    for x in (CFG.get('ids_ignore_sids') if isinstance(CFG.get('ids_ignore_sids'),list) else [])[:512]:
        try: sids.append(int(x))
        except (TypeError,ValueError): pass
    CFG['ids_ignore_sids']=sids
    no=CFG.get('notify_on')
    CFG['notify_on']={**DEFAULTS['notify_on'],**{str(k)[:64]:v for k,v in (no.items() if isinstance(no,dict) else ()) if isinstance(v,bool)}}
    if not isinstance(CFG.get('allow_ips'),list): CFG['allow_ips']=list(DEFAULTS['allow_ips'])
    CFG['allow_ips']=[str(x)[:128] for x in CFG['allow_ips'][:256]]

_normalize_config()
_POLICY_KEYS=('auto_block','response_auth_block','response_feed_block','ipv6_auto_block','response_scan_block','fallback_firewall')
_POLICY_LABELS={'auto_block':'automatic blocking','response_auth_block':'failed-login blocking','response_feed_block':'threat-feed blocking',
                'ipv6_auto_block':'IPv6 blocking','response_scan_block':'port-scan blocking','fallback_firewall':'fallback firewall when UFW is off'}
# The dashboard's policy switches. Kept by the unprivileged half (it changes them), so it is in its own
# state directory; /etc/locsecd is read-only to it. The broker does not read it: nothing it decides depends on it.
RUNTIME_POLICY=STATE/'runtime-policy.json'
def _rp_exists():
    # A state directory with the wrong owner (left by a manual fix, say) must not crash the import.
    try: return RUNTIME_POLICY.exists()
    except OSError as e:
        log(f'cannot read {RUNTIME_POLICY}: {e}; the policy defaults are used. Fix: sudo chown -R {WEB_USER}:{WEB_USER} {STATE}','ERROR')
        return False
if ROLE!='broker' and _rp_exists():
    try:
        rp=json.loads(RUNTIME_POLICY.read_text())
        if isinstance(rp,dict):
            for k in _POLICY_KEYS:
                if isinstance(rp.get(k),bool): CFG[k]=rp[k]
            if isinstance(rp.get('notify_on'),dict):
                merged=dict(CFG.get('notify_on',{}))
                for k,v in rp['notify_on'].items():
                    if isinstance(v,bool): merged[str(k)[:64]]=v
                CFG['notify_on']=merged
    except Exception: pass


# Tools that colourise their output even when stdout is not a TTY (rkhunter
# does) leave ANSI escape sequences in everything we capture. Left in, they
# render as escape garbage in the dashboard and in stored JSON reports -- and a
# colour code in front of "Warning:" also defeats rkhunter warning
# classification, which matches on the start of the line.
_ANSI_CSI=re.compile(r'\x1b\[[0-9;?]*[ -/]*[@-~]')
_ANSI_REST=re.compile(r'\x1b[@-Z\\-_]|[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')

def _strip_ansi(text):
    # ESC[<n>C (cursor-forward) is how rkhunter pads its columns; turn it into a
    # single space so words don't run together, then drop the remaining codes.
    text=re.sub(r'\x1b\[[0-9]+C',' ',text)
    return _ANSI_REST.sub('',_ANSI_CSI.sub('',text))

def _bounded_read(buf, tail=20000, head=0):
    # Return at most head+tail characters of a spooled output file: the first
    # `head` bytes (useful when a tool prints its summary first, e.g. AIDE) and
    # the last `tail` bytes (useful when it prints the summary last).
    size=buf.seek(0,2)
    if head and size>head+tail:
        buf.seek(0); h=buf.read(head)
        buf.seek(size-tail); t=buf.read()
        return _strip_ansi(h.decode('utf-8','replace')+f'\n... [{size-head-tail} bytes omitted] ...\n'+t.decode('utf-8','replace'))
    buf.seek(0 if head and size<=head+tail else max(0,size-tail))
    return _strip_ansi(buf.read().decode('utf-8','replace'))

def run(cmd, timeout=60, input_text=None, kill_group=False, head=0, save_to=None, tail=20000, stdin_path=None, stdin_fd=None):
    # Long scans (clamscan/lynis/rkhunter over "/") can emit output far larger
    # than fits comfortably in RAM if buffered through subprocess.PIPE -- a
    # multi-GB stdout blob has previously been observed to bloat the daemon's
    # resident memory during a scan. Spool to a temp file on disk instead
    # and only ever read back the bounded portion we actually keep.
    #
    # kill_group=True additionally runs cmd in its own session and, on
    # timeout, kills that whole process group rather than just the direct
    # child -- for commands like apt-get/unattended-upgrade that can spawn
    # their own children (e.g. dpkg); subprocess.run's own timeout handling
    # only ever signals the one PID it started, which can leave such a child
    # running (and a lock held) after we've already given up and moved on.
    #
    # save_to=<path> additionally writes the COMPLETE output there (mode 0600)
    # for callers that must parse all of it rather than just the tail.
    # head=N keeps the first N bytes as well as the tail when output is large.
    refused=_broker_guard(cmd)
    if refused: return refused
    try:
        # /tmp is a RAM-backed tmpfs on Debian 13, and PrivateTmp pages are charged to
        # this service's MemoryMax: spool large outputs on disk beside LocSec's state.
        spool=str(STATE) if STATE.is_dir() and os.access(STATE,os.W_OK) else None
        with tempfile.TemporaryFile(mode='w+b',dir=spool) as buf:
            data=input_text.encode('utf-8','replace') if input_text is not None else None
            timed_out=False
            if kill_group:
                proc=subprocess.Popen(cmd, stdin=subprocess.PIPE if data is not None else None,
                                       stdout=buf, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    proc.communicate(input=data, timeout=timeout)
                    rc=proc.returncode
                except subprocess.TimeoutExpired:
                    timed_out=True; rc=124
                    try: os.killpg(proc.pid, signal.SIGTERM)
                    except Exception: pass
                    try: proc.wait(timeout=5)
                    except Exception:
                        try: os.killpg(proc.pid, signal.SIGKILL)
                        except Exception: pass
                        try: proc.wait(timeout=5)
                        except Exception: pass
            elif stdin_fd is not None:
                # A descriptor the unprivileged half opened and handed over: the broker never opens its files.
                os.lseek(stdin_fd,0,os.SEEK_SET)
                try:
                    p=subprocess.run(cmd, stdin=stdin_fd, stdout=buf, stderr=subprocess.STDOUT, timeout=timeout, check=False)
                    rc=p.returncode
                except subprocess.TimeoutExpired:
                    timed_out=True; rc=124
            elif stdin_path is not None:
                # The file is opened here, by the caller, and handed over as stdin, so the child
                # never needs (or gets) permission to open anything under LocSec's state itself.
                fd=os.open(str(stdin_path),os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
                with os.fdopen(fd,'rb') as src:
                    if not stat.S_ISREG(os.fstat(src.fileno()).st_mode): return 127,'not a regular file'
                    try:
                        p=subprocess.run(cmd, stdin=src, stdout=buf, stderr=subprocess.STDOUT, timeout=timeout, check=False)
                        rc=p.returncode
                    except subprocess.TimeoutExpired:
                        timed_out=True; rc=124
            else:
                try:
                    p=subprocess.run(cmd, input=data, stdout=buf, stderr=subprocess.STDOUT, timeout=timeout, check=False)
                    rc=p.returncode
                except subprocess.TimeoutExpired:
                    timed_out=True; rc=124
            if save_to:
                try:
                    buf.seek(0)
                    with open(save_to,'wb') as f:
                        os.chmod(save_to,0o600); shutil.copyfileobj(buf,f)
                except Exception as e: log(f'could not save command output to {save_to}: {e}','ERROR')
            out=_bounded_read(buf,tail,head)
            if timed_out:
                out+=f'\n(timed out after {timeout}s'+('; process group terminated)' if kill_group else ')')
            return rc,out
    except Exception as e: return 127,str(e)


def have(cmd):
    return shutil.which(str(cmd)) is not None

# ======================= PRIVILEGE BROKER: core =======================
# The dispatcher, the socket protocol and the argument validators. The verbs
# themselves are in the PRIVILEGE BROKER section further down.
class BrokerRefused(Exception):
    pass

_BROKER_TLS=threading.local()
_REQ=object()
_VERBS={}

def _in_broker():
    return getattr(_BROKER_TLS,'depth',0)>0

def _A(validator,default=_REQ):
    return (validator,default)

def _verb(name,doc,refused=lambda msg:(126,msg),remote=True,returns_fd=False,**spec):
    """Register a verb. remote=False: only the broker itself may use it (as a step of a compound
    verb that holds the right lock or makes the right checks); the socket refuses it."""
    def deco(fn):
        _VERBS[name]={'fn':fn,'spec':spec,'doc':doc,'refused':refused,'remote':remote,'returns_fd':returns_fd}
        return fn
    return deco

_BROKER_REFUSALS={'n':0}

def _logsafe(x,n=160):
    """X quoted for a log line: control and other non-printing characters escaped, at most N
    characters. For values a client chose (a path, a package name) quoted in a refusal."""
    s=str(x)
    return repr(s[:n])+('...' if len(s)>n else '')

def _caller():
    """'pid P uid U' of the client whose request this thread serves (from SO_PEERCRED), or of
    this process when the call did not come over the socket. Every refusal names it."""
    r=getattr(_BROKER_TLS,'req',None)
    if r is not None: return f'pid {r.pid} uid {r.uid}'
    return f'pid {os.getpid()} uid {os.getuid()} (in-process)'

def broker(verb,**args):
    """Run one privileged operation by name. Unknown verbs, unknown arguments, missing
    arguments and arguments that fail validation are refused and logged."""
    if ROLE=='web':
        # The unprivileged half: every verb runs in the root broker, which validates the arguments itself.
        return _broker_call(verb,args)
    ent=_VERBS.get(verb)
    if ent is None:
        log(f'privilege broker: refused unknown verb {str(verb)[:60]!r} from {_caller()}','ERROR'); _BROKER_REFUSALS['n']+=1
        return (126,'refused: unknown privileged operation')
    spec=ent['spec']; clean={}
    try:
        extra=sorted(set(args)-set(spec))
        if extra: raise BrokerRefused(f'unexpected argument {extra[0]!r}')
        for k,(validator,default) in spec.items():
            if k in args:
                try: clean[k]=validator(args[k])
                except BrokerRefused as e: raise BrokerRefused(f'{k}: {e}')
                except Exception: raise BrokerRefused(f'{k}: invalid value')
            elif default is _REQ: raise BrokerRefused(f'missing argument {k!r}')
            else: clean[k]=default
    except BrokerRefused as e:
        msg=f'refused {verb}: {e}'
        log(f'privilege broker: refused {verb} from {_caller()}: {e}','WARN'); _BROKER_REFUSALS['n']+=1
        return ent['refused'](msg)
    _BROKER_TLS.depth=getattr(_BROKER_TLS,'depth',0)+1
    try:
        return ent['fn'](**clean)
    finally:
        _BROKER_TLS.depth-=1

def broker_catalogue():
    """The verb list as text: name, arguments, what it does."""
    out=[]
    for name in sorted(_VERBS):
        ent=_VERBS[name]
        a=', '.join(k+('' if d is _REQ else '?')+(' <fd>' if getattr(v,'_fd',False) else '') for k,(v,d) in ent['spec'].items())
        out.append(f'{name}({a})'+('' if ent['remote'] else '   [broker-internal]')+f'\n    {ent["doc"]}')
    n=len(_VERBS); r=sum(1 for e in _VERBS.values() if e['remote'])
    out.append(f'\n{n} verbs; {r} can be requested by the unprivileged half, {n-r} are steps the broker uses internally.')
    return '\n'.join(out)

# ---- privileged-command guard used by run() and _run_transient() ----
_PRIV_EXEC={'ufw','nft','tcpdump','clamscan','clamdscan','systemd-run','systemd-inhibit','apt-get',
            'unattended-upgrade','freshclam','aideinit','aide','lynis','rkhunter','suricata-update',
            'iptables','ip6tables','iptables-restore','ip6tables-restore'}
_SYSTEMCTL_READ={'is-active','is-enabled','is-failed','show','status','list-units','list-unit-files','list-timers','cat'}
_CMD_WRAPPERS={'nice','ionice','env','timeout','stdbuf'}

def _privileged_cmd(cmd):
    """The privileged program cmd would run, or '' for an ordinary command."""
    try: toks=[str(t) for t in cmd]
    except TypeError: return ''
    while toks and os.path.basename(toks[0]) in _CMD_WRAPPERS:
        toks=toks[1:]
        while toks and (toks[0].startswith('-') or toks[0].isdigit() or '=' in toks[0]): toks=toks[1:]
    if not toks: return ''
    prog=os.path.basename(toks[0])
    if prog in _PRIV_EXEC: return prog
    if prog=='systemctl':
        sub=next((t for t in toks[1:] if not t.startswith('-')),'')
        return '' if sub in _SYSTEMCTL_READ else f'systemctl {sub}'
    return ''

def _broker_guard(cmd):
    """None if cmd may run here, else the refusal (rc, text)."""
    p=_privileged_cmd(cmd)
    if p and not _in_broker():
        log(f'privilege broker: refused to run {p!r} outside a broker verb from {_caller()} (a call site bypasses the broker; this is a LocSec bug)','ERROR')
        _BROKER_REFUSALS['n']+=1
        return (126,f'refused: {p} may only run through the privilege broker')
    return None

# ---- validators ----
def _vb(x):
    if not isinstance(x,bool): raise BrokerRefused('must be true or false')
    return x

def _vint(lo,hi):
    def v(x):
        if isinstance(x,bool) or not (isinstance(x,int) or (isinstance(x,str) and re.fullmatch(r'[0-9]{1,10}',x))):
            raise BrokerRefused('must be a whole number')
        n=int(x)
        if not lo<=n<=hi: raise BrokerRefused(f'must be between {lo} and {hi}')
        return n
    return v

def _vchoice(*opts):
    def v(x):
        if x not in opts: raise BrokerRefused('must be one of '+', '.join(map(str,opts)))
        return x
    return v

def _vtext(n):
    def v(x):
        return re.sub(r'[\x00-\x1f\x7f]+',' ',str(x))[:n]
    return v

def _v_any_net(x):
    t=_block_target(str(x))
    if not t: raise BrokerRefused('not an IP address or network')
    return t

def _v_block_target(x):
    t=_v_any_net(x)
    if isinstance(t,(ipaddress.IPv4Network,ipaddress.IPv6Network)) and t.prefixlen<(8 if t.version==4 else 16):
        raise BrokerRefused(f'{t} is too wide to block (at most /8 for IPv4, /16 for IPv6)')
    return t

_vport=_vint(1,65535)
_vproto=_vchoice('tcp','udp')

def _v_ports(x):
    if not isinstance(x,(list,tuple)) or len(x)>8: raise BrokerRefused('must be a list of at most 8 ports')
    return [_vport(p) for p in x]

_UNIT_RE=re.compile(r'[A-Za-z0-9_.@][A-Za-z0-9_.@-]{0,127}\.service')
def _v_service(x):
    u=str(x)
    if not _UNIT_RE.fullmatch(u): raise BrokerRefused('not a .service unit name')
    return u

_LOCSEC_UNIT_RE=re.compile(r'locsecd-[a-z-]+-p\d+-[0-9a-f]{8}\.service')
def _v_locsec_units(x):
    if not isinstance(x,(list,tuple)) or not 1<=len(x)<=200: raise BrokerRefused('must be a list of 1 to 200 units')
    out=[]
    for u in x:
        u=str(u)
        if not _LOCSEC_UNIT_RE.fullmatch(u) or u.startswith(_APT_UNIT_PREFIX): raise BrokerRefused(f'{u[:80]!r} is not a LocSec job unit')
        out.append(u)
    return out

# Never ending in '-': to apt-get install, "name-" (or "name:arch-") means REMOVE it (4.0.11-101).
_PKG_RE=re.compile(r'[a-z0-9](?:[a-z0-9+.-]{0,98}[a-z0-9+.])?(?::[a-z0-9](?:[a-z0-9-]{0,29}[a-z0-9])?)?')
def _v_pkg_names(x):
    if not isinstance(x,(list,tuple)) or not 1<=len(x)<=5000: raise BrokerRefused('must be a list of 1 to 5000 package names')
    out=[]
    for p in x:
        p=str(p)
        if not _PKG_RE.fullmatch(p): raise BrokerRefused(f'{p[:80]!r} is not a package name')
        out.append(p)
    return out

# Packages LocSec may install: its own Depends (the Overview "Add" button) and the two extras.
def _installable_pkgs():
    return {i['pkg'] for i in _TOOL_INFO.values()}|{'clamav-freshclam','suricata-update'}

def _v_installable(x):
    pk=_v_pkg_names(x)
    bad=[p for p in pk if p not in _installable_pkgs()]
    if bad: raise BrokerRefused(f'{bad[0]!r} is not a package LocSec installs')
    return pk

_IFACE_RE=re.compile(r'[A-Za-z0-9_.:][A-Za-z0-9_.:-]{0,31}')
def _v_iface(x):
    s=str(x)
    if not _IFACE_RE.fullmatch(s): raise BrokerRefused('not an interface name')
    return s

def _v_uid(x):
    u=_vint(1,2**31-2)(x)
    if not os.path.exists(f'/run/user/{u}/bus'): raise BrokerRefused('that user has no session bus')
    return u

_QID_RE=re.compile(r'[0-9a-f]{16}')
def _v_qid(x):
    s=str(x)
    if not _QID_RE.fullmatch(s): raise BrokerRefused('not a quarantine id')
    return s

def _v_user_file(x):
    """An existing regular file given by absolute path, never through a final symlink,
    and not already in the quarantine vault."""
    raw=Path(str(x))
    if not raw.is_absolute(): raise BrokerRefused('path must be absolute')
    src=raw.parent.resolve()/raw.name
    if src.is_symlink() or not src.is_file(): raise BrokerRefused('not a regular file')
    if str(src).startswith(str(QUAR.resolve())+os.sep): raise BrokerRefused('file is in the quarantine vault')
    return str(src)

def _v_state_file(dirfn,pattern):
    rx=re.compile(pattern)
    def v(x):
        p=Path(str(x)); d=dirfn()
        if p.parent!=d or not rx.fullmatch(p.name): raise BrokerRefused('not a LocSec work file')
        return str(p)
    return v

_AIDE_CONFS=('/etc/aide/aide.conf','/var/lib/aide/aide.conf.autogenerated')


# ---- the socket between the two halves (4.0.11-91) ----
# One request per connection: a 4-byte big-endian length, then JSON. Open file descriptors travel
# with the first 4 bytes as SCM_RIGHTS, so the broker never has to open a path the unprivileged
# side chose. The peer is identified by SO_PEERCRED, which the kernel fills in, not by anything
# the client says.
_BROKER_MAX_REQ=16<<20
_BROKER_MAX_RESP=96<<20

class PassFD(int):
    """An open file descriptor handed to (or returned by) the broker."""

def _sock_send(sock,obj,fds=()):
    data=json.dumps(obj,separators=(',',':'),default=str).encode('utf-8')
    hdr=struct.pack('>I',len(data))
    if fds: sock.sendmsg([hdr],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,array.array('i',[int(f) for f in fds]))])
    else: sock.sendall(hdr)
    sock.sendall(data)

def _sock_recv(sock,limit,maxfds=4):
    fds=[]; hdr=b''
    try:
        while len(hdr)<4:
            msg,anc,flags,_a=sock.recvmsg(4-len(hdr),socket.CMSG_SPACE(maxfds*4),socket.MSG_CMSG_CLOEXEC)
            for lvl,typ,data in anc:
                if lvl==socket.SOL_SOCKET and typ==socket.SCM_RIGHTS:
                    a=array.array('i'); a.frombytes(data[:len(data)-len(data)%a.itemsize]); fds.extend(a)
            if flags&socket.MSG_CTRUNC: raise ValueError('too many file descriptors')
            if not msg: raise EOFError('connection closed')
            hdr+=msg
        n=struct.unpack('>I',hdr)[0]
        if n>limit: raise ValueError(f'message of {n} bytes is over the {limit}-byte limit')
        buf=bytearray()
        while len(buf)<n:
            chunk=sock.recv(min(1<<20,n-len(buf)))
            if not chunk: raise EOFError('connection closed')
            buf+=chunk
        return json.loads(buf.decode('utf-8')),fds
    except BaseException:
        for f in fds:
            try: os.close(f)
            except OSError: pass
        raise

class _Req:
    """What the broker knows about the request a thread is serving."""
    def __init__(self,pid,uid,bind):
        self.pid=pid; self.uid=uid; self.bind=bind
        self.cancel=threading.Event(); self.units=set()

def _req():
    return getattr(_BROKER_TLS,'req',None)

def _client_pid():
    r=_req()
    return r.pid if r is not None else os.getpid()

def _cancelled():
    r=_req()
    return STOP_EVENT.is_set() or (r is not None and r.cancel.is_set())

_BROKER_DOWN_LOGGED=[0.0]

def _broker_call(verb,args):
    """Web side: ask the root broker for VERB. Never raises; a failure returns the verb's refusal value."""
    ent=_VERBS.get(verb)
    refused=ent['refused'] if ent else (lambda m:(126,m))
    names=[k for k,v in args.items() if isinstance(v,PassFD)]
    plain={k:v for k,v in args.items() if k not in names}
    s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    try:
        s.connect(BROKER_SOCK)
        _sock_send(s,{'verb':verb,'args':plain,'fd_args':names,'bind':bool(DAEMON_MODE)},[args[k] for k in names])
        resp,fds=_sock_recv(s,_BROKER_MAX_RESP,1)
    except (FileNotFoundError,ConnectionRefusedError):
        if time.time()-_BROKER_DOWN_LOGGED[0]>60:
            _BROKER_DOWN_LOGGED[0]=time.time()
            log('privilege broker is not running (locsecd-broker.service); privileged operations fail until it is back','ERROR')
        return refused('refused: the LocSec privilege broker is not running (sudo systemctl restart locsecd)')
    except PermissionError:
        return refused('refused: no access to the privilege broker (run this as root, through locsecctl)')
    except Exception as e:
        log(f'privilege broker call {verb} failed: {e}','ERROR')
        return refused(f'refused: privilege broker error: {e}')
    finally:
        s.close()
    if not isinstance(resp,dict): return refused('refused: malformed broker reply')
    if 'refused' in resp:
        log(f'privilege broker refused {verb}: {str(resp["refused"])[:300]}','WARN')
        for f in fds: os.close(f)
        return refused(str(resp['refused']))
    if resp.get('fd'):
        if fds: return PassFD(fds[0])
        return refused('refused: the broker returned no file')
    for f in fds: os.close(f)
    return resp.get('result')

def _root_side(name,doc,after=None,refused=None,local=(),**spec):
    """Make FN a compound verb that always runs in the root broker. The unprivileged side calls the
    same function name and gets the result over the socket; AFTER(result,args) then runs on the
    calling side, for whatever the unprivileged half records (incidents, job times). Arguments named
    in LOCAL are only for AFTER and are never sent."""
    def deco(fn):
        _verb(name,doc,refused=refused or (lambda m:{'ok':False,'error':m}),**spec)(fn)
        sig=inspect.signature(fn)
        @functools.wraps(fn)
        def _root_side_call(*a,**kw):
            args=dict(sig.bind(*a,**kw).arguments)
            for k in local:
                if k not in args: args[k]=sig.parameters[k].default
            r=broker(name,**{k:v for k,v in args.items() if k not in local})
            if after is not None and ROLE!='broker':
                try: after(r,args)
                except Exception as e: log(f'{name}: {e}','ERROR')
            return r
        _root_side_call._root_impl=fn
        return _root_side_call
    return deco

def _sd_notify(msg):
    addr=os.environ.get('NOTIFY_SOCKET')
    if not addr: return
    if addr.startswith('@'): addr='\0'+addr[1:]
    try:
        s=socket.socket(socket.AF_UNIX,socket.SOCK_DGRAM)
        try: s.connect(addr); s.sendall(msg.encode())
        finally: s.close()
    except OSError: pass

# ---- descriptor validators: only accepted when the descriptor really came over the socket ----
def _v_fd_read(x):
    fd=int(x)
    if not stat.S_ISREG(os.fstat(fd).st_mode): raise BrokerRefused('not a regular file')
    if fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==os.O_WRONLY: raise BrokerRefused('not open for reading')
    return fd
_v_fd_read._fd=True

def _v_fd_write(x):
    fd=int(x)
    if not stat.S_ISREG(os.fstat(fd).st_mode): raise BrokerRefused('not a regular file')
    if fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==os.O_RDONLY: raise BrokerRefused('not open for writing')
    return fd
_v_fd_write._fd=True

# ---- reading root-only system files from the unprivileged side ----
# auth.log, syslog and ufw.log are readable through the adm group, and the journal through
# systemd-journal. Whatever is still root-only (the Lynis report, rkhunter's log, Suricata's logs on
# some systems) is opened by the broker, read-only, from this fixed list only, and the open
# descriptor is handed over.
_PRIV_READ_EXACT={'/var/log/auth.log','/var/log/syslog','/var/log/ufw.log','/var/log/rkhunter.log',
                  '/var/log/lynis-report.dat','/var/log/lynis.log','/var/log/aide/aide.log',
                  '/var/log/clamav/freshclam.log','/etc/suricata/suricata.yaml','/etc/rkhunter.conf',
                  '/etc/clamav/clamd.conf'}
_PRIV_READ_RE=re.compile(r'/var/log/suricata/[A-Za-z0-9_.-]{1,64}\.(?:json|log)')

def _v_priv_read_path(x):
    p=str(x)
    eve=str(CFG.get('ids_eve_path') or '')
    if not (p in _PRIV_READ_EXACT or _PRIV_READ_RE.fullmatch(p) or (p==eve and p.startswith('/var/log/'))):
        raise BrokerRefused(f'{_logsafe(p)} is not a file LocSec reads')
    if os.path.realpath(p)!=p: raise BrokerRefused(f'{_logsafe(p)} goes through a symbolic link')
    return p

def _priv_open(path):
    """Open PATH for reading (binary). A root-only system log is opened by the broker instead."""
    p=str(path)
    try:
        fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NONBLOCK)
    except PermissionError:
        if ROLE!='web': raise
        fd=broker('file.open',path=p)
        if fd is None or int(fd)<0: raise
    return os.fdopen(int(fd),'rb')

def _pstat(path):
    """os.stat(PATH), asking the broker for a root-only system file."""
    try:
        return os.stat(str(path))
    except PermissionError:
        if ROLE!='web': raise
        r=broker('file.stat',path=str(path))
        if not isinstance(r,dict): raise
        if not r.get('exists'): raise FileNotFoundError(errno.ENOENT,'No such file or directory',str(path))
        return types.SimpleNamespace(**{k:r[k] for k in ('st_mode','st_size','st_mtime','st_ino','st_dev')})

def _pexists(path):
    try: _pstat(path); return True
    except (OSError,ValueError): return False

# ===================== PRIVILEGE BROKER: core (end) =====================


def append_line(path, text, mode=0o600):
    """Append one newline-terminated record, repairing a truncated last line.

    These logs are appended to constantly and the daemon can be killed at any
    moment -- SIGKILL after TimeoutStopSec, an OOM kill, power loss. A write
    interrupted part-way leaves a line with no terminating newline, and the
    next plain append then lands on that same line: the partial record is
    unparseable (readers skip it, which is correct) but so is the good record
    welded onto it, so a crash silently costs the NEXT incident as well as the
    interrupted one. Checking the final byte first costs one seek per append
    and confines the damage to the record that was actually interrupted.
    """
    # Binary: a record cut off in the middle of a UTF-8 character made the text-mode read(1)
    # raise UnicodeDecodeError on every later append, and log() then lost every line.
    with open(path,'ab+') as f:
        try:
            f.seek(0,os.SEEK_END)
            if f.tell():
                f.seek(-1,os.SEEK_END)
                if f.read(1)!=b'\n':
                    f.write(b'\n')
        except OSError:
            pass                      # unseekable is not a reason to drop the record
        f.write((text if text.endswith('\n') else text+'\n').encode('utf-8','surrogateescape'))
    try: os.chmod(path,mode)
    except OSError: pass

def atomic_json(path,data):
    # A unique temporary name: two writers (the daemon and a locsecctl one-shot) used the
    # same "<file>.tmp", so one could rename the other's half-written file into place.
    fd,tmp=tempfile.mkstemp(prefix='.'+path.name+'.',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            f.write(json.dumps(data,indent=2,sort_keys=True))
        os.chmod(tmp,0o600)
        os.replace(tmp,path)
    except BaseException:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def prune_runtime_state():
    # Keep bounded local state so a 24/7 daemon cannot grow without limit.
    for root,pattern,keep in ((REPORTS,'*.json',int(CFG.get('max_report_count',100))),(REPORTS,'aide-full-*.txt',10),(CAPTURES,'*.pcapng',int(CFG.get('max_capture_count',20)))):
        try:
            files=sorted(root.glob(pattern),key=lambda x:x.stat().st_mtime,reverse=True)
            for f in files[keep:]: f.unlink(missing_ok=True)
        except Exception as e: log(f'state prune failed for {root}: {e}','ERROR')
    # Age-based retention: delete reports, quarantine metadata and old incident
    # lines past retention_days regardless of the count caps above. Runs on
    # every prune cycle (same cadence as the count-based prune).
    try:
        days=max(1,int(CFG.get('retention_days',14))); cutoff=time.time()-days*86400
        # Incidents have their own retention window (incident_ttl_days), separate from the
        # reports/captures/log window above -- an incident timeline is usually worth keeping
        # longer than the raw scan output that produced it.
        inc_cutoff=time.time()-max(1,int(CFG.get('incident_ttl_days',30)))*86400
        for root,pattern in ((CAPTURES,'*.pcapng',),):
            for f in root.glob(pattern):
                try:
                    if f.stat().st_mtime<cutoff: f.unlink(missing_ok=True)
                except Exception: pass
        # Reports: everything in the reports directory, whatever its name,
        # once it is report_retention_days old (7 by default).
        rdays=max(1,int(CFG.get('report_retention_days',7))); rcut=time.time()-rdays*86400; gone=0
        try: entries=list(REPORTS.iterdir())
        except OSError: entries=[]
        for f in entries:
            try:
                if f.is_symlink() or not f.is_file(): continue
                if f.stat().st_mtime<rcut: f.unlink(); gone+=1
            except OSError: pass
        if gone: log(f'reports older than {rdays} days removed: {gone}')
        # Both rewrites below hold LOCK. incident() and _action_log() append to
        # these files from the HTTP and monitor threads; a rewrite that read the
        # file, let an append land, then replaced it dropped that record for good.
        with LOCK:
            if INCIDENTS.exists():
                kept=[]
                for line in INCIDENTS.read_text(errors='replace').splitlines():
                    try:
                        rec=json.loads(line)
                        ts=float(rec.get('updated') or rec.get('ts') or 0)
                        if ts>=inc_cutoff: kept.append(line)
                    except Exception:
                        continue
                tmp=INCIDENTS.with_suffix('.tmp'); tmp.write_text('\n'.join(kept)+('\n' if kept else ''),encoding='utf-8')
                os.chmod(tmp,0o600); os.replace(tmp,INCIDENTS)
                _INC['loaded']=False       # the in-memory index described the old file
            # incident-actions.jsonl had no retention at all: every Investigate,
            # Contain, Resolve and Confirm appended a line that was never removed.
            if INCIDENT_ACTIONS.exists():
                rows=[l for l in _tail_lines(INCIDENT_ACTIONS,20000) if l.strip()]
                kept=[]
                for l in rows:
                    try:
                        if float(json.loads(l).get('ts',0))>=inc_cutoff: kept.append(l)
                    except Exception: continue
                if len(kept)!=len(rows) or INCIDENT_ACTIONS.stat().st_size>4*1024*1024:
                    tmp=INCIDENT_ACTIONS.with_suffix('.tmp')
                    tmp.write_text('\n'.join(kept)+('\n' if kept else ''),encoding='utf-8')
                    os.chmod(tmp,0o600); os.replace(tmp,INCIDENT_ACTIONS)
        for logfile in list(LOG.parent.glob('locsecd.log*')):
            try:
                if logfile.stat().st_mtime<cutoff: logfile.unlink(missing_ok=True)
            except Exception: pass
    except Exception as e: log(f'age-based retention prune failed: {e}','ERROR')



def _tail_lines(path, limit, max_bytes=2000000):
    # Read only the end of a growing append-only file. recent_incidents() used to
    # pull the whole incidents log into memory and then keep the last few lines:
    # with incident_retention at its 10000 default that is several megabytes read,
    # decoded and split on every /api/status call.
    try:
        with _priv_open(path) as f:
            size=f.seek(0,2)
            f.seek(max(0,size-max_bytes))
            data=f.read()
    except OSError:
        return []
    lines=data.decode('utf-8','replace').splitlines()
    # A partial first line is possible whenever the window started mid-file.
    if size>max_bytes and lines: lines=lines[1:]
    return lines[-limit:] if limit else lines

def _incident_key(rec):
    return (str(rec.get('kind','')), str(rec.get('source','')), str(rec.get('indicator','')))

# ---------------------------------------------------------------------------
# Incident store: append-only log with periodic compaction.
#
# incidents.jsonl holds one complete record per line, and for any given id the
# LAST line wins. A delete appends a tombstone. Nothing rewrites the file except
# compact_incidents().
#
# The previous design read the entire file, mutated a list and wrote all of it
# back for every single detection. At the 10000-record default that is a
# multi-megabyte read-modify-write per event while holding LOCK, so a port-scan
# burst turned into tens of megabytes of I/O per second.
#
# What stays in memory is deliberately small: the active incidents (the only
# ones eligible for deduplication, normally a handful) and the set of live ids
# (for the Overview counter). Operations on an arbitrary id read a bounded
# window from the end of the log -- which is where anything the dashboard can
# show came from -- and widen to the whole file only if that misses.
# ---------------------------------------------------------------------------
_INC_ACTIVE_STATES=('new','investigating','contained')
_INC={'loaded':False,'active':{},'ids':set(),'appends':0}
_INC_COMPACT_APPENDS=2000
_INC_LOAD_MAX_BYTES=256*1024*1024

def _incident_retention():
    return max(100,min(100000,int(CFG.get('incident_retention',10000))))

def _inc_resolve(lines):
    """Collapse raw log lines into the current record per id, in first-seen order."""
    order=[]; byid={}
    for line in lines:
        if not line.strip(): continue
        try: rec=json.loads(line)
        except Exception: continue
        if not isinstance(rec,dict): continue
        ident=str(rec.get('id',''))
        if rec.get('_op')=='delete':
            byid.pop(ident,None); continue
        if not ident: continue
        if ident not in byid: order.append(ident)
        byid[ident]=rec
    return [byid[i] for i in order if i in byid]

def _inc_load():
    """Build the in-memory index once per process. Call with LOCK held."""
    if _INC['loaded']: return
    active={}; ids=set()
    for rec in _inc_resolve(_tail_lines(INCIDENTS,0,max_bytes=_INC_LOAD_MAX_BYTES)):
        ids.add(str(rec.get('id','')))
        if str(rec.get('state','new')) in _INC_ACTIVE_STATES:
            active[_incident_key(rec)]=rec
    _INC['active']=active; _INC['ids']=ids; _INC['appends']=0; _INC['loaded']=True

def _inc_append(obj):
    append_line(INCIDENTS, json.dumps(obj,separators=(',',':')))
    _INC['appends']+=1

def _inc_find(ident):
    """Current record for one id, without reading more of the log than needed."""
    ident=str(ident)[:64]
    if not ident: return None
    try: size=INCIDENTS.stat().st_size
    except OSError: return None
    windows=[4*1024*1024]
    if size>windows[0]: windows.append(_INC_LOAD_MAX_BYTES)
    for w in windows:
        for rec in reversed(_inc_resolve(_tail_lines(INCIDENTS,0,max_bytes=w))):
            if str(rec.get('id',''))==ident: return rec
    return None

def _inc_store(rec):
    """Persist a new or changed record and keep the in-memory view in step."""
    ident=str(rec.get('id','')); key=_incident_key(rec)
    _inc_append(rec)
    _INC['ids'].add(ident)
    if str(rec.get('state','new')) in _INC_ACTIVE_STATES:
        cur=_INC['active'].get(key)
        # Reopening an old record must not hide a newer active one for the same key.
        if cur is None or str(cur.get('id',''))==ident or float(cur.get('ts') or 0)<=float(rec.get('ts') or 0):
            _INC['active'][key]=rec
    else:
        cur=_INC['active'].get(key)
        if cur is not None and str(cur.get('id',''))==ident: _INC['active'].pop(key,None)
    if _INC['appends']>=_INC_COMPACT_APPENDS: compact_incidents()

def _inc_forget(ident):
    ident=str(ident)[:64]
    _inc_append({'_op':'delete','id':ident,'ts':time.time()})
    _INC['ids'].discard(ident)
    for k,v in list(_INC['active'].items()):
        if str(v.get('id',''))==ident: _INC['active'].pop(k,None)

def compact_incidents():
    """The only writer that rewrites the log: one current record per incident,
    oldest first, within incident_retention and incident_ttl_days."""
    try:
        recs=_inc_resolve(_tail_lines(INCIDENTS,0,max_bytes=_INC_LOAD_MAX_BYTES))
        cutoff=time.time()-max(1,int(CFG.get('incident_ttl_days',30)))*86400
        def _ts(r):
            try: return float(r.get('updated') or r.get('ts') or 0)
            except Exception: return 0.0
        kept=[r for r in recs if _ts(r)>=cutoff]
        kept.sort(key=_ts)
        kept=kept[-_incident_retention():]
        tmp=INCIDENTS.with_suffix('.tmp')
        with tmp.open('w',encoding='utf-8') as f:
            for rec in kept: f.write(json.dumps(rec,separators=(',',':'))+'\n')
        os.chmod(tmp,0o600); os.replace(tmp,INCIDENTS)
        _INC['loaded']=False; _inc_load()
        return len(kept)
    except Exception as e:
        log(f'incident log compaction failed: {e}','ERROR'); return -1

def _action_log(rec_id, action, message, detail=''):
    entry={'ts':time.time(),'incident_id':str(rec_id)[:64],'action':str(action)[:32],
           'message':str(message)[:1000],'detail':str(detail)[:4000]}
    try:
        with LOCK: append_line(INCIDENT_ACTIONS, json.dumps(entry,separators=(',',':')))
    except Exception as e: log(f'incident action log failed: {e}','ERROR')
    log(f'incident={rec_id} action={action}: {message}')

# Desktop notifications. The daemon sends them itself, as a normal desktop
# notification in the session of each logged-in graphical user, so they appear
# (and are kept in the desktop's notification list) whether or not the
# dashboard window is open. Each one asks for a 10 second display time.
_NOTIFY_TITLES={'virus-found':'Virus found','rootkit-warning':'Rootkit warning','block':'IP blocked',
                'login-failure':'Failed login','port-scan':'Port scan detected','ids-alert':'Attack pattern seen',
                'firewall-fallback':'Fallback firewall turned on','test':'Test notification'}
_NOTIFY_ICONS={'virus-found':'dialog-error','rootkit-warning':'dialog-error','test':'dialog-information'}
_NOTIFY_SECONDS=10
_NOTIFY_KINDS=('virus-found','rootkit-warning','block','login-failure','port-scan','ids-alert','firewall-fallback')
_NOTIFY_Q=queue.Queue(maxsize=200)
_NOTIFY_SEEN={}
_NOTIFY_LOCK=threading.Lock()

def _notify_desktop(rec,force=False):
    """Queue a notification for a new incident of a kind the operator ticked."""
    kind=str(rec.get('kind',''))
    if not force and not CFG.get('notify_on',{}).get(kind): return
    ind=str(rec.get('indicator',''))
    if not force:
        now=time.time()
        with _NOTIFY_LOCK:
            # The same kind and address is not announced again for ten minutes.
            if now-_NOTIFY_SEEN.get((kind,ind),0)<600: return
            if len(_NOTIFY_SEEN)>2000: _NOTIFY_SEEN.clear()
            _NOTIFY_SEEN[(kind,ind)]=now
    try: _NOTIFY_Q.put_nowait((kind,ind,str(rec.get('detail',''))))
    except queue.Full: pass

def _desktop_users():
    """Uids with an active, local, graphical session. Whether that user has a session bus is checked
    by the broker (notify.desktop): this half runs as locsec with ProtectHome=true, which hides
    /run/user, so a check here always failed and no notification was ever shown (4.0.11-91 to -98)."""
    uids=[]
    if not have('loginctl'): return uids
    rc,out=run(['loginctl','list-sessions','--no-legend','--no-pager'],10)
    if rc!=0: return uids
    for line in out.splitlines():
        parts=line.split()
        if len(parts)<2 or not parts[1].isdigit() or int(parts[1])==0 or int(parts[1]) in uids: continue
        if not re.fullmatch(r'[A-Za-z0-9_.-]+',parts[0]): continue
        rc,o=run(['loginctl','show-session',parts[0],'-p','Type','-p','Active','-p','Remote'],10)
        info=dict(l.split('=',1) for l in o.splitlines() if '=' in l)
        if (rc==0 and info.get('Type') in ('x11','wayland') and info.get('Active')=='yes'
                and info.get('Remote','no')=='no'):
            uids.append(int(parts[1]))
    return uids

def _desktop_send(uid,kind,title,body):
    # Built and run by the privilege broker (notify.desktop): as the user, in a unit
    # that has nothing but that user's session bus. True only when it was shown.
    return broker('notify.desktop',uid=uid,kind=str(kind),title=str(title),body=str(body)) is True

# Every notification LocSec raises is kept here, so it survives a logout, reboot or
# restart (a desktop's own notification list does not), and one raised while nobody
# was logged in is shown as a summary at the next log-in instead of being lost.
NOTIFY_LOG=STATE/'notifications.jsonl'
_NOTIFY_LOG_KEEP=500
_NOTIFY_LOG_LOCK=threading.Lock()

def _notify_history(limit=200):
    rows=[]
    for line in _tail_lines(NOTIFY_LOG,max(1,min(limit,_NOTIFY_LOG_KEEP)),max_bytes=1000000):
        try:
            r=json.loads(line)
            if isinstance(r,dict): rows.append(r)
        except Exception: pass
    return rows

def _notify_record(entries):
    if not entries: return
    with _NOTIFY_LOG_LOCK:
        try:
            for e in entries: append_line(NOTIFY_LOG,json.dumps(e,separators=(',',':')),0o600)
            # Keep the newest _NOTIFY_LOG_KEEP; rewrite only once it is well past that.
            if NOTIFY_LOG.stat().st_size>400000:
                keep=_tail_lines(NOTIFY_LOG,_NOTIFY_LOG_KEEP,max_bytes=1000000)
                tmp=NOTIFY_LOG.with_suffix('.tmp'); tmp.write_text('\n'.join(keep)+'\n',encoding='utf-8')
                os.chmod(tmp,0o600); os.replace(tmp,NOTIFY_LOG)
        except Exception as e: log(f'notification history: {e}','ERROR')

def _notify_mark_delivered():
    with _NOTIFY_LOG_LOCK:
        try:
            lines=_tail_lines(NOTIFY_LOG,_NOTIFY_LOG_KEEP,max_bytes=1000000); out=[]
            for line in lines:
                try:
                    r=json.loads(line)
                    if isinstance(r,dict) and r.get('shown') is False: r['shown']='later'
                    out.append(json.dumps(r,separators=(',',':')))
                except Exception: pass
            tmp=NOTIFY_LOG.with_suffix('.tmp'); tmp.write_text('\n'.join(out)+('\n' if out else ''),encoding='utf-8')
            os.chmod(tmp,0o600); os.replace(tmp,NOTIFY_LOG)
        except Exception as e: log(f'notification history: {e}','ERROR')

def clear_notify_history():
    with _NOTIFY_LOG_LOCK:
        try: NOTIFY_LOG.unlink()
        except FileNotFoundError: pass
        except OSError as e: return {'ok':False,'error':str(e)}
    log('notification history cleared')
    return {'ok':True}

def _deliver_missed():
    """At log-in: one summary of the notifications raised while nobody was logged in."""
    missed=[r for r in _notify_history(_NOTIFY_LOG_KEEP) if r.get('shown') is False]
    if not missed: return
    users=_desktop_users()
    if not users: return
    kinds={}
    for r in missed: kinds[r.get('kind','')]=kinds.get(r.get('kind',''),0)+1
    parts=[f'{n} {_NOTIFY_TITLES.get(k,k).lower()}' for k,n in sorted(kinds.items(),key=lambda kv:-kv[1])]
    body='While you were away: '+', '.join(parts[:5])+('. ' if parts else '')+'Open LocSec, Incidents, for the list.'
    sent=[_desktop_send(uid,'test','LocSec: '+str(len(missed))+' alert(s) while you were away',body) for uid in users]
    # Marked as shown only once a summary really reached a desktop; otherwise it is tried again.
    if any(sent): _notify_mark_delivered()

def _deliver_notifications(batch):
    users=_desktop_users()
    by={}
    for kind,ind,detail in batch: by.setdefault(kind,[]).append((ind,detail))
    msgs=[]
    single=len(batch)<=3
    for kind,items in by.items():
        title='LocSec: '+_NOTIFY_TITLES.get(kind,kind.replace('-',' '))
        if single or len(items)==1:
            for ind,detail in items: msgs.append((kind,title,(ind+' \u2014 ' if ind and detail else ind)+detail))
        else:
            sample=', '.join(i for i,_ in items[:4] if i)
            msgs.append((kind,title,f'{len(items)} new'+(f': {sample}' if sample else '')+(', ...' if len(items)>4 else '')))
    now=time.time()
    shown=False
    for uid in users:
        for kind,title,body in msgs[:6]:
            if _desktop_send(uid,kind,title,body): shown=True
    # "shown" is what happened, not whether a session was found: a notification the desktop did
    # not show is kept as waiting, and summarised at the next log-in.
    _notify_record([{'ts':now,'kind':k,'title':t,'text':b[:300],'shown':shown} for k,t,b in msgs[:20] if k!='test'])
    if not users:
        log('desktop notification not shown now: no local graphical session is active; it is shown at the next log-in','INFO')
    elif not shown:
        log(f'desktop notification not shown: the desktop session(s) of uid {", ".join(map(str,users))} did not accept it '
            '(journalctl -t locsecd-broker says why); it is shown at the next log-in','WARN')

def _notifier_loop():
    last_missed=0.0
    while not STOP_EVENT.is_set():
        if time.time()-last_missed>=30:
            last_missed=time.time()
            try: _deliver_missed()
            except Exception as e: log(f'desktop notifier (missed alerts): {e}','ERROR')
        try: first=_NOTIFY_Q.get(timeout=2)
        except queue.Empty: continue
        batch=[first]
        STOP_EVENT.wait(1.5)     # let a burst (a feed refresh blocking many addresses) collect
        while True:
            try: batch.append(_NOTIFY_Q.get_nowait())
            except queue.Empty: break
        try: _deliver_notifications(batch)
        except Exception as e: log(f'desktop notifier: {e}','ERROR')

def incident(kind, source, indicator='', severity='medium', action='logged', detail=''):
    if ROLE=='broker':
        # Incidents belong to the unprivileged half; a broker step that reaches here only logs it.
        log(f'(incident for the dashboard) {kind} {indicator}: {str(detail)[:300]}','WARN'); return None
    """Upsert an active incident; repeated polling/feed observations become count/last_seen."""
    key=(str(kind)[:64],str(source)[:64],str(indicator)[:512]); now=time.time()
    try:
        with LOCK:
            _inc_load()
            rec=_INC['active'].get(key)
            if rec is not None:
                rec['last_seen']=now; rec['count']=int(rec.get('count',1))+1
                rec['severity']=str(severity)[:16]; rec['action']=str(action)[:64]
                rec['detail']=str(detail)[:2000]; rec['updated']=now
                _inc_store(rec)
                return rec
            rec={'id':hashlib.sha256(f'{time.time_ns()}|{kind}|{source}|{indicator}'.encode()).hexdigest()[:24],
                 'ts':now,'last_seen':now,'count':1,'kind':key[0],'source':key[1],
                 'indicator':key[2],'severity':str(severity)[:16],'action':str(action)[:64],
                 'detail':str(detail)[:2000],'state':'new'}
            _inc_store(rec)
        _action_log(rec['id'],'create',f'New {kind} incident from {source}',detail)
        _notify_desktop(rec)
        return rec
    except Exception as e:
        log(f'incident write failed: {e}','ERROR'); return {'id':'','state':'new'}

def delete_incident(identifier):
    ident=str(identifier)[:64]
    with LOCK:
        _inc_load()
        if ident not in _INC['ids'] and _inc_find(ident) is None:
            return {'ok':False,'error':'incident not found'}
        _inc_forget(ident)
    try:
        with LOCK:
            if INCIDENT_ACTIONS.exists():
                # Guard each line: an unparseable one used to raise out of the whole
                # comprehension, so a single corrupt record left every deleted
                # incident's action rows behind from then on.
                lines=[]
                for l in INCIDENT_ACTIONS.read_text(errors='replace').splitlines():
                    if not l.strip(): continue
                    try: drop=json.loads(l).get('incident_id','')==ident
                    except Exception: drop=False
                    if not drop: lines.append(l)
                tmp=INCIDENT_ACTIONS.with_suffix('.tmp'); tmp.write_text('\n'.join(lines)+('\n' if lines else ''),encoding='utf-8')
                os.chmod(tmp,0o600); os.replace(tmp,INCIDENT_ACTIONS)
    except Exception as e: log(f'incident action-log cleanup failed: {e}','ERROR')
    log(f'incident {ident} deleted')
    return {'ok':True}

def delete_all_incidents():
    with LOCK:
        try:
            INCIDENTS.write_text('',encoding='utf-8'); os.chmod(INCIDENTS,0o600)
        except OSError as e: log(f'incident log clear failed: {e}','ERROR')
        _INC['active']={}; _INC['ids']=set(); _INC['appends']=0; _INC['loaded']=True
    try:
        if INCIDENT_ACTIONS.exists():
            os.chmod(INCIDENT_ACTIONS,0o600); INCIDENT_ACTIONS.write_text('',encoding='utf-8')
    except Exception as e: log(f'incident action-log clear failed: {e}','ERROR')
    log('all incidents deleted','WARN')
    return {'ok':True}

def incident_actions(identifier, limit=100):
    ident=str(identifier)[:64]
    try:
        rows=[]
        for line in _tail_lines(INCIDENT_ACTIONS,1000):
            try:
                x=json.loads(line)
                if str(x.get('incident_id',''))==ident: rows.append(x)
            except Exception: pass
        return rows[-max(1,min(int(limit),200)):]
    except Exception: return []

def _incident_evidence(rec):
    """Collect bounded local evidence for a human-readable incident explanation."""
    indicator=str(rec.get('indicator','')); evidence=[]
    if indicator and have('journalctl'):
        # indicator can come from threat-feed or log data outside our control;
        # --grep treats it as a PCRE regex, so escape it rather than passing it
        # through raw.
        _,out=run(['journalctl','--no-pager','--since','-30 minutes','--grep',re.escape(indicator.split('/')[0])],20)
        if out.strip(): evidence.append('Recent journal matches:\n'+out[-5000:])
    if indicator and have('ss'):
        _,out=broker('net.sockets',view='connections')
        hits=[x for x in out.splitlines() if indicator.split('/')[0] in x][:40]
        if hits: evidence.append('Current socket matches:\n'+'\n'.join(hits))
    detail=str(rec.get('detail',''))
    if detail: evidence.append('Recorded detector detail:\n'+detail[:4000])
    return '\n\n'.join(evidence)[-10000:] or 'No additional local evidence was available.'

def incident_action(identifier, action):
    ident=str(identifier)[:64]; action=str(action).lower().strip()
    action={'investigate':'explain','contain':'fix','resolve':'resolve'}.get(action,action)
    if action not in {'explain','fix','resolve'}: return {'ok':False,'error':'invalid incident action'}
    with LOCK:
        _inc_load(); rec=_inc_find(ident)
    if not rec: return {'ok':False,'error':'incident not found'}
    rec=dict(rec); indicator=str(rec.get('indicator','')); did=None; new_state=str(rec.get('state','new'))
    if action=='explain':
        if new_state=='new': new_state='investigating'
        summary='Explained'
    elif action=='fix':
        k=str(rec.get('kind',''))
        if k=='virus-found' and indicator:
            res=quarantine_file(indicator,signature=str(rec.get('detail','') or 'detected'))
            if res.get('ok'):
                did='Moved the file into quarantine. It cannot run there. Malware / Quarantine can put it back or delete it.'; new_state='resolved'
            else:
                did='Could not quarantine it: '+str(res.get('error','unknown error'))+(' Use Malware / Quarantine with "Force" if you are sure.' if 'system directory' in str(res.get('error','')) else '')
        elif k in _INC_NET_KINDS and _incident_ip(rec):
            ip=_incident_ip(rec)
            if _is_blocked(ip): did=f'{ip} is already blocked.'; new_state='contained'
            else:
                ok,msg=block_ip(ip,f'blocked from incident {ident}','incident-action')
                _BLOCKS_MEMO['t']=0
                if ok:
                    did=f'Blocked {ip}: it can no longer reach this computer. The block lifts by itself after {int(CFG.get("block_ttl_days",30))} days, or unblock it on Firewall & Blocks.'; new_state='contained'
                elif msg=='allowlisted': did=f'LocSec did not block {ip}: it is on your own network (allow_ips), and LocSec never blocks those so you cannot lock yourself out.'
                else: did=f'LocSec did not block {ip}: {msg}'
        else:
            did='LocSec cannot fix this kind of incident by itself. The steps under "What you should do" are the fix.'
        summary=did
    else:
        new_state='resolved'; summary='Marked solved'
        if indicator and _is_blocked(indicator): summary+=f'; {indicator} stays blocked until its block runs out'
        did=summary+'.'
    with LOCK:
        _inc_load(); target=_inc_find(ident)
        if not target: return {'ok':False,'error':'incident not found (deleted during processing)'}
        target['state']=new_state; target['updated']=time.time(); target['note']=str(summary)[:1000]; _inc_store(target)
    evidence=_incident_evidence(target) if action=='explain' else ''
    _action_log(ident,action,str(summary)[:200],str(did or '')[:1000])
    return {'ok':True,'incident':target,'explain':incident_explain(target,did),'evidence':evidence,'actions':incident_actions(ident)}

def recent_incidents(limit=200):
    # The log can carry several lines for one incident, so read a wider window
    # than the row count and collapse it to the current record per id.
    n=max(1,min(int(limit),1000))
    try:
        recs=_inc_resolve(_tail_lines(INCIDENTS,0,max_bytes=max(2000000,n*4096)))
        # Newest activity last (the dashboard reverses it). Ordering by first
        # sighting, as this did, buried an old incident that was still counting
        # up at the bottom of the page while quiet newer ones sat above it.
        def _seen(r):
            try: return float(r.get('updated') or r.get('last_seen') or r.get('ts') or 0)
            except Exception: return 0.0
        recs.sort(key=_seen)
        return recs[-n:]
    except Exception: return []

def prune_incidents():
    # Retention and log compaction are the same operation now.
    with LOCK:
        _inc_load(); compact_incidents()

# Single-use browser login codes. The Qt window hands the dashboard the API
# token in the URL and the daemon swaps it for the session cookie with a
# redirect -- safe there, but an ordinary browser would record that long-lived
# token in its history. On systems without PyQt6 (for example one where it was removed by hand) the
# launcher opens the default browser instead, so it first exchanges the token
# (sent in a header, never in a URL) for one of these: 256 random bits, valid
# for 60 seconds, consumed on first use. What reaches the browser history is a
# dead code.
# Failed-credential monitor. Every client is 127.0.0.1, so failures are counted globally. More than
# _AUTH_FAIL_MAX wrong tokens, stale cookies or used login codes in _AUTH_FAIL_WINDOW seconds means a local
# program is guessing: further failures are answered 429 for the rest of the window, a warning is logged and
# an incident is opened (at most every 5 minutes). Valid credentials keep working throughout, so this cannot
# be used to lock the administrator out. The token is 256 random bits; guessing it is not feasible either way.
_AUTH_FAIL_MAX=30
_AUTH_FAIL_WINDOW=60
_AUTH_FAILS={'times':[],'until':0.0,'logged':0.0}
_AUTH_FAIL_LOCK=threading.Lock()
def _auth_failed():
    now=time.time()
    with _AUTH_FAIL_LOCK:
        t=[x for x in _AUTH_FAILS['times'] if now-x<_AUTH_FAIL_WINDOW]; t.append(now)
        _AUTH_FAILS['times']=t[-(_AUTH_FAIL_MAX+5):]
        if len(t)>_AUTH_FAIL_MAX:
            _AUTH_FAILS['until']=now+_AUTH_FAIL_WINDOW
            if now-_AUTH_FAILS['logged']>300:
                _AUTH_FAILS['logged']=now
                msg=(f'more than {_AUTH_FAIL_MAX} failed dashboard authentications in {_AUTH_FAIL_WINDOW} s from a program on this computer. '
                     f'Find it with: sudo ss -tnp | grep {CFG.get("port",8765)}')
                log('dashboard: '+msg,'WARN')
                try: incident('auth-probe','locsecd','127.0.0.1','medium','detected',msg)
                except Exception: pass
def _auth_locked():
    with _AUTH_FAIL_LOCK: return time.time()<_AUTH_FAILS['until']

_LOGIN_CODES={}
_LOGIN_CODES_LOCK=threading.Lock()
_LOGIN_CODE_TTL=60

def mint_login_code():
    code=secrets.token_urlsafe(32); now=time.time()
    with _LOGIN_CODES_LOCK:
        for k in [k for k,exp in _LOGIN_CODES.items() if exp<now]: _LOGIN_CODES.pop(k,None)
        if len(_LOGIN_CODES)>=16: return None
        _LOGIN_CODES[code]=now+_LOGIN_CODE_TTL
    return code

def consume_login_code(code):
    code=str(code or '')
    if not code or len(code)>100 or not code.isascii(): return False
    now=time.time()
    with _LOGIN_CODES_LOCK:
        match=None
        for k in list(_LOGIN_CODES):
            if hmac.compare_digest(k,code): match=k
        if match is None: return False
        exp=_LOGIN_CODES.pop(match)
    return exp>=now

# Browser/GUI sessions. The cookie holds a random session id, never the API
# token, so a stolen cookie is not the long-lived root credential: it expires
# (8 h idle, 3 days at most), is stored only as a hash on disk so it survives a
# service restart, and the 32 newest sessions are kept. Only the token file
# (root-readable) can mint a new one, through a single-use login code.
SESSIONS_FILE=STATE/'sessions.json'
_SESSION_IDLE=8*3600
_SESSION_MAX=3*86400
_SESSION_LIMIT=32
_SESSIONS={'loaded':False,'data':{}}
_SESSIONS_LOCK=threading.Lock()

def _sessions_data():
    if not _SESSIONS['loaded']:
        _SESSIONS['loaded']=True
        try:
            d=json.loads(SESSIONS_FILE.read_text())
            if isinstance(d,dict): _SESSIONS['data']=d
        except Exception: pass
    return _SESSIONS['data']

def _sessions_save():
    try: atomic_json(SESSIONS_FILE,_SESSIONS['data'])
    except Exception as e: log(f'could not save sessions: {e}','WARN')

def new_session():
    now=time.time(); sid=secrets.token_urlsafe(32)
    with _SESSIONS_LOCK:
        d=_sessions_data()
        for k in [k for k,v in d.items() if not isinstance(v,dict) or now-float(v.get('created',0))>_SESSION_MAX or now-float(v.get('last',0))>_SESSION_IDLE]: d.pop(k,None)
        while len(d)>=_SESSION_LIMIT: d.pop(min(d,key=lambda k:float(d[k].get('last',0))),None)
        d[hashlib.sha256(sid.encode()).hexdigest()]={'created':now,'last':now}
        _sessions_save()
    return sid

def session_ok(sid):
    if not sid or len(sid)>100: return False
    now=time.time(); h=hashlib.sha256(sid.encode()).hexdigest()
    with _SESSIONS_LOCK:
        d=_sessions_data(); rec=d.get(h)
        if not isinstance(rec,dict): return False
        if now-float(rec.get('created',0))>_SESSION_MAX or now-float(rec.get('last',0))>_SESSION_IDLE:
            d.pop(h,None); _sessions_save(); return False
        if now-float(rec.get('last',0))>60: rec['last']=now; _sessions_save()
        return True

def token_value():
    # Fast path: every authenticated request reads this, so stay out of LOCK
    # unless the token genuinely has to be created.
    try:
        tok=TOKEN.read_text().strip()
        if tok: return tok
    except OSError: pass
    # First start (or a truncated token file). Create it exactly once: without
    # this, two concurrent requests could each generate and write a different
    # token, and whichever wrote first would have handed out a value the file
    # no longer contains.
    with LOCK:
        try:
            tok=TOKEN.read_text().strip()
            if tok: return tok
        except OSError: pass
        try:
            if TOKEN.exists(): TOKEN.unlink()
        except OSError: pass
        try:
            fd=os.open(str(TOKEN),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            try: os.write(fd,hashlib.sha256(os.urandom(64)).hexdigest().encode('ascii'))
            finally: os.close(fd)
        except FileExistsError: pass
        except OSError as e:
            log(f'could not create the API token: {e}','ERROR'); return ''
        try: return TOKEN.read_text().strip()
        except OSError: return ''


def safe_ip(s):
    # ipaddress accepts any text after '%' as an IPv6 scope id (newlines
    # included), which would let a request write forged lines into the log.
    if '%' in str(s): return None
    try: a=ipaddress.ip_address(str(s).strip())
    except (ValueError, TypeError): return None
    # ::ffff:a.b.c.d is the IPv4 host a.b.c.d. Left as IPv6 it slips past the allowlist and the
    # loopback check, and an IPv6 block rule would never match the attacker's real IPv4 traffic.
    if a.version==6 and a.ipv4_mapped is not None: return a.ipv4_mapped
    return a


def safe_network(s):
    if '%' in str(s): return None
    try: return ipaddress.ip_network(str(s).strip(),strict=False)
    except (ValueError, TypeError): return None


def allowed_ip(ip):
    a=safe_ip(ip)
    if not a: return False
    for n in CFG.get('allow_ips',[]):
        try:
            if a in ipaddress.ip_network(n,strict=False): return True
        except ValueError: pass
    return False


def allowed_network(net):
    n=safe_network(net)
    if not n: return False
    for x in CFG.get('allow_ips',[]):
        allow=safe_network(x)
        if not allow or allow.version!=n.version: continue
        try:
            if n.subnet_of(allow): return True
        except (TypeError,ValueError): pass
    return False


BLOCK_TTL_SECONDS_DEFAULT=30*86400

# Addresses this machine depends on to work at all: its DNS servers and default
# gateways. Private ranges are already in allow_ips, but a public resolver
# (1.1.1.1, 8.8.8.8, the ISP's) is not, and blocking one -- because a feed
# lists it, or a forged probe claimed to come from it -- cuts off name
# resolution for the whole machine. Automatic blocks never touch these; a block
# asked for by hand still does exactly what it was asked.
_INFRA_CACHE={'ts':0.0,'ips':frozenset()}
_INFRA_TTL=300
_MANUAL_BLOCK_SOURCES=('manual','incident-action')

def infrastructure_ips():
    now=time.time()
    if now-_INFRA_CACHE['ts']<_INFRA_TTL: return _INFRA_CACHE['ips']
    found=set()
    for f in ('/etc/resolv.conf','/run/systemd/resolve/resolv.conf','/run/NetworkManager/resolv.conf'):
        try:
            for line in Path(f).read_text(errors='replace').splitlines():
                parts=line.split()
                if len(parts)>=2 and parts[0]=='nameserver': found.add(parts[1].split('%')[0])
        except OSError: pass
    if have('nmcli'):
        # Terse multi-line output: one "IP4.DNS[1]:1.1.1.1" per line.
        rc,out=run(['nmcli','-t','-f','IP4.DNS,IP6.DNS,IP4.GATEWAY,IP6.GATEWAY','device','show'],10)
        if rc==0:
            for line in out.splitlines():
                _,_,val=line.partition(':')
                found.add(val.strip().replace('\\:',':'))
    if have('ip'):
        for fam in ('-4','-6'):
            rc,out=run(['ip',fam,'route','show','default'],10)
            if rc==0:
                for m in re.finditer(r'\bvia\s+(\S+)',out): found.add(m.group(1))
    ips=frozenset(str(a) for a in (safe_ip(x) for x in found if x) if a is not None and not a.is_loopback and not a.is_unspecified)
    _INFRA_CACHE.update(ts=now,ips=ips)
    return ips

def _infra_conflict(target):
    """The infrastructure address a block target would cover, or ''."""
    infra=infrastructure_ips()
    if not infra: return ''
    if isinstance(target,(ipaddress.IPv4Address,ipaddress.IPv6Address)):
        return str(target) if str(target) in infra else ''
    for x in infra:
        a=safe_ip(x)
        if a is not None and a.version==target.version and a in target: return x
    return ''

def block_expiry_seconds():
    try: return max(86400, min(90*86400, int(CFG.get('block_ttl_days',30))*86400))
    except Exception: return BLOCK_TTL_SECONDS_DEFAULT

def _remove_firewall_rule(key):
    try: broker('fw.ufw.undeny',target=key)
    except Exception: pass
    try:
        if safe_network(key) and have('nft'): broker('fw.nft.remove',target=key)
    except Exception: pass

def prune_expired_blocks():
    now=time.time(); expired=[]
    with LOCK:
        blocks=load_blocks(); kept={}
        for key,meta in blocks.items():
            if not isinstance(meta,dict):
                # Not a record this version writes (a hand edit or a damaged file):
                # drop it and take its firewall rule down with it.
                log(f'block list: dropped an unreadable entry for {key}','WARN')
                expired.append(key); continue
            try: created=float(meta.get('ts') or now)
            except Exception: created=now
            try: expires=float(meta.get('expires') or (created+block_expiry_seconds()))
            except Exception: expires=created+block_expiry_seconds()
            meta['expires']=expires
            if expires<=now:
                expired.append(key)
            else:
                kept[key]=meta
        if kept!=blocks: atomic_json(BLOCKS,kept)
    for key in expired:
        with LOCK:
            # Re-blocked since the list above was read: keep its rule.
            if key in load_blocks(): continue
            _remove_firewall_rule(key)
        log(f'block expired: {key}','INFO')
    return expired

def load_blocks():
    if not BLOCKS.exists(): return {}
    try:
        x=json.loads(BLOCKS.read_text()); return x if isinstance(x,dict) else {}
    except Exception as e:
        log(f'block database read error: {e}','ERROR'); return {}



def ensure_nft():
    return broker('fw.nft.ensure')

def firewall_active():
    rc,out=broker('fw.ufw.status')
    return rc==0 and re.search(r'^Status:\s+active',out,re.I|re.M) is not None

def ufw_state():
    """'active', 'inactive', or 'unknown' when ufw could not answer.

    Only an explicit "Status: inactive" counts as off. A ufw that timed out or
    failed (its lock held during an upgrade, say) must not switch the fallback
    firewall on over the top of a working UFW and its allow rules."""
    if not have('ufw'): return 'inactive'
    rc,out=broker('fw.ufw.status')
    if rc!=0: return 'unknown'
    if re.search(r'^Status:\s+active',out,re.I|re.M): return 'active'
    if re.search(r'^Status:\s+inactive',out,re.I|re.M): return 'inactive'
    return 'unknown'

# Fallback firewall: a default-deny input chain in LocSec's own nftables table,
# present only while UFW is installed but not enabled. It sits next to UFW's
# tables rather than inside them, so turning UFW on never conflicts with it,
# and it is removed on the next check once UFW is active. It stays in place if
# locsecd stops (fail closed); removing the package deletes the table.
_FALLBACK_LOG_PREFIX='[LOCSEC BLOCK] '
_FALLBACK={'on':None,'inactive_reads':0,'script':''}

def _fallback_ssh_ports():
    """TCP ports of SSH sessions in use right now. Dropping new connections must not
    be able to cut off the administrator who is logged in remotely."""
    ports=[]
    if not have('ss'): return ports
    rc,out=broker('net.sockets',view='ssh_sessions',timeout=10)
    if rc!=0: return ports
    for line in out.splitlines():
        if '"sshd' not in line: continue
        parts=line.split()
        if len(parts)<4: continue
        try: p=int(parts[2].rsplit(':',1)[1])
        except Exception: continue
        if 1<=p<=65535 and p not in ports: ports.append(p)
    return ports[:8]

def _fallback_blocked_listeners(extra_tcp=()):
    """Network-facing services the fallback firewall is now cutting off."""
    out=[]
    if not have('ss'): return out
    rc,txt=broker('net.sockets',view='listening')
    if rc!=0: return out
    tcp=set(CFG.get('fallback_allow_tcp') or [])|set(extra_tcp); udp=set(CFG.get('fallback_allow_udp') or [])
    for line in txt.splitlines():
        parts=line.split()
        if len(parts)<5: continue
        host,_,port=parts[4].rpartition(':')
        a=safe_ip(host.strip('[]').split('%')[0]) if host.strip('[]') not in ('*','0.0.0.0','::') else None
        if (a is not None and a.is_loopback) or not port.isdigit(): continue
        p=int(port); proto=parts[0]
        if (proto.startswith('tcp') and p in tcp) or (proto.startswith('udp') and (p in udp or p in (68,5353))): continue
        name=(re.search(r'\(\("([^"]+)"',' '.join(parts[6:])) or [None,'unknown'])[1]
        item=f'{proto[:3]} {p} ({name})'
        if item not in out: out.append(item)
    return out[:12]

def _fallback_script(extra_tcp=()):
    t='inet locsec'; c='fallback'
    r=[f'add table {t}',
       f'add chain {t} {c} {{ type filter hook input priority -4 ; policy accept ; }}',
       f'flush chain {t} {c}',
       f'add rule {t} {c} iifname "lo" accept',
       f'add rule {t} {c} ct state established,related accept',
       f'add rule {t} {c} ct state invalid drop',
       f'add rule {t} {c} meta l4proto icmp accept',
       f'add rule {t} {c} meta l4proto ipv6-icmp accept',
       # DHCP and DHCPv6 replies, and the same mDNS allowance UFW's before.rules has.
       f'add rule {t} {c} udp sport 67 udp dport 68 accept',
       f'add rule {t} {c} udp sport 547 udp dport 546 accept',
       f'add rule {t} {c} ip daddr 224.0.0.251 udp dport 5353 accept',
       f'add rule {t} {c} ip6 daddr ff02::fb udp dport 5353 accept']
    for proto,key in (('tcp','fallback_allow_tcp'),('udp','fallback_allow_udp')):
        ports=sorted(set(CFG.get(key) or [])|(set(extra_tcp) if proto=='tcp' else set()))
        if ports: r.append(f'add rule {t} {c} {proto} dport {{ '+', '.join(str(p) for p in ports)+' } accept')
    r.append(f'add rule {t} {c} limit rate 10/second burst 100 packets log prefix "{_FALLBACK_LOG_PREFIX}"')
    r.append(f'add rule {t} {c} drop')
    return '\n'.join(r)+'\n'

def _fallback_present():
    return broker('fw.nft.fallback_present')

def _fallback_remove():
    if not have('nft') or not _fallback_present(): return True
    # One transaction: flush and delete together, so no half-removed chain.
    rc,out=broker('fw.nft.fallback_remove')
    if rc!=0: log(f'could not remove the fallback firewall: {out.strip()[-300:]}','ERROR')
    return rc==0

def _fallback_allowed_text(extra_tcp=()):
    tcp=sorted(set(CFG.get('fallback_allow_tcp') or [])|set(extra_tcp)); udp=CFG.get('fallback_allow_udp') or []
    parts=[f'tcp {",".join(map(str,tcp))}' if tcp else '',f'udp {",".join(map(str,udp))}' if udp else '']
    return '; '.join(p for p in parts if p) or 'no ports'

def fallback_firewall_check():
    """Run once a minute: fallback chain on while UFW is off, gone while it is on."""
    st=_FALLBACK
    if not CFG.get('fallback_firewall',True):
        st['inactive_reads']=0
        if st['on'] is not False and _fallback_remove():
            if st['on']: log('fallback firewall removed: it was turned off in the response policy','WARN')
            st['on']=False
        return
    u=ufw_state()
    if u=='unknown': return
    if u=='active':
        st['inactive_reads']=0
        if st['on'] is not False and _fallback_remove():
            if st['on']: log('UFW is active again; the LocSec fallback firewall was removed','INFO')
            st['on']=False
        return
    # Two readings a minute apart, so `ufw reload` or a disable/enable pair
    # does not flip the fallback on for a moment.
    st['inactive_reads']+=1
    if st['inactive_reads']<2 or not have('nft'): return
    ssh=_fallback_ssh_ports()
    script=_fallback_script(ssh)
    if st['on'] and st['script']==script and _fallback_present(): return
    rc,out=broker('fw.nft.fallback_apply',ssh_ports=ssh)
    if rc!=0:
        log(f'UFW is not enabled and the fallback firewall could not be installed: {out.strip()[-300:]}','ERROR')
        return
    if not st['on']:
        cut=_fallback_blocked_listeners(ssh)
        cut_txt=('Services on this machine that can no longer be reached from the network: '+'; '.join(cut)+'. ') if cut else 'No service is listening on the network. '
        kept=f' SSH port {", ".join(map(str,ssh))} is kept open because a session is using it.' if ssh else ''
        log(f'UFW is not enabled: LocSec fallback firewall on, unsolicited incoming traffic is dropped (still allowed: {_fallback_allowed_text(ssh)}). {cut_txt}'.strip(),'WARN')
        incident('firewall-fallback','locsecd','', 'high','enabled',
                 'UFW is not enabled, so LocSec installed its own default-deny input firewall. '
                 f'Allowed incoming ports: {_fallback_allowed_text(ssh)}.{kept} {cut_txt}'
                 'To keep a service reachable list its port in fallback_allow_tcp/udp, or enable UFW (sudo ufw enable) to replace this firewall.')
    elif st['script']!=script:
        log(f'fallback firewall updated (still allowed: {_fallback_allowed_text(ssh)})','INFO')
    else:
        log('fallback firewall was missing (ruleset flushed?) and has been put back','WARN')
    st['on']=True; st['script']=script


def _block_meta(reason,source,now,expiry,extra=None):
    meta={'reason':str(reason)[:256],'source':str(source)[:64],'ts':now,'expires':expiry}
    # Only the feed-origin fields, each bounded: what explain_block() reads.
    for k in ('feed','ref','feed_url'):
        if isinstance(extra,dict) and extra.get(k): meta[k]=str(extra[k])[:300]
    return meta

def _block_target(ip):
    """Parse a block target; a /32 or /128 network is the single address, so the
    same host always has one key (unblocking 1.2.3.4 must find 1.2.3.4/32)."""
    t=safe_ip(ip) or safe_network(ip)
    if isinstance(t,(ipaddress.IPv4Network,ipaddress.IPv6Network)) and t.prefixlen==t.max_prefixlen:
        t=t.network_address
    return t

_MAX_AUTO_BLOCKS=20000
_BLOCK_CAP_WARNED=[0.0]

def block_ip(ip,reason='threat',source='locsecd',persist=True,record_incident=True,extra=None,ttl=None):
    target=_block_target(ip)
    if not target: return False,'invalid address/network'
    # Whatever asks, never a range as wide as 0.0.0.0/0: that one rule cuts the
    # machine off from every network, remote access included.
    if isinstance(target,(ipaddress.IPv4Network,ipaddress.IPv6Network)) and target.prefixlen<(8 if target.version==4 else 16):
        return False,f'{target} is too wide to block (at most /8 for IPv4, /16 for IPv6)'
    is_single = isinstance(target, (ipaddress.IPv4Address, ipaddress.IPv6Address))
    if (is_single and allowed_ip(str(target))) or ((not is_single) and allowed_network(str(target))):
        return False,'allowlisted'
    # The switch is an automatic-response policy; a block asked for by hand is still made.
    if target.version==6 and str(source) not in _MANUAL_BLOCK_SOURCES and not CFG.get('ipv6_auto_block',True):
        return False,'IPv6 automatic blocking disabled'
    if str(source) not in _MANUAL_BLOCK_SOURCES:
        hit=_infra_conflict(target)
        if hit:
            log(f'automatic block of {target} by {source} refused: it covers {hit}, a DNS server or gateway this machine uses','WARN')
            return False,f'{hit} is a DNS server or gateway this machine uses; it is never blocked automatically'
    key=str(target)
    with LOCK:
        blocks=load_blocks(); meta=blocks.get(key)
        # Automatic blocks are capped: an internet-facing sshd sees thousands of distinct
        # attackers a month, and every block is a firewall rule and a rewrite of this file.
        # Manual blocks are never refused. The cap lifts as old blocks expire.
        if (not meta and str(source) not in _MANUAL_BLOCK_SOURCES
                and sum(1 for v in blocks.values() if not (isinstance(v,dict) and v.get('source') in _MANUAL_BLOCK_SOURCES))>=_MAX_AUTO_BLOCKS):
            if time.time()-_BLOCK_CAP_WARNED[0]>3600:
                _BLOCK_CAP_WARNED[0]=time.time()
                log(f'block list full: {_MAX_AUTO_BLOCKS} automatic blocks are active; {key} was not blocked (old blocks expire after block_ttl_days)','WARN')
            return False,f'the block list already holds {_MAX_AUTO_BLOCKS} automatic blocks'
        if meta:
            exp=float(meta.get('expires') or 0) if isinstance(meta,dict) else 0
            if exp>time.time():
                if record_incident:
                    incident('block',source,key,'high','blocked',reason)
                return False,'already blocked; no duplicate firewall rule or ban was created'
            blocks.pop(key,None); atomic_json(BLOCKS,blocks)
    now=time.time(); expiry=now+(int(ttl) if ttl else block_expiry_seconds())
    # Do not write a persistent block until an enforcement backend confirms it.
    # Otherwise a failed UFW/nft operation would survive a restart and look like
    # a protected address even though the firewall never actually blocked it.
    if firewall_active():
        rc,out=broker('fw.ufw.deny',target=key)
        if rc==0 or re.search(r'(Skipping adding existing rule|already exists)',out,re.I):
            
            if persist:
                with LOCK:
                    blocks=load_blocks(); blocks[key]=_block_meta(reason,source,now,expiry,extra); atomic_json(BLOCKS,blocks)
            if record_incident:
                incident('block',source,key,'high','blocked',reason)
            log(f'blocked address by {source}; expires={int(expiry)}','WARN') if record_incident else None
            return True,out.strip()
    if ensure_nft():
        rc2,out2=broker('fw.nft.add',target=key)
        if rc2==0 or 'exists' in out2.lower():
            
            if persist:
                with LOCK:
                    blocks=load_blocks(); blocks[key]=_block_meta(reason,source,now,expiry,extra); atomic_json(BLOCKS,blocks)
            if record_incident:
                incident('block',source,key,'high','blocked',reason)
                log(f'blocked address by {source}; expires={int(expiry)}','WARN')
            return True,out2.strip()
    if record_incident:
        incident('block',source,key,'high','failed',reason)
        log(f'failed to enforce block for {source}','ERROR')
    return False,'no active enforcement backend'

def restore_blocks():
    prune_expired_blocks()
    blocks=load_blocks()
    if not blocks: return
    nft_ready=False; restored=0
    ufw_on=firewall_active()     # once: it is a ufw call, and this loop can be 500 blocks long
    for target in list(blocks):
        if allowed_network(target) or allowed_ip(target): continue
        meta=blocks.get(target) if isinstance(blocks.get(target),dict) else {}
        tgt=safe_ip(target) or safe_network(target)
        if tgt is not None and str(meta.get('source','')) not in _MANUAL_BLOCK_SOURCES and _infra_conflict(tgt):
            # An automatic block from before this check existed, on an address
            # this machine needs (a forged probe "from" its DNS server). Lift it.
            _remove_firewall_rule(target)
            with LOCK:
                cur=load_blocks(); cur.pop(target,None); atomic_json(BLOCKS,cur)
            log(f'lifted automatic block on {target}: it is a DNS server or gateway this machine uses','WARN')
            continue
        if ufw_on:
            rc,out=broker('fw.ufw.deny',target=target)
            if rc==0 or re.search(r'(Skipping adding existing rule|already exists)',out,re.I): restored+=1; continue
        n=safe_network(target)
        if n:
            if not nft_ready: nft_ready=ensure_nft()
            if nft_ready:
                rc,_=broker('fw.nft.add',target=str(n))
                if rc==0 or 'exists' in _.lower(): restored+=1
    log(f'restored {restored}/{len(blocks)} active persisted blocks')

def unblock_ip(ip):
    target=_block_target(ip)
    if not target: return False,'invalid address/network'
    key=str(target)
    rc,out=broker('fw.ufw.undeny',target=key); msgs=[out.strip()] if out.strip() else []
    # Either backend removing the rule (or never having had it) is a successful
    # unblock. Reporting failure just because ufw is not installed, while nft
    # dropped the rule and the persisted entry is gone, made the dashboard say
    # the address was still blocked when it wasn't.
    ufw_ok = rc==0 or 'not found' in out.lower()
    nft_ok = False
    if have('nft'):
        rc2,out2=broker('fw.nft.remove',target=key)
        nft_ok = rc2==0 or 'no such' in out2.lower() or 'does not exist' in out2.lower()
        if out2.strip(): msgs.append(out2.strip())
    with LOCK:
        blocks=load_blocks(); blocks.pop(key,None); atomic_json(BLOCKS,blocks)
    detail='; '.join(msgs)
    incident('unblock','manual',key,'low','unblocked',detail)
    log(f'unblocked {key}: {detail}')
    return (ufw_ok or nft_ok),detail

# Which log files this package is entitled to clear from the dashboard, and
# why the others are not.
#
# Only locsecd.log is LocSec's own. auth.log and syslog are the primary
# forensic record of a compromise -- offering a security dashboard a button
# that destroys them is an anti-feature, and anyone who has taken the box
# would use it first. The scan logs belong to rkhunter, ClamAV and AIDE, and
# Every one of them is already rotated by its own package,
# so nothing here grows without bound; the sizes reported alongside make that
# visible instead of asking anyone to take it on trust.
_LOG_CLEARABLE={'locsecd'}
_LOG_ROTATION={
    'locsecd':   'daily, 14 kept, compressed (/etc/logrotate.d/locsecd)',
    'auth':      "rsyslog's own rotation (/etc/logrotate.d/rsyslog)",
    'syslog':    "rsyslog's own rotation (/etc/logrotate.d/rsyslog)",
    'ufw':       "rsyslog's own rotation (/etc/logrotate.d/ufw or rsyslog)",
    'rkhunter':  'the rkhunter package',
    'clamav':    'the clamav-freshclam package',
    'aide':      'the aide package',
    'suricata':  'the suricata package (/etc/logrotate.d/suricata)',
    'suricata-engine':'the suricata package (/etc/logrotate.d/suricata)',
}
_LOG_NOT_CLEARABLE_REASON={
    'auth':      'the primary record of who logged in and from where -- the first thing to read after a break-in',
    'syslog':    'the primary system record -- the first thing to read after a break-in',
    'ufw':       'firewall denial history, and rsyslog owns the file',
    'rkhunter':  'owned by the rkhunter package',
    'clamav':    'owned by the clamav-freshclam package',
    'aide':      'owned by the aide package',
    'suricata':  'owned by the suricata package, and the record of what the intrusion detection system matched',
    'suricata-engine':'owned by the suricata package',
}

def _log_rotation(key):
    return _LOG_ROTATION.get(key,'')

def _log_noclear_reason(key):
    return _LOG_NOT_CLEARABLE_REASON.get(key,'it is not a file this package owns')

def _source_paths(key,src):
    paths=list(src['paths'])
    if key=='suricata': paths=[Path(_ids_eve_path()),Path('/var/log/suricata/fast.log')]
    if key=='aide':
        try:
            full=sorted((f for f in REPORTS.glob('aide-full-*.txt') if f.is_file() and not f.is_symlink()),
                        key=lambda f:f.stat().st_mtime,reverse=True)
            if full: paths.insert(0,full[0])
        except OSError: pass
    return paths

def _log_size(src):
    p=next((p for p in src['paths'] if p.exists()),None)
    if p is None: return None,0
    try: return p,p.stat().st_size
    except OSError: return p,0

def clear_log(key):
    key=str(key or '')
    src=LOG_SOURCES.get(key)
    if not src: return {'ok':False,'error':'unknown log source'}
    if key not in _LOG_CLEARABLE:
        why=_log_noclear_reason(key)
        return {'ok':False,'error':f'{LOG_SOURCES[key]["label"]} cannot be cleared from here: {why}. '
                                   f'It is rotated by {_log_rotation(key) or "its own package"}.'}
    p,_=_log_size(src)
    if p is None: return {'ok':False,'error':'that log file does not exist yet'}
    # Confine the target the way report and quarantine paths are confined
    # elsewhere: the only thing this may ever truncate is a file directly
    # inside LocSec's own log directory.
    try:
        resolved=p.resolve()
        resolved.relative_to(LOG.parent.resolve())
    except (OSError,ValueError):
        return {'ok':False,'error':'refusing to clear a path outside LocSec\'s own log directory'}
    try:
        # O_NOFOLLOW, and truncate through the descriptor rather than the
        # path. os.truncate(path) follows symlinks and stats separately from
        # the write, so a symlink left at this path -- or swapped in between
        # the two calls -- would have this daemon truncate whatever it points
        # at, as root. The directory is 0750 root:root so that is not an
        # escalation, but a security tool should not contain a
        # "destroy an arbitrary file" primitive that depends on a directory
        # mode set best-effort at startup.
        #
        # Truncating rather than unlinking is deliberate: locsecd and anything
        # else holding the file open keep their descriptors and carry on
        # writing to the same inode. Deleting it would leave writers appending
        # to an unlinked inode -- the space would not come back until a
        # restart, and the visible log would stop updating.
        # O_NONBLOCK as well: opening a FIFO for writing blocks until a
        # reader appears, which would pin this request thread indefinitely
        # (and, repeated, exhaust the bounded pool). With it, a FIFO fails
        # with ENXIO instead. It has no effect on a regular file.
        fd=os.open(str(p), os.O_WRONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    except OSError as e:
        if getattr(e,'errno',None) in (errno.ELOOP,errno.EMLINK):
            return {'ok':False,'error':f'{p} is a symbolic link; refusing to clear it'}
        if getattr(e,'errno',None)==errno.ENXIO:
            return {'ok':False,'error':f'{p} is a named pipe, not a log file; refusing to clear it'}
        return {'ok':False,'error':f'could not open {p}: {e}'}
    try:
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            return {'ok':False,'error':f'{p} is not a regular file; refusing to clear it'}
        before=st.st_size          # from the same descriptor, so it matches what is truncated
        os.ftruncate(fd,0)
    except OSError as e:
        return {'ok':False,'error':f'could not clear {p}: {e}'}
    finally:
        try: os.close(fd)
        except OSError: pass
    # A security tool destroying its own record says so in the record that
    # replaces it, and in the incident timeline, so the gap is explained.
    log(f'{key} log cleared from the dashboard ({before} bytes discarded)','WARN')
    incident('log-cleared','manual',str(p),'low','success',
             f'{LOG_SOURCES[key]["label"]} cleared from the dashboard; {before} bytes discarded')
    return {'ok':True,'source':key,'path':str(p),'freed':before,
            'output':f'{LOG_SOURCES[key]["label"]} cleared. {before} bytes freed. '
                     f'Rotation is unchanged: {_log_rotation(key)}.'}

def _source_journal(src,n=500):
    """Tail of a log source's journal fallback, or '' if it has none or no entries."""
    if 'jargs' not in src or not have('journalctl'): return ''
    flt=src.get('jfilter')
    # With a substring filter, read further back so n matching lines can be found.
    # At least 2000 lines: the source list probes with n=1, and 20 lines of
    # kernel log rarely include a [UFW line, so UFW read as "(no entries yet)".
    want=max(n*20,2000) if flt else n
    rc,out=run(['journalctl','--no-pager','-q','-o','short-iso','-n',str(min(want,50000))]+list(src['jargs']),20,tail=4000000 if flt else 400000)
    if rc!=0 or not out.strip(): return ''
    lines=out.splitlines()
    # The firewall source has two prefixes: UFW's, and the fallback firewall's
    # while UFW is off, which was filtered out and read as "no entries".
    if flt: lines=[l for l in lines if any(f in l for f in ((flt,) if isinstance(flt,str) else flt))]
    # The exact netfilter layout, so a kernel message that merely quotes the prefix
    # (a crashing program's name) is not shown as a connection attempt.
    if src.get('jregex'): lines=[l for l in lines if re.search(src['jregex'],l)]
    return '\n'.join(lines[-n:])

# ---------------------------------------------------------------------------
# Plain-language log view. Every Logs-page source is turned into rows a
# non-specialist can read: when, a short "what happened", and one or two
# sentences of explanation. The raw lines are still returned alongside, so
# nothing is hidden. Firewall lines (UFW, or the fallback firewall) also get
# their parts pulled out: source address, destination port, and why it was
# blocked. Nothing here changes any state; it only reads.
# ---------------------------------------------------------------------------
_MON={m:i for i,m in enumerate(('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'),1)}
_ISO_TS=re.compile(r'^(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)(?:[.,](\d+))?(Z|[+-]\d\d:?\d\d)?')
_BSD_TS=re.compile(r'^([A-Z][a-z]{2})\s+(\d{1,2})\s+(\d\d):(\d\d):(\d\d)')
_SYSLOG_REST=re.compile(r'^\s*(\S+)\s+([^\s:\[]+)(?:\[(\d+)\])?:\s?(.*)$')

def _parse_ts(s):
    """(epoch seconds or None, characters consumed) for an ISO or syslog timestamp."""
    m=_ISO_TS.match(s)
    if m:
        try:
            y,mo,d,h,mi,se=(int(x) for x in m.groups()[:6])
            dt=datetime(y,mo,d,h,mi,se,int(((m.group(7) or '0')+'000000')[:6]))
            tz=m.group(8)
            if not tz: return time.mktime(dt.timetuple())+dt.microsecond/1e6, m.end()
            off=0
            if tz!='Z':
                t=tz[1:].replace(':','')
                off=(-1 if tz[0]=='-' else 1)*(int(t[:2])*3600+int(t[2:4])*60)
            return dt.replace(tzinfo=timezone.utc).timestamp()-off, m.end()
        except (ValueError,OverflowError): return None,0
    m=_BSD_TS.match(s)
    if m and m.group(1) in _MON:
        try:
            now=datetime.now()
            def _at(year):
                return time.mktime(datetime(year,_MON[m.group(1)],int(m.group(2)),int(m.group(3)),int(m.group(4)),int(m.group(5))).timetuple())
            ts=_at(now.year)
            if ts>time.time()+86400: ts=_at(now.year-1)   # a December line read in January
            return ts, m.end()
        except (ValueError,OverflowError): return None,0
    return None,0

def _split_syslog(line):
    """(ts, program, message) for a syslog-style or journalctl short-iso line."""
    ts,end=_parse_ts(line)
    if end:
        m=_SYSLOG_REST.match(line[end:])
        if m: return ts,m.group(2),m.group(4)
        return ts,'',line[end:].strip()
    return None,'',line.strip()

def _row(ts,lvl,title,text,raw,**extra):
    r={'ts':ts,'lvl':lvl,'title':str(title)[:200],'text':str(text)[:1200],'raw':str(raw)[:2000]}
    r.update(extra)
    return r

# What each port is normally used for.
_PORT_NAMES={
 20:'FTP file transfer',21:'FTP file transfer',22:'SSH remote login',23:'Telnet (old, unsafe remote login)',
 25:'email sending',53:'DNS (looking up website names)',67:'getting a network address (DHCP)',
 68:'getting a network address (DHCP)',69:'TFTP file transfer',80:'web pages',110:'email (POP3)',
 111:'RPC',123:'clock setting (NTP)',135:'Windows remote control (RPC)',137:'Windows computer names',
 138:'Windows computer names',139:'Windows file sharing',143:'email (IMAP)',161:'device monitoring (SNMP)',
 389:'LDAP directory',443:'secure web pages',445:'Windows file sharing',465:'email sending',514:'system logs',
 546:'getting a network address (DHCPv6)',547:'getting a network address (DHCPv6)',587:'email sending',
 631:'printing',853:'secure DNS',993:'email (IMAP)',995:'email (POP3)',1080:'proxy',1194:'OpenVPN',
 1433:'Microsoft SQL database',1723:'PPTP VPN',1900:'finding devices on the network (UPnP)',2049:'NFS file sharing',
 2375:'Docker remote control',3306:'MySQL database',3389:'Windows Remote Desktop',
 3702:'finding devices on the network (WS-Discovery)',5060:'internet phone calls (SIP)',
 5353:'finding devices on the network (mDNS)',5355:'finding computer names (LLMNR)',5432:'PostgreSQL database',
 5900:'remote screen sharing (VNC)',6379:'Redis database',6667:'IRC chat',6697:'IRC chat (secure)',
 7547:'router remote management',8080:'web (alternate port)',8443:'secure web (alternate port)',
 8888:'web (alternate port)',9200:'Elasticsearch database',11211:'Memcached',17500:'Dropbox on the home network',
 27017:'MongoDB database',51820:'WireGuard VPN'}

def _door(port):
    try: p=int(port)
    except (TypeError,ValueError): return ''
    name=_PORT_NAMES.get(p)
    return f'port {p}'+(f' ({name})' if name else '')

class _BlockLookup:
    """Which persisted block (if any) covers an address. Built once per request."""
    def __init__(self):
        self.single={}; self.nets=[]; self.cache={}
        for key,meta in load_blocks().items():
            n=safe_network(key)
            if n is None: continue
            meta=meta if isinstance(meta,dict) else {}
            if n.num_addresses==1: self.single[str(n.network_address)]=(key,meta)
            else: self.nets.append((n,key,meta))
    def match(self,ip):
        if ip in self.cache: return self.cache[ip]
        a=safe_ip(ip); hit=None
        if a is not None:
            hit=self.single.get(str(a))
            if hit is None:
                for n,key,meta in self.nets:
                    if n.version==a.version and a in n: hit=(key,meta); break
        self.cache[ip]=hit
        return hit

def _where(ip):
    a=safe_ip(ip)
    if a is None: return 'unknown'
    if a.is_loopback: return 'this computer'
    # allow_ips is the local-network list (private ranges by default). Not
    # ipaddress.is_private: that also covers documentation and benchmark
    # ranges, which are not anyone's home network.
    if allowed_ip(ip) or a.is_link_local: return 'your own network'
    return 'the internet'

_FW_TAG=re.compile(r'\[(UFW|LOCSEC) ([A-Z ]+?)\]')

def _fw_fields(msg):
    """Pull the parts out of a kernel firewall log line, or None if it is not one."""
    m=_FW_TAG.search(msg)
    if not m: return None
    def f(k):
        x=re.search(r'(?<![A-Z])'+k+r'=(\S*)',msg)
        return x.group(1) if x else ''
    flags=set(re.findall(r'\b(SYN|ACK|RST|FIN|PSH|URG)\b',msg.split('PROTO=',1)[-1]))
    return {'who':m.group(1),'action':m.group(2).strip(),'in':f('IN'),'out':f('OUT'),'src':f('SRC'),'dst':f('DST'),
            'proto':f('PROTO').upper(),'spt':f('SPT'),'dpt':f('DPT'),'flags':flags}

def _fw_explain(msg,ts,raw,blocks):
    """One firewall line in plain language: source, destination port, what the firewall did and why."""
    x=_fw_fields(msg)
    if x is None: return None
    act=x['action']; src=x['src']; dst=x['dst']; proto=x['proto']
    outgoing=bool(x['out']) and not x['in']
    wall='LocSec\'s fallback firewall' if x['who']=='LOCSEC' else 'the firewall (UFW)'
    Wall=wall[0].upper()+wall[1:]
    port=x['dpt']; door=_door(port) if port else ''
    ping=proto in ('ICMP','ICMPV6','1','58')
    where=_where(dst if outgoing else src)
    hit=blocks.match(src) if (src and not outgoing) else None
    d=safe_ip(dst)
    broadcast=d is not None and (d.is_multicast or (d.version==4 and str(d).endswith('.255')))
    lvl='info'
    if act=='AUDIT' or act.startswith('AUDIT'):
        verdict='Logged'; title='Audit entry'
        why=f'{Wall} logged this packet for auditing only. Nothing was blocked.'
    elif 'ALLOW' in act:
        verdict='Allowed in' if not outgoing else 'Allowed out'
        title=f'Allowed: {src} {"to" if not outgoing else "from this computer to"} {door or "this computer"}'
        why=f'An allow rule (added by you or by an installed package) matches this traffic, so {wall} passed it.'
    elif 'LIMIT' in act:
        verdict='Blocked'; lvl='warn'
        title=f'Rate limit hit by {src} on {door or "a port"}'
        why=(f'{src} opened connections to {door or "the same port"} faster than the rate-limit rule allows. '
             f'{Wall} throttles repeated attempts, so this one was dropped.')
    elif outgoing:
        verdict='Blocked'; lvl='warn'
        title=f'Blocked outgoing traffic to {dst}'
        why=(f'A program on this computer tried to connect to {dst} ({where}) on {door or "a port"}. '
             f'An outbound deny rule matches it, so {wall} blocked it.')
    else:
        verdict='Blocked'
        title=f'Blocked a connection attempt from {src or "an unknown source"}'+(f' to {door}' if door else '')
        if hit:
            lvl='warn'
            why=(f'{src} is on LocSec\'s list of blocked computers ({_block_reason_short(hit[1])}), '
                 f'so all of its traffic is refused. {Wall} dropped it.')
        elif ping:
            title=f'Blocked an ICMP message from {src or "an unknown source"}'
            why=(f'{src} ({_where(src)}) sent a ping or another ICMP control message. '
                 'The firewall dropped it. This is routine and not a threat on its own.')
        elif broadcast:
            why=('A device on the local network sent a broadcast or multicast packet to every host. '
                 'No service on this computer listens for it, so it was dropped. This is normal network background traffic.')
        elif proto=='TCP' and x['flags'] and 'SYN' not in x['flags']:
            why=('This packet belonged to a connection that had already closed (not a new connection request). '
                 'The firewall discarded it. This is routine and harmless.')
        elif where=='your own network':
            why=(f'Another device on the local network (a phone, TV, printer or the router) tried to connect to {door or "a port"}. '
                 'No rule allows that port, so the firewall refused it. Usually harmless.')
        elif where=='this computer':
            why='This traffic originated on this computer. The firewall refused it because no rule allows it.'
        else:
            why=(f'A host on the internet ({src}) attempted an unsolicited connection to {door or "a port"} on this computer. '
                 'Incoming connections are denied by default, so the firewall blocked it. Internet-wide scanners probe '
                 'every reachable address this way continuously, looking for exposed services.')
    fields={'verdict':verdict,'from':src,'from_where':_where(src) if src else '','to':dst,
            'door':(f'{port}/{proto.lower()}' if port else ('ping' if ping else proto.lower())),'door_name':_PORT_NAMES.get(int(port),'') if port.isdigit() else ('ICMP echo / control message' if ping else ''),
            'direction':'outbound' if outgoing else 'inbound','listed':bool(hit)}
    return _row(ts,lvl,title,why,raw,fw=fields)

def _block_reason_short(meta):
    src=str(meta.get('source',''))
    if src=='feed':
        f=_FEED_INFO.get(str(meta.get('feed','')))
        return f'listed by {f["name"]}' if f else 'listed on a threat-intelligence feed'
    if src=='auth-monitor': return 'repeated failed logins'
    if src=='scan-monitor': return 'port scan'
    if src=='suricata': return 'Suricata intrusion signature'
    if src in ('manual','incident-action'): return 'blocked manually'
    return str(meta.get('reason') or 'blocked earlier')[:80]

_AUTH_SERVICE={'sudo':'sudo (administrator privileges)','su':'su (switching user)','sshd':'SSH (remote login)','cron':'a scheduled job',
               'CRON':'a scheduled job','systemd-user':'background services','login':'the text login screen',
               'gdm-password':'the login screen','gdm-autologin':'automatic login','lightdm':'the login screen',
               'sddm':'the login screen','pkexec':'pkexec (administrator privileges)','polkit-1':'a polkit administrator prompt',
               'cinnamon-screensaver':'the lock screen','gnome-screensaver':'the lock screen','xscreensaver':'the lock screen'}

def _auth_explain(prog,msg,ts,raw):
    p=prog.split('/')[-1].rstrip(']')
    if 'unlocked login keyring' in msg:
        return _row(ts,'good','Keyring unlocked','Your saved-passwords keyring was unlocked when you logged in.',raw)
    m=re.match(r'Failed (password|publickey|keyboard-interactive\S*) for (invalid user )?',msg)
    if m:
        user,ip=_auth_details(msg); ip=ip or 'an unknown address'
        return _row(ts,'bad','Wrong password',f'{ip} ({_where(ip)}) failed an SSH login as "{user}".'
                    +(' That account does not exist on this system, which is typical of automated password guessing.' if m.group(2) else ''),raw)
    if msg.startswith('Invalid user '):
        user,ip=_auth_details(msg); ip=ip or 'an unknown address'
        return _row(ts,'warn','Unknown account tried',f'{ip} ({_where(ip)}) tried to log in as "{user}", an account that does not exist on this computer. This is typical of automated password guessing.',raw)
    m=re.match(r'Accepted (password|publickey|keyboard-interactive\S*) for ',msg)
    if m:
        how='a key' if m.group(1)=='publickey' else 'a password'
        user,ip=_auth_details(msg)
        return _row(ts,'good','Logged in',f'"{user}" logged in over SSH from {ip} ({_where(ip)}) using {how}.',raw)
    m=re.search(r'^\s*(\S+) : .*?(\d+) incorrect password attempts?',msg)
    if m:
        return _row(ts,'bad','Wrong administrator password',f'"{m.group(1)}" entered an incorrect password for sudo {m.group(2)} time(s).',raw)
    if 'NOT in sudoers' in msg or 'user NOT authorized' in msg:
        u=(re.match(r'^\s*(\S+)',msg) or [None,'someone'])[1]
        return _row(ts,'bad','Unauthorized sudo attempt',f'"{u}" tried to use sudo but is not in the sudoers list.',raw)
    m=re.search(r'^\s*(\S+) : .*?USER=(\S+) ; COMMAND=(.*)$',msg)
    if m and p=='sudo':
        return _row(ts,'info','Admin command',f'"{m.group(1)}" used sudo to run this as {m.group(2)}: {m.group(3).strip()[:300]}',raw)
    m=re.search(r'Executing command \[USER=(\S+)\].*?\[COMMAND=(.*?)\]',msg)
    if m:
        u=(re.match(r'^\s*(\S+):',msg) or [None,'Someone'])[1]
        return _row(ts,'info','Admin command',f'{u} used pkexec to run this as {m.group(1)}: {m.group(2)[:300]}',raw)
    m=re.search(r'pam_\w+\(([^:)]+):(\w+)\): (.*)$',msg)
    if m:
        svc=_AUTH_SERVICE.get(m.group(1),m.group(1)); rest=m.group(3)
        u=re.search(r'for user (\S+?)(?:\(uid=\d+\))?(?: by (\S+?)(?:\(uid=\d+\))?)?$',rest)
        who=u.group(1) if u else ''
        if 'session opened' in rest:
            by=u.group(2) if u and u.group(2) else ''
            return _row(ts,'info','Session opened',f'A session for "{who}" was opened through {svc}'+(f' (asked for by "{by}")' if by and by!=who else '')+'.',raw)
        if 'session closed' in rest:
            return _row(ts,'info','Session closed',f'The session for "{who}" through {svc} was closed.',raw)
        if 'authentication failure' in rest:
            uu=re.search(r'\buser=(\S+)',rest); rh=re.search(r'\brhost=(\S+)',rest)
            local=not (rh and rh.group(1)) and m.group(1)!='sshd'
            return _row(ts,'bad','Wrong password','An incorrect password was entered'+(f' for "{uu.group(1)}"' if uu else '')+f' at {svc}'+(' on this computer (local console).' if local else '.'),raw,
                        fix=_LOCAL_PW_FIX if local else _LOG_FIXES['Wrong password'])
        if 'unlocked login keyring' in rest:
            return _row(ts,'good','Keyring unlocked','Your saved-passwords keyring was unlocked when you logged in.',raw)
        return _row(ts,'info',f'Login system ({svc})',rest,raw)
    if re.search(r'password check failed for user',msg):
        return _row(ts,'info','Password rejected','The password check rejected an incorrect password. The adjacent "Wrong password" entry shows where it was entered.',raw)
    if 'Error opening rules directory' in msg and 'No such file or directory' in msg:
        return _row(ts,'info','Optional directory missing','polkit looked for an optional rules directory that does not exist on this system. Normal.',raw)
    if 'Rejected send message' in msg:
        progs=[x.rsplit('/',1)[-1] for x in re.findall(r'comm="([^"]+)"',msg)]
        return _row(ts,'info','D-Bus message rejected',"The system message bus (D-Bus) rejected a message"+(f' between {progs[0]} and {progs[1]}' if len(progs)>=2 else '')+'. This is D-Bus enforcing its access policy; with Bluetooth audio (bluetoothd and wireplumber) it is expected.',raw)
    if re.search(r'gkr-pam: (?:unable to locate daemon control file|stashed password)',msg):
        return _row(ts,'info','Keyring initializing','The GNOME keyring is initializing for the login session. Normal.',raw)
    m=re.search(r'New session (\S+) of user (\S+?)\.?$',msg)
    if m: return _row(ts,'info','Logged in',f'"{m.group(2)}" logged in (session {m.group(1)}).',raw)
    m=re.search(r'Removed session (\S+?)\.?$',msg)
    if m: return _row(ts,'info','Logged out',f'Session {m.group(1)} ended.',raw)
    m=re.search(r'successfully authenticated as unix-user:(\S+) to gain (\S+) authorization for action (\S+)',msg)
    if m: return _row(ts,'good','Administrator authentication succeeded',f'"{m.group(1)}" authenticated as administrator to authorize: {m.group(3)}.',raw)
    if 'Registered Authentication Agent' in msg: return _row(ts,'info','Authentication agent started','The polkit authentication agent (the administrator password prompt) started.',raw)
    if 'Unregistered Authentication Agent' in msg: return _row(ts,'info','Authentication agent stopped','The polkit authentication agent stopped (normally at log-out).',raw)
    m=re.search(r'(?:Connection closed|Disconnected from) (?:by )?(?:(?:authenticating|invalid) user (\S+) )?(\S+) port',msg)
    if m: return _row(ts,'info','Disconnected',f'{m.group(2)} ({_where(m.group(2))}) disconnected'+(f' while attempting to log in as "{m.group(1)}"' if m.group(1) else '')+'.',raw)
    if re.search(r'(?i)fail|denied|invalid|error',msg):
        return _row(ts,'warn',f'Login system ({p or "unknown"})',msg,raw)
    return _row(ts,'info',f'Login system ({p or "note"})',msg,raw)

_PROG_NAMES={'kernel':'the kernel','systemd':'systemd','NetworkManager':'the network manager',
             'gnome-shell':'the desktop','cinnamon':'the desktop','dbus-daemon':'the message bus','CRON':'scheduled jobs',
             'cron':'scheduled jobs','rsyslogd':'rsyslog','polkitd':'polkit',
             'wpa_supplicant':'Wi-Fi','avahi-daemon':'Avahi (mDNS)','cupsd':'printing','ufw':'the firewall',
             'freshclam':'freshclam (ClamAV signature updater)','clamd':'clamd (ClamAV scanner)','udisksd':'udisks',
             'systemd-logind':'the login manager','systemd-resolved':'name lookups (DNS)','packagekitd':'the software updater',
             'locsecd.py':'LocSec','locsecd':'LocSec','locsecd-broker':'the LocSec privilege broker','aide':'AIDE','dailyaidecheck':'AIDE daily check'}

def _sys_explain(prog,msg,ts,raw,blocks):
    fw=_fw_explain(msg,ts,raw,blocks)
    if fw: return fw
    who=_PROG_NAMES.get(prog,prog or 'unknown program')
    if prog in ('freshclam','clamd'):
        cr=_clam_msg_row(ts,msg,raw)
        if cr: return cr
    msg=re.sub(r'^<(?:info|warn|error|debug|trace)>\s+\[[\d.]+\]\s*','',msg)
    m=re.search(r'apparmor="DENIED" operation="([^"]+)".*?profile="([^"]+)"(?:.*?name="([^"]+)")?',msg)
    if m:
        return _row(ts,'warn','AppArmor denial',f'AppArmor denied "{m.group(2)}" the operation "{m.group(1)}"'+(f' on {m.group(3)}' if m.group(3) else '')+'. Usually a program requesting more access than its profile allows; rarely a security problem.',raw)
    if re.match(r'(Started|Starting) ',msg): return _row(ts,'info','Started',f'{who[0].upper()+who[1:]}: {msg}',raw)
    if re.match(r'(Stopped|Stopping|Deactivated) ',msg): return _row(ts,'info','Stopped',f'{who[0].upper()+who[1:]}: {msg}',raw)
    if re.match(r'Finished |Reached target ',msg): return _row(ts,'good','Completed',f'{who[0].upper()+who[1:]}: {msg}',raw)
    if re.search(r'(?i)\b(failed|failure|fatal|panic|segfault|oom-kill|out of memory)\b',msg):
        return _row(ts,'bad','Error',f'{who[0].upper()+who[1:]} reported an error: {msg}',raw)
    if re.search(r'(?i)\b(error|warning|warn|denied|refused|timed out|timeout)\b',msg):
        return _row(ts,'warn','Warning',f'{who[0].upper()+who[1:]}: {msg}',raw)
    return _row(ts,'info',f'{who[0].upper()+who[1:]}',msg,raw)

_LOCSEC_LINE=re.compile(r'^(\S+)\s+(INFO|WARN|WARNING|ERROR|DEBUG)\s+(.*)$')

def _locsec_explain(line,blocks):
    m=_LOCSEC_LINE.match(line)
    if m:
        ts,_=_parse_ts(m.group(1)); level=m.group(2); msg=m.group(3)
    else:
        ts,_,msg=_split_syslog(line); level='INFO'
    raw=line
    base={'INFO':'info','DEBUG':'info','WARN':'warn','WARNING':'warn','ERROR':'bad'}.get(level,'info')
    mm=re.match(r'(denied authentication attempt|successful authentication)(?: user=(\S+))?(?: from=(\S+))?',msg)
    if mm:
        who=f'"{mm.group(2)}"' if mm.group(2) else 'someone'; frm=f' from {mm.group(3)} ({_where(mm.group(3))})' if mm.group(3) else ''
        if mm.group(1).startswith('denied'):
            return _row(ts,'warn','Wrong password',f'A login as {who}{frm} was refused.',raw,**({} if mm.group(3) else {'fix':_LOCAL_PW_FIX}))
        if not mm.group(2) and not mm.group(3):
            return _row(ts,'info','Session opened','A session was opened on this computer: a login, a sudo command or a scheduled job. The Authentication log shows which.',raw)
        return _row(ts,'good','Logged in',f'{who.capitalize() if who=="someone" else who} logged in{frm}.',raw)
    if msg.startswith('network-denied') and ':' in msg:
        fw=_fw_explain(msg.split(': ',1)[1] if ': ' in msg else msg,ts,raw,blocks)
        if fw: return fw
    mm=re.match(r'network-denied: (\d+) more',msg)
    if mm: return _row(ts,'info','High volume of blocked connections',f'The firewall blocked {mm.group(1)} more connection attempts this minute. They were counted rather than logged individually.',raw)
    if msg.startswith('application-connection-failure'):
        body=msg.split(': ',1)[-1]
        if _LOCAL_HW_RX.search(body):
            return _row(ts,'info','Firmware updater note',"The firmware updater (fwupd) could not read one of the computer's own chip settings "
                        '(Intel ME / BootGuard). This is inside the computer, not the internet, and is harmless.',raw,
                        fix='No action needed. Newer LocSec versions no longer log these lines.')
        return _row(ts,'info','Outbound connection failed','A program on this computer could not reach a remote service, usually because that service was unavailable. '+body[:300],raw,
                    fix='No action needed unless a service you use stopped working. If so, check network connectivity and the System log around the same time.')
    mm=re.match(r'threat feed update: (\d+)/(\d+) source\(s\) reached; (\d+) IPs, (\d+) networks, (\d+) domains; (\d+) newly blocked, (\d+) already blocked',msg)
    if mm:
        a,b,ips,nets,doms,new,old=mm.groups()
        return _row(ts,'good' if a==b else 'warn','Threat lists updated',
                    f'LocSec refreshed its threat-intelligence lists from {a} of {b} sources: {ips} individual addresses, '
                    f'{nets} network ranges and {doms} domains. {new} were newly added to the blocked computers; {old} were already blocked.',raw)
    if msg.startswith('threat feed update: every source failed'):
        return _row(ts,'warn','Threat lists could not be updated','None of the threat-intelligence sources could be reached (no network connectivity?). LocSec kept the previous lists and retries every 15 minutes.',raw)
    mm=re.match(r'feed update failed (\S+): (.*)$',msg)
    if mm: return _row(ts,'warn','Threat list download failed',f'{mm.group(1)} could not be reached: {mm.group(2)[:200]}',raw)
    mm=re.match(r'blocked address by (\S+?);?\s*expires=(\d+)',msg)
    if mm:
        until=datetime.fromtimestamp(int(mm.group(2))).strftime('%b %d, %Y')
        why={'auth-monitor':'of repeated failed logins','scan-monitor':'it ran a port scan against this computer','suricata':'its traffic matched a Suricata intrusion signature',
             'feed':'it appears on a threat-intelligence list','manual':'it was blocked manually',
             'incident-action':'Fix it was used on an incident'}.get(mm.group(1),f'of {mm.group(1)}')
        return _row(ts,'warn','Computer blocked',f'LocSec added an address to the blocked computers because {why}. The block lasts until {until}. Firewall & Blocks lists the address.',raw)
    mm=re.match(r'block expired: (\S+)$',msg)
    if mm: return _row(ts,'info','Block expired',f'{mm.group(1)} was removed from the blocked computers: its block period ended.',raw)
    mm=re.match(r'(?:automatic block of (\S+) by \S+ refused|lifted automatic block on (\S+)): ',msg)
    if mm: return _row(ts,'info','Block intentionally skipped',f'{mm.group(1) or mm.group(2)} is a DNS server or gateway this computer depends on. LocSec never blocks those automatically, since that would cut off network access.',raw)
    mm=re.match(r'quarantine (/.*): ok=(True|False) ?(.*)$',msg)
    if mm:
        if mm.group(2)=='True': return _row(ts,'good','File quarantined',f'{mm.group(1)} was moved into quarantine, where it cannot be executed.',raw)
        return _row(ts,'warn','Could not quarantine',f'{mm.group(1)}: {mm.group(3)[:300]}',raw,fix='Read the reason. A file under a system folder needs "Force" on the Malware / Quarantine page.')
    mm=re.match(r'quarantine restore (\S+): ok=(True|False) ?(.*)$',msg)
    if mm: return _row(ts,'info' if mm.group(2)=='True' else 'warn','File restored' if mm.group(2)=='True' else 'File restore failed',
                       (f'A quarantined file was restored to {mm.group(3)}.' if mm.group(2)=='True' else mm.group(3)[:300]),raw)
    mm=re.match(r'deleted (?:quarantined item \S+|all quarantined items \((\d+) files\))$',msg)
    if mm: return _row(ts,'info','Quarantine emptied' if mm.group(1) else 'Quarantined file deleted',
                       f'{mm.group(1)} quarantined file(s) were permanently deleted.' if mm.group(1) else 'A quarantined file was permanently deleted from Malware / Quarantine.',raw)
    mm=re.match(r'deleted (?:packet capture (\S+)|all packet captures \((\d+) files\))',msg)
    if mm: return _row(ts,'info','Capture deleted',f'The packet capture {mm.group(1)} was deleted.' if mm.group(1) else f'{mm.group(2)} packet capture(s) were deleted.',raw)
    if re.match(r'packet capture \S+ stopped early: disk nearly full',msg):
        return _row(ts,'warn','Capture stopped: disk nearly full','A packet capture was stopped early because the disk is almost full.',raw,
                    fix='Delete old captures on Ports & Capture, and free some disk space.')
    if re.match(r'(?:scan job "\w+" interrupted by shutdown|CVE scan interrupted by shutdown)',msg):
        return _row(ts,'info','Scan interrupted by restart','LocSec was stopped or restarted (for example by a package update) while a scan was running. The scan is rescheduled automatically.',raw)
    if msg.startswith('client disconnected before the response could be sent'):
        return _row(ts,'info','Dashboard closed during a job','The dashboard window was closed (or timed out) while a job was running. The job still completed; its report is on the Reports page.',raw)
    mm=re.match(r'unblocked (\S+?):',msg)
    if mm: return _row(ts,'info','Unblocked',f'{mm.group(1)} was removed from the blocked computers.',raw)
    mm=re.match(r'restored (\d+)/(\d+) active persisted blocks',msg)
    if mm: return _row(ts,'good','Blocks restored',f'At startup LocSec re-applied {mm.group(1)} of its {mm.group(2)} blocks to the firewall.',raw)
    mm=re.match(r'port scan from (\S+): (.*)$',msg)
    if mm: return _row(ts,'bad','Port scan detected',f'{mm.group(1)} probed many different ports within a few minutes, looking for an exposed service (a port scan). {mm.group(2)[:300]}',raw)
    mm=re.match(r'staggered scan job "(\w+)" completed',msg)
    if mm: return _row(ts,'good','Scan completed',f'The {_JOB_LABEL.get(mm.group(1),mm.group(1))} scan completed. Its report is on the Reports page.',raw)
    mm=re.match(r'ClamAV scan completed status=(\S+) scanned=(\d+) infected=(\d+) errors=(\d+)',msg)
    if mm:
        inf=int(mm.group(3))
        return _row(ts,'bad' if inf else 'good','Virus scan finished',
                    f'ClamAV scanned {mm.group(2)} files and found {"no malware" if not inf else str(inf)+" infected file(s); see Malware / Quarantine"}.'
                    +(f' {mm.group(4)} file(s) could not be read (normal on a system in use).' if int(mm.group(4)) else ''),raw)
    mm=re.match(r'(.+?) scan completed rc=(-?\d+)',msg)
    if mm: return _row(ts,'info','Scan completed',f'{mm.group(1)} completed (exit code {mm.group(2)}). The result is on the Reports page.',raw)
    mm=re.match(r'package update completed; changed (\d+) packages',msg)
    if mm: return _row(ts,'good','Updates installed',f'{mm.group(1)} package(s) were updated.' if mm.group(1)!='0' else 'Checked for updates; none were pending.',raw)
    if re.match(r'(rkhunter definitions update|ClamAV signature update) rc=',msg):
        return _row(ts,'info','Signatures updated','LocSec updated the ClamAV or rkhunter signature data.' if msg.endswith('rc=0') else msg,raw)
    if msg.startswith('API/dashboard listening'): return _row(ts,'good','LocSec started','LocSec is running and this dashboard is ready.',raw)
    if msg.startswith('LocSec server shut down cleanly'): return _row(ts,'info','LocSec stopped','LocSec stopped cleanly (a restart or an update does this).',raw)
    mm=re.match(r'deleted report (\S+)',msg)
    if mm: return _row(ts,'info','Report deleted',f'The report {mm.group(1)} was deleted.',raw)
    mm=re.match(r'reports older than (\d+) days removed: (\d+)',msg)
    if mm: return _row(ts,'info','Old reports cleaned up',f'{mm.group(2)} report file(s) older than {mm.group(1)} days were deleted to save disk space.',raw)
    mm=re.match(r'systemctl (\w+) (\S+): rc=(\d+)',msg)
    if mm: return _row(ts,'info' if mm.group(3)=='0' else 'warn','Service '+mm.group(1),f'{mm.group(1).capitalize()} was run on {mm.group(2)} from the Services page.',raw)
    if msg.startswith('UFW is not enabled: LocSec fallback firewall on'):
        return _row(ts,'warn','Fallback firewall enabled','UFW is disabled, so LocSec installed its own default-deny fallback firewall for incoming traffic until UFW is enabled again.',raw)
    if 'fallback firewall was removed' in msg: return _row(ts,'good','Fallback firewall removed','UFW is active again, so LocSec removed its fallback firewall.',raw)
    mm=re.match(r'incident=(\S+) action=(\w+): (.*)$',msg)
    if mm: return _row(ts,base,'Incident '+mm.group(2),mm.group(3)[:400],raw)
    mm=re.match(r'(response policy|notification settings) changed: (\{.*\})$',msg)
    if mm:
        try:
            import ast
            d=ast.literal_eval(mm.group(2))
            if not isinstance(d,dict): raise ValueError
        except Exception: d=None
        if d is not None:
            names=_POLICY_LABELS if mm.group(1)=='response policy' else _NOTIFY_TITLES
            on=[names.get(k,k) for k,v in d.items() if v is True]; off=[names.get(k,k) for k,v in d.items() if v is False]
            what='Automatic response settings' if mm.group(1)=='response policy' else 'Pop-up notification settings'
            return _row(ts,'info',what+' saved',
                        'Settings were saved on the Incidents page. '+(f'On: {", ".join(on)}. ' if on else '')+(f'Off: {", ".join(off)}.' if off else ''),raw)
    if re.match(r'.* log cleared from the dashboard',msg):
        return _row(ts,'info',"LocSec's log was cleared",'"Clear LocSec\'s log" was used on the Logs page. '+msg,raw,
                    fix='If you did this, no action is needed. If not, someone else has access to your dashboard: log out and change your password with: passwd')
    mm=re.match(r'incident (\S+) deleted$',msg)
    if mm: return _row(ts,'info','Incident deleted','An incident was deleted from the Incidents page.',raw)
    if msg=='all incidents deleted': return _row(ts,'info','All incidents deleted','Every incident was deleted from the Incidents page.',raw)
    mm=re.match(r'threat feed: recorded which list named (\d+)',msg)
    if mm: return _row(ts,'info','Block reasons recorded',f'LocSec recorded which threat list named {mm.group(1)} already-blocked computer(s), so Firewall & Blocks can show the reason.',raw)
    if not msg.strip(): return None
    title={'info':'LocSec note','warn':'LocSec warning','bad':'LocSec problem'}[base]
    fix={'warn':'If this keeps coming back, restart LocSec on the Services page. If it still appears, the Troubleshooting page lists the usual causes.',
         'bad':'Restart LocSec on the Services page. If the problem stays, run: sudo journalctl -u locsecd -n 50 and look at the lines around this time.'}.get(base,'')
    return _row(ts,base,title,msg,raw,**({'fix':fix} if fix else {}))

_RKH_GOOD=('[ OK ]','[ Not found ]','[ None found ]','[ Clean ]','[ Not infected ]','[ No update ]','[ Updated ]')

def _rkh_explain(line):
    raw=line; m=re.match(r'^\[\s*(\d\d:\d\d:\d\d)\s*\]\s*(.*)$',line)
    tstr=m.group(1) if m else ''; body=(m.group(2) if m else line).rstrip()
    item=re.sub(r'\s*\[ [^\]]+ \]\s*$','',body).strip()
    if body.startswith('Warning:') or '[ Warning ]' in body:
        return _row(None,'warn','Needs review',f'rkhunter flagged this for review: {item.replace("Warning:","").strip()}',raw,tstr=tstr)
    if any(body.endswith(g) for g in _RKH_GOOD):
        return _row(None,'good','Passed',item,raw,tstr=tstr)
    if body.endswith('[ Skipped ]'): return _row(None,'info','Skipped',item+' (not applicable on this system)',raw,tstr=tstr)
    if body.startswith('Info:'): return _row(None,'info','Note',body[5:].strip(),raw,tstr=tstr)
    if re.search(r'(?i)\berror\b',body): return _row(None,'bad','Problem',body,raw,tstr=tstr)
    return _row(None,'info','Note',body,raw,tstr=tstr)

def _clam_explain(line):
    ts,prog,msg=_split_syslog(line)
    if not prog:
        mm=re.match(r'^(\w{3} \w{3} +\d{1,2} \d\d:\d\d:\d\d \d{4}) -> (.*)$',line)   # freshclam.log
        if mm:
            try: ts=time.mktime(time.strptime(mm.group(1),'%a %b %d %H:%M:%S %Y'))
            except ValueError: ts=None
            msg=mm.group(2)
    return _clam_msg_row(ts,msg,line)

_CLAM_STAMP=re.compile(r'\w{3} \w{3} +\d{1,2} \d\d:\d\d:\d\d \d{4} -> ')

def _clam_msg_row(ts,msg,raw):
    # freshclam stamps its own lines, and the system log keeps that stamp: sometimes first, sometimes
    # after a "WARNING:" prefix. Drop it wherever it is so the rules below see the plain message.
    s=_CLAM_STAMP.sub('',msg.strip(),count=1)
    if not s or set(s)<={'-'}: return None
    mm=re.search(r'(\w+)\.c[lv]d database is up[ -]to[ -]date \(version: (\d+), sigs: (\d+)',s)
    if mm: return _row(ts,'good','Signatures up to date',f'The ClamAV "{mm.group(1)}" signature database is current ({int(mm.group(3)):,} signatures).',raw)
    mm=re.search(r'(\w+)\.c[lv]d updated \(version: (\d+), sigs: (\d+)',s)
    if mm: return _row(ts,'good','Signatures updated',f'Downloaded a newer ClamAV "{mm.group(1)}" signature database ({int(mm.group(3)):,} signatures).',raw)
    if re.search(r'(?i)database test passed|database updated|database load',s): return _row(ts,'good','Signature database verified','The new signature database passed its integrity test.',raw)
    if re.search(r'update process started',s): return _row(ts,'info','Signature update started','freshclam started checking for newer signatures.',raw)
    # ClamAV prints this banner above its out-of-date notice. It is a pointer to the manual, not a failure:
    # the word "panic" in it must not turn the row into a Problem.
    if re.search(r"(?i)^don'?t panic\b",s): return _row(ts,'info','ClamAV notice','ClamAV is referring to its documentation (usually printed next to a version notice). It is not an error.',raw)
    if re.search(r'(?i)local version: .* recommended version:',s): return _row(ts,'warn','ClamAV engine outdated','A newer ClamAV engine version exists. Detection still works; regular system updates will install it.',raw)
    if re.search(r'(?i)OUTDATED',s): return _row(ts,'warn','ClamAV engine outdated','A newer ClamAV engine version exists. Detection still works; regular system updates will install it.',raw)
    if re.search(r'(?i)received signal: wake up',s): return _row(ts,'info','Scheduled check','freshclam started its scheduled signature check.',raw)
    if re.match(r'(?i)warning\b',s):
        return _row(ts,'warn','Warning',('A signature mirror could not be reached; freshclam retries later. ' if re.search(r"(?i)can't (query|connect|download)",s) else '')+s,raw)
    if re.search(r'(?i)\berror\b|can\'t|failed',s): return _row(ts,'bad','Signature update error',s,raw)
    if re.search(r'(?i)\bwarning\b',s): return _row(ts,'warn','Warning',s,raw)
    return _row(ts,'info','Note',s,raw)

# What each AIDE attribute means, in everyday words. Every hash AIDE can record
# means the same thing to a reader: the contents are different.
_AIDE_ATTR={'size':'size','perm':'permissions','uid':'owner','gid':'group','mtime':'last-changed time',
            'lname':'link target','linkcount':'number of links','acl':'access list','xattrs':'extra attributes',
            'selinux':'SELinux label','e2fsattrs':'file flags','caps':'file capabilities','inode':None,
            'ctime':None,'atime':None,'bcount':None}
_AIDE_HASH=re.compile(r'(?i)^(md5|sha\d*|rmd160|tiger|crc32b?|haval|gost|whirlpool|stribog\d*|sha512_256)$')
_AIDE_FILEHDR=re.compile(r'^(?:File|Directory|Link|FIFO|Socket|Block device|Character device|Door|Port|Entry): (/.*)$')
_AIDE_ATTRLINE=re.compile(r'^\s+([A-Za-z][A-Za-z0-9_]*)\s*:\s*(.*?)\s*\|\s*(.*?)\s*$')
_AIDE_CACHE={}
_AIDE_CACHE_LOCK=threading.Lock()
# Records kept from one AIDE result: every important path, plus this many ordinary ones
# (the Logs page shows 1500 rows). A dist-upgrade changes ~100,000 paths; keeping a
# record for each held hundreds of MB for as long as the result was cached.
_AIDE_KEEP_ORDINARY=1500
_AIDE_KEEP_IMPORTANT=20000

def _pkg_activity():
    """Latest install/upgrade/remove time per package, from dpkg's own log (every route:
    apt, a .deb opened in a software centre, dpkg -i). Returns {package: unix time}."""
    import gzip
    act={}
    files=[Path('/var/log/dpkg.log'),Path('/var/log/dpkg.log.1')]+[Path(f'/var/log/dpkg.log.{i}.gz') for i in range(2,5)]
    rx=re.compile(r'^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) (?:install|upgrade|remove|purge|configure) ([a-z0-9][a-z0-9+.-]*)(?::\S+)? ')
    for f in files:
        try:
            if not f.is_file(): continue
            opener=gzip.open if f.suffix=='.gz' else open
            with opener(f,'rt',errors='replace') as fh:
                for n,line in enumerate(fh):
                    if n>400000: break
                    m=rx.match(line)
                    if not m: continue
                    try: t=time.mktime(time.strptime(m.group(1),'%Y-%m-%d %H:%M:%S'))
                    except ValueError: continue
                    if t>act.get(m.group(2),0): act[m.group(2)]=t
        except (OSError,EOFError): continue
    return act

def _dpkg_owners(paths):
    """{path: [packages]} for the paths an installed package owns, read from dpkg's own
    file lists in one pass (dpkg-query -S re-reads every list for each call, which made
    a few thousand paths take minutes). /usr-merge means dpkg may know a file as /bin/x
    or /usr/bin/x, so both spellings are looked up."""
    want={}
    for p in paths:
        if not p.startswith('/') or '\n' in p: continue
        alts=[p]
        m=re.match(r'^/(bin|sbin|lib|lib32|lib64)(/.*)$',p)
        if m: alts.append('/usr'+p)
        m=re.match(r'^/usr/(bin|sbin|lib|lib32|lib64)(/.*)$',p)
        if m: alts.append(p[4:])
        for x in alts: want.setdefault(x,p)
    owners={}
    if not want: return owners
    try: lists=sorted(Path('/var/lib/dpkg/info').glob('*.list'))
    except OSError: return owners
    for lf in lists:
        pkg=lf.name[:-5].split(':')[0]
        try:
            with open(lf,'r',errors='replace') as f:
                for line in f:
                    orig=want.get(line.rstrip('\n'))
                    if orig is not None:
                        lst=owners.setdefault(orig,[])
                        if pkg not in lst: lst.append(pkg)
        except OSError: continue
    return owners

def _aide_parse(path,limit=200000):
    """Read a full AIDE --check output: verdict, counts, every entry and, where AIDE wrote
    them, the old and new value of each attribute that changed."""
    out={'ts':None,'verdict':None,'counts':{},'entries':[],'details':{}}
    try: out['ts']=Path(path).stat().st_mtime
    except OSError: pass
    section=None; cur=None; detailed=False
    with open(path,'r',errors='replace') as f:
        for n,line in enumerate(f):
            if n>600000: break
            line=line.rstrip('\n'); low=line.strip().lower()
            mm=re.match(r'\s*Start timestamp:\s*(\S+ \S+)\s*([+-]\d{4})?',line)
            if mm:
                t,_=_parse_ts(mm.group(1).replace(' ','T')+(mm.group(2) or ''))
                if t: out['ts']=t
                continue
            if 'found no differences' in low: out['verdict']='same'; continue
            if 'found differences' in low: out['verdict']='changed'; continue
            mm=re.match(r'\s*(Total number of entries|Added entries|Removed entries|Changed entries):\s*(\d+)',line)
            if mm: out['counts'][mm.group(1)]=int(mm.group(2)); continue
            if low in ('added entries:','removed entries:','changed entries:'):
                section=low.split()[0]; detailed=False; continue
            if low.startswith('detailed information about changes'): section=None; detailed=True; continue
            if low.startswith('the attributes of the'): section=None; detailed=False; continue
            if section:
                em=_AIDE_ENTRY.match(line)
                if em and len(out['entries'])<limit: out['entries'].append((section,em.group(1).strip()))
                continue
            if detailed:
                hm=_AIDE_FILEHDR.match(line)
                if hm:
                    cur=hm.group(1).strip()
                    if len(out['details'])<limit: out['details'][cur]={}
                    else: cur=None
                    continue
                am=_AIDE_ATTRLINE.match(line)
                if am and cur is not None and cur in out['details']:
                    out['details'][cur].setdefault(am.group(1).lower(),(am.group(2),am.group(3)))
    return out

def _aide_change_text(d):
    """'contents, size 221 -> 248 bytes, permissions -rw-r--r-- -> -rwsr-xr-x' and whether
    a change is the dangerous kind (gained setuid/setgid or capabilities, changed owner)."""
    parts=[]; danger=[]
    if any(_AIDE_HASH.match(k) for k in d): parts.append('its contents')
    for k,(old,new) in d.items():
        if _AIDE_HASH.match(k): continue
        label=_AIDE_ATTR.get(k,k)
        if label is None: continue
        if k=='size': parts.append(f'size {old} \u2192 {new} bytes')
        elif k in ('perm','uid','gid','lname'): parts.append(f'{label} {old} \u2192 {new}')
        elif k=='mtime': continue
        else: parts.append(label)
        if k=='perm' and re.search(r'[sS]',new[:10]) and not re.search(r'[sS]',old[:10]): danger.append('it gained the setuid/setgid bit')
        if k=='caps' and new.strip() not in ('','-'): danger.append('it was given file capabilities')
        if k=='uid': danger.append('its owner changed')
    if not parts and 'mtime' in d: parts.append('only its last-changed time')
    return ', '.join(parts),danger

def _when(t):
    try: return datetime.fromtimestamp(t).strftime('%b %d, %Y %H:%M')
    except Exception: return '?'

def aide_analyze(path):
    """Everything the AIDE views need: one record per changed path with what changed, which
    package owns it, whether an install or update since the last snapshot explains it, the
    level and the fix. Cached per file (one at a time), and built by one request at a time."""
    try: st=Path(path).stat(); key=(str(path),st.st_mtime,st.st_size)
    except OSError:
        _AIDE_CACHE.clear(); raise
    with _AIDE_CACHE_LOCK:
        if _AIDE_CACHE.get('key')==key: return _AIDE_CACHE['data']
        _AIDE_CACHE.clear()
        data=_aide_analyze(path)
        _AIDE_CACHE.update({'key':key,'data':data})
        return data

# Files a package's setup script makes, which dpkg does not list as the package's own: the file they are
# made from, and what to call the relationship. (paths to look up, wording)
def _aide_derived_from(p):
    m=re.match(r'^(.*)/__pycache__/([^/]+?)\.cpython-\d+(?:\.opt-\d)?\.pyc$',p)
    if m: return [f'{m.group(1)}/{m.group(2)}.py'],'Python byte-code compiled at installation from'
    m=re.match(r'^(.*)/__pycache__$',p)
    if m: return [m.group(1)],'Python byte-code cache made at installation in'
    m=re.match(r'^/etc/rc[0-6S]\.d/[SK]\d\d([^/]+)$',p)
    if m: return [f'/etc/init.d/{m.group(1)}'],'start/stop link made when the service was enabled, for'
    m=re.match(r'^/etc/systemd/system/[^/]+\.(?:wants|requires)/([^/]+)$',p)
    if m: return [f'/usr/lib/systemd/system/{m.group(1)}',f'/lib/systemd/system/{m.group(1)}'],'link made when the service was enabled, for'
    m=re.match(r'^(.+)\.(?:dpkg-(?:old|dist|new|bak)|ucf-(?:old|dist|new))$',p)
    if m: return [m.group(1)],'copy dpkg keeps when an upgrade changes a configuration file:'
    return [],''

_SYNAPTIC_LOG=re.compile(r'^/root/\.config/synaptic/log/(\d{4}-\d\d-\d\d)\.(\d{6})\.log$')

# The account database. A package that adds a system account changes all of these; so does a password change.
_AIDE_ACCOUNT_FILES={'/etc/passwd','/etc/passwd-','/etc/group','/etc/group-','/etc/shadow','/etc/shadow-','/etc/gshadow','/etc/gshadow-'}
# Unowned files the system rebuilds itself while packages are installed.
_AIDE_REBUILT={'/etc/ld.so.cache':'ldconfig rebuilds it whenever a package with libraries is installed or updated',
               '/etc/mailcap':'update-mime rebuilds it when a package registers file types',
               '/etc/apt/apt.conf.d/99synaptic':'Synaptic rewrites it each time it runs'}
_AA_CLAMD_LOCAL='/etc/apparmor.d/local/usr.sbin.clamd'
_ACCOUNT_PROGS={'useradd','groupadd','usermod','userdel','groupdel','gpasswd','passwd','chpasswd','chage','chfn','chsh','newusers',
                'adduser','addgroup','deluser','delgroup','groupmod'}

def _aide_locsec_file(p):
    """A file LocSec's own installer writes but does not ship: anything in /etc/locsecd, and its marked clamd AppArmor rule."""
    if p.startswith('/etc/locsecd/'): return True
    if p==_AA_CLAMD_LOCAL:
        try: return 'Added by locsecd' in Path(p).read_text(errors='replace')
        except OSError: return False
    return False

def _aide_account_story(base):
    """What the system log says happened to accounts since the snapshot: (only system accounts were added, text),
    or None when the log has nothing (rotated away, or no rsyslog)."""
    import pwd
    events=[]
    for f in ('/var/log/auth.log.1','/var/log/auth.log'):
        try:
            # The newest 8 MB, not the oldest: on a busy host the changes since the snapshot are at the end.
            with _priv_open(f) as fh:
                size=fh.seek(0,2); fh.seek(max(0,size-(8<<20))); lines=fh.read(8<<20).decode('utf-8','replace').splitlines()
        except OSError: continue
        if size>8<<20 and lines:
            lines=lines[1:]                       # starts mid-line
            first=next((t for t in (_split_syslog(x[:2000])[0] for x in lines[:50]) if t),None)
            # The part read starts after the snapshot: older account changes since then are unseen,
            # so the log cannot be said to explain the account files.
            if first is None or first>base-60: return None
        for line in lines:
            ts,prog,msg=_split_syslog(line[:2000])
            prog=re.sub(r'\[\d+\]$','',prog or '')
            if not ts or ts<base-60: continue
            if prog in _ACCOUNT_PROGS or 'password changed for' in msg: events.append((ts,prog,msg.strip()))
    if not events: return None
    def sysuid(n):
        try: return pwd.getpwnam(n).pw_uid<1000
        except KeyError: return False
    benign=[]; other=[]
    for ts,prog,msg in events:
        m=re.search(r"new (user|group): name=([\w.-]+), (?:UID|GID)=(\d+)",msg) or re.search(r"group added to /etc/(?:group|gshadow): name=([\w.-]+)(?:, GID=(\d+))?",msg)
        ok=False
        if m and m.re.pattern.startswith('new'): ok=int(m.group(3))<1000
        elif m: ok=(m.group(2) is None or int(m.group(2))<1000) and (m.group(2) is not None or _gid_is_system(m.group(1)))
        else:
            a=re.search(r"add '([\w.-]+)' to (?:shadow )?group '([\w.-]+)'",msg)
            if a: ok=sysuid(a.group(1)) and (a.group(2) not in _RKH_PRIVILEGED_GROUPS or (a.group(1)=='locsec' and a.group(2) in ('adm','systemd-journal')))
            elif re.search(r"Adding system (?:user|group)",msg): ok=True
        (benign if ok else other).append(f'{_when(ts)} {prog}: {msg[:160]}')
    if not other:
        names=sorted({x for _,_,msg in events for x in re.findall(r"name=([\w.-]+)",msg)})
        return True,('The account database. Since the last snapshot the system log records only system accounts and groups being added by package installs'
                     +(f' ({", ".join(names[:12])})' if names else '')+'. That explains this.')
    return False,('The account database. Since the last snapshot the system log records these account changes, which need your confirmation: '
                  +'; '.join(other[:6])+('' if len(other)<=6 else f'; and {len(other)-6} more')+'.')

def _gid_is_system(name):
    try:
        import grp
        return grp.getgrnam(name).gr_gid<1000
    except (KeyError,ImportError): return False

def _aide_analyze(path):
    a=_aide_parse(path)
    # /var/lib/aide is not readable by the unprivileged user (Debian: root:_aide 0750), so a plain
    # stat() fails there and nothing could ever be explained. The broker's aide.state reports it.
    try:
        _db=(_aide_db_state() or {}).get('database') or {}
        base=float(_db['mtime']) if _db.get('exists') and _db.get('mtime') else None
    except Exception: base=None
    sens=[p for _,p in a['entries'] if _AIDE_SENSITIVE.search(p)][:_AIDE_KEEP_IMPORTANT]
    owners=_dpkg_owners(sens) if sens else {}
    activity=_pkg_activity() if sens else {}
    # Unowned files a package's setup made (byte-code, enable links, .dpkg-old): look up the file they come from.
    derived={}
    for section,p in a['entries']:
        if section!='removed' and p in sens and not owners.get(p):
            bases,how=_aide_derived_from(p)
            if bases: derived[p]=(bases,how)
    downers=_dpkg_owners(sorted({b for bases,_ in derived.values() for b in bases})) if derived else {}
    since=sorted(((t,p) for p,t in activity.items() if base and t>=base-60),reverse=True)
    acct=None
    if base and any(p in _AIDE_ACCOUNT_FILES for _,p in a['entries']):
        try: acct=_aide_account_story(base)
        except Exception as e: log(f'AIDE: could not read the account history: {e}','WARN')
    recs=[]; ordinary=0; important=0
    for section,p in a['entries']:
        s=bool(_AIDE_SENSITIVE.search(p))
        if s:
            important+=1
            if important>_AIDE_KEEP_IMPORTANT: continue
        else:
            ordinary+=1
            if ordinary>_AIDE_KEEP_ORDINARY: continue
        d=a['details'].get(p,{})
        what,danger=_aide_change_text(d) if section=='changed' else ('',[])
        pkgs=owners.get(p,[]); via=''
        if not pkgs and p in derived:
            for b in derived[p][0]:
                if downers.get(b): pkgs=downers[b]; via=f'{derived[p][1]} {b}'; break
        hit=[(activity.get(x,0),x) for x in pkgs if base and activity.get(x,0)>=base-60]
        pkg=max(hit)[1] if hit else (pkgs[0] if pkgs else ''); t=activity.get(pkg) if pkg else None
        explained=bool(hit)
        syn=_SYNAPTIC_LOG.match(p) if section=='added' and not pkgs else None
        if syn and base and since:
            try:
                st_=time.mktime(time.strptime(syn.group(1)+syn.group(2),'%Y-%m-%d%H%M%S'))
                explained=st_>=base-60
            except ValueError: pass
        note=''
        if s and not explained and base and section!='removed':
            if p in _AIDE_ACCOUNT_FILES and acct:
                explained,note=acct[0] and bool(since),acct[1]
            elif p in _AIDE_REBUILT and section=='changed' and since:
                explained=True; note=f'{_AIDE_REBUILT[p]}; {len(since)} package(s) changed since the last snapshot. That explains this.'
            elif not pkgs and _aide_locsec_file(p) and activity.get('locsecd',0)>=base-60:
                explained=True; note=f"LocSec's installer writes this file, and LocSec was installed or updated on {_when(activity['locsecd'])}, after the last snapshot. That explains this."
        home=p.startswith('/home/') or p.startswith('/root/')
        verb={'added':'is new','removed':'is gone','changed':'was changed'}[section]
        q=shlex.quote(p)
        if not s: lvl='info'
        elif danger: lvl='bad'
        elif explained: lvl='info'
        elif home: lvl='warn' if section=='added' else 'info'
        elif section=='removed' and since and not pkg: lvl='info'
        else: lvl='warn'
        why=''; fix=''
        if s:
            if note and explained:
                why=note
                fix='Nothing to fix. When you have read this list, press "Build AIDE database" on the Scans page: it takes a new snapshot, so the next check starts from here.'
            elif p in _AIDE_ACCOUNT_FILES:
                why=note or ('The account database (accounts, groups and password hashes). It changes when a package adds a system account, or when an account or password is changed. '
                             'The system log since the last snapshot is not available to say which.')
                fix=("Check the login accounts: awk -F: '$3>=1000 && $3<65534 {print $1}' /etc/passwd  and what changed them: "
                     "sudo grep -E 'useradd|usermod|groupadd|passwd|chpasswd' /var/log/auth.log*  . Every account you see should be yours or a system "
                     "account a package added. Do not move or quarantine this file: nobody could log in without it.")
            elif explained and syn and not pkg:
                why=f'Synaptic writes one of these logs for each package operation run from it as root; {len(since)} package(s) changed since the last snapshot. That explains this.'
                fix='Nothing to fix. When you have read this list, press "Build AIDE database" on the Scans page: it takes a new snapshot, so the next check starts from here.'
            elif explained:
                why=(f'It is a {via}, from the package {pkg}, which was installed or updated on {_when(t)}, after the last snapshot. That explains this.' if via
                     else f'The package {pkg} was installed or updated on {_when(t)}, after the last snapshot. That explains this.')
                fix='Nothing to fix. When you have read this list, press "Build AIDE database" on the Scans page: it takes a new snapshot, so the next check starts from here.'
            elif pkg and section=='removed':
                why=f'It belongs to the package {pkg}, which has not been updated since the last snapshot.'
                fix=f'If you did not delete it, put it back: sudo apt install --reinstall {pkg}'
            elif pkg:
                why=f'It belongs to the package {pkg}, which has not been updated since the last snapshot.'
                fix=(f'Check it: sudo dpkg --verify {pkg}  (no output means the package files are as shipped). '
                     +('Files under /etc are settings: if you edited it yourself, that is the change. ' if p.startswith('/etc/') else '')
                     +f'If it is listed and you did not change it, put the original back: sudo apt install --reinstall {pkg}')
            elif home:
                why='This is a start-up or login file in a home folder.'
                fix=(f'If you or a program you set up changed it, nothing to fix. If not, look inside: cat {q}  '
                     'An unknown line in .bashrc or .profile, or an unknown file in .config/autostart, is how some malware starts itself.')
            elif section=='removed':
                why=('No installed package owns it now. '+(f'{len(since)} package(s) were installed, updated or removed since the last snapshot, so an update most likely took it away.' if since else 'Nothing was installed or updated since the last snapshot.'))
                fix='Nothing to fix if you removed a program or ran updates. Otherwise find out what deleted it before trusting this computer with passwords.'
            else:
                why='No installed package owns this file.'+(f' {len(since)} package(s) changed since the last snapshot; a program\'s setup often writes files like this one.' if since else '')
                fix=(f'If you or a program you installed made it, nothing to fix. If you do not know it, look at it: sudo ls -l {q} ; sudo head -n 20 {q}  '
                     'If it is still a mystery, quarantine it on the Malware / Quarantine page.')
            if danger:
                why=('Warning: '+', and '.join(danger)+'. '+why).strip()
                fix=(f'Find out why: sudo ls -l {q}'+(f' ; sudo dpkg --verify {pkg}' if pkg else '')
                     +('. If no update explains it, reinstall the package: sudo apt install --reinstall '+pkg if pkg else
                       '. A file that unexpectedly gains these privileges and is not owned by any package should be quarantined.'))
        if s and _never_quarantine(p) and 'quarantine' in fix.lower():
            fix=re.sub(r'[^.]*\bquarantine[^.]*\.',' Do not quarantine it: the system needs this file.',fix).strip()
        recs.append({'section':section,'path':p,'sensitive':s,'pkg':pkg,'explained':explained,'what':what,
                     'danger':danger,'lvl':lvl,'verb':verb,'why':why,'fix':fix})
    # A folder whose only change is its last-changed time moved because entries inside it were added or removed;
    # when those entries are explained, so is the folder.
    expl_parents={os.path.dirname(r['path']) for r in recs if r['explained'] and r['section'] in ('added','removed')}
    for r in recs:
        if r['sensitive'] and not r['explained'] and r['section']=='changed' and r['what']=='only its last-changed time' and r['path'] in expl_parents and not r['danger']:
            r.update(explained=True,lvl='info',why='Only its last-changed time moved, because entries inside it were added or removed, and those are explained in this list.',
                     fix='Nothing to fix.')
    order={'bad':0,'warn':1,'info':2}
    recs.sort(key=lambda r:(order[r['lvl']],not r['sensitive']))
    sens_recs=[r for r in recs if r['sensitive']]
    return {'ts':a['ts'],'verdict':a['verdict'],'counts':a['counts'],'records':recs,'baseline':base,
            'changed_packages':len(since),'path':str(path),'total':len(a['entries']),
            'n_important':important,'n_ordinary':ordinary,
            'n_bad':sum(1 for r in sens_recs if r['lvl']=='bad'),
            # Important changes past the analysis cap are unexplained as far as anyone knows.
            'n_warn':sum(1 for r in sens_recs if r['lvl']=='warn')+max(0,important-_AIDE_KEEP_IMPORTANT),
            'n_unanalysed':max(0,important-_AIDE_KEEP_IMPORTANT),
            'n_explained':sum(1 for r in sens_recs if r['explained'])}

def _aide_summary_row(a):
    recs=a['records']; ts=a['ts']
    nsens=a['n_important']; nbad=a['n_bad']; nwarn=a['n_warn']; nexpl=a['n_explained']
    base=f' The last snapshot was taken {_when(a["baseline"])}.' if a.get('baseline') else ''
    if a['verdict']=='same' or not recs:
        return _row(ts,'good','Nothing changed','AIDE compared every file with its baseline and found no changes.'+base,'',fix='No action needed.')
    if nbad:
        return _row(ts,'bad','Review these first',f'{nbad} important file(s) gained setuid/setgid bits or capabilities, or changed owner. This is characteristic of a compromise and rarely caused by updates. They are listed first below.'+base,'',
                    fix='Read the first rows below and follow "What to do" on each one before accepting anything.')
    if nwarn:
        return _row(ts,'warn','Some changes are not explained',
                    f'{nsens:,} important file(s) changed. {nexpl:,} are explained by software installed or updated since the last snapshot; '
                    f'{nwarn:,} are not. Those are listed first below.'
                    +(f' {a["n_unanalysed"]:,} of them were too many to check one by one; the full list is in {a["path"]}.' if a.get('n_unanalysed') else '')+base,'',
                    fix='Check each "Warning" row below and follow its "What to do". When every row is explained, press "Build AIDE database" on the Scans page.')
    return _row(ts,'good','Changes are explained',
                f'{nsens:,} important file(s) changed, and software installed or updated since the last snapshot explains all of them. '
                f'The other {a["n_ordinary"]:,} changes are ordinary (caches, logs, your own files).'+base,'',
                fix='Press "Build AIDE database" on the Scans page: it takes a new snapshot, so the next check starts from here.')

def _aide_friendly(path,limit=1500):
    """Rows for an AIDE check output: what to do first, the counts, then every changed path
    (most important first) with what changed and how to fix it."""
    try: a=aide_analyze(path)
    except Exception as e:
        return [_row(None,'bad','Could not read the AIDE result',str(e),'')]
    ts=a['ts']; c=a['counts']; rows=[_aide_summary_row(a)]
    t=c.get('Total number of entries')
    if c:
        rows.append(_row(ts,'info','What AIDE counted',(f'It checked {t:,} files and folders: ' if t else '')+
                         f'{c.get("Added entries",0):,} new, {c.get("Removed entries",0):,} gone, {c.get("Changed entries",0):,} changed.',''))
    for r in a['records'][:limit]:
        title=('Important file ' if r['sensitive'] else 'File ')+r['verb']
        text=r['path']+' '+r['verb']+'.'+(f' What changed: {r["what"]}.' if r['what'] else '')+(' '+r['why'] if r['why'] else '')
        extra={'fix':r['fix']} if r['fix'] else {}
        rows.append(_row(ts,r['lvl'],title,text,r['path'],**extra))
    if a['total']>min(limit,len(a['records'])):
        rows.append(_row(ts,'info','More not shown',f'{a["total"]-min(limit,len(a["records"])):,} more changes are in {path}.',''))
    return rows

def friendly_log(key,lines,path=None):
    """Turn raw log lines into plain-language rows, newest first."""
    blocks=_BlockLookup(); rows=[]
    if key=='aide' and path and Path(path).name.startswith('aide-full-'):
        return _aide_friendly(path)
    for line in lines:
        if not line.strip(): continue
        # Log text can carry attacker-chosen content (an SSH user name); keep
        # every regex below working on a bounded string.
        line=line[:4000]
        try:
            if key=='locsecd': r=_locsec_explain(line,blocks)
            elif key=='rkhunter': r=_rkh_explain(line)
            elif key=='clamav': r=_clam_explain(line)
            elif key=='suricata': r=_suricata_explain(line)
            elif key=='suricata-engine': r=_suricata_engine_explain(line)
            else:
                ts,prog,msg=_split_syslog(line)
                if key=='auth': r=_auth_explain(prog,msg,ts,line)
                elif key=='ufw': r=_fw_explain(msg,ts,line,blocks) or _row(ts,'info','Firewall note',msg,line)
                elif key=='aide':
                    if re.search(r'(?i)found no differences',msg): r=_row(ts,'good','No changes','AIDE found no changed files.',line)
                    elif re.search(r'(?i)found differences',msg): r=_row(ts,'warn','Some files changed','AIDE found changed files. Run "AIDE" on the Scans page for the full list.',line)
                    else: r=_sys_explain(prog,msg,ts,line,blocks)
                else: r=_sys_explain(prog,msg,ts,line,blocks)
        except Exception:
            r=_row(None,'info','LocSec note' if key=='locsecd' else 'Note',line,line)
        if r: rows.append(r)
    rows=_collapse_repeats(rows)
    if key=='suricata-engine':
        # Problems from before Suricata's latest clean start (the package default eth0 before setup moved it
        # to the real interface, say) are history: show them, but do not count them as current problems.
        last=max((i for i,r in enumerate(rows) if r.get('title')=='Suricata started'),default=-1)
        for r in rows[:max(last,0)]:
            if r.get('lvl') in ('bad','warn'):
                r['lvl']='info'; r['title']='Earlier '+('error' if r['title']=='Suricata error' else 'warning').lower()+' (Suricata has started cleanly since)'
    rows=_apply_log_fixes(rows)
    rows.reverse()
    return rows

def _collapse_repeats(rows,window=300):
    """Fold back-to-back rows that say exactly the same thing within a few minutes into one
    row with a count: seven identical "Session opened" rows in one second told nobody anything."""
    out=[]
    for r in rows:
        prev=out[-1] if out else None
        if (prev is not None and prev['lvl']==r['lvl'] and prev['title']==r['title'] and prev['text']==r['text']
                and (r.get('ts') is None or prev.get('ts') is None or abs((r.get('ts') or 0)-(prev.get('last_ts') or prev.get('ts') or 0))<=window)):
            prev['repeat']=int(prev.get('repeat',1))+1
            if r.get('ts'): prev['last_ts']=r['ts']
            continue
        out.append(r)
    return out

# "What to do" for log rows whose explainer did not give one, keyed by the row title.
# Only rows that call for an action get one; ordinary notes stay quiet.
_LOG_FIXES={
 'Wrong password':'If it was you, no action is needed. Otherwise someone is guessing passwords: LocSec blocks a source that fails too often (see Incidents). If you use SSH, switch to key-based login and set "PasswordAuthentication no" in /etc/ssh/sshd_config.',
 'Unknown account tried':'No action needed. This is automated guessing of common account names; LocSec blocks the source after repeated attempts.',
 'Wrong administrator password':'If that was you, no action is needed. Otherwise someone at this computer knows your user name: lock the screen when you step away and change your password with: passwd',
 'Unauthorized sudo attempt':'If that user should have administrator rights: sudo usermod -aG sudo NAME (then log out and back in). Otherwise find out who attempted it.',
 'AppArmor denial':'Usually no action needed. If a program stopped working at that moment, its AppArmor profile is too restrictive: report it to the program\'s maintainers.',
 'Error':'Open "Show the original log lines" for the exact message. If it names a service, run: sudo systemctl status NAME, and restart it on the Services page.',
 'Warning':'Usually no action needed. If the same entry recurs every few minutes, look up the program name and message.',
 'Computer blocked':'No action needed. If it is a computer you trust, unblock it on Firewall & Blocks and add it to allow_ips in /etc/locsecd/locsecd.conf.',
 'Port scan detected':'No action needed: with port-scan blocking on, LocSec blocks the scanning host. If it was your own device (a network scanner app), add it to allow_ips in /etc/locsecd/locsecd.conf.',
 'Threat lists could not be updated':'Check network connectivity. LocSec retries automatically every 15 minutes.',
 'Threat list download failed':'Check network connectivity. LocSec retries automatically every 15 minutes; one list being briefly unavailable is not a problem.',
 'Fallback firewall enabled':'Re-enable UFW: sudo ufw enable  (run sudo ufw allow ssh first if you administer this machine remotely). LocSec removes its fallback firewall automatically.',
 'Needs review':'Open the newest rkhunter report on the Reports page: it separates passed checks from items that need review. For a changed file: dpkg -S FILE, then sudo dpkg --verify PACKAGE. If it verifies and you just installed updates, refresh rkhunter\'s baseline: sudo rkhunter --propupd',
 'Signature update error':'Check network connectivity, then press "Update virus/rootkit definitions now" on the Scans page, or run: sudo systemctl restart clamav-freshclam',
 'ClamAV engine outdated':'Install system updates (Update system on the Scans page).',
 'Virus scan finished':'Open Malware / Quarantine and quarantine each file it lists.',
 'Some files changed':'Run "AIDE" on the Scans page, then select "AIDE (latest check)" here: it lists each file with what changed and what to do.',
 'Suricata alert':'Open Incidents for what LocSec did about it. If the address is one of your own devices or the alert is a known false positive, add the rule number (sid) to ids_ignore_sids in /etc/locsecd/locsecd.conf.',
 'Suricata error':'Run: sudo suricata -T -c /etc/suricata/suricata.yaml to check the configuration, then: sudo locsecctl suricata-setup',
}

_LOCAL_PW_FIX=('If it was you mistyping, no action is needed. If not, someone has had access to your keyboard: lock the screen when you '
               'step away (Super+L) and change your password with: passwd')

def _apply_log_fixes(rows):
    for r in rows:
        if r.get('fix') or r['lvl'] not in ('warn','bad'): continue
        f=_LOG_FIXES.get(r['title'])
        if f is None and r['title'].startswith('Login system'): f='Usually no action needed. If it repeats, open "Show the original log lines" for the exact message.'
        if f: r['fix']=f
    return rows

# ---------------------------------------------------------------------------
# Reports: a plain list of what each check found and what to do about it,
# computed when a report is opened so older reports get it too.
# ---------------------------------------------------------------------------
_RKH_FIX_FILE=('An update usually does this. Check: dpkg -S {f} , then sudo dpkg --verify PACKAGE (no output = as shipped). '
               'If it verifies and you just ran updates, refresh rkhunter\'s record: sudo rkhunter --propupd  '
               'If it does not verify, reinstall it: sudo apt install --reinstall PACKAGE')

def _rkh_fix(text):
    m=re.search(r'File:\s*(/\S+)',text) or re.search(r"command '(/[^']+)'",text) or re.search(r'found:\s*(/\S+?):',text)
    f=shlex.quote(m.group(1)) if m else 'FILE'
    t=text.lower()
    if 'properties have changed' in t or 'replaced by a script' in t: return _RKH_FIX_FILE.format(f=f)
    if 'hidden file' in t or 'hidden directory' in t: return f'Inspect it: sudo ls -la {f} . If no program you use created it and no package owns it (dpkg -S {f}), quarantine it on the Malware / Quarantine page.'
    if 'root access' in t and 'ssh' in t: return 'Disable root login over SSH: set "PermitRootLogin no" in /etc/ssh/sshd_config, then sudo systemctl restart ssh'
    if 'added to the passwd file' in t or 'added to the group file' in t: return 'If you installed a program just before this, it created the account and nothing is wrong: run sudo rkhunter --propupd. If not, check the account: getent passwd NAME'
    if 'shared memory' in t: return 'Usually a desktop program (browsers use large shared-memory segments). If nothing else looks wrong, no action is needed.'
    if 'promisc' in t: return 'A network interface is in promiscuous mode. Expected while a packet capture or Suricata runs; otherwise find out which program set it: ip link'
    return 'Review the warning. If an update or a program you installed explains it, run sudo rkhunter --propupd so it is not reported again. If nothing explains it, investigate before dismissing it.'

def explain_result(r):
    name=str(r.get('name','')); st=str(r.get('status') or ''); out=str(r.get('output',''))
    items=[]
    def add(lvl,title,text,fix=''): items.append({'lvl':lvl,'title':title,'text':text,'fix':fix})
    if st=='not-installed': add('info','Not installed',f'{name} is not installed, so this scan did not run.','Install it with "Add" on the Overview page.'); return items
    if st=='skipped': add('info','Not applicable',out[:300] or 'This scan does not apply to this system.'); return items
    if st=='busy': add('info','Skipped',out[:300] or 'Another job was running.','Run it again later from the Scans page.'); return items
    if st=='timeout': add('warn','Timed out',f'{name} did not finish within its time limit, so the results are incomplete.','Run it again when the system is idle, or raise its time limit in /etc/locsecd/locsecd.conf.')
    if st=='not-initialized': add('warn','No baseline yet','AIDE has no baseline database to compare against.','Press "Build AIDE database" on the Scans page once; checks work from then on.'); return items
    if st=='error':
        first=next((l for l in out.splitlines() if l.strip()),'')[:300]
        add('bad','Scan failed',first or f'{name} exited with an error.',
            'Check network connectivity if the tool downloads data, then run it again. If it keeps failing, the Troubleshooting page lists the usual causes.')
        return items
    low=name.lower()
    if low.endswith(' definitions'):
        rc=r.get('rc'); what='ClamAV virus signatures' if low.startswith('clamav') else 'rkhunter data files'
        if st=='updated': add('good','Updated',f'{what}: new definitions were downloaded.')
        elif st=='up-to-date': add('good','Already up to date',f'{what}: nothing newer was available.')
        elif st=='ok': add('good','Finished',f'{what}: the update finished without an error (it did not say whether anything new was downloaded).')
        else:
            first=next((l for l in out.splitlines() if l.strip()),'')[:300]
            add('warn','Update failed',f'{what} could not be updated (exit code {rc}). {first}'.strip(),
                'Check the network connection, then press "Update virus/rootkit definitions now" again. The full output is below.')
        return items
    if low=='aide':
        fp=r.get('full_output')
        if fp and Path(fp).is_file():
            try:
                a=aide_analyze(fp); s=_aide_summary_row(a)
                add(s['lvl'],s['title'],s['text'],s.get('fix',''))
                for x in [x for x in a['records'] if x['lvl'] in ('bad','warn')][:25]:
                    add(x['lvl'],('Important file ' if x['sensitive'] else 'File ')+x['verb'],
                        x['path']+' '+x['verb']+'.'+(f' What changed: {x["what"]}.' if x['what'] else '')+(' '+x['why'] if x['why'] else ''),x['fix'])
                n=len([x for x in a['records'] if x['lvl'] in ('bad','warn')])
                if n>25: add('info','More to review',f'{n-25} more changes need review. Logs > AIDE (latest check) lists all of them.')
            except Exception as e: add('info','Summary unavailable',f'The full AIDE output could not be read: {e}')
        elif st=='ok': add('good','No changes','AIDE compared every file with its baseline and found no changes.')
        else: add('info','Full list not kept','This report is older than the full AIDE output files (kept 7 days).','Run "AIDE" on the Scans page for a fresh list with what to do.')
        return items
    if low=='lynis':
        m=re.search(r'Hardening index: (\S+)/100',out)
        if m: add('info','Hardening index',f'Lynis rated this system {m.group(1)} out of 100. Higher is better; desktops typically score 60-75.')
        sec=None
        for line in out.splitlines():
            if line.startswith('Warnings'): sec='w'; continue
            if line.startswith('Suggestions'): sec='s'; continue
            mm=re.match(r'^ - ([A-Z]+-\d+): (.*)$',line)
            if mm and sec=='w':
                pi=re.search(r'promiscuous interface\s+\[([^\]]+)\]',mm.group(2)) if mm.group(1)=='NETW-3015' else None
                try: ids_if=pi and pi.group(1) in (_ids_capture_ifaces() or [])
                except Exception: ids_if=False
                if ids_if:
                    add('info','Expected: Suricata is listening',f'{mm.group(2)} ({mm.group(1)}). Suricata captures on {pi.group(1)}, and capturing puts the interface in promiscuous mode.',
                        'No action needed while Suricata runs. If Suricata is stopped and this stays, find out which program set it: ip link')
                else: add('warn','Lynis warning',f'{mm.group(2)} ({mm.group(1)})',f'See what it means and how to fix it: sudo lynis show details {mm.group(1)}')
        ns=int(r.get('suggestions') or 0)
        if ns: add('info',f'{ns} hardening suggestions','These are recommendations, not findings. Lynis targets servers, so some do not apply to a desktop.',
                   'Read them in the full output below. For any one of them: sudo lynis show details TEST-ID')
        if not r.get('warnings') and not ns and not m: add('good','No findings','Lynis reported no warnings.')
        return items
    if low.startswith('debsecan') or 'cve' in low:
        known=r.get('known'); fixable=r.get('fixable')
        if fixable: add('warn','Security fixes pending',f'{fixable} known vulnerabilit(ies) have a fix that is not installed yet.','Press "Update system" on the Scans page. (LocSec also installs security updates by itself.)')
        if known and known!=fixable:
            add('info','Unfixed vulnerabilities',f'{(known or 0)-(fixable or 0)} known vulnerabilit(ies) in installed packages have no fix from the distribution yet.','No action possible yet. When the fix ships, LocSec installs it automatically.')
        if known==0: add('good','No known vulnerabilities','No known vulnerabilities in the installed packages.')
        if known is None:
            n=len(re.findall(r'^(?:CVE|TEMP)-\S+',out,re.M))
            if n: add('info','Vulnerabilities listed',f'This older report lists {n} known vulnerabilit(ies) without indicating which have a fix.','Run the CVE scan again for a list that separates the ones you can fix now.')
        return items
    if low=='rkhunter':
        blocks=[]; sec=None
        for line in out.splitlines():
            if line.startswith('NEEDS REVIEW'): sec='r'; continue
            if line.startswith('INFORMATIONAL'): sec='i'; continue
            if sec=='r':
                if line.startswith('Warning:'): blocks.append([line])
                elif blocks and line.strip(): blocks[-1].append(line.strip())
        for bl in blocks[:30]:
            t=' '.join(bl); add('warn','rkhunter: needs review',t.replace('Warning:','').strip()[:400],_rkh_fix(t))
        m=re.search(r'(\d+) informational',out)
        if m and int(m.group(1)): add('info','Reviewed and expected',f'{m.group(1)} warning(s) were reviewed by LocSec and are expected on this system (listed in the full output).')
        if not blocks: add('good','No rootkit found','rkhunter found nothing that needs review.')
        return items
    if low.startswith('clamav'):
        inf=[l for l in out.splitlines() if l.rstrip().endswith('FOUND')]
        for l in inf[:30]:
            path,_,sig=l.rpartition(': ')
            add('bad','Malware found',f'{path.strip()} matches {sig.replace("FOUND","").strip()}.','Open Malware / Quarantine and quarantine this file. It can be restored later if this is a false positive.')
        if not inf and st=='ok': add('good','No malware','ClamAV found no malware.')
        m=re.search(r'^Errors: (\d+)',out,re.M)
        if m and int(m.group(1)) and st!='warning': add('info','Some files unreadable',f'{m.group(1)} file(s) changed or were removed during the scan. Normal on a system in use.')
        if st=='warning': add('warn','Many files unreadable','More files than usual could not be scanned.','Run the scan again; if it repeats, restart clamav-daemon on the Services page.')
        return items
    if low=='apt security candidates':
        pk=re.findall(r'^Inst (\S+) \[',out,re.M)
        if pk: add('warn',f'{len(pk)} update(s) pending',', '.join(pk[:30])+('...' if len(pk)>30 else ''),'Press "Update system" on the Scans page. LocSec also installs security updates by itself.')
        else: add('good','Up to date','No updates are pending.')
        if 'apt autoremove' in out: add('info','Unused packages','Some installed packages are no longer required.','To remove them: sudo apt autoremove')
        return items
    if low=='listening ports':
        pub=[]
        for line in out.splitlines():
            parts=line.split()
            if len(parts)<5 or parts[0] not in ('tcp','udp'): continue
            loc=parts[4]
            if re.match(r'^(127\.|\[::1\]|::1|\[::ffff:127\.)',loc): continue
            if parts[0]=='tcp' and parts[1]!='LISTEN': continue
            prog=(re.search(r'\("([^"]+)"',line) or [None,'unknown program'])[1]
            pub.append(f'{parts[0]} {loc} ({prog})')
        if pub: add('info','Network-facing ports',f'{len(pub)} port(s) are listening on network interfaces: '+'; '.join(pub[:15]),
                    'The firewall (UFW) still blocks them unless you opened the port. If you do not use one of these programs, stop it on the Services page.')
        else: add('good','No network-facing ports','No service is listening on a network interface; every listener is bound to localhost.')
        return items
    if low=='ufw status':
        if re.search(r'Status:\s*inactive',out): add('warn','Firewall disabled','UFW is disabled.','Enable it: sudo ufw enable  (run sudo ufw allow ssh first if you administer this machine remotely).')
        elif re.search(r'Status:\s*active',out):
            n=len(re.findall(r'^\[\s*\d+\]',out,re.M))
            add('good','Firewall enabled',f'UFW is active with {n} rule(s). Incoming traffic not matched by an allow rule is denied.')
        return items
    if isinstance(r.get('changed'),list):
        add('good','Updates installed' if r['changed'] else 'Nothing to install',f'{len(r["changed"])} package(s) were updated.' if r['changed'] else 'All packages were already up to date.')
        return items
    if st in ('ok','info'): add('good','No findings',f'{name} found nothing that needs review.')
    elif st in ('warning','findings-or-error'):
        first=[l for l in out.splitlines() if l.strip()][:3]
        add('warn','Findings to review',' / '.join(first)[:400] or f'{name} reported findings.','Review the full output below.')
    return items

def _explain_report(rep):
    try:
        res=rep.get('results') if isinstance(rep,dict) else None
        if isinstance(res,list):
            for r in res:
                if isinstance(r,dict): r['explain']=explain_result(r)
        elif isinstance(rep,dict) and isinstance(rep.get('result'),dict):
            rep['result']['explain']=explain_result(rep['result'])
    except Exception as e: log(f'report explanation failed: {e}','ERROR')
    return rep

# ---------------------------------------------------------------------------
# Incidents: what happened, what LocSec did and what to do, in plain language.
# ---------------------------------------------------------------------------
_INC_NET_KINDS=('login-failure','port-scan','ids-alert','block')

def _incident_ip(rec):
    ind=str(rec.get('indicator','')).strip()
    return ind if ind and _block_target(ind) else ''

_BLOCKS_MEMO={'t':0,'b':{}}
def _is_blocked(ind):
    try:
        t=_block_target(ind)
        if time.time()-_BLOCKS_MEMO['t']>2: _BLOCKS_MEMO.update(t=time.time(),b=load_blocks())
        b=_BLOCKS_MEMO['b']
        if not t: return False
        if str(t) in b or ind in b: return True
        # An address inside a blocked range (a feed's /20, say) is blocked too.
        if isinstance(t,(ipaddress.IPv4Address,ipaddress.IPv6Address)):
            if _BLOCKS_MEMO.get('l') is None or _BLOCKS_MEMO.get('lt')!=_BLOCKS_MEMO['t']:
                _BLOCKS_MEMO.update(l=_BlockLookup(),lt=_BLOCKS_MEMO['t'])
            return _BLOCKS_MEMO['l'].match(str(t)) is not None
        return False
    except Exception: return False

def _never_blocked(ip):
    try:
        t=_block_target(ip)
        return allowed_ip(str(t)) if isinstance(t,(ipaddress.IPv4Address,ipaddress.IPv6Address)) else allowed_network(str(t))
    except Exception: return False

def incident_can_fix(rec):
    k=str(rec.get('kind','')); st=str(rec.get('state','new'))
    if st=='resolved': return False
    if k=='virus-found': return bool(rec.get('indicator')) and str(rec.get('action'))!='quarantined'
    if k=='block' and str(rec.get('action'))=='blocked':
        # The block worked. If the address is no longer blocked, someone unblocked it or the block
        # expired; "Fix it" would quietly undo that, so it is offered only to retry a failed block.
        return False
    if k in _INC_NET_KINDS:
        ip=_incident_ip(rec)
        return bool(ip) and not _is_blocked(ip) and not _never_blocked(ip)
    return False

def _incident_story(rec):
    """(level, what happened, what LocSec did, what to do)"""
    k=str(rec.get('kind','')); ind=str(rec.get('indicator','')); det=str(rec.get('detail',''))
    n=int(rec.get('count',1) or 1); times=f' It happened {n} times.' if n>1 else ''
    ip=_incident_ip(rec); where=f' ({_where(ip.split("/")[0])})' if ip else ''
    blocked=_is_blocked(ip) if ip else False
    if k=='login-failure':
        if ip and _never_blocked(ip) and not blocked:
            return ('warn',f'A login from {ip}{where} failed with an incorrect password.{times}',
                    'Recorded it. LocSec never automatically blocks devices on the local network.',
                    'If that was you, press Mark solved. If not, a device on your network is guessing passwords: identify it in your router\'s list of connected devices, and change your password with: passwd')
        if ip:
            return ('warn',f'A login from {ip}{where} failed with an incorrect password.{times}',
                    'LocSec blocked that computer.' if blocked else 'LocSec recorded it. Sources that keep failing are blocked automatically.',
                    'If that was you, no action is needed: press Mark solved.' if blocked else 'If it was not you, press "Fix it" to block that computer. If it was you, press Mark solved.')
        u=re.search(r'\buser=(\S+)',det); svc=re.search(r'pam_\w+\(([^:)]+)',det)
        place=_AUTH_SERVICE.get(svc.group(1),svc.group(1)) if svc else 'a login prompt'
        return ('info','An incorrect password was entered'+(f' for "{u.group(1)}"' if u else '')+f' at {place} on this computer (local console, not over the network).{times}',
                'No action: there is no remote address to block.',
                'If that was you mistyping, no action is needed: press Mark solved. If it was not you, someone has had access to your keyboard: lock the screen when you step away (Super+L) and change your password with: passwd')
    if k=='port-scan':
        return ('warn',f'{ind}{where} probed many different ports within a few minutes, looking for an exposed service (a port scan).{times}',
                'LocSec blocked it.' if blocked else ('LocSec recorded it. Devices on the local network are never blocked automatically.' if ip and _never_blocked(ip) else 'LocSec recorded it but did not block it (port-scan blocking may be off).'),
                'No action needed.' if blocked else ('If you recognise that device (a phone, TV or a network tool), press Mark solved. If not, identify it in your router\'s list of connected devices.' if ip and _never_blocked(ip) else 'If you do not know that device, press "Fix it" to block it. If it is your own, press Mark solved.'))
    if k=='auth-probe':
        return ('warn',f'A program on this computer sent more than {_AUTH_FAIL_MAX} wrong credentials to the LocSec dashboard within one minute.{times}',
                'LocSec answered each further attempt with an error and kept the dashboard available with the real token. The token is 256 random bits, so it cannot be guessed this way.',
                f'If you did not just mistype or run a script against the dashboard, find the program: sudo ss -tnp | grep {CFG.get("port",8765)}  and check which user started it (ps -o user,pid,cmd -p PID). Then run a rootkit check from the Scans page.')
    if k=='ids-alert':
        mm=re.match(r'(.*?) \[sid (\d+)',det); sig=(mm.group(1) if mm else det)[:160]
        dm=re.search(r'\b(inbound|outbound|transit)\b',det); way=dm.group(1) if dm else 'inbound'
        why=re.search(r'\(not blocked: ([^)]*)\)',det); sidn=mm.group(2) if mm else '?'
        if way=='outbound':
            return ('bad',f'This computer sent traffic to {ind}{where} that matches a Suricata signature for a known attack or malware: \"{sig}\".{times}',
                    'LocSec blocked that address.' if blocked else 'LocSec recorded it'+(f' (not blocked: {why.group(1)}).' if why else '.'),
                    f'Find out which program made the connection: sudo ss -tnp | grep {ind}  Then run a virus scan and a rootkit check from the Scans page. If you know it is harmless, press Mark solved, or add its rule number (sid {sidn}) to ids_ignore_sids in /etc/locsecd/locsecd.conf.')
        return ('warn',f'Traffic from {ind}{where} matches a Suricata signature for a known attack: \"{sig}\".{times}',
                'LocSec blocked that address.' if blocked else 'LocSec recorded it'+(f' (not blocked: {why.group(1)}).' if why else '.'),
                'No action needed.' if blocked else 'If you do not recognise that address, press \"Fix it\" to block it. If it is one of your own devices, press Mark solved, or add the rule number (sid '+(mm.group(2) if mm else '?')+') to ids_ignore_sids in /etc/locsecd/locsecd.conf.')
    if k=='block':
        return ('info',f'LocSec added {ind}{where} to the blocked computers. Reason: {det[:200] or "not recorded"}.',
                ('That computer cannot reach this one while the block is in effect.' if blocked else 'The block worked, but it is no longer in effect: it was lifted on Firewall & Blocks or it expired.') if str(rec.get('action'))=='blocked' else 'LocSec attempted the block but it failed: '+det[:200],
                'No action needed. If you trust that computer, unblock it on Firewall & Blocks.' if str(rec.get('action'))=='blocked' else 'Press "Fix it" to try again. If it fails again, check that UFW or nftables is working (Troubleshooting page).')
    if k=='unblock':
        return ('info',f'{ind} was removed from the blocked computers.','No further action.','No action needed.')
    if k=='virus-found':
        return ('bad',f'ClamAV detected "{det[:120]}" in the file {ind}.',
                'Moved it into quarantine.' if str(rec.get('state'))=='resolved' else 'No action yet: the file is still in place.',
                'Press "Fix it" to move the file into quarantine. It cannot be executed there, and it can be restored from Malware / Quarantine if this is a false positive.')
    if k=='rootkit-warning':
        return ('warn','rkhunter reported: '+det.split('\n')[0].replace('Warning:','').strip()[:300],
                'Recorded it. This cannot be remediated automatically.',_rkh_fix(det))
    if k=='firewall-fallback':
        return ('warn','UFW (the firewall) was disabled.','LocSec installed its own default-deny fallback firewall, so unsolicited incoming connections are still blocked.',
                'Re-enable UFW: sudo ufw enable  (run sudo ufw allow ssh first if you administer this machine remotely). LocSec removes its fallback firewall automatically.')
    if k=='log-cleared':
        return ('info',f'The log {ind} was cleared from the dashboard.','No further action.',
                'If you did this, no action is needed. If not, someone else has access to your dashboard: log out of the desktop and change your password with: passwd')
    if k=='service-action':
        return ('info',f'The service {ind} was changed from the Services page: {det[:200]}','No further action.','No action needed if that was you.')
    if k=='tool-add':
        return ('info',f'The tool {ind} was installed from the Overview page.','No further action.','No action needed.')
    return ('info',f'{k} from {rec.get("source","")}: {ind} {det[:200]}'.strip(),'Recorded it.','No action needed unless this was not you.')

def incident_explain(rec,did=None):
    lvl,happened,done,todo=_incident_story(rec)
    st=str(rec.get('state','new'))
    if st=='resolved': todo='No further action. If it recurs, LocSec opens a new incident.'
    elif st=='contained': todo='No further action. Press Mark solved once you have reviewed this.'
    return {'level':lvl,'happened':happened,'did':did or done,'todo':todo,'can_fix':incident_can_fix(rec)}


def ufw_summary(rows):
    """Top sources and most-targeted ports, for the top of the UFW view."""
    srcs={}; doors={}; stopped=allowed=0
    for r in rows:
        f=r.get('fw')
        if not f: continue
        n=int(r.get('repeat',1))
        if f['verdict']=='Blocked': stopped+=n
        elif f['verdict'].startswith('Allowed'): allowed+=n
        if f['direction']=='inbound' and f['from']:
            s=srcs.setdefault(f['from'],{'ip':f['from'],'count':0,'where':f['from_where'],'doors':set(),'listed':f['listed']})
            s['count']+=n
            if f['door']: s['doors'].add(f['door'])
        if f['door']:
            d=doors.setdefault(f['door'],{'door':f['door'],'name':f['door_name'],'count':0}); d['count']+=n
    need=int(CFG.get('scan_ports',8))
    top=sorted(srcs.values(),key=lambda x:-x['count'])[:10]
    for s in top:
        s['scanner']=len(s['doors'])>=need
        s['doors']=sorted(s['doors'])[:12]
    return {'stopped':stopped,'allowed':allowed,'sources':len(srcs),'top_sources':top,
            'top_doors':sorted(doors.values(),key=lambda x:-x['count'])[:10]}

# Which threat feed an indicator came from, in plain language. Keys are stored in
# the block record ("feed"), so the Firewall page can say who listed it and why.
_FEED_INFO={
 'spamhaus-drop':{'name':'Spamhaus DROP list','home':'https://www.spamhaus.org/blocklists/do-not-route-or-peer/',
    'why':('This address range is hijacked or leased to spammers or cybercriminals. Spamhaus lists ranges '
           'from which no legitimate traffic is expected, so all traffic to and from them should be dropped.')},
 'feodo':{'name':'abuse.ch Feodo Tracker','home':'https://feodotracker.abuse.ch/',
    'why':('This host is a botnet command-and-control (C2) server for banking malware such as Emotet, QakBot, '
           'Dridex or TrickBot. Infected machines contact it for instructions. Blocking it cuts any infection on '
           'this machine off from its operator.')},
 'urlhaus':{'name':'abuse.ch URLhaus','home':'https://urlhaus.abuse.ch/',
    'why':('This host was observed distributing malware. Blocking it prevents anything on this machine '
           'from downloading from it.')},
 'other':{'name':'a threat feed','home':'',
    'why':'This address is on a public threat-intelligence list that LocSec downloads.'},
}

def _feed_kind(url):
    u=str(url).lower()
    if 'spamhaus.org' in u and 'drop' in u: return 'spamhaus-drop'
    if 'feodotracker.abuse.ch' in u: return 'feodo'
    if 'urlhaus.abuse.ch' in u: return 'urlhaus'
    return 'other'

def explain_block(key,meta):
    """One persisted block in plain language: what it covers, why, who said so."""
    meta=meta if isinstance(meta,dict) else {}
    n=safe_network(key); src=str(meta.get('source','')); reason=str(meta.get('reason',''))
    if n is None: what=f'{key}'; size=0
    elif n.num_addresses==1: what=f'Single address: {n.network_address}'; size=1
    else:
        size=n.num_addresses
        what=(f'A range of {size:,} addresses ({n}), {n.network_address} to {n.broadcast_address}. '
              'Every address in the range is blocked.')
    addr=str(n.network_address) if (n is not None and n.num_addresses==1) else key
    out={'key':key,'address':addr,'size':size,'what':what,'source':src,'reason':reason,
         'added':meta.get('ts'),'expires':meta.get('expires'),'who':'','who_home':'','ref':'','ref_page':'','why':'','seen_at':''}
    if src=='feed':
        fk=str(meta.get('feed',''))
        info=_FEED_INFO.get(fk)
        if info:
            out.update(who=info['name'],who_home=info['home'],why=info['why'])
            ref=str(meta.get('ref',''))
            if fk=='spamhaus-drop' and re.fullmatch(r'SBL\d+',ref):
                out['ref']=ref; out['ref_page']=f'https://check.spamhaus.org/sbl/query/{ref}'
            elif fk=='feodo':
                out['ref_page']=f'https://feodotracker.abuse.ch/browse/host/{addr}/'
            elif fk=='urlhaus':
                out['ref_page']=f'https://urlhaus.abuse.ch/host/{addr}/'
                if ref: out['seen_at']=ref
            if fk=='other' and meta.get('feed_url'): out['who']=urllib.parse.urlparse(str(meta['feed_url'])).hostname or 'a threat feed'
        else:
            out.update(who='a threat feed (list not recorded yet)',
                       why='This address is on one of the public threat-intelligence lists LocSec downloads. '
                           'The next feed update (every 12 hours, or "Update feeds now" on Threat Intelligence) records which list and why.')
    elif src=='auth-monitor':
        mm=re.match(r'(\d+) failed',reason)
        out.update(who='LocSec (login monitor)',
                   why=(f'This address failed {mm.group(1) if mm else "too many"} login attempts against this machine, '
                        'so LocSec blocked it. This pattern indicates automated password guessing (brute force).'))
    elif src=='scan-monitor':
        mm=re.search(r'(\d+) different closed ports probed within (\d+) min',reason)
        out.update(who='LocSec (port-scan detection)',
                   why=(f'This address probed {mm.group(1) if mm else "many"} different closed ports within {mm.group(2) if mm else "a few"} minutes, '
                        'looking for an exposed service. Port scanning is typically the reconnaissance stage of an attack.'))
    elif src=='suricata':
        out.update(who='LocSec (Suricata intrusion detection)',
                   why=f'Suricata matched traffic between this address and this computer against a signature for a known attack or malware ({reason[:200]}). Signature blocks are short-lived, in case the source address was spoofed.')
    elif src=='manual':
        out.update(who='You',why='Blocked manually on this page'+(f' ("{reason}")' if reason and reason!='manual dashboard block' else '')+'.')
    elif src=='incident-action':
        out.update(who='You',why='Blocked with Fix it on an incident about this address.')
    else:
        out.update(who=src or 'unknown',why=reason or 'No reason was recorded.')
    return out

# Programs whose failed logins count towards automatic blocking. Only these accept logins
# from the network; a wrong password typed at this computer has no address to block.
_AUTH_NET_PROGRAMS={'sshd','sshd-session','sshd-auth'}

def _sshd_uids():
    uids={0}
    try:
        import pwd
        for name in ('sshd','_sshd'):
            try: uids.add(pwd.getpwnam(name).pw_uid)
            except KeyError: pass
    except ImportError: pass
    return uids

def _auth_trusted(comm,uid):
    """True when journald says the record came from sshd itself. _COMM and _UID are
    added by journald from the sending process and cannot be set by it, unlike the
    SYSLOG_IDENTIFIER that "logger -t sshd" or any program can choose."""
    try: return str(comm) in _AUTH_NET_PROGRAMS and int(uid) in _sshd_uids()
    except (TypeError,ValueError): return False

def auth_lines():
    """Recent auth/authpriv records as {'line','trusted'}. 'trusted' is True only for records
    journald attributes to sshd; the auth.log fallback cannot tell, so it is trusted as before."""
    window=max(60,min(86400,int(CFG.get('auth_window',900))))
    seen=set(); out=[]; journal_ok=False
    if have('journalctl'):
        # 200 KB tail: on a noisy host the generic cap could cover only seconds of the
        # auth window. --facility needs journalctl >= 245; older ones fall back to the
        # whole journal for the window.
        base=['journalctl','--no-pager','--since',f'{window} seconds ago','-o','json','-n','20000',
              '--output-fields=MESSAGE,SYSLOG_IDENTIFIER,SYSLOG_PID,_COMM,_PID,_UID,_HOSTNAME']
        rc,s=run(base+['--facility=auth','--facility=authpriv'],30,tail=2000000)
        if rc!=0: rc,s=run(base,30,tail=2000000)
        if rc==0:
            journal_ok=True
            for raw in s.splitlines():
                try: e=json.loads(raw)
                except Exception: continue
                msg=e.get('MESSAGE','')
                if not isinstance(msg,str): continue      # binary payloads come as byte arrays
                try: ts=datetime.fromtimestamp(int(e.get('__REALTIME_TIMESTAMP','0'))/1e6).astimezone().isoformat(timespec='seconds')
                except Exception: ts=''
                ident=str(e.get('SYSLOG_IDENTIFIER') or e.get('_COMM') or '')[:64]
                pid=str(e.get('_PID') or e.get('SYSLOG_PID') or '')[:16]
                line=f"{ts} {e.get('_HOSTNAME','')} {ident}{f'[{pid}]' if pid else ''}: {msg[:4000]}"
                if line in seen: continue
                seen.add(line); out.append({'line':line,'msg':msg[:4000],'trusted':_auth_trusted(e.get('_COMM'),e.get('_UID'))})
    # /var/log/auth.log only on a system without a usable journal. While the journal
    # works it is the only source: auth.log is written by rsyslog from whatever any
    # program sends (logger -t sshd), and an empty journal window is normal.
    if not journal_ok and _pexists('/var/log/auth.log'):
        s='\n'.join(_tail_lines('/var/log/auth.log',2000,200000))
        cutoff=time.time()-window
        for line in s.splitlines():
            if line in seen: continue
            ts,prog,msg=_split_syslog(line)
            if ts is None or ts<cutoff: continue
            seen.add(line)
            out.append({'line':line,'msg':msg,'trusted':prog.split('/')[-1] in _AUTH_NET_PROGRAMS})
    return out

def _load_seen(path, limit=20000):
    # An insertion-ordered dict, used as an ordered set: membership is O(1) and
    # the order is the order things were seen. The previous version kept a plain
    # set and trimmed with sorted(), which evicts the lexicographically smallest
    # hashes -- effectively at random -- so an event already handled could fall
    # out of the window and be reported a second time while newer markers stayed.
    try:
        data=json.loads(path.read_text())
        return dict.fromkeys(data[-limit:]) if isinstance(data,list) else {}
    except Exception:
        return {}

def _remember_seen(path, seen, limit=20000):
    try:
        atomic_json(path,list(seen)[-limit:])
    except Exception:
        pass

# The sshd records that carry a remote address, each matched whole from start to end.
# A user name, a client's disconnect reason or a banner can contain "ADDRESS port N",
# but it can never make one of these match with the attacker's text in the address
# group: the user name is the greedy group, and the line must end exactly where sshd
# ends it. Anything else (Received disconnect, banners, PAM errors) yields no address.
_P=r'(?: \[preauth\])?$'
_SSHD_ADDR=[re.compile(x) for x in (
    r'^Failed \S+ for (?:invalid user )?(?P<user>.*) from (?P<addr>\S+) port \d+ ssh2'+_P,
    r'^Invalid user (?P<user>.*) from (?P<addr>\S+) port \d+'+_P,
    r'^(?:Connection closed by|Disconnected from) (?:invalid |authenticating )?user (?P<user>.*) (?P<addr>\S+) port \d+'+_P,
    r'^Disconnecting (?:invalid |authenticating )?user (?P<user>.*) (?P<addr>\S+) port \d+: Too many authentication failures'+_P,
    r'^maximum authentication attempts exceeded for (?:invalid user )?(?P<user>.*) from (?P<addr>\S+) port \d+ ssh2'+_P,
    r'^Accepted \S+ for (?P<user>.*) from (?P<addr>\S+) port \d+ ssh2(?:: \S+ \S+)?$',
)]
# PAM writes rhost= before user=, and sshd always fills rhost in, so the first one is real.
_PAM_SSHD=re.compile(r'^pam_\w+\(sshd:auth\): authentication failure;.*? rhost=(?P<addr>\S*)(?:\s+user=(?P<user>.*))?$')

def _auth_parse(msg):
    for rx in _SSHD_ADDR:
        m=rx.match(msg)
        if m: return m.group('user'),m.group('addr')
    m=_PAM_SSHD.match(msg)
    if m: return (m.group('user') or ''),m.group('addr')
    return '',''

def _auth_ip(msg):
    """The remote address of an sshd record, or '' when the record is not one of the
    known sshd formats (see _SSHD_ADDR)."""
    _,cand=_auth_parse(msg)
    a=safe_ip(cand.strip('[]')) if cand else None
    return str(a) if a is not None else ''

# The sshd records that are an attempt in their own right. One wrong password also writes a
# PAM "authentication failure" line and, at the end, "Connection closed by invalid user ...":
# counting those as well made 2 or 3 mistypes reach auth_threshold, and "got the password
# wrong 7 times" on Firewall & Blocks really meant 2 or 3 tries.
_SSHD_ATTEMPT=re.compile(r'^(?:Failed \S+ for |Invalid user |maximum authentication attempts exceeded )')

def _auth_details(line):
    """(user, address) for display and counting."""
    user,_=_auth_parse(line); ip=_auth_ip(line)
    if not user:
        m=re.search(r'\buser=(\S+)',line); user=m.group(1) if m else ''
    return user[:128],ip

def record_auth_events(raw_events):
    # log_auth_each_attempt=false keeps the per-attempt lines out of locsecd.log
    # (they are still in the system journal); detection, counting and automatic
    # blocking are unaffected -- those run off parse_auth() in login_monitor().
    if not CFG.get('log_auth_each_attempt',True): return
    seen=_load_seen(AUTHSEEN); changed=False
    for ev in raw_events:
        line=str(ev.get('line',''))[:2000]
        msg=str(ev.get('msg',line))[:2000]
        if not line: continue
        kind=str(ev.get('kind','auth-failure'))
        marker=hashlib.sha256(f'{kind}|{line}'.encode(errors='replace')).hexdigest()
        if marker in seen: continue
        seen[marker]=None; changed=True
        user,ip=_auth_details(msg)
        if not ev.get('trusted',True): ip=''      # not written by sshd: its "from" is not evidence
        # A user name is chosen by whoever connects; keep it to one token so it
        # cannot add a second "from=" to this line.
        user=re.sub(r'[\s=]+','_',user)
        who=f' user={user}' if user else ''
        src=f' from={ip}' if ip else ''
        if kind=='auth-success':
            log(f'successful authentication{who}{src}','INFO')
        else:
            log(f'denied authentication attempt{who}{src}','WARN')
    if changed: _remember_seen(AUTHSEEN,seen)

def parse_auth():
    """Failed-login counts per remote address (for automatic blocking), successes, and
    raw records. Only records journald attributes to sshd are counted: a local user can
    write "Failed password ... from 8.8.8.8" to the auth log with logger, and must not be
    able to make LocSec block an address of their choosing."""
    fail={}; success=[]; raw=[]
    rx=re.compile(r'(?i)(?:failed|failure|invalid user|authentication failure)')
    okrx=re.compile(r'(?i)(?:accepted|session opened)')
    for rec in auth_lines():
        line=rec['line']; msg=rec['msg']
        if rx.search(msg):
            user,ip=_auth_details(msg)
            if ip and rec['trusted'] and _SSHD_ATTEMPT.match(msg): fail[ip]=fail.get(ip,0)+1
            raw.append({'kind':'auth-failure','line':line,'msg':msg,'trusted':rec['trusted']})
        if okrx.search(msg):
            user,ip=_auth_details(msg)
            success.append({'user':user,'ip':ip if rec['trusted'] else '','line':line})
            raw.append({'kind':'auth-success','line':line,'msg':msg,'trusted':rec['trusted']})
    return fail,success,raw


def journal_events():
    """Read only newly arrived security-relevant journal records."""
    if not have('journalctl'):
        return []
    since='-2 minutes'; prev=0.0
    try:
        if JOURNALSTATE.exists():
            state=json.loads(JOURNALSTATE.read_text())
            ts=float(state.get('ts',0))
            if ts>0:
                # Never more than 15 minutes back: after a long stop or a clock jump the
                # backlog could take longer to print than the 45 s allowed, and the same,
                # growing backlog was asked for again every minute from then on.
                prev=max(ts,time.time()-900)
                since=datetime.fromtimestamp(max(0,prev-2),timezone.utc).isoformat()
    except Exception:
        pass
    # -o json emits every field of every record (~900 bytes each), so run()'s
    # default 20 KB tail held only ~22 records per 60s poll: on any busy host the
    # rest of the window was discarded before it was ever examined, and the cursor
    # below then advanced past them for good. Ask for only the two fields used here
    # (journalctl always adds the mandatory __REALTIME_TIMESTAMP alongside) and keep
    # a 400 KB tail, the same reasoning as auth_lines(). --output-fields needs
    # systemd >= 236; fall back to the unfiltered form rather than returning nothing.
    cmd=['journalctl','--no-pager','-o','json','--output-fields=MESSAGE,_SYSTEMD_UNIT,_TRANSPORT,_COMM,_UID','--since',since]
    rc,out=run(cmd,45,tail=400000)
    if rc!=0 and rc!=124:
        rc,out=run(['journalctl','--no-pager','-o','json','--since',since],45,tail=400000)
    if rc!=0:
        if rc==124:
            # Too much to read in time: skip ahead rather than retrying the same window.
            atomic_json(JOURNALSTATE,{'ts':time.time()-60})
            log('journal monitor: reading the journal timed out; skipped ahead to the last minute','WARN')
        return []
    events=[]; denials=[]; newest=0.0
    for line in out.splitlines():
        try: e=json.loads(line)
        except Exception: continue
        try: rts=float(e.get('__REALTIME_TIMESTAMP','0'))/1000000.0
        except Exception: rts=0.0
        newest=max(newest,min(rts,time.time()))
        # The window starts 2s before the last record seen, so the tail of the
        # previous poll comes back again. Those records were already handled;
        # counting them twice inflated every failed-login incident near a poll.
        if prev and rts and rts<=prev: continue
        msg=e.get('MESSAGE','')
        if not isinstance(msg,str): continue
        msg=msg[:2000]
        unit=str(e.get('_SYSTEMD_UNIT',''))[:128]
        trusted=_auth_trusted(e.get('_COMM'),e.get('_UID'))
        if _FW_DENY_RX.search(msg):
            # Only the kernel writes real firewall drops. Anything else carrying the
            # prefix was written by a program (logger, a user) and is not a packet.
            if e.get('_TRANSPORT')!='kernel' or not _FW_LINE_RX.match(msg): continue
            # Firewall drops arrive in bursts (a single scan is hundreds), so
            # they are kept apart and capped on their own; mixed into the list
            # below they pushed failed logins out of its 500-record window.
            denials.append({'ts':rts or newest or time.time(),'unit':unit,'message':msg})
        elif re.search(r'(?i)(failed password|authentication failure|invalid user|accepted password|accepted publickey|sudo:|port.?scan|blocked|denied|connection refused|failed to connect|connect failed|connection timed out|connection denied)',msg):
            events.append({'ts':rts or newest or time.time(),'unit':unit,'message':msg,'trusted':trusted})
    if newest:
        atomic_json(JOURNALSTATE,{'ts':newest})
    return denials[-5000:]+events[-500:]

# Kernel log lines for dropped packets: UFW's "[UFW BLOCK]" and the fallback
# firewall's own prefix. Either one is the packet-level record that a port scan
# leaves behind.
_FW_DENY_RX=re.compile(r'\[(?:UFW BLOCK|LOCSEC BLOCK)\]')
# The whole netfilter LOG layout, from the first character. A kernel message that only
# quotes the prefix (a crashing program named "[UFW BLOCK] IN=...": its name is at most
# 15 bytes, then "[pid]: segfault") cannot match.
_FW_LINE_RX=re.compile(r'^\[(?:UFW|LOCSEC) [A-Z ]+\] IN=\S* OUT=\S* (?:MAC=\S* )?SRC=\S+ DST=\S+ ')
_LOCAL_HW_RX=re.compile(r'(?i)\bFuEngine\b|\bfwupd\b|\bMKHI\b|BootGuard')

def _network_event_details(msg):
    src=''; dst=''; proto=''; dpt=''; spt=''
    m=re.search(r'(?i)SRC=([^\s]+)',msg); src=m.group(1) if m else ''
    m=re.search(r'(?i)DST=([^\s]+)',msg); dst=m.group(1) if m else ''
    m=re.search(r'(?i)PROTO=([^\s]+)',msg); proto=m.group(1) if m else ''
    m=re.search(r'(?i)DPT=(\d+)',msg); dpt=m.group(1) if m else ''
    m=re.search(r'(?i)SPT=(\d+)',msg); spt=m.group(1) if m else ''
    return src,dst,proto,spt,dpt

def record_network_events(events):
    if not (CFG.get('log_network_denials',True) or CFG.get('log_app_connection_failures',True)): return
    seen=_load_seen(SECURITYSEEN); changed=False; denied_logged=0; denied_skipped=0
    for e in events:
        msg=str(e.get('message',''))[:2000]
        if not msg: continue
        lower=msg.lower()
        is_ufw=(('ufw block' in lower) or ('locsec block' in lower) or ('kernel:' in lower and '[ufw' in lower) or (' [ufw ' in lower)) and ('dpt=' in lower or 'src=' in lower)
        is_portscan=('port scan' in lower or 'portscan' in lower)
        is_connfail=bool(re.search(r'(?i)(connection refused|connect(?:ion)?(?: to)? .* failed|failed to connect|connect\(\).*failed|connection timed out|connection denied|connect failed)',msg))
        # fwupd talking to the computer's own chips (Intel ME "MKHI", BootGuard) is not a
        # program failing to reach the network; it filled the diary on every boot.
        if is_connfail and _LOCAL_HW_RX.search(msg+' '+str(e.get('unit',''))): is_connfail=False
        if is_ufw and CFG.get('log_network_denials',True): kind='network-denied'
        elif is_portscan and CFG.get('log_network_denials',True): kind='port-probe'
        elif is_connfail and CFG.get('log_app_connection_failures',True): kind='application-connection-failure'
        else: continue
        marker=hashlib.sha256(f'{kind}|{e.get("ts",0)}|{msg}'.encode(errors='replace')).hexdigest()
        if marker in seen: continue
        seen[marker]=None; changed=True
        if kind=='network-denied':
            # One line per dropped packet would put a whole scan in the log.
            if denied_logged>=50: denied_skipped+=1; continue
            denied_logged+=1
        src,dst,proto,spt,dpt=_network_event_details(msg)
        details=[]
        if src: details.append(f'src={src}')
        if dst: details.append(f'dst={dst}')
        if proto: details.append(f'proto={proto}')
        if spt: details.append(f'sport={spt}')
        if dpt: details.append(f'dport={dpt}')
        suffix=(' '+' '.join(details)) if details else ''
        level='WARN' if kind!='application-connection-failure' else 'INFO'
        log(f'{kind}{suffix}: {msg}',level)
    if denied_skipped: log(f'network-denied: {denied_skipped} more dropped packets this minute were not logged one by one','WARN')
    if changed: _remember_seen(SECURITYSEEN,seen)

def monitor_journal():
    events=journal_events()
    record_network_events(events)
    try: detect_port_scans(events)
    except Exception as e: log(f'port-scan detection: {e}','ERROR')
    for e in events:
        msg=e['message']
        failed=bool(re.search(r'(?i)(failed password|authentication failure|invalid user)',msg))
        if not failed: continue
        # Every address in the line used to become an incident, including one typed
        # into the user name. Only the sshd record's own remote address counts, and
        # only when journald attributes the record to sshd.
        ip=_auth_ip(msg) if e.get('trusted') else ''
        if ip and not _SSHD_ATTEMPT.match(msg): continue    # the PAM or disconnect line of the same try
        incident('login-failure','journal',ip,'medium','denied',msg)
    return len(events)


# Port-scan detection (replaces PortSentry). PortSentry opened decoy ports and
# reacted to connections on them; this reads the firewall's own record of
# dropped packets instead, so nothing new listens on the network. A source that
# sends new-connection packets to scan_ports different closed ports within
# scan_window seconds is blocked like any other automatic block: allowlisted
# (LAN) addresses and this machine's DNS servers and gateways are only
# recorded, never blocked.
_SCAN_TRACK={}    # source -> {"TCP/22": last seen}
_SCAN_FLAGGED={}  # source -> when it was last acted on
_SCAN_MAX_SOURCES=4096
_SCAN_MAX_PORTS=256
_SCAN_BLOCKS=[]   # when each automatic scan block was made, for the hourly cap

def _established_peers():
    """Remote addresses this machine currently has an established TCP connection with."""
    peers=set()
    if not have('ss'): return peers
    rc,out=run(['ss','-Hnt','state','established'],10)
    if rc!=0: return peers
    for line in out.splitlines():
        parts=line.split()
        if len(parts)<4: continue
        a=safe_ip(parts[3].rsplit(':',1)[0].strip('[]').split('%')[0])
        if a is not None and a.version==6 and a.ipv4_mapped: a=a.ipv4_mapped
        if a is not None: peers.add(str(a))
    return peers

def detect_port_scans(events):
    if not CFG.get('scan_detect',True): return
    now=time.time(); window=int(CFG['scan_window']); need=int(CFG['scan_ports'])
    for e in events:
        msg=str(e.get('message',''))
        if not _FW_DENY_RX.search(msg): continue
        # Inbound only: UFW also logs blocked outgoing packets (OUT=<iface>).
        if not re.search(r'\bIN=\S',msg) or re.search(r'\bOUT=\S',msg): continue
        src,dst,proto,_,dpt=_network_event_details(msg)
        proto=proto.upper()
        if not dpt or proto not in ('TCP','UDP'): continue
        # TCP: count connection attempts only. A late ACK/RST from a server this
        # machine talked to earlier is not a probe.
        if proto=='TCP' and (not re.search(r'\bSYN\b',msg) or re.search(r'\bACK\b',msg)): continue
        a=safe_ip(src); d=safe_ip(dst)
        if a is None or a.is_loopback or a.is_multicast or a.is_unspecified: continue
        if d is not None and (d.is_multicast or str(d)=='255.255.255.255'): continue
        key=str(a); ports=_SCAN_TRACK.get(key)
        if ports is None:
            if len(_SCAN_TRACK)>=_SCAN_MAX_SOURCES:
                # Evict the source seen longest ago rather than ignoring newcomers,
                # so a flood of forged single-packet sources cannot blind the detector.
                _SCAN_TRACK.pop(min(_SCAN_TRACK,key=lambda k:max(_SCAN_TRACK[k].values(),default=0)),None)
            ports=_SCAN_TRACK[key]={}
        pk=f'{proto}/{dpt}'
        if pk in ports or len(ports)<_SCAN_MAX_PORTS:
            try: ports[pk]=float(e.get('ts') or now)
            except Exception: ports[pk]=now
    cutoff=now-window
    for k in [k for k,t in _SCAN_FLAGGED.items() if now-t>=3600]: _SCAN_FLAGGED.pop(k,None)
    for key in list(_SCAN_TRACK):
        ports={p:t for p,t in _SCAN_TRACK[key].items() if t>=cutoff}
        if not ports: _SCAN_TRACK.pop(key,None); continue
        _SCAN_TRACK[key]=ports
        if len(ports)<need or key in _SCAN_FLAGGED: continue
        _SCAN_FLAGGED[key]=now
        a=safe_ip(key)
        sample=', '.join(sorted(ports,key=ports.get)[:20])+(', ...' if len(ports)>20 else '')
        detail=f'{len(ports)} different closed ports probed within {max(1,window//60)} min: {sample}'
        lan=allowed_ip(key) or (a is not None and a.is_link_local)
        skip=''
        _SCAN_BLOCKS[:]=[t for t in _SCAN_BLOCKS if now-t<3600]
        if lan: skip='allowlisted or local-network address'
        elif key in _established_peers(): skip='this machine has an open connection with that address, so the probe may be forged'
        elif len(_SCAN_BLOCKS)>=int(CFG['scan_block_max_per_hour']): skip=f'already {len(_SCAN_BLOCKS)} scan blocks this hour (a forged scan could otherwise lock out many addresses)'
        elif not (CFG.get('auto_block') and CFG.get('response_scan_block',True)): skip='automatic port-scan blocking is off'
        if not skip:
            ok,why=block_ip(key,'port scan: '+detail,'scan-monitor',ttl=int(CFG['scan_block_hours'])*3600)
            if ok:
                _SCAN_BLOCKS.append(now)
                log(f'port scan from {key}: {detail}; blocked for {int(CFG["scan_block_hours"])} h','WARN'); continue
            if why.startswith('already blocked'): continue
            skip=why
        detail+=f' (not blocked: {skip})'
        incident('port-scan','scan-monitor',key,'medium' if lan else 'high','detected',detail)
        log(f'port scan from {key}: {detail}','WARN')

# ---------------------------------------------------------------------------
# Network intrusion signatures (Suricata). Suricata is a separate
# package that inspects packets against signature rules. It runs as its own
# service in detection mode (it never drops traffic itself) and writes what it
# matches to eve.json. LocSec only READS that file, so a Suricata problem can
# never cut this machine off the network, and LocSec adds no listening port.
# An alert becomes an "ids-alert" incident; a high-severity one may also block
# the remote address, through the same block_ip() as every other automatic block
# (allowlist, DNS/gateway protection, block cap and expiry all apply).
# ---------------------------------------------------------------------------
_IDS={'inode':None,'pos':0,'head':b'','seen':0,'last_alert':0.0,'blocks':[],'logged':{},'dropped':0}
_IDS_MAX_READ=64*1024*1024     # bytes of eve.json read per cycle
_IDS_MAX_LINE=1024*1024        # a longer "line" is garbage and is skipped
_IDS_MAX_ALERTS=2000           # alerts looked at per cycle
_IDS_MAX_KEYS=500              # distinct (address, rule) pairs acted on per cycle
_LOCAL_ADDRS={'ts':0.0,'addrs':frozenset()}
_IDS_RULES_BUSY=threading.Lock()
_IDS_RULES_STAMP=STATE/'ids-rules-updated'
_IDS_SETUP={'checked':0.0,'last_run':0.0,'manual':None}
_IDS_SETUP_HELPER='/usr/lib/locsecd/locsec-suricata-setup'

def _ids_clean(t,n=160):
    return re.sub(r'[\x00-\x1f\x7f]+',' ',str(t)).strip()[:n]

def _local_addrs():
    """This machine's own addresses, so an alert can be told apart as inbound or outbound."""
    now=time.time()
    if now-_LOCAL_ADDRS['ts']<60: return _LOCAL_ADDRS['addrs']
    addrs=set()
    rc,out=run(['ip','-o','addr','show'],10)
    if rc==0:
        for line in out.splitlines():
            m=re.search(r'\binet6?\s+([0-9a-fA-F:.]+)/\d+',line)
            a=safe_ip(m.group(1)) if m else None
            if a is not None: addrs.add(a)
    if not any(not a.is_loopback for a in addrs):
        # "ip" failed or saw only loopback: read the kernel's own tables (no netlink needed).
        try:
            prev=''
            for line in Path('/proc/net/fib_trie').read_text().splitlines():
                if '/32 host LOCAL' in line:
                    a=safe_ip(prev.strip().lstrip('|-').strip())
                    if a is not None: addrs.add(a)
                prev=line
        except OSError: pass
        try:
            for line in Path('/proc/net/if_inet6').read_text().splitlines():
                h=line.split()[0] if line.split() else ''
                if len(h)==32:
                    a=safe_ip(':'.join(h[i:i+4] for i in range(0,32,4)))
                    if a is not None: addrs.add(a)
        except OSError: pass
        if not _LOCAL_ADDRS.get('warned'):
            _LOCAL_ADDRS['warned']=True
            log(f'"ip -o addr show" gave no address (rc={rc}: {str(out).strip()[:160]}); using /proc/net instead','WARN')
    if addrs or not _LOCAL_ADDRS['addrs']: _LOCAL_ADDRS.update(ts=now,addrs=frozenset(addrs))
    else: _LOCAL_ADDRS['ts']=now
    return _LOCAL_ADDRS['addrs']

def _ids_read_alerts():
    """New alert records appended to eve.json since the last call. The first call starts at the end of the
    file, so a restart never replays old history. A rotated file (new inode), an emptied one, or one emptied
    and refilled past the old position (its first bytes, which hold a timestamp, changed) is read from its start."""
    path=Path(str(CFG.get('ids_eve_path')))
    out=[]; total=0; deadline=time.time()+10; tail=b''
    try:
        with _priv_open(path) as fh:
            st=os.fstat(fh.fileno())
            if not stat.S_ISREG(st.st_mode): return []
            head=fh.read(64)
            if _IDS['inode']!=st.st_ino:
                first=_IDS['inode'] is None
                _IDS['inode']=st.st_ino; _IDS['pos']=st.st_size if first else 0
            elif st.st_size<_IDS['pos'] or (len(_IDS['head'])==64 and head[:64]!=_IDS['head']):
                _IDS['pos']=0
            _IDS['head']=head
            fh.seek(_IDS['pos'])
            while time.time()<deadline and total<_IDS_MAX_READ:
                chunk=fh.read(1<<20)
                if not chunk: break
                total+=len(chunk)
                lines=(tail+chunk).split(b'\n'); new_tail=lines.pop()
                _IDS['pos']+=len(tail)+len(chunk)-len(new_tail)
                tail=new_tail
                if len(tail)>_IDS_MAX_LINE:
                    _IDS['pos']+=len(tail); tail=b''
                for line in lines:
                    # eve.json also holds dns, http, flow and stats records; only alerts matter here.
                    if b'"alert"' not in line: continue
                    try: rec=json.loads(line)
                    except ValueError: continue
                    al=rec.get('alert') if isinstance(rec,dict) else None
                    if not isinstance(al,dict) or rec.get('event_type')!='alert': continue
                    if len(out)>=_IDS_MAX_ALERTS: _IDS['dropped']+=1; continue
                    out.append((rec,al))
    except FileNotFoundError:
        _IDS['inode']=None; _IDS['head']=b''
    except OSError as e:
        log(f'suricata alert log unreadable: {e}','WARN')
    return out

_EVE_TYPE=re.compile(rb'"event_type"\s*:\s*"([a-z_]{1,24})"')

def _ids_eve_path():
    return str(CFG.get('ids_eve_path') or DEFAULTS['ids_eve_path'])

def ids_recent_alerts(limit=200,max_bytes=32<<20):
    """The newest alert records in eve.json, oldest first, plus counts of what else the scanned part held.
    The file is read backwards in 1 MB steps and at most max_bytes are examined, so a multi-gigabyte eve.json
    costs the same as a small one. Returns (raw_lines, stats)."""
    path=_ids_eve_path()
    stats={'path':path,'exists':False,'size':0,'mtime':None,'scanned':0,'records':0,'alerts':0,'types':{},'complete':False}
    found=[]
    try:
        fh=_priv_open(path)
    except OSError:
        return [],stats
    with fh:
        st=os.fstat(fh.fileno())
        if not stat.S_ISREG(st.st_mode): return [],stats
        stats.update(exists=True,size=st.st_size,mtime=st.st_mtime)
        pos=st.st_size; carry=b''; types={}
        while pos>0 and stats['scanned']<max_bytes and len(found)<limit:
            step=min(1<<20,pos); pos-=step
            fh.seek(pos); chunk=fh.read(step); stats['scanned']+=len(chunk)
            buf=chunk+carry
            lines=buf.split(b'\n')
            carry=lines.pop(0) if pos>0 else b''
            if len(carry)>_IDS_MAX_LINE: carry=b''
            for line in reversed(lines):
                if not line.strip(): continue
                stats['records']+=1
                m=_EVE_TYPE.search(line[:400]) or _EVE_TYPE.search(line)
                t=m.group(1).decode() if m else 'other'
                types[t]=types.get(t,0)+1
                if t=='alert' and len(found)<limit and len(line)<=_IDS_MAX_LINE:
                    found.append(line.decode('utf-8','replace'))
        stats['complete']=pos==0
        stats['alerts']=types.get('alert',0)
        stats['types']=dict(sorted(types.items(),key=lambda kv:-kv[1])[:12])
    found.reverse()
    return found,stats

def _ids_alert_fields(line):
    """A parsed eve.json alert as a flat dict, or None."""
    try: rec=json.loads(line)
    except ValueError: return None
    if not isinstance(rec,dict) or rec.get('event_type')!='alert' or not isinstance(rec.get('alert'),dict): return None
    al=rec['alert']; local=_local_addrs()
    src=safe_ip(rec.get('src_ip')); dst=safe_ip(rec.get('dest_ip'))
    try: sev=int(al.get('severity',3))
    except (TypeError,ValueError): sev=3
    try: sid=int(al.get('signature_id',0))
    except (TypeError,ValueError): sid=0
    if src is not None and src in local: direction='outbound'
    elif dst is not None and dst in local: direction='inbound'
    else: direction='transit'
    sp=rec.get('src_port'); dp=rec.get('dest_port')
    return {'ts':_iso_ts(rec.get('timestamp')),'tstr':_ids_clean(rec.get('timestamp',''),40),'sev':sev,'sid':sid,
            'sig':_ids_clean(al.get('signature','unknown')),'cat':_ids_clean(al.get('category',''),80),
            'action':_ids_clean(al.get('action',''),12),'proto':_ids_clean(rec.get('proto',''),8).upper(),
            'src':str(src) if src else _ids_clean(rec.get('src_ip',''),45),'dst':str(dst) if dst else _ids_clean(rec.get('dest_ip',''),45),
            'sport':sp if isinstance(sp,int) else None,'dport':dp if isinstance(dp,int) else None,'direction':direction,
            'ignored':sid in set(CFG.get('ids_ignore_sids',[]))}

def _iso_ts(v):
    if not isinstance(v,str) or len(v)>40: return None
    try:
        v=re.sub(r'([+-]\d\d)(\d\d)$',r'\1:\2',v)
        return datetime.fromisoformat(v).timestamp()
    except ValueError: return None

_IDS_SEV_WORD={1:'high',2:'medium',3:'low'}
def _suricata_explain(line):
    line=line.strip()
    if line.startswith('{'):
        a=_ids_alert_fields(line)
        if a is None: return None
        remote=a['dst'] if a['direction']=='outbound' else a['src']
        flow=f"{a['src']}{':'+str(a['sport']) if a['sport'] is not None else ''} -> {a['dst']}{':'+str(a['dport']) if a['dport'] is not None else ''}"
        lvl={1:'bad',2:'warn'}.get(a['sev'],'info')
        if a['direction']=='outbound':
            what=f'This computer contacted {remote}, and the traffic matched a known-threat signature.'
        elif a['direction']=='inbound':
            what=f'Traffic from {remote} to this computer matched a known-threat signature.'
        else:
            what='Traffic passing through this machine (not addressed to it) matched a known-threat signature.'
        text=(f"{a['sig']}. {what} Category: {a['cat'] or 'none given'}; severity {a['sev']} ({_IDS_SEV_WORD.get(a['sev'],'low')}); "
              f"rule {a['sid']}; {a['proto'] or '?'} {flow}.")
        if a['ignored']: text+=' This rule number is in ids_ignore_sids, so LocSec ignores it.'
        elif a['sev']<=int(CFG.get('ids_incident_severity',2)): text+=' Alerts at this severity are recorded as incidents when LocSec is running (see Incidents).'
        else: text+=' This is below the incident level (ids_incident_severity), so it is listed here only.'
        r=_row(a['ts'],lvl,'Suricata alert',text,line)
        if a['ts'] is None: r['tstr']=a['tstr']
        return r
    # fast.log: 10/04/2026-12:00:00.123456  [**] [1:2010935:3] ET SCAN ... [**] [Classification: ...] [Priority: 2] {TCP} 1.2.3.4:5 -> 6.7.8.9:22
    m=re.match(r'(\d\d/\d\d/\d{4}-\d\d:\d\d:\d\d)\S*\s+\[\*\*\]\s+\[\d+:(\d+):\d+\]\s+(.*?)\s+\[\*\*\](?:\s+\[Classification:\s*([^\]]*)\])?\s+\[Priority:\s*(\d)\]\s+\{(\w+)\}\s+(.*)',line)
    if m:
        try: ts=datetime.strptime(m.group(1),'%m/%d/%Y-%H:%M:%S').timestamp()
        except ValueError: ts=None
        sev=int(m.group(5))
        return _row(ts,{1:'bad',2:'warn'}.get(sev,'info'),'Suricata alert',
                    f'{m.group(3)}. Category: {m.group(4) or "none given"}; severity {sev}; rule {m.group(2)}; {m.group(6)} {m.group(7)[:200]}.',line)
    return _row(None,'info','Suricata note',line[:500],line)

def _suricata_engine_explain(line):
    # suricata.log: "[1234] 4/10/2026 -- 12:00:00 - (suricata.c:1234) <Notice> (main) -- message"
    # newer:        "[1234 - Suricata-Main] 2026-10-04 12:00:00 Notice: suricata: message"
    m=re.search(r'<(Emergency|Alert|Critical|Error|Warning|Notice|Info|Perf|Config|Debug)>.*?--\s*(.*)$',line) or \
      re.search(r'\b(Emergency|Alert|Critical|Error|Warning|Notice|Info|Perf|Config|Debug):\s*(?:[\w-]+:\s*)?(.*)$',line)
    ts=None
    t=re.search(r'(\d{4}-\d\d-\d\d[ T]\d\d:\d\d:\d\d)',line) or re.search(r'(\d{1,2}/\d{1,2}/\d{4}) -- (\d\d:\d\d:\d\d)',line)
    if t:
        try:
            ts=(datetime.fromisoformat(t.group(1).replace('T',' ')) if t.lastindex==1
                else datetime.strptime(t.group(1)+' '+t.group(2),'%d/%m/%Y %H:%M:%S')).timestamp()
        except ValueError: ts=None
    if not m:
        ts2,_prog,msg=_split_syslog(line)
        return _row(ts or ts2,'info','Suricata note',(msg or line)[:500],line)
    level,msg=m.group(1),m.group(2).strip()[:500]
    low=msg.lower()
    if level in ('Emergency','Alert','Critical','Error'):
        return _row(ts,'bad','Suricata error',msg,line)
    if level=='Warning':
        if 'no rule files' in low or 'no rules loaded' in low or '0 rules' in low:
            return _row(ts,'bad','Suricata error',msg+' -- with no rules Suricata cannot match anything.',line)
        return _row(ts,'warn','Warning',msg,line)
    if re.search(r'all \d+ packet processing threads|engine started',low):
        return _row(ts,'good','Suricata started',msg,line)
    if re.search(r'rules successfully loaded|signatures processed',low):
        return _row(ts,'good','Rules loaded',msg,line)
    if 'signal received' in low or 'stopping engine' in low:
        return _row(ts,'info','Suricata stopping',msg,line)
    return _row(ts,'info','Suricata note',msg,line)

def ids_overview(limit=50):
    """Everything the Threat Intelligence page shows about Suricata."""
    st=ids_status()
    lines,stats=ids_recent_alerts(limit=max(limit,200))
    alerts=[a for a in (_ids_alert_fields(l) for l in lines) if a]
    by_sev={'1':0,'2':0,'3':0}
    for a in alerts: by_sev[str(min(max(a['sev'],1),3))]+=1
    now=time.time()
    day=[a for a in alerts if a['ts'] and now-a['ts']<86400]
    sigs={}
    for a in alerts:
        e=sigs.setdefault(a['sid'],{'sid':a['sid'],'sig':a['sig'],'cat':a['cat'],'sev':a['sev'],'n':0,'last':0})
        e['n']+=1; e['last']=max(e['last'],a['ts'] or 0)
    st.update(capture_ifaces=_ids_capture_ifaces(),route_iface=_ids_default_iface(),eve=stats,
              recent=list(reversed(alerts))[:limit],by_severity=by_sev,alerts_24h=len(day),
              top_signatures=sorted(sigs.values(),key=lambda e:-e['n'])[:10],
              incident_severity=int(CFG.get('ids_incident_severity',2)),block_severity=int(CFG.get('ids_block_severity',1)),
              block_hours=int(CFG.get('ids_block_hours',24)),
              why_empty=_ids_why_empty(st,stats,alerts))
    try:
        st['rules_count']=sum(1 for l in open('/var/lib/suricata/rules/suricata.rules','rb') if l[:1] not in (b'#',b'\n'))
    except OSError: st['rules_count']=None
    return st

def _ids_why_empty(st,stats,alerts):
    if alerts: return ''
    if not st.get('installed'): return 'Suricata is not installed, so there is nothing to show. Install it with: sudo apt install suricata suricata-update, then run: sudo locsecctl suricata-setup'
    if st.get('state')=='stopped': return 'Suricata is installed but not running, so it writes nothing. Start it with: sudo locsecctl suricata-setup'
    if not stats.get('exists'): return f'Suricata has not created {stats["path"]} yet. It appears a few seconds after Suricata starts with eve-log output enabled (the default in suricata.yaml).'
    other=sum(n for t,n in stats.get('types',{}).items() if t!='alert')
    scope='the whole file' if stats.get('complete') else f'the newest {stats["scanned"]//(1<<20)} MB'
    msg=(f'No alerts in {scope} of {stats["path"]}. It holds {other:,} other records '
         f'({", ".join(f"{t} {n:,}" for t,n in list(stats.get("types",{}).items())[:5]) or "none"}): Suricata logs every connection, DNS lookup and '
         f'TLS handshake it sees, and writes an alert only when traffic matches an attack signature. On a home or office network that is rare, '
         f'so an empty alert list is the normal, healthy result.')
    if st.get('hint'): msg+=' '+st['hint']
    elif not stats.get('types'): msg+=' The file is empty, which usually means Suricata is watching an interface that carries no traffic.'
    return msg

def ids_monitor():
    if not CFG.get('ids_enabled',True): return
    alerts=_ids_read_alerts()
    if not alerts: return
    local=_local_addrs(); now=time.time()
    ignore=set(CFG.get('ids_ignore_sids',[])); agg={}
    for rec,al in alerts:
        try: sev=int(al.get('severity',3)); sid=int(al.get('signature_id',0))
        except (TypeError,ValueError): continue
        if sid in ignore: continue
        _IDS['seen']+=1; _IDS['last_alert']=now
        if sev>int(CFG['ids_incident_severity']): continue
        src=safe_ip(rec.get('src_ip')); dst=safe_ip(rec.get('dest_ip'))
        if src is None or dst is None: continue
        if src in local and dst in local: continue
        if src in local: remote,direction=dst,'outbound'
        elif dst in local: remote,direction=src,'inbound'
        else: remote,direction=src,'transit'
        if remote.is_loopback or remote.is_multicast or remote.is_unspecified: continue
        key=(str(remote),sid); e=agg.get(key)
        if e is None:
            if len(agg)>=_IDS_MAX_KEYS: continue
            sp=rec.get('src_port'); dp=rec.get('dest_port')
            agg[key]=e={'n':0,'sev':sev,'direction':direction,'proto':_ids_clean(rec.get('proto',''),8).upper(),
                        'sig':_ids_clean(al.get('signature','unknown')),'cat':_ids_clean(al.get('category',''),60),
                        'flow':f'{src}:{sp if isinstance(sp,int) else "-"} -> {dst}:{dp if isinstance(dp,int) else "-"}'}
        e['n']+=1; e['sev']=min(e['sev'],sev)
    if _IDS['dropped']:
        log(f'suricata: {_IDS["dropped"]} alert(s) skipped, more than {_IDS_MAX_ALERTS} in one minute','WARN'); _IDS['dropped']=0
    _IDS['blocks'][:]=[t for t in _IDS['blocks'] if now-t<3600]
    for k in [k for k,t in _IDS['logged'].items() if now-t>=3600]: _IDS['logged'].pop(k,None)
    for (ip,sid),e in agg.items():
        sev=e['sev']; skip=''
        # A remote address is only blocked when it is certainly the real sender: any outbound alert (this
        # machine started that conversation), or inbound TCP, which needs a completed handshake. Inbound UDP
        # can be forged, so it is only recorded; blocking it would let an attacker lock out any address they like.
        if not (CFG.get('auto_block') and CFG.get('ids_response_block',True)): skip='automatic intrusion-signature blocking is off'
        elif sev>int(CFG['ids_block_severity']): skip=f'severity {sev} is above the blocking level'
        elif e['direction']=='transit': skip='the traffic only passed through this machine'
        elif e['direction']=='inbound' and e['proto']!='TCP': skip='inbound UDP and other packets can be forged'
        elif len(_IDS['blocks'])>=int(CFG['ids_block_max_per_hour']): skip=f'already {len(_IDS["blocks"])} signature blocks this hour'
        detail=f'{e["sig"]} [sid {sid}, {e["cat"] or "no category"}] {e["direction"]} {e["proto"] or "?"} {e["flow"]}; {e["n"]} alert(s)'
        if not skip:
            ok,why=block_ip(ip,f'intrusion signature: {e["sig"]} (sid {sid}, {e["direction"]})','suricata',
                            ttl=int(CFG['ids_block_hours'])*3600)
            if ok: _IDS['blocks'].append(now)
            elif not why.startswith('already blocked'): skip=why
        if skip: detail+=f' (not blocked: {skip})'
        incident('ids-alert','suricata',ip,{1:'high',2:'medium'}.get(sev,'low'),'detected' if skip else 'blocked',detail)
        if (ip,sid) not in _IDS['logged']:
            _IDS['logged'][(ip,sid)]=now
            log(f'intrusion signature, {ip}: {detail}','WARN')

def _ids_default_iface():
    rc,out=run(['ip','-o','route','show','default'],10)
    m=re.search(r'\bdev\s+(\S+)',out) if rc==0 else None
    return m.group(1) if m else ''

def _ids_capture_ifaces():
    """The interfaces named under af-packet in suricata.yaml (the first one is the one Suricata captures on)."""
    try:
        with _priv_open('/etc/suricata/suricata.yaml') as fh: text=fh.read().decode('utf-8','replace')
    except OSError: return []
    m=re.search(r'^af-packet:\s*\n((?:[ \t-].*\n|[ \t]*\n|#.*\n)*)',text,re.M)
    if not m: return []
    # "- interface: default" is Suricata's block of default settings, not an interface it captures on.
    return [x.strip('"\'') for x in re.findall(r'^\s*-\s*interface:\s*(\S+)',m.group(1),re.M) if x.strip('"\'')!='default']

def _ids_config_hint():
    """Suricata watches only the interface named under af-packet in suricata.yaml, and the package default
    (eth0) is wrong on most modern machines, where it is named enp3s0, wlp2s0 and the like."""
    ifaces=set(_ids_capture_ifaces())
    want=_ids_default_iface()
    if want and ifaces and want not in ifaces:
        if CFG.get('ids_auto_configure',True) and not _IDS_SETUP.get('manual'):
            return (f'Suricata is set to watch {", ".join(sorted(ifaces))}, but this machine reaches the network through {want}. '
                    f'LocSec is switching it over automatically; this note goes away within a few minutes.')
        return (f'Suricata is set to watch {", ".join(sorted(ifaces))}, but this machine reaches the network through {want}. '
                f'Run: sudo locsecctl suricata-setup')
    return ''

def ids_status():
    st={'enabled':bool(CFG.get('ids_enabled',True)),'installed':have('suricata'),'alerts_seen':_IDS['seen'],
        'last_alert':_IDS['last_alert'] or None,'blocks_this_hour':len(_IDS['blocks']),'hint':'','rules_updated':None}
    if not st['installed']:
        st.update(state='absent',state_text='not installed'); return st
    rc,out=run(['systemctl','is-active','suricata'],10)
    running=rc==0 and out.strip()=='active'
    try: age=time.time()-_pstat(str(CFG.get('ids_eve_path'))).st_mtime
    except OSError: age=None
    try: st['rules_updated']=_pstat('/var/lib/suricata/rules/suricata.rules').st_mtime
    except OSError: pass
    if not st['enabled']: st.update(state='off',state_text='installed, but LocSec is not reading its alerts (ids_enabled is off)')
    elif not running: st.update(state='stopped',state_text='installed, not running',hint='Start it with: sudo locsecctl suricata-setup (sets the interface, downloads rules and starts it)')
    elif age is None: st.update(state='nolog',state_text='running, but no alert log yet')
    elif age>180: st.update(state='stalled',state_text='running, but its log has not been written for over 3 minutes')
    else: st.update(state='monitoring',state_text='watching the network')
    if st['state'] in ('monitoring','nolog','stalled'): st['hint']=_ids_config_hint()
    if st['state']=='monitoring' and not st['rules_updated']:
        st['hint']=st['hint'] or 'No rules are installed yet, so nothing can match. LocSec downloads them after each threat-feed update; to do it now run: sudo locsecctl suricata-setup'
    return st

def ids_rules_update():
    """Download fresh Suricata rules (suricata-update) in the background. Called after each threat-feed update."""
    if not CFG.get('ids_enabled',True) or not CFG.get('ids_rules_update',True): return
    if not (have('suricata') and have('suricata-update')): return
    # The scheduler runs this after every threat-feed update, and the first one comes seconds after the service
    # starts, so every restart made Suricata reload its ~50,000 rules (about 40 s of CPU). Remember the last
    # successful update on disk and skip until ids_rules_min_hours have passed.
    try: last=float(_IDS_RULES_STAMP.read_text().strip())
    except (OSError,ValueError): last=0.0
    if time.time()-last<float(CFG.get('ids_rules_min_hours',6))*3600: return
    def job():
        if not _IDS_RULES_BUSY.acquire(blocking=False): return
        try:
            if CFG.get('ids_auto_configure',True) and os.path.exists(_IDS_SETUP_HELPER):
                # The helper runs suricata-update, makes sure suricata.yaml loads what it wrote, and has a running
                # Suricata reload the new rules (suricata-update alone leaves the old ones loaded until a restart).
                rc,out=broker('job.ids',op='rules')
            else:
                rc,out=broker('job.suricata_update')
                if rc==0: broker('svc.fixed',op='suricata.reload')
            last=_ids_clean((out or '').strip().splitlines()[-1] if (out or '').strip() else '',200)
            if rc==0:
                log('suricata rules updated'+(f': {last}' if last else ''))
                try: _IDS_RULES_STAMP.write_text(f'{time.time():.0f}\n')
                except OSError as e: log(f'could not record the suricata rule update time: {e}','WARN')
            else: log(f'suricata rule update failed (rc={rc}): {last}','WARN')
        except Exception as e: log(f'suricata rule update: {e}','ERROR')
        finally: _IDS_RULES_BUSY.release()
    threading.Thread(target=job,daemon=True,name='ids-rules').start()

def ids_auto_interface():
    """Every 5 minutes: if Suricata captures on an interface other than the one the default route uses (the package
    default eth0, or a laptop that moved from Wi-Fi to a cable), have locsec-suricata-setup switch it. The helper
    refuses to replace an interface an administrator picked; that answer is remembered until the route changes."""
    now=time.time()
    if now-_IDS_SETUP['checked']<300: return
    _IDS_SETUP['checked']=now
    if not (CFG.get('ids_enabled',True) and CFG.get('ids_auto_configure',True)): return
    if not (have('suricata') and os.path.exists(_IDS_SETUP_HELPER)): return
    ifaces=_ids_capture_ifaces(); want=_ids_default_iface()
    if not ifaces or not want or ifaces[0]==want:
        _IDS_SETUP['manual']=None; return
    if _IDS_SETUP['manual']==(ifaces[0],want): return
    if now-_IDS_SETUP['last_run']<1800: return
    if not _IDS_RULES_BUSY.acquire(blocking=False): return
    _IDS_SETUP['last_run']=now
    def job():
        try:
            rc,out=broker('job.ids',op='interface')
            text=_ids_clean(' '.join((out or '').split()),400)
            if 'set by hand' in (out or ''):
                _IDS_SETUP['manual']=(ifaces[0],want)
                log(f'suricata: capture interface {ifaces[0]} was set by hand; not switching it to {want}')
            elif rc==0: log(f'suricata interface check: {text}')
            else: log(f'suricata interface update failed (rc={rc}): {text}','WARN')
        except Exception as e: log(f'suricata interface update: {e}','ERROR')
        finally: _IDS_RULES_BUSY.release()
    threading.Thread(target=job,daemon=True,name='ids-setup').start()

def network_connections():
    if not have('ss'): return []
    rc,out=broker('net.sockets',view='connections',timeout=30)
    if rc!=0: return []
    rows=[]
    for line in out.splitlines()[:1000]:
        parts=line.split()
        if len(parts)>=5:
            rows.append({'proto':parts[0], 'state':parts[1], 'local':parts[4] if len(parts)>4 else '', 'peer':parts[5] if len(parts)>5 else ''})
    return rows

def login_monitor():
    fails,success,raw=parse_auth(); record_auth_events(raw)
    for ip,n in fails.items():
        # Its old failures stay in the auth window for up to auth_window seconds after the
        # block; calling block_ip again each minute added one to the block incident's count.
        if _is_blocked(ip): continue
        if n>=int(CFG['auth_threshold']) and CFG.get('auto_block') and CFG.get('response_auth_block',True) and not allowed_ip(ip):
            block_ip(ip,f'{n} failed authentication events','auth-monitor')
    return {'failed':fails,'successful':success[:100]}

def feed_update():
    prune_expired_blocks()
    urls=CFG.get('feed_urls',[]); hits=0; domains=set(); networks=set(); errors=[]
    # A URL feed (URLhaus and friends) carries hundreds of thousands of entries.
    # Without a ceiling the sets, the JSON on disk and every later read of it grow
    # with whatever the feed publishes that day; the daemon runs under MemoryMax=2G.
    max_ind=200000; capped=False
    # Where each address came from (which list, plus the list's own reference:
    # a Spamhaus SBL number, or the URLhaus download address it was seen
    # serving). Only used to explain blocks; first list to name it wins.
    origin={}
    for url in urls:
        fkind=_feed_kind(url)
        try:
            if urllib.parse.urlparse(str(url)).scheme!='https':
                raise ValueError('feed URL must use HTTPS')
            req=urllib.request.Request(str(url),headers={'User-Agent':f'locsecd/{VERSION}'})
            with _FEED_OPENER.open(req,timeout=30) as r:
                # A total deadline, not just a per-read one: a server dripping a
                # byte every few seconds would otherwise hold the job lock for hours.
                buf=bytearray(); deadline=time.time()+120
                while len(buf)<=MAX_FEED_BYTES:
                    if time.time()>deadline: raise TimeoutError('feed download took longer than 120 seconds')
                    chunk=r.read(65536)
                    if not chunk: break
                    buf+=chunk
                data=bytes(buf)
            if len(data)>MAX_FEED_BYTES: raise ValueError('feed exceeds size limit')
            text=data.decode('utf-8','replace')
            for line in text.splitlines():
                line=line.strip()
                if not line or line.startswith('#'): continue
                # Handle CIDRs (e.g. Spamhaus DROP), single IPs, and URLs/domains.
                for token in re.findall(r'(?<![\w:.])(?:\d{1,3}\.){3}\d{1,3}(?:/\d{1,2})?(?![\w.])',line):
                    n=safe_network(token)
                    if n and n.version==4 and len(networks)<max_ind:
                        networks.add(str(n))
                        if str(n) not in origin:
                            ref=''
                            if fkind=='spamhaus-drop':
                                sm=re.search(r';\s*(SBL\d+)',line); ref=sm.group(1) if sm else ''
                            elif fkind=='urlhaus' and '://' in line:
                                ref=line.split()[0][:300]
                            origin[str(n)]=(fkind,ref,str(url)[:300])
                for token in re.findall(r'https?://[^\s]+',line):
                    try:
                        host=urllib.parse.urlparse(token.rstrip('.,;')).hostname
                        if host and re.fullmatch(r'[A-Za-z0-9.-]{1,253}',host) and len(domains)<max_ind: domains.add(host.lower().rstrip('.'))
                    except Exception: pass
                plain=line.split()[0] if line.split() else ''
                if re.fullmatch(r'[A-Za-z0-9.-]{1,253}',plain) and '.' in plain and safe_ip(plain) is None and len(domains)<max_ind: domains.add(plain.lower().rstrip('.'))
                if len(domains)>=max_ind or len(networks)>=max_ind:
                    capped=True; break
            hits+=1
        except Exception as e:
            errors.append(f'{url}: {e}'); log(f'feed update failed {url}: {e}','ERROR')
    # One pass, one ipaddress object per entry: the previous two comprehensions
    # parsed every indicator twice more just to split hosts from networks.
    single=[]; nets=[]
    for x in networks:
        nw=safe_network(x)
        if not nw: continue
        (single if nw.prefixlen==32 else nets).append(str(nw))
    single.sort(); nets.sort()
    if capped:
        errors.append(f'indicator list truncated at {max_ind} entries per category; raise nothing and it stays bounded, the newest feed contents are kept')
    if urls and not hits:
        # Every source failed (no network or DNS yet, typically right after boot).
        # Writing the empty result here used to replace the whole indicator
        # database with nothing, so reputation checks matched nothing until the
        # next successful run 12 hours later. Keep the last good copy, and record
        # the failed attempt beside it.
        try: prev=json.loads(FEEDS.read_text())
        except Exception: prev={}
        if not isinstance(prev,dict): prev={}
        prev.update({'interval_seconds':int(CFG.get('feed_interval',900)),'sources':urls,'errors':errors,
                     'last_attempt':time.time(),'last_attempt_ok':False})
        for k in ('domains','ips','networks'):
            if not isinstance(prev.get(k),list): prev[k]=[]
        atomic_json(FEEDS,prev)
        log(f'threat feed update: every source failed; kept the previous indicators '
            f'({len(prev["ips"])} IPs, {len(prev["networks"])} networks, {len(prev["domains"])} domains)','WARN')
        return {'sources_ok':0,'domains':len(prev['domains']),'ips':len(prev['ips']),'networks':len(prev['networks']),
                'blocked':0,'already_blocked':0,'errors':errors,'kept_previous':True}
    now=time.time()
    data={'updated':now,'last_attempt':now,'last_attempt_ok':True,'interval_seconds':int(CFG.get('feed_interval',900)),'sources':urls,
          'domains':sorted(domains),'ips':single,'networks':nets,'errors':errors}
    atomic_json(FEEDS,data)
    blocked=0; skipped_already_blocked=0
    if CFG.get('feed_auto_block') and CFG.get('auto_block') and CFG.get('response_feed_block',True):
        limit=max(0,min(2000,int(CFG.get('feed_auto_block_limit',500))))
        indicators=data['ips']+data['networks']
        max_prefix=max(0,min(32,int(CFG.get('max_auto_block_prefix',8))))
        # Skip indicators already persisted from a prior cycle: re-running ufw/nft
        # for the same ~500 already-blocked entries every feed_interval was costing
        # minutes of held JOB_LOCK for no effect (feed order is stable, so it's
        # usually the exact same set every time).
        already=set(load_blocks().keys())
        for target in indicators[:limit]:
            n=safe_network(target)
            if n and n.prefixlen < max_prefix: continue
            # block_ip keys a single address without /32 (_block_target), so compare that form too.
            key=str(_block_target(target) or target)
            if key in already or str(n or target) in already or target in already:
                skipped_already_blocked+=1; continue
            fk,ref,furl=origin.get(target) or origin.get(key) or ('other','','')
            label=_FEED_INFO.get(fk,_FEED_INFO['other'])['name']
            if block_ip(target,f'threat-intelligence feed: {label}'+(f' ({ref})' if ref and fk=='spamhaus-drop' else ''),'feed',
                        record_incident=False,extra={'feed':fk,'ref':ref,'feed_url':furl})[0]: blocked+=1
    # Feed blocks made before 4.0.11-65 (or by an earlier run) recorded only
    # "threat-intelligence feed". Fill in which list named them and why, so the
    # Firewall page can explain every one. Metadata only: expiry is untouched.
    try:
        with LOCK:
            cur=load_blocks(); changed=0
            onorm={str(_block_target(k) or k):v for k,v in origin.items()}
            for key,meta in cur.items():
                if not isinstance(meta,dict) or meta.get('source')!='feed': continue
                o=origin.get(key) or onorm.get(key)
                if not o: continue
                fk,ref,furl=o
                if meta.get('feed')!=fk or (ref and meta.get('ref')!=ref):
                    meta['feed']=fk; meta['ref']=ref; meta['feed_url']=furl
                    label=_FEED_INFO.get(fk,_FEED_INFO['other'])['name']
                    meta['reason']=f'threat-intelligence feed: {label}'+(f' ({ref})' if ref and fk=='spamhaus-drop' else '')
                    changed+=1
            if changed: atomic_json(BLOCKS,cur)
        if changed: log(f'threat feed: recorded which list named {changed} existing feed block(s)')
    except Exception as e: log(f'threat feed: could not annotate existing blocks: {e}','ERROR')
    # skipped_already_blocked used to be counted and then dropped, so a feed
    # run that blocked nothing reported blocked=0 with no way to tell whether
    # the feed was empty, everything was filtered out, or -- the usual case --
    # it had all been blocked on a previous cycle already.
    # A successful run used to log nothing, so the log showed only failures and
    # an old failure read as the current state.
    log(f'threat feed update: {hits}/{len(urls)} source(s) reached; {len(data["ips"])} IPs, {len(data["networks"])} networks, '
        f'{len(domains)} domains; {blocked} newly blocked, {skipped_already_blocked} already blocked'
        +(f'; {len(errors)} error(s)' if errors else ''),'INFO' if not errors else 'WARN')
    return {'sources_ok':hits,'domains':len(domains),'ips':len(data['ips']),'networks':len(data['networks']),
            'blocked':blocked,'already_blocked':skipped_already_blocked,'errors':errors}

# A false-positive ClamAV hit moving a live system binary out from under a
# running system is worse than the malware it's meant to catch. Require an
# explicit override to quarantine anything under these trees.
_SYSTEM_PATHS=('/bin','/sbin','/usr/bin','/usr/sbin','/usr/lib','/usr/lib64','/usr/libexec','/lib','/lib64','/etc','/boot',
               '/usr/local/bin','/usr/local/sbin','/usr/local/lib')

QUAR_HELPER='/usr/lib/locsecd/locsec-quarantine'
_QUAR_ID_RE=re.compile(r'^[0-9a-f]{16}$')
QUAR_LOCK=threading.Lock()

def _quarantine_helper(verb,**args):
    """Run the privileged quarantine helper in a sibling transient unit (the daemon itself
    is sandboxed read-only for /home and has no CAP_DAC_OVERRIDE/CAP_CHOWN) and return its
    JSON result. verb is job.quarantine or job.quarantine_restore."""
    h=Path(QUAR_HELPER)
    if not h.is_file() or h.is_symlink(): return {'ok':False,'error':'quarantine helper is missing; reinstall locsecd'}
    with QUAR_LOCK:
        rc,out=broker(verb,**args)
    try: res=json.loads(out.strip().splitlines()[-1]) if out.strip() else None
    except Exception: res=None
    if not isinstance(res,dict): return {'ok':False,'rc':rc,'error':'quarantine helper returned no valid result','output':str(out)[-2000:]}
    if rc!=0 and res.get('ok') is True: res['ok']=False
    return res

def _incident_mark(ident,state,note):
    try:
        with LOCK:
            _inc_load(); rec=_inc_find(str(ident)[:64])
            if not rec: return
            rec['state']=state; rec['updated']=time.time(); rec['note']=str(note)[:1000]; _inc_store(rec)
        _action_log(rec['id'],state,str(note)[:200],str(note)[:1000])
    except Exception as e: log(f'incident update after quarantine failed: {e}','ERROR')

# Never quarantined, even with force (4.0.11-91). Since the dashboard runs unprivileged, "force" is something
# a compromised dashboard could ask for too; these are the files whose loss locks every user out, stops the
# machine from booting, or disables LocSec. A genuine malware sample is not one of them.
_NEVER_QUARANTINE={'/etc/passwd','/etc/shadow','/etc/group','/etc/gshadow','/etc/sudoers','/etc/fstab','/etc/crypttab',
                   '/etc/nsswitch.conf','/etc/ld.so.cache','/etc/ld.so.conf','/etc/hosts','/etc/resolv.conf',
                   '/usr/bin/sudo','/usr/bin/su','/usr/bin/pkexec','/usr/bin/login','/usr/sbin/sshd','/usr/bin/bash','/usr/bin/dash',
                   '/usr/bin/sh','/usr/bin/systemctl','/usr/bin/python3','/usr/sbin/nft','/usr/sbin/ufw','/usr/sbin/iptables'}
_NEVER_QUARANTINE_DIRS=('/boot','/etc/pam.d','/etc/security','/etc/sudoers.d','/etc/ssh','/etc/systemd','/etc/locsecd',
                        '/usr/lib/systemd','/lib/systemd','/usr/lib/locsecd','/etc/ufw','/usr/lib/x86_64-linux-gnu/security',
                        '/lib/x86_64-linux-gnu/security','/usr/lib/security','/lib/security',
                        '/usr/libexec/sudo','/usr/lib/sudo','/usr/lib/openssh','/usr/libexec/openssh','/usr/lib/polkit-1')
_NEVER_QUARANTINE_NAMES=re.compile(r'(?:ld-linux[^/]*\.so[^/]*|libc\.so[^/]*|libpam\.so[^/]*|libsystemd\.so[^/]*|libcrypt\.so[^/]*|python3(?:\.\d+)?)')

def _never_quarantine(p):
    if p in _NEVER_QUARANTINE: return True
    if any(p==d or p.startswith(d+os.sep) for d in _NEVER_QUARANTINE_DIRS): return True
    return p.startswith(('/usr/','/lib')) and bool(_NEVER_QUARANTINE_NAMES.fullmatch(os.path.basename(p)))

@_root_side('quarantine.file','scan one file with ClamAV and move it into the root-only vault if it is flagged (or anyway); '
            'never a symbolic link, never under a system directory unless forced',
            local=('incident_id',),
            after=lambda r,a:(_incident_mark(a['incident_id'],'resolved',
                f'File quarantined ({r.get("signature","")}); it can be restored or deleted from Malware / Quarantine.')
                if isinstance(r,dict) and r.get('ok') and a.get('incident_id') else None),
            path=_A(_vtext(4096)),force=_A(_vb,False),anyway=_A(_vb,False),signature=_A(_vtext(300),''))
def quarantine_file(path,force=False,anyway=False,signature='',incident_id=''):
    """Move a file into the quarantine vault with its original location recorded so it can
    be restored. Without `signature` the file is scanned first and only quarantined if
    ClamAV flags it; `anyway` quarantines a file ClamAV does not flag."""
    raw=Path(path)
    if not raw.is_absolute(): return {'ok':False,'error':'path must be absolute'}
    # Resolve the directory only: a symlink is never followed, so quarantining one can
    # never move or delete the file it points at.
    src=raw.parent.resolve()/raw.name
    if src.is_symlink(): return {'ok':False,'error':f'{src} is a symbolic link; quarantine the file it points to instead'}
    if not src.is_file(): return {'ok':False,'error':'file not found'}
    if str(src).startswith(str(QUAR.resolve())+os.sep): return {'ok':False,'error':'file already quarantined'}
    if not force and any(str(src)==p or str(src).startswith(p+os.sep) for p in _SYSTEM_PATHS):
        return {'ok':False,'error':f'{src} is under a system directory; quarantining it could break the system. Pass force=true to override.'}
    if _never_quarantine(str(src)):
        return {'ok':False,'error':f'{src} is never quarantined from the dashboard, even when forced: without it nobody can log in, '
                                  'the machine may not boot, or LocSec stops working. Deal with it by hand if it really is malicious.'}
    sig=str(signature or '').strip()[:300]
    if not sig:
        if not have('clamscan'): return {'ok':False,'error':'clamscan not installed'}
        rc,out=broker('scan.clamscan_file',path=str(src))
        log(f'quarantine scan {src}: rc={rc}')
        if rc==1:
            for line in str(out).splitlines():
                if line.rstrip().endswith('FOUND'):
                    sig=line.rstrip()[:-5].rpartition(': ')[2].strip(); break
            sig=sig or 'detected'
        elif rc==0:
            if not anyway:
                return {'ok':False,'clean':True,'rc':0,'error':'ClamAV found nothing in this file, so it was not quarantined. Tick "Quarantine even if clean" to quarantine it anyway.'}
            sig='Manually quarantined (no detection)'
        else:
            return {'ok':False,'rc':rc,'error':'ClamAV could not scan this file','output':out}
    res=_quarantine_helper('job.quarantine',path=str(src),signature=sig)
    log(f'quarantine {src}: ok={res.get("ok")} {res.get("error","")}','WARN' if res.get('ok') else 'ERROR')
    if isinstance(res,dict): res.setdefault('signature',sig)
    return res

@_root_side('quarantine.list','the items in the quarantine vault',refused=lambda m:{'items':[],'error':m})
def list_quarantine():
    items=[]
    try: entries=sorted(QUAR.iterdir())
    except OSError: return {'items':[]}
    ids=set()
    for m in entries:
        if m.suffix!='.json' or not _QUAR_ID_RE.match(m.stem) or m.is_symlink(): continue
        try: rec=json.loads(m.read_text())
        except Exception: continue
        data=QUAR/(m.stem+'.qf')
        ids.add(m.stem)
        items.append({'id':m.stem,'original_path':str(rec.get('original_path','')),'signature':str(rec.get('signature','')),
                      'size':int(rec.get('size',0)),'quarantined_at':rec.get('quarantined_at'),
                      'restorable':data.is_file() and not data.is_symlink()})
    for f in entries:
        # Path('<id>.json.tmp').stem is '<id>.json', so the id test never matched a
        # half-written metadata file and it was listed as an un-restorable item.
        if f.suffix=='.tmp': continue
        if f.suffix=='.json' and _QUAR_ID_RE.match(f.stem): continue
        if f.suffix=='.qf' and f.stem in ids: continue
        try:
            if f.is_symlink() or not f.is_file(): continue
            st=f.stat()
        except OSError: continue
        # A file with no metadata record (quarantine interrupted part-way, or a record
        # deleted by hand): listed so it can still be seen and deleted.
        items.append({'id':f.name,'original_path':'(unknown - its quarantine record is missing)','signature':'',
                      'size':st.st_size,'quarantined_at':st.st_mtime,'restorable':False})
    items.sort(key=lambda x:x.get('quarantined_at') or 0,reverse=True)
    return {'items':items}

@_root_side('quarantine.restore','put one quarantined file back where the vault recorded it came from',
            qid=_A(_vtext(64)),overwrite=_A(_vb,False))
def restore_quarantined(qid,overwrite=False):
    qid=str(qid or '')
    if not _QUAR_ID_RE.match(qid): return {'ok':False,'error':'not a quarantine item: the id must be the 16-character id shown on the Malware / Quarantine page'}
    # Nothing is ever restored to a path that could never have been quarantined (4.0.11-101): a record
    # naming one did not come from quarantine_file(), whoever put it in the vault.
    try:
        rec=json.loads((QUAR/(qid+'.json')).read_text())
        dest=os.path.normpath(str(rec.get('original_path',''))) if isinstance(rec,dict) else ''
    except (OSError,ValueError): dest=''
    if dest and _never_quarantine(dest):
        log(f'quarantine restore {qid}: refused, its record names {dest[:200]}, which is never quarantined','WARN')
        return {'ok':False,'error':f'refused: {dest} is a file LocSec never quarantines, so this record is not one it made'}
    res=_quarantine_helper('job.quarantine_restore',qid=qid,overwrite=bool(overwrite))
    log(f'quarantine restore {qid}: ok={res.get("ok")} {res.get("restored_to","") or res.get("error","")}','WARN')
    return res

@_root_side('quarantine.delete','delete one item from the quarantine vault',ident=_A(_vtext(256)))
def delete_quarantine_item(ident):
    """Permanently delete one quarantined item by id, or a stray file by name."""
    ident=str(ident or '')
    with QUAR_LOCK:
        if _QUAR_ID_RE.match(ident):
            n=0
            for suf in ('.qf','.json'):
                p=QUAR/(ident+suf)
                try:
                    if p.is_symlink() or p.is_file(): p.unlink(); n+=1
                except OSError as e: return {'ok':False,'error':str(e)}
            if not n: return {'ok':False,'error':'quarantined item not found'}
        else:
            if not ident or '/' in ident or ident in ('.','..'): return {'ok':False,'error':'invalid item'}
            p=QUAR/ident
            try:
                if not (p.is_file() or p.is_symlink()): return {'ok':False,'error':'quarantined item not found'}
                p.unlink()
            except OSError as e: return {'ok':False,'error':str(e)}
    log(f'deleted quarantined item {ident}','WARN')
    return {'ok':True}

@_root_side('quarantine.delete_all','empty the quarantine vault')
def delete_all_quarantine():
    n=0
    with QUAR_LOCK:
        try: entries=list(QUAR.iterdir())
        except OSError: entries=[]
        for p in entries:
            try:
                if p.is_symlink() or p.is_file(): p.unlink(); n+=1
            except OSError: pass
    log(f'deleted all quarantined items ({n} files)','WARN')
    return {'ok':True,'deleted':n}

_PRIVILEGED_COMMANDS={'apt-get','unattended-upgrade','freshclam'}

def run_privileged(cmd,timeout=60,input_text=None):
    if not isinstance(cmd,(list,tuple)) or not cmd or str(cmd[0]) not in _PRIVILEGED_COMMANDS:
        return 126,'refused privileged command'
    # apt-get/unattended-upgrade need to setuid/setgid down to the unprivileged
    # _apt sandbox user before fetching anything; our systemd unit deliberately
    # runs the long-lived daemon with a minimal CapabilityBoundingSet (no
    # CAP_SETUID/CAP_SETGID), and a child process can never exceed its parent's
    # bounding set even as root, so a plain subprocess call always fails that
    # step ("setgroups/setegid/seteuid ... Operation not permitted"). Same
    # workaround as aide_init(): run it in its own transient unit with the
    # full capability set instead of inheriting ours.
    # NOTE: locsecd.service also sets PrivateTmp=true, so this daemon's own
    # /tmp is a private mount namespace invisible to the transient unit that
    # systemd-run spawns (that unit is a sibling managed directly by PID 1,
    # not a child that inherits our namespace). Never pass a /tmp filepath
    # from this process into a command run via run_privileged() -- it will
    # not exist from the transient unit's point of view and will fail with
    # a confusing "no such file" instead of a permissions error. Pass data
    # via input_text (stdin) instead; --pipe below forwards it through.
    pre='locsecd-apt' if str(cmd[0]) in ('apt-get','unattended-upgrade') else 'locsecd-priv'
    rc,out=_run_transient(cmd,timeout,input_text,prefix=pre)
    if rc!=0 and 'Operation not permitted' in out:
        out+='\n(systemd-run not available to grant this command the extra capabilities it needs to sandbox itself as _apt; run it manually with sudo instead.)'
    return rc,out

def _apt_pending(phase_opt):
    # Simulate an upgrade and return [(pkg, old, new, [origins], is_security)] for packages that
    # are already installed (i.e. real upgrades), plus the raw simulation output.
    rc,out=broker('job.apt_simulate',with_new_pkgs=True,phased=bool(phase_opt))
    pending=[]
    for line in out.splitlines():
        m=re.match(r'^Inst (\S+)(?: \[([^\]]*)\])? \((\S+) (.*?)\)\s*(?:\[[^\]]*\]\s*)?$',line)
        if not m or m.group(2) is None: continue   # no "[old]" = brand-new dependency, pulled in automatically
        origins=re.sub(r'\s*\[[^\]]*\]\s*$','',m.group(4))
        olist=[o.strip() for o in origins.split(',') if o.strip()]
        pending.append((m.group(1),m.group(2),m.group(3),olist,any('security' in o.lower() for o in olist)))
    return rc,pending,out

def package_update():
    if not have('apt-get'): return {'ok':False,'output':'apt-get not found'}
    before=run(['dpkg-query','-W','-f=${binary:Package} ${Version}\n'],120,tail=8000000)[1]
    out=[]; note_parts=[]
    rc,s=broker('job.apt_update'); out.append(s)
    if rc!=0:
        # A single unreachable third-party repo (or a transient mirror error) must not stop security
        # patches from the repos that did refresh; carry on with the lists apt has.
        note_parts.append('apt-get update reported errors (see output); continuing with the package lists that are available.')
    phase_opt=['-o','APT::Get::Always-Include-Phased-Updates=true'] if CFG.get('include_phased_updates') else []
    rc_sim,pending,sim=_apt_pending(phase_opt); out.append(sim[-6000:])
    if rc_sim!=0 and not pending:
        return {'ok':False,'changed':[],'needs_reboot':Path('/var/run/reboot-required').exists(),
                'note':'Could not compute the list of pending updates; see the output.','output':'\n'.join(out)[-30000:]}
    # Origin policy is decided HERE from apt's own metadata instead of unattended-upgrade's
    # Allowed-Origins list, which is distro-specific and on Linux Mint (whose default list names only
    # Mint's own repos) silently excludes the upstream Ubuntu security packages Mint actually runs.
    security_only=bool(CFG.get('update_security_only'))
    chosen=[p for p in pending if p[4]] if security_only else list(pending)
    held=[p for p in pending if p not in chosen]
    install_rc=0
    if chosen and CFG.get('auto_update'):
        names=[p[0] for p in chosen]
        rc_i,s=broker('job.apt_upgrade',packages=names,phased=bool(phase_opt))
        out.append(s); install_rc=rc_i
        if rc_i!=0:
            if re.search(r'Could not get lock|Unable to acquire the dpkg frontend lock|held by process',s):
                note_parts.append('Another package manager is running (Update Manager, unattended-upgrades or apt); nothing was changed. Retry when it finishes.')
            else:
                note_parts.append(f'apt-get install exited with status {rc_i}; see the output for the failing package.')
    after=run(['dpkg-query','-W','-f=${binary:Package} ${Version}\n'],120,tail=8000000)[1]
    old={line.split(' ',1)[0]:line.split(' ',1)[1] for line in before.splitlines() if ' ' in line}
    changed=[]
    for line in after.splitlines():
        if ' ' in line:
            pkg,ver=line.split(' ',1)
            if old.get(pkg)!=ver: changed.append(f'{pkg}: {old.get(pkg,"not-installed")} -> {ver}')
    needs_restart=Path('/var/run/reboot-required').exists()
    if not pending:
        note_parts.append('The system is up to date: no pending package updates.')
    elif not CFG.get('auto_update'):
        note_parts.append(f'auto_update is off: {len(chosen)} update(s) are ready ({", ".join(p[0] for p in chosen[:10])}{"..." if len(chosen)>10 else ""}) but were not applied.')
    if held:
        if security_only:
            note_parts.append(f'{len(held)} non-security update(s) were left alone because update_security_only is true ({", ".join(p[0] for p in held[:10])}{"..." if len(held)>10 else ""}). Set update_security_only to false to apply everything.')
    if not changed and pending and chosen and CFG.get('auto_update') and install_rc==0:
        # Nothing changed although apt reported candidates and did not fail: phased rollout.
        # run_privileged, not run: apt drops to the _apt sandbox user even for a
        # simulation, which this daemon's own capability set cannot allow.
        _,cand=broker('job.apt_simulate',timeout=120)
        phased=re.findall(r'deferred due to phasing.*?\n((?:^\s+\S.*\n?)*)',cand,re.M)
        phased_pkgs=[p for line in phased for p in line.split()]
        if phased_pkgs:
            note_parts.append(f'{len(phased_pkgs)} package(s) are held back by Ubuntu\'s phased rollout ({", ".join(phased_pkgs[:10])}); apt releases them to every machine within a few days. Set include_phased_updates to true to apply immediately.')
    ok = install_rc==0
    result={'ok':ok,'changed':changed,'needs_reboot':needs_restart,'note':' '.join(note_parts),'output':'\n'.join(out)[-30000:]}
    report=REPORTS/f'update-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'; atomic_json(report,{'ts':time.time(),'result':result})
    result['report']=str(report)
    log(f'package update completed; changed {len(changed)} packages; report={report}')
    # Persisted like the scan jobs, so a restart or reboot does not make the next update wait
    # a full update_interval, and a manual run restarts the timer. A failed run is not stamped.
    if ok: _mark_job_run('update')
    return result

def _scan_props(io='idle'):
    # CPU/I-O priority for scans that run in their own transient unit (where
    # a nice/ionice wrapper would just be one more thing to get wrong).
    props=[f'Nice={int(CFG.get("scan_nice",10))}']
    if io=='idle': props.append('IOSchedulingClass=idle')
    else: props+=['IOSchedulingClass=best-effort','IOSchedulingPriority=7']
    return props

def scan_tool(name,cmd,timeout=1800,transient=False,tail=20000,verb=None,vargs=None):
    if not have(cmd[0]): return {'name':name,'status':'not-installed','output':f'{cmd[0]} not found'}
    # Heavy scans are deliberately background-friendly: lower CPU priority and
    # idle I/O prevent LocSec from competing with interactive workloads.
    #
    # transient=True runs the tool in its own systemd transient unit instead of
    # inside locsecd.service's sandbox. The daemon's unit deliberately runs with
    # a minimal capability set, a read-only /etc and /usr, no /lib/modules and a
    # private mount namespace -- fine for a monitor, wrong for an auditor:
    # Lynis/apt failed to drop privileges ("setgroups ... Operation not
    # permitted"), rkhunter saw "/lib/modules is missing or empty", and AIDE
    # would read attributes under a different capability set than aideinit used
    # to build its baseline.
    if transient:
        # The privilege broker builds the command itself; cmd here only names the tool.
        rc,out=broker(verb,**(vargs or {}))
    else:
        run_cmd=list(cmd)
        if have('nice') and have('ionice'):
            run_cmd=['nice','-n',str(int(CFG.get('scan_nice',10))),'ionice','-c','3']+run_cmd
        rc,out=run(run_cmd,timeout,tail=tail)
    log(f'{name} scan completed rc={rc}')
    return {'name':name,'status':'ok' if rc==0 else 'findings-or-error','rc':rc,'output':out}


def _aide_lock(blocking=False):
    """Acquire the cross-process AIDE lock and return its open fd, or None."""
    try:
        AIDE_LOCK_PATH.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        # /run/lock is world-writable (sticky) and this runs as root: never follow a planted symlink,
        # and refuse a lock file that is not a plain file owned by root.
        fd=os.open(str(AIDE_LOCK_PATH), os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_CLOEXEC, 0o660)
        try:
            st=os.fstat(fd)
            if not stat.S_ISREG(st.st_mode) or st.st_uid!=0:
                os.close(fd)
                log(f'AIDE lock {AIDE_LOCK_PATH} is not a regular root-owned file; refusing to use it','ERROR')
                return None
        except OSError:
            os.close(fd); raise
        try:
            os.fchmod(fd,0o660)
        except Exception:
            pass
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except OSError:
            os.close(fd)
            return None
        return fd
    except Exception as e:
        log(f'AIDE lock acquisition failed: {e}','ERROR')
        return None


def _aide_unlock(fd):
    if fd is None: return
    try: fcntl.flock(fd, fcntl.LOCK_UN)
    except Exception: pass
    try: os.close(fd)
    except Exception: pass


def _aide_systemd_busy():
    if not have('systemctl'): return False
    rc,_=run(['systemctl','is-active','--quiet','dailyaidecheck.service'],10)
    return rc==0


def _aide_processes_running():
    # Defensive check for AIDE invocations which did not use our shared systemd lock.
    try:
        out=subprocess.check_output(['pgrep','-a','-f',r'(^|/)(aide|aideinit)( |$)'],text=True,stderr=subprocess.DEVNULL,timeout=5)
        return [line for line in out.splitlines() if line.strip()]
    except Exception:
        return []


def external_aide():
    """An AIDE run LocSec did not start, so the Scans page can say what is using the CPU.

    The aide package's own daily check (dailyaidecheck.service, run as _aide)
    is the usual one: LocSec's own AIDE runs always hold JOB_LOCK, so this is
    only asked when no LocSec job is running."""
    procs=[]
    for line in _aide_processes_running()[:10]:
        pid=(line.split() or [''])[0]
        user=''
        try:
            uid=int(next(l.split()[1] for l in Path(f'/proc/{pid}/status').read_text().splitlines() if l.startswith('Uid:')))
            import pwd
            user=pwd.getpwuid(uid).pw_name
        except Exception: pass
        procs.append({'pid':pid,'user':user,'cmd':line.split(None,1)[1][:200] if ' ' in line else line})
    daily=_aide_systemd_busy()
    if not procs and not daily: return None
    timer=''
    if have('systemctl'):
        _,timer=run(['systemctl','is-enabled','dailyaidecheck.timer'],10); timer=timer.strip().splitlines()[0] if timer.strip() else ''
    if daily or any(p['user']=='_aide' for p in procs):
        msg=('AIDE is running, but LocSec did not start it: this is the aide package\'s own daily check '
             '(dailyaidecheck, run as the _aide user). '+
             ('LocSec turns that daily check off when it is installed; this run was already going and will finish on its own.'
              if timer!='enabled' else
              'It is still switched on (dailyaidecheck.timer is enabled), so it runs every day on top of LocSec\'s weekly check. '
              'Turn it off with: sudo systemctl disable --now dailyaidecheck.timer'))
    else:
        msg='AIDE is running, but LocSec did not start it (started by hand or by another program).'
    return {'what':'AIDE','message':msg,'processes':procs,'daily_timer':timer}


@_root_side('aide.state','size, owner, mode and time of aide.db and aide.db.new',refused=lambda m:{'error':m})
def _aide_db_state():
    state={}
    for label,path in (('database',AIDE_DB),('new_database',AIDE_DB_NEW)):
        try:
            st=path.stat()
            state[label]={'path':str(path),'exists':True,'size':st.st_size,'mode':oct(st.st_mode & 0o777),'uid':st.st_uid,'gid':st.st_gid,'mtime':st.st_mtime}
        except FileNotFoundError:
            state[label]={'path':str(path),'exists':False}
        except Exception as e:
            state[label]={'path':str(path),'exists':False,'error':str(e)}
    return state


def _aide_preflight():
    """Acquire the shared AIDE lock and reject concurrent AIDE work."""
    fd=_aide_lock(False)
    if fd is None:
        return None, {'ok':False,'error':'another AIDE operation is already running'}
    if _aide_systemd_busy():
        _aide_unlock(fd)
        return None, {'ok':False,'error':'Debian dailyaidecheck.service is currently running; wait for it to finish before changing the AIDE baseline'}
    running=_aide_processes_running()
    if running:
        _aide_unlock(fd)
        return None, {'ok':False,'error':'another AIDE process is currently running; operation was refused','processes':running[:10]}
    return fd, None


_AIDE_PENDING_CACHE={}
@_root_side('aide.pending','whether aide.db.new is a valid file that differs from aide.db',refused=lambda m:True)
def aide_pending_differs():
    """True when aide.db.new is a valid file that is not just a copy of aide.db.

    Drives whether the dashboard shows "Accept pending AIDE baseline". The copy that
    "aideinit --force" leaves behind is identical to aide.db and is not pending.
    Any doubt (unreadable file, compare error) counts as pending, so the button
    is never hidden when there might be something to review.
    """
    try:
        if not _aide_regular_file(AIDE_DB_NEW): return False
        if not _aide_regular_file(AIDE_DB): return True
        a=AIDE_DB_NEW.stat(); b=AIDE_DB.stat()
        if a.st_size!=b.st_size: return True
        key=(a.st_size,a.st_mtime_ns,b.st_size,b.st_mtime_ns)
        if _AIDE_PENDING_CACHE.get('key')==key: return _AIDE_PENDING_CACHE['val']
        import filecmp
        val=not filecmp.cmp(str(AIDE_DB_NEW),str(AIDE_DB),shallow=False)
        _AIDE_PENDING_CACHE.update(key=key,val=val)
        return val
    except Exception:
        return True


def _aide_regular_file(path):
    try:
        st=path.stat()
        return path.is_file() and st.st_size>0 and not path.is_symlink()
    except OSError:
        return False


def _aide_timeout():
    """Single time limit for every AIDE run (check, initialize, rebuild): aide_scan_timeout."""
    try: t=int(CFG.get('aide_scan_timeout',10800))
    except (TypeError,ValueError): t=10800
    return max(300,min(259200,t))

@_root_side('aide.init','build the first AIDE baseline (aideinit --yes) under the AIDE lock; never replaces one',
            after=lambda r,a:_mark_job_run('aide') if isinstance(r,dict) and r.get('ok') and 'rc' in r else None)
def aide_init():
    """Initialize AIDE only when no baseline exists; never overwrite one silently."""
    if not have('aideinit'): return {'ok':False,'error':'aideinit not installed'}
    fd,err=_aide_preflight()
    if err: return err
    try:
        state=_aide_db_state()
        if AIDE_DB.exists():
            # A valid existing baseline means AIDE is already initialized. The old
            # implementation returned an error here, making the dashboard button
            # look broken on every already-initialized machine. Do not overwrite it.
            valid=_aide_regular_file(AIDE_DB)
            pending=_aide_regular_file(AIDE_DB_NEW)
            return {'ok':valid,'initialized':valid,'already_initialized':valid,
                    'pending_database':pending,
                    'message':('AIDE is already initialized; the existing baseline was not changed.' if valid else 'AIDE database exists but is not a valid regular non-empty file.'),
                    'database':state}
        if AIDE_DB_NEW.exists():
            return {'ok':False,'error':'AIDE has an existing pending database at aide.db.new; use Accept pending baseline after reviewing it','database':state}
        # aideinit writes to /var/log/aide and internally re-execs aide via capsh with
        # extra capabilities. The LocSec service has a deliberately narrow capability
        # bounding set, so run aideinit in a transient systemd unit with its own full
        # bounding set. The shared flock is held by this parent for the entire operation.
        rc,out=broker('job.aide_init',timeout=_aide_timeout())
        if rc!=0 and not have('systemd-run'):
            out+='\n(systemd-run not available to grant aideinit the extra capabilities it needs; run "sudo aideinit --yes" manually instead.)'
        if rc==124: out=(out+'\n' if out else '')+f'aideinit did not finish within {_aide_timeout()}s (aide_scan_timeout in /etc/locsecd/locsecd.conf). Raise the limit or exclude large trees in /etc/aide/aide.conf.d, then run it again.'
        state=_aide_db_state()
        valid=state.get('database',{}).get('exists') and state.get('database',{}).get('size',0)>0
        ok=(rc==0 and valid)
        if not ok and rc==0:
            out=(out+'\n' if out else '')+'aideinit returned success but no non-empty aide.db was produced.'
        log(f'AIDE initialization rc={rc} db_valid={valid} state={json.dumps(state,separators=(",",":"))}')
        return {'ok':ok,'rc':rc,'output':out,'database':state}
    finally:
        _aide_unlock(fd)


@_root_side('aide.accept','promote a reviewed aide.db.new to the baseline under the AIDE lock (confirm required)',
            confirm=_A(_vb,False))
def aide_accept_pending(confirm=False):
    """Explicitly promote Debian's pending AIDE database to the active baseline.

    The long-lived LocSec service deliberately has a reduced capability set. Debian's
    dailyaidecheck creates aide.db.new as _aide, so chmod/chown cannot safely be done
    in that constrained daemon. Perform only this narrowly-scoped promotion in a
    short-lived root transient unit, while the parent keeps the shared AIDE lock.
    """
    if not confirm:
        return {'ok':False,'error':'explicit confirmation required to replace the active AIDE baseline','required_confirmation':'ACCEPT_PENDING'}
    fd,err=_aide_preflight()
    if err: return err
    try:
        if not _aide_regular_file(AIDE_DB_NEW):
            return {'ok':False,'error':'no valid non-empty aide.db.new is available','database':_aide_db_state()}
        helper=Path('/usr/lib/locsecd/aide-accept-pending')
        if not helper.exists() or not helper.is_file() or helper.is_symlink():
            return {'ok':False,'error':'AIDE pending-database helper is missing or invalid','database':_aide_db_state()}
        # The helper is root-owned mode 0700 and is invoked only in a sibling
        # transient unit with the host capability set. The daemon's reduced
        # CapabilityBoundingSet therefore remains unchanged.
        rc,out=broker('job.aide_accept')
        payload=None
        try:
            payload=json.loads(out.strip().splitlines()[-1]) if out.strip() else None
        except Exception:
            payload=None
        if isinstance(payload,dict):
            payload.setdefault('rc',rc)
            if rc!=0 and payload.get('ok') is True:
                payload['ok']=False
            return payload
        return {'ok':False,'rc':rc,'error':'AIDE promotion helper returned no valid JSON result','output':out[-12000:],'database':_aide_db_state()}
    finally:
        _aide_unlock(fd)

@_root_side('aide.reinit','rebuild and replace the AIDE baseline (aideinit --force) under the AIDE lock (confirm required)',
            after=lambda r,a:_mark_job_run('aide') if isinstance(r,dict) and r.get('ok') else None,
            confirm=_A(_vb,False))
def aide_reinitialize(confirm=False):
    """Explicitly rebuild and replace the AIDE baseline using aideinit --force."""
    if not confirm:
        return {'ok':False,'error':'explicit confirmation required to replace the active AIDE baseline','required_confirmation':'REPLACE_BASELINE'}
    if not have('aideinit'): return {'ok':False,'error':'aideinit not installed'}
    fd,err=_aide_preflight()
    if err: return err
    try:
        # Debian's aideinit documents --force as the explicit operation that replaces
        # the existing database; --yes only permits overwriting database_out.
        rc,out=broker('job.aide_reinit',timeout=_aide_timeout())
        state=_aide_db_state()
        valid=_aide_regular_file(AIDE_DB)
        ok=(rc==0 and valid and state['database']['uid']==0 and state['database']['gid']==0 and state['database']['mode']=='0o600')
        if rc!=0 and not have('systemd-run'):
            out+='\n(systemd-run not available; run "sudo aideinit --yes --force" manually instead.)'
        if rc==124: out=(out+'\n' if out else '')+f'aideinit did not finish within {_aide_timeout()}s (aide_scan_timeout in /etc/locsecd/locsecd.conf). The existing baseline was not replaced. Raise the limit or exclude large trees in /etc/aide/aide.conf.d, then run it again.'
        removed_dup=False
        if ok:
            # aideinit --force copies aide.db.new over aide.db and leaves the copy behind
            # (owned by _aide), so the dashboard showed a "pending" database right after a
            # build. Remove it only when it is a plain file byte-identical to the new
            # baseline; the root transient unit is needed because this daemon is sandboxed.
            if AIDE_DB_NEW.exists() and not AIDE_DB_NEW.is_symlink():
                rc2,_o=broker('job.aide_dedup')
                removed_dup=(rc2==0 and not AIDE_DB_NEW.exists())
            state=_aide_db_state()
        log(f'AIDE reinitialization rc={rc} db_valid={valid} duplicate_new_removed={removed_dup} state={json.dumps(state,separators=(",",":"))}')
        return {'ok':ok,'rc':rc,'output':out,'action':'reinitialize','database':state,'duplicate_new_removed':removed_dup}
    finally:
        _aide_unlock(fd)


# Paths whose change is worth a person's attention: system binaries and
# libraries, configuration, boot files, root's home, scheduled jobs, and the
# places in a user's home that run code at login or accept remote logins.
_AIDE_SENSITIVE=re.compile(r'^/(?:etc|boot|root|bin|sbin|lib|lib32|lib64|usr/(?:bin|sbin|lib|lib32|lib64|libexec|local)|var/spool/cron|opt)(?:/|$)'
                           r'|^/home/[^/]+/(?:\.ssh|\.bashrc|\.bash_profile|\.profile|\.bash_logout|\.zshrc|\.xprofile|\.xsessionrc|\.config/autostart|\.config/systemd|\.config/environment\.d|\.local/bin|\.gnupg)(?:/|$)')
_AIDE_ENTRY=re.compile(r'^[fdlpsbcDPL!][^:]{0,40}: (/.*)$')

def _aide_digest(path, list_max=150):
    """Summarise a full AIDE --check output: every security-relevant path, and
    everything else counted by directory, so thousands of cache and catalogue
    changes cannot bury the one that matters."""
    section=None; counts={'added':0,'removed':0,'changed':0}
    sensitive={'added':[],'removed':[],'changed':[]}; nsens={'added':0,'removed':0,'changed':0}; areas={}
    with open(path,'r',errors='replace') as f:
        for line in f:
            line=line.rstrip('\n')
            h=line.strip().lower()
            if h in ('added entries:','removed entries:','changed entries:'): section=h.split()[0]; continue
            if h.startswith('detailed information about changes') or h.startswith('the attributes of the'): section=None; continue
            if not section: continue
            m=_AIDE_ENTRY.match(line)
            if not m: continue
            p=m.group(1).strip(); counts[section]+=1
            if _AIDE_SENSITIVE.search(p):
                nsens[section]+=1
                if len(sensitive[section])<list_max: sensitive[section].append(p)
            else:
                parts=[x for x in p.split('/') if x]
                key='/'+'/'.join(parts[:3])
                areas[key]=areas.get(key,0)+1
    lines=['LocSec summary of this AIDE check',
           f'  {counts["added"]} added, {counts["removed"]} removed, {counts["changed"]} changed.',
           f'  Security-relevant (system binaries, libraries, /etc, /boot, root, cron, login and SSH files): '
           f'{nsens["added"]} added, {nsens["removed"]} removed, {nsens["changed"]} changed.']
    for sec in ('added','removed','changed'):
        if sensitive[sec]:
            lines+=['',f'SECURITY-RELEVANT, {sec.upper()} ({nsens[sec]}):']+['  '+x for x in sensitive[sec]]
            if nsens[sec]>len(sensitive[sec]): lines.append(f'  ... and {nsens[sec]-len(sensitive[sec])} more in the full output')
    if any(nsens.values()):
        lines+=['','Changes under /usr, /lib and /etc right after a package update are expected: compare the times with',
                'the apt history (grep -A3 "Start-Date" /var/log/apt/history.log). A change nothing explains needs a look.']
    else:
        lines+=['','Nothing security-relevant changed. Everything below is ordinary churn (caches, catalogues, logs).']
    if areas:
        lines+=['','Other changes by directory (largest first):']
        for k,v in sorted(areas.items(),key=lambda kv:-kv[1])[:25]: lines.append(f'  {v:7d}  {k}')
        if len(areas)>25: lines.append(f'  ... and {len(areas)-25} more directories')
    lines+=['',f'Full AIDE output: {path}','--- AIDE output (beginning and end) ---']
    return '\n'.join(lines)

def _aide_config():
    # Debian/Ubuntu's aide package ships aide.wrapper (used by cron/aideinit),
    # which knows where its config lives; the raw `aide` binary invoked
    # directly does not have a compiled-in default and fails with "missing
    # configuration" unless --config is passed explicitly. /etc/aide/aide.conf
    # is where the package puts it; Debian also generates a merged
    # /var/lib/aide/aide.conf.autogenerated that includes it.
    for c in (Path('/etc/aide/aide.conf'),Path('/var/lib/aide/aide.conf.autogenerated')):
        if c.exists(): return str(c)
    return None

def _scan_aide():
    """The AIDE check. The broker runs it under the AIDE lock and writes the complete output into a report
    file this half creates and hands over open."""
    full=REPORTS/f'aide-full-{datetime.now().strftime("%Y%m%d-%H%M%S")}.txt'
    try: fd=os.open(str(full),os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    except OSError as e: return {'name':'AIDE','status':'error','output':f'could not create the AIDE report file: {e}'}
    try: r=broker('aide.check',report=PassFD(fd))
    finally: os.close(fd)
    try:
        if os.path.getsize(full)==0: os.unlink(full)
    except OSError: pass
    if isinstance(r,dict) and r.get('full_output'): r['full_output']=str(full)
    return r

@_verb('aide.check','aide --check under the AIDE lock; the complete output is written to the report file handed over',
       refused=lambda m:{'name':'AIDE','status':'error','output':m},report=_A(_v_fd_write))
def _scan_aide_root(report):
    full=None
    if not have('aide'): return None
    if _aide_systemd_busy():
        return {'name':'AIDE','status':'busy','output':'Debian dailyaidecheck.service is running; LocSec skipped AIDE to avoid competing for the reference database.'}
    fd=_aide_lock(False)
    if fd is None:
        return {'name':'AIDE','status':'busy','output':'Another AIDE operation is running; LocSec skipped AIDE.'}
    try:
        running=_aide_processes_running()
        if running:
            return {'name':'AIDE','status':'busy','output':'Another AIDE process is running; LocSec skipped AIDE.\n'+'\n'.join(running[:10])}
        if not AIDE_DB.exists():
            return {'name':'AIDE','status':'not-initialized','output':'AIDE database not found; use Build AIDE database on the Scans page before checking integrity'}
        conf=_aide_config()
        if not conf:
            return {'name':'AIDE','status':'error','output':'AIDE config not found at /etc/aide/aide.conf; reinstall the aide package or run aideinit to regenerate it.'}
        timeout=_aide_timeout()
        # The complete output goes to a file beside the reports: the dashboard copy
        # keeps only the head and tail, and a check with thousands of changes had
        # everything in between -- usually the part that matters -- thrown away.
        full=BROKER_WORK/f'aide-full-{datetime.now().strftime("%Y%m%d-%H%M%S")}-{uuid.uuid4().hex[:8]}.txt'
        # Best-effort (not idle) I/O class: under idle-class I/O a busy desktop can starve AIDE
        # for hours. head=8000 keeps AIDE's summary block, which it prints BEFORE the long detail lists.
        result=scan_tool('AIDE',['aide','--config',conf,'--check'],timeout,transient=True,
                         verb='job.aide_check',vargs={'conf':conf,'timeout':timeout,'save_to':str(full)})
        rc=result.get('rc')
        if isinstance(rc,int) and 1<=rc<=7 and full.is_file():
            try:
                result['output']=_aide_digest(full)+'\n\n'+str(result.get('output',''))
                result['full_output']='report'
            except Exception as e: log(f'AIDE digest failed: {e}','ERROR')
        # aide exit status is a bitmask: 1=added 2=removed 4=changed (any of 1..7 = differences found,
        # which is a finding, not a failure); 14+ are real errors (write/argument/config/IO/version).
        if rc==0: result['status']='ok'
        elif rc==124:
            result['status']='timeout'
            result['output']=(f'AIDE did not finish within {timeout}s (aide_scan_timeout in /etc/locsecd/locsecd.conf). '
                              'The check was stopped; raise the limit and re-run, or exclude large volatile trees in /etc/aide/aide.conf.d.\n')+str(result.get('output',''))
        elif isinstance(rc,int) and 1<=rc<=7: result['status']='findings-or-error'
        else: result['status']='error'
        result['database']=_aide_db_state()
        return result
    finally:
        _aide_unlock(fd)
        if full is not None:
            # Hand the complete output over, then drop the broker's own copy.
            try:
                if full.is_file():
                    with open(full,'rb') as src, os.fdopen(os.dup(report),'wb') as dst:
                        dst.seek(0); dst.truncate(); shutil.copyfileobj(src,dst)
            except OSError as e: log(f'could not hand over the AIDE report: {e}','ERROR')
            try: full.unlink()
            except OSError: pass

_LYNIS_NOISE=re.compile(r'(?:\[WARNING\]: Test \S+ had a long execution|^pgrep: pattern that searches for process name longer|^Try `pgrep -f. option|Cannot initialize device-mapper)')

def _scan_lynis():
    if not have('lynis'): return None
    started=time.time()
    lt=max(60,min(86400,int(CFG.get('lynis_timeout',3600))))
    r=scan_tool('Lynis',['lynis','audit','system','--quick','--no-colors','--quiet'],lt,transient=True,verb='job.lynis',vargs={'timeout':lt})
    rc=r.get('rc')
    # Lynis's own report file is the authoritative record of what it found; stdout with --quiet is
    # just warnings plus internal timing chatter. Read the report instead of guessing from stdout.
    def _field(line,prefix):
        # lynis-report.dat rows are "<prefix>TEST-ID|text|details|solution|".
        f=line[len(prefix):].split('|')
        out=(f[0]+': '+(f[1] if len(f)>1 else '')).strip()
        det=(f[2] if len(f)>2 else '').strip()
        if det and det not in ('-','') and len(det)<=120: out+=f'  [{det}]'
        return out
    warns=[]; suggs=[]; idx=None; have_report=False
    try:
        # Root-only on most systems: opened by the broker and read here.
        report_text=None
        try:
            with _priv_open('/var/log/lynis-report.dat') as fh:
                st_rp=os.fstat(fh.fileno())
                if stat.S_ISREG(st_rp.st_mode) and st_rp.st_mtime>=started-5:
                    report_text=fh.read().decode('utf-8','replace')
        except FileNotFoundError: pass
        if report_text is not None:
            have_report=True
            for line in report_text.splitlines():
                if line.startswith('warning[]='):
                    warns.append(_field(line,'warning[]='))
                elif line.startswith('suggestion[]='):
                    # Previously only counted. The report file is root-only, so an
                    # operator reading the dashboard was told "Suggestions: 51" and
                    # then pointed at a file they could not open; list them here.
                    suggs.append(_field(line,'suggestion[]='))
                elif line.startswith('hardening_index='): idx=line.split('=',1)[1].strip()
    except Exception as e: log(f'could not read Lynis report: {e}','ERROR')
    raw=[l for l in str(r.get('output','')).splitlines() if l.strip()]
    noise=[l for l in raw if _LYNIS_NOISE.search(l)]
    other=[l for l in raw if l not in noise]
    if rc==124: status='timeout'
    elif not have_report and rc not in (0,): status='error'
    elif warns: status='warning'
    else: status='ok'
    lines=[]
    if have_report:
        lines.append(f'Lynis audit complete. Hardening index: {idx if idx is not None else "n/a"}/100. Warnings: {len(warns)}. Suggestions: {len(suggs)}.')
    if warns: lines+=['','Warnings (review these first):']+[' - '+w for w in warns[:100]]
    if suggs:
        lines+=['',f'Suggestions ({len(suggs)}) -- hardening opportunities, not findings:']+[' - '+x for x in suggs[:150]]
        if len(suggs)>150: lines.append(f' ... and {len(suggs)-150} more (see the report file).')
        lines+=['','Lynis is written for servers, so some suggestions do not apply to a desktop. Treat them as a',
                'list to decide on deliberately rather than a score to raise. Anything that tightens /var/log',
                'so rsyslog cannot write works against LocSec itself -- check a suggestion against the rest',
                'of the system before applying it.']
    if noise: lines+=['',f'Informational: {len(noise)} internal timing/environment note(s) from Lynis (slow tests, missing device-mapper) -- not findings.']
    if other: lines+=['','Other output:']+other[:60]
    if have_report: lines+=['','Full report: /var/log/lynis-report.dat']
    r['status']=status
    r['output']='\n'.join(lines) if lines else str(r.get('output',''))
    r['warnings']=len(warns); r['suggestions']=len(suggs); r['suggestion_list']=suggs[:150]
    return r

_DEBSECAN_LINE=re.compile(r'^((?:CVE|TEMP)-\S+)\s+(\S+)(?:\s+\((.*)\))?\s*$')

def _debsecan_result(name):
    # debsecan exits 0 whether it lists nothing or hundreds of CVEs, so the
    # result used to be labelled "Clean / no findings" above a long list; and
    # the list itself was the last 20 KB of output, so most of it was dropped.
    # Run it twice -- everything known, and only what already has a fix -- and
    # report the numbers that decide what to do.
    s=scan_tool(name,['debsecan','--suite',DEBIAN_SUITE],1800,tail=4000000)
    if s.get('status')=='not-installed': return s
    if s.get('rc')!=0:
        s['status']='error'
        s['output']='debsecan could not run (it downloads the Debian security tracker data, so this is usually no network):\n'+str(s.get('output',''))[-3000:]
        return s
    f=scan_tool(name,['debsecan','--suite',DEBIAN_SUITE,'--only-fixed'],1800,tail=4000000)
    def parse(out):
        rows=[]
        for line in str(out).splitlines():
            m=_DEBSECAN_LINE.match(line.strip())
            if m: rows.append((m.group(1),m.group(2),m.group(3) or ''))
        return rows
    known=parse(s.get('output','')); fixed=parse(f.get('output','')) if f.get('rc')==0 else []
    fixkeys={(c,p) for c,p,_ in fixed}
    per={}
    for c,pkg,_f in known:
        if (c,pkg) not in fixkeys: per[pkg]=per.get(pkg,0)+1
    high=[r for r in known if 'high urgency' in r[2] or 'remotely exploitable' in r[2]]
    lines=[f'debsecan ({DEBIAN_SUITE}): {len(known)} known vulnerabilit{"y" if len(known)==1 else "ies"} in {len(per)} installed package(s); '
           f'{len(fixed)} ha{"s" if len(fixed)==1 else "ve"} a fix available now.']
    if f.get('rc')!=0: lines.append('(The fixed-only query failed, so the number with a fix is not known this time.)')
    if fixed:
        lines+=['','FIX AVAILABLE -- install with Update system (or wait for the automatic update):']
        lines+=[f'  {c}  {p}'+(f'  ({fl})' if fl else '') for c,p,fl in fixed[:200]]
        if len(fixed)>200: lines.append(f'  ... and {len(fixed)-200} more')
    if high:
        lines+=['',f'Marked remotely exploitable or high urgency ({len(high)}):']+[f'  {c}  {p}  ({fl})' for c,p,fl in high[:50]]
    if per:
        lines+=['','Known but not yet fixed in Debian, by package (largest first). Nothing to install for these;',
                'they clear when Debian ships a fix, which LocSec then installs automatically:']
        for pkg,n in sorted(per.items(),key=lambda kv:-kv[1])[:40]: lines.append(f'  {n:5d}  {pkg}')
        if len(per)>40: lines.append(f'  ... and {len(per)-40} more packages')
    s['status']='warning' if fixed else ('info' if known else 'ok')
    s['known']=len(known); s['fixable']=len(fixed)
    s['output']='\n'.join(lines)
    return s

def _scan_debsecan():
    if not have('debsecan'): return None
    if IS_DEBIAN_NATIVE: return _debsecan_result('Debsecan')
    return {'name':'Debsecan','status':'skipped','output':'skipped on Ubuntu/Mint: the Debian vulnerability feed does not match Ubuntu package versions; see APT security candidates instead'}

def _dpkg_file_intact(path):
    # True only when the file is owned by an installed package AND dpkg's own
    # verification (md5sums) reports it unmodified. Used to tell "a package shipped
    # this as a script" apart from "something replaced a system binary".
    try:
        if not path.startswith('/') or '\n' in path: return False
        rc,out=run(['dpkg','-S',path],20)
        if rc!=0: return False
        pkg=out.split(':',1)[0].split(',')[0].strip()
        if not re.fullmatch(r'[A-Za-z0-9.+_-]+(?::[a-z0-9]+)?',pkg): return False
        rc,v=broker('pkg.verify',pkg=pkg)
        return rc==0 and path not in v
    except Exception:
        return False

# Files systemd/other base components create that rkhunter's "hidden file" check reports on every run.
_RKH_BENIGN_HIDDEN={'/etc/.updated','/etc/.resolv.conf.systemd-resolved.bak','/etc/.pwd.lock','/etc/.java',
                    '/usr/share/man/man5/.k5identity.5.gz','/usr/share/man/man5/.k5login.5.gz','/dev/.udev','/dev/.mdadm'}

# Groups whose membership grants root or raw hardware/disk access. A new one of
# these is never waved through as "created by a package".
_RKH_PRIVILEGED_GROUPS={'root','sudo','wheel','adm','shadow','disk','kmem','docker','lxd','libvirt','kvm','staff'}

def _is_login_user(name):
    try:
        import pwd
        return pwd.getpwnam(name).pw_uid>=1000
    except Exception:
        return False

def _rkhunter_classify(block):
    # block = [ 'Warning: ...', '   continuation', ... ]. Returns (benign, reason).
    head=block[0]; body=block[1:]
    text='\n'.join(block)
    for pat in CFG.get('rkhunter_ignore',[]):
        try:
            if re.search(pat,text): return True,'matched rkhunter_ignore in locsecd.conf'
        except re.error: pass
    m=re.search(r"The command '([^']+)' has been replaced by a script",head)
    if m:
        return (_dpkg_file_intact(m.group(1)),'shipped as a script by its package and verifies unmodified (dpkg --verify)')
    if 'suspicious (large) shared memory segments' in head:
        owners=set(re.findall(r'Owner:\s+(\S+)',' '.join(body)))
        if owners and all(_is_login_user(o) for o in owners):
            return True,'shared-memory segments owned by a normal login user (desktop applications / X11 IPC)'
        return False,''
    if head.startswith('Warning: Hidden file found:'):
        m=re.match(r'Warning: Hidden file found: (.+?): ',head)
        path=m.group(1) if m else ''
        if path in _RKH_BENIGN_HIDDEN: return True,'known systemd/base-system hidden file'
        return (_dpkg_file_intact(path) if path else False),'owned by a package and verifies unmodified'
    if head.startswith('Warning: Hidden directory found:'):
        m=re.match(r'Warning: Hidden directory found: (\S+?):?(?:\s|$)',head)
        if m and m.group(1) in _RKH_BENIGN_HIDDEN: return True,'known systemd/base-system hidden directory'
        return False,''
    if 'Suspicious file types found in /dev' in head:
        entries=[b.strip() for b in body if b.strip()]
        if entries and all(re.match(r'/dev/shm/(?:ecryptfs-[^/]+-Private|lttng-ust-wait-\d+(?:-\d+)?):',e) for e in entries):
            return True,'eCryptfs signature or LTTng tracing wait file in /dev/shm (cleared at reboot)'
        return False,''
    # A new system account is what installing a service package does (clamav,
    # _aide, wireshark ...). Treat it as informational only when it really is
    # one: an unprivileged id in the system range, and for a user no login
    # shell. A new uid-0, login-capable or regular-range account still needs
    # review, as does any change to an existing group's members (sudo).
    m=re.match(r"Warning: Changes found in the group file for group '([^']+)':",head)
    if m and m.group(1) in ('adm','systemd-journal'):
        members=[re.match(r"\s*User '([^']+)' has been added to the group\s*$",b) for b in body if b.strip()]
        if members and all(members) and {x.group(1) for x in members}=={'locsec'}:
            try:
                import pwd
                u=pwd.getpwnam('locsec')
                if 100<=u.pw_uid<1000 and (u.pw_shell.endswith('nologin') or u.pw_shell.endswith('/false')):
                    return True,f"LocSec's own service account, added to {m.group(1)} by its installer so it can read the logs"
            except (KeyError,ImportError): pass
        return False,''
    m=re.match(r"Warning: The file '(/[^']+)' exists on the system, but it is not present in the 'rkhunter.dat' file",head)
    if m:
        # rkhunter's file database predates the package (rsyslog is installed with LocSec).
        return (_dpkg_file_intact(m.group(1)),'installed after rkhunter built its file database; owned by a package and verifies unmodified (dpkg --verify)')
    m=re.match(r"Warning: User '([^']+)' has been added to the passwd file",head)
    if m:
        try:
            import pwd
            u=pwd.getpwnam(m.group(1))
            if 100<=u.pw_uid<1000 and (u.pw_shell.endswith('nologin') or u.pw_shell.endswith('/false')):
                return True,f'system account (uid {u.pw_uid}, no login shell) created by a package'
        except (KeyError,ImportError): pass
        return False,''
    m=re.match(r"Warning: Group '([^']+)' has been added to the group file",head)
    if m:
        try:
            import grp
            g=grp.getgrnam(m.group(1))
            if 100<=g.gr_gid<1000 and m.group(1) not in _RKH_PRIVILEGED_GROUPS:
                return True,f'system group (gid {g.gr_gid}) created by a package'
        except (KeyError,ImportError): pass
        return False,''
    return False,''

def _scan_rkhunter():
    if not have('rkhunter'): return None
    fix_rkhunter_web_cmd()
    broker('job.rkhunter_update',context='scan')
    # 200 KB, not the generic 20 KB tail: the warning classifier parses findings
    # out of this output, so anything the tail cut off was silently not reported.
    r=scan_tool('rkhunter',['rkhunter','--check','--skip-keypress','--rwo'],3600,transient=True,verb='job.rkhunter_check')
    rc=r.get('rc'); out=str(r.get('output',''))
    # --rwo (warnings-only output): each 'Warning:' line starts a finding; indented lines under it belong to it.
    blocks=[]
    for line in out.splitlines():
        if not line.strip(): continue
        if line.startswith('Warning:') or not blocks: blocks.append([line])
        else: blocks[-1].append(line)
    review=[]; benign=[]
    for bl in blocks:
        if not bl[0].startswith('Warning:'):
            review.append((bl,'')); continue
        ok,why=_rkhunter_classify(bl)
        (benign if ok else review).append((bl,why))
    if rc==124: status='timeout'
    elif rc not in (0,1): status='error'
    elif review: status='findings-or-error'
    elif benign: status='info'
    else: status='ok'
    lines=[f'rkhunter: {len(review)} finding(s) need review, {len(benign)} informational (verified benign).']
    if review:
        lines+=['','NEEDS REVIEW:']
        for bl,_ in review: lines+=bl
    if benign:
        lines+=['','INFORMATIONAL (checked, no action needed):']
        for bl,why in benign:
            lines.append(bl[0]+('  -- '+why if why else ''))
            lines+=bl[1:6]
            if len(bl)>6: lines.append(f'         ... and {len(bl)-6} more')
    r['status']=status
    r['output']='\n'.join(lines) if (blocks or rc in (0,1)) else out
    for bl,_ in review[:50]:
        key=re.sub(r'\s+',' ',bl[0])[:120]
        incident('rootkit-warning','rkhunter',key,'high','detected','\n'.join(bl)[:1500])
    return r

def _clamav_incident(result):
    # clamscan/clamdscan exit 1 means "infected files found" (0=clean,
    # 2=error). Surface each infected line as its own incident so the
    # timeline names the actual file and signature, not just "scan ran".
    if not result or result.get('rc')!=1: return
    lines=[l for l in str(result.get('output','')).splitlines() if l.rstrip().endswith('FOUND')]
    for line in lines[:50]:
        path,_,sig=line.rpartition(': ')
        incident('virus-found','clamav',path.strip(),'critical','detected',sig.strip())

# Trees never worth walking with an antivirus even if an operator points
# clamav_scan_paths at "/": pseudo filesystems, other volumes' mirrors,
# eCryptfs's encrypted lower directory (scanning ciphertext is pointless; the
# decrypted view is scanned through the user's mounted home), package/vendor
# static content. Extendable per-host via clamav_extra_excludes in locsecd.conf
# (list of anchored path regexes).
CLAMAV_DEFAULT_EXCLUDES=[
    r'^/proc', r'^/sys', r'^/dev', r'^/run', r'^/snap',
    r'^/home/\.ecryptfs',
    r'^/usr/src',
    r'^/usr/lib/firmware',
    r'^/usr/share/icons',
    r'^/usr/share/themes',
    r'^/usr/share/doc',
    r'^/usr/share/man',
    r'^/var/lib/dpkg/info',
    r'^/var/lib/flatpak',
    r'^/var/cache/apparmor',
    # The quarantine vault (root only since 4.0.11-91; the old path never exists any more).
    r'^/var/lib/locsecd-broker',
]
def _clamav_excludes():
    extra=CFG.get('clamav_extra_excludes',[])
    if not isinstance(extra,list): extra=[]
    seen=set(); out=[]
    for pat in CLAMAV_DEFAULT_EXCLUDES+list(extra):
        if pat not in seen:
            seen.add(pat); out.append(pat)
    return out

def _clamav_build_list(paths, out_path, max_bytes):
    # Walk the scan paths as root (this process) and write one regular-file path
    # per line. Symlinks, sockets, device nodes and oversize files are skipped
    # here instead of being handed to clamd to reject one by one.
    excl=[]
    for pat in _clamav_excludes():
        try: excl.append(re.compile(pat))
        except re.error: log(f'ignoring invalid ClamAV exclude regex: {pat}','WARN')
    st={'listed':0,'too_big':0,'special':0,'excluded':0,'unreadable_dirs':0}
    with open(out_path,'w',encoding='utf-8',errors='surrogateescape') as f:
        os.chmod(out_path,0o600)
        for top in paths:
            stack=[top]
            while stack and not STOP_EVENT.is_set():
                d=stack.pop()
                try: it=os.scandir(d)
                except OSError: st['unreadable_dirs']+=1; continue
                with it:
                    for e in it:
                        try:
                            path=e.path
                            if '\n' in path: continue
                            if any(rx.match(path) for rx in excl): st['excluded']+=1; continue
                            if e.is_symlink(): continue
                            if e.is_dir(follow_symlinks=False): stack.append(path); continue
                            if not e.is_file(follow_symlinks=False): st['special']+=1; continue
                            size=e.stat(follow_symlinks=False).st_size
                            if size==0: continue
                            if size>max_bytes: st['too_big']+=1; continue
                            f.write(path+'\n'); st['listed']+=1
                        except OSError: continue
    return st

def _clamav_parse_output(path):
    # Stream the full saved clamd/clamscan output: infected lines, error lines and the summary.
    r={'infected':[], 'found':0, 'errors':0, 'err_sample':[], 'have_summary':False, 'sum_infected':None, 'sum_errors':None}
    try:
        with open(path,'r',errors='replace') as f:
            for line in f:
                line=line.rstrip('\n')
                if line.endswith(' FOUND'):
                    r['found']=r.get('found',0)+1
                    # Keep the count exact but the list bounded: a badly
                    # misconfigured scan can report every file as infected.
                    if len(r['infected'])<500: r['infected'].append(line)
                elif line.endswith('ERROR') and ': ' in line:
                    r['errors']+=1
                    if len(r['err_sample'])<20: r['err_sample'].append(line)
                m=re.match(r'Infected files:\s*(\d+)',line)
                if m: r['sum_infected']=int(m.group(1)); r['have_summary']=True
                m=re.match(r'Total errors:\s*(\d+)',line)
                if m: r['sum_errors']=int(m.group(1))
    except OSError: pass
    if r['sum_errors'] is not None: r['errors']=max(r['errors'],r['sum_errors'])
    return r

# Work files carry the broker's pid and a random tag per scan. They used to be fixed
# names in STATE, which a second locsecd.py process -- `locsecctl scan-clamav`
# or `locsecctl scan`, neither of which can see the daemon's in-process
# JOB_LOCK -- would truncate and unlink underneath a scan the daemon was
# already running, losing or corrupting both sets of results.
_CLAMAV_WORKFILE_RE=re.compile(r'^clamav-(?:filelist|batch|out)-(\d+)-[0-9a-f]{8}(?:-\d+)?$')

def _clamav_sweep_stale():
    # A SIGKILL/OOM/power loss mid-scan leaves the file list and the current
    # batch behind (a list of every file under clamav_scan_paths is not small).
    # Nothing else ever removed them, so they accumulated one set per crash.
    # Only files whose owning process is gone are removed: a `locsecctl
    # scan-clamav` started before this daemon must not have its work files
    # deleted out from under it just because the daemon restarted.
    if ROLE=='web': return
    for f in list(BROKER_WORK.glob('clamav-*.txt'))[:5000]:
        try:
            if not f.is_file() or f.is_symlink(): continue
            m=_CLAMAV_WORKFILE_RE.match(f.stem)
            if m and (Path('/proc')/m.group(1)).exists(): continue   # owner still running
            f.unlink()
        except OSError: pass

def _clamav_run_batch(mode, files, idx, timeout, tag):
    bf=BROKER_WORK/f'clamav-batch-{tag}-{idx}.txt'; of=BROKER_WORK/f'clamav-out-{tag}-{idx}.txt'
    try:
        with open(bf,'w',encoding='utf-8',errors='surrogateescape') as f:
            os.chmod(bf,0o600); f.write('\n'.join(files)+'\n')
        rc,out=broker('job.clamav_batch',mode=mode,timeout=max(60,min(3600,int(timeout))),batch_file=str(bf),out_file=str(of))
        res=_clamav_parse_output(of); res['rc']=rc; res['tail']=out[-2000:]
        return res
    finally:
        for x in (bf,of):
            try: x.unlink()
            except OSError: pass

def _clamd_active():
    if not have('systemctl'): return False
    rc,_=run(['systemctl','is-active','--quiet','clamav-daemon.service'],15)
    if rc==0: return True
    broker('svc.fixed',op='clamd.start')
    rc,_=run(['systemctl','is-active','--quiet','clamav-daemon.service'],15)
    return rc==0

@_root_side('scan.clamav','the ClamAV scan of clamav_scan_paths: the file list (walking homes needs root) and the batches, in the broker',
            refused=lambda m:{'name':'ClamAV','status':'error','rc':126,'output':m},
            after=lambda r,a:_clamav_incident(r) if isinstance(r,dict) else None)
def _scan_clamav():
    paths=[p for p in CFG.get('clamav_scan_paths',['/home']) if os.path.isdir(p)]
    if not paths:
        return {'name':'ClamAV','status':'error','rc':2,'output':'None of the configured clamav_scan_paths exist: '+', '.join(CFG.get('clamav_scan_paths',[]))}
    # Methods, best first. clamdscan --fdpass hands clamd open file descriptors, so clamd never needs
    # permission to read the user's files (eCryptfs homes included). That only works if the caller
    # is in the host mount namespace -- which is why the scan runs in its own transient unit and
    # not inside locsecd.service's private one (under AppArmor, a descriptor from another mount
    # namespace has no resolvable path: "Failed name lookup - disconnected path", and clamd then
    # reports every file as "Not a regular file ERROR"). If that still fails systemically we
    # fall back to streaming the content, then to standalone clamscan.
    modes=[]
    if have('clamdscan') and _clamd_active(): modes+=['fdpass','stream']
    if have('clamscan'): modes.append('clamscan')
    if not modes: return None
    max_mb=int(CFG.get('clamav_max_file_mb',100))
    max_bytes=max_mb*1024*1024
    # One tag per scan: the broker is one long-lived process serving every client on its own thread,
    # so a per-process tag let a second scan (locsecctl scan-clamav) truncate this one's files.
    tag=f'{os.getpid()}-{uuid.uuid4().hex[:8]}'
    listfile=BROKER_WORK/f'clamav-filelist-{tag}.txt'
    started=time.time(); deadline=started+int(CFG.get('clamav_timeout',7200))
    try:
        st=_clamav_build_list(paths,listfile,max_bytes)
    except Exception as e:
        return {'name':'ClamAV','status':'error','rc':2,'output':f'could not build the scan file list: {e}'}
    batch_size=int(CFG.get('clamav_batch_size',20000))
    mi=0; notes=[]; infected=[]; infected_total=0; errors=0; err_sample=[]; scanned=0; timed_out=False; idx=0
    stream_max=None
    try:
        with open(listfile,'r',encoding='utf-8',errors='surrogateescape') as lf:
            while not _cancelled():
                batch=[]
                for line in lf:
                    line=line.rstrip('\n')
                    if line: batch.append(line)
                    if len(batch)>=batch_size: break
                if not batch: break
                # Files can vanish between listing and scanning (editor saves, caches); drop those
                # up front so they are not counted as scan errors.
                live=[x for x in batch if os.path.exists(x)]
                if not live: continue
                while True:
                    now=time.time()
                    if now>=deadline: timed_out=True; break
                    mode=modes[mi]
                    files=live
                    if mode=='stream':
                        # clamd refuses streams larger than StreamMaxLength; those would be errors, not scans.
                        if stream_max is None:
                            stream_max=_size_to_bytes(_clamd_conf_value('StreamMaxLength','25M'),25*1024*1024)
                        files=[]
                        for x in live:
                            try:
                                if os.stat(x).st_size<=stream_max: files.append(x)
                            except OSError: pass
                        # Every file in this batch is over StreamMaxLength. Sent as an
                        # empty list, clamdscan printed no summary, which read as a
                        # systemic failure and dropped the rest of the scan to clamscan.
                        if not files:
                            notes.append(f'{len(live)} file(s) in one batch are larger than clamd\'s StreamMaxLength and were skipped in stream mode.')
                            break
                    idx+=1
                    res=_clamav_run_batch(mode,files,idx,int(min(3600,max(60,deadline-now))),tag)
                    n=len(files)
                    systemic=(not res['have_summary']) or res['errors']>=max(1,min(50,n//2))
                    if systemic and not res['infected'] and mi+1<len(modes):
                        notes.append(f'{mode} failed systemically on a batch of {n} file(s) (rc={res["rc"]}, {res["errors"]} error(s)); switching to {modes[mi+1]}.')
                        log(f'ClamAV {mode} failed systemically (rc={res["rc"]}, errors={res["errors"]}/{n}); falling back to {modes[mi+1]}','WARN')
                        mi+=1; continue
                    infected=(infected+res['infected'])[:500]; infected_total+=res.get('found',len(res['infected'])); errors+=res['errors']
                    err_sample=(err_sample+res['err_sample'])[:20]
                    scanned+=max(0,n-res['errors'])
                    break
                if timed_out: break
    finally:
        try: listfile.unlink()
        except OSError: pass
    secs=int(time.time()-started)
    mode=modes[mi]
    desc={'fdpass':'clamdscan --fdpass (clamd daemon)','stream':'clamdscan --stream (clamd daemon)','clamscan':'clamscan (standalone engine)'}[mode]
    tol=max(10,int(scanned*0.001))
    if infected_total: status='findings-or-error'; rc=1
    elif _cancelled(): status='interrupted'; rc=130
    elif timed_out: status='timeout'; rc=124
    elif errors>tol: status='warning'; rc=2
    elif errors>0: status='info'; rc=0
    else: status='ok'; rc=0
    lines=[f'ClamAV scan of: {", ".join(paths)}',
           f'Method: {desc}',
           f'Files listed: {st["listed"]}  (skipped: {st["too_big"]} larger than {max_mb} MB, {st["special"]} special files, {st["excluded"]} in excluded paths, {st["unreadable_dirs"]} unreadable directories)',
           f'Files scanned: {scanned}',
           f'Infected files: {infected_total}',
           f'Errors: {errors}',
           f'Time: {secs}s']
    if timed_out: lines.append(f'The scan hit clamav_timeout ({int(CFG.get("clamav_timeout",7200))}s) and was stopped; results above are partial.')
    if errors and status=='info': lines.append('A handful of errors is normal on a live system (files that changed or vanished mid-scan).')
    lines+=notes
    if infected:
        lines+=['','INFECTED:']+infected[:100]
        if infected_total>len(infected[:100]): lines.append(f'... and {infected_total-len(infected[:100])} more (see the report file).')
    if err_sample: lines+=['','Error sample (first 20):']+err_sample
    log(f'ClamAV scan completed status={status} scanned={scanned} infected={infected_total} errors={errors} method={mode} time={secs}s')
    r={'name':'ClamAV daemon' if mode!='clamscan' else 'ClamAV','status':status,'rc':rc,'output':'\n'.join(lines),'infected':infected_total,'errors':errors,'scanned':scanned}
    return r

_CLAMD_KICK={'checked':0.0,'done':False}

def clamd_after_first_signatures():
    """Every 5 minutes until it has happened: start clamav-daemon once the first signatures exist.
    Debian's unit does not start without a database, so on a fresh install the start postinst asks
    for comes before freshclam's first download, systemd skips it, and nothing started clamd later:
    it stayed stopped until a reboot or the first ClamAV scan. Only a start systemd skipped is
    redone; a clamd that has been running this boot (and so was stopped on purpose) or that is
    disabled is left alone."""
    now=time.time()
    if _CLAMD_KICK['done'] or now-_CLAMD_KICK['checked']<300: return
    _CLAMD_KICK['checked']=now
    if not have('systemctl'): return
    rc,out=run(['systemctl','show','clamav-daemon.service','-p','ActiveState','-p','UnitFileState','-p','ConditionResult',
                '-p','ConditionTimestampMonotonic','-p','ActiveEnterTimestampMonotonic'],15)
    if rc!=0: return
    info=dict(l.split('=',1) for l in out.splitlines() if '=' in l)
    if info.get('ActiveState') in ('active','activating','reloading'): _CLAMD_KICK['done']=True; return
    skipped=(info.get('ConditionResult')=='no' and info.get('ConditionTimestampMonotonic','0') not in ('','0')
             and info.get('ActiveEnterTimestampMonotonic','0') in ('','0'))
    if info.get('UnitFileState')!='enabled' or not skipped: return
    if not any(os.path.exists(f'/var/lib/clamav/main.{x}') for x in ('cvd','cld','inc')): return
    log('ClamAV signatures have arrived: starting clamav-daemon, whose start at install was skipped because there were none yet')
    broker('svc.fixed',op='clamd.start')
    _CLAMD_KICK['done']=True

def _clamd_conf_value(key,default=None):
    try:
        for line in Path('/etc/clamav/clamd.conf').read_text(errors='replace').splitlines():
            parts=line.split(None,1)
            if len(parts)==2 and parts[0]==key: return parts[1].strip()
    except OSError: pass
    return default

def _size_to_bytes(text,default):
    m=re.fullmatch(r'(\d+)\s*([KkMmGg]?)',str(text or '').strip())
    if not m: return default
    return int(m.group(1))*{'':1,'k':1024,'m':1024**2,'g':1024**3}[m.group(2).lower()]

def _scan_ports_fw():
    results=[]
    # These are inventories, not scans with a pass/fail verdict: label them informational instead
    # of "clean".
    if have('ss'):
        rc,out=broker('net.sockets',view='listening_table',timeout=120); log(f'Listening ports scan completed rc={rc}')
        results.append({'name':'Listening ports','status':'info' if rc==0 else 'error','rc':rc,'output':out})
    if have('ufw'):
        rc,out=broker('fw.ufw.status',detail='numbered',timeout=120); log(f'UFW status scan completed rc={rc}')
        r={'name':'UFW status','status':'info' if rc==0 else 'error','rc':rc,'output':out}; results.append(r)
    return results or None

# Individual scan jobs the background loop runs one at a time, staggered by
# scan_stagger_seconds so a week's worth of scanning doesn't all land on the
# CPU/disk at once. Each still runs once every scan_interval (default:
# weekly), just offset from the others. The buttons on the Scans page run one
# tool at once (/api/scan-job), outside this schedule.
# ClamAV is intentionally not in this list -- see CLAMAV_JOB below, which
# runs on its own daily clamav_scan_interval instead of the weekly one.
SCAN_JOBS=[('aide',_scan_aide),('lynis',_scan_lynis),('debsecan',_scan_debsecan),
           ('rkhunter',_scan_rkhunter),('ports_fw',_scan_ports_fw)]
CLAMAV_JOB=('clamav',_scan_clamav)
_JOB_LABEL={'aide':'AIDE','lynis':'Lynis','debsecan':'Debsecan','rkhunter':'rkhunter','ports_fw':'Ports/firewall','clamav':'ClamAV','cve':'CVE'}

def _mark_job_run(*keys):
    # State of the unprivileged half; the broker never writes it (the calling side marks the run).
    if ROLE=='broker': return
    try:
        with LOCK:
            try: runs=json.loads(JOBRUNS.read_text())
            except Exception: runs={}
            if not isinstance(runs,dict): runs={}
            for k in keys: runs[str(k)]=time.time()
            atomic_json(JOBRUNS,runs)
    except Exception as e: log(f'could not record the job run time: {e}','ERROR')

def _job_runs():
    try:
        runs=json.loads(JOBRUNS.read_text())
        return {str(k):float(v) for k,v in runs.items()} if isinstance(runs,dict) else {}
    except Exception: return {}

def _job_busy(result):
    rs=result if isinstance(result,list) else [result]
    return bool(rs) and all(isinstance(r,dict) and r.get('status')=='busy' for r in rs)

def run_scan_job(key,fn):
    result=fn()
    # Stopped part-way (service stop/restart, package upgrade): no report, and not
    # marked as run, so it is due again as soon as LocSec is back.
    if STOP_EVENT.is_set():
        log(f'scan job "{key}" interrupted by shutdown; it will run again','WARN')
        return {'interrupted':True}
    if result is not None and _job_busy(result):
        log(f'scan job "{key}" skipped: {(result if isinstance(result,dict) else result[0]).get("output","busy")[:200]}','INFO')
        return {'busy':True,'results':result if isinstance(result,list) else [result]}
    _mark_job_run(key)
    if result is None: return None
    results=result if isinstance(result,list) else [result]
    report=REPORTS/f'scan-{key}-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'
    atomic_json(report,{'ts':time.time(),'job':key,'results':results})
    log(f'staggered scan job "{key}" completed, report={report}')
    return {'report':str(report),'results':results}

def idle_enough():
    try: load=float(Path('/proc/loadavg').read_text().split()[0])
    except Exception: return False
    return load <= float(CFG.get('idle_load',1.0))


def cve_scan():
    # Known vulnerabilities in installed packages, from the distribution's own
    # data: debsecan (Debian and LMDE, against the Debian security tracker) and
    # the security updates APT has pending. Trivy was removed in 4.0.11-62: it
    # needed a third-party APT repository that apt trusted as root.
    out=[]
    if have('debsecan') and IS_DEBIAN_NATIVE: out.append(_debsecan_result('Debian CVE scan'))
    elif have('debsecan'): out.append({'name':'Debian CVE scan','status':'skipped','output':'skipped on Ubuntu/Mint: the Debian vulnerability feed does not match Ubuntu package versions; the APT security candidates below cover this system'})
    if have('apt-get'):
        rc,ss=broker('job.apt_simulate'); out.append({'name':'APT security candidates','rc':rc,'output':ss[-20000:]})
    if STOP_EVENT.is_set():
        log('CVE scan interrupted by shutdown; no report written','WARN')
        return {'interrupted':True,'results':out}
    _mark_job_run('cve')
    report=REPORTS/f'cve-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'; atomic_json(report,{'ts':time.time(),'results':out})
    return {'report':str(report),'results':out}

# Units LocSec coordinates. These stay on the Services list even when they are
# not running: the list is otherwise "currently running", so stopping one made
# it disappear from the page (and from the Overview card) with no way to start
# it again except by typing its name into the manual box.
_MANAGED_UNITS_BASE=('locsecd.service','ufw.service','clamav-daemon.service',
                      'clamav-freshclam.service','rsyslog.service')

def _managed_units():
    return _MANAGED_UNITS_BASE

def _unit_states(units):
    """ActiveState/SubState/LoadState/Description for several units in one call."""
    out_map={}
    if not units or not have('systemctl'): return out_map
    rc,out=run(['systemctl','show','--no-pager','-p','Id','-p','LoadState','-p','ActiveState',
                '-p','SubState','-p','UnitFileState','-p','Description','-p','MainPID','--']+list(units),30)
    if rc!=0: return out_map
    cur={}
    for line in out.splitlines():
        if not line.strip():
            if cur.get('Id'): out_map[cur['Id']]=cur
            cur={}; continue
        k,_,v=line.partition('=')
        cur[k.strip()]=v.strip()
    if cur.get('Id'): out_map[cur['Id']]=cur
    return out_map

# systemd reports two orthogonal things: ActiveState (is the unit up?) and
# SubState (what is the process doing?). A Type=oneshot unit with
# RemainAfterExit=yes -- ufw.service is exactly that -- sits at
# ActiveState=active / SubState=exited for its whole working life. Showing the
# SubState verbatim made a correctly running firewall read as "exited" on the
# Services page and in the Overview card, which is alarming and wrong. Show a
# state derived from ActiveState, and only fall back to the SubState when it
# genuinely adds something.
_SETTLED_SUBSTATES={'exited','mounted','plugged','listening','waiting','active'}

def _display_state(active,sub):
    a=str(active or '').strip(); b=str(sub or '').strip()
    if a=='active':
        if b=='running': return 'running'
        if b in _SETTLED_SUBSTATES or not b: return 'active'
        return b
    if a=='inactive': return 'stopped'
    if a in ('failed','activating','deactivating','reloading'): return a
    return a or 'unknown'

_TRANSITIONAL=('activating','deactivating','reloading','refreshing')

def _settle_unit_state(unit,tries=6,delay=0.5):
    # systemctl returns when the job is enqueued and run, but a unit that is
    # D-Bus- or socket-activated (bluetooth.service is both on a desktop) can
    # be pulled straight back up by whatever wanted it, and a unit with a slow
    # ExecStart can still read as "activating" the instant the job completes.
    # Sampling once produced "stop ... ok (running -> activating)": a stop that
    # had already been undone, reported as a success. Wait for the unit to
    # settle out of a transitional state before judging the outcome.
    st=_unit_state_one(unit)
    for _ in range(max(0,tries)):
        if st['active'] not in _TRANSITIONAL: return st
        time.sleep(delay)
        st=_unit_state_one(unit)
    return st

def _unit_state_one(unit):
    m=_unit_states([unit])
    # Keyed by systemd's Id, the canonical name: sshd.service (an alias) comes back as ssh.service.
    st=m.get(unit) or (next(iter(m.values())) if len(m)==1 else {})
    a=str(st.get('ActiveState','')); b=str(st.get('SubState',''))
    return {'active':a,'sub':b,'load':str(st.get('LoadState','')),
            'file':str(st.get('UnitFileState','')),
            'running':a=='active','state':_display_state(a,b)}

# Units the operator has acted on from the dashboard. 4.0.11-31 made
# LocSec-managed units stay listed when stopped, but every other unit still
# vanished the moment it left the running list -- stop bluetooth.service and
# the row disappeared, leaving no way to start it again except typing the name
# into the manual box. Anything acted on here stays listed whatever its state.
def _unit_pids(units):
    """Main PID systemd reports for each unit. 0 means no running main process."""
    pids={}
    units=list(units)
    for i in range(0,len(units),100):
        for unit,st in _unit_states(units[i:i+100]).items():
            try: pids[unit]=int(st.get('MainPID') or 0)
            except ValueError: pids[unit]=0
    return pids

def service_list():
    if not have('systemctl'):
        return []
    managed=_managed_units()
    rc,out=run(['systemctl','list-units','--type=service','--state=running','--no-legend','--no-pager'],30)
    if rc!=0:
        return []
    items=[]; seen=set()
    for line in out.splitlines():
        parts=line.split(None,4)
        if len(parts)>=5:
            unit=parts[0]; seen.add(unit)
            items.append({'unit':unit,'load':parts[1],'active':parts[2],'sub':parts[3],
                          'state':_display_state(parts[2],parts[3]),
                          'description':parts[4][:500],'running':parts[2]=='active',
                          'managed':unit in managed})
    # LocSec-managed units stay listed even when stopped.
    missing=[u for u in managed if u not in seen]
    for unit,st in _unit_states(missing).items():
        if str(st.get('LoadState',''))=='not-found': continue   # package not installed here
        items.append({'unit':unit,'load':st.get('LoadState',''),'active':st.get('ActiveState',''),
                      'sub':st.get('SubState',''),
                      'state':('masked' if str(st.get('LoadState',''))=='masked' and st.get('ActiveState')!='active'
                               else _display_state(st.get('ActiveState',''),st.get('SubState',''))),
                      'description':str(st.get('Description',''))[:500],
                      'running':st.get('ActiveState')=='active',
                      'managed':True})
    pids=_unit_pids([x['unit'] for x in items])
    for x in items:
        x['pid']=pids.get(x['unit'],0)
    # ufw.service is a one-shot unit: it loads the rules into the kernel and exits, so systemd has no
    # process to report and the PID column used to be a bare dash, which read as "not running". Ask ufw
    # itself, and say so: the state is only "running" when the rules are really loaded.
    for x in items:
        if x['unit']=='ufw.service' and x['pid']<=0 and x.get('active')=='active':
            if firewall_active():
                x['state']='running'; x['running']=True
                x['pid_note']='no process: rules are loaded in the kernel'
            else:
                x['state']='rules off'; x['running']=False
                x['pid_note']='unit is up but ufw reports the firewall inactive'
    items.sort(key=lambda x:(not x['managed'],x['unit']))
    return items[:500]

_FEEDS_CACHE={'key':None,'data':{}}
_FEEDS_LOCK=threading.Lock()

def _feeds():
    """The parsed feeds.json, re-read only when the file changes."""
    try: st=FEEDS.stat(); key=(st.st_mtime_ns,st.st_size)
    except OSError: return {}
    with _FEEDS_LOCK:
        if _FEEDS_CACHE['key']!=key:
            try: d=json.loads(FEEDS.read_text())
            except Exception: d={}
            _FEEDS_CACHE.update(key=key,data=d if isinstance(d,dict) else {})
        return _FEEDS_CACHE['data']

def reputation_check(indicator):
    raw=str(indicator or '').strip()[:512]
    if not raw:
        return {'ok':False,'error':'indicator required'}
    host=raw
    try:
        if '://' in raw:
            host=urllib.parse.urlparse(raw).hostname or ''
        elif '/' in raw and not safe_network(raw):
            host=raw.split('/',1)[0]
        host=host.strip().lower().rstrip('.')
    except Exception:
        host=''
    feeds=_feeds()
    matches=[]
    addr=safe_ip(host)
    if addr:
        for item in feeds.get('ips',[])+feeds.get('networks',[]):
            n=safe_network(item)
            if n and addr in n: matches.append(item)
    else:
        for d in feeds.get('domains',[]):
            d=str(d).lower().rstrip('.')
            if host==d or host.endswith('.'+d): matches.append(d)
    return {'ok':True,'indicator':raw,'normalized':host,'malicious':bool(matches),'matches':sorted(set(matches))[:100], 'feed_updated':feeds.get('updated')}

# How much serialized JSON the dashboard will render inline. dashboard_report_max_mb
# is the safety cap on reading a report at all; this is the much smaller amount a
# browser can actually lay out. A 32 MiB report pushed through
# JSON.stringify + innerHTML is what used to freeze the window on "View".
_DASHBOARD_INLINE_MAX=1500000

def _display_report(n,path,size,data,mtime=None):
    """Return something the dashboard can render without locking up the browser."""
    if size>_DASHBOARD_INLINE_MAX:
        head=data if isinstance(data,str) else ''
        return {'ts':mtime if mtime is not None else 0,'results':[{'name':n,'status':'info',
                'output':(f'This report is {size/1048576:.1f} MiB -- too large to display in full.\n'
                          f'First {_DASHBOARD_INLINE_MAX//1024} KiB of the file:\n\n')+head
                          +f'\n\n... truncated for display. Full document: {path}'}]},True
    return data,False

def read_report(name):
    n=Path(str(name)).name
    if n!=str(name) or not n.endswith('.json'):
        return {'ok':False,'error':'invalid report name'}
    path=REPORTS/n
    try:
        limit=int(CFG.get('dashboard_report_max_mb',100))*1024*1024
        fd=os.open(str(path),os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
        try:
            st=os.fstat(fd)
            if not stat.S_ISREG(st.st_mode):
                return {'ok':False,'error':'report is not a regular file'}
            size=st.st_size
            if size > limit:
                return {'ok':False,'error':f'report is {size/1048576:.1f} MiB and exceeds the {limit/1048576:.0f} MiB dashboard display limit; use the report file directly or delete it.'}
            if size>_DASHBOARD_INLINE_MAX:
                with os.fdopen(fd,'r',errors='replace') as rf:
                    fd=None
                    data=rf.read(_DASHBOARD_INLINE_MAX)
            else:
                with os.fdopen(fd,'r',errors='replace') as rf:
                    fd=None
                    data=json.load(rf)
            report,summarized=_display_report(n,path,size,data,st.st_mtime)
            if not summarized: report=_explain_report(report)
            return {'ok':True,'name':n,'bytes':size,'summarized':summarized,'report':report}
        finally:
            if fd is not None:
                try: os.close(fd)
                except OSError: pass
    except FileNotFoundError:
        return {'ok':False,'error':'report not found'}
    except OSError as e:
        if getattr(e,'errno',None)==errno.ELOOP:
            return {'ok':False,'error':'report is a symbolic link; refusing to follow it'}
        return {'ok':False,'error':f'cannot read report safely: {e}'}
    except (ValueError,json.JSONDecodeError) as e:
        return {'ok':False,'error':f'cannot read report safely: {e}'}
    except MemoryError:
        return {'ok':False,'error':'report is too large to load into memory; open the file on disk instead'}

def delete_report(name):
    n=Path(str(name)).name
    if n!=str(name) or not n.endswith('.json'):
        return {'ok':False,'error':'invalid report name'}
    path=REPORTS/n
    try:
        st=os.lstat(path)
        if stat.S_ISLNK(st.st_mode):
            return {'ok':False,'error':'report is a symbolic link; refusing to delete it'}
        if not stat.S_ISREG(st.st_mode):
            return {'ok':False,'error':'report is not a regular file'}
        dfd=os.open(str(REPORTS),os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
        try:
            os.unlink(n,dir_fd=dfd)
        finally:
            os.close(dfd)
        log(f'deleted report {n}')
        return {'ok':True}
    except FileNotFoundError:
        return {'ok':False,'error':'report not found'}
    except OSError as e:
        return {'ok':False,'error':f'cannot delete report safely: {e}'}


# Units that must never be stopped/disabled/restarted from the dashboard: doing
# so either cuts off the operator's own access to the box (ssh/networking) or
# disables the security monitoring this daemon exists to provide (locsecd
# itself, and the login-session/system bus other units depend on). 'start' and
# 'enable' are still allowed on any of these -- only the disruptive actions
# are blocked.
# Stopping, restarting or disabling any of these cuts off your own access to the
# machine or to the desktop session the dashboard is displayed in. 'start' and
# 'enable' stay allowed on all of them.
_PROTECTED_UNITS={'locsecd.service','ssh.service','sshd.service','systemd-logind.service',
                   'dbus.service','networking.service','NetworkManager.service','systemd-journald.service',
                   'systemd-udevd.service','systemd-networkd.service',
                   # A desktop session dies with its display manager, taking the
                   # dashboard window with it; polkit is how the GUI reads the token.
                   'display-manager.service','lightdm.service','gdm.service','gdm3.service',
                   'sddm.service','polkit.service','polkitd.service'}
_DISRUPTIVE_ACTIONS={'stop','restart','disable'}

def _normalize_unit(unit):
    # The manual-control box is typed into by hand, so it gets what a person
    # would type: "bluetooth", a pasted name with a stray space, or the full
    # "bluetooth.service". Only the last of those used to be accepted; the
    # other two came back as "invalid unit name", which reads as a rejection
    # of the service rather than of the spelling. Normalise first, and keep
    # the regex as the actual guard.
    u=str(unit or '').strip().strip('\'"')
    if not u: return ''
    # A name beginning with '-' is not a unit, it is an option: `systemctl stop
    # -h.service` prints the help text and exits 0, which this code then reported
    # as a successful stop. Refuse it here rather than hand it to systemctl.
    if u.startswith('-'): return ''
    if not u.endswith('.service'):
        # Only add the suffix when there isn't some other unit type already.
        if '.' not in u.rsplit('/',1)[-1] or u.rsplit('.',1)[-1] not in (
                'socket','timer','target','mount','path','slice','scope','device','swap','automount'):
            u=u.split('.')[0]+'.service' if '.' not in u else u
    return u

def service_action(unit,action):
    if not have('systemctl'): return {'ok':False,'error':'systemctl not installed'}
    raw=str(unit or '').strip()
    unit=_normalize_unit(unit)
    if not unit: return {'ok':False,'error':'enter a unit name'}
    if not re.fullmatch(r'[A-Za-z0-9_.@-]{1,128}\.service',unit):
        return {'ok':False,'error':f'"{raw}" is not a valid service unit name. This page controls .service units only.'}
    if action not in ('start','stop','restart','enable','disable'): return {'ok':False,'error':'invalid action'}
    # Previously every unit outside a five-entry allowlist was refused, while the
    # Services page drew Stop/Restart buttons for every running unit -- so almost
    # every button on that page failed with "restricted to supported LocSec-managed
    # services". The dashboard already requires the root-only API token, so the
    # meaningful limit is the protected set below, not an arbitrary allowlist.
    # An alias (dbus-org.freedesktop.login1.service is systemd-logind) must not
    # get round the protected list: compare the unit systemd resolves it to.
    rc_id,canon=run(['systemctl','show','-p','Id','--value','--',unit],10)
    canon=canon.strip() if rc_id==0 else ''
    if (unit in _PROTECTED_UNITS or canon in _PROTECTED_UNITS) and action in _DISRUPTIVE_ACTIONS:
        incident('service-action','manual',unit,'medium','blocked',f'refused {action}: protected unit')
        return {'ok':False,'error':f'{unit} is protected; {action} is blocked to avoid locking you out or disabling security monitoring'}
    # Consumer-safe default: an authenticated dashboard session is a root-level
    # control plane, so allowing an arbitrary .service unit to be stopped,
    # restarted, enabled or disabled makes a stolen session much more powerful
    # than LocSec needs to be. Keep normal LocSec-managed service control
    # available, but require an explicit local configuration opt-in before the
    # dashboard can manipulate unrelated services. Start/enable of arbitrary
    # units are also gated: a service may contain privileged ExecStart code and
    # therefore is not a harmless read-only operation.
    if unit not in _managed_units() and not CFG.get('allow_manual_service_control',False):
        incident('service-action','manual',unit,'medium','blocked','refused service action: manual service control is disabled by default')
        return {'ok':False,'error':f'{unit} is outside LocSec-managed services. Manual control of unrelated services is disabled by default; set allow_manual_service_control=true in /etc/locsecd/locsecd.conf and restart locsecd if you explicitly need it.'}
    # NOTE: unit=='locsecd.service' and action in ('restart','stop') means this
    # call tells systemd to stop the very process handling this request. This
    # subprocess still returns (systemd-run/systemctl itself isn't killed until
    # the daemon's own process has exited and, for restart, been replaced), but
    # this process may be torn down before the response below is ever written
    # to the socket -- the caller should expect a dropped connection rather
    # than a JSON body in that case, not treat it as a crash.
    before=_unit_state_one(unit)
    if before.get('load')=='not-found':
        return {'ok':False,'unit':unit,'action':action,
                'error':f'{unit} is not installed on this system (systemd reports it as not-found)'}
    # A plain systemctl call. 4.0.11-37 added a retry in a transient unit here,
    # on the theory that this daemon's trimmed CapabilityBoundingSet could make
    # PID 1 refuse a control request. Testing on a real system showed control
    # actions work directly and that the retry never fired -- the original
    # "stop and restart do nothing" was entirely a reporting problem, fixed in
    # -37 and -38. Removed in -40 rather than left in as dead speculation.
    t0=int(time.time())-1
    rc,out=broker('svc.control',unit=unit,action=action)
    # The Overview card and the tool table come from a 30s cache; without this a
    # service you just stopped or started keeps its old state there for half a
    # minute, which reads as the action having done nothing.
    _slow_status_cache['ts']=0.0
    after=_settle_unit_state(unit) if action in ('start','stop','restart') else _unit_state_one(unit)
    # systemctl exiting 0 is not by itself proof the unit did what was asked:
    # confirm against the state systemd reports afterwards, so a silent no-op
    # is reported as a failure here instead of looking like success on a page
    # that then redraws unchanged.
    ok=rc==0
    note=''
    if ok and action in ('start','restart'):
        if after['active'] in _TRANSITIONAL:
            note=f'{unit} is still {after["state"]}; it is taking longer than expected to come up. Check systemctl status {unit}.'
        elif not after['running']:
            ok=False
            note=f'systemctl reported success but {unit} is {after["state"]}.'
            if after.get('file')=='masked':
                note=(f'{unit} is masked, so it cannot start. Unmask it first: '
                      f'sudo systemctl unmask {unit}')
    elif ok and action in ('enable','disable'):
        # ActiveState does not move on enable/disable, so reporting it as the
        # before/after was meaningless here ("running -> running"). The unit
        # file state is what these two actually change.
        fs=after.get('file','')
        if action=='enable' and fs in ('disabled','masked'):
            ok=False; note=f'systemctl reported success but {unit} is {fs}.'
        elif action=='disable' and fs.startswith('enabled'):
            ok=False; note=f'systemctl reported success but {unit} is still {fs}.'
    elif ok and action=='stop':
        # "activating" here is not a partial success -- it means the unit is on
        # its way back up. Judging on ActiveState=='active' alone reported that
        # as a clean stop, which is what "stop bluetooth.service: ok (running
        # -> activating)" was.
        if after['active'] in ('active','activating','reloading','refreshing'):
            ok=False
            note=(f'{unit} is {after["state"]} again -- the stop was undone immediately. '
                  f'Something on the system pulled it back up: D-Bus or socket activation, another '
                  f'unit that Requires= it, or Restart= in its own unit file. '
                  f'Check with: systemctl list-dependencies --reverse {unit}  and  systemctl cat {unit}. '
                  f'A unit like this cannot be held down by stopping it; mask it instead if you really want it off.')
    # A masked unit makes systemctl start/restart/enable exit non-zero, so the
    # masked note above (success branch only) never fired for the real case and
    # the incident read just "rc=1 stopped->stopped". Say so whatever rc was.
    masked=action in ('start','restart','enable') and 'masked' in (after.get('file'),before.get('file'))
    if masked and not note:
        ok=False
        note=(f'{unit} is masked, so it cannot be {"enabled" if action=="enable" else action+"ed"}. Masking is set outside LocSec '
              f'(LocSec never masks units). Unmask it first: sudo systemctl unmask {unit}')
    detail=(out or '').strip()
    if not detail and ok:
        if action in ('enable','disable'):
            detail=f'{unit}: {before.get("file") or "unknown"} -> {after.get("file") or "unknown"}'
        else:
            detail=f'{unit}: {before["state"]} -> {after["state"]}'
    if note: detail=(note+'\n'+detail).strip()
    # On failure, systemctl's own output is only "Job for X failed... see
    # journalctl -xeu X", which told the user nothing (the incident read just
    # "rc=1 stopped->stopped"). Attach the unit's journal from this attempt so
    # the reason -- bad config, port already bound, missing binary -- is in the
    # incident itself.
    why=''
    if not ok and action in ('start','stop','restart') and have('journalctl'):
        jrc,jout=run(['journalctl','--no-pager','-q','-o','short-iso','-u',unit,'--since',f'@{t0}','-n','20'],15)
        if jrc!=0 or not jout.strip():
            jrc,jout=run(['journalctl','--no-pager','-q','-o','short-iso','-u',unit,'-b','-n','20'],15)
        jout=(jout or '').strip() if jrc==0 else ''
        if jout:
            detail=(detail+'\n--- journalctl -u '+unit+' ---\n'+jout).strip()
            # Prefer the unit's own last message over systemd's generic
            # "Failed with result 'exit-code'" trailer.
            jl=jout.splitlines()
            own=[l for l in jl if ' systemd[1]: ' not in l]
            why=(own or jl)[-1][-300:]
    incident('service-action','manual',unit,'low','success' if ok else 'failed',f'{action}: {detail[-1990:] if len(detail)>1990 else detail}')
    log(f'systemctl {action} {unit}: rc={rc} {before["state"]}->{after["state"]}'+(f' last journal line: {why}' if why else ''),'INFO' if ok else 'WARN')
    if action in ('enable','disable'):
        b_state,a_state=before.get('file') or 'unknown',after.get('file') or 'unknown'
    else:
        b_state,a_state=before['state'],after['state']
    return {'ok':ok,'rc':rc,'unit':unit,'action':action,
            'before':b_state,'after':a_state,'file':after.get('file',''),
            'output':detail}

_SLOW_STATUS_TTL=30
_slow_status_cache={'ts':0.0,'data':None}
_STATUS_TOOLS=['ufw','aide','lynis','debsecan','rkhunter','clamscan','clamdscan','tshark','tcpdump','ss','nft','suricata']

def slow_status_parts():
    # Tool presence, firewall state and the running-service list are all
    # expensive (many subprocess spawns) and change rarely, so they are
    # recomputed at most once per _SLOW_STATUS_TTL seconds instead of on every
    # /api/status call.
    now=time.time()
    cached=_slow_status_cache['data']
    if cached is not None and (now-_slow_status_cache['ts'])<_SLOW_STATUS_TTL:
        return cached
    data={
        'tools':{x:have(x) for x in _STATUS_TOOLS},
        'firewall_active':firewall_active(),
        'services':service_list(),
        'missing':missing_components(),
        'exposure':_exposure(),
        'ids':ids_status(),
    }
    _slow_status_cache['ts']=now
    _slow_status_cache['data']=data
    return data

def _exposure():
    """Configuration a remote attacker would look at first, with the fix for each."""
    items=[]
    def add(level,item,detail,fix=''):
        items.append({'level':level,'item':item,'detail':detail,'fix':fix})
    if have('ufw'):
        rc,out=broker('fw.ufw.status',detail='verbose')
        if rc==0 and re.search(r'^Status:\s+active',out,re.M):
            m=re.search(r'Default:\s*(\w+)\s*\(incoming\)',out)
            pol=m.group(1).lower() if m else 'unknown'
            if pol in ('deny','reject'): add('ok','Firewall',f'UFW is active; unsolicited incoming traffic is {"denied" if pol=="deny" else "rejected"} by default.')
            else: add('warn','Firewall',f'UFW is active but the default incoming policy is "{pol}", so anything listening is reachable.','sudo ufw default deny incoming')
        elif _FALLBACK.get('on'):
            add('warn','Firewall',f'UFW is not enabled. LocSec\'s fallback firewall is dropping unsolicited incoming traffic (still allowed: {_fallback_allowed_text(_fallback_ssh_ports())}). Port-scan detection keeps working through it.',
                'sudo ufw enable  (run sudo ufw allow ssh first if you log in remotely); the fallback is removed automatically')
        else:
            add('warn','Firewall','UFW is not enabled: every listening service is reachable from the network.'+('' if CFG.get('fallback_firewall',True) else ' The LocSec fallback firewall is turned off in the response policy.'),'sudo ufw enable  (run sudo ufw allow ssh first if you log in remotely)')
    if have('ss'):
        rc,out=broker('net.sockets',view='listening')
        pub=[]
        if rc==0:
            for line in out.splitlines():
                parts=line.split()
                if len(parts)<5: continue
                local=parts[4]; proc=' '.join(parts[6:]) if len(parts)>6 else ''
                host=local.rsplit(':',1)[0].strip('[]').split('%')[0]
                a=safe_ip(host) if host not in ('*','0.0.0.0','::') else None
                if a is not None and a.is_loopback: continue
                name=(re.search(r'\(\("([^"]+)"',proc) or [None,'unknown'])[1]
                pub.append(f'{parts[0]} {local} ({name})')
        if pub:
            add('warn','Network-facing services',
                f'{len(pub)} socket(s) listen on a non-loopback address: '+'; '.join(pub[:12])+('; ...' if len(pub)>12 else ''),
                'Stop or uninstall any service you do not use; the firewall covers the rest while its incoming policy is deny.')
        else:
            add('ok','Network-facing services','Nothing listens on a network address; every service is local to this machine.')
    if have('sshd'):
        rc,out=broker('ssh.effective_config')
        if rc==0:
            cfg={}
            for line in out.splitlines():
                k,_,v=line.partition(' ')
                cfg[k.lower()]=v.strip().lower()
            bad=[]
            if cfg.get('permitrootlogin') in ('yes',): bad.append('root may log in with a password')
            if cfg.get('passwordauthentication')=='yes': bad.append('password logins are allowed')
            if bad: add('warn','SSH server','OpenSSH is installed and '+' and '.join(bad)+'.',
                        'Use keys, then set PasswordAuthentication no and PermitRootLogin no in /etc/ssh/sshd_config.d/ and run sudo systemctl reload ssh. If you never log in remotely: sudo apt purge openssh-server')
            else: add('ok','SSH server','OpenSSH allows key logins only, and no password login for root.')
    if have('lsblk'):
        rc,out=run(['lsblk','-rno','TYPE'],10)
        if rc==0:
            if 'crypt' in out.split(): add('ok','Disk encryption','An encrypted (LUKS) volume is in use.')
            else: add('warn','Disk encryption','No encrypted volume found: anyone who takes the disk can read it.',
                      'Encryption is chosen at install time (Debian installer: Guided - use entire disk and set up encrypted LVM).')
    return items

def incidents_count():
    # Avoid re-reading and re-parsing up to 10000 JSON lines on every status call;
    # only recount when the incidents log has actually changed on disk.
    try:
        with LOCK:
            _inc_load(); return len(_INC['ids'])
    except Exception: return 0

_AUTH_SUMMARY_TTL=30
_auth_summary_cache={'ts':0.0,'data':None}

def auth_summary():
    # The Overview/Logins pages call /api/status on every page switch, and
    # parse_auth() shells out to journalctl for the whole auth_window each time
    # (seconds of work, a 30s timeout in the worst case). These two numbers are
    # display-only, so serve them from a short cache like slow_status_parts().
    # login_monitor() still calls parse_auth() directly on its own schedule --
    # detection, counting and automatic blocking never read this cache.
    now=time.time()
    data=_auth_summary_cache['data']
    if data is not None and (now-_auth_summary_cache['ts'])<_AUTH_SUMMARY_TTL:
        return data
    fails,success,_raw=parse_auth()
    data=(sum(fails.values()),len(success))
    _auth_summary_cache['ts']=now; _auth_summary_cache['data']=data
    return data

def status():
    slow=slow_status_parts()
    auth_failures,auth_successes=auth_summary()
    try: load=Path('/proc/loadavg').read_text().split()[:3]
    except Exception: load=[]
    return {'version':VERSION,'time':time.time(),'load':load,'idle':idle_enough(),'tools':slow['tools'],'blocks':len(load_blocks()),'auth_failures':auth_failures,'auth_successes':auth_successes,'firewall_active':slow['firewall_active'],'incidents':incidents_count(),'recent_incidents':recent_incidents(20),'services':slow['services'],'missing':slow['missing'],'exposure':slow.get('exposure',[]),'ids':slow.get('ids')}

def health():
    # Cheap liveness endpoint for the 15s frontend ping: no subprocess spawns,
    # no log parsing. Just proves the daemon is alive and responsive.
    try: load=Path('/proc/loadavg').read_text().split()[:3]
    except Exception: load=[]
    return {'ok':True,'version':VERSION,'time':time.time(),'load':load}

# ------------------------------------------------------------------ capture analysis
# The bytes in a capture came off the wire, so whoever sent the packets chose them. Two engines:
#
#  * built-in (default): a small pure-Python pcap/pcapng reader that looks only at the link, IP
#    and TCP/UDP headers. Python is memory-safe, every length is checked before it is used, and
#    the work is capped in bytes, packets and seconds, so a hostile capture can at worst be
#    rejected as corrupt. Wireshark's ~3000 protocol decoders are never involved.
#  * deep (only on request, "Deep analysis (Wireshark)"): tshark, for the full protocol breakdown.
#    It runs as a throwaway unprivileged user (DynamicUser) in a unit with no network, a read-only
#    system, LocSec's state hidden, a system-call filter and resource caps, and it never opens the
#    capture itself: LocSec opens the file and passes it on stdin. A decoder bug therefore lands in
#    a process that can read nothing private, write nothing, and reach nothing.
_PCAP_MAX_BYTES=1<<30
_PCAP_MAX_PKTS=3000000
_PCAP_MAX_SECS=60
_PCAP_MAX_REC=1<<20
_PCAPNG_MAX_BLOCK=16<<20
_PCAP_MAX_PAIRS=200000
_APP_PORTS={20:'FTP data',21:'FTP',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',67:'DHCP',68:'DHCP',69:'TFTP',80:'HTTP',
    110:'POP3',123:'NTP',137:'NetBIOS',138:'NetBIOS',139:'NetBIOS',143:'IMAP',161:'SNMP',162:'SNMP trap',389:'LDAP',
    443:'HTTPS/TLS',445:'SMB',465:'SMTPS',500:'IKE',514:'Syslog',587:'SMTP submission',631:'IPP printing',636:'LDAPS',
    853:'DNS over TLS',993:'IMAPS',995:'POP3S',1194:'OpenVPN',1900:'SSDP',3306:'MySQL',3389:'RDP',3478:'STUN',
    4500:'IPsec NAT-T',5222:'XMPP',5228:'Google push',5353:'mDNS',5355:'LLMNR',5432:'PostgreSQL',5900:'VNC',
    6379:'Redis',6667:'IRC',6697:'IRC/TLS',8080:'HTTP alt',8443:'HTTPS alt',27017:'MongoDB',51820:'WireGuard'}

class _CapErr(Exception): pass

def _pcap_records(fh, st):
    """(linktype, packet bytes) for every packet in a pcap or pcapng file, with every length checked."""
    head=fh.read(4)
    if len(head)<4: raise _CapErr('the file is empty or too short to be a capture')
    if head==b'\x0a\x0d\x0d\x0a':
        yield from _pcapng_records(fh, st); return
    if head in (b'\xd4\xc3\xb2\xa1',b'\x4d\x3c\xb2\xa1'): end='<'
    elif head in (b'\xa1\xb2\xc3\xd4',b'\xa1\xb2\x3c\x4d'): end='>'
    else: raise _CapErr('this is not a pcap or pcapng file')
    rest=fh.read(20)
    if len(rest)<20: raise _CapErr('the capture header is truncated')
    link=struct.unpack(end+'I',rest[16:20])[0]&0xFFFF
    while True:
        h=fh.read(16)
        if len(h)<16: return
        incl=struct.unpack(end+'I',h[8:12])[0]
        if incl>_PCAP_MAX_REC: raise _CapErr(f'a packet record claims {incl} bytes; the file is corrupt or crafted')
        data=fh.read(incl)
        if len(data)<incl: st['truncated']=True; return
        st['bytes']+=16+incl
        yield link,data

def _pcapng_records(fh, st):
    links=[]; end=None; first=True
    while True:
        if first: tb=b'\x0a\x0d\x0d\x0a'; first=False
        else:
            tb=fh.read(4)
            if len(tb)<4: return
        lb=fh.read(4)
        if len(lb)<4: st['truncated']=True; return
        if tb==b'\x0a\x0d\x0d\x0a':            # section header: byte order, and a fresh interface list
            bom=fh.read(4)
            if bom==b'\x4d\x3c\x2b\x1a': end='<'
            elif bom==b'\x1a\x2b\x3c\x4d': end='>'
            else: raise _CapErr('bad pcapng byte-order mark')
            blen=struct.unpack(end+'I',lb)[0]
            if blen<28 or blen>_PCAPNG_MAX_BLOCK or blen%4: raise _CapErr('corrupt pcapng section header')
            skip=fh.read(blen-12)
            if len(skip)<blen-12: st['truncated']=True; return
            links=[]; st['bytes']+=blen; continue
        if end is None: raise _CapErr('pcapng file without a section header')
        btype=struct.unpack(end+'I',tb)[0]; blen=struct.unpack(end+'I',lb)[0]
        if blen<12 or blen>_PCAPNG_MAX_BLOCK or blen%4: raise _CapErr(f'corrupt pcapng block length {blen}')
        body=fh.read(blen-8)
        if len(body)<blen-8: st['truncated']=True; return
        st['bytes']+=blen
        if btype==1:                                    # interface description
            if len(body)>=2 and len(links)<256: links.append(struct.unpack(end+'H',body[:2])[0])
        elif btype==6:                                  # enhanced packet
            if len(body)<24: continue
            ifid=struct.unpack(end+'I',body[0:4])[0]; cap=struct.unpack(end+'I',body[12:16])[0]
            if ifid>=len(links) or cap>len(body)-24: st['bad']+=1; continue
            yield links[ifid],body[20:20+cap]
        elif btype==3 and links:                        # simple packet
            if len(body)<8: continue
            orig=struct.unpack(end+'I',body[0:4])[0]
            yield links[0],body[4:4+min(orig,len(body)-8)]

def _cap_decode(link, d, st, pairs):
    et=None; off=0
    if link==1:                                         # Ethernet, with up to two VLAN tags
        if len(d)<14: st['bad']+=1; return
        et=int.from_bytes(d[12:14],'big'); off=14
        for _ in range(2):
            if et in (0x8100,0x88a8) and len(d)>=off+4: et=int.from_bytes(d[off+2:off+4],'big'); off+=4
        st['link']['Ethernet']=st['link'].get('Ethernet',0)+1
    elif link==113:                                     # Linux cooked (tcpdump -i any)
        if len(d)<16: st['bad']+=1; return
        et=int.from_bytes(d[14:16],'big'); off=16; st['link']['Linux cooked']=st['link'].get('Linux cooked',0)+1
    elif link==276:                                     # Linux cooked v2
        if len(d)<20: st['bad']+=1; return
        et=int.from_bytes(d[0:2],'big'); off=20; st['link']['Linux cooked v2']=st['link'].get('Linux cooked v2',0)+1
    elif link in (12,14,101,228,229):                   # raw IP
        if not d: st['bad']+=1; return
        v=d[0]>>4; et=0x0800 if v==4 else 0x86dd if v==6 else None; st['link']['Raw IP']=st['link'].get('Raw IP',0)+1
    elif link in (0,108):                               # BSD loopback / null
        if len(d)<5: st['bad']+=1; return
        v=d[4]>>4; et=0x0800 if v==4 else 0x86dd if v==6 else None; off=4
        st['link']['Loopback']=st['link'].get('Loopback',0)+1
    else:
        st['link'][f'link type {link}']=st['link'].get(f'link type {link}',0)+1; return
    if et==0x0806: st['l3']['ARP']+=1; return
    if et==0x0800:
        ip=d[off:]
        if len(ip)<20: st['bad']+=1; return
        ihl=(ip[0]&15)*4
        if ihl<20 or len(ip)<ihl: st['bad']+=1; return
        proto=ip[9]; src=socket.inet_ntop(socket.AF_INET,ip[12:16]); dst=socket.inet_ntop(socket.AF_INET,ip[16:20])
        frag=int.from_bytes(ip[6:8],'big')&0x1FFF
        st['l3']['IPv4']+=1; l4=ip[ihl:] if frag==0 else None
    elif et==0x86dd:
        ip=d[off:]
        if len(ip)<40: st['bad']+=1; return
        proto=ip[6]; src=socket.inet_ntop(socket.AF_INET6,ip[8:24]); dst=socket.inet_ntop(socket.AF_INET6,ip[24:40])
        p=40; st['l3']['IPv6']+=1
        for _ in range(8):                              # skip extension headers, bounded
            if proto in (0,43,60,51):
                if len(ip)<p+2: proto=-1; break
                ln=(ip[p+1]+2)*4 if proto==51 else (ip[p+1]+1)*8
                proto=ip[p]; p+=ln
            elif proto==44:
                if len(ip)<p+8: proto=-1; break
                fo=int.from_bytes(ip[p+2:p+4],'big')>>3; proto=ip[p]; p+=8
                if fo: proto=-1; break
            else: break
        l4=ip[p:] if 0<=proto and p<=len(ip) else None
    else:
        st['l3']['Other']+=1; return
    name={6:'TCP',17:'UDP',1:'ICMP',58:'ICMPv6',2:'IGMP',47:'GRE',50:'ESP',132:'SCTP'}.get(proto,'Other')
    st['l4'][name]=st['l4'].get(name,0)+1
    port=''; pname=''
    if proto in (6,17) and l4 is not None and len(l4)>=4:
        sp=int.from_bytes(l4[0:2],'big'); dp=int.from_bytes(l4[2:4],'big')
        # name the conversation by its service port: a known one, else the lower one
        svc=dp if (dp in _APP_PORTS or (dp<1024 and not sp in _APP_PORTS)) else sp if (sp in _APP_PORTS or sp<1024) else dp
        port=str(svc); pname=_APP_PORTS.get(svc,'')
        if pname: st['app'][pname]=st['app'].get(pname,0)+1
        else: st['app']['other ports']=st['app'].get('other ports',0)+1
    st['ip']+=1
    k=(src,dst,port,name.lower() if name in ('TCP','UDP') else '')
    if k in pairs or len(pairs)<_PCAP_MAX_PAIRS: pairs[k]=pairs.get(k,0)+1

def _builtin_capture_summary(path):
    st={'frames':0,'bytes':0,'ip':0,'bad':0,'truncated':False,'stopped':'',
        'link':{},'l3':{'IPv4':0,'IPv6':0,'ARP':0,'Other':0},'l4':{},'app':{}}
    pairs={}; deadline=time.time()+_PCAP_MAX_SECS
    fd=os.open(str(path),os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    with os.fdopen(fd,'rb',buffering=1<<20) as fh:
        if not stat.S_ISREG(os.fstat(fh.fileno()).st_mode): raise _CapErr('not a regular file')
        for link,data in _pcap_records(fh, st):
            st['frames']+=1
            try: _cap_decode(link,data,st,pairs)
            except (ValueError,IndexError,struct.error,OSError): st['bad']+=1
            if st['frames']>=_PCAP_MAX_PKTS: st['stopped']=f'stopped after {_PCAP_MAX_PKTS:,} packets'; break
            if st['bytes']>=_PCAP_MAX_BYTES: st['stopped']=f'stopped after {_PCAP_MAX_BYTES>>20} MB'; break
            if st['frames']%5000==0 and time.time()>deadline: st['stopped']=f'stopped after {_PCAP_MAX_SECS} seconds'; break
    def line(title,d):
        items=[(k,v) for k,v in sorted(d.items(),key=lambda kv:-kv[1]) if v]
        return f'{title}: '+(', '.join(f'{k} {v:,}' for k,v in items) if items else 'none')
    out=[f'Frames: {st["frames"]:,} ({st["bytes"]:,} bytes read)',
         line('Link layer',st['link']),line('Network layer',st['l3']),line('Transport',st['l4']),
         line('Applications (guessed from the service port)',st['app'])]
    if st['bad']: out.append(f'Malformed or too-short packets skipped: {st["bad"]:,}')
    if st['truncated']: out.append('The file ends mid-packet (capture still recording, or cut short); everything before that was read.')
    if st['stopped']: out.append(f'Analysis {st["stopped"]}; the rest of the file was not read.')
    return st,pairs,'\n'.join(out)

# tshark runs as a throwaway user in a unit that can read nothing private and reach nothing.
_TSHARK_PROPS=['DynamicUser=yes','PrivateNetwork=yes','IPAddressDeny=any','PrivateDevices=yes','PrivateTmp=yes',
    'ProtectSystem=strict','ProtectHome=yes','ProtectKernelTunables=yes','ProtectKernelModules=yes','ProtectKernelLogs=yes',
    'ProtectControlGroups=yes','ProtectProc=invisible','ProcSubset=pid','NoNewPrivileges=yes','RestrictSUIDSGID=yes',
    'RestrictNamespaces=yes','RestrictAddressFamilies=AF_UNIX','RemoveIPC=yes','UMask=0077',
    'InaccessiblePaths=-/var/lib/locsecd -/etc/locsecd -/root -/var/log -/etc/ssl/private -/etc/shadow -/etc/gshadow',
    'SystemCallFilter=@system-service','SystemCallFilter=~@mount @debug @module @reboot @swap @clock @raw-io @obsolete @cpu-emulation',
    'SystemCallErrorNumber=EPERM','MemoryMax=512M','TasksMax=32','LimitCORE=0','CPUQuota=100%',
    'Environment=HOME=/tmp','Environment=WIRESHARK_CONFIG_DIR=/tmp']

def analyze_capture(name, deep=False):
    n=Path(str(name)).name
    if n!=str(name) or not n.endswith('.pcapng'):
        return {'ok':False,'error':'invalid capture name'}
    path=(CAPTURES/n).resolve()
    try: path.relative_to(CAPTURES.resolve())
    except ValueError: return {'ok':False,'error':'invalid capture path'}
    if not path.is_file(): return {'ok':False,'error':'capture not found'}
    if not deep:
        try: st,pairs,summary=_builtin_capture_summary(path)
        except _CapErr as e: return {'ok':False,'name':n,'engine':'builtin','error':f'Could not read {n}: {e}.'}
        except OSError as e: return {'ok':False,'name':n,'engine':'builtin','error':f'Could not open {n}: {e.strerror or e}'}
        top=[{'src':a,'dst':b,'port':pt,'proto':pr,'packets':c,'door':(_PORT_NAMES.get(int(pt),'') or _APP_PORTS.get(int(pt),'')) if pt.isdigit() else ''}
             for (a,b,pt,pr),c in sorted(pairs.items(),key=lambda kv:-kv[1])[:25]]
        return {'ok':True,'name':n,'engine':'builtin','protocols':summary,'top':top,'ip_packets':st['ip'],
                'pairs':len(pairs),'frames':st['frames'],'deep_available':have('tshark') and bool(CFG.get('capture_deep_analysis',True)),'rc':0}
    if not CFG.get('capture_deep_analysis',True):
        return {'ok':False,'name':n,'engine':'tshark','error':'Deep analysis is turned off (capture_deep_analysis is false in /etc/locsecd/locsecd.conf).'}
    if not have('tshark'): return {'ok':False,'name':n,'engine':'tshark','error':'tshark is not installed; the built-in analysis still works.'}
    def _tshark(mode):
        # Opened here and handed over: the broker never opens a path in this half's directories.
        fd=os.open(str(path),os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
        try: return broker('job.tshark',mode=mode,capture=PassFD(fd))
        finally: os.close(fd)
    rc,summary=_tshark('summary')
    # One line per packet: keep up to 16 MB of it (the default 20 KB tail undercounted every real capture).
    rc2,endpoints=_tshark('endpoints')
    partial=len(str(endpoints))>=(16<<20)-64
    pairs={}; packets=0
    for line in str(endpoints).splitlines():
        f=line.split('|')
        if len(f)<4 or not (f[0] or f[1]): continue
        packets+=1
        port=f[2] or f[3]; proto='tcp' if f[2] else ('udp' if f[3] else '')
        k=(f[0][:64],f[1][:64],port.split(',')[0][:8],proto)
        if k in pairs or len(pairs)<_PCAP_MAX_PAIRS: pairs[k]=pairs.get(k,0)+1
    top=[{'src':a,'dst':b,'port':pt,'proto':pr,'packets':c,'door':(_PORT_NAMES.get(int(pt),'') if pt.isdigit() else '')}
         for (a,b,pt,pr),c in sorted(pairs.items(),key=lambda kv:-kv[1])[:25]]
    lines=[l for l in str(summary).splitlines() if l.strip() and not set(l.strip())<={'='}]
    ok=rc==0 or rc2==0
    prot='\n'.join(lines)[-20000:]
    if partial: prot+='\n(The capture is very large: the conversation table covers only its last part. The protocol breakdown above covers all of it.)'
    out={'ok':ok,'name':n,'engine':'tshark','protocols':prot,'top':top,'ip_packets':packets,
         'pairs':len(pairs),'rc':rc if rc!=0 else rc2}
    if not ok: out['error']=('Wireshark could not analyze this capture inside its sandbox (exit code '+str(out['rc'])+'). '
                             'The built-in analysis still works. Output: '+'\n'.join(lines)[-600:])
    return out

def _capture_path(name):
    n=Path(str(name)).name
    if n!=str(name) or not n.endswith('.pcapng'): return None
    path=CAPTURES/n
    try: path.parent.resolve().relative_to(CAPTURES.resolve())
    except ValueError: return None
    return path

def start_capture(iface,seconds):
    """Create the capture file (this half owns it) and have the broker run tcpdump into it.
    Returns (json_body, http_status)."""
    fn=CAPTURES/f'capture-{datetime.now().strftime("%Y%m%d-%H%M%S-%f")}.pcapng'
    try: fd=os.open(str(fn),os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    except OSError as e: return {'error':f'could not create the capture file: {e}'},500
    try: res,code=broker('capture.start',iface=iface,seconds=int(seconds),out=PassFD(fd))
    finally: os.close(fd)
    if code!=200 or not (isinstance(res,dict) and res.get('ok')):
        try: os.unlink(str(fn))
        except OSError: pass
        return res,code
    def cleanup():
        # tcpdump that died at once (an unknown interface, say) leaves a zero-byte file.
        time.sleep(int(seconds)+15)
        try:
            if os.stat(str(fn)).st_size==0: os.unlink(str(fn))
        except OSError: pass
    threading.Thread(target=cleanup,daemon=True).start()
    log(f'packet capture started {fn} iface={iface} duration={seconds}s')
    return {'ok':True,'file':str(fn)},200

def delete_capture(name):
    """Delete one saved capture. One still being recorded is stopped first."""
    path=_capture_path(name)
    if path is None: return {'ok':False,'error':'invalid capture name'}
    # A capture still recording into this file is stopped first (the broker runs tcpdump).
    running=0
    try:
        st=os.lstat(path)
        if stat.S_ISREG(st.st_mode): running=broker('capture.stop',dev=st.st_dev,ino=st.st_ino) or 0
    except OSError: pass
    try:
        if path.is_symlink() or path.is_file(): path.unlink()
        else: return {'ok':False,'error':'capture not found'}
    except OSError as e: return {'ok':False,'error':str(e)}
    log(f'deleted packet capture {path.name}'+(' (it was still recording; stopped first)' if running else ''),'WARN')
    return {'ok':True,'deleted':path.name,'was_running':bool(running)}

def delete_all_captures():
    running=broker('capture.stop_all') or 0
    n=0
    try: entries=list(CAPTURES.glob('*.pcapng'))
    except OSError: entries=[]
    for f in entries:
        try:
            if f.is_symlink() or f.is_file(): f.unlink(); n+=1
        except OSError: pass
    log(f'deleted all packet captures ({n} files)','WARN')
    return {'ok':True,'deleted':n,'stopped':running}

def _terminate_capture(proc, wait=True):
    # wait=False is for the signal handler: ask the capture to stop, but do
    # not block waiting for it. See _shutdown_handler.
    if proc is None or proc.poll() is not None:
        return
    try: os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError: return
    except Exception: pass
    if not wait: return
    try: proc.wait(timeout=5)
    except Exception:
        try: os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        except Exception: pass
        try: proc.wait(timeout=5)
        except Exception: pass


STOP_EVENT=threading.Event()

def _shutdown_handler(signum, frame):
    # This runs on the main thread, interrupting whatever it was doing, and
    # every second spent here comes out of the unit's TimeoutStopSec=30 budget
    # before systemd sends SIGKILL. So it does the least possible: set the
    # stop flag and ask any capture to exit. It does NOT wait for them.
    #
    # It used to wait: _terminate_capture() blocks up to 5s for SIGTERM and
    # another 5s after SIGKILL, so three hung captures could burn the whole
    # 30s here. systemd would then SIGKILL us mid-handler and server()'s
    # cleanup would never run -- meaning the sibling transient units
    # (apt/aideinit/scan jobs) would be left running unsupervised, which is
    # the exact thing that cleanup exists to prevent. The waiting now happens
    # in server()'s finally, outside signal context, where it belongs.
    #
    # Not taking CAPTURE_LOCK is also deliberate: blocking on a lock another
    # thread already holds would deadlock the shutdown. Copying the list is
    # atomic enough, and anything started microseconds later is still reached
    # by the cgroup teardown and by server()'s own cleanup.
    STOP_EVENT.set()
    for proc in list(ACTIVE_CAPTURES):
        _terminate_capture(proc, wait=False)


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    request_queue_size=32
    max_workers=32

    def __init__(self,*args,tls_context=None,**kwargs):
        super().__init__(*args,**kwargs)
        self._slots=threading.BoundedSemaphore(self.max_workers)
        if tls_context is not None:
            # Wrap the listening socket. The handshake is deferred to the first read, which
            # happens in the worker thread under Handler.timeout, so a client that connects and
            # then goes quiet cannot hold up the accept loop.
            self.socket=tls_context.wrap_socket(self.socket,server_side=True,do_handshake_on_connect=False)

    def handle_error(self,request,client_address):
        # A browser that does not accept the certificate, a plain-HTTP client talking to the
        # HTTPS port, or a client that simply hangs up are routine; the default prints a
        # traceback to the journal for every one of them.
        et=sys.exc_info()[0]
        if et is not None and issubclass(et,(ssl.SSLError,ConnectionError,TimeoutError)):
            return
        super().handle_error(request,client_address)

    def process_request(self,request,client_address):
        if not self._slots.acquire(blocking=False):
            try: request.close()
            except Exception: pass
            return
        try:
            super().process_request(request,client_address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self,request,client_address):
        try:
            super().process_request_thread(request,client_address)
        finally:
            self._slots.release()

class Handler(BaseHTTPRequestHandler):
    # A ThreadingHTTPServer spawns one thread per connection with no built-in
    # cap; a handful of slow/idle clients holding sockets open (Slowloris)
    # can pin threads indefinitely if this is ever exposed beyond loopback.
    # `timeout` makes socketserver abort a connection that goes quiet for
    # this long instead of waiting forever.
    timeout=30
    def log_message(self,*args): pass
    def auth(self):
        # Valid credentials are always accepted, even during a burst of failures: otherwise any local user
        # could lock the administrator out of the dashboard just by sending wrong tokens.
        ok=self._auth_check()
        if not ok and (self.headers.get('X-LocSec-Token') or COOKIE in self.headers.get('Cookie','')): _auth_failed()
        return ok
    def _auth_check(self):
        tok=token_value()
        header=self.headers.get('X-LocSec-Token','')
        if header and hmac.compare_digest(header.encode('utf-8','replace'),tok.encode()): return True
        for item in self.headers.get('Cookie','').split(';'):
            k,_,v=item.strip().partition('=')
            if k==COOKIE and v and session_ok(v): return True
        return False
    def sendj(self,obj,code=200):
        data=json.dumps(obj,default=str).encode()
        try:
            self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','no-referrer'); self.send_header('Cross-Origin-Resource-Policy','same-origin'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        except (BrokenPipeError,ConnectionError,OSError) as e:
            # The client went away (shell timeout, closed window, network blip) while a long job was
            # running. The job itself is unaffected and its report is on disk; one WARN line is enough.
            log(f'client disconnected before the response could be sent ({type(e).__name__}); the job result was not lost','WARN')
    def _host_ok(self):
        # A page elsewhere can point its own hostname at 127.0.0.1 (DNS
        # rebinding) and then talk to this port as if it were same-origin.
        # The token still stops it, but only requests addressed to this
        # machine by name are answered at all.
        host=(self.headers.get('Host') or '').strip().lower()
        return host in {f'127.0.0.1:{CFG["port"]}',f'localhost:{CFG["port"]}','127.0.0.1','localhost'}
    def do_GET(self):
        if not self._host_ok(): return self.sendj({'error':'unexpected Host header'},421)
        path=self.path.split('?',1)[0]
        self._code_ok=False
        if path=='/dashboard' and not self.auth():
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            if q.get('code',[''])[0]:
                self._code_ok=consume_login_code(q.get('code',[''])[0])
                if not self._code_ok:
                    _auth_failed()
                    return self.sendj({'error':'unauthorized: login code expired or already used -- open LocSec again'},429 if _auth_locked() else 401)
            else: return self.sendj({'error':'unauthorized'},401)
        elif not self.auth(): return self.sendj({'error':'too many failed logins; wait a minute'} if _auth_locked() else {'error':'unauthorized'},429 if _auth_locked() else 401)
        if path=='/api/health': return self.sendj(health())
        if path=='/api/job':
            cur=JOB_LOCK.current()
            return self.sendj({'running':cur,'message':JOB_LOCK.busy_message() if cur else 'No maintenance job is running.',
                               'external':None if cur else external_aide(),'schedule':schedule_status(),'aide_pending':aide_pending_differs()})
        if path=='/api/status': return self.sendj(status())
        if path=='/api/ids': return self.sendj(ids_overview())
        if path=='/api/blocks/explained':
            rows=[explain_block(k,v) for k,v in load_blocks().items()]
            rows.sort(key=lambda r:-(float(r.get('added') or 0)))
            return self.sendj({'blocks':rows[:500],'total':len(rows)})
        if path=='/api/log-sources':
            avail=[]
            for key,src in LOG_SOURCES.items():
                p=next((p for p in _source_paths(key,src) if _pexists(p)),None)
                if p is None and _source_journal(src,1):
                    avail.append({'key':key,'label':src['label'],'available':True,'clearable':False,
                                  'path':f"systemd journal ({src.get('jlabel','')})"}); continue
                regular=False
                if p is not None:
                    try: regular=stat.S_ISREG(p.lstat().st_mode)   # lstat: a symlink here is not a log this may clear
                    except OSError: regular=False
                avail.append({'key':key,'label':src['label'],'available':p is not None,
                              # Match clear_log()'s own test, so the page never
                              # offers a Clear button that is certain to fail.
                              'clearable':key in _LOG_CLEARABLE and regular,
                              'path':str(p) if p else str(src['paths'][0])})
            return self.sendj({'sources':avail})
        if path=='/api/logs':
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            src_key=q.get('source',['locsecd'])[0]
            if src_key not in LOG_SOURCES: src_key='locsecd'
            src=LOG_SOURCES[src_key]
            # The firewall view is the one people read entry by entry, so it
            # gets a longer stretch of history than the others.
            nlines=1000 if src_key=='ufw' else 500
            def _reply(lines,path,fpath=None):
                ev=friendly_log(src_key,lines,fpath)
                out={'lines':lines,'path':path,'events':ev,'source':src_key}
                if src_key=='ufw': out['summary']=ufw_summary(ev)
                return self.sendj(out)
            p=next((p for p in _source_paths(src_key,src) if _pexists(p)),None)
            if p is None:
                jt=_source_journal(src,nlines)
                if jt: return _reply(jt.splitlines()[-nlines:],f"systemd journal ({src.get('jlabel','')})")
                why=f"{src['paths'][0]} does not exist"+(' and the systemd journal has no matching entries' if 'jargs' in src else '')
                if src.get('hint'): why+=f" -- {src['hint']}"
                return self.sendj({'lines':[],'path':None,'error':why,'events':[],'source':src_key})
            if src_key=='suricata' and p.name.endswith('.json'):
                lines,stats=ids_recent_alerts(limit=nlines)
                if not lines:
                    why=_ids_why_empty(ids_status(),stats,[])
                    return self.sendj({'lines':[],'path':str(p),'events':[{'ts':None,'lvl':'info','title':'No alerts','text':why,'raw':''}],'source':src_key})
                return _reply(lines,f'{p} (alert records only; {stats["records"]:,} records scanned)')
            try:
                # readable-only; large files are tailed rather than fully loaded.
                # An AIDE check prints its verdict and counts first, so that one
                # is read from the top.
                full_aide=src_key=='aide' and p.name.startswith('aide-full-')
                rc,out=run(['head' if full_aide else 'tail','-n',str(nlines),str(p)],10,tail=4000000)
                lines=out.splitlines() if rc==0 else _tail_lines(p,nlines,4000000)
                return _reply(lines,str(p),str(p) if full_aide else None)
            except PermissionError:
                return self.sendj({'lines':[],'path':str(p),'error':'permission denied (LocSec could not read this file; try sudo tail on it directly)'})
            except Exception as e:
                return self.sendj({'lines':[],'path':str(p),'error':str(e)})
        if path=='/api/reports': return self.sendj({'reports':[x.name for x in sorted(REPORTS.glob('*.json'),reverse=True)[:50]]})
        if path=='/api/ports':
            rc,out=broker('net.sockets',view='listening_table',timeout=30); return self.sendj({'output':out})
        if path=='/api/firewall':
            rc,out=broker('fw.ufw.status',detail='verbose'); return self.sendj({'rc':rc,'output':out})
        if path=='/api/feeds':
            # Counts only. Sending the full arrays meant the Threat Intelligence
            # page downloaded and parsed the entire indicator database (megabytes)
            # just to render three numbers -- the same failure mode as the oversize
            # report view. Reputation lookups are answered server-side by
            # /api/reputation, which reads the file directly.
            try:
                f=_feeds()
                return self.sendj({'updated':f.get('updated'),'interval_seconds':f.get('interval_seconds'),
                                   'last_attempt':f.get('last_attempt'),'last_attempt_ok':f.get('last_attempt_ok',True),
                                   'sources':f.get('sources',[]),'errors':f.get('errors',[])[:20],
                                   'domains':len(f.get('domains',[])),'ips':len(f.get('ips',[])),
                                   'networks':len(f.get('networks',[]))})
            except Exception: return self.sendj({'domains':0,'ips':0,'networks':0,'sources':[],'errors':[]})
        if path=='/api/captures':
            rows=[]
            busy={tuple(x) for x in (broker('capture.active') or []) if isinstance(x,list) and len(x)==2}
            for x in sorted(CAPTURES.glob('*.pcapng'),reverse=True)[:50]:
                try: st=x.stat()
                except OSError: continue
                rows.append({'name':x.name,'size':st.st_size,'mtime':st.st_mtime,'recording':(st.st_dev,st.st_ino) in busy})
            return self.sendj({'captures':[r['name'] for r in rows],'items':rows})
        if path=='/api/quarantine/list': return self.sendj(list_quarantine())
        if path=='/api/incidents':
            incs=recent_incidents(300)
            for i in incs:
                try: i['can_fix']=incident_can_fix(i)
                except Exception: i['can_fix']=False
            return self.sendj({'incidents':incs,'notify_on':CFG.get('notify_on',{})})
        if path=='/api/notify-settings': return self.sendj({'notify_on':CFG.get('notify_on',{})})
        if path=='/api/notifications': return self.sendj({'items':list(reversed(_notify_history(200)))})
        if path=='/api/connections': return self.sendj({'connections':network_connections()})
        if path=='/api/services': return self.sendj({'services':service_list()})
        if path=='/api/response-policy': return self.sendj({'policy':{k:CFG.get(k) for k in _POLICY_KEYS}})
        if path=='/dashboard':
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            cookie_ok=self.auth()
            # Only a single-use login code (minted with the API token) starts a session.
            token_ok=self._code_ok
            if not cookie_ok and not token_ok: return self.sendj({'error':'unauthorized'},401)
            if token_ok and not cookie_ok:
                # Fresh login via a single-use code: exchange it for a session
                # cookie and redirect to the bare URL. The cookie is a random,
                # expiring session id, not the API token.
                self.send_response(302)
                self.send_header('Set-Cookie',f'{COOKIE}={new_session()}; HttpOnly; Secure; SameSite=Strict; Path=/')
                self.send_header('Location','/dashboard')
                self.send_header('Cache-Control','no-store'); self.send_header('Content-Length','0'); self.end_headers()
                return
            html=DASHBOARD.replace('__REPORT_DAYS__',str(int(CFG.get('report_retention_days',7))))
            data=html.encode(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'");
            self.send_header('X-Frame-Options','DENY'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','no-referrer'); self.send_header('Cache-Control','no-store'); self.send_header('Cross-Origin-Opener-Policy','same-origin'); self.send_header('Cross-Origin-Resource-Policy','same-origin'); self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=(), payment=(), usb=()'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        return self.sendj({'error':'not found'},404)
    def _same_origin(self):
        # Defence in depth behind the SameSite=Strict session cookie: a browser
        # attaches Origin to every cross-site POST, so anything that arrives
        # with a foreign Origin is refused even if it somehow carried the
        # cookie. Requests with no Origin at all (curl, locsecctl, the GUI's
        # own XHR on some Qt builds) are unaffected -- those cannot be driven
        # by a third-party page in the first place.
        origin=self.headers.get('Origin')
        if not origin: return True
        try: o=urllib.parse.urlsplit(origin)
        except ValueError: return False
        return bool(o.netloc) and o.netloc==self.headers.get('Host','')
    def do_POST(self):
        if not self._host_ok(): return self.sendj({'error':'unexpected Host header'},421)
        if not self.auth(): return self.sendj({'error':'too many failed logins; wait a minute'} if _auth_locked() else {'error':'unauthorized'},429 if _auth_locked() else 401)
        if not self._same_origin(): return self.sendj({'error':'cross-origin request refused'},403)
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n < 0 or n > MAX_BODY: return self.sendj({'error':'request body too large'},413)
            body=json.loads(self.rfile.read(n) or b'{}')
            if not isinstance(body,dict): return self.sendj({'error':'JSON object required'},400)
        except Exception: return self.sendj({'error':'bad json'},400)
        p=self.path.split('?',1)[0]
        try:
            if p=='/api/login-code':
                c=mint_login_code()
                return self.sendj({'ok':True,'code':c,'ttl':_LOGIN_CODE_TTL} if c else {'ok':False,'error':'too many outstanding login codes; wait a minute'},200 if c else 429)
            if p=='/api/incident/action': return self.sendj(incident_action(body.get('id',''),body.get('action','')))
            if p=='/api/incident/delete': return self.sendj(delete_incident(body.get('id','')))
            if p=='/api/incident/delete-all': return self.sendj(delete_all_incidents())
            if p=='/api/response-policy':
                allowed=set(_POLICY_KEYS)
                changed={}
                for k,v in body.items():
                    if k in allowed and isinstance(v,bool): CFG[k]=v; changed[k]=v
                if changed:
                    with LOCK:
                        try: persisted=json.loads(RUNTIME_POLICY.read_text())
                        except Exception: persisted={}
                        if not isinstance(persisted,dict): persisted={}
                        persisted.update(changed)
                        atomic_json(RUNTIME_POLICY,persisted)
                log(f'response policy changed: {changed}')
                return self.sendj({'ok':True,'changed':changed})
            if p=='/api/notify-test':
                if not (have('notify-send') or have('gdbus')): return self.sendj({'ok':False,'error':'Neither notify-send nor gdbus is installed. Install it with: sudo apt install libnotify-bin'})
                users=_desktop_users()
                if not users: return self.sendj({'ok':False,'error':'No local graphical session is active, so there is nowhere to show a notification.'})
                # Sent now rather than queued, so the answer says whether the desktop really showed it.
                sent=[_desktop_send(u,'test','LocSec: '+_NOTIFY_TITLES.get('test','Test notification'),'Desktop notifications from LocSec are working.') for u in users]
                if not any(sent):
                    return self.sendj({'ok':False,'error':'LocSec found your desktop session, but the notification could not be shown. '
                                       'The reason is in: sudo journalctl -t locsecd-broker -n 20'})
                return self.sendj({'ok':True,'sessions':sum(sent)})
            if p=='/api/notifications/clear': return self.sendj(clear_notify_history())
            if p=='/api/notify-settings':
                cur=dict(CFG.get('notify_on',{}))
                changed={}
                for k,v in body.items():
                    # Only the kinds the dashboard offers; anything else would grow
                    # the configuration (and every response carrying it) unbounded.
                    if isinstance(v,bool) and k in _NOTIFY_KINDS: cur[k]=v; changed[k]=v
                CFG['notify_on']=cur
                if changed:
                    with LOCK:
                        try: persisted=json.loads(RUNTIME_POLICY.read_text())
                        except Exception: persisted={}
                        if not isinstance(persisted,dict): persisted={}
                        no=dict(persisted.get('notify_on',{})) if isinstance(persisted.get('notify_on'),dict) else {}
                        no.update(changed); persisted['notify_on']=no
                        atomic_json(RUNTIME_POLICY,persisted)
                log(f'notification settings changed: {changed}')
                return self.sendj({'ok':True,'notify_on':cur})
            if p=='/api/block':
                ok,msg=block_ip(body.get('ip',''),body.get('reason','manual'),'manual')
                if msg=='allowlisted': msg='that address is on your own network (allow_ips), and LocSec never blocks those'
                return self.sendj({'ok':ok,'message':str(msg)[:500]} if ok else {'ok':False,'error':str(msg)[:500]})
            if p=='/api/unblock':
                ok,msg=unblock_ip(body.get('ip',''))
                return self.sendj({'ok':ok,'message':str(msg)[:500]} if ok else {'ok':False,'error':str(msg)[:500] or 'the firewall did not confirm the unblock'})
            if p in ('/api/cve','/api/update','/api/feed','/api/defs-update'):
                if not JOB_LOCK.acquire(blocking=False,job={'/api/cve': 'CVE scan', '/api/update': 'System update', '/api/feed': 'Threat-feed update', '/api/defs-update': 'Virus/rootkit definition update'}[p]): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try:
                    result={'/api/cve':cve_scan,'/api/update':package_update,'/api/feed':feed_update,'/api/defs-update':update_definitions}[p]()
                    return self.sendj(result)
                finally: JOB_LOCK.release()
            if p=='/api/scan-job':
                # Run one scan tool now. Same job names as locsecctl's scan-<name> commands.
                jobs=dict(SCAN_JOBS+[CLAMAV_JOB])
                key=str(body.get('job',''))
                if key not in jobs: return self.sendj({'ok':False,'error':f'unknown job "{key}"'},400)
                if not JOB_LOCK.acquire(blocking=False,job=_JOB_LABEL.get(key,key)+' scan'): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try: return self.sendj(run_scan_job(key,jobs[key]) or {'ok':False,'error':f'{key} is not installed or produced no result'})
                finally: JOB_LOCK.release()
            if p in ('/api/aide/accept','/api/aide/reinitialize'):
                if not JOB_LOCK.acquire(blocking=False,job={'/api/aide/accept':'Accept pending AIDE baseline','/api/aide/reinitialize':'Build AIDE database'}[p]): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try:
                    if p=='/api/aide/accept': return self.sendj(aide_accept_pending(body.get('confirm')=='ACCEPT_PENDING'))
                    return self.sendj(aide_reinitialize(body.get('confirm')=='REPLACE_BASELINE'))
                finally: JOB_LOCK.release()
            if p=='/api/tool/add':
                if not JOB_LOCK.acquire(blocking=False,job=f"Installing {str(body.get('tool',''))[:40]}"): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try: return self.sendj(tool_add(body.get('tool','')))
                finally: JOB_LOCK.release()
            if p=='/api/reputation': return self.sendj(reputation_check(body.get('indicator','')))
            if p=='/api/capture/analyze': return self.sendj(analyze_capture(body.get('name',''),deep=body.get('deep') is True))
            if p=='/api/capture/delete': return self.sendj(delete_capture(body.get('name','')))
            if p=='/api/capture/delete-all': return self.sendj(delete_all_captures())
            if p=='/api/report/read': return self.sendj(read_report(body.get('name','')))
            if p=='/api/report/delete': return self.sendj(delete_report(body.get('name','')))
            if p=='/api/log/clear':
                return self.sendj(clear_log(str(body.get('source',''))))
            if p=='/api/service/action':
                return self.sendj(service_action(str(body.get('unit','')),str(body.get('action',''))))
            if p=='/api/install-missing':
                if not JOB_LOCK.acquire(blocking=False,job='Installing missing components'): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try: return self.sendj(install_missing())
                finally: JOB_LOCK.release()
            if p=='/api/quarantine': return self.sendj(quarantine_file(str(body.get('path','')),force=bool(body.get('force',False)),anyway=bool(body.get('anyway',False)),signature=str(body.get('signature','')),incident_id=str(body.get('incident_id',''))))
            if p=='/api/quarantine/restore': return self.sendj(restore_quarantined(str(body.get('id','')),overwrite=bool(body.get('overwrite',False))))
            if p=='/api/quarantine/delete': return self.sendj(delete_quarantine_item(str(body.get('id',''))))
            if p=='/api/quarantine/delete-all': return self.sendj(delete_all_quarantine())
            if p=='/api/firewall/enable':
                rc,out=broker('fw.ufw.enable'); log(f'ufw enable: {out.strip()}'); return self.sendj({'ok':rc==0,'output':out})
            if p=='/api/firewall/disable':
                rc,out=broker('fw.ufw.disable'); log(f'ufw disable: {out.strip()}'); return self.sendj({'ok':rc==0,'output':out})
            if p=='/api/port/open':
                port=str(body.get('port','')); proto=str(body.get('proto','tcp')).lower()
                if not re.fullmatch(r'[0-9]{1,5}',port) or not (1 <= int(port) <= 65535) or proto not in ('tcp','udp'): return self.sendj({'error':'invalid port'},400)
                rc,out=broker('fw.ufw.allow_port',port=int(port),proto=proto); log(f'ufw open {port}/{proto}: {out.strip()}'); return self.sendj({'ok':rc==0,'output':out})
            if p=='/api/port/close':
                port=str(body.get('port','')); proto=str(body.get('proto','tcp')).lower()
                if not re.fullmatch(r'[0-9]{1,5}',port) or not (1 <= int(port) <= 65535) or proto not in ('tcp','udp'): return self.sendj({'error':'invalid port'},400)
                rc,out=broker('fw.ufw.unallow_port',port=int(port),proto=proto); log(f'ufw close {port}/{proto}: {out.strip()}'); return self.sendj({'ok':rc==0,'output':out})
            if p=='/api/capture/start':
                iface=str(body.get('iface','any'))
                try: dur=min(max(int(body.get('seconds',60)),5),3600)
                except (ValueError,TypeError,OverflowError): return self.sendj({'error':'seconds must be a whole number between 5 and 3600'},400)
                # No leading '-': tcpdump would read the name as one of its own options.
                if not re.fullmatch(r'[A-Za-z0-9_.:][A-Za-z0-9_.:-]{0,31}',iface): return self.sendj({'error':'invalid interface'},400)
                # The privilege broker (capture.start) owns the whole capture: the concurrency
                # cap, the free-space checks, tcpdump itself and the timer that stops it.
                res,code=start_capture(iface,dur)
                return self.sendj(res,code)
        except Exception as e:
            log(f'API error {p}: {e}','ERROR'); return self.sendj({'error':str(e)},500)
        return self.sendj({'error':'not found'},404)

DASHBOARD='''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LocSec Security Center</title><style>
:root{--bg:#0b0d12;--panel:#12151d;--panel2:#171b26;--line:#232838;--txt:#e6e9f2;--muted:#8b93a7;--accent:#5b8cff;--accent2:#7c5cff;--ok:#33d69f;--bad:#ff5d7a;--warn:#ffb547}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
.card{scroll-margin-top:76px}
.card a{color:var(--accent);text-decoration:none}
.card a:hover{text-decoration:underline}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,sans-serif;background:radial-gradient(1200px 600px at 10% -10%,#161b2b 0%,var(--bg) 55%);color:var(--txt);-webkit-font-smoothing:antialiased}
header{position:fixed;z-index:5;left:0;right:0;top:0;height:60px;background:rgba(18,21,29,.9);backdrop-filter:blur(10px);border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 22px;gap:12px}
header .logo{width:26px;height:26px;border-radius:8px;background:linear-gradient(135deg,var(--accent),var(--accent2));flex:none}
header .title{font-size:15px;font-weight:600;letter-spacing:.2px}
header .sub{font-size:11px;color:var(--muted)}
header .status{margin-left:auto;display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted)}
header .dot{width:8px;height:8px;border-radius:50%;background:var(--muted)}
header .dot.up{background:var(--ok);box-shadow:0 0 8px var(--ok)}
header .dot.down{background:var(--bad);box-shadow:0 0 8px var(--bad)}
nav{position:fixed;top:60px;bottom:0;left:0;width:216px;background:var(--panel);border-right:1px solid var(--line);padding:14px 10px;overflow:auto}
nav button{display:flex;align-items:center;gap:10px;width:100%;padding:13px 14px;margin-bottom:4px;background:none;border:0;border-radius:8px;color:var(--muted);text-align:left;font-size:15.5px;cursor:pointer;transition:background .12s,color .12s}
nav button:hover{background:var(--panel2);color:var(--txt)}
nav button.active{background:linear-gradient(90deg,rgba(91,140,255,.18),rgba(124,92,255,.08));color:var(--txt);box-shadow:inset 2px 0 0 var(--accent)}
main{margin-left:216px;padding:84px 26px 40px;max-width:1180px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px}
.card{background:linear-gradient(180deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:16px;box-shadow:0 8px 24px rgba(0,0,0,.25)}
.card h2{margin:0 0 12px;font-size:15px;font-weight:600}
.card h3{margin:18px 0 8px;font-size:13px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
.metric{font-size:28px;font-weight:700;letter-spacing:-.02em}
.muted{color:var(--muted);font-size:12px}
.ok{color:var(--ok)}
.bad{color:var(--bad)}
.pill{display:inline-block;padding:2px 9px;border-radius:99px;font-size:11px;font-weight:600;white-space:nowrap}
.pill.ok{background:rgba(51,214,159,.14);color:var(--ok)}
.pill.bad{background:rgba(255,93,122,.14);color:var(--bad)}
button.act{appearance:none;-webkit-appearance:none;font-family:inherit;line-height:1.2;padding:8px 14px;border:1px solid var(--accent);border-radius:9px;background:rgba(91,140,255,.12);color:var(--accent);margin:3px 6px 3px 0;cursor:pointer;font-size:13px;font-weight:600;transition:filter .12s,transform .08s}
button.act:hover{filter:brightness(1.25)}
button.act:active{transform:scale(.97)}
button.act:disabled{opacity:.5;cursor:default;filter:none}
button.danger{background:rgba(255,93,122,.12);border-color:var(--bad);color:var(--bad)}
button.ghost{background:rgba(139,147,167,.10);border-color:var(--muted);color:var(--txt)}
input,select,textarea{color-scheme:dark;accent-color:var(--accent);font:inherit;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:#0e111a;color:var(--txt)}
select{appearance:none;-webkit-appearance:none;padding-right:30px;cursor:pointer;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M1 1l4 4 4-4' fill='none' stroke='%238b93a7' stroke-width='1.5'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 11px center}
input::placeholder,textarea::placeholder{color:#5b6376}
input{min-width:240px}
input[type=checkbox]{min-width:0;width:auto;padding:0;margin:0}
.toolbar label{display:inline-flex;align-items:center;gap:7px}
table{width:100%;border-collapse:collapse;font-size:13px}
td,th{padding:9px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{color:var(--muted);font-weight:600;font-size:11.5px;text-transform:uppercase;letter-spacing:.05em}
.scroll{max-height:430px;overflow:auto}
.scroll.tall{max-height:72vh}
code.wrap{white-space:normal;word-break:break-all;font-size:11.5px;color:#c9d3e6}
.pill.warn{background:rgba(255,181,71,.14);color:var(--warn)}
.pill.note{background:rgba(91,140,255,.14);color:var(--accent)}
.intro{font-size:14.5px;line-height:1.55;margin:4px 0 12px}
.tally{display:flex;gap:14px;flex-wrap:wrap;align-items:center;margin-bottom:10px;font-size:13px}
table.loglist{table-layout:fixed}
table.loglist td{font-size:13.5px;line-height:1.45}
td,.fix,.explain .item,.story p{overflow-wrap:anywhere;word-break:break-word}
details>summary{cursor:pointer;display:inline-block;padding:6px 12px;border:1px solid var(--accent);border-radius:8px;color:var(--accent);font-weight:600;font-size:12.5px;margin:4px 0;user-select:none}
details>summary:hover{background:rgba(91,140,255,.12)}
details[open]>summary{margin-bottom:8px}
tr.lv-bad td:first-child{box-shadow:inset 3px 0 0 var(--bad)}
tr.lv-warn td:first-child{box-shadow:inset 3px 0 0 var(--warn)}
.fwsum .big{font-size:16px;margin-top:0}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;margin-bottom:6px}
details.raw{margin-top:12px}
.logcard pre#r:empty{display:none}
.fix{margin-top:6px;padding:7px 10px;border-left:3px solid var(--ok);background:rgba(51,214,159,.07);border-radius:4px;font-size:13px;line-height:1.45}
.fix b{color:var(--ok)}
.rep{color:var(--muted);font-weight:400;font-size:12px}
.explain .item{padding:9px 0;border-bottom:1px solid var(--line);font-size:13.5px;line-height:1.45}
.explain .item:last-child{border-bottom:0}
.explain h3{margin:16px 0 4px}
.story h3{margin:16px 0 4px;font-size:14px}.story p{margin:0;line-height:1.5}
.modalbg{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:9999;display:flex;align-items:center;justify-content:center;padding:24px}
@media print{
 body.printing > *:not(.modalbg){display:none!important}
 body.printing{background:#fff!important}
 body.printing .modalbg{position:static;background:#fff;padding:0;display:block}
 body.printing .modalbg .card{max-height:none!important;overflow:visible!important;background:#fff!important;color:#000!important;box-shadow:none!important;border:0!important}
 body.printing .noprint{display:none!important}
 body.printing .fix{background:#f2f2f2;color:#000;border-left-color:#888}
 body.printing .fix b{color:#000}
 body.printing details{display:none}
 body.printing .explain .item{border-bottom-color:#ccc}
}
pre{max-height:460px;overflow:auto;background:#0a0c12;color:#c9d3e6;padding:14px;border-radius:10px;white-space:pre-wrap;word-break:break-word;font-size:12.5px;border:1px solid var(--line)}
.toolbar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px}
.incident-actions{display:grid;grid-template-columns:repeat(2,max-content);gap:2px 4px;align-items:center}.incident-actions button.act,td button.act{margin:0;padding:6px 10px;font-size:12px}
.banner{display:none;background:rgba(255,93,122,.12);border:1px solid var(--bad);color:#ffd6dd;border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:13px;align-items:center;gap:10px}
.banner.show{display:flex}
.banner button{margin-left:auto}
.skel{height:64px;border-radius:12px;background:linear-gradient(90deg,var(--panel2),var(--panel),var(--panel2));background-size:200% 100%;animation:sh 1.2s infinite}
@keyframes sh{0%{background-position:200% 0}100%{background-position:-200% 0}}
</style></head><body>
<header><div class="logo"></div><div><div class="title">LocSec Security Center</div><div class="sub">24/7 local host protection</div></div><div class="status"><span class="dot" id="hdot"></span><span id="htext">Checking…</span></div></header>
<nav id="nav">
<button data-p="overview" onclick="page('overview')">Overview</button>
<button data-p="firewall" onclick="page('firewall')">Firewall &amp; Blocks</button>
<button data-p="logins" onclick="page('logins')">Login Activity</button>
<button data-p="incidents" onclick="page('incidents')">Incidents</button>
<button data-p="scans" onclick="page('scans')">Scans &amp; CVEs</button>
<button data-p="malware" onclick="page('malware')">Malware / Quarantine</button>
<button data-p="threats" onclick="page('threats')">Threat Intelligence</button>
<button data-p="network" onclick="page('network')">Ports &amp; Capture</button>
<button data-p="services" onclick="page('services')">Services</button>
<button data-p="reports" onclick="page('reports')">Reports</button>
<button data-p="logs" onclick="page('logs')">Logs</button>
<button data-p="troubleshooting" onclick="page('troubleshooting')">Troubleshooting</button>
<button data-p="help" onclick="page('help')">Help</button>
</nav>
<main id="app"><div class="banner" id="banner"><span></span><button class="act ghost" onclick="dismissFlash()">Dismiss</button></div><div id="pagebody"></div></main>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let currentPage='overview';
const REPORT_DAYS=Number('__REPORT_DAYS__')||7;

async function api(u,o={}){
  o.headers=Object.assign({'Content-Type':'application/json'},o.headers||{});
  let r;
  try{ r=await fetch(u,o); }
  catch(e){ throw new Error('Cannot reach the LocSec service ('+(e&&e.message?e.message:'network error')+'). Is locsecd running?'); }
  let j;
  try{ j=await r.json(); }
  catch(e){ j={error:'invalid server response'}; }
  if(!r.ok){
    const msg=(j&&j.error)?j.error:('HTTP '+r.status);
    if(r.status===401) document.title='LocSec - session expired';
    throw new Error(r.status===401?'Session expired — reopen LocSec to sign in again.':msg);
  }
  return j;
}

function show(x){let r=document.getElementById('r');if(r)r.textContent=typeof x==='string'?x:JSON.stringify(x,null,2)}

async function toolAdd(tool,btn){await run('/api/tool/add',{tool:tool},btn);page('overview')}
async function run(u,b={},btn){
  if(btn) btn.disabled=true;
  try{
    let x=await api(u,{method:'POST',body:JSON.stringify(b)});
    show(x); return x;
  }catch(e){
    show('Error: '+e.message); flash(e.message); return {ok:false,error:e.message};
  }finally{
    if(btn) btn.disabled=false;
    if(document.getElementById('jobnow')) showJob();
  }
}

function flash(msg){
  const b=document.getElementById('banner');
  if(!b) return;
  b.querySelector('span').textContent=msg;
  b.classList.add('show');
}
function dismissFlash(){const b=document.getElementById('banner');if(b)b.classList.remove('show')}

function nav(p){document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.p===p))}

// Each page load waits on the service. A slower, earlier load finishing after a newer one
// used to paint its page over the one picked since (and, on Malware / Quarantine, replace the
// list the row buttons point into). Only the newest load may write.
let PAGE_SEQ=0;
async function page(p){
  currentPage=p; nav(p); dismissFlash();
  const seq=++PAGE_SEQ, real=document.getElementById('pagebody');
  real.innerHTML='<div class="skel"></div><div class="skel" style="margin-top:10px"></div>';
  const a={live:()=>seq===PAGE_SEQ,set innerHTML(h){if(seq===PAGE_SEQ)real.innerHTML=h},get innerHTML(){return real.innerHTML}};
  try{
    await renderPage(p,a);
  }catch(e){
    if(!a.live()) return;
    real.innerHTML=`<div class="card"><p class="bad">Could not load this page.</p><button class="act ghost" onclick="page('${p}')">Retry</button></div>`;
    flash(e.message);
  }
}

async function renderPage(p,a){
if(p==='overview'){let s=await api('/api/status');let m=s.missing||{};let need=[];if(m['clamav-daemon'])need.push('ClamAV daemon');
a.innerHTML=`<div class="grid"><div class="card"><div class="muted">Version</div><div class="metric">${esc(s.version)}</div></div><div class="card"><div class="muted">Blocks</div><div class="metric">${esc(s.blocks)}</div></div><div class="card"><div class="muted">Auth failures</div><div class="metric">${esc(s.auth_failures)}</div></div><div class="card"><div class="muted">Load</div><div class="metric">${esc((s.load||[])[0]||'?')}</div><div class="muted">${s.idle?'idle scan eligible':'busy'}</div></div></div>`+
(need.length?`<div class="card"><h2>Setup incomplete</h2><p class="muted">Not installed yet: ${need.map(esc).join(', ')}.</p><div class="toolbar">${m['clamav-daemon']?`<button class="act" onclick="run('/api/install-missing',{},this).then(()=>page('overview'))">Install missing components</button>`:''}</div><pre id="r"></pre></div>`:'')+
`<div class="card"><h2>Protection status</h2><table><tr><th>Component</th><th>Status</th><th>Action</th></tr>${Object.entries(s.tools||{}).map(([k,v])=>`<tr><td>${esc(k)}</td><td><span class="pill ${v?'ok':'bad'}">${v?'installed':'missing'}</span></td><td>${v?'<span class="muted">'+'required'+'</span>':`<div class="incident-actions"><button class="act" onclick="toolAdd(${esc(JSON.stringify(k))},this)">Add</button></div>`}</td></tr>`).join('')}</table><p>Firewall: <span class="pill ${s.firewall_active?'ok':'bad'}">${s.firewall_active?'active':'inactive'}</span></p></div>${s.ids&&s.ids.installed?`<div class="card"><h2>Intrusion signatures (Suricata)</h2><p><span class="pill ${s.ids.state==='monitoring'?'ok':'bad'}">${esc(s.ids.state_text)}</span></p>${s.ids.hint?`<p class="bad">${esc(s.ids.hint)}</p>`:''}<p class="muted">Alerts seen since LocSec started: ${esc(s.ids.alerts_seen)}${s.ids.last_alert?`, the last at ${esc(new Date(s.ids.last_alert*1000).toLocaleString())}`:''}. Rules last updated: ${esc(s.ids.rules_updated?new Date(s.ids.rules_updated*1000).toLocaleDateString():'never')}.</p></div>`:''}${(s.exposure||[]).length?`<div class="card"><h2>Exposure</h2><p class="muted">What an attacker on the network would try first. LocSec reports these; it does not change them for you.</p><table><tr><th>Check</th><th>State</th><th>Detail</th></tr>${s.exposure.map(e=>`<tr><td>${esc(e.item)}</td><td><span class="pill ${e.level==='ok'?'ok':'bad'}">${e.level==='ok'?'ok':'review'}</span></td><td>${esc(e.detail)}${e.fix?`<br><span class="muted">Fix: <code>${esc(e.fix)}</code></span>`:''}</td></tr>`).join('')}</table></div>`:''}<div class="card"><h2>Services</h2><table><tr><th>Unit</th><th>State</th></tr>${(s.services||[]).filter(x=>x.managed).map(x=>`<tr><td>${esc(x.unit)}</td><td><span class="pill ${x.running?'ok':'bad'}">${esc(x.state||(x.running?'running':'stopped'))}</span></td></tr>`).join('')||'<tr><td colspan="2" class="muted">No LocSec-managed services found.</td></tr>'}</table><p class="muted">The Services page lists these plus everything else currently running.</p></div>`}
if(p==='firewall'){let b=await api('/api/blocks/explained'),f=await api('/api/firewall'),ports=await api('/api/ports');if(!a.live())return;window._blk=b.blocks||[];a.innerHTML=`<div class="card"><h2>Firewall</h2><div class="toolbar"><button class="act" onclick="run('/api/firewall/enable',{},this).then(()=>page('firewall'))">Enable UFW</button><button class="act danger" onclick="run('/api/firewall/disable',{},this).then(()=>page('firewall'))">Disable UFW</button><input id="ip" placeholder="IP or CIDR"><button class="act" onclick="manualBlock()">Block</button></div><div class="toolbar"><input id="fwport" placeholder="Port 1-65535" type="number" min="1" max="65535"><select id="fwproto"><option>tcp</option><option>udp</option></select><button class="act" onclick="portRule('open')">Open port</button><button class="act danger" onclick="portRule('close')">Close port</button></div><pre>${esc(f.output||'')}</pre><h3>Listening ports</h3><pre>${esc(ports.output||'')}</pre></div>`+blocksCard(b)+`<pre id="r"></pre>`}
if(p==='logins'){let s=await api('/api/status');a.innerHTML=`<div class="grid"><div class="card"><div class="muted">Failed events</div><div class="metric">${esc(s.auth_failures)}</div></div><div class="card"><div class="muted">Successful events</div><div class="metric">${esc(s.auth_successes)}</div></div></div><div class="card"><h2>Authentication / intrusion monitoring</h2><p class="muted">Repeated failures can trigger automatic blocking.</p></div>`}
if(p==='incidents'){let x=await api('/api/incidents');if(!a.live())return;a.innerHTML=`<div class="card"><h2>Automatic response policy</h2><p class="muted">These controls govern automatic containment. Allowlisted addresses are never blocked.</p><div class="toolbar"><label><input id="pol_auto" type="checkbox"> Automatic blocking</label><label><input id="pol_auth" type="checkbox"> Failed-login blocking</label><label><input id="pol_feed" type="checkbox"> Threat-feed blocking</label><label><input id="pol_v6" type="checkbox"> IPv6 blocking</label><label><input id="pol_scan" type="checkbox"> Port-scan blocking</label><label><input id="pol_fb" type="checkbox"> Fallback firewall when UFW is off</label><button class="act" onclick="savePolicy()">Save policy</button></div><pre id="policyout"></pre></div><div class="card"><h2>Desktop notifications</h2><p class="muted">A new incident of a checked type pops up as a desktop notification for about 10 seconds, even when this window is closed. The same address is announced at most once every 10 minutes. Your choices are saved and kept across restarts and reboots.</p><div class="toolbar"><label><input id="ntf_virus" type="checkbox"> Virus found</label><label><input id="ntf_rootkit" type="checkbox"> Rootkit warning</label><label><input id="ntf_block" type="checkbox"> IP blocked</label><label><input id="ntf_login" type="checkbox"> Failed login</label><label><input id="ntf_scan" type="checkbox"> Port scan</label><label><input id="ntf_ids" type="checkbox"> Attack pattern seen</label><label><input id="ntf_fb" type="checkbox"> Fallback firewall on</label><button class="act" onclick="saveNotifySettings()">Save</button><button class="act" onclick="testNotification()">Send test notification</button></div><pre id="notifyout"></pre><h3>Recent notifications</h3><p class="muted">Kept by LocSec, so they survive a log-out, reboot or restart (the desktop's own list does not). One raised while nobody was logged in is shown as a summary at the next log-in.</p><div id="notifyhist"><p class="muted">Loading...</p></div></div><div class="card"><h2>Incident timeline</h2><div class="toolbar"><button class="act danger" onclick="deleteAllIncidents()">Delete all</button></div><p class="muted"><b>Explain</b> says in plain language what happened, what LocSec did and what you should do. <b>Fix it</b> appears only when LocSec can fix it by itself (block that computer, or move the file into quarantine). <b>Mark solved</b> closes it. Every result can be printed or copied.</p><p class="muted">Repeated observations are folded into one incident <b>while it is open</b> &mdash; the Seen column counts them. Resolving or dismissing closes it for good: a later observation of the same thing opens a new incident with its own timestamp, so closure stays meaningful and the history of the old one is preserved. Feed entries are intelligence indicators, not proof that the listed address actually connected to this computer. Network blocks expire after 30 days unless refreshed by a new confirmed event.</p><div class="scroll"><table><tr><th>Time</th><th>Type</th><th>Source</th><th>Indicator</th><th>Severity</th><th>State</th><th>Seen</th><th>Action</th></tr>${(x.incidents||[]).slice().reverse().map(i=>`<tr><td>${esc(new Date((i.ts||0)*1000).toLocaleString())}</td><td>${esc(KIND_LABEL[i.kind]||i.kind)}</td><td>${esc(i.source)}</td><td>${esc(i.indicator)}</td><td>${esc(i.severity)}</td><td>${esc(STATE_LABEL[i.state||'new']||i.state)}</td><td>${esc(i.count||1)}<br><small>${i.last_seen?esc(new Date(i.last_seen*1000).toLocaleString()):''}</small></td><td><div class="incident-actions"><button class="act" onclick="incidentAction(${esc(JSON.stringify(i.id))},'explain')">Explain</button>${i.can_fix?`<button class="act" onclick="incidentAction(${esc(JSON.stringify(i.id))},'fix')">Fix it</button>`:''}${i.state!=='resolved'?`<button class="act" onclick="incidentAction(${esc(JSON.stringify(i.id))},'resolve')">Mark solved</button>`:''}<button class="act danger" onclick="deleteIncident(${esc(JSON.stringify(i.id))})">Delete</button></div></td></tr>`).join('')||'<tr><td colspan="8" class="muted">No incidents recorded.</td></tr>'}</table></div></div>`;await loadPolicy()}
if(p==='scans'){setTimeout(showJob,0);a.innerHTML=`<div class="card"><h2>Security scans</h2><p class="muted">AIDE, Lynis, Debsecan, rkhunter, a port/firewall snapshot and a CVE check each run automatically once a week, staggered a day apart and at most one per day, so they don't all hit the CPU/disk together. ClamAV runs separately once a day, and rkhunter/ClamAV signature definitions refresh once a day in the background. Scheduled runs wait until the machine has been idle (load at or below <code>idle_load</code> for <code>idle_seconds</code>); buttons here start at once. Only one maintenance job runs at a time. The aide package's own daily check (dailyaidecheck) is switched off when LocSec is installed, so AIDE runs once a week, not every day. Reports are deleted automatically after ${esc(REPORT_DAYS)} days.</p><p id="jobnow" class="muted"></p><div id="schedule"></div><p class="muted">Run a scan now:</p><div class="toolbar"><button class="act" onclick="run('/api/scan-job',{job:'aide'},this)">AIDE</button><button class="act" onclick="run('/api/scan-job',{job:'lynis'},this)">Lynis</button><button class="act" onclick="run('/api/scan-job',{job:'debsecan'},this)">Debsecan</button><button class="act" onclick="run('/api/scan-job',{job:'rkhunter'},this)">rkhunter</button><button class="act" onclick="run('/api/scan-job',{job:'clamav'},this)">ClamAV</button><button class="act" onclick="run('/api/scan-job',{job:'ports_fw'},this)">Ports/firewall</button><button class="act" onclick="run('/api/cve',{},this)">CVE scan</button></div><p class="muted">Updates and the AIDE baseline:</p><div class="toolbar"><button class="act" onclick="run('/api/update',{},this)">Update system</button><button class="act" onclick="run('/api/defs-update',{},this)">Update virus/rootkit definitions now</button><button class="act" id="aidePendingBtn" style="display:none" onclick="aideAcceptPending(this)">Accept pending AIDE baseline</button><button class="act danger" onclick="aideReinitialize(this)">Build AIDE database</button></div><p class="muted">AIDE baseline: press Build AIDE database only for a first baseline, or after you have reviewed the AIDE report and every difference is expected. Accept pending AIDE baseline appears only when a differing pending database exists. Details are on the Help page under AIDE.</p><pre id="r"></pre></div>`}
if(p==='malware'){let q=await api('/api/quarantine/list');let inc=await api('/api/incidents');if(!a.live())return;window._qitems=q.items||[];window._qdet=(inc.incidents||[]).filter(i=>i.kind==='virus-found'&&i.state!=='resolved'&&i.indicator).reverse();a.innerHTML=`<div class="card"><h2>Quarantine</h2><p class="muted">Quarantined files are moved out of place, stripped of any way to run them, and kept with their original location so they can be restored. Files under system directories (/bin, /usr/lib, /etc, ...) are refused by default to avoid a false positive breaking the system.</p><div class="toolbar"><input id="mal" placeholder="Absolute file path"><label><input id="malforce" type="checkbox"> Force (allow system paths)</label><label><input id="malany" type="checkbox"> Quarantine even if clean</label><button class="act" onclick="qAdd(this)">Scan &amp; quarantine</button></div></div><div class="card"><h2>Detections awaiting action</h2><p class="muted">Infected files found by ClamAV scans that have not been quarantined yet.</p><div class="scroll"><table><tr><th>Time</th><th>File</th><th>Signature</th><th>Action</th></tr>${window._qdet.map((d,n)=>`<tr><td>${esc(new Date((d.ts||0)*1000).toLocaleString())}</td><td>${esc(d.indicator)}</td><td>${esc(d.detail)}</td><td><div class="incident-actions"><button class="act" onclick="qDetect(${n},this)">Quarantine</button></div></td></tr>`).join('')||'<tr><td colspan="4" class="muted">No unhandled detections.</td></tr>'}</table></div></div><div class="card"><h2>Quarantined files</h2><div class="toolbar"><button class="act danger" onclick="qDeleteAll()">Delete all</button></div><div class="scroll"><table><tr><th>Quarantined</th><th>Original location</th><th>Signature</th><th>Size</th><th>Action</th></tr>${window._qitems.map((x,n)=>`<tr><td>${esc(x.quarantined_at?new Date(x.quarantined_at*1000).toLocaleString():'')}</td><td>${esc(x.original_path)}</td><td>${esc(x.signature)}</td><td>${esc(fmtBytes(x.size))}</td><td><div class="incident-actions">${x.restorable?`<button class="act" onclick="qRestore(${n})">Restore</button>`:''}<button class="act danger" onclick="qDelete(${n})">Delete</button></div></td></tr>`).join('')||'<tr><td colspan="5" class="muted">Quarantine is empty.</td></tr>'}</table></div></div><div class="card"><pre id="r"></pre></div>`}
if(p==='threats'){let f=await api('/api/feeds');let cnt=x=>typeof x==='number'?x:(x||[]).length;let mins=Math.round((f.interval_seconds||43200)/60);let when=f.updated?new Date(f.updated*1000).toLocaleString():'never';let age=f.updated?Math.round((Date.now()/1000-f.updated)/60):null;
a.innerHTML=`<div class="card"><h2>Threat intelligence</h2><p class="muted">Auto-updates every ${mins} minute(s) in the background (no action needed). Last updated: ${esc(when)}${age!==null?` (${age} min ago)`:''}.</p>${f.last_attempt_ok===false?`<p class="bad">The last update, ${esc(new Date((f.last_attempt||0)*1000).toLocaleString())}, reached none of the sources (errors below). The indicators shown are from the last successful update, and LocSec retries every 15 minutes until one succeeds.</p>`:''}<div class="toolbar"><button class="act" onclick="run('/api/feed',{},this)">Update feeds now</button><input id="rep" placeholder="domain, IP or URL"><button class="act" onclick="repcheck()">Check reputation</button></div><p class="muted">Checks the local IOC database; LocSec does not visit submitted sites.</p><div class="grid"><div class="card"><div class="muted">Domains</div><div class="metric">${esc(cnt(f.domains))}</div></div><div class="card"><div class="muted">IPs</div><div class="metric">${esc(cnt(f.ips))}</div></div><div class="card"><div class="muted">Networks</div><div class="metric">${esc(cnt(f.networks))}</div></div></div>${(f.errors&&f.errors.length)?`<pre>${esc(JSON.stringify(f.errors,null,2))}</pre>`:''}<pre id="r"></pre></div><div id="idscard"><div class="card"><h2>Intrusion detection (Suricata)</h2><p class="muted">Loading...</p></div></div>`;idsCard(a)}
if(p==='network'){let c=await api('/api/captures'),ports=await api('/api/ports'),con=await api('/api/connections');a.innerHTML=`<div class="card"><h2>Ports &amp; packet capture</h2><h3>Current connections</h3><pre>${esc(JSON.stringify(con.connections||[],null,2))}</pre><h3>Listening ports</h3><pre>${esc(ports.output||'')}</pre><div class="toolbar"><input id="iface" value="any"><input id="secs" value="60" type="number" min="5" max="3600"><button class="act" onclick="capture()">Start capture</button></div><div class="toolbar"><input id="capname" placeholder="capture filename"><button class="act" onclick="analyzeCapture(document.getElementById('capname').value,this)">Analyze capture</button></div>${(c.items||[]).length?`<h3>Saved captures</h3><div class="toolbar"><button class="act danger" onclick="deleteAllCaptures()">Delete all captures</button></div><div class="scroll"><table><tr><th>File</th><th>Recorded</th><th>Size</th><th>Action</th></tr>${(c.items||[]).map(f=>`<tr><td>${esc(f.name)}${f.recording?' <span class="pill warn">recording</span>':''}</td><td>${esc(new Date(f.mtime*1000).toLocaleString())}</td><td>${esc(fmtBytes(f.size))}</td><td><div class="incident-actions"><button class="act" onclick="analyzeCapture(${esc(JSON.stringify(f.name))},this)">Analyze</button><button class="act danger" onclick="deleteCapture(${esc(JSON.stringify(f.name))})">Delete</button></div></td></tr>`).join('')}</table></div>`:'<p class="muted">No saved captures.</p>'}<div id="capview"></div><pre id="r"></pre></div>`}
if(p==='services'){let s=await api('/api/services');a.innerHTML=`<div class="card"><h2>Services</h2><p class="muted">Units LocSec coordinates are listed first and stay listed when stopped. Everything else currently running follows. PID is the main process ID systemd reports for the unit; a dash means it has no running main process (it is stopped). ufw is a one-shot unit that loads its rules into the kernel and exits, so it has no PID by design: it shows <b>running</b> with a note when ufw confirms the rules are loaded, and <b>rules off</b> when it does not.</p><div class="scroll"><table><tr><th>Unit</th><th>State</th><th>Description</th><th>PID</th></tr>${(s.services||[]).map(x=>`<tr><td>${esc(x.unit)}${x.managed?' <span class="pill ok">LocSec</span>':''}</td><td><span class="pill ${x.running?'ok':'bad'}">${esc(x.state||(x.running?'running':'stopped'))}</span></td><td>${esc(x.description)}</td><td>${x.pid>0?esc(String(x.pid)):(x.pid_note?'<span class="muted">'+esc(x.pid_note)+'</span>':'<span class="muted">&mdash;</span>')}</td></tr>`).join('')}</table></div><h3>Manual control</h3><p class="muted">For a unit that is not listed above. The name may be typed with or without the <code>.service</code> suffix. By default only LocSec-managed services can be controlled; set <code>allow_manual_service_control=true</code> in the configuration to explicitly enable control of unrelated services. Units your own access depends on (ssh, networking, the display manager, polkit, locsecd itself) can be started and enabled here but never stopped, restarted or disabled.</p><div class="toolbar"><input id="svcname" placeholder="bluetooth (or bluetooth.service)" value="${esc(MANUAL_UNIT)}" onkeydown="if(event.key==='Enter'){manualSvc('start')}" oninput="MANUAL_UNIT=this.value"><button class="act" onclick="manualSvc('start')">Start</button><button class="act" onclick="manualSvc('restart')">Restart</button><button class="act danger" onclick="manualSvc('stop')">Stop</button><button class="act" onclick="manualSvc('enable')">Enable</button><button class="act danger" onclick="manualSvc('disable')">Disable</button></div><pre id="r"></pre></div>`}
if(p==='reports'){let r=await api('/api/reports');a.innerHTML=`<div class="card"><h2>Reports</h2><p class="muted">Every report is deleted automatically once it is ${esc(REPORT_DAYS)} days old, so reports never fill up the disk (<code>report_retention_days</code> in the configuration).</p><div class="scroll"><table><tr><th>Report</th><th>Action</th></tr>${(r.reports||[]).map(x=>`<tr><td>${esc(x)}</td><td><div class="incident-actions"><button class="act" onclick="readReport(${esc(JSON.stringify(x))})">View</button><button class="act danger" onclick="deleteReport(${esc(JSON.stringify(x))})">Delete</button></div></td></tr>`).join('')||'<tr><td colspan="2" class="muted">No reports yet.</td></tr>'}</table></div></div><div id="reportview"></div>`}
if(p==='logs'){await renderLogs('locsecd',a)}
if(p==='troubleshooting'){a.innerHTML=TROUBLESHOOTING_HTML}
if(p==='help'){a.innerHTML=HELP_HTML}
}

async function showJob(){
  // Which maintenance job holds the lock, so a refused button explains itself.
  try{
    let j=await api('/api/job'); let el=document.getElementById('jobnow'); if(!el) return;
    if(j.running){ let m=Math.floor((Date.now()/1000-j.running.since)/60);
      el.innerHTML='<span class="pill" style="background:rgba(255,181,71,.14);color:var(--warn)">Running now</span> '+esc(j.running.name)+' ('+esc(j.running.origin)+'), started '+esc(new Date(j.running.since*1000).toLocaleTimeString())+', '+(m<1?'under a minute':m+' min')+' ago.';
    } else if(j.external){ el.innerHTML='<span class="pill warn">AIDE running, not started by LocSec</span> '+esc(j.external.message);
    } else el.textContent='No maintenance job is running.';
    let sch=document.getElementById('schedule'); if(sch) sch.innerHTML=scheduleHtml(j.schedule);
    let pb=document.getElementById('aidePendingBtn'); if(pb) pb.style.display=j.aide_pending?'':'none';
  }catch(e){}
}
async function aideAcceptPending(btn){
  if(!await uiConfirm('Accept pending AIDE baseline','Accept /var/lib/aide/aide.db.new as the active AIDE baseline? This records current changes as accepted. The previous baseline will be retained as aide.db.locsec-backup.','Accept',false)) return;
  await run('/api/aide/accept',{confirm:'ACCEPT_PENDING'},btn);
}
async function aideReinitialize(btn){
  if(!await uiConfirm('Build AIDE database','Build the AIDE database from the current filesystem? If a database already exists it is replaced, so review the AIDE report first. On a machine with no database yet this creates the first one.','Build database',true)) return;
  await run('/api/aide/reinitialize',{confirm:'REPLACE_BASELINE'},btn);
}

function fmtWhen(t){return t?new Date(t*1000).toLocaleString([], {year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):''}
function blocksCard(b){
  const rows=b.blocks||[];const by={};rows.forEach(x=>{by[x.who||'unknown']=(by[x.who||'unknown']||0)+1});
  const who=Object.entries(by).sort((p,q)=>q[1]-p[1]).map(([k,v])=>`<b>${esc(v)}</b> from ${esc(k)}`).join(', ');
  return `<div class="card"><h2>Blocked computers</h2>
<p>These are computers LocSec will not let talk to this one. Each row says <b>what</b> is blocked, <b>why</b>, and <b>who said</b> it is bad. Every block goes away by itself on the date shown.</p>
<p class="muted">LocSec blocks computers by their internet address (IP). It does not block ads or websites by name: when a list says an address was handing out a harmful download, the address it was seen at is shown, so you know what it was. Web addresses here are shown as text on purpose, so they cannot be clicked by accident.</p>
${rows.length?`<p class="muted">${esc(b.total)} blocked${b.total>rows.length?` (newest ${rows.length} shown; the full list is /var/lib/locsecd/blocks.json)`:''}: ${who}.</p>`:''}
<div class="scroll tall"><table><tr><th style="width:24%">What is blocked</th><th>Reason</th><th style="width:20%">Source</th><th style="width:14%">Blocked / lifts</th><th>Action</th></tr>${rows.map((x,n)=>`<tr><td><b>${esc(x.address)}</b><br><span class="muted">${esc(x.what)}</span>${x.seen_at?`<br><span class="muted">Harmful download seen at:</span><br><code class="wrap">${esc(x.seen_at)}</code>`:''}</td><td>${esc(x.why)}</td><td>${esc(x.who)}${x.ref?`<br><span class="muted">Reference ${esc(x.ref)}</span>`:''}${x.ref_page?`<br><span class="muted">Look it up:</span><br><code class="wrap">${esc(x.ref_page)}</code>`:''}</td><td>${esc(fmtWhen(x.added))}<br><span class="muted">lifts ${x.expires?esc(fmtWhen(x.expires)):'after 30 days'}</span></td><td><div class="incident-actions"><button class="act danger" onclick="unblock(window._blk[${n}].key)">Unblock</button></div></td></tr>`).join('')||'<tr><td colspan="5" class="muted">Nothing is blocked right now.</td></tr>'}</table></div></div>`;
}
async function manualBlock(){let x=document.getElementById('ip').value;if(x){const r=await run('/api/block',{ip:x,reason:'manual dashboard block'});await page('firewall');if(r&&!r.ok)flash('Not blocked: '+(r.error||'unknown reason'))}}
async function portRule(action){let port=Number(document.getElementById('fwport').value),proto=document.getElementById('fwproto').value;if(Number.isInteger(port)&&port>=1&&port<=65535){await run('/api/port/'+action,{port:String(port),proto});page('firewall')}else{flash('Enter a port between 1 and 65535.')}}
async function incidentAction(id,action){
  let j;
  try{ j=await api('/api/incident/action',{method:'POST',body:JSON.stringify({id,action})}); }catch(e){ flash(e.message); return }
  if(!j||!j.ok){flash((j&&j.error)||'That did not work.');return}
  const x=j.explain||{}, i=j.incident||{};
  const hist=(j.actions||[]).map(a=>new Date((a.ts||0)*1000).toLocaleString()+'  '+a.action+': '+a.message).join(NL);
  const title={explain:'What happened',fix:'Fix it',resolve:'Marked solved'}[action]||'Result';
  const body=`<div class="story">${lvlPill(x.level||'info')} <b>${esc(KIND_LABEL[i.kind]||i.kind||'')}</b>${i.count>1?` <span class="rep">(seen ${esc(i.count)} times)</span>`:''}<h3>What happened</h3><p>${esc(x.happened||'')}</p><h3>What LocSec did</h3><p>${esc(x.did||'')}</p><h3>What you should do</h3><div class="fix">${esc(x.todo||'')}</div>${x.can_fix&&action!=='fix'?'<p class="muted">LocSec can do this for you: close this and press <b>Fix it</b>.</p>':''}</div><details class="raw"><summary>Technical details (for experts)</summary><pre>${esc((j.evidence?j.evidence+NL+NL:'')+'History:'+NL+hist)}</pre></details>`;
  const text='What happened: '+(x.happened||'')+NL+NL+'What LocSec did: '+(x.did||'')+NL+NL+'What you should do: '+(x.todo||'');
  showSheet(title,'',body,text,()=>page('incidents'));
}
function uiConfirm(title,message,okLabel,danger){
  return new Promise(resolve=>{
    let d=document.createElement('div');
    d.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:9999;display:flex;align-items:center;justify-content:center;padding:24px';
    d.innerHTML='<div class="card" role="dialog" aria-modal="true" style="max-width:460px;width:100%;margin-bottom:0"><h2>'+esc(title)+'</h2><p class="muted" style="white-space:pre-line">'+esc(message)+'</p><div class="toolbar" style="justify-content:flex-end;margin-bottom:0"><button class="act ghost" id="ui-cancel">Cancel</button><button class="act'+(danger?' danger':'')+'" id="ui-ok">'+esc(okLabel||'OK')+'</button></div></div>';
    document.body.appendChild(d);
    let onKey=e=>{if(e.key==='Escape')done(false)};
    let done=v=>{document.removeEventListener('keydown',onKey);d.remove();resolve(v)};
    document.addEventListener('keydown',onKey);
    d.onclick=e=>{if(e.target===d)done(false)};
    document.getElementById('ui-cancel').onclick=()=>done(false);
    let ok=document.getElementById('ui-ok');ok.onclick=()=>done(true);ok.focus();
  });
}
async function qAdd(btn){
  let path=document.getElementById('mal').value.trim(); if(!path){show('Enter an absolute file path.');return}
  let x=await run('/api/quarantine',{path:path,force:document.getElementById('malforce').checked,anyway:document.getElementById('malany').checked},btn);
  if(x&&x.ok) page('malware');
}
async function qDetect(n,btn){
  let d=(window._qdet||[])[n]; if(!d) return;
  // Never force on the first attempt: a ClamAV false positive on a system binary
  // would be moved out from under a running system with one unconfirmed click.
  let b={path:d.indicator,signature:d.detail||'detected',incident_id:d.id};
  let x=await run('/api/quarantine',b,btn);
  if(x&&x.error&&/system directory/.test(x.error)){
    if(!await uiConfirm('Quarantine a system file',x.error+'\\n\\nQuarantine it anyway?','Quarantine anyway',true)) return;
    x=await run('/api/quarantine',Object.assign({force:true},b),btn);
  }
  if(x&&x.ok) page('malware');
}
async function qRestore(n){
  let it=(window._qitems||[])[n]; if(!it) return;
  if(!await uiConfirm('Restore file','Put this file back at '+it.original_path+'? It was quarantined for a reason: only restore it if you are sure it is safe.','Restore',false)) return;
  let x=await run('/api/quarantine/restore',{id:it.id,overwrite:false});
  if(x&&x.error&&/already exists/.test(x.error)){
    if(await uiConfirm('Replace existing file',x.error+' Replace it with the quarantined copy?','Replace',true)) x=await run('/api/quarantine/restore',{id:it.id,overwrite:true});
  }
  if(x&&x.ok) page('malware');
}
async function qDelete(n){
  let it=(window._qitems||[])[n]; if(!it) return;
  if(!await uiConfirm('Delete quarantined file','Delete this file permanently? This cannot be undone.','Delete',true)) return;
  let x=await run('/api/quarantine/delete',{id:it.id});
  if(x&&x.ok) page('malware');
}
async function qDeleteAll(){
  if(!await uiConfirm('Delete all quarantined files','Delete ALL quarantined files permanently? This cannot be undone.','Delete all',true)) return;
  let x=await run('/api/quarantine/delete-all',{});
  if(x&&x.ok) page('malware');
}
async function deleteIncident(id){
  if(!await uiConfirm('Delete incident','Delete this incident and its action log from the dashboard permanently? This cannot be undone.','Delete',true)) return;
  try{ await api('/api/incident/delete',{method:'POST',body:JSON.stringify({id})}); }catch(e){ flash(e.message); return }
  page('incidents');
}
async function deleteAllIncidents(){
  if(!await uiConfirm('Delete all incidents','Delete ALL incidents permanently? This cannot be undone.','Delete all',true)) return;
  try{ await api('/api/incident/delete-all',{method:'POST',body:'{}'}); }catch(e){ flash(e.message); return }
  page('incidents');
}
function fmtBytes(n){
  n=Number(n)||0;
  if(n<1024) return n+' B';
  const u=['KB','MB','GB','TB']; let i=-1;
  do{ n/=1024; i++; }while(n>=1024 && i<u.length-1);
  return n.toFixed(n<10?1:0)+' '+u[i];
}
async function refreshLogs(){
  // The page only reloaded when the source dropdown changed, so watching a
  // log meant re-picking the same entry. This re-reads the current source
  // and the sizes alongside it. renderLogs rebuilds the DOM, so the button
  // is looked up by id each time rather than held across the rebuild.
  const el=document.getElementById('logsrc');
  const src=el?el.value:'locsecd';
  const btn=document.getElementById('logrefresh');
  if(btn) btn.disabled=true;
  try{ await renderLogs(src); }
  catch(e){ const b=document.getElementById('logrefresh'); if(b) b.disabled=false; flash(e.message); }
}
async function clearLog(key){
  if(!await uiConfirm('Clear this log?','The file is emptied in place, not deleted, so logging continues normally. Its rotation is unchanged. This cannot be undone, and the action itself is recorded as an incident.','Clear',true)) return;
  let x=await run('/api/log/clear',{source:key});
  await renderLogs(document.getElementById('logsrc')?document.getElementById('logsrc').value:key);
  let r=document.getElementById('r');
  if(r&&x) r.textContent=x.ok?(x.output||'Cleared.'):('Error: '+(x.error||'could not clear that log'));
}
const NL=String.fromCharCode(10);
// An opened "Show the original log lines" (or full output) appears below the fold; bring it into view.
document.addEventListener('toggle',e=>{const t=e.target;if(t&&t.tagName==='DETAILS'&&t.open){const x=t.querySelector('pre')||t;setTimeout(()=>x.scrollIntoView({block:'nearest',behavior:'smooth'}),30)}},true);
function fmtEvery(sec){sec=Number(sec)||0;if(sec%604800===0)return sec===604800?'once a week':'every '+(sec/604800)+' weeks';if(sec%86400===0)return sec===86400?'once a day':'every '+(sec/86400)+' days';if(sec%3600===0)return sec===3600?'every hour':'every '+(sec/3600)+' hours';return 'every '+Math.round(sec/60)+' minutes'}
function scheduleHtml(sc){
  if(!sc||!sc.ready) return '<p class="muted">The scheduler is starting; the plan appears within a minute.</p>';
  const now=sc.now, idleFor=sc.idle_since?Math.floor((now-sc.idle_since)/60):0, idleNow=sc.idle_since&&(now-sc.idle_since)>=sc.idle_seconds;
  const capped=sc.weekly_today>=sc.weekly_per_day;
  const rows=sc.rows.map(r=>{let nxt;
    if(r.next>now) nxt=new Date(r.next*1000).toLocaleString([],{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
    else if(r.weekly&&capped) nxt='Due; waits until tomorrow (one weekly check per day)';
    else if(r.idle&&!idleNow) nxt='Due; starts when the computer is idle';
    else nxt='Due; starts within a minute';
    return `<tr><td><b>${esc(r.name)}</b></td><td>${esc(fmtEvery(r.every))}${r.idle?'<br><span class="muted">when idle</span>':''}</td><td>${r.last?esc(new Date(r.last*1000).toLocaleString([],{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})):'<span class="muted">not yet</span>'}</td><td>${esc(nxt)}</td></tr>`}).join('');
  return `<h3>Schedule</h3><p class="muted">Checks have no fixed clock time: each one is due a set time after it last ran, and the ones marked "when idle" wait until the computer has been quiet (load ${esc(sc.idle_load)} or less) for ${esc(Math.round(sc.idle_seconds/60))} minutes. Right now the load is ${esc(sc.load??'?')}${idleNow?', so the computer counts as idle':(sc.idle_since?`, quiet for ${esc(idleFor)} minute(s)`:', so it is busy')}. At most ${esc(sc.weekly_per_day)} weekly check starts per day (${esc(sc.weekly_today)} today).</p><table><tr><th>Check</th><th>How often</th><th>Last ran</th><th>Next</th></tr>${rows}</table>`;
}
const KIND_LABEL={'login-failure':'Wrong password','auth-probe':'Dashboard token guessing','port-scan':'Port scan','ids-alert':'Intrusion signature (Suricata)','block':'Computer blocked','unblock':'Computer unblocked','virus-found':'Virus found','rootkit-warning':'Rootkit warning','firewall-fallback':'Fallback firewall enabled','log-cleared':'Log cleared','service-action':'Service changed','tool-add':'Tool installed'};
const STATE_LABEL={new:'New',investigating:'Looked at',contained:'Fixed',resolved:'Solved'};
function fixHtml(f){return f?`<div class="fix"><b>What to do:</b> ${esc(f)}</div>`:''}
function repHtml(e){return e.repeat>1?` <span class="rep">(${esc(e.repeat)} times)</span>`:''}
function itemsHtml(items){return items.map(e=>`<div class="item">${lvlPill(e.lvl)} <b>${esc(e.title)}</b>${repHtml(e)}${e.more?` <span class="rep">and ${esc(e.more)} more like it</span>`:''}<div>${esc(e.text)}</div>${fixHtml(e.fix)}</div>`).join('')}
function itemsText(items){return items.map(e=>'['+(LVL[e.lvl]||LVL.info)[1]+'] '+e.title+(e.repeat>1?' ('+e.repeat+' times)':'')+(e.more?' and '+e.more+' more like it':'')+NL+e.text+(e.fix?NL+'What to do: '+e.fix:'')).join(NL+NL)}
function showSheet(title,intro,bodyHtml,text,onClose){
  let d=document.createElement('div'); d.className='modalbg';
  d.innerHTML=`<div class="card" role="dialog" aria-modal="true" style="max-width:1000px;max-height:85vh;overflow:auto;width:100%;margin-bottom:0"><h2>${esc(title)}</h2>${intro?`<p class="muted">${esc(intro)}</p>`:''}<div class="explain">${bodyHtml}</div><div class="toolbar noprint" style="margin-top:14px;margin-bottom:0"><button class="act" data-k="print">Print</button><button class="act" data-k="copy">Copy as text</button><button class="act ghost" data-k="close">Close</button></div></div>`;
  document.body.appendChild(d);
  let onKey=e=>{if(e.key==='Escape')close()};
  let close=()=>{document.removeEventListener('keydown',onKey);document.body.classList.remove('printing');d.remove();if(onClose)onClose()};
  document.addEventListener('keydown',onKey);
  d.onclick=e=>{if(e.target===d)close()};
  d.querySelector('[data-k=close]').onclick=close;
  // The class stays until the sheet closes: the desktop window turns window.print() into a
  // PDF in the background, after this handler has already returned.
  d.querySelector('[data-k=print]').onclick=()=>{document.body.classList.add('printing');window.print()};
  d.querySelector('[data-k=copy]').onclick=async ev=>{
    const full=title+NL+NL+(intro?intro+NL+NL:'')+text, b=ev.target;
    try{await navigator.clipboard.writeText(full);b.textContent='Copied'}
    catch(_){let t=document.createElement('textarea');t.value=full;document.body.appendChild(t);t.select();try{document.execCommand('copy');b.textContent='Copied'}catch(__){}t.remove()}
  };
  d.querySelector('[data-k=close]').focus();
  return d;
}
function logFixes(){
  const l=window._lastLog||{}, ev=l.events||[], aide=l.source==='aide';
  let groups=[],seen={};
  ev.filter(e=>e.lvl==='bad'||e.lvl==='warn').forEach(e=>{
    const k=e.title+'|'+(e.fix||'')+(aide?'|'+e.text:'');
    if(seen[k]){seen[k].more=(seen[k].more||0)+1}else{seen[k]=Object.assign({},e);groups.push(seen[k])}
  });
  if(aide&&ev.length&&ev[0].lvl!=='warn'&&ev[0].lvl!=='bad') groups.unshift(ev[0]);
  if(!groups.length) groups=[{lvl:'good',title:'No action needed',text:'Nothing in this log currently needs attention.',fix:''}];
  const order={bad:0,warn:1,good:2,info:3}; if(!aide) groups.sort((a,b)=>order[a.lvl]-order[b.lvl]);
  showSheet('What to do: '+(l.label||'log'),'Every entry in this log that needs attention, with the recommended action. Generated '+new Date().toLocaleString()+'.',itemsHtml(groups),itemsText(groups));
}
async function idsCard(a){let el=document.getElementById('idscard');if(!el)return;let s;try{s=await api('/api/ids')}catch(e){el.innerHTML=`<div class="card"><h2>Intrusion detection (Suricata)</h2><p class="bad">${esc(e.message)}</p></div>`;return}if(a&&a.live&&!a.live())return;el=document.getElementById('idscard');if(!el)return;
const okst=s.state==='monitoring',sevw={1:'high',2:'medium',3:'low'},sevc={1:'bad',2:'warn',3:'note'};const fmt=t=>t?new Date(t*1000).toLocaleString():'never';
el.innerHTML=`<div class="card"><h2>Intrusion detection (Suricata)</h2>
<p>Suricata is a network intrusion detection system (IDS). It inspects the packets on this computer's network interface and compares them with tens of thousands of signatures describing known attacks, exploit attempts, malware command-and-control traffic and scanning. The threat lists above block addresses already known to be malicious; Suricata recognises the <i>behaviour</i>, including outbound traffic from an infected program on this computer, which a firewall and an address list do not see.</p>
<p class="muted">LocSec reads Suricata's alerts every minute. Severity runs from 1 (most serious) to 3. Alerts at severity ${esc(s.incident_severity)} or more serious become incidents; alerts at severity ${esc(s.block_severity)} or more serious also block the remote address for ${esc(s.block_hours||24)} hours when that address is certainly the sender (outbound traffic, or inbound TCP).</p>
<div class="grid"><div class="card"><div class="muted">State</div><div><span class="pill ${okst?'ok':(s.installed?'bad':'warn')}">${esc(s.state_text||'')}</span></div></div>
<div class="card"><div class="muted">Alerts, last 24 h</div><div class="metric">${esc(s.alerts_24h||0)}</div></div>
<div class="card"><div class="muted">By severity (recent)</div><div>${['1','2','3'].map(k=>`<span class="pill ${sevc[k]}">${sevw[k]}: ${esc((s.by_severity||{})[k]||0)}</span>`).join(' ')}</div></div>
<div class="card"><div class="muted">Rules</div><div class="metric">${s.rules_count!=null?esc(Number(s.rules_count).toLocaleString()):'none'}</div><div class="muted">updated ${esc(s.rules_updated?new Date(s.rules_updated*1000).toLocaleDateString():'never')}</div></div></div>
<table><tr><th>Capture interface</th><td>${esc((s.capture_ifaces||[]).join(', ')||'not configured')}${s.route_iface?` <span class="muted">(this computer's network connection: ${esc(s.route_iface)})</span>`:''}</td></tr>
<tr><th>Alert log</th><td><code>${esc((s.eve||{}).path||'')}</code> ${s.eve&&s.eve.exists?`<span class="muted">${esc(fmtBytes(s.eve.size))}, last written ${esc(fmt(s.eve.mtime))}</span>`:'<span class="muted">(not present)</span>'}</td></tr>
<tr><th>Alerts since LocSec started</th><td>${esc(s.alerts_seen||0)}${s.last_alert?`, the last at ${esc(fmt(s.last_alert))}`:''}; blocks this hour: ${esc(s.blocks_this_hour||0)}</td></tr></table>
${s.hint?`<p class="bad">${esc(s.hint)}</p>`:''}
${s.why_empty?`<h3>Why there are no alerts</h3><p>${esc(s.why_empty)}</p>`:''}
${(s.top_signatures||[]).length?`<h3>Most frequent signatures</h3><div class="scroll"><table><tr><th>Signature</th><th>Category</th><th>Severity</th><th>Rule (sid)</th><th>Count</th><th>Last</th></tr>${s.top_signatures.map(t=>`<tr><td>${esc(t.sig)}</td><td>${esc(t.cat)}</td><td><span class="pill ${sevc[Math.min(Math.max(t.sev,1),3)]}">${esc(sevw[Math.min(Math.max(t.sev,1),3)])}</span></td><td>${esc(t.sid)}</td><td>${esc(t.n)}</td><td>${esc(fmt(t.last))}</td></tr>`).join('')}</table></div>`:''}
${(s.recent||[]).length?`<h3>Recent alerts</h3><div class="scroll"><table><tr><th>Time</th><th>Severity</th><th>Signature</th><th>Direction</th><th>From</th><th>To</th><th>Protocol</th></tr>${s.recent.map(r=>`<tr><td>${esc(r.ts?new Date(r.ts*1000).toLocaleString():r.tstr)}</td><td><span class="pill ${sevc[Math.min(Math.max(r.sev,1),3)]}">${esc(sevw[Math.min(Math.max(r.sev,1),3)])}</span></td><td>${esc(r.sig)}${r.ignored?' <span class="muted">(ignored)</span>':''}<br><small class="muted">${esc(r.cat)} &middot; sid ${esc(r.sid)}</small></td><td>${esc(r.direction)}</td><td>${esc(r.src)}${r.sport!=null?':'+esc(r.sport):''}</td><td>${esc(r.dst)}${r.dport!=null?':'+esc(r.dport):''}</td><td>${esc(r.proto)}</td></tr>`).join('')}</table></div>`:''}
<p class="muted">Full history: Logs page, source <b>Suricata alerts</b>. Engine start-up and errors: source <b>Suricata engine</b>. To silence a rule that misfires on your network, add its sid to <code>ids_ignore_sids</code> in /etc/locsecd/locsecd.conf.</p></div>`}
const LOG_INTRO={
 locsecd:`LocSec's own activity log: blocked computers, scans, threat-list updates and configuration changes.`,
 auth:`Authentication log: logins, failed passwords, sudo and polkit use, and session start/stop.`,
 rkhunter:`rkhunter rootkit scanner output. Each line is one check and its result.`,
 clamav:`freshclam log: daily ClamAV malware-signature updates.`,
 aide:`AIDE file-integrity check: files added, removed or changed since the last baseline. Package updates also change files, so each change is matched against recent installs.`,
 ufw:`Firewall log: connection attempts the firewall refused (or allowed and logged), with the remote address and the port it tried. Most entries are automated internet scanners testing which ports answer; they are refused and need no action.`,
 syslog:`System log: messages from the kernel, systemd and running services.`,
 suricata:`Suricata intrusion-detection alerts: network traffic that matched a known attack, malware or scanning signature. Only alert records are shown; eve.json also holds flow, DNS and TLS records, which are filtered out. An empty list is normal on a quiet network.`,
 'suricata-engine':`Suricata's own engine log: start-up, rule loading, the interface it captures on, and errors. Read this when Suricata is not running or shows no rules.`
};
const LVL={good:['ok','OK'],info:['note','Info'],warn:['warn','Warning'],bad:['bad','Problem']};
let LOG_FILTER='all';
function lvlPill(l){const x=LVL[l]||LVL.info;return `<span class="pill ${x[0]}">${x[1]}</span>`}
function logWhen(e){return e.ts?esc(new Date(e.ts*1000).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit',second:'2-digit'})):esc(e.tstr||'')}
function setLogFilter(v){LOG_FILTER=v;const el=document.getElementById('logsrc');renderLogs(el?el.value:'locsecd')}
function ufwView(l,shown){
  const s=l.summary||{};
  const top=(s.top_sources||[]).map(x=>`<tr><td><b>${esc(x.ip)}</b><br><span class="muted">from ${esc(x.where)}</span></td><td>${esc(x.count)}</td><td>${esc((x.doors||[]).join(', '))}</td><td>${x.listed?'<span class="pill warn">blocked computer</span> ':''}${x.scanner?'<span class="pill bad">port scan</span>':''}${(!x.listed&&!x.scanner)?'<span class="muted">routine</span>':''}</td></tr>`).join('');
  const doors=(s.top_doors||[]).map(d=>`<tr><td><b>${esc(d.door)}</b></td><td>${esc(d.name||'uncommon port')}</td><td>${esc(d.count)}</td></tr>`).join('');
  return `<div class="fwsum"><p class="big">The firewall blocked <b>${esc(s.stopped||0)}</b> connection attempt(s)${s.allowed?` and allowed <b>${esc(s.allowed)}</b>`:''}, from <b>${esc(s.sources||0)}</b> different source(s).</p>
<div class="grid2"><div><h3>Top sources</h3><table><tr><th>Source</th><th>Attempts</th><th>Ports tried</th><th>Assessment</th></tr>${top||'<tr><td colspan="4" class="muted">Nobody.</td></tr>'}</table></div><div><h3>Most-targeted ports</h3><table><tr><th>Port</th><th>Service</th><th>Attempts</th></tr>${doors||'<tr><td colspan="3" class="muted">None.</td></tr>'}</table></div></div></div>
<h3>All entries, newest first</h3><div class="scroll tall"><table class="loglist"><tr><th style="width:130px">When</th><th style="width:96px">Action</th><th style="width:170px">Source</th><th style="width:170px">Port</th><th>Why</th></tr>${shown.map(e=>{const f=e.fw||{};return `<tr class="lv-${esc(e.lvl)}"><td class="muted">${logWhen(e)}${e.repeat>1?`<br><span class="rep">${esc(e.repeat)} times</span>`:''}</td><td><span class="pill ${f.verdict==='Blocked'?'ok':'note'}">${esc(f.verdict||'Note')}</span></td><td>${f.from?`<b>${esc(f.from)}</b><br><span class="muted">${esc(f.direction==='outbound'?'this computer, sending to '+(f.to||'?'):'from '+(f.from_where||'?'))}</span>`:'<span class="muted">-</span>'}${f.listed?'<br><span class="pill warn">blocked computer</span>':''}</td><td>${f.door?`<b>${esc(f.door)}</b>${f.door_name?`<br><span class="muted">${esc(f.door_name)}</span>`:''}`:'<span class="muted">-</span>'}</td><td>${esc(e.text)}</td></tr>`}).join('')||'<tr><td colspan="5" class="muted">No entries need attention.</td></tr>'}</table></div>`;
}
let LOG_SEQ=0;
async function renderLogs(src,guard){
  const seq=++LOG_SEQ;
  let a=document.getElementById('pagebody');
  let s=await api('/api/log-sources');
  let opts=(s.sources||[]).map(x=>`<option value="${esc(x.key)}" ${x.key===src?'selected':''}>${esc(x.label)}${x.available?'':' (no entries yet)'}</option>`).join('');
  let cur=(s.sources||[]).find(x=>x.key===src)||{};
  let l=await api('/api/logs?source='+encodeURIComponent(src));
  // Another page, or a newer pick of log, was chosen while this one loaded.
  if(seq!==LOG_SEQ||currentPage!=='logs'||(guard&&!guard.live())) return;
  let ev=l.events||[]; l.label=cur.label||src; window._lastLog=l;
  let cnt={good:0,info:0,warn:0,bad:0};ev.forEach(e=>{cnt[e.lvl]=(cnt[e.lvl]||0)+1});
  let shown=LOG_FILTER==='attention'?ev.filter(e=>e.lvl==='warn'||e.lvl==='bad'):ev;
  let list;
  if(l.error) list=`<p>${esc(l.error)}</p>`;
  else if(!ev.length) list=`<p class="muted">Nothing is written here yet.</p>`;
  else if(src==='ufw') list=ufwView(l,shown);
  else list=`<div class="scroll tall"><table class="loglist"><tr><th style="width:140px">When</th><th style="width:96px">Kind</th><th>What happened</th></tr>${shown.map(e=>`<tr class="lv-${esc(e.lvl)}"><td class="muted">${logWhen(e)}</td><td>${lvlPill(e.lvl)}</td><td><b>${esc(e.title)}</b>${repHtml(e)}<br>${esc(e.text)}${fixHtml(e.fix)}</td></tr>`).join('')||'<tr><td colspan="3" class="muted">Nothing that needs a look. Everything here is fine.</td></tr>'}</table></div>`;
  let raw=(l.lines||[]).length?`<details class="raw"><summary>Show the original log lines (${esc((l.lines||[]).length)})</summary><pre>${esc((l.lines||[]).join('\\n'))}</pre></details>`:'';
  a.innerHTML=`<div class="card logcard"><h2>Security logs</h2><div class="toolbar"><label>Log: <select id="logsrc" onchange="renderLogs(this.value)">${opts}</select></label><label>Show: <select id="logfilter" onchange="setLogFilter(this.value)"><option value="all" ${LOG_FILTER==='all'?'selected':''}>Everything</option><option value="attention" ${LOG_FILTER==='attention'?'selected':''}>Only things to look at</option></select></label><button class="act" id="logrefresh" onclick="refreshLogs()">Refresh</button>${l.error?'':'<button class="act" onclick="logFixes()">What to do</button>'}${cur.clearable?`<button class="act danger" onclick="clearLog(${esc(JSON.stringify(src))})">Clear LocSec's log</button>`:''}<span class="muted">Loaded ${esc(new Date().toLocaleTimeString())}</span></div>
<p class="intro">${esc(LOG_INTRO[src]||'')}</p>
${l.error?'':`<div class="tally">${['bad','warn','good','info'].map(k=>`<span>${lvlPill(k)} ${esc(cnt[k]||0)}</span>`).join('')}<span class="muted">${src==='aide'&&(l.path||'').indexOf('aide-full-')>=0?'Most important first':'Newest first'}. ${esc(ev.length)} entries${l.path?', from '+esc(l.path):''}.</span></div>`}
${list}${raw}<pre id="r"></pre></div>`;
}
async function unblock(ip){const r=await run('/api/unblock',{ip});await page('firewall');if(r&&!r.ok)flash('Unblock: '+(r.error||'unknown reason'))}
async function repcheck(){show(await run('/api/reputation',{indicator:document.getElementById('rep').value}))}
async function capture(){const x=await run('/api/capture/start',{iface:document.getElementById('iface').value,seconds:Number(document.getElementById('secs').value)});if(x&&x.ok)page('network')}
const STATUS_LABEL={'updated':'Updated','up-to-date':'Up to date','ok':'Clean / no findings','info':'Informational (no action needed)','warning':'Warnings (review output)','findings-or-error':'Findings (review output)','timeout':'Timed out','error':'Scan error','busy':'Skipped (another job is running)','not-installed':'Tool not installed','not-initialized':'Not initialized yet','skipped':'Skipped (not applicable on this OS)'};
function statusPill(status,rc){
  let label = STATUS_LABEL[status] || status || (rc===0?'OK':(rc!==undefined?`Exit code ${esc(rc)}`:''));
  let cls = (status==='ok'||status==='info'||status==='updated'||status==='up-to-date'||(rc===0&&!status)) ? 'ok' : (status==='not-installed'||status==='skipped'||status==='not-initialized'||status==='busy'||status==='warning') ? '' : 'bad';
  return `<span class="pill ${cls||'bad'}" style="${cls?'':'background:rgba(255,181,71,.14);color:var(--warn)'}">${esc(label)}</span>`;
}
function renderAptUpgrade(text){
  let rows=[];
  (text||'').split('\\n').forEach(line=>{
    let m=line.match(/^Inst (\\S+) \\[(.*?)\\] \\((\\S+)/);
    if(m) rows.push({pkg:m[1],old:m[2],neu:m[3]});
  });
  if(!rows.length) return `<p class="muted">No pending security/maintenance updates found.</p>`;
  return `<p class="muted">${rows.length} package(s) have an update available (security or maintenance):</p><table><tr><th>Package</th><th>Installed</th><th>Available</th></tr>${rows.map(r=>`<tr><td>${esc(r.pkg)}</td><td>${esc(r.old)}</td><td>${esc(r.neu)}</td></tr>`).join('')}</table>`;
}
const PRE_MAX=200000;
function capText(t){
  t=String(t??'');
  return t.length>PRE_MAX ? t.slice(0,PRE_MAX)+'\\n\\n... display truncated at '+PRE_MAX+' characters. Open the report file on disk for the rest.' : t;
}
function renderResult(r){
  const name=r.name||'Result';
  const body = (name==='APT security candidates') ? renderAptUpgrade(r.output) : `<pre>${esc(capText(r.output!==undefined?r.output:JSON.stringify(r,null,2)))}</pre>`;
  const note = r.note ? `<div class="banner show" style="position:static;margin-bottom:12px"><span>${esc(r.note)}</span></div>` : '';
  const ex = Array.isArray(r.explain)&&r.explain.length ? `<div class="explain">${itemsHtml(r.explain)}</div>` : '';
  const changedList = Array.isArray(r.changed) ? (r.changed.length?`<p class="muted">${r.changed.length} package(s) applied:</p><ul style="margin:0 0 10px;padding-left:18px">${r.changed.map(c=>`<li>${esc(c)}</li>`).join('')}</ul>`:'<p class="muted">No packages were applied.</p>') : '';
  const shown = ex ? (name==='APT security candidates' ? ex+body : ex+`<details class="raw"><summary>Show the full output</summary>${body}</details>`) : body;
  return `<div class="card"><h3>${esc(name)} ${statusPill(r.status,r.rc)}</h3>${note}${changedList}${shown}</div>`;
}
function renderReport(x){
  if(!x||!x.ok) return `<div class="card"><p class="bad">${esc((x&&x.error)||'Could not load report.')}</p></div>`;
  const rep=x.report||{};
  const when=rep.ts?new Date(rep.ts*1000).toLocaleString():'';
  let body;
  if(Array.isArray(rep.results)) body=rep.results.map(renderResult).join('');
  else if(rep.result) body=renderResult(Object.assign({name:'Result'},rep.result));
  else body=`<pre>${esc(capText(JSON.stringify(rep,null,2)))}</pre>`;
  const note = x.summarized ? `<p class="muted">Large report: shown as a summary. The complete document is on disk under /var/lib/locsecd/reports/.</p>` : '';
  window._lastReport=x;
  const fixBtn = (rep.results||[rep.result||{}]).some(r=>r&&Array.isArray(r.explain)&&r.explain.length) ? `<div class="toolbar" style="margin-bottom:0"><button class="act" onclick="reportFixes()">What to do</button></div>` : '';
  return `<div class="card"><h2>${esc(x.name)}</h2><p class="muted">${esc(when)}</p>${note}${fixBtn}</div>${body}`;
}
function reportFixes(){
  const x=window._lastReport||{}, rep=x.report||{}, res=Array.isArray(rep.results)?rep.results:(rep.result?[Object.assign({name:'Result'},rep.result)]:[]);
  let html='',text='';
  res.filter(r=>Array.isArray(r.explain)&&r.explain.length).forEach(r=>{html+=`<h3>${esc(r.name||'Result')}</h3>`+itemsHtml(r.explain);text+=(r.name||'Result').toUpperCase()+NL+itemsText(r.explain)+NL+NL});
  const when=rep.ts?new Date(rep.ts*1000).toLocaleString():'';
  showSheet('What to do: '+(x.name||'report'),'What each check found, in plain language, with how to fix it. Report from '+when+'.',html||'<p>Nothing to show.</p>',text);
}
async function readReport(name){
  const target=document.getElementById('reportview');
  const x=await run('/api/report/read',{name});
  if(target) target.innerHTML=renderReport(x);
}
async function deleteReport(name){await run('/api/report/delete',{name});page('reports')}
function renderCapture(x){
  if(!x||!x.ok) return `<div class="card"><p class="bad">${esc((x&&x.error)||'Could not analyze this capture.')}</p></div>`;
  const rows=(x.top||[]).map(t=>`<tr><td>${esc(t.src)}</td><td>${esc(t.dst)}</td><td>${t.port?esc(t.proto+' '+t.port):'<span class="muted">-</span>'}${t.door?`<br><span class="muted">${esc(t.door)}</span>`:''}</td><td>${esc(t.packets)}</td></tr>`).join('');
  const eng=x.engine==='tshark'?'Deep analysis (Wireshark decoders, sandboxed)':'Built-in analysis (headers only; Wireshark not used)';
  return `<div class="card"><h3>What is in ${esc(x.name)}</h3><p class="muted">${esc(eng)}</p><p>${esc(x.ip_packets)} IP packet(s) between ${esc(x.pairs)} pair(s) of computers.</p>
<h3>Who talked to whom (busiest first)</h3>${rows?`<div class="scroll"><table><tr><th>From</th><th>To</th><th>Port</th><th>Packets</th></tr>${rows}</table></div>`:'<p class="muted">No IP traffic in this capture.</p>'}
<details class="raw"><summary>Show the protocol breakdown</summary><pre>${esc(x.protocols||'')}</pre></details>
${x.engine!=='tshark'&&x.deep_available?`<p class="muted">The built-in analysis reads only the network and transport headers, which is enough to see who talked to whom. <b>Deep analysis</b> decodes every protocol with Wireshark's decoders. Those decoders have had many security bugs, and the packets in a capture were chosen by whoever sent them, so Wireshark runs as a throwaway unprivileged user with no network, a read-only system and LocSec's files hidden. Use it when you need the full protocol breakdown.</p>`:''}
<div class="toolbar" style="margin-top:12px">${x.engine!=='tshark'&&x.deep_available?`<button class="act" onclick="analyzeCapture(${esc(JSON.stringify(x.name))},this,true)">Deep analysis (Wireshark)</button>`:''}<button class="act danger" onclick="deleteCapture(${esc(JSON.stringify(x.name))})">Delete this capture and these results</button></div></div>`;
}
async function analyzeCapture(name,btn,deep){
  const i=document.getElementById('capname');if(i)i.value=name;
  if(!name){flash('Pick a capture first.');return}
  if(btn)btn.disabled=true;
  try{
    const x=await api('/api/capture/analyze',{method:'POST',body:JSON.stringify({name,deep:!!deep})});
    const v=document.getElementById('capview'); if(v){v.innerHTML=renderCapture(x); v.scrollIntoView({block:'start',behavior:'smooth'})}
  }catch(e){flash(e.message)}finally{if(btn)btn.disabled=false}
}
async function deleteCapture(name){
  if(!await uiConfirm('Delete capture','Delete '+name+' and its analysis? This cannot be undone. A capture still recording is stopped first.','Delete',true)) return;
  let x; try{ x=await api('/api/capture/delete',{method:'POST',body:JSON.stringify({name})}); }catch(e){ flash(e.message); return }
  if(!x.ok){flash(x.error||'Could not delete it.');return}
  page('network');
}
async function deleteAllCaptures(){
  if(!await uiConfirm('Delete all captures','Delete every saved capture and its analysis? This cannot be undone. Captures still recording are stopped first.','Delete all',true)) return;
  let x; try{ x=await api('/api/capture/delete-all',{method:'POST',body:'{}'}); }catch(e){ flash(e.message); return }
  if(!x.ok){flash(x.error||'Could not delete them.');return}
  page('network');
}
// The redraw after an action rebuilds the manual-control input, which used to
// clear whatever had been typed -- so a start-then-enable on the same unit
// meant typing the name twice. Keep it across redraws.
let MANUAL_UNIT='';
async function manualSvc(action){
  let el=document.getElementById('svcname');
  if(el) MANUAL_UNIT=el.value;
  if(!MANUAL_UNIT.trim()){ show('Enter a unit name first.'); return; }
  await svc(MANUAL_UNIT,action);
}
async function svc(unit,action){
  if(!unit)return;
  let x=await run('/api/service/action',{unit,action});
  // The redraw below rebuilds the page and with it the output box, so the
  // result has to be written back afterwards. Without this every action --
  // including every failure and its reason -- was erased the instant it
  // arrived, and the page simply redrew, which is why a refused stop or
  // restart looked like a button that did nothing at all.
  await page('services');
  let r=document.getElementById('r'); if(!r||!x) return;
  if(x.ok===false||x.error){
    r.textContent=(x.error?x.error:`${action} ${unit} failed`)
      +(x.rc!==undefined?` (exit ${x.rc})`:'')
      +(x.before!==undefined?`\nstate: ${x.before} -> ${x.after}`:'')
      +(x.output?`\n\n${x.output}`:'');
  }else{
    r.textContent=`${action} ${unit}: ok`
      +(x.before!==undefined?` (${x.before} -> ${x.after})`:'')
      +(x.output?`\n\n${x.output}`:'');
  }
}
async function savePolicy(){
  try{
    let b={auto_block:pol_auto.checked,response_auth_block:pol_auth.checked,response_feed_block:pol_feed.checked,ipv6_auto_block:pol_v6.checked,response_scan_block:pol_scan.checked,fallback_firewall:pol_fb.checked};
    let x=await api('/api/response-policy',{method:'POST',body:JSON.stringify(b)});
    let ch=Object.entries(x.changed||{}).map(([k,v])=>k+' = '+v).join(', ');
    document.getElementById('policyout').textContent=x.ok?('Saved. Applies immediately and survives restarts.'+(ch?'\\n'+ch:'')):JSON.stringify(x);
  }catch(e){ flash(e.message); }
}
async function loadPolicy(){
  try{
    let x=await api('/api/response-policy');let p=x.policy||{};
    for(let [id,k] of [['pol_auto','auto_block'],['pol_auth','response_auth_block'],['pol_feed','response_feed_block'],['pol_v6','ipv6_auto_block'],['pol_scan','response_scan_block'],['pol_fb','fallback_firewall']]){let e=document.getElementById(id);if(e)e.checked=!!p[k]}
  }catch(e){ flash(e.message); }
  loadNotifySettings();
}
// --- Desktop notifications -------------------------------------------------
// Maps the checkbox id shown on the Incidents page to the incident "kind"
// the daemon records. The daemon sends the notification itself; this page only
// edits which kinds are enabled and can send a test.
const NOTIFY_KINDS={ntf_virus:'virus-found',ntf_rootkit:'rootkit-warning',ntf_block:'block',ntf_login:'login-failure',ntf_scan:'port-scan',ntf_ids:'ids-alert',ntf_fb:'firewall-fallback'};
async function saveNotifySettings(){
  try{
    let b={}; for(let [id,kind] of Object.entries(NOTIFY_KINDS)){let e=document.getElementById(id); if(e) b[kind]=e.checked}
    await api('/api/notify-settings',{method:'POST',body:JSON.stringify(b)});
    document.getElementById('notifyout').textContent='Saved. Applies immediately and survives restarts.';
  }catch(e){ flash(e.message); }
}
async function loadNotifySettings(){
  try{
    let x=await api('/api/notify-settings');
    for(let [id,kind] of Object.entries(NOTIFY_KINDS)){let e=document.getElementById(id); if(e) e.checked=!!(x.notify_on||{})[kind]}
  }catch(e){ /* Incidents page may not be open; ignore. */ }
  loadNotifyHistory();
}
async function loadNotifyHistory(){
  const el=document.getElementById('notifyhist'); if(!el) return;
  try{
    const h=await api('/api/notifications'), it=h.items||[];
    const shown={true:'Shown',false:'Waiting for a log-in',later:'Shown at log-in'};
    el.innerHTML=it.length?`<div class="toolbar"><button class="act danger" onclick="clearNotifyHistory()">Clear history</button></div><div class="scroll"><table><tr><th>When</th><th>Notification</th><th>On screen</th></tr>${it.map(r=>`<tr><td>${esc(new Date((r.ts||0)*1000).toLocaleString())}</td><td><b>${esc(String(r.title||'').replace(/^LocSec: /,''))}</b><br>${esc(r.text||'')}</td><td>${esc(shown[String(r.shown)]||'')}</td></tr>`).join('')}</table></div>`:'<p class="muted">No notifications yet.</p>';
  }catch(e){ el.innerHTML='<p class="muted">Could not load the history.</p>'; }
}
async function clearNotifyHistory(){
  if(!await uiConfirm('Clear notification history','Delete the list of past notifications? Incidents are not affected.','Clear',true)) return;
  try{ await api('/api/notifications/clear',{method:'POST',body:'{}'}); }catch(e){ flash(e.message); return }
  loadNotifyHistory();
}
async function testNotification(){
  try{
    let x=await api('/api/notify-test',{method:'POST',body:'{}'});
    document.getElementById('notifyout').textContent=x.ok?'Test notification sent to '+x.sessions+' desktop session(s).':(x.error||'Not sent.');
  }catch(e){ flash(e.message); }
}

async function healthPing(){
  const dot=document.getElementById('hdot'),txt=document.getElementById('htext');
  try{
    await api('/api/health');
    dot.className='dot up'; txt.textContent='Service online';
    if(document.getElementById('jobnow')) showJob();
  }catch(e){
    dot.className='dot down'; txt.textContent=/Session expired/.test(e.message)?'Signed out: reopen LocSec':'Service unreachable';
  }
}

const TROUBLESHOOTING_HTML=`
<div class="card"><h2>Troubleshooting</h2><p class="muted">Start with the symptom, then follow the checks in order. Every command below can be run from a terminal; anything that needs root is shown with <code>sudo</code>. For deeper diagnosis, open the <a href="#ts-log">Logs page</a> or run <code>locsecctl logs</code>.</p>
<table><tr><th>Area</th><th>Symptoms covered</th></tr>
<tr><td><a href="#ts-service">Service &amp; access</a></td><td>Dashboard unreachable, missing token, password prompt, "not in the sudoers file", blank desktop window, panel icon</td></tr>
<tr><td><a href="#ts-status">Reading scan statuses</a></td><td>What each status label means and when to act</td></tr>
<tr><td><a href="#ts-clamav">ClamAV</a></td><td>Errors, repeated summaries, scan scope, AppArmor messages, clamscan vs clamdscan</td></tr>
<tr><td><a href="#ts-aide">AIDE</a></td><td>Timeouts, a slow Rebuild or Initialize, differences after updates, pending database</td></tr>
<tr><td><a href="#ts-quarantine">Quarantine</a></td><td>A file will not quarantine or restore, older items, where quarantined files live</td></tr>
<tr><td><a href="#ts-lynis">Lynis &amp; rkhunter</a></td><td>Informational warnings, sandbox messages, hidden files</td></tr>
<tr><td><a href="#ts-cve">CVE scan &amp; reports</a></td><td>What the CVE scan covers, large reports</td></tr>
<tr><td><a href="#ts-updates">Updates</a></td><td>Updates that do not apply, held packages, apt lock</td></tr>
<tr><td><a href="#ts-ids">Intrusion signatures (Suricata)</a></td><td>The Add button fails or times out, suricata missing after install, not running, no rules, wrong interface, no alerts, false alarms</td></tr>
<tr><td><a href="#ts-fallback">UFW is off: fallback firewall and port-scan blocks</a></td><td>What protects the machine while UFW is disabled, and what a scan block means</td></tr>
<tr><td><a href="#ts-schedule">Schedules &amp; jobs</a></td><td>Scans that never start, "another job is running", threat feeds failing to update</td></tr>
<tr><td><a href="#ts-notify">Notifications</a></td><td>No desktop notification appears</td></tr>
<tr><td><a href="#ts-incidents">Incident grouping</a></td><td>Repeat rows for one address, a count that stopped rising</td></tr>
<tr><td><a href="#ts-services">Services page</a></td><td>Manual control refused or did nothing, why an action failed, what PID means.</td></tr>
<tr><td><a href="#ts-exited">Service state</a></td><td>ufw or another unit shown as "exited" while it is running</td></tr>
<tr><td><a href="#ts-bounce">Service will not stop</a></td><td>A stopped unit restarts itself, or its row disappears</td></tr>
<tr><td><a href="#ts-manual">Manual control</a></td><td>"invalid unit name"; enable/disable results; masked units</td></tr>
<tr><td><a href="#ts-verify">Verifying the install</a></td><td>Checking installed files against what the package shipped</td></tr>
<tr><td><a href="#ts-logsrc">Logs page sources</a></td><td>Sources shown as "not found" or "(no entries yet)", especially on Debian</td></tr>
<tr><td><a href="#ts-logs">Log and report disk use</a></td><td>Whether logs or reports fill up the disk, and clearing LocSec's log</td></tr>
<tr><td><a href="#ts-kill">Stop, restart, kill</a></td><td>What each leaves behind, and what a kill can lose</td></tr>
<tr><td><a href="#ts-harden">Post-install changes</a></td><td>The kernel hardening the package applies, and how to revert it</td></tr>
<tr><td><a href="#ts-log">Collecting diagnostics</a></td><td>What to gather before asking for help</td></tr>
</table></div>

<div class="card" id="ts-service"><h2>Service &amp; access</h2>
<h3>Dashboard unreachable, or "service not running / API token missing"</h3>
<ol>
<li>Check the service: <code>locsecctl status</code>. If it is not active, run <code>sudo systemctl restart locsecd.service</code> and read <code>locsecctl logs</code> for the reason.</li>
<li>Confirm the listener: <code>sudo ss -ltnp | grep 8765</code>. The dashboard binds to <code>127.0.0.1:8765</code> and speaks HTTPS only (the port is <code>port</code> in the configuration). It only ever listens on this machine. <code>listen</code> stays in the configuration at <code>127.0.0.1</code> so the address is visible, but it is pinned: from 4.0.11-62 any other value is replaced by 127.0.0.1 and the log says so, because the dashboard is a root control panel and must never be reachable from the network. Requests addressed to any other host name are refused (421), which stops DNS-rebinding pages.</li>
<li><b>Dashboard will not open, or the log says "dashboard NOT started".</b> The dashboard needs the certificate made for this machine at install: the private key <code>/etc/locsecd/dashboard.key</code> (root only, mode 0600) and the public certificate <code>/etc/ssl/locsecd/dashboard.crt</code>. Without a usable pair the daemon keeps monitoring and blocking but leaves the dashboard off, rather than fall back to plain HTTP. Fix: <code>sudo locsecctl tls-renew &amp;&amp; sudo systemctl restart locsecd</code>. A running panel icon keeps the old certificate until it is restarted: <code>pkill -f locsec-gui; locsecctl tray</code>. <code>locsecctl tls-fingerprint</code> prints the certificate's SHA-256 fingerprint.</li>
<li>The API token lives in <code>/var/lib/locsecd/api.token</code> and is readable only by root. The desktop app reads it through a one-time <code>pkexec</code> prompt (packages <code>pkexec</code> and <code>polkitd</code>). GNOME, KDE Plasma, Cinnamon, MATE and LXQt provide the polkit agent that shows that prompt. On a session with no agent (bare Xfce, i3 and other window managers) the app asks for your <code>sudo</code> password instead; to get the normal prompt there, install one agent, e.g. <code>sudo apt install mate-polkit</code>, and log in again.</li>
<li><b>The dashboard opens in a browser instead of a window.</b> PyQt6 is not installed (the package depends on it, so this only happens if it was removed by hand). "LocSec Security Center" then opens the dashboard in your default browser instead. It reads the token through <code>pkexec</code> as usual, sends it once in a request header to get a single-use login code that is valid for 60 seconds, and opens the browser with only that code in the address. The long-lived token never reaches browser history, and a code copied from history afterwards is refused. If the browser shows "login code expired or already used", open LocSec again. On releases that do package it, <code>sudo apt install python3-pyqt6.qtwebengine</code> brings back the desktop window.</li>
<li>The <code>sudo</code> fallback only works if your account may use sudo. "<i>user</i> is not in the sudoers file" means it may not: Debian 13 does not add the first user to the <code>sudo</code> group when a root password is set during installation. Become root with <code>su -</code>, run <code>usermod -aG sudo <i>user</i></code>, then log out and back in. <code>groups</code> should then list <code>sudo</code>. Until then, run privileged commands from this page as root via <code>su -</code>.</li>
</ol>
<h3>Calling the API from a script</h3>
<p>Every JSON endpoint requires the token in an <code>X-LocSec-Token</code> header. The dashboard page itself is opened with a single-use login code (<code>POST /api/login-code</code>, then <code>/dashboard?code=...</code>); the <code>?token=</code> parameter is no longer accepted.</p>
<pre>TOKEN=$(sudo cat /var/lib/locsecd/api.token)
curl -s --cacert /etc/ssl/locsecd/dashboard.crt -X POST https://127.0.0.1:8765/api/scan-job -H "X-LocSec-Token: $TOKEN" -H "Content-Type: application/json" -d '{"job":"clamav"}'</pre>
<h3>Desktop window is blank or white</h3>
<p>Some hybrid-graphics, virtual-machine and XWayland setups fail to render the embedded view. GPU acceleration is already disabled in the app. If the window is still blank, launch it once with <code>QTWEBENGINE_DISABLE_SANDBOX=1 locsec-gui</code> (this disables the Chromium sandbox; use it only on a trusted desktop session), or open the dashboard in a normal browser: <code>POST /api/login-code</code> as shown above, then open <code>https://127.0.0.1:8765/dashboard?code=CODE</code>. The browser warns once that the certificate is self-signed; compare the SHA-256 fingerprint it shows with <code>locsecctl tls-fingerprint</code> before continuing.</p>
<h3>Panel icon</h3>
<p>From 4.0.11-63 LocSec puts a shield icon in the panel's status area (next to the clock, volume and network icons) when you log in, and that icon is LocSec's only panel entry: the window is kept off the taskbar. The icon is blue while <code>locsecd</code> is running and turns amber with an exclamation mark, with a notification, when the service stops or fails. Click it to show or hide the dashboard; its menu has <b>Open LocSec Security Center</b>, the service state, <b>Start at login</b> and <b>Quit panel icon</b>. Closing the window hides it to the panel. Quitting the icon only closes the desktop app; the <code>locsecd</code> service keeps protecting the machine. Opening LocSec again from the applications menu, or running <code>locsecctl tray</code>, brings the icon back. Only one copy runs per user. No password is asked at login; the dashboard asks for it the first time you open the window.</p>
<ul>
<li><b>GNOME</b> on Debian shows panel icons only through the AppIndicator extension: <code>sudo apt install gnome-shell-extension-appindicator</code>, then log out and back in. LocSec switches the extension on for your account if it is installed but off. Ubuntu ships it enabled.</li>
<li><b>KDE Plasma, Cinnamon, Xfce, MATE, LXQt, LXDE, Budgie, Deepin and COSMIC</b> show it with no extra setup, as long as the panel has its tray item (Status Tray / Notification Area / System Tray / Status Notifier, present by default). If it was removed, LocSec shows a one-time message saying where to add it back for your desktop.</li>
<li><b>elementary OS (Pantheon)</b> needs the Ayatana indicator in its top panel: <code>sudo apt install wingpanel-indicator-ayatana</code>, then log out and back in.</li>
<li><b>Tiling and standalone window managers</b> (sway, Hyprland, i3 and similar) need a bar with a tray (Waybar's <code>tray</code> module, i3bar, polybar), a notification daemon (mako or dunst) for pop-ups, and a polkit agent for the password dialog; without an agent LocSec asks for your sudo password itself. They do not run <code>/etc/xdg/autostart</code> entries unless your config does (for example with <code>dex -a</code>); add <code>locsecctl tray</code> to your startup commands instead.</li>
<li>To stop it starting at login, untick <b>Start at login</b> in its menu (per user), or remove it in your desktop's Startup Applications. The system-wide entry is <code>/etc/xdg/autostart/locsec-tray.desktop</code>.</li>
<li>On a Wayland session other than GNOME the window runs through XWayland so it can stay off the taskbar. Set <code>QT_QPA_PLATFORM=wayland</code> before launching to run it natively instead; the window then shows a taskbar button while it is open.</li>
</ul></div>

<div class="card" id="ts-status"><h2>Reading scan statuses</h2><p>Each scan result carries a status label. The label reflects what the tool actually reported, not just whether it ran.</p>
<table><tr><th>Status</th><th>Meaning</th><th>Action</th></tr>
<tr><td>Clean / no findings</td><td>The tool completed and reported nothing of concern.</td><td>None.</td></tr>
<tr><td>Informational</td><td>The tool completed; remaining output is expected noise (for example Lynis timing notes).</td><td>None. Review only if curious.</td></tr>
<tr><td>Warnings</td><td>Completed with warnings or hardening suggestions.</td><td>Review the output and the Lynis suggestions.</td></tr>
<tr><td>Findings</td><td>Completed and found something that needs a decision: infected files, changed files, rootkit warnings, open CVEs.</td><td>Open the report and act on each item.</td></tr>
<tr><td>Timed out</td><td>The job exceeded its time limit and was stopped cleanly.</td><td>Raise the matching timeout key (see AIDE below) and run it again.</td></tr>
<tr><td>Scan error</td><td>The tool failed to run or to produce usable output.</td><td>Read the output tail in the report, then see the section for that tool.</td></tr>
<tr><td>Skipped</td><td>Not applicable here (for example debsecan on Ubuntu or Mint; LMDE runs it), or another job held the lock.</td><td>None; re-run later if it was the lock.</td></tr>
<tr><td>Tool not installed / Not initialized</td><td>A required package is missing, or AIDE has no baseline yet.</td><td>Use <b>Add</b> on the Overview page, or <b>Build AIDE database</b> on the Scans page.</td></tr>
</table></div>

<div class="card" id="ts-clamav"><h2>ClamAV</h2>
<h3>Scope and how the scan runs</h3>
<p>The scheduled ClamAV job scans the directories listed in <code>clamav_scan_paths</code> (default: <code>/home</code>) in a single pass and produces one summary. Files larger than <code>clamav_max_file_mb</code> (100 MB by default) are skipped, and the job is limited by <code>clamav_timeout</code>. LocSec builds the list of files to scan itself and leaves out pseudo and virtual filesystems (<code>/proc</code>, <code>/sys</code>, <code>/dev</code>, <code>/run</code>, <code>/snap</code>), eCryptFS internals, documentation, icons and the quarantine vault. It does not edit <code>/etc/clamav/clamd.conf</code>, which belongs to the ClamAV package (from 4.0.11-102; earlier builds appended <code>ExcludePath</code> lines there, which made ClamAV upgrades ask about the file, and the installer now removes them when that restores the package's version). The job runs in a separate systemd unit so that clamd receives regular file descriptors; if a batch fails as a whole, LocSec retries it through a stream scan and then through <code>clamscan</code>.</p>
<h3>Do I need both clamscan and clamdscan?</h3>
<p>Yes, keep both installed (packages <code>clamav</code> and <code>clamav-daemon</code>). Scheduled scans use <code>clamdscan</code> through the clamd daemon, which is much faster because the signature database stays loaded. <code>clamscan</code> is the fallback if clamd is down or a batch fails, and it is what scans a single file for the Malware / Quarantine page.</p>
<h3>Scan reports many errors, or shows more than one summary</h3>
<ol>
<li>Confirm you are on the current version: <code>dpkg -s locsecd | grep Version</code>. Older builds scanned the whole filesystem and printed a summary per batch.</li>
<li>Check what was left out: the report's "Files listed" line counts the files scanned and those skipped (too big, special, in excluded paths). The exclusions are LocSec's own list plus <code>clamav_extra_excludes</code>; <code>clamd.conf</code> is not involved.</li>
<li>Check the daemon is healthy: <code>systemctl status clamav-daemon</code> and <code>sudo journalctl -u clamav-daemon -n 50 --no-pager</code>.</li>
<li>Add site-specific exclusions with <code>clamav_extra_excludes</code> in <code>/etc/locsecd/locsecd.conf</code>, then restart LocSec.</li>
</ol>
<h3>AppArmor "DENIED" messages for clamd</h3>
<p>Occasional entries of the form <code>Failed name lookup - disconnected path</code> mean a file was removed or renamed while it was being scanned, which is normal on a busy desktop. A sustained high rate is worth investigating: <code>sudo journalctl -k --since "1 hour ago" | grep -i "apparmor.*clamd"</code>.</p></div>

<div class="card" id="ts-aide"><h2>AIDE</h2><h3>Which AIDE button do I use?</h3><p>LocSec never changes the AIDE database by itself. The weekly check only compares the system against <code>aide.db</code>; the baseline changes only when you press a button.</p><table><tr><th>Situation</th><th>What to do</th></tr><tr><td>New machine, or the check says AIDE is not initialized</td><td>Press <b>Build AIDE database</b> once.</td></tr><tr><td>The weekly check is clean</td><td>Nothing.</td></tr><tr><td>The check shows differences you recognize, such as package updates or a config change you made</td><td>Review the report, then press <b>Build AIDE database</b>. The same differences are reported every week until you do.</td></tr><tr><td>The check shows differences you do not recognize (under <code>/etc</code>, <code>/usr/bin</code>, <code>/boot</code>, <code>~/.ssh</code>)</td><td>Press neither button. Investigate first.</td></tr><tr><td>You just pressed <b>Build AIDE database</b> and it finished</td><td>Nothing. It is already the active baseline; no Accept step is needed.</td></tr><tr><td>The <b>Accept pending AIDE baseline</b> button is visible</td><td>A pending <code>aide.db.new</code> that differs from <code>aide.db</code> exists. Review the differences; accept only if you want it to become the baseline.</td></tr></table><p><b>Build AIDE database</b> hashes the system as it is now and treats that as normal, with no backup of the old baseline, so changes you have not explained become the new normal. <b>Accept pending AIDE baseline</b> keeps the previous database as <code>aide.db.locsec-backup</code>, so it can be rolled back.</p>
<h3>Check, Initialize or Rebuild timed out</h3>
<p>One limit covers all three: <code>aide_scan_timeout</code> (10800 seconds by default). A large home directory or slow disk can need more; raise the value, restart LocSec and run the check again. AIDE runs at idle I/O priority, so it is slower on a busy machine by design.</p>
<h3>Rebuild or Initialize is taking a long time</h3>
<p>Hashing every file takes as long as a full check: minutes on a small SSD, an hour or more on a large home directory or a slow disk. It is not stuck if <code>ps -eo pid,etime,stat,pcpu,cmd | grep [a]ide</code> shows exactly one <code>aide --init</code> using CPU. The new database is written only when hashing finishes, so <code>aide.db.new</code> does not grow while it runs and memory use climbs until the end.</p>
<ul style="margin:0;padding-left:18px;line-height:1.7">
<li>Output goes to <code>/var/log/aide/aideinit.log</code> and <code>/var/log/aide/aideinit.errors</code>. A steady trickle of warnings is normal; a flood from <code>/home/.ecryptfs</code> means the eCryptfs exclude is missing.</li>
<li>It is finished when no aide process remains and the database is fresh: <code>sudo ls -l /var/lib/aide/</code>.</li>
<li>Do not click Rebuild again or start <code>aide --init</code> by hand while it runs; two writers race on the same database.</li>
<li>If it reaches <code>aide_scan_timeout</code> it is stopped and the existing baseline is left unchanged. Raise the limit or exclude large trees you do not need checked, then run it again.</li>
</ul>
<h3>Thousands of differences, or the report is cut off in the middle</h3>
<p>A desktop changes thousands of files a day that say nothing about tampering: browser caches, the software-centre icon catalogue, logs. From 4.0.11-61 an AIDE result opens with a <b>LocSec summary</b>: every change in a security-relevant place listed by name (system binaries and libraries, <code>/etc</code>, <code>/boot</code>, root's home, cron, and the login, autostart and SSH files in each home), and everything else counted by directory. The dashboard copy of the raw output is still shortened; the complete output is saved as <code>/var/lib/locsecd/reports/aide-full-&lt;time&gt;.txt</code> (the newest 10 are kept, each for 7 days). Read it with <code>sudo less</code>, or pick <b>AIDE (latest check)</b> on the Logs page.</p>
<p>The same release stops AIDE checking <code>~/.cache</code>, <code>/root/.cache</code>, <code>/var/lib/swcatalog</code> LocSec's own state and log directories, the transient units LocSec starts for each scan, its AIDE lock file and aideinit's logs, and fixes the <code>/run/user</code> exclude that still let AIDE fail on <code>/run/user/1000/doc</code> and <code>gvfs</code>. The existing baseline still contains those paths, so after reviewing the current report use <b>Build AIDE database</b> once; later checks are then short. Add your own excludes as files in <code>/etc/aide/aide.conf.d/</code>, for example <code>!/home/[^/]+/Downloads</code>.</p>
<h3>Differences reported after package updates</h3>
<p>Upgrades legitimately change files. Review the list: changes under package-managed paths that line up with an apt upgrade (for example the Postfix chroot under <code>/var/spool/postfix</code>, which is rebuilt on every restart) are expected. Do not accept changes merely because AIDE reported them; review the differences first.</p>
<h3>Both aide.db and aide.db.new exist</h3>
<p>If <code>/var/lib/aide/aide.db.new</code> exists alongside the active database, the aide package's daily job produced a pending reference database (before 4.0.11-65 switched that job off, or because you turned it back on). Seeing both files is normal. Review the AIDE differences first, then use <b>Accept pending AIDE baseline</b> on the Scans page if you intentionally want to promote it. That button only appears while a pending database that differs from the active one exists. LocSec secures the pending file as <code>root:root</code> mode <code>0600</code>, retains the previous active database as <code>/var/lib/aide/aide.db.locsec-backup</code>, and atomically promotes the pending database.</p>
<p>If you need a completely fresh baseline instead, or the machine has no baseline yet, use <b>Build AIDE database</b>. It is explicitly confirmed and uses AIDE's force/rebuild path, so it creates the first baseline or replaces an existing one.</p>
<h3>Useful commands</h3>
<pre>locsecctl aide-init             # initialize only if no active baseline exists
locsecctl aide-accept           # explicitly accept aide.db.new
locsecctl aide-reinitialize     # explicitly rebuild and replace the baseline
locsecctl scan-aide              # check the current baseline
sudo stat /var/lib/aide/aide.db /var/lib/aide/aide.db.new
sudo journalctl -u dailyaidecheck.service --since "yesterday"
systemctl cat dailyaidecheck.service</pre>
<h3>Pending database has the wrong owner</h3>
<p><code>aide.db.new</code> may be created by Debian's AIDE job as user <code>_aide</code>. That is expected. Do not manually copy it over <code>aide.db</code>. Use <b>Accept pending AIDE baseline</b>, which validates and changes ownership to <code>root:root</code> mode <code>0600</code> before the atomic replacement.</p>
<h3>Pending database is present but should not be accepted</h3>
<p>Leave <code>aide.db.new</code> in place while investigating. It is evidence of the database produced by the daily job. If you decide the changes should not become the new baseline, leave the active <code>aide.db</code> unchanged and let the next AIDE cycle produce a new pending database according to Debian's configuration.</p>
<h3>AIDE runs every day, or "No maintenance job is running" while AIDE uses the CPU</h3>
<p>That is the aide package's own daily check, <code>dailyaidecheck</code>, which runs a full AIDE check every day as the <code>_aide</code> user. It is not a LocSec job, so the Scans page said no job was running while <code>top</code> showed <code>_aide</code> near 100% CPU. LocSec already checks AIDE once a week, so from 4.0.11-65 the installer switches the daily check off (<code>systemctl disable --now dailyaidecheck.timer</code>), and the Scans page now says when an AIDE run LocSec did not start is going. A run already in progress during the upgrade is left to finish: stopping it part-way could leave a half-written <code>aide.db.new</code>. Removing LocSec switches the daily check back on if LocSec was what turned it off.</p>
<p>Check it with <code>systemctl is-enabled dailyaidecheck.timer</code> (should print <code>disabled</code>). If you want the daily check anyway, <code>sudo systemctl enable --now dailyaidecheck.timer</code>; LocSec shares <code>/run/lock/locsecd-aide.lock</code> with it so the two never run together.</p></div>

<div class="card" id="ts-quarantine"><h2>Quarantine</h2>
<h3>Where quarantined files live</h3>
<p>In <code>/var/lib/locsecd/quarantine</code>, root-only. Each item is a <code>.qf</code> data file and a <code>.json</code> record of its original path, owner, mode, size, SHA-256 and detection name. Back this directory up if you want quarantined files to survive a purge.</p>
<h3>A file will not quarantine</h3>
<ul style="margin:0;padding-left:18px;line-height:1.7">
<li><b>ClamAV found nothing in this file</b>: it is clean as far as ClamAV can tell. Tick <b>Quarantine even if clean</b> to quarantine it anyway.</li>
<li><b>Under a system directory</b>: tick <b>Force</b> only if you are sure; quarantining a system binary can break the system.</li>
<li><b>Is a symbolic link</b>: links are never followed. Quarantine the file it points to.</li>
<li><b>Quarantine helper is missing</b>: reinstall the package. The helper is <code>/usr/lib/locsecd/locsec-quarantine</code>, root, mode 0700.</li>
</ul>
<h3>Restore is refused</h3>
<ul style="margin:0;padding-left:18px;line-height:1.7">
<li><b>Already exists</b>: a file is at the original path. Confirm the prompt to replace it, or move it first.</li>
<li><b>Directory no longer exists, or is now a symlink</b>: recreate the directory, or delete the item instead. LocSec will not write through a symlinked directory.</li>
<li><b>Does not match its recorded checksum</b>: the quarantined data was altered, so it is not restored. Delete it.</li>
<li><b>No Restore button</b>: the file was quarantined by a version older than the one that records locations. It can only be deleted.</li>
</ul>
<p>Restored files get their original owner, permissions and modification time, but never setuid or setgid bits. A restored file that was detected as malware will be detected again by the next scan.</p></div>

<div class="card" id="ts-lynis"><h2>Lynis &amp; rkhunter</h2>
<h3>Lynis</h3>
<p>Lynis runs in a separate systemd unit with full capabilities, so the privilege-drop errors seen in older builds no longer occur. Results come from the Lynis report file: the hardening index, the warnings and the suggestions, all listed in the scan result. Slow-test timing notes, device-mapper messages and <code>pgrep</code> chatter are informational and do not change the status.</p><p><b>Warnings</b> are what to review first. <b>Suggestions</b> are hardening opportunities, not findings: Lynis is written for servers, so on a desktop many of them do not apply, and the hardening index is a ratio of tests passed against its whole catalogue rather than a security score to chase. Decide on each one deliberately, and check it against the rest of this system first — a suggestion that tightens <code>/var/log</code> so rsyslog can no longer write works against LocSec itself.</p>
<h3>rkhunter</h3>
<p>Each warning is checked before it is reported. Hidden files that belong to the system, scripts that match their package checksums (verified with <code>dpkg</code>), files owned by real login users, new system accounts and groups a package created (an unprivileged id below 1000, and for a user no login shell), and eCryptfs or LTTng tracing files in <code>/dev/shm</code> are classed as informational. Anything else is a finding, including a new account with uid 0 or a login shell, and any change to an existing group's members, such as a user added to <code>sudo</code>. rkhunter compares against its own snapshot: after reviewing a report, <code>sudo rkhunter --propupd</code> records the current state so the same changes are not reported again. To silence a known-good item permanently, add a matching pattern to <code>rkhunter_ignore</code> in the configuration; the report notes which entries were suppressed and why. LocSec repairs a rejected rkhunter configuration automatically before each run.</p></div>

<div class="card" id="ts-cve"><h2>CVE scan &amp; reports</h2>
<ul>
<li><b>What the CVE scan covers.</b> On Debian and LMDE it runs <code>debsecan</code> against the Debian security tracker, and on every system it lists the security updates APT has waiting (<b>APT security candidates</b>). Those updates are installed automatically every 12 hours while <code>auto_update</code> is on.</li>
<li><b>Reading the debsecan result.</b> The first line gives the number of known vulnerabilities and how many have a fix available now. Only the ones with a fix are something to act on: they are listed first and install with <b>Update system</b>. Everything else is known to Debian but not fixed yet, counted by package; hundreds are normal on a desktop (most are kernel headers, <code>linux-libc-dev</code>). The status is <b>Warnings</b> when a fix is waiting and <b>Informational</b> when none is. Before 4.0.11-62 debsecan's exit status alone decided the label, so a long list read as <i>Clean / no findings</i>, and only the last 20 KB of the list was kept.</li>
<li><b>Report too large.</b> Reading a report is capped by <code>dashboard_report_max_mb</code> (100 MB). Opening a large report shows its beginning instead of the whole document, so the window does not lock up.</li>
</ul></div>

<div class="card" id="ts-updates"><h2>Updates</h2>
<p><b>Update system</b> works out what is pending with a simulated <code>apt-get upgrade</code>, installs the selected packages (security-only unless <code>update_security_only</code> is false) without interactive prompts, and keeps your existing configuration files. The result lists what was installed and explains anything left over.</p>
<table><tr><th>Message</th><th>Cause and remedy</th></tr>
<tr><td>Nothing to update</td><td>No packages are pending for the selected policy. Non-security updates are skipped when <code>update_security_only</code> is true; set it to false to include them.</td></tr>
<tr><td>Packages held back (phased rollout)</td><td>Ubuntu and Mint release some updates gradually. They arrive on their own within a few days, or set <code>include_phased_updates</code> to true.</td></tr>
<tr><td>Could not get the apt lock</td><td>Another package manager (Update Manager, unattended-upgrades, apt) is running. Wait for it to finish, or check with <code>sudo lsof /var/lib/dpkg/lock-frontend</code>, and try again.</td></tr>
<tr><td>Repository refresh failed</td><td>A network or third-party repository problem. The update continues with cached lists; fix the repository with <code>sudo apt-get update</code> and read its error.</td></tr>
<tr><td>Automatic updates skipped</td><td><code>auto_update</code> is false. Apply manually from the Scans page, or enable it in the configuration.</td></tr>
</table></div>

<div class="card" id="ts-ids"><h2>Intrusion signatures (Suricata)</h2>
<p>Suricata is the traffic inspector LocSec installs with itself. It compares network packets with a large set of rules describing known attacks and malware, including traffic that leaves this machine, which the firewall and the threat lists cannot see. It comes with LocSec as a dependency; if it was removed, reinstall it from Overview (the Add button next to suricata) or with <code>sudo apt install suricata suricata-update</code>. It runs as its own service and only watches: it never drops traffic. LocSec reads its alert file, <code>/var/log/suricata/eve.json</code>, opens no port, and starts reading at the end of the file, so alerts from while LocSec was stopped are not replayed.</p>
<p><b>Setup is automatic.</b> Suricata watches only the interface named under <code>af-packet</code> in <code>/etc/suricata/suricata.yaml</code>, and the package default (<code>eth0</code>) is wrong on most machines. When LocSec is installed it sets that interface to the one your default route uses, downloads the rules with <code>suricata-update</code> and starts Suricata, in the background (follow it with <code>journalctl -u locsec-suricata-setup -f</code>). After that it keeps the interface in step with the default route every 5 minutes and refreshes the rules after each threat-feed update (every 12 hours), reloading them into the running Suricata. An interface you set by hand is left alone. To redo the whole setup now, run <code>sudo locsecctl suricata-setup</code>. Suricata cannot read inside encrypted (HTTPS) traffic: it matches addresses, handshakes and unencrypted protocols.</p>
<p><b>What LocSec does with an alert.</b> Alerts of severity 1 and 2 (<code>ids_incident_severity</code>) become an <i>Attack pattern</i> incident. Only severity 1 (<code>ids_block_severity</code>) blocks the other address, for <code>ids_block_hours</code> (24) at most <code>ids_block_max_per_hour</code> (10) times an hour, through the same block list as every other automatic block, so the allowlist and your DNS servers and gateways are never blocked. Inbound UDP is only recorded, because a forged source address could otherwise be used to get any address blocked. Expect false alarms, especially from rules about policy or old protocols: add the rule number (sid) from the incident to <code>ids_ignore_sids</code> to silence a rule, or set <code>ids_block_severity</code> to 0 to record only. <code>ids_enabled</code> false stops LocSec reading Suricata altogether.</p>
<h3>Suricata is shown as missing, or the Add button fails</h3>
<p>Suricata is a dependency of LocSec, so a normal <code>sudo apt install ./locsecd_5.0-1_amd64.deb</code> installs it. It shows as <i>missing</i> only if it was removed afterwards, or if LocSec was installed with an older build that treated it as optional. Check with <code>dpkg -l suricata</code>. To repair, click <b>Add</b> next to suricata on Overview, or run <code>sudo apt install suricata</code>; running <code>sudo apt install --reinstall ./locsecd_4.0.11-86_amd64.deb</code> also pulls it in. Suricata brings in many libraries, so the download can take several minutes: the Add button waits up to 10 minutes (older builds gave up after 3, which can make the click look as if it did nothing). If Add still fails, open <b>Incidents</b> and read the <i>Tool installed</i> entry for suricata, which holds apt's last output. The usual causes are another package manager holding the apt lock (<code>sudo lsof /var/lib/dpkg/lock-frontend</code>), no network or a mirror that is down (<code>sudo apt update</code>), or the <i>universe</i> component being disabled on Ubuntu. If apt reports that suricata cannot be installed, LocSec itself will not install on that machine until it can.</p>
<h3>Installed, but the card says it is not running</h3>
<p>Check <code>systemctl status suricata</code> and <code>sudo journalctl -u suricata -e</code>. A configuration error after editing <code>suricata.yaml</code> by hand is the most common cause; <code>sudo suricata -T -c /etc/suricata/suricata.yaml</code> tests the file, and LocSec's own edits are tested before they are kept (the untouched original is <code>/etc/suricata/suricata.yaml.locsec-orig</code>). Right after installing LocSec, give the background setup a few minutes: <code>journalctl -u locsec-suricata-setup</code> shows what it did. <code>sudo locsecctl suricata-setup</code> sets the interface, downloads the rules and starts Suricata in one go. Starting can take a minute while the rules load.</p>
<h3>The card says no rules are installed</h3>
<p>LocSec downloads the rules during installation and again after each threat-feed update, so this usually means the download failed (no network at the time) or <code>suricata-update</code> is missing. Run <code>sudo locsecctl suricata-setup</code> to try now; it reports what went wrong. If it says suricata-update is not installed, your release ships the rule downloader as a separate package: <code>sudo apt install suricata-update</code>.</p>
<h3>Running, rules loaded, but no alerts at all</h3>
<p>That is normal on a quiet machine. If you expect traffic to be seen, the usual reason is the wrong interface: the Overview card names the interface Suricata is set to watch and the one this machine uses. LocSec switches it by itself within a few minutes unless the interface was set by hand; <code>sudo locsecctl suricata-setup</code> switches it in that case too. Check that alerts are being written: <code>sudo tail -f /var/log/suricata/eve.json</code>. If <code>ids_eve_path</code> was changed, it must match the path Suricata writes to.</p>
<h3>High CPU or memory use</h3>
<p>Suricata inspects every packet and can use a lot of memory with the full rule set. Check it with <code>systemctl status suricata</code>, and keep the rule set modest on a small machine. Stopping it with <code>sudo systemctl disable --now suricata</code> only removes the intrusion-signature layer: LocSec keeps running and the Overview card reads <i>not running</i>. Setting <code>ids_enabled</code> to false stops LocSec reading its alerts.</p>
<p><a href="#help-top">Back to contents</a></p></div>
<div class="card" id="ts-fallback"><h2>UFW is off: fallback firewall and port-scan blocks</h2>
<p><b>Port-scan detection.</b> LocSec reads the firewall's "dropped packet" log lines (<code>[UFW BLOCK]</code>, or <code>[LOCSEC BLOCK]</code> from the fallback below) and blocks a public address that sends new connections to <code>scan_ports</code> (8) different closed ports within <code>scan_window</code> seconds (600). It opens no ports. The block appears under Persisted blocks with source <code>scan-monitor</code>, and a <code>port-scan</code> incident is recorded. Addresses on your allowlist (the local network by default) and your DNS servers and gateways are only recorded as an incident, never blocked. Turn it off with <b>Port-scan blocking</b> on the Incidents page, or <code>scan_detect</code> in the configuration. It needs UFW logging on: <code>sudo ufw logging on</code>. UFW itself logs only about 3 dropped packets a minute after an initial burst of 10, so very slow scans are only partly seen. Because the source address of a probe can be forged, scan blocks last <code>scan_block_hours</code> (24) rather than the usual 30 days, at most <code>scan_block_max_per_hour</code> (10) are made per hour, and an address this machine has an open connection with is only recorded as an incident.</p>
<p><b>Fallback firewall.</b> If UFW is installed but not enabled (and has been for two checks in a row, about two minutes), LocSec adds its own nftables chain <code>inet locsec fallback</code> that drops unsolicited incoming traffic. It allows loopback, replies to connections this machine started, ICMP, DHCP, mDNS, and any ports listed in <code>fallback_allow_tcp</code> and <code>fallback_allow_udp</code>. Everything else is dropped and logged. An SSH session that is open when the fallback turns on keeps its port open while it lasts, so you cannot be cut off mid-session. The incident and the log line list which network services were cut off. The Overview Firewall card says when it is active. <b>If you accept incoming connections (SSH, file sharing, a web server) list those ports before turning UFW off</b>, for example <code>"fallback_allow_tcp": [22]</code> in <code>/etc/locsecd/locsecd.conf</code>, then restart locsecd. Enabling UFW (<code>sudo ufw enable</code>) removes the fallback within a minute, since UFW's rules take over. Turn it off with <b>Fallback firewall when UFW is off</b> on the Incidents page or <code>"fallback_firewall": false</code>.</p>
<p>The fallback is not saved across a reboot by itself: after boot it returns about two minutes after locsecd starts. It stays in place if locsecd is stopped, so an incoming service that suddenly stopped answering can be this. Check with <code>sudo nft list chain inet locsec fallback</code>; to remove it for good, enable UFW or set <code>fallback_firewall</code> to false (LocSec puts it back within two minutes otherwise).</p></div>

<div class="card" id="ts-schedule"><h2>Schedules &amp; jobs</h2>
<ul>
<li><b>A scheduled scan never starts.</b> Heavy jobs wait until the load is at or below <code>idle_load</code> for <code>idle_seconds</code>. On a machine that is rarely idle, run the job from the Scans page, which bypasses the wait.</li>
<li><b>System updates never seem to run.</b> Updates are due every <code>update_interval</code> (12 hours) and, like the scans, start only after the load has stayed at or below <code>idle_load</code> for <code>idle_seconds</code>, and not while another maintenance job holds the lock (a ClamAV or AIDE run can take hours). Before 4.0.11-76 the time of the last update was not saved, so every restart or reboot moved the next update about 11 hours away. It is saved now, and the Schedule table on the Scans page shows when System updates last ran and are next due. <b>Update system</b> runs one at once, and a failed scheduled update is retried after an hour.</li>
<li><b>Scans do not run with the lid closed.</b> If closing the lid suspends the computer, nothing runs while it is suspended, and LocSec does not wake it. Scheduled jobs start after you wake it and it has been idle for <code>idle_seconds</code>, at most one per day. To scan with the lid closed, make the machine stay awake on lid close (for example <code>HandleLidSwitch=ignore</code> in <code>logind.conf</code> when docked). A job that is already running is protected from suspend by <code>inhibit_sleep_during_jobs</code>.</li>
<li><b>"Another maintenance job is already running".</b> Only one maintenance job runs at a time. The message names the job that holds the lock, whether it was started from the dashboard or by the schedule, and how long it has been running, and the Scans page shows the same under <b>Running now</b>. Scheduled scans start on their own once the machine is idle, so a button can be refused by a job nobody clicked. Wait for it to finish; a ClamAV or AIDE run can take an hour or more. To see the tool itself: <code>systemctl list-units 'locsecd-*' --no-pager</code>. If a job is stuck after a crash, <code>sudo systemctl restart locsecd.service</code> clears it.</li>
<li><b>A client disconnected mid-job.</b> The job keeps running and its report is still written to <code>/var/lib/locsecd/reports/</code>. Look for the new report instead of starting the job again.</li>
<li><b>Real-time protection is not affected by load.</b> Login monitoring and blocking run continuously.</li>
<li><b>Threat feeds show "Temporary failure in name resolution".</b> The machine could not look up the feed servers when the update ran, usually because it ran seconds after boot, before the network or DNS was up. From 4.0.11-61 a run that reaches no source keeps the previous indicators (it used to replace them with nothing), says so on the Threat Intelligence page, and is retried every 15 minutes instead of 12 hours. If it keeps failing, test DNS on the machine itself: <code>getent hosts www.spamhaus.org</code>. No output means the machine has no working DNS; check the connection with <code>nmcli general status</code> and <code>cat /etc/resolv.conf</code>. If that works, click <b>Update feeds now</b>.</li>
</ul></div>

<div class="card" id="ts-notify"><h2>Notifications</h2>
<h3>No desktop notification appears</h3>
<ul>
<li>Tick the kinds you want and press <b>Save</b>, then <b>Send test notification</b> on the Incidents page. The test says whether a graphical session was found.</li>
<li>LocSec sends the notification itself, to every user logged in at a local desktop (X11 or Wayland), so the dashboard window does not need to be open. A remote (SSH) or locked-out session gets none.</li>
<li>It uses <code>notify-send</code> (package <code>libnotify-bin</code>) or, if that is missing, <code>gdbus</code>. It asks the desktop to show it for 10 seconds; the desktop's notification service decides how: GNOME shows a banner and keeps the entry in its notification list, KDE Plasma and desktops with a tray show a bubble by the tray icon.</li>
<li>Do Not Disturb hides the banner but the entry is still kept in the list.</li>
<li>A new incident of a ticked kind notifies once; the same kind and address is not announced again for 10 minutes, and a burst (for example a feed refresh blocking many addresses) becomes one summary.</li>
</ul>
</div>

<div class="card" id="ts-incidents"><h2>Two incidents for the same address, or a count that stopped rising</h2>
<p>Both are the grouping rules working as intended.</p>
<ul>
<li><b>The Seen count stopped going up.</b> The incident was resolved or dismissed. A closed incident never absorbs another observation; the next one opens a new incident. Look for a newer row with the same indicator.</li>
<li><b>Two (or more) rows for one address.</b> Each row is one incident that was opened, counted and then closed. A source that keeps coming back after you resolve it produces one row per round, each with its own first-seen and last-seen times. That is the history of the source, not duplicate reporting.</li>
<li><b>An incident you updated several times appears once.</b> Correct: the list shows the current state of each incident. Every state change is kept in the action log and is visible through Investigate/Contain/Resolve on that incident.</li>
<li><b>Genuinely duplicated rows in the same state</b> would mean the kind, source or indicator differ &mdash; compare those three columns. Feed-sourced and login-monitor observations of the same address are different incidents by design, because they are different kinds of evidence.</li>
</ul>
<p>If you want a clean slate, <b>Delete all</b> on the Incidents page clears the timeline; individual rows can be deleted one at a time. Neither touches firewall state.</p></div>

<div class="card" id="ts-services"><h2>A manual service action fails or does nothing</h2>
<p>The Services table is read-only: each row shows the unit, its state and its PID, and nothing on a row can be clicked. Start, restart, stop, enable and disable are in the <b>Manual control</b> box under the table. Two defects there were fixed in 4.0.11-31:</p>
<ul>
<li><b>Stop and Restart failed on almost every unit.</b> The daemon only permitted five specific units and refused the rest with "service action is restricted to supported LocSec-managed services". Any unit can now be controlled, except the protected ones below.</li>
<li><b>A stopped service vanished.</b> The list showed only <i>running</i> units, so stopping one removed it from the Services page and from the Overview card. LocSec-managed units now stay listed with their state; their PID reads as a dash while they are stopped.</li>
</ul>
<p>What is still refused, on purpose: <b>stop</b>, <b>restart</b> and <b>disable</b> on ssh, sshd, networking, NetworkManager, systemd-networkd, dbus, systemd-logind, systemd-journald, systemd-udevd, the display manager (lightdm, gdm, gdm3, sddm), polkit and <code>locsecd</code> itself. Those either disconnect you from the machine or kill the desktop session showing this window. <b>Start</b> and <b>enable</b> are allowed on all of them. Use <code>systemctl</code> in a terminal if you really need one of the blocked combinations.</p>
<p>A third defect was fixed in 4.0.11-37: the result of an action was written to the output box and then immediately erased, because the page redrew itself straight afterwards and rebuilt that box empty. Every action looked like a button that did nothing, whether it had succeeded or been refused, and the reason for a refusal was never visible. The outcome is now written after the redraw and stays on screen.</p>
<p>The same release stopped trusting <code>systemctl</code>'s exit status on its own. LocSec now reads the unit's state before and after, reports it as <code>stopped -&gt; running</code>, and calls the action a failure if the state did not actually move -- so a silent no-op is reported as one instead of looking like success.</p>
<p>If an action still reports a failure, read the output box. A unit that is not installed reports "Unit ... not found". From 4.0.11-58 a failed start, stop or restart also carries the unit's own journal lines from that attempt (up to 20, under a <code>--- journalctl -u &lt;unit&gt; ---</code> marker), and the same text is stored in the incident, so the reason is visible without a terminal. Before -58 the incident held only systemctl's generic "Job ... failed" line, cut to 500 characters, and the LocSec log read just <code>rc=1 stopped-&gt;stopped</code>. The log line is now a WARN and ends with the unit's last journal message.</p>
<p>A LocSec-managed unit that is masked shows <b>masked</b> in the State column rather than stopped, so a unit that cannot be started is not mistaken for one that merely is not running. A <b>masked</b> unit is reported as masked, with the <code>systemctl unmask</code> command to fix it; see <a href="#ts-manual">Manual control</a>. If the output box has no journal section, the unit wrote nothing during the attempt; <code>sudo systemctl status &lt;unit&gt;</code> and <code>sudo journalctl -u &lt;unit&gt; -b -n 50</code> are the next step. Reading another unit's journal needs root or membership of the <code>adm</code> or <code>systemd-journal</code> group: as an ordinary user it prints "No entries" even when there are some.</p>
<p>Repeating a failed action does not add a row. It folds into the open incident for that unit, and the <b>Seen</b> count rises, as described under <a href="#ts-incidents">Incident grouping</a>.</p></div>

<div class="card" id="ts-exited"><h2>ufw (or another service) shows "exited" but is really running</h2>
<p>Fixed in 4.0.11-37. systemd reports two separate things about a unit: <b>ActiveState</b>, meaning is it up, and <b>SubState</b>, meaning what its process is doing. A <code>Type=oneshot</code> unit with <code>RemainAfterExit=yes</code> -- which is exactly what <code>ufw.service</code> is -- applies its rules, exits, and then sits at <code>active (exited)</code> for as long as the firewall is up. That is the normal, healthy state for it, not a stopped service.</p>
<p>The Services page and the Overview card were showing the SubState verbatim, so a working firewall read as <b>exited</b>. They now show a state derived from ActiveState: <b>running</b> for a unit with a live process, <b>active</b> for a settled oneshot unit like ufw, <b>stopped</b>, <b>failed</b> or <b>activating</b> otherwise.</p>
<p>Confirm the firewall independently at any time with <code>sudo ufw status</code>, or <code>systemctl show ufw.service -p ActiveState -p SubState</code>.</p></div>

<div class="card" id="ts-bounce"><h2>A service will not stay stopped</h2>
<p>Both were fixed in 4.0.11-38, and the first is usually the system working as designed rather than a fault.</p>
<p><b>"Stop" reported success and the unit came straight back.</b> Up to 4.0.11-37 the check after a stop asked only whether the unit was <i>active</i>. A unit caught mid-restart reads as <code>activating</code>, which is not active, so a stop that had already been undone was reported as <code>ok (running -&gt; activating)</code>. LocSec now waits for the unit to settle out of a transitional state before judging, and treats coming back up as a failed stop.</p>
<p>Plenty of units legitimately restart themselves the moment they are stopped. <code>bluetooth.service</code> on a desktop is the usual example: it is D-Bus activated, so the Bluetooth applet in the panel asks for it again immediately. The same goes for socket-activated units and anything another running unit <code>Requires=</code>. Find out what is pulling it up, and stop that instead:</p>
<pre>systemctl list-dependencies --reverse bluetooth.service
systemctl cat bluetooth.service</pre>
<p>Stopping cannot hold such a unit down. If you genuinely want it off, mask it — <code>sudo systemctl mask bluetooth.service</code> — and <code>unmask</code> to undo. LocSec does not offer masking from the dashboard on purpose: it survives reboots and is easy to forget you did.</p>
<p>A stopped unit that briefly seemed missing and returned after a browser refresh was the same settling problem: the page redrew while the unit was still <code>activating</code>. The redraw now happens after the state settles.</p>
</div>

<div class="card" id="ts-kill"><h2>What a restart, a stop or a kill leaves behind</h2>
<p><b>Ordinary stop or restart.</b> On SIGTERM the daemon sets its stop flag and asks any running packet capture to exit, then returns immediately; the waiting happens in the shutdown path proper. It closes the listener, asks systemd to stop the sibling transient units (aideinit, a running scan) that <code>KillMode=control-group</code> cannot reach because systemd owns them, not LocSec, and gives the captures 5 seconds in total before killing them. An apt or dpkg job is deliberately <b>not</b> stopped: killing dpkg mid-run leaves packages half-configured, so it is left to finish on its own. "LocSec server shut down cleanly" in the log means all of that finished.</p>
<p>Before 4.0.11-48 the signal handler did the waiting itself: up to 5 seconds per capture for SIGTERM and 5 more after SIGKILL, so three unresponsive captures could consume the unit's whole <code>TimeoutStopSec=30</code>. systemd would then SIGKILL the daemon mid-handler and the transient-unit cleanup would never run -- leaving exactly the orphaned jobs that cleanup exists to prevent.</p>
<p><b>SIGKILL, an OOM kill or power loss.</b> Nothing gets to run, so:</p>
<ul>
<li>Ordinary children (scans, captures) die with the cgroup. Transient units survive, but from 4.0.11-62 each is named after the daemon process that started it, and the next instance stops every one whose owner is gone as soon as it starts (apt jobs excepted, as above). Before that they ran on until their <code>RuntimeMaxSec</code> -- and an orphaned aideinit could race a new one, because the AIDE lock died with the old daemon.</li>
<li>If the kill landed while definitions were updating, <code>clamav-freshclam.service</code> was left stopped for good. From 4.0.11-62 the next start turns it back on when it is enabled.</li>
<li>If the monitoring thread itself ever stops, the daemon exits on purpose so systemd restarts it whole, rather than serving the dashboard with no monitoring behind it.</li>
<li>The AIDE lock is an <code>flock()</code> on an open descriptor; the kernel releases it when the process dies. The in-memory maintenance lock simply ceases to exist. Neither can be left stuck by a kill.</li>
<li>State written through the atomic path (blocks, feeds, seen-markers, compaction) is either the old file or the new one, never a mixture.</li>
<li>The append-only logs -- incidents, incident actions, events, the text log -- can lose the record that was being written. From 4.0.11-48 that is <i>all</i> they lose: an append now repairs a missing final newline first. Previously the next record written after a kill landed on the truncated line and was lost with it, so one crash cost two incidents rather than one.</li>
</ul>
<p>After an unclean stop, <code>sudo journalctl -u locsecd -b</code> shows whether the clean-shutdown line was ever reached, and <code>systemctl list-units 'locsecd-*'</code> lists any transient job still running. LocSec does not reload its configuration on SIGHUP (that signal is ignored, so log rotation cannot kill it); after editing <code>locsecd.conf</code>, restart it with <code>sudo systemctl restart locsecd</code>.</p></div>

<div class="card" id="ts-logsrc"><h2>Logs page sources show "not found" or "(no entries yet)"</h2>
<p><b>On a host without rsyslog this was a defect, fixed in 4.0.11-58.</b> LocSec now installs rsyslog as a dependency, but if it has been removed the system logs only to the systemd journal, so <code>/var/log/auth.log</code>, <code>syslog</code> and <code>ufw.log</code> never exist there. The page read files only, so those sources showed "not found". Hosts with rsyslog write the files directly. Every source now falls back to the journal when its file is missing; the path line under the source shows which one was read.</p>
<p>A source that still shows <i>(no entries yet)</i> has neither a file nor any matching journal entries. Select it to see why. The usual reasons:</p>
<ul><li><b>rkhunter</b>: writes <code>/var/log/rkhunter.log</code> only, on its first run. Run it from the Scans page.</li>
<li><b>AIDE</b>: LocSec's weekly AIDE check has not run yet (or its output is older than 7 days and was deleted), or no baseline exists. Press <b>AIDE</b> on the Scans page, or <b>Build AIDE database</b> first if there is no baseline.</li>
<li><b>UFW</b>: UFW logs only when logging is on and something has been denied. Check with <code>sudo ufw status verbose</code> and turn it on with <code>sudo ufw logging low</code>.</li>
</ul>
<p>If rsyslog was removed and you want the classic files back, <code>sudo apt install rsyslog</code> creates them from then on. LocSec reads the file once it exists. Check the journal directly with <code>sudo journalctl -u clamav-freshclam -n 20</code>, <code>sudo journalctl SYSLOG_FACILITY=4 SYSLOG_FACILITY=10 -n 20</code> or <code>sudo journalctl -k | grep "UFW "</code>.</p></div>

<div class="card" id="ts-logs"><h2>Are logs or reports going to fill up the disk?</h2>
<p>No.</p>
<ul>
<li><b>Reports</b> (everything in <code>/var/lib/locsecd/reports/</code>: scan, CVE and update reports and the full AIDE outputs) are deleted automatically once they are 7 days old (<code>report_retention_days</code>). The check runs every hour.</li>
<li><b>LocSec's own log</b> is rotated daily, 14 kept, compressed (<code>/etc/logrotate.d/locsecd</code>).</li>
<li><b>auth.log, syslog, ufw.log</b> are rotated by rsyslog, which LocSec installs as a dependency. If rsyslog has been removed they are kept in the systemd journal instead, which journald trims within the limits in <code>/etc/systemd/journald.conf</code>.</li>
<li><b>rkhunter, ClamAV, AIDE</b> logs are rotated by their own packages.</li>
</ul>
<p>The Logs page used to show a "Disk use and rotation" table under every log. It was removed in 4.0.11-65; the rules above have not changed. If something really is growing, find it with <code>sudo du -h /var/log /var/lib/locsecd --max-depth=2 | sort -h | tail -20</code>.</p>
<p>Only LocSec's own log can be cleared from the Logs page (<b>Clear LocSec's log</b>, shown when that log is selected). It is emptied in place rather than deleted, and the clear is recorded as an incident. The other logs are deliberately not clearable from the dashboard: see the Logs section of the Help page.</p></div>

<div class="card" id="ts-verify"><h2>Confirming the installed files are the ones the package shipped</h2>
<p>Every file is checksummed at build time, so dpkg can tell you if anything on disk has changed since installation &mdash; whether by an edit you forgot, a failed upgrade, or something you did not do:</p>
<pre>sudo debsums -c locsecd          # lists only files whose checksum no longer matches
dpkg -V locsecd                  # same idea, no extra package needed
dpkg -s locsecd | grep Version   # the installed version</pre>
<p>Configuration files under <code>/etc</code> are expected to differ once you have edited them; dpkg flags those separately as conffiles and never silently overwrites them. A mismatch on anything under <code>/usr</code> or <code>/lib</code> is worth investigating, because nothing in normal operation writes there.</p>
<p>If you want to rebuild from source and compare against what you are running, see <b>Source and licence</b> on the Help page.</p>
<p>Note for anyone comparing an older package: releases up to 4.0.11-40 shipped a stray Python byte-cache file under <code>/usr/lib/locsecd/__pycache__/</code>. It was a build artefact, it was never loaded, and it is gone from 4.0.11-41 onward.</p></div>

<div class="card" id="ts-manual"><h2>The manual control box says "invalid unit name"</h2>
<p>Fixed in 4.0.11-38. The box required the exact full unit name, so <code>bluetooth</code> was refused and only <code>bluetooth.service</code> was accepted -- and a leading or trailing space from a paste was refused the same way, with the same message, which reads as a rejection of the service rather than of the spelling. The name is now trimmed and given a <code>.service</code> suffix if it has none, so all three spellings work. A name that is still not a service unit is refused with the name quoted back, so you can see what was actually read.</p>
<p>Also fixed in the same release: the box lost whatever was typed on every action, because the page redraws afterwards and rebuilt the field empty -- so starting and then enabling the same unit meant typing it twice. It keeps its contents now, <b>Restart</b> was added, and Enter runs Start.</p>
<p><b>Enable and disable</b> report the unit file state (<code>disabled -&gt; enabled</code>) rather than the running state. They do not change whether the unit is running now, only whether it starts at boot; ActiveState was previously reported for these, which made the result read as "running -&gt; running". A unit that is <b>masked</b> cannot be started or enabled at all. The action now says so and gives the <code>systemctl unmask</code> command. That check was added in 4.0.11-38 but only ran when systemctl exited 0, and a start on a masked unit always exits 1, so until 4.0.11-58 the result was a bare failure with no reason. LocSec never masks a unit itself; masking comes from an administrator, a hardening script or a setup tool. Check with <code>systemctl is-enabled &lt;unit&gt;</code>, which prints <code>masked</code>.</p>
<p>This box controls <code>.service</code> units only. For timers, sockets and other unit types, use <code>systemctl</code> in a terminal.</p></div>

<div class="card" id="ts-harden"><h2>Something changed after installing or upgrading LocSec</h2>
<p>The package applies two hardening files at install time. They are conservative, and nothing in them should affect normal desktop or laptop use, but this is where to look first if the timing points at a LocSec install.</p>
<table><tr><th>File</th><th>What it sets</th></tr>
<tr><td><code>/etc/sysctl.d/60-locsec-hardening.conf</code></td><td>Kernel information leaks, ICMP redirects, source routing, martian logging, SUID core dumps.</td></tr>
<tr><td><code>/etc/modprobe.d/60-locsec-disable-unused-protocols.conf</code></td><td>Stops the dccp, sctp, rds and tipc modules from loading.</td></tr>
</table>
<h3>Effects you may notice, all intended</h3>
<ul>
<li><code>dmesg</code> now needs <code>sudo</code> (<code>kernel.dmesg_restrict=1</code>). The journal is unaffected: use <code>journalctl -k</code>.</li>
<li>Kernel addresses read as zeros in <code>/proc</code> for non-root (<code>kernel.kptr_restrict=2</code>); some profiling and debugging tools report less detail unless run as root.</li>
<li>New <code>martian source</code> lines in the kernel log (<code>log_martians=1</code>). Those are spoofed or impossible source addresses being logged on purpose, not errors.</li>
</ul>
<h3>Inspect and revert</h3>
<pre>sysctl -a --pattern 'dmesg_restrict|kptr_restrict|log_martians|redirects|source_route'
sysctl net.ipv4.conf.all.accept_redirects        # read one value

sudo rm /etc/sysctl.d/60-locsec-hardening.conf   # opt out of all of it
sudo rm /etc/modprobe.d/60-locsec-disable-unused-protocols.conf
sudo reboot                                      # values already applied persist until reboot</pre>
<p>Both are configuration files owned by the package, so a deletion or an edit survives future upgrades; LocSec will not put them back. To change one setting rather than all of them, edit the file and run <code>sudo sysctl --system</code>.</p>
<p>What LocSec deliberately does <b>not</b> set, because each breaks something real: strict reverse-path filtering (VPNs and multi-homed hosts), disabling IPv6 router advertisements (IPv6 autoconfiguration), disabling magic SysRq (emergency shutdown on a wedged laptop) and restricting user namespaces (Flatpak and the Chromium sandbox). Each omission is documented in the sysctl file itself. If you applied one of those by hand and networking or an application broke afterwards, that is the first thing to undo.</p></div>

<div class="card" id="ts-log"><h2>Collecting diagnostics</h2><p>Before asking for help, gather:</p>
<pre>dpkg -s locsecd | grep Version
locsecctl status
sudo journalctl -u locsecd -n 200 --no-pager
sudo tail -n 100 /var/log/locsecd/locsecd.log
ls -lt /var/lib/locsecd/reports | head
systemctl is-enabled &lt;unit&gt;; sudo journalctl -u &lt;unit&gt; -b -n 50 --no-pager   # for a service that will not start</pre>
<p>Include the failing report from the Reports page (or the newest file under <code>/var/lib/locsecd/reports/</code>) and your Linux distribution and version.</p></div>
`
const HELP_HTML=`
<div class="card"><h2>About LocSec</h2><p>LocSec is a local security daemon and dashboard for this machine. It watches logins and system logs; blocks hostile addresses through UFW (or nftables when UFW is inactive); runs AIDE, Lynis, rkhunter, ClamAV, debsecan and CVE checks; and applies security updates. Nothing leaves the machine: there is no cloud service, no telemetry, and since 4.0.11-47 no AI component of any kind.</p>
<p class="muted">Supported on Debian 12 and 13, Ubuntu 24.04 LTS, 26.04 LTS and 26.10, Linux Mint 22, and LMDE 6 and 7. The Troubleshooting page covers what to do when something behaves differently from what is described here.</p></div>

<div class="card" id="help-top"><h2>Contents</h2><table><tr><th>Topic</th><th>What it covers</th></tr>
<tr><td><a href="#help-overview">Overview</a></td><td>Status, protection tools, load and idle rules.</td></tr>
<tr><td><a href="#help-firewall">Firewall &amp; Blocks</a></td><td>UFW, ports, manual and automatic blocks.</td></tr>
<tr><td><a href="#help-logins">Login Activity</a></td><td>Authentication events and the auto-block threshold.</td></tr>
<tr><td><a href="#help-incidents">Incidents</a></td><td>Timeline, response policy, desktop notifications.</td></tr>
<tr><td><a href="#help-scans">Scans &amp; CVEs</a></td><td>Scan tools, statuses, schedules and updates.</td></tr>
<tr><td><a href="#help-malware">Malware / Quarantine</a></td><td>Quarantine, restore and delete.</td></tr>
<tr><td><a href="#help-threats">Threat Intelligence</a></td><td>IOC feeds and reputation checks.</td></tr>
<tr><td><a href="#help-network">Ports &amp; Capture</a></td><td>Connections, listening ports, packet capture.</td></tr>
<tr><td><a href="#help-ids">Intrusion signatures (Suricata)</a></td><td>Where Suricata shows up, what it needs, and what LocSec does with its alerts.</td></tr>
<tr><td><a href="#help-services">Services</a></td><td>systemd services, their state and PID, and manual control.</td></tr>
<tr><td><a href="#help-reports">Reports</a></td><td>Scan, CVE and update reports.</td></tr>
<tr><td><a href="#help-logs">Logs</a></td><td>Log sources and where each comes from.</td></tr>
<tr><td><a href="#help-schedule">Schedules &amp; resource use</a></td><td>When each job runs and how it limits its impact.</td></tr>
<tr><td><a href="#help-config">Configuration</a></td><td>Key settings in locsecd.conf.</td></tr>
<tr><td><a href="#help-cli">Command line</a></td><td>locsecctl and systemd commands, installing and upgrading.</td></tr>
<tr><td><a href="#help-security">Security model</a></td><td>How the dashboard and daemon are protected.</td></tr>
<tr><td><a href="#help-source">Source and licence</a></td><td>Rebuilding the package yourself, and the licence.</td></tr>
</table></div>

<div class="card" id="help-overview"><h2>Overview</h2><p>The landing page shows the installed version, the number of active blocks, recent authentication failures and the current load. The load figure also shows whether the machine counts as idle: load must stay at or below <code>idle_load</code> for <code>idle_seconds</code> before background scans and updates start.</p>
<p>The <b>Protection status</b> table lists every tool LocSec coordinates, Suricata included. All of them are installed together with LocSec, so a row only reads <i>missing</i> if a package was removed afterwards. A missing component has an <b>Add</b> button that installs just that package; <b>Install missing components</b> installs everything that is absent. Once Suricata is installed, an <b>Intrusion signatures (Suricata)</b> card appears underneath (see <a href="#help-ids">Intrusion signatures</a>).</p><p>The <b>Exposure</b> card checks what an attacker on the network would try first: whether UFW is on and denies incoming traffic by default, which services listen on a network address, whether OpenSSH allows password or root logins, and whether the disk is encrypted. Each warning carries the command that fixes it. LocSec only reports these; it does not change your firewall or SSH configuration for you.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-firewall"><h2>Firewall &amp; Blocks</h2><p>Enable or disable UFW, open or close a port (1 to 65535, tcp or udp), and block or unblock a single address or CIDR range. Manual blocks are recorded as <code>manual</code>.</p><p>The <b>Blocked computers</b> table explains every current block in plain language: <b>what</b> is blocked (one computer, or a whole group of addresses and how many), <b>why</b>, <b>who said</b> it is bad, when it was blocked and when it lifts. For threat-feed blocks it names the list: <b>Spamhaus DROP</b> (address groups taken over by spammers or criminals, with the Spamhaus SBL reference), <b>abuse.ch Feodo Tracker</b> (command servers for banking-virus botnets) or <b>abuse.ch URLhaus</b> (computers handing out malware, with the download address it was seen at). Lookup pages and download addresses are shown as text, not links, so a malware address cannot be opened by accident. LocSec blocks by IP address only; it does not block ads or websites by name. Feed blocks made before 4.0.11-65 recorded only "threat-intelligence feed"; the next feed update fills in which list named them.</p><p>When UFW is not enabled, LocSec runs a fallback default-deny firewall of its own and keeps detecting port scans; see Troubleshooting, "UFW is off".</p><p>Automatic blocks (login monitor, port-scan monitor, threat feeds) never cover this machine's own DNS servers or default gateways, read from <code>/etc/resolv.conf</code>, NetworkManager and the routing table. That stops a feed entry or a forged probe from cutting off name resolution. A block you enter by hand is still applied. An automatic block of such an address made by an earlier version is lifted when LocSec starts.</p>
<p>Networks in <code>allow_ips</code> (loopback and private ranges by default) are never blocked automatically. LocSec never force-enables UFW; while UFW is inactive it uses its own nftables table.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-logins"><h2>Login Activity</h2><p>Successful and failed authentication events from the system journal and <code>auth.log</code>. When one source reaches <code>auth_threshold</code> failures (5) within <code>auth_window</code> seconds (900) it is blocked, provided <code>auto_block</code> and <code>response_auth_block</code> are on. Logs are read every <code>event_poll_seconds</code> (60).</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-incidents"><h2>Incidents</h2><p>Every block, scan finding and login event is recorded as an incident, newest first. The <b>Automatic response policy</b> switches control what may block automatically (failed logins, port scans, threat feeds, IPv6) and whether the fallback firewall runs while UFW is off; turning off <b>Automatic blocking</b> disables all of them. Changes apply immediately and survive restarts.</p>
<p><b>Explain</b> opens a plain-words page: what happened, what LocSec did, and what you should do, with the technical evidence folded away underneath. <b>Fix it</b> appears only when LocSec can fix the incident by itself: it blocks the computer behind a failed login or port scan (never one on your own network), or moves an infected file into quarantine. Everything else (a rootkit warning, the firewall being off, a wrong password typed at this keyboard) has no automatic fix, so Explain lists the steps instead. <b>Mark solved</b> closes the incident; existing blocks stay until they run out. The State column reads New, Looked at, Fixed or Solved. Every result can be printed or copied. No AI is involved: the explanations are fixed rules written into LocSec.</p>
<h3>How repeats are grouped</h3><p>An incident is identified by its kind, its source and its indicator &mdash; for example a failed-login incident for 203.0.113.7. While that incident is <b>open</b> (new, investigating or contained), every further observation of the same thing folds into it: the <b>Seen</b> column counts them and shows when it was last seen, rather than adding a row.</p>
<p>Once you <b>resolve or dismiss</b> it, the incident is closed permanently. A later observation of the same kind, source and indicator opens a <b>new</b> incident with its own timestamp and its own count. That is deliberate: a closed case stays closed and keeps its history, and a scanner that comes back a month later is genuinely a new event rather than an old row quietly ticking upward. Expect to see more than one row for a persistent source over time &mdash; that is the timeline working, not duplication.</p>
<p>The list shows one row per incident in its current state, however many times it has been updated. Two rows with the same indicator are therefore two separate incidents, distinguishable by their timestamps.</p>
<p><b>Delete</b> permanently removes that incident and its action log from the dashboard (after a confirmation prompt); <b>Delete all</b> clears the whole timeline. Deleting does not remove firewall blocks. The most recent <code>incident_retention</code> incidents are kept.</p>
<p><b>Desktop notifications</b> pop up for about 10 seconds, even with the dashboard closed, for new incidents of the kinds you tick (virus, rootkit, IP blocked, failed login, port scan, attack pattern seen, fallback firewall on), and stay in the desktop notification list until you log out. Your ticks are saved in <code>/etc/locsecd/runtime-policy.json</code> and kept across restarts and reboots. <b>Recent notifications</b> underneath is LocSec's own copy of the last 500, kept across log-outs and reboots; one raised while nobody was logged in is shown as a single "while you were away" summary at the next log-in. <b>Clear history</b> empties that list. Save your selection, then use <b>Send test notification</b>.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-scans"><h2>Scans &amp; CVEs</h2>
<p>The top row runs one scan now: <b>AIDE</b>, <b>Lynis</b>, <b>Debsecan</b>, <b>rkhunter</b>, <b>ClamAV</b>, <b>Ports/firewall</b> and <b>CVE scan</b>. Each one otherwise runs on its own schedule (the table above). <b>CVE scan</b> runs debsecan (Debian and LMDE) and lists the security updates APT has waiting. <b>Update system</b> installs pending updates (see below). <b>Update definitions now</b> refreshes ClamAV signatures and rkhunter data. If Debian has produced an <code>aide.db.new</code> that differs from <code>aide.db</code> (the button appears only then), <b>Accept pending AIDE baseline</b> explicitly promotes it after review, retains the previous baseline as <code>aide.db.locsec-backup</code>, and secures the promoted file as <code>root:root</code> mode <code>0600</code>. <b>Build AIDE database</b> is an explicitly confirmed operation that creates the first baseline on a new machine or replaces an existing one. The <b>Schedule</b> table on the Scans page shows, for every check, how often it runs, when it last ran and when it is next due. Checks have no fixed clock time: each is due a set time after it last ran, and the ones marked "when idle" wait until the load has stayed at or below <code>idle_load</code> for <code>idle_seconds</code>.</p>
<h3>Tools</h3>
<table><tr><th>Tool</th><th>Checks</th><th>Notes</th></tr>
<tr><td>AIDE</td><td>File integrity against the baseline.</td><td>Limit <code>aide_scan_timeout</code> (3 hours), which also covers Build AIDE database. Runs at idle I/O priority. Differences after package upgrades are expected.</td></tr>
<tr><td>Lynis</td><td>System hardening audit.</td><td>Reports the hardening index, the warnings and the full suggestion list from the Lynis report file (which is root-only on disk).</td></tr>
<tr><td>rkhunter</td><td>Rootkits and suspicious files.</td><td>Warnings are verified against the package database; benign items are labelled informational.</td></tr>
<tr><td>ClamAV</td><td>Malware in <code>clamav_scan_paths</code> (<code>/home</code>).</td><td>One pass, one summary. Files over <code>clamav_max_file_mb</code> are skipped.</td></tr>
<tr><td>CVE scan</td><td>Known CVEs in installed packages (debsecan) and pending security updates.</td><td>Security updates install automatically while <code>auto_update</code> is on.</td></tr>
<tr><td>debsecan</td><td>Debian CVE feed.</td><td>Reports how many known CVEs affect installed packages and lists the ones with a fix available. Runs on Debian and LMDE (against LMDE's Debian suite); skipped on Ubuntu and Ubuntu-based Mint, where its Debian feed does not match the package versions.</td></tr>
<tr><td>Ports &amp; firewall</td><td>Listening sockets and firewall state.</td><td>An inventory, marked informational.</td></tr>
</table>
<h3>Statuses</h3>
<p>Each result shows a status: <b>Clean</b>, <b>Informational</b> (expected noise, no action), <b>Warnings</b> or <b>Findings</b> (review the report), <b>Timed out</b>, <b>Scan error</b>, <b>Skipped</b>, <b>Tool not installed</b> or <b>Not initialized</b>. A scan is only labelled clean when the tool completed and reported nothing of concern.</p>
<h3>Updates</h3>
<p><b>Update system</b> simulates <code>apt-get upgrade</code>, then installs the pending packages (security only while <code>update_security_only</code> is true) without prompts and keeps your configuration files. The result lists what was installed and explains anything left over: phased-rollout holds, a busy apt lock, or automatic updates being disabled.</p>
<p>Only one maintenance job runs at a time. A second request is refused with the name of the job that is running, where it came from (dashboard or schedule) and how long it has run; the Scans page shows it under <b>Running now</b>.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-malware"><h2>Malware / Quarantine</h2><p>Quarantine moves a file out of place into a private vault, keeps it from running, and records where it came from. Enter an absolute path to scan one file with ClamAV; an infected file is quarantined (tick <b>Quarantine even if clean</b> to quarantine a file ClamAV does not flag). Infected files found by scheduled scans are listed under <b>Detections awaiting action</b> with a <b>Quarantine</b> button each. In <b>Quarantined files</b>, <b>Restore</b> puts a file back exactly where it was, with its original owner and permissions (setuid/setgid bits are not restored), and <b>Delete</b> removes it permanently; <b>Delete all</b> empties the vault. A file whose quarantine record is missing (an interrupted quarantine) has no recorded location, so it can only be deleted. Paths under core system directories (<code>/bin</code>, <code>/usr/lib</code>, <code>/etc</code> and similar) are refused unless you tick <b>Force</b>, so a false positive cannot disable a working system binary.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-threats"><h2>Threat Intelligence</h2><p>LocSec keeps a local copy of public feeds (Spamhaus DROP, Feodo Tracker and URLhaus by default, set in <code>feed_urls</code>) and refreshes it every <code>feed_interval</code> seconds (12 hours). Each feed is capped at 8 MB on download and the stored indicator list at 200,000 entries per category, so a feed that suddenly publishes millions of entries cannot grow the daemon's memory or the state directory without limit; the page shows counts rather than downloading the indicator list itself. <b>Check reputation</b> searches that local copy only; nothing you enter is sent anywhere. With <code>feed_auto_block</code> on, feed addresses are blocked automatically, at most <code>feed_auto_block_limit</code> per refresh.</p><p>If an update reaches none of the sources (no network or DNS), the previous indicators are kept, the page says the last attempt failed, and the update is retried every 15 minutes until it succeeds. <b>Last updated</b> is the time of the last successful update.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-network"><h2>Ports &amp; Capture</h2><p>Live connections and listening ports come from <code>ss</code>. <b>Start capture</b> runs tcpdump for 5 to 3600 seconds and saves the capture under <code>/var/lib/locsecd/captures/</code>. Before 4.0.11-62 captures could come out missing or empty on Debian, whose tcpdump drops to its own <code>tcpdump</code> user and could not write into that root-only directory; LocSec now opens the file itself and tcpdump writes into it. Saved captures are listed underneath with when they were recorded and their size. <b>Analyze</b> shows who talked to whom and on which port, busiest first, with the protocol breakdown folded away underneath. Since 4.0.11-88 it uses LocSec's own built-in reader, which looks only at the link, IP and TCP/UDP headers. It is memory-safe, checks every length, and stops after 1 GB, 3 million packets or 60 seconds. A crafted capture can therefore at worst be rejected as corrupt, and Wireshark is not involved. <b>Deep analysis (Wireshark)</b>, under the results, decodes every protocol with tshark. Wireshark's decoders have a long history of security bugs, and the packets in a capture were chosen by whoever sent them. So tshark runs as a throwaway unprivileged user (systemd DynamicUser) with no network, a read-only system, LocSec's state, logs and keys hidden, a system-call filter and a 512 MB memory cap. It never opens the capture itself: LocSec passes it in on standard input. Set <code>capture_deep_analysis</code> to <code>false</code> in the configuration to remove the option entirely; <b>Delete</b> removes one capture and its results, <b>Delete all captures</b> removes every one (a capture still recording is stopped first). The filename box is there for a capture that is not in the list. Captures will not start with less than 1 GB free, stop early below 256 MB, and at most 3 run at once.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-ids"><h2>Intrusion signatures (Suricata)</h2>
<p>Suricata is a network traffic inspector. It compares packets with a large set of rules that describe known attacks and malware, including traffic that leaves this machine, which the firewall and the threat lists cannot see. Since 4.0.11-84 it is a dependency of LocSec, so it is installed together with LocSec; <code>suricata-update</code>, the rule downloader, is a recommended package and is installed where your release provides it. Suricata runs as its own service (<code>suricata.service</code>) and only watches: it never drops traffic. LocSec reads its alert file, <code>/var/log/suricata/eve.json</code>, opens no port, and starts reading at the end of the file, so alerts from while LocSec was stopped are not replayed.</p>
<p><b>Where it appears.</b> <b>Overview</b> shows a <i>suricata</i> row in Protection status, and an <i>Intrusion signatures (Suricata)</i> card with its state (monitoring, installed but not running, or no rules yet), the alerts seen since LocSec started, and when the rules were last updated. The card warns when Suricata is watching a different network interface from the one this machine uses. <b>Incidents</b> lists each alert as an <i>Attack pattern (Suricata)</i> incident; <b>Firewall &amp; Blocks</b> lists any block made from one, with the source <code>suricata</code>. The <b>Attack pattern seen</b> box on the Incidents page controls its desktop notification. There is no separate Suricata page.</p>
<p><b>Setup.</b> You do not need to edit anything. While LocSec installs, it sets the interface Suricata watches (under <code>af-packet</code> in <code>/etc/suricata/suricata.yaml</code>; the package default <code>eth0</code> is usually wrong) to the one your default route uses, downloads the rules and starts Suricata. Each edit is tested with <code>suricata -T</code> before it is kept, and the original file is saved once as <code>suricata.yaml.locsec-orig</code>. LocSec then checks every 5 minutes that the interface still matches the default route, for example after a laptop moves from Wi-Fi to a cable, and refreshes the rules every 12 hours. It never replaces an interface you set by hand; <code>sudo locsecctl suricata-setup</code> does that, and redoes the whole setup. Set <code>ids_auto_configure</code> to false to manage Suricata yourself. The Troubleshooting page has the checks if the card still says <i>missing</i>, <i>not running</i> or <i>no rules</i>.</p>
<p><b>What LocSec does with an alert.</b> Severity 1 and 2 alerts become incidents (<code>ids_incident_severity</code>). Only severity 1 (<code>ids_block_severity</code>) blocks the other address, for <code>ids_block_hours</code> (24), at most <code>ids_block_max_per_hour</code> (10) times an hour, through the same block list as every other automatic block, so the allowlist and your DNS servers and gateways are never blocked. Inbound UDP is only recorded, because a forged source address could otherwise be used to get any address blocked. Suricata cannot read inside encrypted (HTTPS) traffic, and some rules raise false alarms: put the rule number (sid) from the incident into <code>ids_ignore_sids</code> to silence it, or set <code>ids_block_severity</code> to 0 to record only. <code>ids_enabled</code> set to false stops LocSec reading Suricata altogether.</p>
<p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-services"><h2>Services</h2><p>Lists the units LocSec coordinates first — these stay listed when stopped — followed by everything else currently running. Each row shows the unit's state and its <b>PID</b>, the main process ID systemd reports for it. A dash means the unit has no running main process: it is stopped. ufw is a one-shot unit that loads its rules into the kernel and exits, so it never has a PID; LocSec asks ufw itself and shows <b>running</b> with a note when the rules are loaded, or <b>rules off</b> when they are not. The rows are read-only; the manual box below takes any unit name for start, restart, stop, enable or disable.</p><p>Units your own access depends on are protected: the manual box refuses stop, restart and disable for ssh, networking, NetworkManager, dbus, logind, journald, udev, the display manager, polkit and locsecd itself, and allows start and enable. Stopping any of those either cuts your connection to the machine or kills the desktop session this window is displayed in; use the command line if you genuinely need to.</p><p>A failed start, stop or restart shows why in the output box: systemd's message plus the unit's own journal lines from that attempt. The same text is kept in the <b>service-action</b> incident. A masked unit is named as masked, with the command to unmask it, and a masked LocSec-managed unit shows <b>masked</b> in the State column. LocSec never masks or unmasks units itself.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-reports"><h2>Reports</h2><p>Every scan, CVE check and update writes a JSON report to <code>/var/lib/locsecd/reports/</code>. The page lists the 50 most recent; <b>View</b> opens one and <b>Delete</b> removes it. Each check in a report starts with what it found in plain language and what to do about it; the tool's own output is under <b>Show the full output</b>. <b>What to do</b> collects all of it on one page that can be printed or copied. A very large report is shown in part rather than in full, so opening it cannot lock up the window; the complete file stays on disk. Every file in the reports directory, including the full AIDE outputs, is deleted automatically once it is <code>report_retention_days</code> old (7 days), so reports cannot fill the disk.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-logs"><h2>Logs</h2><p>Pick a log from the <b>Log</b> list. Each line is translated into plain language: <b>when</b> it happened, a coloured <b>kind</b> (OK, Info, Warning, Problem) and <b>what happened</b> in a sentence or two. A short line at the top says what that log is for. The counts next to the coloured labels add up what is on screen.</p>
<p><b>Show: Only things to look at</b> hides everything marked OK or Info, leaving the Warning and Problem rows. <b>Show the original log lines</b>, at the bottom, opens the exact text the computer wrote, so nothing is hidden. <b>Refresh</b> reads the log again. The same line repeated within a few minutes is shown once, with how many times it happened.</p>
<p>Rows that need action carry a green <b>What to do</b> box with the fix. <b>What to do</b> in the toolbar collects every Warning and Problem in that log on one page, with the fix for each; <b>Print</b> on that page prints it (the desktop window saves it as a PDF in Documents and opens it, so you can print from the PDF viewer), and <b>Copy as text</b> copies it.</p>
<p><b>AIDE (latest check)</b> lists the most important changes first. For each changed file it says <i>what</i> changed (contents, size, permissions, owner), which package owns it, and whether software installed or updated since the last snapshot explains it (from <code>/var/log/dpkg.log</code>). Explained changes are Info; unexplained ones are Warning; a file that gains setuid/setgid or capabilities, or changes owner, is a Problem.</p>
<h3>The firewall (UFW) log</h3>
<p>This view reads the last 1000 firewall log lines and shows:</p>
<ul>
<li>how many connection attempts the firewall blocked, and from how many sources;</li>
<li><b>Top sources</b>: each source address, whether it is on the internet or the local network, the ports it tried, and whether it is a blocked computer or ran a port scan;</li>
<li><b>Most-targeted ports</b>: each port and the service normally on it (22 is SSH, 445 is Windows file sharing, and so on);</li>
<li><b>All entries</b>: time, action (Blocked, Allowed, Logged), source, port and the reason. Local broadcasts, packets from closed connections and unsolicited internet connections are explained separately, because they mean different things.</li>
</ul>
<p>Most blocked internet traffic comes from automated scanners probing every reachable address. It is blocked and needs no action. A source marked <b>port scan</b> is blocked automatically by LocSec's port-scan detection.</p>
<h3>Clearing</h3>
<p>Only <code>locsecd.log</code> can be cleared here, with <b>Clear LocSec's log</b>. It is emptied in place rather than deleted, so LocSec keeps writing to the same file, and the clear is recorded as an incident. The file is opened with <code>O_NOFOLLOW</code> and truncated through that descriptor, never by path, and must be a regular file inside LocSec's own log directory, so a symbolic link left there cannot point the clear at another file. <code>auth.log</code> and <code>syslog</code> are the first thing anyone reads after a break-in, and the scan logs belong to rkhunter, ClamAV and AIDE, so none of them can be cleared from the dashboard. To clear one anyway, use a terminal: <code>sudo truncate -s 0 /var/log/&lt;file&gt;</code>.</p>
<h3>Where each log comes from</h3>
<table><tr><th>Log</th><th>File, when present</th><th>Otherwise, the systemd journal</th></tr>
<tr><td>LocSec</td><td><code>/var/log/locsecd/locsecd.log</code></td><td><code>journalctl -u locsecd</code></td></tr>
<tr><td>Authentication</td><td><code>/var/log/auth.log</code></td><td>auth and authpriv facilities (<code>journalctl SYSLOG_FACILITY=4 SYSLOG_FACILITY=10</code>)</td></tr>
<tr><td>rkhunter</td><td><code>/var/log/rkhunter.log</code></td><td>none; rkhunter writes only its file, created on its first run</td></tr>
<tr><td>ClamAV (freshclam)</td><td><code>/var/log/clamav/freshclam.log</code></td><td><code>journalctl -u clamav-freshclam</code></td></tr>
<tr><td>AIDE (latest check)</td><td>the newest <code>/var/lib/locsecd/reports/aide-full-*.txt</code>, else <code>/var/log/aide/aide.log</code></td><td><code>journalctl -u dailyaidecheck</code></td></tr>
<tr><td>UFW</td><td><code>/var/log/ufw.log</code></td><td>kernel messages containing <code>[UFW </code> (<code>journalctl -k</code>)</td></tr>
<tr><td>System</td><td><code>/var/log/syslog</code></td><td>the whole journal</td></tr>
<tr><td>Suricata alerts</td><td>alert records from <code>/var/log/suricata/eve.json</code> (or <code>ids_eve_path</code>), else <code>/var/log/suricata/fast.log</code></td><td>none; alerts are only written to these files</td></tr>
<tr><td>Suricata engine</td><td><code>/var/log/suricata/suricata.log</code></td><td><code>journalctl -u suricata</code></td></tr>
</table>
<p>The authentication, system and UFW files are written by rsyslog, which LocSec installs as a dependency. Every log falls back to the journal when its file is missing (for example if rsyslog was removed), and the line above the list says which one was read. A log with neither is marked <i>(no entries yet)</i>, and selecting it says why. The UFW log needs firewall logging on: <code>sudo ufw logging low</code>.</p><p><a href="#help-top">Back to contents</a></p></div>


<div class="card" id="help-schedule"><h2>Schedules &amp; resource use</h2>
<table><tr><th>Job</th><th>Default cadence</th><th>Setting</th></tr>
<tr><td>AIDE, Lynis, debsecan, rkhunter, ports snapshot, CVE scan</td><td>Weekly, staggered a day apart</td><td><code>scan_interval</code>, <code>scan_stagger_seconds</code></td></tr>
<tr><td>ClamAV</td><td>Daily</td><td><code>clamav_scan_interval</code></td></tr>
<tr><td>Security updates</td><td>Every 12 hours</td><td><code>update_interval</code>, <code>auto_update</code></td></tr>
<tr><td>Virus and rootkit definitions</td><td>Daily</td><td><code>defs_update_interval</code></td></tr>
<tr><td>Threat-intelligence feeds</td><td>Every 12 hours</td><td><code>feed_interval</code></td></tr>
</table>
<p>Scheduled scans and updates wait for an idle machine, run at low CPU and idle I/O priority, and never run together. Manual runs start immediately. Real-time protection (login monitoring, blocking) is not delayed by load. Scan tools run in a separate systemd unit with their own time limit, so a stuck tool is stopped cleanly rather than hanging the service.</p><p><b>Sleep, hibernate and the laptop lid.</b> LocSec never wakes a computer that is asleep or hibernated: a suspended machine runs nothing, so no scheduled job starts until it is awake and has then been idle for <code>idle_seconds</code>. Overdue jobs are not lost; they start one per day once that happens. While a scan, update or AIDE job is <i>running</i>, LocSec holds a systemd-logind inhibitor lock so that idle suspend and closing the lid do not freeze the job halfway. The lock is released the moment the job ends, and is capped at 6 hours. Set <code>inhibit_lid_switch</code> to <code>false</code> if you want the lid to suspend the machine even during a job (idle suspend is still held off), or <code>inhibit_sleep_during_jobs</code> to <code>false</code> to turn the feature off. On a laptop in a bag a long job with the lid closed keeps it awake and warm, so close the lid only when you are happy for that to happen.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-config"><h2>Configuration</h2><p>Settings live in <code>/etc/locsecd/locsecd.conf</code> (JSON). After editing, run <code>sudo systemctl restart locsecd.service</code>. The response switches on the Incidents page are saved separately and take effect immediately.</p>
<p class="muted">Two further files belong to the package but are not read by the daemon: <code>/etc/sysctl.d/60-locsec-hardening.conf</code> and <code>/etc/modprobe.d/60-locsec-disable-unused-protocols.conf</code> apply kernel and network hardening at install time. See the Troubleshooting page for what they set and how to opt out.</p>
<table><tr><th>Key</th><th>Default</th><th>Purpose</th></tr>
<tr><td>listen / port</td><td>127.0.0.1 / 8765</td><td>Dashboard address, HTTPS only. <code>listen</code> is pinned to 127.0.0.1: any other value is replaced and logged.</td></tr>
<tr><td>auth_threshold / auth_window</td><td>5 / 900</td><td>Failures within the window that trigger a block.</td></tr>
<tr><td>scan_detect / scan_ports / scan_window</td><td>true / 8 / 600</td><td>Block a public address that probes this many different closed ports within the window (seconds). Needs firewall logging.</td></tr>
<tr><td>scan_block_hours / scan_block_max_per_hour</td><td>24 / 10</td><td>How long a port-scan block lasts, and the most that are made per hour (scan source addresses can be forged).</td></tr>
<tr><td>ids_enabled / ids_response_block</td><td>true / true</td><td>Read Suricata alerts, and let severity-1 alerts block the other address. Needs Suricata installed.</td></tr>
<tr><td>ids_block_severity / ids_incident_severity</td><td>1 / 2</td><td>Highest Suricata severity number that is blocked (0 = never) and that is recorded as an incident at all.</td></tr>
<tr><td>ids_block_hours / ids_block_max_per_hour</td><td>24 / 10</td><td>How long a signature block lasts, and the most made per hour.</td></tr>
<tr><td>ids_auto_configure</td><td>true</td><td>Set Suricata's capture interface to the one the default route uses (only replacing eth0, a missing interface or LocSec's own earlier choice), load the rules suricata-update downloads, and reload them after each update.</td></tr>
<tr><td>ids_ignore_sids / ids_rules_update / ids_eve_path</td><td>[] / true / /var/log/suricata/eve.json</td><td>Rule numbers to ignore, whether LocSec runs suricata-update after feed updates, and where Suricata writes alerts.</td></tr>
<tr><td>fallback_firewall</td><td>true</td><td>Install LocSec's own default-deny input chain while UFW is installed but not enabled.</td></tr>
<tr><td>fallback_allow_tcp / fallback_allow_udp</td><td>[]</td><td>Incoming ports the fallback firewall leaves open, for example [22].</td></tr>
<tr><td>allow_ips</td><td>loopback and private ranges</td><td>Never blocked automatically.</td></tr>
<tr><td>idle_load / idle_seconds</td><td>1.0 / 600</td><td>Idle rule for heavy jobs.</td></tr>
<tr><td>inhibit_sleep_during_jobs / inhibit_lid_switch</td><td>true / true</td><td>Hold off suspend, and ignore lid close, while a job is running. Never wakes a sleeping computer. See Schedules &amp; resource use.</td></tr>
<tr><td>clamav_scan_paths</td><td>["/home"]</td><td>Directories ClamAV scans.</td></tr>
<tr><td>clamav_max_file_mb / clamav_timeout</td><td>100 / 7200</td><td>Largest file scanned, job time limit (seconds).</td></tr>
<tr><td>clamav_extra_excludes</td><td>[]</td><td>Additional paths or patterns to skip.</td></tr>
<tr><td>aide_scan_timeout</td><td>10800</td><td>AIDE time limit for checks, Initialize and Rebuild (seconds).</td></tr>
<tr><td>lynis_timeout</td><td>3600</td><td>Lynis time limit (seconds).</td></tr>
<tr><td>rkhunter_ignore</td><td>[]</td><td>Patterns for known-good rkhunter warnings.</td></tr>
<tr><td>auto_update / update_security_only</td><td>true / true</td><td>Apply updates automatically; security updates only.</td></tr>
<tr><td>include_phased_updates</td><td>false</td><td>Apply phased-rollout packages immediately.</td></tr>
<tr><td>dashboard_report_max_mb</td><td>100</td><td>Largest report the dashboard will open.</td></tr>
<tr><td>report_retention_days</td><td>7</td><td>Every file in the reports directory is deleted once it is this many days old.</td></tr>
<tr><td>retention_days</td><td>14</td><td>Packet captures and LocSec's rotated log files are deleted after this many days.</td></tr>
</table><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-cli"><h2>Command line</h2>
<pre>locsecctl status | start | stop | restart | enable | disable
locsecctl scan-aide       # also: scan-lynis, scan-rkhunter, scan-clamav,
                          #       scan-debsecan, scan-ports
locsecctl cve             # CVE scan now
locsecctl update          # apply updates now
locsecctl feed-update     # refresh threat feeds now
locsecctl aide-init       # initialize only if no active AIDE baseline exists
locsecctl aide-accept     # explicitly promote /var/lib/aide/aide.db.new
locsecctl aide-reinitialize # explicitly rebuild and replace the active baseline
locsecctl logs            # last 200 journal lines
locsecctl gui             # open the desktop window (browser if PyQt6 is missing)
locsecctl tray            # start the panel icon without opening the window
locsecctl uninstall --dry-run # staged removal plan; also --keep-tools, --all,
                          #   --include-firewall, -y (run with sudo)
sudo journalctl -u locsecd.service -f
sudo tail -f /var/log/locsecd/locsecd.log</pre>
<h3>Installing and upgrading the package</h3>
<p>Install or upgrade with apt, from a terminal, so dependencies resolve and the installer's own messages (ClamAV's first signature download, AIDE) are visible as they happen. The installer restarts <code>locsecd</code> itself.</p>
<pre>sudo apt install ./locsecd_&lt;version&gt;_amd64.deb
sudo apt install --reinstall ./locsecd_&lt;version&gt;_amd64.deb   # a rebuilt package with the same version number</pre>
<p>Install with <code>apt</code> from a terminal, as above. Do not use the GDebi graphical installer: on some desktops it fails with a GTK/VTE runtime error and looks frozen while the package is still being configured. If you double-click the file instead, use your distribution's APT-based software installer. Avoid <code>dpkg -i</code> alone; it does not fetch missing dependencies, and if you used it, follow with <code>sudo apt-get install -f</code>. If an install was interrupted, finish it with <code>sudo dpkg --configure -a</code>, then <code>sudo apt-get install -f</code>, and check that <code>dpkg -l locsecd</code> shows <code>ii</code>.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-security"><h2>Security model</h2><ul style="margin:0;padding-left:18px;line-height:1.7">
<li>The dashboard listens on 127.0.0.1 only (<code>listen</code> is pinned there), over HTTPS (TLS 1.2 or later) with a certificate made for this machine, and there is no plain-HTTP fallback. The desktop window and the browser launcher check that the server presents exactly that certificate <i>before</i> they send the API token, so a program that grabbed port 8765 while LocSec was stopped cannot collect it. Every request needs the per-install token in <code>/var/lib/locsecd/api.token</code> (root only). Requests whose <code>Host</code> is not 127.0.0.1 or localhost are refused, so a web page cannot reach the API through DNS rebinding, and cross-site POSTs are refused.</li>
<li>Threat feeds are fetched over HTTPS only. A plain <code>http://</code> URL in <code>feed_urls</code> is ignored with a warning, because whoever can rewrite a feed in transit chooses what this machine blocks.</li>
<li>The daemon runs under a systemd sandbox with a restricted capability set. Scan tools run in a separate, time-limited unit.</li>
<li>Allowlisted networks are never auto-blocked, and feed blocking is capped per refresh. Port-scan blocks last 24 hours, are limited to 10 an hour, and skip any address this machine is connected to, because probe source addresses can be forged.</li>
<li>The browser or desktop window signs in with a single-use login code and then holds a random session cookie (HttpOnly, Secure, SameSite=Strict, with no expiry date so it is not saved to disk) that the daemon expires (8 hours idle, 3 days at most). The cookie is never the API token, so a stolen cookie does not give lasting access; the token itself is in a root-only file. The desktop window signs in again by itself when its session expires. Scan, apt and notification jobs run in their own units with extra restrictions (the notification helper has no privileges at all). An example AppArmor profile for the daemon is in <code>/usr/share/doc/locsecd/examples/</code>; it is not loaded by default.</li>
<li>Quarantine refuses system directories unless forced; restore refuses to write through a symlinked directory or over a non-regular file; captures are limited by free disk space.</li>
<li>The package installs conservative kernel and network hardening (<code>/etc/sysctl.d/60-locsec-hardening.conf</code>) and blocks four unused network protocol modules (<code>/etc/modprobe.d/60-locsec-disable-unused-protocols.conf</code>). Both are configuration files: edit or delete them and the change survives upgrades. Each documents what was deliberately left out — reverse-path filtering, IPv6 router advertisements, magic SysRq and user namespaces — because those break roaming laptops or desktop sandboxes.</li>
</ul><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-source"><h2>Source and licence</h2>
<p><b>Licence: GPL-3 or later.</b> The full text is at <code>/usr/share/common-licenses/GPL-3</code>, and <code>/usr/share/doc/locsecd/copyright</code> records it in machine-readable form. Every executable file in the package carries a GPL notice header. Releases before 4.0.11-42 stated no licence anywhere, which was an omission rather than a different licence.</p>
<p>The desktop window imports PyQt6, which is GPLv3-or-commercial, so the GUI is a derived work of it. The daemon runs UFW, AIDE, Lynis, rkhunter and the rest as separate processes, which does not make it a derived work of those, but the package ships as one unit under one licence.</p>
<p>No third-party code is bundled. The package is thirty text files &mdash; Python, shell, systemd units, configuration and one SVG icon &mdash; with no binaries, blobs or vendored dependencies. Everything else it uses comes from your distribution.</p>
<p><b>Rebuilding it yourself.</b> From 4.0.11-41 LocSec ships as a Debian source package. The only build dependency is <code>dpkg-dev</code> &mdash; no debhelper, no compiler, no fakeroot &mdash; so it can be rebuilt on the machine it protects without installing a build toolchain.</p>
<pre>sudo apt install dpkg-dev
dpkg-source -x locsecd_5.0-&lt;rev&gt;.dsc
cd locsecd-5.0
dpkg-buildpackage -us -uc -b
sudo apt install -y ../locsecd_5.0-&lt;rev&gt;_amd64.deb</pre>
<p><code>debian/rules build</code> syntax-checks the Python and shell that ships without producing a package. The source tree mirrors the installed filesystem, so a file you want to read sits at the path it installs to. Appendix C of the installation guide covers the layout and the three files a release bump touches.</p>
<p><a href="#help-top">Back to contents</a></p></div>
`;

page('overview');
healthPing();
setInterval(healthPing,15000);
</script></body></html>'''



def _tls_context():
    """The server-side TLS context, or raises RuntimeError saying what is wrong.
    Refuses a key that anyone but root and the dashboard's own group could have read:
    whoever holds it can pose as this dashboard to the desktop window."""
    try:
        st=os.lstat(TLS_KEY)
    except OSError as e:
        raise RuntimeError(f'no dashboard private key at {TLS_KEY} ({e.strerror})')
    ids=_web_ids()
    group_ok=(st.st_mode&0o040)==0 or (ids is not None and st.st_gid==ids[1])
    if not stat.S_ISREG(st.st_mode) or st.st_uid!=0 or (st.st_mode&0o037) or not group_ok:
        raise RuntimeError(f'{TLS_KEY} must be a regular file owned by root, mode 0640 with group {WEB_USER} (or 0600)')
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version=ssl.TLSVersion.TLSv1_2
    try:
        ctx.load_cert_chain(TLS_CERT,TLS_KEY)
    except (OSError,ssl.SSLError) as e:
        raise RuntimeError(f'cannot load the dashboard certificate {TLS_CERT} ({e})')
    return ctx

_BIND_RETRY_SECONDS=30
_WATCHED_THREADS=[]   # monitor and notifier threads: if one dies, server() exits so systemd restarts a whole daemon

def server(worker=None):
    # HTTPS only, and no fallback to plain HTTP: a downgrade path would let anything that can
    # bind this port first pose as the dashboard. Without a usable certificate the dashboard
    # stays off and monitoring, blocking and scheduled jobs carry on.
    try:
        ctx=_tls_context()
    except RuntimeError as e:
        ctx=None
        log(f'dashboard NOT started: {e}. Fix: sudo locsecctl tls-renew && sudo systemctl restart locsecd','ERROR')
    srv=None
    next_bind=0.0; bind_logged=False
    def _bind():
        # A port clash must not take monitoring down with it: an uncaught OSError here killed the daemon,
        # systemd restarted it into the same clash until StartLimitBurst gave up, and the machine ended up
        # with no login monitoring, blocking or scans. Log once, keep monitoring, retry every 30 seconds.
        nonlocal srv,bind_logged
        try:
            srv=BoundedThreadingHTTPServer((LISTEN_ADDR,int(CFG['port'])),Handler,tls_context=ctx)
        except OSError as e:
            if not bind_logged:
                log(f'dashboard NOT started: cannot listen on {LISTEN_ADDR}:{CFG["port"]} ({e}). Monitoring continues; '
                    'retrying every 30 seconds. Fix: free the port or change "port" in /etc/locsecd/locsecd.conf','ERROR')
                bind_logged=True
            return
        srv.timeout=1
        bind_logged=False
        log(f'API/dashboard listening on https://{LISTEN_ADDR}:{CFG["port"]} (TLS 1.2+)')
    if ctx is not None: _bind()
    next_bind=time.time()+_BIND_RETRY_SECONDS
    rc=0
    try:
        while not STOP_EVENT.is_set():
            if srv is not None: srv.handle_request()
            else:
                STOP_EVENT.wait(1)
                if ctx is not None and time.time()>=next_bind:
                    _bind(); next_bind=time.time()+_BIND_RETRY_SECONDS
            # The monitoring thread catches errors per tick, but anything that
            # escapes kills it silently while the dashboard keeps answering:
            # no login monitoring, no scans, no updates, and nothing to say so.
            # Exit instead, so systemd (Restart=always) brings up a whole one.
            if not STOP_EVENT.is_set():
                dead=[t.name for t in ([worker] if worker is not None else [])+_WATCHED_THREADS if not t.is_alive()]
                if dead:
                    log(f'the {", ".join(dead)} thread stopped unexpectedly; exiting so systemd restarts LocSec','ERROR')
                    rc=1; break
    finally:
        if srv is not None: srv.server_close()
        # The blocking half of capture teardown, outside signal context: the
        # handler has already sent SIGTERM, so these waits usually return at
        # once. cgroup-kill (KillMode=control-group) reaches every ordinary
        # child of ours anyway; this is what makes the exit orderly rather
        # than relying on it.
        # Sibling units first: that is one non-blocking call, and it must not
        # be starved by capture teardown if systemd's stop timeout runs short.
        _stop_inflight_priv_units()
        if _FRESHCLAM_STOPPED.is_set():
            broker('svc.fixed',op='freshclam.start_nowait')
        with CAPTURE_LOCK:
            captures=list(ACTIVE_CAPTURES)
        # All captures already got SIGTERM from the signal handler; wait for
        # them together (5s in total, not 10s each), then SIGKILL what is left.
        deadline=time.time()+5
        for proc in captures:
            try: proc.wait(timeout=max(0.1,deadline-time.time()))
            except Exception: pass
        for proc in captures:
            if proc.poll() is None:
                try: os.killpg(proc.pid, signal.SIGKILL)
                except Exception: pass
        log('LocSec server shut down cleanly')
    return rc

def fix_rkhunter_web_cmd():
    # Debian's rkhunter package ships /etc/rkhunter.conf with two settings
    # that between them make "rkhunter --update" fail out of the box:
    #
    # 1. WEB_CMD="/bin/false" (meant to just disable the online-version
    #    check) but rkhunter's own config validator rejects that value
    #    outright: "Invalid WEB_CMD configuration option: Relative
    #    pathname". WEB_CMD="" is the value that actually disables the
    #    check without failing validation.
    # 2. MIRRORS_MODE=1 ("only use local mirrors") -- Debian's own default,
    #    documented in rkhunter's README, deliberately ships this way so
    #    rkhunter never contacts a remote mirror unless you opt in. With no
    #    local mirrors configured either, every data-file download fails
    #    with "Unable to determine the latest version number" because it
    #    never has anywhere to fetch from. MIRRORS_MODE=0 lets it use the
    #    real (SourceForge) mirror list -- required for the auto-update
    #    feature to do anything at all.
    #
    # Both idempotent; safe to call before every rkhunter invocation.
    conf=Path('/etc/rkhunter.conf')
    try:
        try:
            with _priv_open(conf) as fh: text=fh.read().decode('utf-8','replace')
        except FileNotFoundError: return False
        fixed=re.sub(r'(?m)^WEB_CMD\s*=\s*"?/bin/false"?\s*$','WEB_CMD=""',text)
        fixed=re.sub(r'(?m)^MIRRORS_MODE\s*=\s*1\s*$','MIRRORS_MODE=0',fixed)
        if fixed!=text:
            # locsecd.service mounts /etc read-only (ProtectSystem=strict); edit it from a transient unit.
            rc,out=broker('job.rkhunter_fix_conf')
            if rc!=0:
                log(f'could not patch rkhunter.conf (rc={rc}): {out[-300:]}','ERROR'); return False
            log('patched rkhunter.conf: WEB_CMD -> "" and MIRRORS_MODE -> 0 (Debian defaults otherwise block --update entirely)')
            return True
    except Exception as e:
        log(f'could not patch rkhunter.conf: {e}','ERROR')
    return False

# ======================= PRIVILEGE BROKER (begin) =======================
# Everything this daemon does that needs root goes through broker(verb, **args).
#
# Each verb has a fixed name, a fixed set of arguments and a validator for every
# argument, and it builds its command line itself. No verb accepts a command, an
# option string, an arbitrary path or an arbitrary unit name; the only paths a
# verb accepts are checked against the one directory they must be in. Policy that
# must hold whoever asks (no block wider than /8 or /16, the protected service
# list, the package allowlist) is enforced HERE, not only in the dashboard code
# that calls it.
#
# Since 4.0.11-91 the verbs run in a separate root process (locsecd-broker.service)
# and the rest of LocSec, as the unprivileged user locsec, can only ask for them
# over /run/locsecd/broker.sock. The list is the complete answer to "what can
# LocSec do as root":
#     locsecctl broker-verbs
#
# Enforced at runtime: _run_transient() and run() refuse privileged commands
# (ufw, nft, tcpdump, clamscan, systemd-run, systemd-inhibit, apt-get, freshclam
# and every systemctl action that changes state) unless a broker verb is running.
# A call site that bypasses the broker therefore fails loudly instead of working.

# ---- firewall: ufw ----
def _ufw(args,timeout=30):
    if not have('ufw'): return 127,'ufw is not installed'
    return run(['ufw']+args,timeout)

@_verb('fw.ufw.status','ufw status [verbose|numbered]',
       detail=_A(_vchoice('plain','verbose','numbered'),'plain'),timeout=_A(_vint(5,300),30))
def _bv_ufw_status(detail,timeout):
    return _ufw(['status'] if detail=='plain' else ['status',detail],timeout)

@_verb('fw.ufw.deny','ufw insert 1 deny from TARGET (no range wider than /8 or /16)',target=_A(_v_block_target))
def _bv_ufw_deny(target):
    return _ufw(['insert','1','deny','from',str(target)])

@_verb('fw.ufw.undeny','ufw delete deny from TARGET',target=_A(_v_any_net))
def _bv_ufw_undeny(target):
    return _ufw(['delete','deny','from',str(target)])

@_verb('fw.ufw.enable','ufw --force enable')
def _bv_ufw_enable():
    return _ufw(['--force','enable'])

@_verb('fw.ufw.disable','ufw disable')
def _bv_ufw_disable():
    return _ufw(['disable'])

@_verb('fw.ufw.allow_port','ufw allow PORT/PROTO',port=_A(_vport),proto=_A(_vproto))
def _bv_ufw_allow(port,proto):
    return _ufw(['allow',f'{port}/{proto}'])

@_verb('fw.ufw.unallow_port','ufw delete allow PORT/PROTO',port=_A(_vport),proto=_A(_vproto))
def _bv_ufw_unallow(port,proto):
    return _ufw(['delete','allow',f'{port}/{proto}'])

# ---- firewall: LocSec's own nftables table ----
@_verb('fw.nft.ensure','create table inet locsec with the blocked4/blocked6 sets and their drop rules, if missing',
       refused=lambda msg:False)
def _bv_nft_ensure():
    if not have('nft'): return False
    specs=[
      ['nft','add','table','inet','locsec'],
      ['nft','add','set','inet','locsec','blocked4','{','type','ipv4_addr',';','flags','interval',';','}'],
      ['nft','add','set','inet','locsec','blocked6','{','type','ipv6_addr',';','flags','interval',';','}'],
      ['nft','add','chain','inet','locsec','input','{','type','filter','hook','input','priority','-5',';','policy','accept',';','}'],
    ]
    for c in specs: run(c,30)
    rc,chain=run(['nft','list','chain','inet','locsec','input'],30)
    if rc!=0: return False
    if '@blocked4 drop' not in chain: run(['nft','add','rule','inet','locsec','input','ip','saddr','@blocked4','drop'],30)
    if '@blocked6 drop' not in chain: run(['nft','add','rule','inet','locsec','input','ip6','saddr','@blocked6','drop'],30)
    return True

def _nft_set(target):
    return 'blocked4' if target.version==4 else 'blocked6'

@_verb('fw.nft.add','add TARGET to the blocked4/blocked6 set (no range wider than /8 or /16)',target=_A(_v_block_target))
def _bv_nft_add(target):
    return run(['nft','add','element','inet','locsec',_nft_set(target),'{',str(target),'}'],30)

@_verb('fw.nft.remove','remove TARGET from the blocked4/blocked6 set',target=_A(_v_any_net))
def _bv_nft_remove(target):
    if not have('nft'): return 127,'nft is not installed'
    return run(['nft','delete','element','inet','locsec',_nft_set(target),'{',str(target),'}'],30)

@_verb('fw.nft.fallback_present','whether the fallback chain exists',refused=lambda msg:False)
def _bv_fallback_present():
    rc,_=run(['nft','list','chain','inet','locsec','fallback'],15)
    return rc==0

@_verb('fw.nft.fallback_apply','install the default-deny fallback chain (allowed ports from the configuration, plus the given live SSH ports)',
       ssh_ports=_A(_v_ports))
def _bv_fallback_apply(ssh_ports):
    return run(['nft','-f','-'],30,input_text=_fallback_script(ssh_ports))

@_verb('fw.nft.fallback_remove','delete the fallback chain')
def _bv_fallback_remove():
    return run(['nft','-f','-'],30,input_text='flush chain inet locsec fallback\ndelete chain inet locsec fallback\n')

# ---- services ----
@_verb('svc.control','systemctl start|stop|restart|enable|disable UNIT. Protected units are never stopped, restarted or '
       'disabled; units outside the LocSec-managed set need allow_manual_service_control=true',
       unit=_A(_v_service),action=_A(_vchoice('start','stop','restart','enable','disable')))
def _bv_svc_control(unit,action):
    rc_id,canon=run(['systemctl','show','-p','Id','--value','--',unit],10)
    canon=canon.strip() if rc_id==0 else ''
    if (unit in _PROTECTED_UNITS or canon in _PROTECTED_UNITS) and action in _DISRUPTIVE_ACTIONS:
        return 126,f'refused: {unit} is protected'
    if unit not in _managed_units() and not CFG.get('allow_manual_service_control',False):
        return 126,f'refused: {unit} is not LocSec-managed and allow_manual_service_control is off'
    return run(['systemctl',action,'--',unit],30)

# Fixed service operations LocSec itself performs; nothing here takes a unit name.
_SVC_FIXED={
 'clamd.start':        [(['systemctl','start','clamav-daemon.service'],120)],
 'freshclam.stop':     [(['systemctl','stop','clamav-freshclam.service'],30)],
 'freshclam.start':    [(['systemctl','start','clamav-freshclam.service'],60)],
 'clamav.enable':      [(['systemctl','enable','--now','clamav-freshclam.service'],30),
                        (['systemctl','enable','--now','clamav-daemon.service'],30)],
 'suricata.reload':    [(['systemctl','try-reload-or-restart','suricata.service'],120)],
}

@_verb('svc.fixed','one of LocSec\'s own fixed service operations: '+', '.join(sorted(_SVC_FIXED))+', freshclam.start_nowait',
       op=_A(_vchoice(*sorted(_SVC_FIXED),'freshclam.start_nowait')))
def _bv_svc_fixed(op):
    if op=='freshclam.start_nowait':
        # Shutdown path: never wait on systemd here.
        try: subprocess.run(['systemctl','start','--no-block','clamav-freshclam.service'],timeout=10,
                            stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
        except Exception: pass
        return 0,''
    rc,out=0,''
    for cmd,t in _SVC_FIXED[op]:
        rc,o=run(cmd,t); out+=o
    return rc,out

@_verb('jobs.stop_inflight','stop the LocSec job units started for the calling process (apt units are left to finish)',refused=lambda msg:None)
def _bv_stop_inflight():
    me=_client_pid()
    with INFLIGHT_LOCK:
        units=[u for u,owner in INFLIGHT_PRIV_UNITS.items() if owner==me and not u.startswith(_APT_UNIT_PREFIX)]
    if not units: return None
    try: subprocess.run(['systemctl','stop','--no-block','--']+units, timeout=10,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    except Exception: pass
    return None

@_verb('jobs.stop_stale','systemctl stop for LocSec job units (locsecd-*-pPID-XXXXXXXX.service only, never apt units)',
       remote=False,units=_A(_v_locsec_units))
def _bv_stop_stale(units):
    return run(['systemctl','stop','--']+units,60)

# ---- jobs in sibling transient units ----
@_verb('job.aide_check','aide --check with one of the two packaged configurations; full output saved to a broker work file',
       remote=False,conf=_A(_vchoice(*_AIDE_CONFS)),timeout=_A(_vint(300,259200)),
       save_to=_A(_v_state_file(lambda:BROKER_WORK,r'aide-full-\d{8}-\d{6}-[0-9a-f]{8}\.txt')))
def _bv_aide_check(conf,timeout,save_to):
    return _run_transient(['aide','--config',conf,'--check'],timeout,prefix='locsecd-scan',props=_scan_props('besteffort'),
                          head=8000,save_to=save_to)

@_verb('job.lynis','lynis audit system --quick',timeout=_A(_vint(60,86400)))
def _bv_lynis(timeout):
    return _run_transient(['lynis','audit','system','--quick','--no-colors','--quiet'],timeout,prefix='locsecd-scan',props=_scan_props('idle'))

@_verb('job.rkhunter_check','rkhunter --check --skip-keypress --rwo')
def _bv_rkhunter_check():
    return _run_transient(['rkhunter','--check','--skip-keypress','--rwo'],3600,prefix='locsecd-scan',props=_scan_props('idle'),tail=200000)

@_verb('job.rkhunter_update','rkhunter --update (as part of a scan, or a definitions update)',context=_A(_vchoice('scan','defs')))
def _bv_rkhunter_update(context):
    if context=='scan': return _run_transient(['rkhunter','--update'],600,prefix='locsecd-scan',props=_scan_props('idle'))
    return _run_transient(['rkhunter','--update'],600,prefix='locsecd-priv')

@_verb('job.rkhunter_fix_conf','set WEB_CMD="" and MIRRORS_MODE=0 in /etc/rkhunter.conf (only those two lines)')
def _bv_rkhunter_fix_conf():
    return _run_transient(['sed','-i','-E',
        r's|^WEB_CMD[[:space:]]*=[[:space:]]*"?/bin/false"?[[:space:]]*$|WEB_CMD=""|;s|^MIRRORS_MODE[[:space:]]*=[[:space:]]*1[[:space:]]*$|MIRRORS_MODE=0|',
        '/etc/rkhunter.conf'],30,prefix='locsecd-priv')

@_verb('job.clamav_batch','scan one ClamAV batch list (clamdscan --fdpass, clamdscan --stream or clamscan); list and output are LocSec work files',
       remote=False,mode=_A(_vchoice('fdpass','stream','clamscan')),timeout=_A(_vint(60,3600)),
       batch_file=_A(_v_state_file(lambda:BROKER_WORK,r'clamav-batch-\d+-[0-9a-f]{8}-\d+\.txt')),
       out_file=_A(_v_state_file(lambda:BROKER_WORK,r'clamav-out-\d+-[0-9a-f]{8}-\d+\.txt')))
def _bv_clamav_batch(mode,timeout,batch_file,out_file):
    if mode=='fdpass': cmd=['clamdscan','--infected','--fdpass',f'--file-list={batch_file}']
    elif mode=='stream': cmd=['clamdscan','--infected','--stream',f'--file-list={batch_file}']
    else: cmd=['clamscan','--infected',f'--file-list={batch_file}']
    return _run_transient(cmd,timeout,prefix='locsecd-clamav',props=_scan_props('idle'),save_to=out_file)

@_verb('scan.clamscan_file','clamscan one file before quarantining it',remote=False,path=_A(_v_user_file))
def _bv_clamscan_file(path):
    return run(['clamscan','--infected','--no-summary',path],300)

@_verb('job.aide_init','aideinit --yes (first baseline)',remote=False,timeout=_A(_vint(300,259200)))
def _bv_aide_init(timeout):
    return _run_transient(['aideinit','--yes'],timeout,prefix='locsecd-aideinit')

@_verb('job.aide_reinit','aideinit --yes --force (replace the baseline)',remote=False,timeout=_A(_vint(300,259200)))
def _bv_aide_reinit(timeout):
    return _run_transient(['aideinit','--yes','--force'],timeout,prefix='locsecd-aide-reinit')

@_verb('job.aide_accept','/usr/lib/locsecd/aide-accept-pending (promote aide.db.new)',remote=False)
def _bv_aide_accept():
    return _run_transient(['/usr/lib/locsecd/aide-accept-pending'],120,prefix='locsecd-aide-accept')

@_verb('job.aide_dedup','remove aide.db.new when it is a plain file byte-identical to aide.db',remote=False)
def _bv_aide_dedup():
    return _run_transient(['/bin/sh','-c','[ -f "$1" ] && [ ! -L "$1" ] && cmp -s "$1" "$2" && rm -f -- "$1"','sh',
                           str(AIDE_DB_NEW),str(AIDE_DB)],60,prefix='locsecd-aide-dedup')

@_verb('job.ids','locsec-suricata-setup rules|interface|install',op=_A(_vchoice('rules','interface','install')))
def _bv_ids(op):
    t,props={'rules':(1200,['MemoryMax=1G']),'interface':(600,[]),'install':(1500,['MemoryMax=1G'])}[op]
    return _run_transient([_IDS_SETUP_HELPER,op],t,prefix='locsecd-ids',props=_scan_props('idle')+props)

@_verb('job.suricata_update','suricata-update (when the setup helper is not used)')
def _bv_suricata_update():
    return _run_transient(['suricata-update'],900,prefix='locsecd-ids',props=_scan_props('idle')+['MemoryMax=1G'])

@_verb('job.quarantine','locsec-quarantine quarantine PATH SIGNATURE (moves one regular file into the vault)',
       remote=False,path=_A(_v_user_file),signature=_A(_vtext(300)),timeout=_A(_vint(10,3600),600))
def _bv_quarantine(path,signature,timeout):
    return _run_transient([QUAR_HELPER,'quarantine',path,signature],timeout,prefix='locsecd-quarantine')

@_verb('job.quarantine_restore','locsec-quarantine restore ID [--overwrite] (back to the location recorded in the vault)',
       remote=False,qid=_A(_v_qid),overwrite=_A(_vb,False),timeout=_A(_vint(10,3600),600))
def _bv_quarantine_restore(qid,overwrite,timeout):
    return _run_transient([QUAR_HELPER,'restore',qid]+(['--overwrite'] if overwrite else []),timeout,prefix='locsecd-quarantine')

def _phase_opt(phased):
    return ['-o','APT::Get::Always-Include-Phased-Updates=true'] if phased else []

@_verb('job.apt_update','apt-get update')
def _bv_apt_update():
    return run_privileged(['apt-get','update'],300)

@_verb('job.apt_simulate','apt-get -s [--with-new-pkgs] upgrade (changes nothing)',
       with_new_pkgs=_A(_vb,False),phased=_A(_vb,False),timeout=_A(_vint(30,900),180))
def _bv_apt_simulate(with_new_pkgs,phased,timeout):
    return run_privileged(['apt-get','-s']+(['--with-new-pkgs'] if with_new_pkgs else [])+_phase_opt(phased)+['upgrade'],timeout)

@_verb('job.apt_upgrade','apt-get install -y --only-upgrade PACKAGES (only already-installed packages are upgraded; '
       'none is newly installed)',packages=_A(_v_pkg_names),phased=_A(_vb,False))
def _bv_apt_upgrade(packages,phased):
    return run_privileged(['apt-get','install','-y','--only-upgrade',
                           '-o','Dpkg::Options::=--force-confold','-o','Dpkg::Options::=--force-confdef','-o','Dpkg::Use-Pty=0']
                          +_phase_opt(phased)+packages,3600)

@_verb('job.apt_install','apt-get install -y --no-install-recommends PACKAGES, only packages LocSec depends on',
       packages=_A(_v_installable),timeout=_A(_vint(60,900),180))
def _bv_apt_install(packages,timeout):
    return run_privileged(['apt-get','install','-y','--no-install-recommends']+packages,timeout)

@_verb('job.freshclam','freshclam (its own messages say whether anything was downloaded)')
def _bv_freshclam():
    return run_privileged(['freshclam'],120)

@_verb('job.tshark','tshark on one capture, as a throwaway user with no network; the capture file is handed over open and passed on stdin',
       mode=_A(_vchoice('summary','endpoints')),capture=_A(_v_fd_read))
def _bv_tshark(mode,capture):
    if mode=='summary':
        return _run_transient(['tshark','-n','-r','-','-q','-z','io,phs'],120,prefix='locsecd-tshark',props=_TSHARK_PROPS,stdin_fd=capture)
    return _run_transient(['tshark','-n','-r','-','-T','fields','-e','ip.src','-e','ip.dst','-e','tcp.dstport','-e','udp.dstport','-E','separator=|'],120,
                          prefix='locsecd-tshark',props=_TSHARK_PROPS,stdin_fd=capture,tail=16<<20)

# ---- desktop, capture, power ----
@_verb('notify.desktop','show a desktop notification to UID, running as that user with nothing but its session bus',
       refused=lambda msg:False,uid=_A(_v_uid),kind=_A(_vtext(40)),title=_A(_vtext(200)),body=_A(_vtext(1000)))
def _bv_notify(uid,kind,title,body):
    title=title.strip()[:80]
    # Notification bodies accept a little markup; text from logs must not.
    body=body.strip()[:300].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    icon=_NOTIFY_ICONS.get(kind,'dialog-warning'); ms=_NOTIFY_SECONDS*1000
    if have('notify-send'):
        cmd=['notify-send','--app-name=LocSec','--icon='+icon,f'--expire-time={ms}','--urgency=normal','--',title,body]
    elif have('gdbus'):
        gv=lambda t:"'"+t.replace('\\','\\\\').replace("'","\\'")+"'"
        cmd=['gdbus','call','--session','--dest','org.freedesktop.Notifications','--object-path','/org/freedesktop/Notifications',
             '--method','org.freedesktop.Notifications.Notify','LocSec','0',icon,gv(title),gv(body),'[]','{}',str(ms)]
    else:
        return False
    props=[f'User={uid}','NoNewPrivileges=yes','CapabilityBoundingSet=','AmbientCapabilities=',
           'ProtectSystem=strict','PrivateTmp=yes','RestrictAddressFamilies=AF_UNIX','RestrictNamespaces=yes',
           'ProtectKernelTunables=yes','ProtectKernelModules=yes','ProtectKernelLogs=yes','ProtectControlGroups=yes',
           'SystemCallFilter=@system-service','UMask=0077',
           f'Environment=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{uid}/bus XDG_RUNTIME_DIR=/run/user/{uid}']
    rc,out=_run_transient(cmd,20,prefix='locsecd-notify',props=props)
    if rc!=0: log(f'desktop notification for uid {uid} failed: {out.strip()[-200:]}','WARN')
    return rc==0

@_verb('capture.start','tcpdump -i IFACE for SECONDS into a new, empty capture file the unprivileged half created and handed over open; '
       f'at most {MAX_CONCURRENT_CAPTURES} at once, never below {MIN_CAPTURE_FREE_BYTES>>20} MB free, stopped early below {HARD_MIN_CAPTURE_FREE_BYTES>>20} MB',
       refused=lambda msg:({'error':msg},400),iface=_A(_v_iface),seconds=_A(_vint(5,3600)),out=_A(_v_fd_write))
def _bv_capture_start(iface,seconds,out):
    """Start, limit and stop one capture. Returns (json_body, http_status)."""
    if not have('tcpdump'): return {'error':'tcpdump is not installed'},503
    st=os.fstat(out)
    if st.st_size!=0: return {'error':'the capture file is not new and empty'},400
    # The limits live here, with the privileged operation, so they hold whoever asks.
    def free():
        try: v=os.fstatvfs(keep); return v.f_bavail*v.f_frsize
        except OSError: return None
    keep=os.dup(out)
    started=False
    try:
        free_bytes=free()
        if free_bytes is not None and free_bytes<MIN_CAPTURE_FREE_BYTES:
            return {'error':f'only {free_bytes//(1024*1024)}MB free on the capture volume; refusing to start a capture below {MIN_CAPTURE_FREE_BYTES//(1024*1024)}MB free'},507
        with CAPTURE_LOCK:
            _reap_captures()
            if len(ACTIVE_CAPTURES)>=MAX_CONCURRENT_CAPTURES:
                return {'error':f'too many packet captures already running (max {MAX_CONCURRENT_CAPTURES}); wait for one to finish'},429
            # Debian's tcpdump drops to its own "tcpdump" user after opening the interface; it writes to
            # stdout, the descriptor it was handed, so it never needs to open anything itself.
            try:
                proc=subprocess.Popen(['tcpdump','-Z','root','-i',iface,'-nn','-s','0','-U','-w','-'],stdout=out,stderr=subprocess.DEVNULL,start_new_session=True)
            except OSError as e:
                log(f'packet capture could not start: {e}','ERROR')
                return {'error':'could not start tcpdump'},500
            proc.locsec_id=(st.st_dev,st.st_ino)
            ACTIVE_CAPTURES.append(proc)
            started=True
    finally:
        if not started: os.close(keep)
    def stop():
        try:
            # Poll instead of a single sleep so a capture that fills the disk mid-run
            # gets killed early rather than running the full duration regardless.
            deadline=time.time()+seconds
            while time.time()<deadline and proc.poll() is None:
                f=free()
                if f is not None and f<HARD_MIN_CAPTURE_FREE_BYTES:
                    log(f'packet capture (inode {st.st_ino}) stopped early: disk nearly full','WARN'); break
                time.sleep(2)
            _terminate_capture(proc)
            with CAPTURE_LOCK:
                if proc in ACTIVE_CAPTURES: ACTIVE_CAPTURES.remove(proc)
        finally:
            os.close(keep)
    threading.Thread(target=stop,daemon=True).start()
    log(f'packet capture started iface={iface} duration={seconds}s for pid {_client_pid()}')
    return {'ok':True,'id':[st.st_dev,st.st_ino]},200


# ---- reads that need root (4.0.11-91) ----
_SS_VIEWS={
 'listening':['ss','-Hlntup'],            # listening sockets with their processes
 'listening_table':['ss','-lntup'],       # the same, with a header, for display
 'connections':['ss','-Hntup'],           # established TCP/UDP with processes
 'ssh_sessions':['ss','-Hntp','state','established'],
}

@_verb('net.sockets','ss with process names (only root sees other users\' processes): '+', '.join(sorted(_SS_VIEWS)),
       view=_A(_vchoice(*sorted(_SS_VIEWS))),timeout=_A(_vint(5,120),15))
def _bv_net_sockets(view,timeout):
    # ss -p names a socket's program by reading /proc/PID/fd, which the kernel allows only with
    # CAP_SYS_PTRACE (other users' processes, and root processes with more capabilities than the
    # caller). The broker deliberately lacks it, so ss runs in a short transient unit instead.
    return _run_transient(_SS_VIEWS[view],timeout,prefix='locsecd-ss',props=['Nice=5'])

@_verb('ssh.effective_config','sshd -T (the effective SSH server configuration; reading it needs the host keys)')
def _bv_sshd_t():
    return run(['sshd','-T'],15)

_DPKG_PKG_RE=re.compile(r'[A-Za-z0-9.+_-]{1,100}(?::[a-z0-9]{1,30})?')
def _v_dpkg_pkg(x):
    s=str(x)
    if not _DPKG_PKG_RE.fullmatch(s) or s.startswith('-'): raise BrokerRefused('not a package name')
    return s

@_verb('pkg.verify','dpkg --verify PACKAGE (checksums of its files; some are root-only)',pkg=_A(_v_dpkg_pkg))
def _bv_dpkg_verify(pkg):
    return run(['dpkg','--verify',pkg],120)

@_verb('file.open','open one of a fixed list of root-only system logs and configuration files read-only, and hand over the descriptor',
       refused=lambda msg:None,returns_fd=True,path=_A(_v_priv_read_path))
def _bv_file_open(path):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    if not stat.S_ISREG(os.fstat(fd).st_mode):
        os.close(fd); return None
    return fd

@_verb('file.stat','size, time and type of one file from the same fixed list',refused=lambda msg:None,path=_A(_v_priv_read_path))
def _bv_file_stat(path):
    try: st=os.stat(path)
    except FileNotFoundError: return {'exists':False}
    return {'exists':True,'st_mode':st.st_mode,'st_size':st.st_size,'st_mtime':st.st_mtime,'st_ino':st.st_ino,'st_dev':st.st_dev}

# ---- packet captures: the unprivileged side owns the file, the broker owns tcpdump ----
@_verb('capture.active','the captures still recording, as [device, inode] of their files',refused=lambda msg:[])
def _bv_capture_active():
    with CAPTURE_LOCK:
        _reap_captures()
        return [list(getattr(p,'locsec_id',(0,0))) for p in ACTIVE_CAPTURES]

def _stop_captures(match):
    with CAPTURE_LOCK: procs=[p for p in ACTIVE_CAPTURES if match(p)]
    for p in procs: _terminate_capture(p)
    with CAPTURE_LOCK:
        for p in procs:
            if p in ACTIVE_CAPTURES: ACTIVE_CAPTURES.remove(p)
    return len(procs)

@_verb('capture.stop','stop the capture that writes to the file with this device and inode',refused=lambda msg:0,
       dev=_A(_vint(0,2**62)),ino=_A(_vint(0,2**62)))
def _bv_capture_stop(dev,ino):
    return _stop_captures(lambda p:getattr(p,'locsec_id',None)==(dev,ino))

@_verb('capture.stop_all','stop every running capture',refused=lambda msg:0)
def _bv_capture_stop_all():
    return _stop_captures(lambda p:True)

# ---- keeping the machine awake during a job: one inhibitor per client process ----
_INHIBITORS={}
_INHIBIT_LOCK=threading.Lock()

@_verb('power.inhibit_start','systemd-inhibit --mode=block for the calling process\'s maintenance job (at most 6 hours)',
       refused=lambda msg:False,what=_A(_vchoice('sleep','sleep:handle-lid-switch')),why=_A(_vtext(120)))
def _bv_inhibit_start(what,why):
    key=_client_pid()
    with _INHIBIT_LOCK:
        p=_INHIBITORS.get(key)
        if p is not None and p.poll() is None: return True
        _INHIBITORS[key]=subprocess.Popen(
            ['systemd-inhibit','--what='+what,'--who=LocSec','--why='+why,'--mode=block','sleep',str(_SleepInhibitor.MAX_SECONDS)],
            stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
    return True

def _end_inhibitor(p):
    if p is None or p.poll() is not None: return
    try: os.killpg(p.pid,signal.SIGTERM)
    except Exception: pass
    try: p.wait(timeout=2)
    except Exception:
        try: os.killpg(p.pid,signal.SIGKILL)
        except Exception: pass
        try: p.wait(timeout=2)
        except Exception: pass

@_verb('power.inhibit_stop','end the calling process\'s inhibitor',refused=lambda msg:False)
def _bv_inhibit_stop():
    with _INHIBIT_LOCK: p=_INHIBITORS.pop(_client_pid(),None)
    _end_inhibitor(p)
    return True

def _reap_inhibitors():
    """An inhibitor whose client process is gone (a crash, a kill) is ended."""
    with _INHIBIT_LOCK:
        gone=[k for k,p in _INHIBITORS.items() if p.poll() is not None or not os.path.exists(f'/proc/{k}')]
        procs=[_INHIBITORS.pop(k) for k in gone]
    for p in procs: _end_inhibitor(p)

# ---- the broker process ----
def _watch_client(conn,req,done):
    """Cancel REQ when its client hangs up (a restarted daemon, a Ctrl-C'd locsecctl): the units
    it started are stopped and no further unit starts for it."""
    while not done.is_set():
        try: r,_w,_x=select.select([conn],[],[],1.0)
        except (OSError,ValueError): return
        if not r: continue
        try: gone=conn.recv(1,socket.MSG_PEEK|socket.MSG_DONTWAIT)==b''
        except BlockingIOError: gone=False
        except OSError: gone=True
        if not gone: return
        if done.is_set(): return
        req.cancel.set()
        with INFLIGHT_LOCK: units=sorted(u for u in req.units if not u.startswith(_APT_UNIT_PREFIX))
        if units:
            log(f'client pid {req.pid} went away; stopping its job unit(s): {", ".join(units)}','WARN')
            try: subprocess.run(['systemctl','stop','--no-block','--']+units,timeout=10,
                                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
            except Exception: pass
        return

def _broker_conn(conn,web_uid,sem):
    fds=[]; out_fds=[]; pid=uid=None
    try:
        pid,uid,_gid=struct.unpack('3i',conn.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,struct.calcsize('3i')))
        if uid!=0 and uid!=web_uid:
            log(f'privilege broker: refused a connection from pid {pid} uid {uid}: not root or {WEB_USER}','WARN'); return
        conn.settimeout(30)
        req,fds=_sock_recv(conn,_BROKER_MAX_REQ)
        conn.settimeout(None)
        verb=req.get('verb') if isinstance(req,dict) else None
        args=req.get('args') if isinstance(req,dict) else None
        names=req.get('fd_args') if isinstance(req,dict) else None
        ent=_VERBS.get(verb) if isinstance(verb,str) else None
        why=''
        if not isinstance(args,dict) or not isinstance(names,list) or len(names)!=len(fds) \
                or not all(isinstance(n,str) for n in names) or set(names)&set(args):
            why='malformed request'
        elif ent is None: why=f'unknown verb {str(verb)[:60]!r}'
        elif not ent['remote']: why=f'{verb} is internal to the broker and cannot be requested'
        else:
            for k,(v,_d) in ent['spec'].items():
                isfd=getattr(v,'_fd',False)
                if isfd and k in args: why=f'{k} must be passed as a file descriptor'
                if not isfd and k in names: why=f'{k} must be a plain value, not a file descriptor'
            for k in names:
                if k not in ent['spec']: why=f'unexpected argument {k!r}'
        if why:
            # A verb name the client made up is quoted and escaped; a real one is shown as is.
            vname=verb if isinstance(verb,str) and re.fullmatch(r'[a-z0-9_.]{1,60}',verb) else _logsafe(verb,60)
            log(f'privilege broker: refused {vname} from pid {pid} uid {uid}: {why}','WARN'); _BROKER_REFUSALS['n']+=1
            _sock_send(conn,{'refused':f'refused: {why}'}); return
        call=dict(args); call.update({k:PassFD(f) for k,f in zip(names,fds)})
        r=_Req(pid,uid,bool(req.get('bind')))
        _BROKER_TLS.req=r
        done=threading.Event()
        threading.Thread(target=_watch_client,args=(conn,r,done),daemon=True,name='broker-watch').start()
        try:
            result=broker(verb,**call)
        finally:
            done.set(); _BROKER_TLS.req=None
        if ent.get('returns_fd'):
            if isinstance(result,int) and not isinstance(result,bool) and result>=0:
                out_fds=[int(result)]; _sock_send(conn,{'fd':True},out_fds)
            else: _sock_send(conn,{'refused':'refused: the file could not be opened'})
            return
        _sock_send(conn,{'result':result})
    except (EOFError,BrokenPipeError,ConnectionResetError,socket.timeout): pass
    except (ValueError,UnicodeDecodeError) as e:
        # Malformed or oversized input from a client: refused, and logged (rate-limited) as such.
        log(f'privilege broker: refused a malformed request from pid {pid} uid {uid}: {str(e)[:200]}','WARN'); _BROKER_REFUSALS['n']+=1
    except Exception as e:
        log(f'privilege broker: request failed: {e}','ERROR')
    finally:
        for f in fds+out_fds:
            try: os.close(f)
            except OSError: pass
        try: conn.close()
        except OSError: pass
        sem.release()

def _broker_serve():
    ids=_web_ids()
    if ids is None: log(f'the {WEB_USER} account does not exist; only root can use the broker','ERROR')
    web_uid=ids[0] if ids else None
    d=os.path.dirname(BROKER_SOCK)
    os.makedirs(d,mode=0o750,exist_ok=True)
    try: os.unlink(BROKER_SOCK)
    except FileNotFoundError: pass
    srv=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    old=os.umask(0o177)
    try: srv.bind(BROKER_SOCK)
    finally: os.umask(old)
    try:
        # Group locsec, mode 0660: root and the unprivileged half only. SO_PEERCRED is checked as well.
        if ids: os.chown(BROKER_SOCK,0,ids[1])
        os.chmod(BROKER_SOCK,0o660)
    except OSError as e: log(f'could not set the broker socket\'s group: {e}','ERROR')
    srv.listen(64); srv.settimeout(1.0)
    log(f'privilege broker listening on {BROKER_SOCK} ({len(_VERBS)} verbs, {sum(1 for v in _VERBS.values() if v["remote"])} callable from the unprivileged side)')
    _sd_notify('READY=1')
    sem=threading.BoundedSemaphore(64)
    try:
        while not STOP_EVENT.is_set():
            _reap_inhibitors()
            try: conn,_a=srv.accept()
            except socket.timeout: continue
            except OSError:
                if STOP_EVENT.is_set(): break
                time.sleep(0.2); continue
            if not sem.acquire(blocking=False):
                try:
                    pid,uid,_gid=struct.unpack('3i',conn.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,struct.calcsize('3i')))
                    who=f' from pid {pid} uid {uid}'
                except OSError: who=''
                log(f'privilege broker: 64 requests already running; refused one{who}','WARN'); conn.close(); continue
            threading.Thread(target=_broker_conn,args=(conn,web_uid,sem),daemon=True,name='broker-req').start()
    finally:
        srv.close()
        try: os.unlink(BROKER_SOCK)
        except OSError: pass

def _broker_shutdown(signum,frame):
    STOP_EVENT.set()
    for proc in list(ACTIVE_CAPTURES): _terminate_capture(proc,wait=False)

def _main_broker():
    if os.geteuid()!=0:
        print('locsecd --broker must run as root (it is started by locsecd-broker.service)',file=sys.stderr); return 1
    signal.signal(signal.SIGTERM,_broker_shutdown); signal.signal(signal.SIGINT,_broker_shutdown)
    signal.signal(signal.SIGHUP,signal.SIG_IGN)
    _prepare_dirs()
    for name,fn in (('orphan unit sweep',_sweep_orphan_units),('ClamAV work files',_clamav_sweep_stale)):
        try: fn()
        except Exception as e: log(f'startup {name}: {e}','ERROR')
    try:
        _broker_serve()
    finally:
        with INFLIGHT_LOCK: units=[u for u in INFLIGHT_PRIV_UNITS if not u.startswith(_APT_UNIT_PREFIX)]
        if units:
            try: subprocess.run(['systemctl','stop','--no-block','--']+units,timeout=10,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
            except Exception: pass
        _stop_captures(lambda p:True)
        with _INHIBIT_LOCK: procs=list(_INHIBITORS.values()); _INHIBITORS.clear()
        for p in procs: _end_inhibitor(p)
        log('privilege broker stopped')
    return 0

# ======================= PRIVILEGE BROKER (end) =========================

def _defs_status(tool,rc,out):
    """'updated', 'up-to-date', 'ok' (finished, no detail) or 'findings-or-error', from the tool's own words first:
    exit codes alone do not say whether anything was downloaded."""
    out=str(out or '')
    if tool=='rkhunter':
        if rc not in (0,2): return 'findings-or-error'
        return 'updated' if (rc==2 or '[ Updated ]' in out) else 'up-to-date'
    if rc not in (0,1): return 'findings-or-error'
    if re.search(r'\bupdated \(version|database updated|Database updated',out): return 'updated'
    if re.search(r'up-to-date|up to date',out,re.I) or rc==1: return 'up-to-date'
    return 'ok'

def update_definitions():
    # Keep the signature/definition databases for the scan tools themselves
    # fresh, independent of the (potentially infrequent) weekly scan
    # cycle. clamav-freshclam already runs as its own systemd service/timer
    # (enabled in postinst) so ClamAV signatures update on their own; this
    # covers the tools that only refresh when explicitly told to.
    results={}
    if have('rkhunter'):
        fix_rkhunter_web_cmd()
        # Same transient unit the rkhunter scan uses: --update writes under
        # /var/lib/rkhunter and re-reads /etc/rkhunter.conf, and inside this
        # daemon's sandbox it behaves differently from the scheduled scan.
        rc,out=broker('job.rkhunter_update',context='defs')
        if rc!=0 and 'Update failed' in out:
            # rkhunter's own summary never says *why* a file failed to fetch
            # (network/DNS/TLS/mirror problem); its log does.
            tail='\n'.join(_tail_lines('/var/log/rkhunter.log',60))
            out += '\n--- /var/log/rkhunter.log (tail) ---\n'+tail
        results['rkhunter']={'rc':rc,'output':out[-6000:]}
        log(f'rkhunter definitions update rc={rc}')
    if have('freshclam'):
        # Two problems here, both stemming from the same cause: clamav-freshclam.service
        # already runs continuously in the background (enabled by postinst) and holds
        # a lock on /var/log/clamav/freshclam.log. (1) freshclam drops from root to the
        # clamav user via initgroups()/setuid, which locsecd's own restricted capability
        # set can't grant -- same class of fix as aide_init()/package_update(), run it
        # in its own transient unit with the full capability set. (2) even with that
        # fixed, a manual run competes with the always-on service for the same log
        # lock ("Failed to lock the log file ... Resource temporarily unavailable").
        # Stop the service for the duration of the manual run, same as postinst does
        # during install, so there's only ever one freshclam touching that lock.
        broker('svc.fixed',op='freshclam.stop')
        _FRESHCLAM_STOPPED.set()
        try:
            rc,out=broker('job.freshclam')
        finally:
            broker('svc.fixed',op='freshclam.start')
            _FRESHCLAM_STOPPED.clear()
        # rc=1 from freshclam commonly just means "already up to date" -- not a real failure.
        results['clamav']={'rc':rc,'output':out[-4000:]}
        log(f'ClamAV signature update rc={rc}')
    # A report on the Reports page, like every other job. rkhunter --update: 0 nothing new, 2 updated.
    # freshclam: 0 updated, 1 already up to date.
    rows=[]
    if 'rkhunter' in results:
        x=results['rkhunter']; rows.append({'name':'rkhunter definitions','status':_defs_status('rkhunter',x['rc'],x['output']),'rc':x['rc'],'output':x['output']})
    if 'clamav' in results:
        x=results['clamav']; rows.append({'name':'ClamAV definitions','status':_defs_status('clamav',x['rc'],x['output']),'rc':x['rc'],'output':x['output']})
    if rows:
        try:
            report=REPORTS/f'defs-update-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'
            atomic_json(report,{'ts':time.time(),'results':rows}); results['report']=str(report)
        except Exception as e: log(f'could not save the definitions-update report: {e}','WARN')
    return results

# Set while update_definitions() has clamav-freshclam.service stopped; server() starts
# it again on the way out if a stop arrives in that minute.
_FRESHCLAM_STOPPED=threading.Event()

def _restore_freshclam():
    # update_definitions() stops clamav-freshclam.service for its own freshclam
    # run and starts it again in a finally -- which a SIGKILL, an OOM kill or a
    # stop during that minute skips, leaving signature updates off for good.
    if not have('systemctl'): return
    rc,st=run(['systemctl','is-enabled','clamav-freshclam.service'],10)
    if rc==0 and st.strip().startswith('enabled'):
        rc,_=run(['systemctl','is-active','--quiet','clamav-freshclam.service'],10)
        if rc!=0:
            broker('svc.fixed',op='freshclam.start')
            log('clamav-freshclam.service was stopped although enabled; started it again','WARN')

def missing_components():
    # What postinst tries to set up automatically but can silently skip if a
    # 60-300s network timeout was hit during install (slow mirror, congested
    # link, etc). Checked by dpkg status / binary presence, not by re-running
    # apt, so this is cheap enough to surface on every /api/status call.
    out={}
    rc,_=run(['dpkg-query','-W','-f=${Status}','clamav-daemon'],10)
    out['clamav-daemon']=rc!=0
    return out

# Packages the Overview table's Add button may install. Every entry is a real
# Depends: of LocSec, so there is deliberately no removal path: apt would take
# LocSec out with it.
_TOOL_INFO={
 'ufw':{'pkg':'ufw'},
 'aide':{'pkg':'aide'},
 'lynis':{'pkg':'lynis'},
 'debsecan':{'pkg':'debsecan'},
 'rkhunter':{'pkg':'rkhunter'},
 'clamscan':{'pkg':'clamav'},
 'clamdscan':{'pkg':'clamav-daemon'},
 'tshark':{'pkg':'tshark'},
 'tcpdump':{'pkg':'tcpdump'},
 'ss':{'pkg':'iproute2'},
 'nft':{'pkg':'nftables'},
 # A Depends: since 4.0.11-84, so apt installs it with LocSec; the Add button is the repair path. See tool_add().
 'suricata':{'pkg':'suricata'},
}

def tool_add(tool):
    tool=str(tool)
    info=_TOOL_INFO.get(tool)
    if not info: return {'ok':False,'error':'unknown component'}
    if not have('apt-get'): return {'ok':False,'error':'apt-get not found'}
    pkg=info['pkg']
    rc,_=run(['dpkg-query','-W',pkg],10)
    if rc==0:
        return {'ok':True,'output':f'{pkg} already installed'}
    rc,out=broker('job.apt_install',packages=[pkg],timeout=600 if pkg=='suricata' else 180)
    if rc==0 and pkg=='clamav-daemon':
        broker('svc.fixed',op='clamav.enable')
    if rc==0 and pkg=='suricata':
        # The rule downloader is a separate package on some releases; the engine works without it, but has no rules.
        rc2,_=broker('job.apt_install',packages=['suricata-update'])
        out+=f'\nsuricata-update: {"installed" if rc2==0 else "not available from apt on this system; run suricata-update by hand if you have it"}'
        if rc==0 and os.path.exists(_IDS_SETUP_HELPER):
            # Finish its setup (interface, rules, start) in the background: the rule download can take minutes,
            # and the Add button's request should not wait for it. The result goes to the LocSec log.
            def _ids_setup_job():
                try:
                    rc3,out3=broker('job.ids',op='install')
                    log(f'suricata setup after Add (rc={rc3}): {_ids_clean(" ".join((out3 or "").split()),600)}','INFO' if rc3==0 else 'WARN')
                except Exception as e: log(f'suricata setup after Add: {e}','ERROR')
            threading.Thread(target=_ids_setup_job,daemon=True,name='ids-setup-add').start()
            out+='\nSuricata: setting the network interface and downloading rules in the background (a few minutes).'
    incident('tool-add','manual',tool,'low','success' if rc==0 else 'failed',out[-1000:])
    return {'ok':rc==0,'output':out[-4000:]}

def install_missing():
    # On-demand retry of whatever postinst's network-bounded steps skipped,
    # without having to reinstall the whole .deb. Same timeouts/behavior as
    # postinst, just re-runnable from the dashboard.
    results=[]
    if not have('apt-get'):
        return {'ok':False,'results':['apt-get not found']}
    rc,_=run(['dpkg-query','-W','clamav-daemon'],10)
    if rc!=0:
        rc,out=broker('job.apt_install',packages=['clamav-daemon','clamav-freshclam'])
        results.append({'component':'clamav-daemon','rc':rc,'output':out[-4000:]})
        if rc==0:
            broker('svc.fixed',op='clamav.enable')
    else:
        results.append({'component':'clamav-daemon','rc':0,'output':'already installed'})
    for r in results:
        if r.get('rc')!=0:
            log(f'install-missing: {r["component"]} failed (rc={r.get("rc")}): {str(r.get("output",""))[-1000:]}','ERROR')
    log(f'install-missing run: {[(r["component"],r.get("rc")) for r in results]}')
    return {'ok':all(r['rc']==0 for r in results),'results':results}

# What the scheduler below is waiting for, for the Scans page. Written by background() once a
# minute; read-only everywhere else.
_SCHED={}

def schedule_status():
    if not _SCHED: return {'ready':False}
    now=time.time(); runs=_job_runs()
    def last_real(key,patterns):
        newest=runs.get(key,0.0)
        for pat in patterns:
            for f in REPORTS.glob(pat):
                try: newest=max(newest,f.stat().st_mtime)
                except OSError: pass
        return newest or None
    rows=[]; si=_SCHED['scan_interval']
    for key,_ in _SCHED['jobs_list']:
        pats=['cve-*.json'] if key=='cve' else [f'scan-{key}-*.json']
        rows.append({'key':key,'name':_JOB_LABEL.get(key,key),'every':si,'last':last_real(key,pats),
                     'next':_SCHED['jobs'][key]+si,'idle':True,'weekly':True})
    rows.append({'key':'clamav','name':'ClamAV virus scan','every':_SCHED['clamav_interval'],'last':last_real('clamav',['scan-clamav-*.json']),
                 'next':_SCHED['clamav']+_SCHED['clamav_interval'],'idle':True})
    if CFG.get('auto_update'):
        rows.append({'key':'update','name':'System updates','every':_SCHED['update_interval'],'last':runs.get('update') or None,
                     'next':_SCHED['update']+_SCHED['update_interval'],'idle':True})
    rows.append({'key':'feed','name':'Threat-intelligence lists','every':int(CFG['feed_interval']),'last':_SCHED['feed'] or None,
                 'next':(_SCHED['feed'] or now)+int(CFG['feed_interval']),'idle':False})
    rows.append({'key':'defs','name':'Virus/rootkit definitions','every':int(CFG.get('defs_update_interval',43200)),'last':_SCHED['defs'] or None,
                 'next':(_SCHED['defs'] or now)+int(CFG.get('defs_update_interval',43200)),'idle':True})
    try: load=float(Path('/proc/loadavg').read_text().split()[0])
    except Exception: load=None
    return {'ready':True,'now':now,'rows':rows,'load':load,'idle_load':float(CFG.get('idle_load',1.0)),
            'idle_seconds':int(CFG.get('idle_seconds',600)),'idle_since':_SCHED['idle_since'] or None,
            'weekly_today':_SCHED['started_today'],'weekly_per_day':_SCHED['per_day']}

def background():
    last_feed=last_defs=0; idle_since=0
    now0=time.time()
    scan_interval=int(CFG.get('scan_interval',604800))
    clamav_interval=int(CFG.get('clamav_scan_interval',86400))
    stagger=int(CFG.get('scan_stagger_seconds',3600))
    update_interval=int(CFG.get('update_interval',43200))
    # Jobs (AIDE/Lynis/Debsecan/rkhunter/ports+fw/CVE) each run once every
    # scan_interval (weekly by default), but seeded here so their first runs
    # land stagger seconds apart from each other instead of all firing in the
    # same tick -- so a week's worth of scanning is spread across the week.
    ALL_JOBS=SCAN_JOBS+[('cve',cve_scan)]
    last_scan_job={key: now0-scan_interval+i*stagger for i,(key,_) in enumerate(ALL_JOBS)}
    # The seeds above are in memory only, so every restart -- including each
    # package upgrade or reinstall -- made the first job (AIDE, hours on a big
    # home directory) due again at once, however recently it had run. The
    # reports on disk record when each job last ran; never schedule a job
    # earlier than scan_interval after its newest report.
    def _last_report(*patterns):
        newest=0.0
        for pat in patterns:
            for f in REPORTS.glob(pat):
                try: newest=max(newest,f.stat().st_mtime)
                except OSError: pass
        return newest
    runs=_job_runs()
    for key,_ in ALL_JOBS:
        seen=_last_report('cve-*.json') if key=='cve' else _last_report(f'scan-{key}-*.json')
        seen=max(seen,runs.get(key,0.0))
        if seen>last_scan_job[key]: last_scan_job[key]=seen
    # Hard per-calendar-day cap on how many weekly jobs are allowed to
    # *start*, independent of how many are due. Staggering (above) only
    # spaces out when jobs first become due -- it does nothing to stop a
    # pile-up of overdue jobs (host was busy/offline for a few days, several
    # weekly jobs are now all overdue at once) from firing back-to-back the
    # instant the machine finally goes idle. This counter is what actually
    # enforces "no more than scan_jobs_per_day weekly jobs start on the same
    # day" regardless of how the due-list looks. Resets whenever the local
    # calendar date changes; like everything else here it's in-memory and
    # reseeds on a service restart (same as last_scan_job above).
    scan_jobs_per_day=int(CFG.get('scan_jobs_per_day',1))
    jobs_started_today=0
    last_job_date=time.strftime('%Y-%m-%d', time.localtime(now0))
    # ClamAV runs on its own, faster, daily cadence -- seeded half a stagger
    # step off the weekly jobs' offsets so it doesn't land on the same tick.
    last_clamav=now0-clamav_interval+(stagger//2)
    last_clamav=max(last_clamav,_last_report('scan-clamav-*.json'),runs.get('clamav',0.0))
    # Package updates run twice a day (update_interval), independent of the
    # weekly scan cadence. The time is kept in job_runs.json (written by package_update on success), so it survives
    # restarts and reboots. With no record (first run, or an upgrade from a version that did not
    # keep one) the update is due as soon as the machine has been idle for idle_seconds, instead
    # of update_interval minus a stagger after every service start, which on a machine that is
    # restarted or switched off daily meant it never came due.
    last_update=max(now0-update_interval,runs.get('update',0.0))
    while not STOP_EVENT.is_set():
        try:
            now=time.time()
            # Manual runs (dashboard buttons, locsecctl, Build AIDE database) stamp
            # job_runs.json from other threads or processes; adopt a newer stamp so the
            # weekly timer restarts from it instead of only noticing after a restart.
            _runs=_job_runs()
            for _k in list(last_scan_job):
                if _runs.get(_k,0.0)>last_scan_job[_k]: last_scan_job[_k]=_runs[_k]
            if _runs.get('clamav',0.0)>last_clamav: last_clamav=_runs['clamav']
            if _runs.get('update',0.0)>last_update: last_update=_runs['update']
            _SCHED.update(jobs=dict(last_scan_job),jobs_list=ALL_JOBS,scan_interval=scan_interval,clamav=last_clamav,
                          clamav_interval=clamav_interval,update=last_update,update_interval=update_interval,
                          feed=last_feed,defs=last_defs,idle_since=idle_since,started_today=jobs_started_today,per_day=scan_jobs_per_day)
            # The monitors (logins, journal, fallback firewall, block pruning) run
            # on their own thread, monitor_loop(), so a scan that takes hours here
            # no longer stops brute-force blocking or port-scan detection.
            if idle_enough():
                idle_since = idle_since or now
            else:
                idle_since = 0
            # At most one idle-gated job per tick (4.0.11-101). now and idle_since are read once,
            # before any job: after an hours-long AIDE run they are stale, and the next job used
            # to start straight away on a machine the first job had just loaded.
            ran=False
            def quiet():
                return bool(idle_since) and not ran and now-idle_since>=int(CFG.get('idle_seconds',600))
            if now-last_defs>=int(CFG.get('defs_update_interval',43200)) and quiet():
                if JOB_LOCK.acquire(blocking=False,job='Virus/rootkit definition update',origin='scheduled'):
                    ran=True
                    try: update_definitions()
                    finally: JOB_LOCK.release(); last_defs=now
            if now-last_feed>=int(CFG['feed_interval']):
                # Only mark this cycle done when the job actually ran. Previously
                # last_feed was stamped even when JOB_LOCK was busy (another job
                # in progress), which could silently starve feed updates forever
                # under sustained contention instead of retrying next minute like
                # the scan jobs and package_update already do.
                if JOB_LOCK.acquire(blocking=False,job='Threat-feed update',origin='scheduled'):
                    fr=None
                    try: fr=feed_update()
                    finally: JOB_LOCK.release(); last_feed=now
                    try: ids_rules_update()
                    except Exception as e: log(f'suricata rule update: {e}','ERROR')
                    # The first run happens seconds after the service starts, which
                    # at boot is often before DNS works. A run where every source
                    # failed is retried in 15 minutes instead of waiting a full
                    # feed_interval (12 hours by default).
                    if isinstance(fr,dict) and fr.get('kept_previous'):
                        last_feed=now-int(CFG['feed_interval'])+900
            # Staggered weekly scans: due once every scan_interval per job, but
            # (as before) only actually started once the machine has been
            # idle for idle_seconds straight. A due-but-not-idle job just
            # waits -- it isn't skipped, it fires as soon as idle_seconds is
            # met. Only one job (whichever is most overdue) starts per tick,
            # so a full week's worth of scans still land roughly stagger
            # seconds apart rather than all firing back-to-back once idle.
            # On top of that spacing, scan_jobs_per_day hard-caps how many
            # weekly jobs can *start* on the same calendar day -- if several
            # are overdue at once (host was busy/offline for a while), only
            # the cap's worth start today; the rest wait for the following
            # day(s) instead of running back-to-back.
            today=time.strftime('%Y-%m-%d', time.localtime(now))
            if today!=last_job_date:
                last_job_date=today; jobs_started_today=0
            if quiet() and jobs_started_today<scan_jobs_per_day:
                due=[(key,fn) for key,fn in ALL_JOBS if now-last_scan_job[key]>=scan_interval]
                if due:
                    key,fn=min(due,key=lambda kv: last_scan_job[kv[0]])
                    if JOB_LOCK.acquire(blocking=False,job=_JOB_LABEL.get(key,key)+' scan',origin='scheduled'):
                        ran=True
                        # Stamped even if the job raises (a report write failing after a
                        # three-hour AIDE run), or it would start again next minute.
                        res=None
                        try:
                            res=cve_scan() if key=='cve' else run_scan_job(key,fn)
                        finally:
                            JOB_LOCK.release()
                            if isinstance(res,dict) and res.get('busy'):
                                # Another AIDE run held the database: try again in an hour.
                                last_scan_job[key]=now-scan_interval+3600
                            elif not (isinstance(res,dict) and res.get('interrupted')):
                                # Stamped even if the job raised, or it would start again next minute.
                                last_scan_job[key]=now; jobs_started_today+=1
            # ClamAV: same idle gate as the weekly scans above, but on its own
            # daily clamav_interval, separate from the once-a-week jobs.
            if quiet() and now-last_clamav>=clamav_interval:
                if JOB_LOCK.acquire(blocking=False,job='ClamAV scan',origin='scheduled'):
                    ran=True
                    res=None
                    try: res=run_scan_job(*CLAMAV_JOB)
                    finally:
                        JOB_LOCK.release()
                        if not (isinstance(res,dict) and res.get('interrupted')): last_clamav=now
            # Package updates: twice a day (update_interval), same idle gate
            # as the scans -- a due update waits for the machine to be idle
            # before running rather than being skipped.
            if CFG.get('auto_update') and quiet() and now-last_update>=update_interval:
                if JOB_LOCK.acquire(blocking=False,job='System update',origin='scheduled'):
                    ran=True
                    res=None
                    try: res=package_update()
                    finally:
                        JOB_LOCK.release()
                        # A run that failed (another package manager held the lock, apt could not
                        # list the updates) is tried again in an hour, not in update_interval.
                        last_update=now if (isinstance(res,dict) and res.get('ok')) else now-update_interval+3600
            # A job loads the machine: the next one waits for a fresh idle_seconds of quiet.
            if ran: idle_since=0
        except Exception as e: log(f'background loop: {e}','ERROR')
        STOP_EVENT.wait(60)

def monitor_loop():
    """Detection that must keep running whatever the scheduler is doing: failed
    logins, the journal (port scans, firewall drops), the fallback firewall, and
    hourly expiry of blocks and old state. Each step is isolated, so one failing
    (a full disk, a tool that hangs and times out) does not skip the others."""
    last_auth=0.0; last_prune=0.0
    def step(name,fn):
        try: fn()
        except Exception as e: log(f'{name}: {e}','ERROR')
    while not STOP_EVENT.is_set():
        now=time.time()
        if now-last_auth>=max(15,int(CFG.get('event_poll_seconds',60))):
            step('login monitor',login_monitor); last_auth=now
        step('fallback firewall',fallback_firewall_check)
        step('journal monitor',monitor_journal)
        step('intrusion signatures',ids_monitor)
        step('suricata interface',ids_auto_interface)
        step('clamd start after first signatures',clamd_after_first_signatures)
        if now-last_prune>=3600:
            step('block expiry',prune_expired_blocks); step('state cleanup',prune_runtime_state); step('incident cleanup',prune_incidents)
            last_prune=now
        STOP_EVENT.wait(60)

def main():
    # Read-only and harmless, so it needs no root: the complete list of what LocSec can do as root.
    if '--broker-verbs' in sys.argv: print(broker_catalogue()); return 0
    if ROLE=='broker': return _main_broker()
    if ROLE=='web':
        ids=_web_ids()
        if ids is None or os.geteuid()!=ids[0]:
            print(f'locsecd must be started as root (it then runs as {WEB_USER}), or as {WEB_USER}',file=sys.stderr); return 1
    elif os.geteuid()!=0: print('locsecd must run as root',file=sys.stderr); return 1
    _flush_early_log()
    # logrotate sends SIGHUP after rotating our log; log() reopens the file on
    # every write already so there's nothing to reopen, but SIGHUP's default
    # action is to terminate the process -- ignore it so a weekly log rotation
    # doesn't kill the daemon (dropping in-progress captures/scans/JOB_LOCK).
    signal.signal(signal.SIGHUP, signal.SIG_IGN)
    oneshot=any(a in sys.argv for a in ('--once-cve','--update','--feed-update','--aide-init','--aide-accept','--aide-reinitialize','--once-job'))
    if oneshot:
        def _oneshot_stop(signum,frame):
            # Ctrl-C or a kill during "locsecctl scan" and friends: stop the transient
            # unit doing the work now (it would otherwise run on until RuntimeMaxSec),
            # and unwind without writing a report or marking the job as run.
            STOP_EVENT.set(); _stop_inflight_priv_units()
            raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, _oneshot_stop); signal.signal(signal.SIGINT, _oneshot_stop)
        if any(a in sys.argv for a in ('--once-cve','--update','--aide-init','--aide-accept','--aide-reinitialize','--once-job')):
            SLEEP_INHIBIT.start('LocSec: command-line job')
        try: return _main_oneshot()
        except KeyboardInterrupt:
            print('locsecd: interrupted; the running job was stopped and nothing was recorded',file=sys.stderr); return 130
        finally: SLEEP_INHIBIT.stop(); _flush_notifications()
    signal.signal(signal.SIGTERM, _shutdown_handler)
    signal.signal(signal.SIGINT, _shutdown_handler)
    return _main_daemon()

def _flush_notifications():
    # A one-shot run has no notifier thread: a virus found by "locsecctl scan-clamav" was
    # queued and then lost with the process, and never reached the history either.
    batch=[]
    while True:
        try: batch.append(_NOTIFY_Q.get_nowait())
        except queue.Empty: break
    if batch:
        try: _deliver_notifications(batch)
        except Exception as e: log(f'desktop notifier: {e}','ERROR')

def _daemon_running():
    if not have('systemctl'): return False
    rc,_=run(['systemctl','is-active','--quiet','locsecd.service'],10)
    return rc==0

def _main_oneshot():
    token_value()
    # The one-shot modes (locsecctl scan, scan-*, cve, update, feed-update)
    # used to replay every persisted block first. That is the running daemon's
    # job, it cost one ufw/nft call per block before the requested work began,
    # and it pruned and rewrote blocks.json from a second process that shares
    # no lock with the daemon, so a block the daemon added meanwhile could be
    # dropped from the file.
    if '--once-cve' in sys.argv: print(json.dumps(cve_scan(),indent=2)); return 0
    if '--update' in sys.argv: print(json.dumps(package_update(),indent=2)); return 0
    if '--feed-update' in sys.argv:
        # A feed update rewrites blocks.json and the firewall; two processes doing that
        # at once lose each other's blocks (the lock is per process). The running
        # service updates the feeds itself; use the dashboard's button to ask now.
        if _daemon_running():
            print(json.dumps({'ok':False,'error':'locsecd.service is running and owns the block list. Use "Update feeds now" '
                              'on the Threat Intelligence page, or stop the service first (sudo systemctl stop locsecd).'},indent=2))
            return 1
        print(json.dumps(feed_update(),indent=2)); return 0
    if '--aide-init' in sys.argv: print(json.dumps(aide_init(),indent=2)); return 0
    if '--aide-accept' in sys.argv:
        print(json.dumps(aide_accept_pending(True),indent=2)); return 0
    if '--aide-reinitialize' in sys.argv:
        print(json.dumps(aide_reinitialize(True),indent=2)); return 0
    if '--once-job' in sys.argv:
        # Run a single scan job immediately by name, bypassing the weekly/daily
        # schedule -- e.g. `locsecctl scan-aide` when you only want AIDE's
        # result and don't want to wait through a full ClamAV pass first.
        i=sys.argv.index('--once-job')
        key=sys.argv[i+1] if i+1<len(sys.argv) else ''
        jobs=dict(SCAN_JOBS+[CLAMAV_JOB])
        if key not in jobs:
            print(json.dumps({'ok':False,'error':f'unknown job "{key}"; choices: {sorted(jobs)}'},indent=2)); return 1
        print(json.dumps(run_scan_job(key,jobs[key]),indent=2)); return 0
    return 2

def _main_daemon():
    global DAEMON_MODE
    DAEMON_MODE=True
    token_value()
    # restore_blocks() replays every persisted block through ufw/nft (one subprocess
    # call each, ~0.2-0.3s apiece); with a large blocks.json that can take minutes.
    # Run it in the background thread instead of blocking startup, so the
    # dashboard/API comes up immediately even with hundreds+ of persisted blocks.
    def background_with_restore():
        # A failure in one startup step (a full disk while restoring blocks) must
        # not kill the scheduler: server() would then exit and systemd restart
        # straight back into the same failure.
        def fallback_state():
            # A fallback chain left by the previous run (it stays on purpose while UFW is
            # off): adopt it, rather than "installing" it again with a new incident and a
            # desktop notification on every restart.
            if have('nft') and _fallback_present(): _FALLBACK['on']=True
        for name,fn in (('orphan unit sweep',_sweep_orphan_units),('freshclam restore',_restore_freshclam),
                        ('ClamAV cleanup',_clamav_sweep_stale),('fallback state',fallback_state)):
            try: fn()
            except Exception as e: log(f'startup {name}: {e}','ERROR')
        # Detection first: putting hundreds of blocks back can take minutes.
        mt=threading.Thread(target=monitor_loop,daemon=True,name='monitor'); mt.start(); _WATCHED_THREADS.append(mt)
        try: restore_blocks()
        except Exception as e: log(f'startup block restore: {e}','ERROR')
        background()
    t=threading.Thread(target=background_with_restore,daemon=True,name='background'); t.start()
    nt=threading.Thread(target=_notifier_loop,daemon=True,name='notifier'); nt.start(); _WATCHED_THREADS.append(nt)
    return server(t)
if __name__=='__main__': sys.exit(main())
