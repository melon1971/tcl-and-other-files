#!/usr/bin/python3
# LocSec -- local host security daemon and dashboard.
# Copyright (C) 2025-2026 LocSec Project
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Usage: locsec-gui          open the dashboard window (and the panel icon)
#        locsec-gui --tray   start in the panel only (used at login)
#
# One process per user. A second launch hands its request to the running one
# over a socket in $XDG_RUNTIME_DIR and exits, so there is never more than one
# LocSec icon in the panel. While the panel icon is available, closing the
# window hides it to the panel instead of quitting, and the window is kept off
# the taskbar: the panel icon is LocSec's only entry. Quit in the icon's menu
# closes the GUI; the locsecd service keeps running either way.
import os, sys, subprocess, shutil, time, ctypes.util
# Fixes a white/blank QtWebEngine window on some Mint/Cinnamon setups
# (hybrid graphics, VMs, some Wayland-via-XWayland sessions). Not touching
# the sandbox flag by default since this is a security tool; set
# QTWEBENGINE_DISABLE_SANDBOX=1 yourself before launching if disabling GPU
# alone isn't enough on your hardware.
os.environ.setdefault('QTWEBENGINE_CHROMIUM_FLAGS','--disable-gpu')
# The dashboard is served over HTTPS with a certificate made for this one machine
# (locsec-tls). It is self-signed, so the embedded browser is told to accept exactly
# one public key: the one in /etc/ssl/locsecd/dashboard.spki, written by root at install.
# Any other certificate on that port is still an error. A second check in Window
# (certificateError) compares the whole certificate for Qt builds that ignore the flag.
def _spki_pin_flag():
    import re
    try:
        pin=open('/etc/ssl/locsecd/dashboard.spki').read().strip()
    except OSError:
        return ''
    return '--ignore-certificate-errors-spki-list='+pin if re.fullmatch(r'[A-Za-z0-9+/]{43}=',pin) else ''
_pin_flag=_spki_pin_flag()
if _pin_flag:
    os.environ['QTWEBENGINE_CHROMIUM_FLAGS']=(os.environ.get('QTWEBENGINE_CHROMIUM_FLAGS','')+' '+_pin_flag).strip()
# XDG_CURRENT_DESKTOP is a colon-separated list ("ubuntu:GNOME", "Budgie:GNOME",
# "X-Cinnamon", "KDE", "XFCE", "COSMIC", "sway"). Budgie and other GNOME-based
# desktops list GNOME too, but only GNOME Shell needs the AppIndicator extension and
# has no taskbar, so test for the shell itself, not for the word.
def _desktops():
    return {d.strip().upper() for d in os.environ.get('XDG_CURRENT_DESKTOP','').split(':') if d.strip()}
_NOT_GNOME_SHELL={'BUDGIE','UNITY','PANTHEON','CINNAMON','X-CINNAMON','MATE','XFCE','LXQT','LXDE','KDE','COSMIC','DEEPIN','DDE','ENLIGHTENMENT','LXDE-PI'}
def _gnome_shell():
    d=_desktops()
    return 'GNOME' in d and not (d & _NOT_GNOME_SHELL)
# Keeping the window off the taskbar needs _NET_WM_STATE_SKIP_TASKBAR, which
# exists only for X11 windows; Wayland has no protocol for it, so on a Wayland
# desktop with a taskbar (KDE Plasma, LXQt, ...) the open window would add a
# second LocSec button. There, run through XWayland when it is available.
# GNOME has no taskbar and stays native. X11 sessions already use xcb. Qt 6.5+
# cannot load its xcb plugin without libxcb-cursor, so only switch when it is
# installed. Set QT_QPA_PLATFORM yourself to override.
if (os.environ.get('XDG_SESSION_TYPE')=='wayland' and os.environ.get('DISPLAY')
        and not os.environ.get('QT_QPA_PLATFORM')
        and not _gnome_shell()
        and ctypes.util.find_library('xcb-cursor')):
    os.environ['QT_QPA_PLATFORM']='xcb'
from pathlib import Path
TOKEN=Path('/var/lib/locsecd/api.token')
URL='https://127.0.0.1:8765/dashboard'
CERT=Path('/etc/ssl/locsecd/dashboard.crt')
UNIT='locsecd.service'
ICON_DIR=Path('/usr/share/icons/hicolor')
ICON_SIZES=(16,22,24,32,48,64,128,256)
AUTOSTART_NAME='locsec-tray.desktop'
SYSTEM_AUTOSTART=Path('/etc/xdg/autostart')/AUTOSTART_NAME
TRAY_MODE='--tray' in sys.argv[1:]

def _config_home():
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home()/'.config')

def _socket_path():
    rt=os.environ.get('XDG_RUNTIME_DIR')
    if rt and os.path.isdir(rt):
        return os.path.join(rt,'locsec-gui.sock')
    return os.path.join(_config_home(),'locsec','gui.sock')

def _pinned_context():
    """A client TLS context that believes exactly one certificate: the public one the
    installer made for this machine. Nothing else is trusted, not even the system store,
    so whatever else is listening on the port is refused before the token is sent."""
    import ssl
    if not CERT.is_file():
        raise RuntimeError(f'the dashboard certificate {CERT} is missing; run: sudo locsecctl tls-renew && sudo systemctl restart locsecd')
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version=ssl.TLSVersion.TLSv1_2
    ctx.load_verify_locations(cafile=str(CERT))
    return ctx

def _cert_fingerprint():
    import ssl, hashlib
    try:
        der=ssl.PEM_cert_to_DER_cert(CERT.read_text())
    except (OSError, ValueError):
        return ''
    h=hashlib.sha256(der).hexdigest().upper()
    return ':'.join(h[i:i+2] for i in range(0,len(h),2))

def _login_code(token):
    """Trade the API token for a single-use, 60-second login code. Only the code
    goes in a URL; the token never does, and the page gets an expiring session.
    The connection is verified against the pinned certificate first: urllib sends
    the request, and with it the token, only after the handshake has succeeded."""
    import json, ssl, urllib.request, urllib.error
    ctx=_pinned_context()
    req=urllib.request.Request(URL.rsplit('/',1)[0]+'/api/login-code',data=b'{}',method='POST',
                               headers={'X-LocSec-Token':token,'Content-Type':'application/json'})
    try:
        # Short: this runs on the GUI thread, and the service answers locally.
        with urllib.request.urlopen(req,timeout=5,context=ctx) as r: return json.load(r).get('code')
    except urllib.error.URLError as e:
        if isinstance(getattr(e,'reason',None),ssl.SSLError):
            raise RuntimeError('whatever is answering on 127.0.0.1:8765 is not the LocSec service: its certificate '
                               f'does not match {CERT}. The token was NOT sent. Check: systemctl status locsecd; '
                               'sudo ss -ltnp | grep 8765') from None
        raise

def _browser_fallback(reason):
    # PyQt6 / QtWebEngine are package dependencies for the native GUI. If a
    # dependency is nevertheless missing (for example an incomplete manual
    # dpkg install), retain the browser fallback as a defensive recovery path.
    # Normal installations use the native Qt GUI and persistent tray icon.
    #
    # Without them, open the dashboard in
    # the default browser. The long-lived API token must not appear in a URL a
    # browser would record in its history, so it is sent once in a header to
    # mint a single-use, 60-second login code, and only that code goes in the
    # URL (the daemon swaps it for the session cookie and redirects).
    def tell(msg, error=True):
        print('LocSec: '+msg, file=sys.stderr)
        for cmd in (['zenity','--error' if error else '--info','--title=LocSec','--text='+msg],
                    ['kdialog','--error' if error else '--msgbox',msg,'--title','LocSec'],
                    ['notify-send','LocSec',msg]):
            if shutil.which(cmd[0]):
                try: subprocess.run(cmd,timeout=300,check=False)
                except Exception: pass
                return
    try:
        token=TOKEN.read_text().strip() if os.access(str(TOKEN),os.R_OK) else ''
    except OSError:
        token=''
    if not token and shutil.which('pkexec'):
        try:
            p=subprocess.run(['pkexec','/bin/cat',str(TOKEN)],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120,check=False)
            if p.returncode==0: token=p.stdout.strip()
            elif p.returncode==127 and 'agent' in (p.stderr or '').lower():
                tell('No polkit authentication agent is running, and the desktop window is unavailable ('+reason+'). '
                     'Install a polkit agent (for example: sudo apt install mate-polkit) and log in again, '
                     'or install python3-pyqt6.qtwebengine if your release provides it.'); return 1
        except subprocess.TimeoutExpired:
            pass
    if not token:
        tell('Could not read the dashboard token. Check that locsecd.service is running: systemctl status locsecd'); return 1
    try:
        code=_login_code(token)
    except Exception as e:
        tell(f'Could not reach the LocSec service at {URL} ({e}). Check: systemctl status locsecd'); return 1
    finally:
        token=None
    if not code:
        tell('The LocSec service refused a login code; try again in a minute.'); return 1
    target=URL+'?code='+code
    # A normal browser does not know this machine's certificate, so it will warn once. Say
    # why, and give the fingerprint to compare, without blocking the launch on a dialog.
    fp=_cert_fingerprint()
    note=('Your browser will warn that the connection is not private: LocSec uses a certificate made for this computer. '
          'Compare the SHA-256 fingerprint in the warning with: '+(fp or 'locsecctl tls-fingerprint')+'. If it matches, continue.')
    print('LocSec: '+note, file=sys.stderr)
    if shutil.which('notify-send'):
        try: subprocess.Popen(['notify-send','-t','15000','LocSec',note],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
        except OSError: pass
    for opener in ('xdg-open','gio','sensible-browser','x-www-browser'):
        if shutil.which(opener):
            cmd=[opener,'open',target] if opener=='gio' else [opener,target]
            try:
                subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
                return 0
            except OSError:
                continue
    tell('No browser launcher found. Install xdg-utils (sudo apt install xdg-utils) and open LocSec again.'); return 1

try:
    from PyQt6.QtCore import QUrl, QTimer, QProcess
    from PyQt6.QtGui import QIcon, QAction
    from PyQt6.QtWidgets import QApplication, QMainWindow, QMessageBox, QInputDialog, QLineEdit, QSystemTrayIcon, QMenu
    from PyQt6.QtNetwork import QLocalServer, QLocalSocket
except ImportError as e:
    # The login-time panel icon must never open a browser or a dialog.
    if TRAY_MODE:
        print(f'LocSec: panel icon unavailable, PyQt6 is not installed ({e.name or e})', file=sys.stderr); sys.exit(0)
    sys.exit(_browser_fallback(f'PyQt6 is not installed: {e.name or e}'))
# QtWebEngine has to be imported before the QApplication exists. Without it
# the panel icon still works and "Open" uses the browser fallback.
WEBENGINE_ERR=''
try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    HAVE_WEBENGINE=True
except ImportError as e:
    HAVE_WEBENGINE=False
    WEBENGINE_ERR=f'PyQt6 WebEngine is not installed: {e.name or e}'

def _instance_lock():
    """Hold this user's single-instance lock for the life of the process, or None if
    another locsec-gui has it. Without it, two launches at the same moment (the
    login-time panel icon and a click on the menu entry) could both find no running
    instance, both start, and the panel showed two LocSec icons."""
    import fcntl
    path=_socket_path()+'.lock'
    try:
        os.makedirs(os.path.dirname(path),mode=0o700,exist_ok=True)
        fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_CLOEXEC,0o600)
    except OSError:
        return -1          # cannot lock at all: behave as before rather than refuse to start
    try:
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        return fd
    except OSError:
        os.close(fd); return None

def _hand_off_to_running_instance():
    # True when another locsec-gui of this user took the request.
    s=QLocalSocket()
    s.connectToServer(_socket_path())
    if not s.waitForConnected(1500):
        return False
    s.write(b'tray\n' if TRAY_MODE else b'show\n'); s.flush(); s.waitForBytesWritten(1500)
    s.disconnectFromServer()
    return True

def _make_icon(name):
    icon=QIcon()
    for size in ICON_SIZES:
        p=ICON_DIR/f'{size}x{size}'/'apps'/f'{name}.png'
        if p.is_file(): icon.addFile(str(p))
    svg=ICON_DIR/'scalable'/'apps'/f'{name}.svg'
    if svg.is_file(): icon.addFile(str(svg))   # used when Qt's SVG plugin is present
    if icon.isNull(): icon=QIcon.fromTheme('security-high')
    return icon

def _skip_taskbar_x11(wid):
    # Ask the window manager (EWMH) to keep this window off the taskbar and the
    # pager. Sent as a client message to the root window, the documented way to
    # change _NET_WM_STATE of a mapped window. Best-effort; X11 only.
    import ctypes
    lib=ctypes.util.find_library('X11')
    if not lib: return
    x=ctypes.cdll.LoadLibrary(lib)
    x.XOpenDisplay.restype=ctypes.c_void_p; x.XOpenDisplay.argtypes=[ctypes.c_char_p]
    x.XInternAtom.restype=ctypes.c_ulong; x.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int]
    x.XDefaultRootWindow.restype=ctypes.c_ulong; x.XDefaultRootWindow.argtypes=[ctypes.c_void_p]
    x.XSendEvent.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_long,ctypes.c_void_p]
    x.XFlush.argtypes=[ctypes.c_void_p]; x.XCloseDisplay.argtypes=[ctypes.c_void_p]
    class ClientMessage(ctypes.Structure):
        _fields_=[('type',ctypes.c_int),('serial',ctypes.c_ulong),('send_event',ctypes.c_int),
                  ('display',ctypes.c_void_p),('window',ctypes.c_ulong),('message_type',ctypes.c_ulong),
                  ('format',ctypes.c_int),('l',ctypes.c_long*5)]
    class XEvent(ctypes.Union):
        _fields_=[('xclient',ClientMessage),('pad',ctypes.c_long*24)]
    dpy=x.XOpenDisplay(None)
    if not dpy: return
    try:
        ev=XEvent()
        ev.xclient.type=33                      # ClientMessage
        ev.xclient.send_event=1
        ev.xclient.window=wid
        ev.xclient.message_type=x.XInternAtom(dpy,b'_NET_WM_STATE',0)
        ev.xclient.format=32
        ev.xclient.l[0]=1                       # _NET_WM_STATE_ADD
        ev.xclient.l[1]=x.XInternAtom(dpy,b'_NET_WM_STATE_SKIP_TASKBAR',0)
        ev.xclient.l[2]=x.XInternAtom(dpy,b'_NET_WM_STATE_SKIP_PAGER',0)
        ev.xclient.l[3]=1                       # source: normal application
        mask=(1<<19)|(1<<20)                    # SubstructureNotify | SubstructureRedirect
        x.XSendEvent(dpy,x.XDefaultRootWindow(dpy),0,mask,ctypes.byref(ev))
        x.XFlush(dpy)
    finally:
        x.XCloseDisplay(dpy)

if HAVE_WEBENGINE:
  class Window(QMainWindow):
    def __init__(self, controller):
        super().__init__(); self.setWindowTitle('LocSec Security Center'); self.resize(1280,800)
        self.controller=controller; self.loaded=False; self.loading=False
        self.web=QWebEngineView(); self.setCentralWidget(self.web)
        # The dashboard sets its title to "session expired" when the service no
        # longer accepts its session (8 h idle, 3 days at most); sign in again.
        self.web.titleChanged.connect(self._title_changed)
        # Accept the dashboard's certificate only if it is byte-for-byte the pinned one.
        try: self.web.page().certificateError.connect(self._cert_error)
        except AttributeError: pass
        # Print on a "What to do" sheet calls window.print(), which QtWebEngine ignores
        # unless the application handles it. Save a PDF and open it in the PDF viewer,
        # whose own Print button reaches every printer the desktop knows.
        sig=getattr(self.web,'printRequested',None) or getattr(self.web.page(),'printRequested',None)
        if sig is not None: sig.connect(self._print_to_pdf)
        try: self.web.page().pdfPrintingFinished.connect(self._pdf_done)
        except AttributeError: pass
    def _print_to_pdf(self):
        d=Path.home()/'Documents'
        if not d.is_dir(): d=Path.home()
        self.web.page().printToPdf(str(d/time.strftime('LocSec-%Y%m%d-%H%M%S.pdf')))
    def _pdf_done(self, path, ok):
        if ok:
            from PyQt6.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        else:
            QMessageBox.warning(self,'LocSec','Could not save the PDF to '+str(path))
    def showEvent(self, event):
        super().showEvent(event)
        # The window manager drops _NET_WM_STATE whenever the window is
        # hidden (withdrawn), so this is re-applied on every show.
        if self.controller.tray_active() and QApplication.platformName()=='xcb':
            QTimer.singleShot(0,self._apply_skip_taskbar)
        # First show (and any later show after a failed or cancelled login):
        # a panel icon started at login never asks for a password until the
        # dashboard is actually opened.
        if not self.loaded and not self.loading:
            self.loading=True
            QTimer.singleShot(300,self.load)
    def _title_changed(self, title):
        if 'session expired' in (title or '').lower() and not self.loading:
            self.loaded=False
            if self.isVisible():
                self.loading=True
                QTimer.singleShot(0,self.load)
    def _apply_skip_taskbar(self):
        try: _skip_taskbar_x11(int(self.winId()))
        except Exception: pass
    def closeEvent(self, event):
        if self.controller.tray_active():
            event.ignore(); self.hide(); self.controller.hidden_to_tray()
        else:
            event.accept(); QApplication.quit()
    # ---- dashboard token ---------------------------------------------------
    # The token is root-only, so reading it needs a privilege prompt (pkexec,
    # or a sudo password when the session has no polkit agent). That prompt
    # can take as long as the person takes to answer -- or never appear at all
    # when the agent is not up yet -- so it must NOT run on the thread that
    # paints this window and serves the panel icon: blocking there left the
    # window blank and the icon's "Service: checking..." line frozen. Both
    # helpers below use QProcess and return to the event loop at once; the
    # result arrives through a callback.
    PLACEHOLDER=('<html><body style="margin:0;background:#12151d;color:#e6e9f2;font:15px sans-serif;'
                 'display:flex;align-items:center;justify-content:center;height:100vh">'
                 '<div style="text-align:center;max-width:34em;padding:1em">'
                 '<div style="font-size:20px;margin-bottom:.7em">LocSec Security Center</div>@@MSG@@</div></body></html>')
    def _placeholder(self, msg):
        self.web.setHtml(self.PLACEHOLDER.replace('@@MSG@@',msg))
    def _run_token_proc(self, argv, stdin_text, timeout_s, cb):
        # cb(returncode, stdout, stderr); returncode is -1 if the program could
        # not start and -2 if it was killed after timeout_s seconds.
        p=QProcess(self); timer=QTimer(self); timer.setSingleShot(True); done=[False]
        def finish(rc, out, err):
            if done[0]: return
            done[0]=True; timer.stop(); timer.deleteLater(); p.deleteLater()
            cb(rc,out,err)
        def on_finished(code, _status):
            finish(code,bytes(p.readAllStandardOutput()).decode(errors='replace'),
                   bytes(p.readAllStandardError()).decode(errors='replace'))
        def on_error(_e):
            if p.state()==QProcess.ProcessState.NotRunning: finish(-1,'','could not start '+argv[0])
        def on_timeout():
            p.kill(); finish(-2,'','timed out')
        p.finished.connect(on_finished); p.errorOccurred.connect(on_error); timer.timeout.connect(on_timeout)
        timer.start(int(timeout_s*1000))
        p.start(argv[0],argv[1:])
        if stdin_text is not None:
            p.write(stdin_text.encode()); p.closeWriteChannel()
    def _read_token_async(self, done):
        # pkexec first: GNOME Shell, KDE Plasma, Cinnamon, MATE, LXQt and most
        # Xfce installs run a polkit authentication agent that shows the
        # password dialog. pkexec exits 127 with "No authentication agent
        # found" when the session has none (bare Xfce, i3, other window
        # managers); 126 means the user dismissed the dialog, which is a
        # "no" and must not trigger a second prompt.
        if not shutil.which('pkexec'):
            self._read_token_sudo(done); return
        def after(rc, out, err):
            if rc==0: done(out.strip()); return
            if rc==127 and 'agent' in (err or '').lower(): self._read_token_sudo(done); return
            done('')
        self._run_token_proc(['pkexec','/bin/cat',str(TOKEN)],None,120,after)
    def _read_token_sudo(self, done):
        # No polkit agent: ask for the sudo password in a Qt dialog and pass it
        # to sudo on stdin only (never on the command line or in the
        # environment). -k ignores cached credentials, -S reads stdin, and
        # -p '' suppresses sudo's own prompt text. The dialog is modal but
        # runs its own event loop, so the window and the panel icon stay live.
        if not shutil.which('sudo'):
            done(''); return
        pw,ok=QInputDialog.getText(self,'LocSec','No polkit authentication agent is running in this session.\nEnter your password (sudo) to open the dashboard:',QLineEdit.EchoMode.Password)
        if not ok or not pw:
            done(''); return
        self._run_token_proc(['sudo','-k','-S','-p','','/bin/cat',str(TOKEN)],pw+'\n',30,
                             lambda rc,out,err: done(out.strip() if rc==0 else ''))
        pw=None
    def load(self):
        try:
            # The token's parent dir is 0700 locsec:locsec, so another
            # user's stat() can raise PermissionError here instead of just
            # returning False. Treat "can't tell" as "assume it exists and
            # let the pkexec fallback below sort out access."
            try:
                token_missing = not TOKEN.exists()
            except PermissionError:
                token_missing = False
            if token_missing:
                self.loading=False
                self._placeholder('The locsecd service is not running or the API token is missing.<br><br>Start it with <b>sudo systemctl start locsecd</b>, then open LocSec again.')
                QMessageBox.critical(self,'LocSec','The locsecd service is not running or the API token is missing.'); return
            # Ask whether *this* user can actually read the file rather than
            # inspecting its permission bits: the token is mode 0600, so a bit
            # test always said "no" and forced a pkexec prompt even when the
            # GUI was already running as root.
            try:
                readable_directly = os.access(str(TOKEN), os.R_OK)
            except OSError:
                readable_directly = False
            if readable_directly:
                self._open_with_token(TOKEN.read_text().strip()); return
            self._placeholder('Waiting for your password&hellip;<br><br><span style="color:#9aa3b8;font-size:13px">A password prompt should appear. '
                              'If it does not, no polkit agent is running: install one for your desktop '
                              '(for example <b>sudo apt install mate-polkit</b>) and log in again.</span>')
            self._read_token_async(self._open_with_token)
        except Exception as e:
            self._load_failed(str(e))
    def _open_with_token(self, token):
        try:
            if not token:
                raise RuntimeError('could not obtain the local dashboard token (check that locsecd.service is running, and that pkexec or sudo is available to your account)')
            try:
                code=_login_code(token)
            finally:
                token=None
            if not code:
                raise RuntimeError('the LocSec service refused a login code; try again in a minute')
            self.web.setUrl(QUrl(URL+'?code='+code))
            self.loaded=True; self.loading=False
        except Exception as e:
            self._load_failed(str(e))
    def _load_failed(self, msg):
        self.loading=False
        self._placeholder('Could not open the dashboard.<br><br>Close this window and open LocSec again to retry.')
        QMessageBox.critical(self,'LocSec',f'Unable to authenticate the dashboard: {msg}')
    # ---- reopening ---------------------------------------------------------
    # Closing the window only hides it, so a long-lived panel icon would
    # otherwise re-show whatever page it last had -- including one that was
    # loaded before a locsecd restart or upgrade. Reload on every re-show; if
    # the reload comes back without the dashboard (expired session cookie,
    # service restarted, unreachable), start a full token login again.
    def _cert_error(self, error):
        try:
            import ssl
            pinned=ssl.PEM_cert_to_DER_cert(CERT.read_text())
            chain=error.certificateChain()
            if (chain and bytes(chain[0].toDer())==pinned and error.isOverridable()
                    and error.url().host() in ('127.0.0.1','localhost','::1','[::1]')):
                error.acceptCertificate(); return
        except Exception:
            pass
        error.rejectCertificate()
    def refresh(self):
        if self.loading or not self.loaded: return
        page=self.web.page()
        page.loadFinished.connect(self._after_reload)
        self.web.reload()
    def _after_reload(self, ok):
        try: self.web.page().loadFinished.disconnect(self._after_reload)
        except (TypeError, RuntimeError): pass
        if not ok:
            self._full_reload(); return
        self.web.page().runJavaScript("!!document.getElementById('pagebody')",
                                      lambda good: None if good else self._full_reload())
    def _full_reload(self):
        if self.loading: return
        self.loaded=False; self.loading=True
        QTimer.singleShot(0,self.load)

class Controller:
    TRAY_WAIT_MS=90000   # how long a login-time start waits for the panel to appear
    def __init__(self, app):
        self.app=app; self.window=None; self.tray=None; self.state=None; self.proc=None
        self.told_hidden=False; self.waited=0; self.gnome_tried=False; self.proc_started=0.0
        self.icon_ok=_make_icon('locsec-tray'); self.icon_alert=_make_icon('locsec-tray-alert')
        self.server=QLocalServer()
        self.server.setSocketOptions(QLocalServer.SocketOption.UserAccessOption)
        path=_socket_path(); os.makedirs(os.path.dirname(path),mode=0o700,exist_ok=True)
        QLocalServer.removeServer(path)   # stale socket left by a crashed instance
        if not self.server.listen(path):
            print(f'LocSec: cannot listen on {path}: {self.server.errorString()}', file=sys.stderr)
        self.server.newConnection.connect(self._on_connection)
        self.poll=QTimer(); self.poll.timeout.connect(self._poll_status); self.poll.start(10000)
        self.wait_timer=QTimer(); self.wait_timer.timeout.connect(self._try_tray)
    def tray_active(self):
        return self.tray is not None and self.tray.isVisible()
    def start(self):
        if not self._try_tray() and TRAY_MODE:
            # At login the panel can come up after the autostart apps.
            self.wait_timer.start(2000)
        # Without a panel icon this is the plain window it always was:
        # closing it quits.
        if not TRAY_MODE:
            self.show_window()
        self._poll_status()
    # ---- panel icon -------------------------------------------------------
    def _try_tray(self):
        if self.tray is not None:
            return True
        if not QSystemTrayIcon.isSystemTrayAvailable():
            self._enable_gnome_appindicator()
            if self.wait_timer.isActive():
                self.waited+=self.wait_timer.interval()
                if self.waited>=self.TRAY_WAIT_MS:
                    self.wait_timer.stop()
                    self._no_tray_hint()
                    if self.window is None or not self.window.isVisible():
                        self.app.quit()
            return False
        self.wait_timer.stop()
        self._build_tray()
        return True
    def _build_tray(self):
        self.tray=QSystemTrayIcon(self.icon_ok)
        self.tray.setToolTip('LocSec Security Center')
        menu=QMenu()
        self.act_open=QAction('Open LocSec Security Center',menu); self.act_open.triggered.connect(self.show_window)
        self.act_status=QAction('Service: checking...',menu); self.act_status.setEnabled(False)
        self.act_login=QAction('Start at login',menu); self.act_login.setCheckable(True)
        self.act_login.setChecked(self._autostart_enabled()); self.act_login.toggled.connect(self._set_autostart)
        act_quit=QAction('Quit panel icon (service keeps running)',menu); act_quit.triggered.connect(self.app.quit)
        menu.addAction(self.act_open); menu.addAction(self.act_status); menu.addSeparator()
        menu.addAction(self.act_login); menu.addSeparator(); menu.addAction(act_quit)
        menu.aboutToShow.connect(self._refresh_login_check)
        self.menu=menu
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_activated)
        self.tray.show()
        if self.state: self._apply_state(self.state, notify=False)
        # A window opened before the panel appeared joins it now.
        if self.window is not None and self.window.isVisible() and QApplication.platformName()=='xcb':
            self.window._apply_skip_taskbar()
    def _refresh_login_check(self):
        self.act_login.blockSignals(True)
        self.act_login.setChecked(self._autostart_enabled())
        self.act_login.blockSignals(False)
    def _on_activated(self, reason):
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            if self.window is not None and self.window.isVisible() and self.window.isActiveWindow():
                self.window.hide()
            else:
                self.show_window()
    def hidden_to_tray(self):
        if not self.told_hidden and self.tray_active():
            self.told_hidden=True
            self.tray.showMessage('LocSec','LocSec is still running in the panel. Use Quit in its menu to close it.',
                                  self.icon_ok,4000)
    def _enable_gnome_appindicator(self):
        # GNOME Shell shows panel icons only through the AppIndicator extension.
        # If it is installed but switched off, switch it on for this user (a
        # per-user setting, applied live). Never installs anything.
        if self.gnome_tried: return
        self.gnome_tried=True
        if not _gnome_shell() or not shutil.which('gnome-extensions'):
            return
        try:
            installed=subprocess.run(['gnome-extensions','list'],text=True,capture_output=True,timeout=10).stdout.split()
            enabled=subprocess.run(['gnome-extensions','list','--enabled'],text=True,capture_output=True,timeout=10).stdout.split()
        except Exception:
            return
        for uuid in ('appindicatorsupport@rgcjonas.gmail.com','ubuntu-appindicators@ubuntu.com'):
            if uuid in installed and uuid not in enabled:
                try: subprocess.run(['gnome-extensions','enable',uuid],timeout=10,check=False)
                except Exception: pass
                return
    def _no_tray_hint(self):
        # Shown once per user, not at every login.
        marker=_config_home()/'locsec'/'tray-hint-shown'
        if marker.exists(): return
        msg='LocSec could not put its icon in the panel: this desktop has no system tray.'
        d=_desktops(); again=' Then start the icon again with: locsecctl tray'
        if _gnome_shell():
            msg+=(' On GNOME, install the AppIndicator extension '
                  '(sudo apt install gnome-shell-extension-appindicator), log out and back in, '
                  'and LocSec will switch it on.')
        elif 'XFCE' in d:
            msg+=' On Xfce, right-click the panel, choose Panel > Add New Items and add "Status Tray Plugin" (or "Notification Area" on older Xfce).'+again
        elif 'MATE' in d:
            msg+=' On MATE, right-click the panel, choose Add to Panel and add "Notification Area".'+again
        elif 'BUDGIE' in d:
            msg+=' On Budgie, open Budgie Desktop Settings > Panel and add the "System Tray" applet.'+again
        elif 'LXQT' in d:
            msg+=' On LXQt, right-click the panel, choose Manage Widgets and add "Status Notifier".'+again
        elif d & {'LXDE','LXDE-PI'}:
            msg+=' On LXDE, right-click the panel, choose Add/Remove Panel Items and add "System Tray".'+again
        elif d & {'CINNAMON','X-CINNAMON'}:
            msg+=' On Cinnamon, right-click the panel, choose Applets and add "Xapp Status Applet" or "System Tray".'+again
        elif 'KDE' in d:
            msg+=' On KDE Plasma, right-click the panel, choose Add Widgets and add "System Tray".'+again
        elif 'PANTHEON' in d:
            msg+=(' On elementary OS (Pantheon), install the Ayatana indicator for the top panel '
                  '(sudo apt install wingpanel-indicator-ayatana) and log out and back in.')+again
        elif 'COSMIC' in d:
            msg+=' On COSMIC, open Settings > Desktop > Panel > Configure panel applets and add "Notification Tray".'+again
        elif d & {'SWAY','HYPRLAND','RIVER','NIRI','WAYFIRE','LABWC'}:
            msg+=' On a tiling or standalone Wayland compositor, add a tray to your bar (for example the "tray" module in Waybar).'+again
        elif d & {'I3','BSPWM','OPENBOX','AWESOME','QTILE','DWM'}:
            msg+=' On a standalone window manager, run a tray such as stalonetray or trayer, or use a bar with a tray (polybar, i3bar).'+again
        if shutil.which('notify-send'):
            try: subprocess.run(['notify-send','-i','locsec','LocSec',msg],timeout=10,check=False)
            except Exception: pass
        print('LocSec: '+msg, file=sys.stderr)
        try:
            marker.parent.mkdir(parents=True,exist_ok=True); marker.touch()
        except OSError:
            pass
    # ---- service status ---------------------------------------------------
    def _poll_status(self):
        if self.proc is not None:
            # A systemctl that has not answered in 15 s is stuck; do not let it
            # stop every later poll (the menu would say "checking..." forever).
            if time.monotonic()-self.proc_started<15: return
            old=self.proc; self.proc=None
            for sig in (old.finished, old.errorOccurred):
                try: sig.disconnect()
                except (TypeError, RuntimeError): pass
            try: old.kill()
            except Exception: pass
            old.deleteLater()
        p=QProcess(); self.proc=p; self.proc_started=time.monotonic()
        p.finished.connect(self._status_done)
        p.errorOccurred.connect(lambda _e, p=p: self._status_failed(p))
        p.start('systemctl',['is-active',UNIT])
    def _status_failed(self, p):
        # systemctl missing or would not start: finished() never fires.
        if p.state()==QProcess.ProcessState.NotRunning and self.proc is p:
            self.proc=None; p.deleteLater()
            self._apply_state('unknown', notify=False)
    def _status_done(self, *_):
        p=self.proc; self.proc=None
        if p is None: return
        state=bytes(p.readAllStandardOutput()).decode(errors='replace').strip() or 'unknown'
        p.deleteLater()
        prev=self.state; self.state=state
        changed = prev is not None and prev!=state and (prev=='active' or state=='active')
        self._apply_state(state, notify=changed)
    def _apply_state(self, state, notify):
        if self.tray is None: return
        ok = state=='active'
        self.tray.setIcon(self.icon_ok if ok else self.icon_alert)
        if ok:
            self.tray.setToolTip('LocSec Security Center\nProtection active')
            self.act_status.setText('Service: running')
        else:
            self.tray.setToolTip(f'LocSec Security Center\nService {state}')
            self.act_status.setText(f'Service: {state}')
        if notify:
            if ok:
                self.tray.showMessage('LocSec','The LocSec service is running again.',self.icon_ok,5000)
            else:
                self.tray.showMessage('LocSec',f'The LocSec service is not running ({state}). Protection is off.',
                                      QSystemTrayIcon.MessageIcon.Warning,10000)
    # ---- window -----------------------------------------------------------
    def show_window(self):
        if not HAVE_WEBENGINE:
            if self.tray_active():
                # The fallback can sit in a pkexec prompt for up to two minutes.
                # On this thread that froze the panel icon and its status line,
                # the same freeze 4.0.11-64 fixed for the window. It only runs
                # subprocesses, so a worker thread is safe.
                import threading
                threading.Thread(target=_browser_fallback,args=(WEBENGINE_ERR,),daemon=True).start()
                return
            rc=_browser_fallback(WEBENGINE_ERR)
            # No panel icon to stay in: behave like the old launcher and exit.
            # Queued, because this can run before the event loop starts.
            QTimer.singleShot(0,lambda: self.app.exit(rc))
            return
        if self.window is None:
            self.window=Window(self)
        w=self.window
        was_hidden=not w.isVisible()
        if w.isMinimized(): w.showNormal()
        else: w.show()
        w.raise_(); w.activateWindow()
        if was_hidden and w.loaded: w.refresh()
    def _on_connection(self):
        while self.server.hasPendingConnections():
            c=self.server.nextPendingConnection()
            buf=bytearray(); handled=[False]
            def got(*_a, c=c, buf=buf, handled=handled):
                # Also called on disconnect and straight away: the second launch writes its
                # request and hangs up at once, so the bytes can already be waiting (or the
                # socket already closed) before readyRead is connected, and the request was
                # then never read.
                if handled[0]: return
                buf.extend(bytes(c.readAll()))
                connected=c.state()==QLocalSocket.LocalSocketState.ConnectedState
                if b'\n' not in buf and connected: return
                handled[0]=True
                if bytes(buf).strip()==b'show': self.show_window()
                if connected: c.disconnectFromServer()
            c.readyRead.connect(got)
            c.disconnected.connect(got)
            c.disconnected.connect(c.deleteLater)
            if c.bytesAvailable() or c.state()!=QLocalSocket.LocalSocketState.ConnectedState: got()
    # ---- start at login ---------------------------------------------------
    @staticmethod
    def _user_autostart():
        return _config_home()/'autostart'/AUTOSTART_NAME
    @staticmethod
    def _desktop_enabled(path):
        try: text=path.read_text(errors='replace')
        except OSError: return False
        for line in text.splitlines():
            k,_,v=line.partition('=')
            k=k.strip(); v=v.strip().lower()
            if (k=='Hidden' and v=='true') or (k=='X-GNOME-Autostart-enabled' and v=='false'):
                return False
        return True
    def _autostart_enabled(self):
        user=self._user_autostart()
        if user.exists():
            return self._desktop_enabled(user)
        return SYSTEM_AUTOSTART.exists() and self._desktop_enabled(SYSTEM_AUTOSTART)
    def _set_autostart(self, on):
        # Per user only. A file of the same name in ~/.config/autostart
        # overrides the system-wide /etc/xdg/autostart entry on every desktop.
        user=self._user_autostart()
        try:
            if on and SYSTEM_AUTOSTART.exists() and self._desktop_enabled(SYSTEM_AUTOSTART):
                if user.exists(): user.unlink()
                return
            user.parent.mkdir(parents=True,exist_ok=True)
            user.write_text('[Desktop Entry]\nType=Application\nName=LocSec panel icon\n'
                            'Exec=/usr/bin/locsec-gui --tray\nIcon=locsec\nTerminal=false\nNoDisplay=true\n'
                            f'Hidden={"false" if on else "true"}\n'
                            f'X-GNOME-Autostart-enabled={"true" if on else "false"}\n')
        except OSError as e:
            QMessageBox.warning(None,'LocSec',f'Could not change the login setting: {e}')

app=QApplication(sys.argv)
app.setApplicationName('locsec-gui')
app.setApplicationDisplayName('LocSec Security Center')
app.setDesktopFileName('locsec')
app.setQuitOnLastWindowClosed(False)
app.setWindowIcon(_make_icon('locsec'))
_LOCK_FD=_instance_lock()
if _LOCK_FD is None:
    # Another instance holds the lock: it is running, or still starting and not yet
    # listening. Keep offering it the request for a while instead of starting a second one.
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        if _hand_off_to_running_instance(): sys.exit(0)
        time.sleep(0.5)
    print('LocSec: another locsec-gui is running but did not answer; not starting a second one', file=sys.stderr)
    sys.exit(0)
if _hand_off_to_running_instance():      # a running instance from before this lock existed
    sys.exit(0)
# Native Qt/GTK-looking dialog buttons clash with the dashboard; match its button style.
app.setStyleSheet('QMessageBox{background:#12151d}QMessageBox QLabel{color:#e6e9f2;font-size:13px}QPushButton{padding:8px 18px;border:1px solid #5b8cff;border-radius:9px;background:#172033;color:#5b8cff;font-weight:600;min-width:72px}QPushButton:hover{background:#1f2c48}QPushButton:pressed{background:#12192b}')
controller=Controller(app)
controller.start()
sys.exit(app.exec())
