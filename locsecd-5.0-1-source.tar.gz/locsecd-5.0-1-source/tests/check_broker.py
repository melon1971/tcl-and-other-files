#!/usr/bin/python3
"""Static check for locsecd.py's privilege broker (LocSec 4.0.11-90 and later; two processes from 4.0.11-91).

Fails (exit 1) when:
  * a privileged command (ufw, nft, tcpdump, apt-get, systemd-run, a state-changing
    systemctl action, ...) is run anywhere outside the broker section or the two
    low-level runners, run() and _run_transient();
  * _run_transient() or run_privileged() is called outside the broker section;
  * subprocess is called with a command that is not a literal list, outside run();
  * broker() is called with a verb name that is not registered, or with an argument
    that verb does not declare, or without one it requires.

Usage: check_broker.py [path/to/locsecd.py]
"""
import ast, sys, os

PATH = sys.argv[1] if len(sys.argv) > 1 else '/usr/lib/locsecd/locsecd.py'
src = open(PATH).read()
tree = ast.parse(src)
lines = src.split('\n')

begin = next(i for i, l in enumerate(lines, 1) if 'PRIVILEGE BROKER (begin)' in l)
end = next(i for i, l in enumerate(lines, 1) if 'PRIVILEGE BROKER (end)' in l)

# Functions allowed to execute raw commands: the generic runners themselves.
RUNNERS = {'run', '_run_transient', 'run_privileged'}
# Wrappers that forward a verb chosen by their (checked) callers.
PASS_THROUGH = {'scan_tool', '_quarantine_helper', '_root_side_call', '_broker_conn'}

PRIV_EXEC = {'ufw', 'nft', 'tcpdump', 'clamscan', 'clamdscan', 'systemd-run', 'systemd-inhibit', 'apt-get',
             'unattended-upgrade', 'freshclam', 'aideinit', 'aide', 'lynis', 'rkhunter', 'suricata-update',
             'iptables', 'ip6tables', 'iptables-restore', 'ip6tables-restore'}
SYSTEMCTL_READ = {'is-active', 'is-enabled', 'is-failed', 'show', 'status', 'list-units', 'list-unit-files', 'list-timers', 'cat'}
WRAPPERS = {'nice', 'ionice', 'env', 'timeout', 'stdbuf'}

# enclosing function for every line
spans = []
for n in ast.walk(tree):
    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
        spans.append((n.lineno, n.end_lineno, n.name))
def enclosing(line):
    best = None
    for a, b, nm in spans:
        if a <= line <= b and (best is None or a > best[0]):
            best = (a, nm)
    return best[1] if best else '<module>'

def in_broker(line):
    return begin <= line <= end

def literal_prefix(node):
    """Leading string literals of a list/tuple node, or None if not a literal list."""
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return literal_prefix(node.left)
    if not isinstance(node, (ast.List, ast.Tuple)):
        return None
    out = []
    for e in node.elts:
        if isinstance(e, ast.Constant) and isinstance(e.value, str):
            out.append(e.value)
        else:
            out.append(None)
    return out

def privileged(toks):
    toks = list(toks)
    while toks and toks[0] is not None and os.path.basename(toks[0]) in WRAPPERS:
        toks = toks[1:]
        while toks and toks[0] is not None and (toks[0].startswith('-') or toks[0].isdigit() or '=' in toks[0]):
            toks = toks[1:]
    if not toks or toks[0] is None:
        return ''
    prog = os.path.basename(toks[0])
    if prog in PRIV_EXEC:
        return prog
    if prog == 'systemctl':
        sub = next((t for t in toks[1:] if t is not None and not t.startswith('-')), None)
        if sub is None:
            return 'systemctl <dynamic>'
        return '' if sub in SYSTEMCTL_READ else 'systemctl ' + sub
    return ''

def call_name(f):
    if isinstance(f, ast.Name):
        return f.id
    if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name):
        return f.value.id + '.' + f.attr
    return ''

# registered verbs and their argument specs
verbs = {}
for n in ast.walk(tree):
    if isinstance(n, ast.FunctionDef):
        for d in n.decorator_list:
            if isinstance(d, ast.Call) and call_name(d.func) in ('_verb', '_root_side') and d.args and isinstance(d.args[0], ast.Constant):
                spec = {}
                for kw in d.keywords:
                    if kw.arg in ('refused', 'remote', 'returns_fd', 'after', 'local'):
                        continue
                    required = isinstance(kw.value, ast.Call) and len(kw.value.args) == 1
                    spec[kw.arg] = required
                verbs[d.args[0].value] = spec

problems = []
for n in ast.walk(tree):
    if not isinstance(n, ast.Call):
        continue
    name = call_name(n.func)
    line = n.lineno
    where = enclosing(line)
    if name in ('_run_transient', 'run_privileged'):
        if not in_broker(line) and where not in RUNNERS:
            problems.append(f'{line}: {name}() called from {where}, outside the broker')
        continue
    if name == 'ufw':
        problems.append(f'{line}: ufw() no longer exists; use a fw.ufw.* verb')
        continue
    if name in ('run', 'subprocess.run', 'subprocess.Popen', 'subprocess.check_output', 'subprocess.call', 'subprocess.check_call'):
        if not n.args:
            continue
        toks = literal_prefix(n.args[0])
        if toks is None:
            if name.startswith('subprocess.') and where not in RUNNERS and not in_broker(line):
                problems.append(f'{line}: {name}() with a non-literal command in {where}')
            continue
        p = privileged(toks)
        if p and not in_broker(line) and where not in RUNNERS:
            problems.append(f'{line}: privileged command {p!r} run from {where}, outside the broker')
        continue
    # broker(VERB, ...), _quarantine_helper(VERB, ...), scan_tool(..., verb=VERB, vargs={...})
    v = None; given = None
    if name in ('broker', '_quarantine_helper') and n.args:
        v = n.args[0]
        if any(kw.arg is None for kw in n.keywords):
            if where in PASS_THROUGH:
                continue  # forwards its caller's verb and arguments; the callers are checked
            problems.append(f'{line}: {name}() with **kwargs in {where}')
            continue
        given = {kw.arg for kw in n.keywords if kw.arg}
    elif name == 'scan_tool':
        kw = {k.arg: k.value for k in n.keywords}
        if 'verb' not in kw:
            continue
        v = kw['verb']
        va = kw.get('vargs')
        if va is None:
            given = set()
        elif isinstance(va, ast.Dict) and all(isinstance(k, ast.Constant) for k in va.keys):
            given = {k.value for k in va.keys}
        else:
            problems.append(f'{line}: scan_tool() vargs is not a literal dict'); continue
    if v is not None:
        if not (isinstance(v, ast.Constant) and isinstance(v.value, str)):
            if where not in PASS_THROUGH:
                problems.append(f'{line}: {name}() verb is not a literal string ({where})')
            continue
        spec = verbs.get(v.value)
        if spec is None:
            problems.append(f'{line}: {name}({v.value!r}) is not a registered verb')
            continue
        for k in sorted(given - set(spec)):
            problems.append(f'{line}: {v.value!r} has no argument {k!r}')
        for k, req in spec.items():
            if req and k not in given:
                problems.append(f'{line}: {v.value!r} is missing required argument {k!r}')

print(f'{len(verbs)} verbs registered; broker section lines {begin}-{end}')
if problems:
    print('\n'.join(problems))
    sys.exit(1)
print('OK: every privileged operation goes through the broker')
