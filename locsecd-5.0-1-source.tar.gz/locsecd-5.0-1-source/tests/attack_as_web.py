#!/usr/bin/python3
"""Run as the unprivileged user (locsec), as a compromised dashboard would be: talk to the broker socket
directly and try to get more than the verbs allow. Every attempt must fail. Prints one line per attempt;
exits 1 if any attempt succeeded."""
import socket, struct, json, os, array, sys, time

SOCK = '/run/locsecd/broker.sock'
failed = []

def call(obj, fds=(), raw=None):
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(30)
    s.connect(SOCK)
    data = raw if raw is not None else json.dumps(obj).encode()
    hdr = struct.pack('>I', len(data))
    if fds:
        s.sendmsg([hdr], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', fds))])
    else:
        s.sendall(hdr)
    try:
        s.sendall(data)
        h = b''
        while len(h) < 4:
            msg, anc, fl, _ = s.recvmsg(4 - len(h), socket.CMSG_SPACE(16))
            if not msg: return {'closed': True}
            h += msg
            for lvl, typ, d in anc:
                a = array.array('i'); a.frombytes(d[:len(d) - len(d) % 4])
                for f in a: os.close(f); return {'GOT_FD': True}
        n = struct.unpack('>I', h)[0]; buf = b''
        while len(buf) < n:
            c = s.recv(n - len(buf))
            if not c: break
            buf += c
        return json.loads(buf)
    except (BrokenPipeError, ConnectionResetError):
        return {'closed': True}
    finally:
        s.close()

def expect_refused(label, resp, why_contains=''):
    r = resp.get('refused') if isinstance(resp, dict) else None
    res = resp.get('result') if isinstance(resp, dict) else None
    ok = (r is not None and why_contains.lower() in str(r).lower()) or resp.get('closed') or \
         (isinstance(res, list) and res and res[0] == 126) or (isinstance(res, dict) and (res.get('ok') is False or 'error' in res)) \
         or res is False or (res is None and 'refused' in resp)
    print(('PASS ' if ok else 'FAIL ') + label + ': ' + json.dumps(resp)[:170])
    if not ok: failed.append(label)

print(f'running as uid {os.getuid()} gid {os.getgid()} groups {os.getgroups()}')

# 1. internal steps: the AIDE baseline without the lock, a raw quarantine move, a ClamAV list of my choosing
expect_refused('aideinit --force without the AIDE lock', call({'verb': 'job.aide_reinit', 'args': {'timeout': 600}, 'fd_args': []}), 'internal')
expect_refused('raw quarantine move of /etc/shadow', call({'verb': 'job.quarantine', 'args': {'path': '/etc/shadow', 'signature': 'x'}, 'fd_args': []}), 'internal')
expect_refused('clamscan an arbitrary file list', call({'verb': 'job.clamav_batch', 'args': {'mode': 'clamscan', 'timeout': 60,
               'batch_file': '/var/lib/locsecd-broker/work/clamav-batch-1-deadbeef-1.txt', 'out_file': '/var/lib/locsecd-broker/work/clamav-out-1-deadbeef-1.txt'}, 'fd_args': []}), 'internal')
expect_refused('stop arbitrary units', call({'verb': 'jobs.stop_stale', 'args': {'units': ['locsecd-scan-p1-deadbeef.service']}, 'fd_args': []}), 'internal')
# 2. reading root-only files
for p in ('/etc/shadow', '/var/lib/locsecd-broker/quarantine/0123456789abcdef.qf', '/var/log/../etc/shadow',
          '/var/log/suricata/../../../etc/shadow', '/root/.bash_history', '/etc/locsecd/../shadow'):
    expect_refused(f'file.open {p}', call({'verb': 'file.open', 'args': {'path': p}, 'fd_args': []}))
# a symlink planted where an allowed file name is expected
try:
    os.symlink('/etc/shadow', '/var/lib/locsecd/shadow-link')
except OSError: pass
expect_refused('file.open of a symlink outside the list', call({'verb': 'file.open', 'args': {'path': '/var/lib/locsecd/shadow-link'}, 'fd_args': []}))
# 3. descriptor arguments: a number in the JSON must never be taken as one of the broker's own descriptors
for n in (0, 3, 4, 5, 6, 7):
    expect_refused(f'tshark on broker fd {n} given as a number', call({'verb': 'job.tshark', 'args': {'mode': 'summary', 'capture': n}, 'fd_args': []}), 'file descriptor')
r_, w_ = os.pipe()
expect_refused('tshark on a pipe', call({'verb': 'job.tshark', 'args': {'mode': 'summary'}, 'fd_args': ['capture']}, fds=[r_]))
expect_refused('fd for a non-fd argument', call({'verb': 'fw.ufw.deny', 'args': {}, 'fd_args': ['target']}, fds=[r_]), 'not a file descriptor')
expect_refused('more fds than names', call({'verb': 'fw.ufw.enable', 'args': {}, 'fd_args': []}, fds=[r_]), 'malformed')
# 4. policy that must hold whoever asks
expect_refused('block 0.0.0.0/0', call({'verb': 'fw.ufw.deny', 'args': {'target': '0.0.0.0/0'}, 'fd_args': []}))
expect_refused('stop ssh', call({'verb': 'svc.control', 'args': {'unit': 'ssh.service', 'action': 'stop'}, 'fd_args': []}))
expect_refused('stop an alias of logind', call({'verb': 'svc.control', 'args': {'unit': 'dbus-org.freedesktop.login1.service', 'action': 'stop'}, 'fd_args': []}))
expect_refused('install a package LocSec does not use', call({'verb': 'job.apt_install', 'args': {'packages': ['netcat-traditional']}, 'fd_args': []}))
expect_refused('apt option smuggled as a package', call({'verb': 'job.apt_upgrade', 'args': {'packages': ['-oAPT::Get::AllowUnauthenticated=1']}, 'fd_args': []}))
for p, force in (('/etc/shadow', True), ('/etc/passwd', True), ('/usr/bin/sudo', True), ('/etc/pam.d/common-auth', True),
                 ('/usr/lib/locsecd/locsecd.py', True), ('/etc/hostname', False)):
    expect_refused(f'quarantine {p} force={force}', call({'verb': 'quarantine.file', 'args': {'path': p, 'force': force, 'signature': 'x'}, 'fd_args': []}))
expect_refused('restore with a crafted id', call({'verb': 'quarantine.restore', 'args': {'qid': '../../../etc/cron.d/x'}, 'fd_args': []}))
expect_refused('notify uid 0', call({'verb': 'notify.desktop', 'args': {'uid': 0, 'kind': 'x', 'title': 't', 'body': 'b'}, 'fd_args': []}))
# 5. malformed requests
expect_refused('unknown verb', call({'verb': 'shell', 'args': {'cmd': 'id'}, 'fd_args': []}), 'unknown')
expect_refused('args not an object', call({'verb': 'fw.ufw.enable', 'args': ['x'], 'fd_args': []}), 'malformed')
expect_refused('not JSON', call(None, raw=b'\xff\xfe not json'))
expect_refused('oversized request (17 MB)', call(None, raw=b'{"verb":"x","pad":"' + b'A' * (17 << 20) + b'"}'))
# 6. the broker's own files stay out of reach
for p in ('/var/lib/locsecd-broker', '/var/lib/locsecd-broker/quarantine', '/etc/shadow'):
    try:
        os.listdir(p) if os.path.isdir(p) else open(p).read()
        print('FAIL direct access to', p); failed.append(p)
    except PermissionError:
        print('PASS no direct access to', p)
# 7. still able to do its job: a legitimate verb works
resp = call({'verb': 'fw.ufw.status', 'args': {}, 'fd_args': []})
ok = isinstance(resp.get('result'), list) and resp['result'][0] == 0
print(('PASS ' if ok else 'FAIL ') + 'a legitimate verb still works: ' + json.dumps(resp)[:120])
if not ok: failed.append('legit')
print(f'{len(failed)} attempt(s) succeeded that should not have' if failed else 'all attempts refused')
sys.exit(1 if failed else 0)
