"""Suricata card test: while systemd reports Suricata as "reloading" (LocSec triggers a rule reload
after each update, and it can take a minute or two) the card must not say "not running".
Usage: test_ids_reloading.py path/to/locsecd.py   (throwaway container; needs the locsec account)"""
import sys, importlib.util, types, time
import os; os.environ["LOCSEC_INPROCESS_BROKER"]="1"
PATH=sys.argv[1]
spec=importlib.util.spec_from_file_location('l',PATH); m=importlib.util.module_from_spec(spec); sys.argv=[PATH]; spec.loader.exec_module(m)
m.log=lambda *a,**k: None
m.have=lambda c: True
m._pstat=lambda p: types.SimpleNamespace(st_mtime=time.time())
m._ids_config_hint=lambda: ''
def state(rc,out):
    m.run=lambda cmd,timeout=60,**k: (rc,out)
    return m.ids_status()['state']
bad=[]
for rc,out,want in ((0,'active\n','monitoring'),(3,'reloading\n','monitoring'),(3,'inactive\n','stopped'),(3,'failed\n','stopped'),(124,'(timed out after 10s)','stopped')):
    got=state(rc,out)
    print(f'is-active rc={rc} {out.strip()!r:28} -> {got}')
    if got!=want: bad.append((out.strip(),want,got))
assert not bad, f'wrong state: {bad}'
print('ok')
