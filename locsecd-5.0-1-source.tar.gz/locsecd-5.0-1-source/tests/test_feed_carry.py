"""Feed carry-forward test: a source that fails one run keeps its last good copy
(up to 7 days) instead of dropping out of the indicator list.
Usage: test_feed_carry.py path/to/locsecd.py   (throwaway container; needs the locsec account)"""
import sys, importlib.util, tempfile, pathlib, json, io, time
import os; os.environ["LOCSEC_INPROCESS_BROKER"]="1"
PATH=sys.argv[1]
spec=importlib.util.spec_from_file_location('l',PATH); m=importlib.util.module_from_spec(spec); sys.argv=[PATH]; spec.loader.exec_module(m)
d=pathlib.Path(tempfile.mkdtemp())
m.FEEDS=d/'feeds.json'; m.BLOCKS=d/'blocks.json'
if hasattr(m,'FEED_SOURCES'): m.FEED_SOURCES=d/'feed-sources.json'
m.log=lambda *a,**k: None; m.prune_expired_blocks=lambda: None
m.CFG.update(feed_urls=['https://www.spamhaus.org/drop/drop.txt','https://urlhaus.abuse.ch/downloads/text/'],feed_auto_block=False)
BODY={'spamhaus':b'1.2.3.0/24 ; SBL1\n5.6.7.0/24 ; SBL2\n','urlhaus':b'http://evil.example.com/a.exe\nhttp://9.9.9.9/x\nhttp://bad.test/y\n'}
fail=set()
class R(io.BytesIO):
    def __enter__(s): return s
    def __exit__(s,*a): pass
class O:
    def open(s,req,timeout=30):
        k='urlhaus' if 'urlhaus' in req.full_url else 'spamhaus'
        if k in fail: raise TimeoutError('The read operation timed out')
        return R(BODY[k])
m._FEED_OPENER=O()
r1=m.feed_update(); print('run1',r1)
fail.add('urlhaus'); r2=m.feed_update(); print('run2',r2)
f=json.loads(m.FEEDS.read_text()); print('domains',f['domains'],'ips',f['ips'])
assert 'evil.example.com' in f['domains'] and '9.9.9.9/32' in f['ips'], 'URLhaus entries dropped'
# stale copy
if hasattr(m,'FEED_SOURCES'):
    c=json.loads(m.FEED_SOURCES.read_text()); c['https://urlhaus.abuse.ch/downloads/text/']['fetched']=time.time()-8*86400; m.FEED_SOURCES.write_text(json.dumps(c))
    r3=m.feed_update(); f=json.loads(m.FEEDS.read_text()); print('run3',r3['errors'],f['domains'])
    assert 'evil.example.com' not in f['domains']
    fail.clear(); r4=m.feed_update(); print('run4',r4['errors'],r4['domains'])
print('PASS')
