#!/usr/bin/python3
"""Differential test: run the same scenarios against one locsecd.py with subprocess
stubbed, and print every command it would have executed, per scenario, as JSON.
Usage: difftest.py path/to/locsecd.py > out.json   (run as root in a throwaway container)"""
import sys, os, json, re, time, shutil, subprocess, importlib.util, threading, io, types

PATH = sys.argv[1]
REC = []          # (scenario, argv)
CUR = ['import']

# --- canned responses: (predicate on argv, rc, output) ---
STATE = {'ufw': 'active'}
def respond(argv):
    a = [str(x) for x in argv]
    j = ' '.join(a)
    if a[0] == 'systemd-run':
        inner = a[a.index('--setenv=DEBIAN_FRONTEND=noninteractive') + 1:] if '--setenv=DEBIAN_FRONTEND=noninteractive' in a else a
        inner = [x for x in inner if not x.startswith('--property=')]
        ij = ' '.join(inner)
        if 'locsec-quarantine' in ij: return 0, '{"ok":true,"restored_to":"/x"}\n'
        if 'aide-accept-pending' in ij: return 0, '{"ok":true}\n'
        if 'apt-get -s' in ij:
            return 0, 'Inst foo [1.0] (1.1 Debian-Security:12/stable-security [amd64])\nInst bar [2.0] (2.1 Debian:12/stable [amd64])\n'
        if 'clamdscan' in ij or 'clamscan' in ij:
            return 1, '/srv/t/a.txt: Eicar-Signature FOUND\n----------- SCAN SUMMARY -----------\nInfected files: 1\nTotal errors: 0\n'
        if 'tshark' in ij and 'fields' in ij: return 0, '10.0.0.1|10.0.0.2|443|\n'
        return 0, 'ok\n'
    if a[0] == 'ufw' and a[1:2] == ['status']: return 0, f'Status: {STATE["ufw"]}\n'
    if a[0] == 'nft' and 'list' in a: return 0, 'table inet locsec { chain input { ip saddr @blocked4 drop\nip6 saddr @blocked6 drop } }'
    if a[0] == 'systemctl' and 'show' in a and '-p' in a and 'Id' in a and '--value' in a: return 0, a[-1] + '\n'
    if a[0] == 'systemctl' and 'show' in a: return 0, 'Id=x\nLoadState=loaded\nActiveState=active\nSubState=running\nDescription=x\n'
    if a[0] == 'systemctl' and 'list-units' in a: return 0, 'locsecd-scan-p999999-deadbeef.service loaded active running x\n'
    if a[0] == 'systemctl' and 'is-enabled' in a: return 0, 'enabled\n'
    if a[0] == 'systemctl' and 'is-active' in a and any('dailyaidecheck' in x for x in a): return 3, 'inactive\n'
    if a[0] == 'systemctl' and 'is-active' in a: return 0, 'active\n'
    if a[0] == 'dpkg-query' and len(a) == 3 and a[1] == '-W': return 1, ''      # tool not installed
    if a[0] == 'dpkg-query' and '-f=${Status}' in a: return 1, ''
    if a[0] == 'clamscan': return 1, f'{a[-1]}: Eicar-Signature FOUND\n'
    if a[0] == 'ss': return 0, ''
    if a[0] == 'loginctl': return 0, ''
    return 0, ''

def norm(argv):
    out = []
    for x in argv:
        x = str(x)
        x = re.sub(r'-p\d+-[0-9a-f]{8}\.service', '-pPID-HEX.service', x)
        x = re.sub(r'capture-[0-9-]+\.pcapng', 'capture-TS.pcapng', x)
        x = re.sub(r'aide-full-\d{8}-\d{6}(-[0-9a-f]{8})?\.txt', 'aide-full-TS.txt', x)
        x = re.sub(r'clamav-(batch|out|filelist)-\d+-[0-9a-f]{8}', r'clamav-\1-TAG', x)
        out.append(x)
    return out

class FakeProc:
    def __init__(self, argv, stdout=None, **kw):
        self.args = argv; self.pid = 999998; self.returncode = None; self._stdout = stdout
        rc, outp = respond(argv); self._rc = rc; self._out = outp
    def poll(self): return self.returncode
    def communicate(self, input=None, timeout=None):
        if hasattr(self._stdout, 'write'): self._stdout.write(self._out.encode())
        self.returncode = self._rc; return (None, None)
    def wait(self, timeout=None): self.returncode = self._rc if self.returncode is None else self.returncode; return self.returncode
    def terminate(self): self.returncode = -15
    def kill(self): self.returncode = -9
    def send_signal(self, s): self.returncode = -s

def fake_run(argv, input=None, stdin=None, stdout=None, stderr=None, timeout=None, check=False, text=False, **kw):
    REC.append((CUR[0], norm(argv)))
    rc, outp = respond(argv)
    if hasattr(stdout, 'write'):
        stdout.write(outp.encode()); return subprocess.CompletedProcess(argv, rc)
    return subprocess.CompletedProcess(argv, rc, stdout=outp if text else outp.encode(), stderr='')

def fake_popen(argv, *a, **kw):
    REC.append((CUR[0], norm(argv)))
    return FakeProc(argv, **kw)

def fake_check_output(argv, *a, **kw):
    REC.append((CUR[0], norm(argv)))
    return ''

subprocess.run = fake_run
subprocess.Popen = fake_popen
subprocess.check_output = fake_check_output
os.killpg = lambda *a: None

# fresh state
for d in ('/var/lib/locsecd', '/var/lib/locsecd-broker', '/var/log/locsecd', '/var/lib/aide', '/srv/t'):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs('/var/lib/aide'); os.makedirs('/srv/t'); os.makedirs('/run/user/1000', exist_ok=True)
open('/run/user/1000/bus', 'w').close()
open('/srv/t/a.txt', 'w').write('X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR')
os.makedirs('/etc/aide', exist_ok=True); open('/etc/aide/aide.conf', 'w').write('# x\n')
open('/etc/rkhunter.conf', 'w').write('WEB_CMD="/bin/false"\nMIRRORS_MODE=1\n')

spec = importlib.util.spec_from_file_location('locsecd_under_test', PATH)
m = importlib.util.module_from_spec(spec)
sys.argv = [PATH]
spec.loader.exec_module(m)
m.have = lambda c: True
m.CFG['clamav_scan_paths'] = ['/srv/t']
m.CFG['auto_update'] = True
m.CFG['inhibit_sleep_during_jobs'] = True

def wait_threads():
    for t in threading.enumerate():
        if t is not threading.current_thread() and t.name.startswith('ids'): t.join(10)

def scen(name, fn):
    CUR[0] = name
    try:
        r = fn()
    except Exception as e:
        REC.append((name, ['EXCEPTION', type(e).__name__, str(e)[:200]]))
    wait_threads()

scen('block_ufw', lambda: m.block_ip('203.0.113.5', reason='t', source='manual'))
STATE['ufw'] = 'inactive'
scen('block_nft', lambda: m.block_ip('198.51.100.0/24', reason='t', source='manual'))
scen('unblock', lambda: m.unblock_ip('203.0.113.5'))
scen('restore_blocks', m.restore_blocks)
scen('remove_rule', lambda: m._remove_firewall_rule('198.51.100.0/24'))
scen('fallback1', m.fallback_firewall_check)
scen('fallback2', m.fallback_firewall_check)
STATE['ufw'] = 'active'
scen('fallback_off', m.fallback_firewall_check)
scen('firewall_active', m.firewall_active)
scen('svc_restart_managed', lambda: m.service_action('clamav-daemon.service', 'restart'))
scen('svc_stop_protected', lambda: m.service_action('ssh.service', 'stop'))
scen('tool_add_aide', lambda: m.tool_add('aide'))
scen('tool_add_clamd', lambda: m.tool_add('clamdscan'))
scen('tool_add_suricata', lambda: m.tool_add('suricata'))
scen('install_missing', m.install_missing)
scen('package_update', m.package_update)
scen('update_definitions', m.update_definitions)
scen('quarantine', lambda: m.quarantine_file('/srv/t/a.txt'))
scen('quarantine_restore', lambda: m.restore_quarantined('0123456789abcdef', overwrite=True))
scen('aide_init', m.aide_init)
open('/var/lib/aide/aide.db', 'w').write('db')
scen('aide_reinit', lambda: m.aide_reinitialize(confirm=True))
open('/var/lib/aide/aide.db.new', 'w').write('dbnew')
scen('aide_accept', lambda: m.aide_accept_pending(confirm=True))
for name, fn in m.SCAN_JOBS:
    scen('job_' + name, fn)
scen('job_clamav', m.CLAMAV_JOB[1])
scen('cve_scan', m.cve_scan)
os.makedirs(str(m.CAPTURES), exist_ok=True)
open(str(m.CAPTURES / 'capture-20261004-120000-000001.pcapng'), 'wb').write(b'\x0a\x0d\x0d\x0a' + b'\0' * 40)
scen('deep_analysis', lambda: m.analyze_capture('capture-20261004-120000-000001.pcapng', deep=True))
scen('notify', lambda: m._desktop_send(1000, 'test', 'Hello', '<b>x</b> & y'))
scen('inhibit', lambda: (m.SLEEP_INHIBIT.start('LocSec job'), m.SLEEP_INHIBIT.stop()))
scen('ids_rules', m.ids_rules_update)
scen('sweep_orphans', m._sweep_orphan_units)
if isinstance(m.INFLIGHT_PRIV_UNITS, dict): m.INFLIGHT_PRIV_UNITS['locsecd-scan-p1-abcdef12.service'] = os.getpid()
else: m.INFLIGHT_PRIV_UNITS.add('locsecd-scan-p1-abcdef12.service')
scen('stop_inflight', m._stop_inflight_priv_units)
m.INFLIGHT_PRIV_UNITS.clear()

out = {}
for s_, argv in REC:
    out.setdefault(s_, []).append(argv)
json.dump(out, sys.stdout, indent=1)
