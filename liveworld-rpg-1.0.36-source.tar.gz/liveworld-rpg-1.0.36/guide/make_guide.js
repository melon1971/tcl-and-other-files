// Builds LiveWorld-RPG-Guide.docx: one guide for installing and playing.
// Gameplay sections come from data.json (exported from the game's own guide.py), so they match F1 in the game.
//   node make_guide.js data.json out.docx
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, LevelFormat, Footer, Header, PageNumber, TableOfContents, PageBreak,
} = require("docx");

const [, , dataPath, outPath] = process.argv;
const D = JSON.parse(fs.readFileSync(dataPath, "utf8"));
const VER = D.version;
const DEB = `liveworld-rpg_${VER}_all.deb`;
const TITLE = `LiveWorld RPG ${VER} – Player's Manual`;
const TODAY = new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
const n0 = (x) => Number(x).toLocaleString("en-US");

const INK = "2B2118", GOLD = "8A6416", RULE = "C9A85A", HEAD_BG = "EFE3C6", ZEBRA = "FAF6EC", CODE_BG = "F2F2F2";
const FONT = "Arial", MONO = "Consolas";
const PAGE_W = 12240, MARGIN = 1260, CONTENT = PAGE_W - 2 * MARGIN;   // US Letter, 0.875" margins

// ------------------------------------------------------------------ helpers
const nice = (s) => s.replace(/ -> /g, " → ").replace(/ - /g, " – ").replace(/\.\.\./g, "…");

function runs(text, opts = {}) {
  // **bold** and `code` spans
  const out = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`)/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), ...opts }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, ...opts }));
    else out.push(new TextRun({ text: t.slice(1, -1), font: MONO, size: 19, ...opts }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), ...opts }));
  return out;
}
const P = (text, o = {}) => new Paragraph({ children: runs(text), spacing: { after: 120 }, ...o });
const TOC = [];
const H1 = (text, pageBreak = true) => (TOC.push([1, text]), new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: pageBreak, children: [new TextRun(text)] }));
const H2 = (text) => (TOC.push([2, text]), new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(text)] }));
const H3_ = 0;
const H3 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(text)] });
const bullet = (text) => new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { after: 80 }, children: runs(text) });
let listNo = 0;
const numbered = (items) => { const ref = `num${listNo++}`; NUM_REFS.push(ref);
  return items.map((t) => new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 80 }, children: runs(t) })); };
const NUM_REFS = [];
const code = (lines) => lines.map((l, i) => new Paragraph({
  shading: { type: ShadingType.CLEAR, fill: CODE_BG, color: "auto" },
  spacing: { before: i === 0 ? 60 : 0, after: i === lines.length - 1 ? 140 : 0 },
  indent: { left: 240, right: 240 },
  children: [new TextRun({ text: l, font: MONO, size: 19 })],
}));
const note = (text) => new Paragraph({
  spacing: { before: 60, after: 160 }, indent: { left: 240 },
  border: { left: { style: BorderStyle.SINGLE, size: 18, color: RULE, space: 8 } },
  children: runs(text),
});

const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "D8CBA8" };
function table(widths, header, rows) {
  const total = widths.reduce((a, b) => a + b, 0);
  const mk = (cells, isHead, zebra) => new TableRow({
    tableHeader: isHead,
    children: cells.map((c, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: isHead ? { type: ShadingType.CLEAR, fill: HEAD_BG, color: "auto" } : zebra ? { type: ShadingType.CLEAR, fill: ZEBRA, color: "auto" } : undefined,
      margins: { top: 70, bottom: 70, left: 110, right: 110 },
      borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder },
      children: [new Paragraph({ children: runs(String(c), isHead ? { bold: true } : {}) })],
    })),
  });
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    rows: [mk(header, true, false), ...rows.map((r, i) => mk(r, false, i % 2 === 1))],
  });
}
const gap = () => new Paragraph({ spacing: { after: 120 }, children: [] });

// split "LABEL. rest" / "LABEL: rest" in the in-game guide lines into a bold lead
function guideLine(s) {
  s = nice(s);
  const m = s.match(/^([A-Z][A-Z' ]{2,}[A-Z?]?[.?:])\s+(.*)$/);
  if (m) {
    const lead = m[1].charAt(0) + m[1].slice(1).toLowerCase();
    return `**${lead}** ${m[2]}`;
  }
  return s;
}

// ------------------------------------------------------------------ content
const pages = Object.fromEntries(D.pages.map(([t, lines]) => [t, lines]));
const kids = [];

// ---- title
kids.push(new Paragraph({ spacing: { before: 2200, after: 120 }, alignment: AlignmentType.LEFT,
  children: [new TextRun({ text: "LiveWorld RPG", font: FONT, size: 64, bold: true, color: INK })] }));
kids.push(new Paragraph({ spacing: { after: 240 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: RULE, space: 10 } },
  children: [new TextRun({ text: "Player's Manual", font: FONT, size: 36, color: GOLD })] }));
kids.push(P("Install · Play · Craft · Commands · Uninstall · Build from source"));
kids.push(P(`Version ${VER} · Debian/Ubuntu package \`${DEB}\` · Updated ${TODAY}`));
kids.push(P("LiveWorld RPG is an offline, single-player fantasy RPG with isometric 2.5D graphics, written in Python with pygame. You explore a world of twenty zones and forty towns split between the Alliance and the Horde, shared with over six hundred computer-controlled adventurers. Level from 1 to 100, run dungeons and raids with AI party members, fight in battlegrounds, and gather, craft and trade."));
kids.push(P("**Part 1** covers what the game needs and how to install, update and remove it. **Part 2** is the full player's guide – the same text you get with F1 in the game, plus tables for the controls, classes and zones. **Part 3** lists every crafting recipe. **Part 4** is a reference for every command. **Part 5** explains how to run, test and build the game from its source."));
kids.push(new Paragraph({ spacing: { before: 360, after: 120 }, children: [new TextRun({ text: "Contents", bold: true, size: 28, color: INK })] }));
const TOC_AT = kids.length;

// ================================================================ PART 1
kids.push(H1("Part 1 – Installation"));
kids.push(H2("Requirements"));
kids.push(table([2200, CONTENT - 2200], ["Item", "Details"], [
  ["Operating system", "Debian, Ubuntu, Linux Mint or another Debian-based Linux. The package is architecture-independent (all), so it works on x86-64 and ARM."],
  ["Required packages", "`python3`, `python3-pygame` and `python3-numpy` – all three are installed for you when you install with apt."],
  ["Recommended", "`x11-utils` (helps the game find your screen size for full screen)."],
  ["Disk space", "About 2 MB for the game, plus a small save folder."],
  ["Graphics", "Any desktop. The game starts on Normal graphics and drops to Lite by itself if it runs slowly. Press F9 to switch between Lite and Normal at any time."],
]));
kids.push(gap());
kids.push(H3("Packages in detail"));
kids.push(table([2600, 1800, CONTENT - 4400], ["Package", "Needed?", "What it does for the game"], [
  ["`python3`", "Required", "Runs the game."],
  ["`python3-pygame`", "Required", "Window, graphics, sound and keyboard/mouse input. Without it the launcher stops and tells you how to install it."],
  ["`python3-numpy`", "Required", "Fast textured ground. The game still starts without it, but with plainer ground."],
  ["`x11-utils`", "Recommended", "Lets the game read your screen size for full screen."],
  ["`kdialog` or `zenity`", "Optional", "Desktop dialogs for the uninstaller (otherwise it asks in a terminal)."],
  ["`pkexec` (polkit)", "Optional", "Password prompt for the uninstaller's desktop dialog (otherwise it uses sudo)."],
  ["A terminal emulator", "Optional", "Shows the startup log in a window if the game fails to start."],
]));
kids.push(gap());
kids.push(P("To install the required packages yourself (for example before running from source):"));
kids.push(...code(["sudo apt install python3 python3-pygame python3-numpy x11-utils"]));

kids.push(H2("Step 1 – Install the package"));
kids.push(P("Open a terminal in the folder that holds the file (usually Downloads) and run:"));
kids.push(...code(["cd ~/Downloads", `sudo apt install ./${DEB}`]));
kids.push(P("The `./` matters: it tells apt to install the local file and fetch python3-pygame for you. Type your password when asked and answer **Y** to confirm."));
kids.push(note(`**Alternative:** if you used \`sudo dpkg -i ${DEB}\` and it complained about missing dependencies, run \`sudo apt -f install\` to pull them in. You can also double-click the .deb in your file manager to open it in your software installer, then click Install.`));
kids.push(P("To check the download first, keep the SHA256SUMS file next to the package and run:"));
kids.push(...code([`sha256sum -c --ignore-missing SHA256SUMS-${VER}.txt`]));

kids.push(H2("Step 2 – Launch the game"));
kids.push(bullet("**From the menu:** open your applications menu and look for **LiveWorld RPG** under Games."));
kids.push(bullet("**From a terminal:** run `liveworld-rpg`."));
kids.push(P("A loading screen appears while the world is built. The first start takes longest; later starts use a cached world map and are faster. Only one copy of the game runs at a time – starting it again just tells you it is already open."));

kids.push(H2("Step 3 (optional) – Create a character from the terminal"));
kids.push(P("You normally create your character in the game. There is also a command-line helper:"));
kids.push(...code(["liveworld-create-character NAME Alliance|Horde CLASS [SPEC]"]));
kids.push(P("Example: `liveworld-create-character Aria Alliance Paladin Holy`. Run it with no arguments and it asks each question in turn. An existing hero keeps its name and faction."));

kids.push(H2("Updating to a newer version"));
kids.push(P(`Install the new .deb the same way (\`sudo apt install ./liveworld-rpg_<version>_all.deb\`). Your saves are kept because they live in your home folder, not in the package. Saves from before 0.36 keep your hero; if the hero stood somewhere that changed on the new world map, they wake in a town of their own side.`));

kids.push(H2("Uninstalling"));
kids.push(P("Open **Uninstall LiveWorld RPG** from the applications menu (or right-click the game's menu entry), or run:"));
kids.push(...code(["liveworld-uninstall"]));
kids.push(P("It asks whether to **Remove everything** (the game plus your characters, saves and settings) or **Keep my saves** (only the program). A running game is saved and closed first. To remove only the program by hand:"));
kids.push(...code(["sudo apt remove liveworld-rpg"]));
kids.push(P("This leaves your save data. To delete it as well, remove `~/.local/share/liveworld-rpg` and `~/.local/state/liveworld-rpg`."));

kids.push(H2("Where files go"));
kids.push(table([4300, CONTENT - 4300], ["Path", "What it holds"], [
  ["`/usr/bin/liveworld-rpg`", "Game launcher"],
  ["`/usr/bin/liveworld-create-character`", "Command-line character helper"],
  ["`/usr/bin/liveworld-uninstall`", "Uninstaller (also in the applications menu)"],
  ["`/usr/lib/liveworld-rpg/`", "Game code (Python)"],
  ["`/usr/share/doc/liveworld-rpg/GUIDE.md`", "The player's guide as plain text (the same as F1 in the game)"],
  ["`~/.local/share/liveworld-rpg/`", "Your saves, settings and world data (override with the LIVEWORLD_DATA environment variable)"],
  ["`~/.local/state/liveworld-rpg/startup.log`", "Startup log – useful when something goes wrong"],
]));
kids.push(gap());

kids.push(H2("Troubleshooting"));
kids.push(table([3000, CONTENT - 3000], ["Problem", "Fix"], [
  ["A terminal window says “python3-pygame is unavailable”", "Run `sudo apt install python3-pygame`, then start the game again."],
  ["The game closes right after starting", "Read the log: `cat ~/.local/state/liveworld-rpg/startup.log`. The last lines show the error. The launcher also opens a terminal with the log when it can."],
  ["“LiveWorld RPG is already running”", "Another copy is open with the same save. Switch to its window, or close it first."],
  ["Full screen hides the HUD under a desktop panel or top bar", "Press Esc (or the gear button) → Settings → Display, and choose Borderless or Window."],
  ["The game runs slowly", "Press F9 to switch to Lite graphics. The game also does this by itself on slow PCs."],
  ["Nights are too dark", "Raise Brightness in Settings."],
  ["The menu entry does not appear", "Log out and back in, or start the game from a terminal with `liveworld-rpg`."],
]));

// ================================================================ PART 2
kids.push(H1("Part 2 – How to Play"));
kids.push(H2("Your first ten minutes"));
kids.push(...numbered([
  "**Create a character.** Pick a name, a faction (Alliance or Horde) and one of 12 classes. Alliance heroes start at Lionsreach in Greenfields, Horde heroes at Grimhold in Ashen Vale. Both zones are levels 1–10.",
  "**Move.** Click the ground to walk, or use W A S D / arrow keys.",
  "**Fight.** Click a monster to target it and auto-attack. Tab cycles targets; Space or E attacks the nearest one. Keys 1–0 use your class skills.",
  "**Get quests.** Find the Quest Giver by the notice board in town (name ends in “(Quests)”, marked with **!**). Press F next to them. Come back to the same giver when the marker shows **?** to hand in.",
  "**Loot and heal.** Press Z to pick up loot, H for a health potion, J for a mana potion.",
  "**Spend points.** Each level gives 3 stat points (U) and 1 spell point (K).",
  "**Read the in-game guide** any time with F1.",
]));

kids.push(H2("Controls"));
const cw = [1500, Math.floor((CONTENT - 3000) / 2), 1500, CONTENT - 3000 - Math.floor((CONTENT - 3000) / 2)];
kids.push(table(cw, ["Key", "Action", "Key", "Action"], [
  ["Click / WASD / arrows", "Move", "F", "Talk, interact, gather, enter dungeons, use buildings"],
  ["Click a monster", "Target and auto-attack", "Tab", "Next target (on the map: zoom in / out)"],
  ["Space / E", "Attack target (or nearest)", "1 – 0", "Class skills"],
  ["Shift + 1 – 6", "High-level skills (levels 30–80)", "Z", "Pick up loot"],
  ["H", "Health potion", "J", "Mana potion"],
  ["V", "Eat food (out of combat)", "Y", "Buff scroll, Health Bread or Sunwine"],
  ["T", "Teleport scroll", "G", "Fish (press again when a fish bites)"],
  ["X", "Mount / dismount", "I", "Bag and equipment"],
  ["C", "Class window", "K", "Skills (ranks are raised at a Skill Shop)"],
  ["U", "Character stats", "Q", "Quest log"],
  ["M", "World map", "` (backquote)", "Collapse / expand chat"],
  ["O", "Leave a dungeon, raid or battleground (out of combat)", "N", `Skip the ${D.rest}-second rest after a dungeon or raid boss`],
  ["F1", "This guide", "F9", "Switch between Lite and Normal graphics"],
  ["F11", "Full screen", "Esc / gear button", "Settings (graphics, brightness, sound, display)"],
]));
kids.push(gap());
kids.push(H3("Keys on the world map (M)"));
kids.push(table([2600, CONTENT - 2600], ["Key", "Action"], [
  ["W A S D / arrows", "Pan the map"], ["+ / –", "Zoom in / out"], ["Tab", "Centre on you, or back to the whole world"],
  ["0", "Show the whole world"], ["M or Esc", "Close the map"],
]));
kids.push(H3("Other screens"));
kids.push(table([2600, CONTENT - 2600], ["Key", "Action"], [
  ["1, R or Enter", "Difficulty picker at a dungeon or raid entrance: Regular"],
  ["2 or H", "Difficulty picker: Heroic"],
  ["P", "Close the battleground screen"],
  ["Esc", "Closes whatever is open; then clears your target, your walk destination or a fishing cast; then opens Settings"],
  ["Enter / Backspace", "Character creation: confirm / delete a letter of the name"],
]));
kids.push(P("The buttons on the bottom bar do the same as the keys: **Bag I**, **Skills K**, **Hero C**, **Stats U**, **Gear**, **Map M**, **Quest Q**, **Guide F1**, **Mats** (your crafting materials) and **Party**. Inside a dungeon or raid the **Leave (O)** and **Ready (N)** buttons sit at the top right."));
kids.push(gap());

kids.push(H2("Classes and roles"));
kids.push(P("Each class wears one armour type and only its own weapon types; unusable items show red in the bag. Paladin, Shaman and Druid choose a Tank, Healer or DPS specialization. Juggernaut is a pure tank; the other classes fill a damage slot in groups."));
const ROLE = { Warrior: "Melee DPS", Ranger: "Ranged DPS", Mage: "Caster DPS", Cleric: "Caster, self-heals", Rogue: "Melee DPS",
  Berserker: "Melee DPS", Warlock: "Caster DPS", Monk: "Melee DPS", Juggernaut: "Tank" };
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
kids.push(table([1600, 3300, 1300, CONTENT - 6200], ["Class", "Role", "Armour", "Weapons"],
  D.classes.map((c) => [c,
    D.hybrid[c] ? `${D.hybrid[c].map((s) => s[1]).join(" / ")} (${D.hybrid[c].map((s) => s[0]).join(", ")})` : ROLE[c],
    cap(D.armor[c]), D.wtypes[c].map(cap).join(", ")])));
kids.push(gap());

kids.push(H2("The world and where to level"));
kids.push(P("Each side has its own zone for every 10-level band: the Alliance in the west, the Horde in the east, with the front lines in the middle. Your own side's towns are safe; the other side's towns send their City Watch after you. Zone names are coloured by difficulty: green is easy, yellow fair, red dangerous. Levelling is deliberately slow, so mix kills, quests and dungeons."));
const bands = [];
for (const [name, fac, lo, hi] of D.areas) {
  let b = bands.find((x) => x.lo === lo); if (!b) bands.push(b = { lo, hi, A: [], H: [] });
  (fac === "Alliance" ? b.A : b.H).push(name);
}
kids.push(table([1700, Math.floor((CONTENT - 1700) / 2), CONTENT - 1700 - Math.floor((CONTENT - 1700) / 2)],
  ["Levels", "Alliance zone", "Horde zone"], bands.map((b) => [`${b.lo}–${b.hi}`, b.A.join(", "), b.H.join(", ")])));
kids.push(gap());

// ---- the in-game guide, page by page (Getting started and Gear by class are covered by the tables above)
const SKIP = new Set(["Getting started", "Gear by class"]);
for (const [title, lines] of D.pages) {
  if (SKIP.has(title)) continue;
  kids.push(H2(title));
  if (title === "The Mythic weapon") {
    const steps = lines.find((l) => l.startsWith("Steps:"));
    const weapons = lines.filter((l) => /^[A-Z][a-z]+: Voidreaver/.test(l));
    for (const l of lines) if (l !== steps && !weapons.includes(l) && !l.startsWith("Progress")) kids.push(bullet(guideLine(l)));
    kids.push(H3("Steps"));
    kids.push(...numbered(steps.replace(/^Steps:\s*/, "").split(/\s*\(\d+\)\s*/).filter(Boolean).map(nice)));
    kids.push(H3("The weapon for each class"));
    kids.push(table([2400, CONTENT - 2400], ["Class", "Mythic weapon"], weapons.map((l) => l.split(": "))));
    kids.push(gap());
    const prog = lines.find((l) => l.startsWith("Progress")); if (prog) kids.push(P(nice(prog)));
    continue;
  }
  for (const l of lines) kids.push(bullet(guideLine(l)));
}

kids.push(H2("Tips"));
for (const t of [
  "Stay in zones whose name shows green or yellow; red zones will kill you quickly.",
  "Elite monsters have gold name plates and give 3× rewards, but hit much harder.",
  "Keep a Teleport scroll (T) for getting back to town, and keep your savings in the Vault – dying in the open world costs 5% of the gold you carry.",
  "Eat cooked fish (V) between fights instead of spending potions.",
  "Read your quest log (Q): it shows the distance and direction to each target zone and the town to return to.",
  "Gear is a grind on purpose: raid set pieces drop in about one clear in three, and a full Gladiator set takes about 45 won 4v4 battlegrounds or 15 won 12v12 battlegrounds.",
]) kids.push(bullet(t));

// ================================================================ PART 3
kids.push(H1("Part 3 – Crafting Reference"));
kids.push(P("Every recipe below comes straight from the game's data, so the numbers match what the crafting windows show. In town, press F at a station (or click it) to open it. A recipe you cannot make yet tells you why: the level it needs, missing ingredients or not enough gold."));
kids.push(H2("Crafting stations"));
kids.push(table([2700, CONTENT - 2700], ["Station", "What you make there"], [
  ["Inn – Alchemy tab", "Health and mana potions, teleport and buff scrolls, Weave Cloth"],
  ["Inn – Cooking tab", "Food you eat with V, and Health Bread (Y)"],
  ["Inn or Fishing Hut – Elixirs tab", "Elixirs, potions and flasks (the herb and fish of one zone band)"],
  ["Forge", "Weapons, armor, helms and necklaces for your class; upgrades +1 to +5; the Mythic weapon"],
  ["Jeweler's Kiln", "Cut jewels; make rings and necklaces; open sockets and set jewels into gear"],
  ["Apothecary / General Store", "Buy Cloth, Leather, Iron Ore and Arcane Dust when you are short"],
]));
kids.push(gap());
kids.push(H2("Materials"));
kids.push(table([2400, 1100, CONTENT - 3500], ["Material", "Value", "Where it comes from"], [
  ["Cloth Scrap", `${D.mats["Mat:Cloth Scrap"]}g`, "Humanoid monsters; General Store; Weave Cloth at the Inn; sunken caches"],
  ["Leather Scrap", `${D.mats["Mat:Leather Scrap"]}g`, "Skinning beast carcasses (F); General Store; sunken caches"],
  ["Iron Ore", `${D.mats["Mat:Iron Ore"]}g`, "Ore veins (F); humanoid monsters; Apothecary"],
  ["Arcane Dust", `${D.mats["Mat:Arcane Dust"]}g`, "Undead and magical monsters; Silver, Gold and Mithril veins; Apothecary"],
  ["Spirit Essence", `${D.mats["Mat:Spirit Essence"]}g`, "Elites, dungeon bosses, high ore veins, sunken caches – never sold in shops"],
  ["Herbs", "–", "Glowing plants in every zone (green squares on the minimap); each zone has its own herb"],
  ["Fish", "–", "Press G beside water; each zone has its own fish"],
]));
kids.push(gap());
const need = (a) => a.map(([i, n]) => `${n} ${i}`).join(", ");
const rec = (rows) => table([2700, 2500, 900, CONTENT - 6100], ["Recipe", "Ingredients", "Gold", "Effect"],
  rows.map((r) => [r.name + (r.lvl > 1 ? ` (level ${r.lvl}+)` : ""), need(r.needs), r.gold ? n0(r.gold) : "–", nice(r.desc)]));
kids.push(H2("Alchemy (Inn)"));
kids.push(P("“Any herb” means herbs from any zone. Press H for a health potion, J for mana, T for a teleport scroll and Y for a buff scroll."));
kids.push(rec(D.alchemy)); kids.push(gap());
kids.push(H2("Cooking (Inn)"));
kids.push(P("Eat with V while out of combat. You keep healing every second until the food runs out or you are hit."));
kids.push(rec(D.cooking)); kids.push(gap());
kids.push(H2("Elixirs, potions and flasks"));
kids.push(P("Each brew uses the herb and the fish of the zone band of its level, so the strongest brews need ingredients from the highest zones. Most recipes make two; flasks make one. Drink with Y or from the Bag."));
for (const c of [...new Set(D.brews.map((b) => b.cat))]) {
  kids.push(H3(c));
  kids.push(table([2600, 800, 3000, 800, CONTENT - 7200], ["Brew", "Level", "Ingredients", "Gold", "Effect"],
    D.brews.filter((b) => b.cat === c).map((b) => [`${b.name} ×${b.n}`, String(b.lvl), need(b.needs), n0(b.gold), nice(b.desc)])));
}
kids.push(gap());
kids.push(H2("The Forge"));
kids.push(P("In each tier the Forge makes a weapon, an armor, a helm and a necklace for your class. The item's power is set by your level when you craft it, so the same recipe made at a higher level gives a stronger item."));
kids.push(table([1800, 1300, 800, 1500, 1200, 1400, CONTENT - 8000], ["Tier", "Rarity", "Level", "Main material", "Arcane Dust", "Spirit Essence", "Gold"],
  D.forge.map((t) => [t.name, t.rarity, String(t.lvl), String(t.main), t.dust ? String(t.dust) : "–", t.ess ? String(t.ess) : "–", n0(t.gold)])));
kids.push(note("**Which main material?** Armor and helms use your armor type: Cloth Scrap for cloth classes, Leather Scrap for leather classes, Iron Ore for mail and plate. Weapons use Iron Ore (Arcane Dust for caster weapons), and from Superior up also a few Leather Scrap (Cloth Scrap for caster weapons). Necklaces use Arcane Dust."));
kids.push(bullet("**Upgrade +5 tab:** any piece of gear can be raised from +1 to +5. Each step adds 6 power and 10% of the item's own bonus; +4 and +5 also need Legendary Essence."));
kids.push(bullet("**Mythic weapon:** the last step of the Mythic quest (level 91+) is done at the Forge – see “The Mythic weapon” in Part 2."));
kids.push(H2("Jewelcrafting (Jeweler's Kiln)"));
kids.push(P("Cut a jewel from Iron Ore, Arcane Dust and gold. Then wear it as a ring (1.5× its bonus, two rings worn) or a necklace (2×, one worn), or set it into a socket in your gear."));
kids.push(table([2600, CONTENT - 2600], ["Gem", "Bonus"], D.gems.map(([g, b]) => [g, cap(b)])));
kids.push(gap());
kids.push(table([1600, 800, 3100, CONTENT - 5500], ["Quality", "Level", "Cut a jewel", "Ring or necklace (the jewel plus…)"],
  D.qualities.map((q) => [q.name, String(q.lvl), `${q.cut[0]} Iron Ore, ${q.cut[1]} Arcane Dust, ${n0(q.cut[2])} gold`, `${q.jewelry[0]} Iron Ore, ${n0(q.jewelry[1])} gold`])));
kids.push(gap());
kids.push(H3("Opening sockets"));
kids.push(table([1300, 900, 1300, 1400, 1600, CONTENT - 6500], ["Socket", "Level", "Iron Ore", "Arcane Dust", "Spirit Essence", "Gold"],
  D.sockets.map((s, i) => [["1st", "2nd", "3rd"][i], String(s[0]), String(s[1]), String(s[2]), s[3] ? String(s[3]) : "–", n0(s[4])])));
kids.push(note("Taking a jewel out of a socket destroys it, so choose before you set it."));

// ================================================================ PART 4
kids.push(H1("Part 4 – Command Reference"));
kids.push(P("The game is played with the keyboard and mouse – Part 2 lists every key, and there are no typed chat commands. These are the commands you run in a terminal."));
kids.push(H2("Game commands"));
kids.push(table([3900, CONTENT - 3900], ["Command", "What it does"], [
  ["`liveworld-rpg`", "Start the game (the same as the menu entry). Writes `~/.local/state/liveworld-rpg/startup.log` and keeps the previous run's log as `startup.log.1`."],
  ["`liveworld-create-character`", "Create a hero from the terminal; it asks for each detail in turn."],
  ["`liveworld-create-character NAME FACTION CLASS [SPEC]`", "The same in one line. FACTION is Alliance or Horde."],
  ["`liveworld-uninstall`", "Remove the game, and optionally your saves (it asks first)."],
]));
kids.push(gap());
kids.push(H3("liveworld-create-character"));
kids.push(P(`Classes: ${D.classes.join(", ")}. Specs (Paladin, Shaman and Druid only): ` +
  Object.entries(D.hybrid).map(([c, ss]) => `${c} – ${ss.map((x) => `${x[0]} (${x[1]})`).join(", ")}`).join("; ") + "."));
kids.push(...code(["liveworld-create-character Aria Alliance Paladin Holy", "liveworld-create-character Grok Horde Juggernaut"]));
kids.push(P("Close the game first – the helper will not run while the game is open. If you already have a hero, it keeps the name and faction and changes only the class."));
kids.push(H2("Package commands"));
kids.push(table([4700, CONTENT - 4700], ["Command", "What it does"], [
  [`\`sudo apt install ./${DEB}\``, "Install or update from the downloaded file (pulls in the required packages)"],
  [`\`sudo dpkg -i ${DEB}\``, "Install without apt; follow with `sudo apt -f install` if it reports missing packages"],
  [`\`sha256sum -c --ignore-missing SHA256SUMS-${VER}.txt\``, "Check the download against its checksum"],
  ["`dpkg -s liveworld-rpg`", "Show the installed version"],
  ["`sudo apt remove liveworld-rpg`", "Remove the program, keep your saves"],
  ["`sudo apt purge liveworld-rpg`", "Remove the program and its system files (saves in your home folder stay)"],
  ["`rm -rf ~/.local/share/liveworld-rpg ~/.local/state/liveworld-rpg`", "Delete your saves, settings and logs – this cannot be undone"],
]));
kids.push(gap());
kids.push(H2("Environment variables"));
kids.push(table([3200, CONTENT - 3200], ["Variable", "Effect"], [
  ["`LIVEWORLD_DATA`", "Folder for saves, settings and world data (default `~/.local/share/liveworld-rpg`). Handy for keeping a second, separate world."],
  ["`XDG_STATE_HOME`", "Where the `liveworld-rpg` log folder goes (default `~/.local/state`)."],
  ["`SDL_VIDEODRIVER`, `SDL_AUDIODRIVER`", "Standard SDL settings; `dummy` runs without a screen or sound (the tests use this)."],
]));
kids.push(...code(["LIVEWORLD_DATA=~/lw-second-world liveworld-rpg"]));

// ================================================================ PART 5
kids.push(H1("Part 5 – Running and Building from Source"));
kids.push(P(`The source archive \`liveworld-rpg-${VER}-source.tar.gz\` holds the whole project: the game, the packaging, the tests, this manual's generator and the build script.`));
kids.push(H2("Run from source"));
kids.push(...code([`tar xzf liveworld-rpg-${VER}-source.tar.gz`, `cd liveworld-rpg-${VER}`, "sudo apt install python3 python3-pygame python3-numpy",
  "PYTHONPATH=usr/lib/liveworld-rpg python3 -m liveworld_rpg.run"]));
kids.push(H2("Run the tests"));
kids.push(...code(["python3 tests/smoke_test.py                  # everything, about 6 minutes", "python3 tests/smoke_test.py RestAfterBosses  # one group"]));
kids.push(P("The tests use a throwaway save folder and SDL's dummy drivers, so they never touch your saves and need no screen. Groups include Package, WorldBoot, ArenaMaps, ArenaMatches, Dungeons, RestAfterBosses and Render."));
kids.push(H2("Build a release"));
kids.push(...code(["./build.sh           # build", "./build.sh --test    # run the tests first and stop if any fail"]));
kids.push(P("The build writes to `dist/`: the `.deb`, the source `.tar.gz`, this manual (`LiveWorld-RPG-Guide.docx`) and `SHA256SUMS-<version>.txt`. It needs `dpkg-deb`; the manual also needs Node.js with the `docx` module (`npm install docx`) and is skipped without it."));
kids.push(H2("Releasing a new version"));
kids.push(...numbered([
  "Change the version in `DEBIAN/control`, `VERSION` in `game.py`, `__version__` in `__init__.py`, and add a `<release>` entry to `usr/share/metainfo/liveworld-rpg.metainfo.xml`.",
  "Add a changelog line at the end of `DEBIAN/control`.",
  "Run `./build.sh --test`. The tests fail if the version numbers disagree.",
]));

// static contents list (a Word TOC field shows empty until Word refreshes it)
kids.splice(TOC_AT, 0, ...TOC.map(([lvl, t]) => new Paragraph({
  spacing: { before: lvl === 1 ? 140 : 0, after: 30 }, indent: { left: lvl === 1 ? 0 : 360 },
  children: [new TextRun({ text: t, bold: lvl === 1, size: lvl === 1 ? 22 : 20, color: lvl === 1 ? INK : "5A4A32" })],
})));

// ------------------------------------------------------------------ document
const doc = new Document({
  creator: "LiveWorld RPG Project",
  title: TITLE,
  styles: {
    default: { document: { run: { font: FONT, size: 21, color: INK }, paragraph: { spacing: { line: 276 } } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 36, bold: true, color: INK },
        paragraph: { spacing: { before: 0, after: 240 }, outlineLevel: 0,
          border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: RULE, space: 6 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 28, bold: true, color: GOLD },
        paragraph: { spacing: { before: 320, after: 140 }, outlineLevel: 1, keepNext: true } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 23, bold: true, color: INK },
        paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 2, keepNext: true } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 460, hanging: 280 } } } }] },
      ...NUM_REFS.map((ref) => ({ reference: ref, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 460, hanging: 320 } } } }] })),
    ],
  },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: 15840 }, margin: { top: 1200, bottom: 1200, left: MARGIN, right: MARGIN } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: TITLE, size: 16, color: "8C7E66" })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "8C7E66" })] })] }) },
    children: kids,
  }],
});

Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(outPath, buf); console.log("wrote", outPath); });
