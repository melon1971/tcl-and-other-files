"""Write the game data the Word guide is built from (version, F1 guide pages, zones, classes, recipes) as JSON.
    python3 guide/export_data.py OUT.json
Run with PYTHONPATH pointing at usr/lib/liveworld-rpg.  1.0.18: needs no pygame (the version comes from __init__)."""
import json, os, sys, tempfile
from pathlib import Path

os.environ.setdefault("LIVEWORLD_DATA", tempfile.mkdtemp())
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
import liveworld_rpg   # noqa: E402
from liveworld_rpg import guide, engine as E, rpg, brews, jewels, instance as I   # noqa: E402

# a throwaway hero, only to read the Inn's recipe lists exactly as the game shows them
E.DATA = Path(tempfile.mkdtemp()); E.DB = E.DATA / "world.db"
w = E.World(); w.create_character("Guide", "Alliance", "Warrior")
def rows(rs):
    lab = lambda i: {"herb*": "any herb", "fish*": "any fish"}.get(i, i.split(":", 1)[-1])
    return [{"name": r["name"], "desc": r["desc"], "needs": [(lab(i), n) for i, n in r["raw"]], "gold": r["gold"], "lvl": r["minlvl"]} for r in rs]
alchemy, cooking = rows(w._alchemy_recipes()), rows(w._cooking_recipes())
w.close()

json.dump({"version": liveworld_rpg.__version__, "pages": guide.PAGES,
           "areas": [(a[0], a[5], a[6], a[7]) for a in E.AREAS],
           "classes": list(E.CLASSES), "armor": rpg.CLASS_ARMOR, "wtypes": rpg.CLASS_WTYPES, "hybrid": E.HYBRID_SPECS,
           "alchemy": alchemy, "cooking": cooking,
           "brews": [{"name": b["name"], "cat": b["cat"], "lvl": b["lvl"], "n": b["n"], "desc": b["desc"], "gold": b["gold"] * E.World.BUY_MULT,
                      "needs": [(i.split(":", 1)[-1], n) for i, n in b["needs"]]} for b in brews.BREWS],
           "forge": [{"name": t[1], "rarity": t[2], "lvl": t[3], "main": t[4], "dust": t[5], "ess": t[6], "gold": t[7] * E.World.BUY_MULT} for t in rpg.FORGE_TIERS],
           "gems": [(g, jewels.GEMS[g][1]) for g in jewels.GEM_ORDER],
           "qualities": [{"name": q[0], "lvl": q[1], "cut": jewels.cut_cost(i), "jewelry": jewels.jewelry_cost(i)} for i, q in enumerate(jewels.QUALITIES)],
           "sockets": jewels.SOCKET_COSTS, "mats": rpg.MATS,
           "rest": I.DUNGEON_BOSS_REST},
          open(sys.argv[1], "w"), indent=1, default=str)
