"""1.0.35: Auto-play - your hero plays dungeons, raids and battlegrounds by itself (press . to turn it on or off).

1.0.33's Autofight only swung at whatever stood next to you.  Once a pack was dead you stood still, and so did the
whole party: the AI tank never leads more than 11 tiles ahead of you, and when YOU are the tank nobody leads at all.
Auto-play plays the whole run:

  dungeons and raids
    * plays your role: a Tank grabs the boss, picks up loose mobs and taunts back anything that peels onto the party;
      a Healer keeps the party up (your heals also heal the most wounded ally) and only attacks with spare mana;
      DPS kill the adds first, then whatever the party is focusing
    * interrupts interruptible boss casts with a stun, silence or charge, and braces (shield / armour) for Crushing Blow
    * steps out of Rain of Fire and Dragon Breath, runs into the Inferno safe circle, and runs from the party with a Void Mark
    * drinks Health Potions under 35% health and Mana Potions under 20% mana
    * after a fight: picks up the loot, skips the rest once everyone is healthy, then moves on - following the AI tank,
      or leading to the next pack yourself when you are the tank (or the tank is dead)
  battlegrounds
    * Capture the Flag: grabs the enemy flag, runs it home, hunts whoever stole yours, escorts a team-mate's carry
    * Domination: goes for the points your team doesn't hold (the nearest, least defended first) and stands on them
    * Team Deathmatch: pushes the nearest, most wounded enemy
    * breaks off to a healing shrine when low, and returns once healed

think(w) is the brain; it only reads the world (and, as a tank, taunts).  The game (game.py autofight) carries out the
order with its own movement and spell effects; drive(w, ticks) carries it out headlessly for the tests.
"""
import math

MELEE = ("Warrior", "Rogue", "Berserker", "Monk", "Juggernaut")
SKIP_KINDS = ("sprint", "vanish")          # Blink-style dashes go where you last walked; Vanish drops the tank's threat


def _d(ax, ay, bx, by):
    return math.hypot(ax - bx, ay - by)


def _toward(px, py, gx, gy, stop):
    """The point `stop` tiles short of (gx, gy) on the way from (px, py)."""
    d = _d(px, py, gx, gy)
    if d <= stop or d < .01: return px, py
    k = (d - stop) / d
    return px + (gx - px) * k, py + (gy - py) * k


def role_of(w):
    return w.spec_role() or "DPS"


def _order():
    return {"mode": "idle", "goal": None, "target": None, "fight": False, "cast": None, "potion": False,
            "mana_potion": False, "ready": False, "loot": False, "note": "", "interrupt": None, "brace": False}


# ------------------------------------------------------------------ the brain
def think(w):
    o = _order()
    inst = w.inst
    if inst is None: return o
    if inst.player_down(): o["mode"] = "down"; return o
    p = w.player
    mx = max(1, w._effective_maxhp()); mm = max(1, w.max_mana())
    hpf = p["hp"] / mx; mf = p.get("mana", mm) / mm
    o["potion"] = hpf < .35; o["mana_potion"] = mf < .2
    if getattr(inst, "is_arena", False): _arena(w, inst, o, hpf)
    else: _dungeon(w, inst, o, hpf, mf)
    o["cast"] = _pick_cast(w, inst, o, hpf, mf)
    return o


# ------------------------------------------------------------------ dungeons and raids
def _unsafe(inst, x, y):
    for h in inst.hazards:
        k = h["kind"]
        if k == "fire" and _d(x, y, h["x"], h["y"]) <= h["r"] + .35: return True
        if k == "breath" and inst._in_cone(x, y, h["x"], h["y"], h["ang"], h["half"] + .08, h["r"]) and not inst.blocked_los(h["x"], h["y"], x, y): return True
        if k == "inferno" and _d(x, y, h["x"], h["y"]) > h["r"] - .5: return True
    return False


def _safe_spot(inst, px, py):
    """The nearest floor spot that is out of every hazard (and inside the Inferno circle when one is up)."""
    cands = []
    for h in inst.hazards:
        if h["kind"] == "inferno":
            for i in range(8):
                a = i / 8 * math.tau
                cands.append((h["x"] + math.cos(a) * .9, h["y"] + math.sin(a) * .9))
            cands.append((h["x"], h["y"]))
    for r in (2.0, 3.2, 4.6, 6.2, 8.0):
        for i in range(16):
            a = i / 16 * math.tau
            cands.append((px + math.cos(a) * r, py + math.sin(a) * r))
    ok = [c for c in cands if (int(c[0]), int(c[1])) in inst.floor and not _unsafe(inst, c[0], c[1])]
    return min(ok, key=lambda c: _d(px, py, c[0], c[1])) if ok else None


def _mark_spot(inst, px, py, al):
    """Void Mark: the floor spot (within ~9 tiles) furthest from every ally."""
    if not al: return None
    best = None
    for r in (4.0, 6.5, 9.0):
        for i in range(16):
            a = i / 16 * math.tau
            x, y = px + math.cos(a) * r, py + math.sin(a) * r
            if (int(x), int(y)) not in inst.floor or _unsafe(inst, x, y): continue
            near = min(_d(x, y, b.x, b.y) for b in al)
            if best is None or near > best[0]: best = (near, x, y)
    return (best[1], best[2]) if best else None


def _dungeon_target(w, inst, role, live):
    p = w.player; px, py = p["x"], p["y"]
    bosses = [m for m in live if m.role == "boss"]
    adds = [m for m in live if m.role == "add"]
    if role == "Tank":
        if bosses and not inst.boss_immune(bosses[0]): return bosses[0]
        if adds: return min(adds, key=lambda m: _d(px, py, m.x, m.y))
        if bosses: return bosses[0]
        loose = [m for m in live if getattr(m, "tgt", None) != "player"]
        return min(loose or live, key=lambda m: _d(px, py, m.x, m.y))
    f = inst._focus()
    if f is not None: return f
    ok = [m for m in live if not (m.role == "boss" and inst.boss_immune(m))]
    return min(ok, key=lambda m: _d(px, py, m.x, m.y)) if ok else None


def _taunt(w, inst, live):
    """You are the tank: every two seconds, pull anything chewing on the party back onto you (like the AI tank does)."""
    now = w.tick
    if now - getattr(inst, "_ap_taunt", -99) < 8: return
    p = w.player
    peeled = [m for m in live if getattr(m, "tgt", None) != "player" and _d(m.x, m.y, p["x"], p["y"]) < 11]
    if not peeled: return
    inst._ap_taunt = now
    for m in peeled:
        if inst.fx.random() < .85: m.tgt = "player"


def _loot_near(w, r=14):
    p = w.player
    try:
        rows = w.db.execute("SELECT id,x,y FROM ground_loot WHERE expires>? AND (x-?)*(x-?)+(y-?)*(y-?)<=? ORDER BY id",
                            (w.tick, p["x"], p["x"], p["y"], p["y"], r * r)).fetchall()
    except Exception:
        return []
    return [(row["id"], row["x"], row["y"]) for row in rows]


def _dungeon(w, inst, o, hpf, mf):
    p = w.player; px, py = p["x"], p["y"]; now = w.tick
    role = role_of(w)
    al = inst.alive_allies()
    live = inst._live_mobs()
    # 1. stay out of the bad stuff
    if inst.mark:
        spot = _mark_spot(inst, px, py, al)
        if spot and min((_d(px, py, b.x, b.y) for b in al), default=99) < 7:
            o.update(mode="dodge", goal=spot, note="Void Mark - running from the party")
    if o["goal"] is None and inst.hazards and _unsafe(inst, px, py):
        spot = _safe_spot(inst, px, py)
        if spot: o.update(mode="dodge", goal=spot, note="dodging")
    # 2. boss casts
    b = inst.boss_actor()
    c = getattr(b, "cast", None) if b is not None else None
    if c:
        if c.get("interruptible"): o["interrupt"] = b
        if c["kind"] == "buster" and c.get("tgt") == "player": o["brace"] = True
    # 3. fight
    if live:
        if role == "Tank": _taunt(w, inst, live)
        t = _dungeon_target(w, inst, role, live)
        o["target"] = t
        if o["goal"] is None and t is not None:
            o.update(mode="fight", fight=True)
        return
    if o["goal"] is not None: return
    # 4. after the fight: loot, rest, move on
    loot = _loot_near(w)
    if loot:
        lid, lx, ly = min(loot, key=lambda r: _d(px, py, r[1], r[2]))
        if _d(px, py, lx, ly) <= 5.5: o.update(mode="loot", loot=True, note="looting")
        else: o.update(mode="loot", goal=(lx, ly), note="picking up loot")
        return
    nr = inst._next_room()
    if inst.done or nr is None:
        o.update(mode="done", note="cleared - press O to leave"); return
    party_ok = all(a.hp >= a.maxhp * .9 for a in al) and hpf >= .85
    if now < inst.rest_until:
        if party_ok and mf >= .5: o["ready"] = True
        o.update(mode="wait", note="resting"); return
    tank = inst.mt if (inst.mt is not None and not inst.mt.dead) else None
    if role == "Tank" or tank is None:
        # you lead: wait for the party to recover first, then walk to the next pack (or into the boss room)
        if not (all(a.hp >= a.maxhp * .7 for a in al) and hpf >= .7 and mf >= .35):
            o.update(mode="wait", note="waiting for the party to recover"); return
        if al and sum(_d(px, py, a.x, a.y) for a in al) / len(al) > 12:
            o.update(mode="wait", note="waiting for the party"); return
        mobs = [inst.actors[m] for m in nr["mobs"] if inst.actors[m].hp > 0]
        if nr["type"] == "trash" and mobs:
            m = min(mobs, key=lambda m: _d(px, py, m.x, m.y))
            o.update(mode="lead", goal=_toward(px, py, m.x, m.y, 1.2), note="leading to the next pack")
        else:
            o.update(mode="lead", goal=(nr["cx"], nr["cy"]), note="into the boss room")
        return
    # the AI tank leads (it waits for you within 11 tiles): stay a few steps behind it
    o.update(mode="follow", goal=_toward(px, py, tank.x, tank.y, 3.0), note=f"following {tank.name}")


# ------------------------------------------------------------------ battlegrounds
def _arena(w, inst, o, hpf):
    p = w.player; px, py = p["x"], p["y"]
    foes = [r for r in inst.reds if not r.dead]
    carrying = inst.carry_player is not None
    # a healing shrine when low (a flag carrier keeps running home)
    if inst.shrines:
        healing = getattr(inst, "_ap_heal", False)
        if not healing and hpf < .4 and not carrying: healing = True
        elif healing and (hpf >= .9 or carrying): healing = False
        inst._ap_heal = healing
        if healing:
            sx, sy = min(inst.shrines, key=lambda s: _d(px, py, s[0], s[1]) + 6 * sum(1 for f in foes if _d(f.x, f.y, s[0], s[1]) < 7))
            near = [f for f in foes if _d(px, py, f.x, f.y) <= 3]
            o.update(mode="heal", goal=(sx, sy) if _d(px, py, sx, sy) > 1.2 else None, note="healing at a shrine",
                     target=min(near, key=lambda f: _d(px, py, f.x, f.y)) if near else None)
            return
    goal = None; note = ""; chase = None; hold = None
    if inst.mode == "ctf":
        fe = inst.flags["red"]; fo = inst.flags["blue"]
        if carrying:
            goal = fo["home"]; note = "running the flag home"
        elif fo["carrier"] is not None and fo["carrier"] != "player":
            chase = fo["carrier"]; goal = (chase.x, chase.y); note = "hunting the flag carrier"
        elif tuple(fo["pos"]) != tuple(fo["home"]):
            goal = fo["pos"]; note = "returning our flag"
        elif fe["carrier"] is not None and fe["carrier"] != "player":
            c = fe["carrier"]; goal = _toward(px, py, c.x, c.y, 2.5); note = f"escorting {c.name}"
        else:
            goal = fe["pos"]; note = "going for the enemy flag"
    elif inst.mode == "dom":
        rad = 4.6 if inst.cfg["n"] >= 12 else 3.4
        def score(pt):
            reds_ = sum(1 for f in foes if _d(f.x, f.y, pt["x"], pt["y"]) < rad + 3)
            s = _d(px, py, pt["x"], pt["y"]) + 3 * reds_
            if pt["owner"] == "blue": s += 40 - 12 * min(3, reds_)        # ours: only worth it when it is under attack
            elif pt["owner"] == "red": s -= 4
            return s
        hold = min(inst.points, key=score)
        goal = (hold["x"], hold["y"]); note = f"taking point {hold['n']}" if hold["owner"] != "blue" else f"holding point {hold['n']}"
    else:
        if foes:
            f = min(foes, key=lambda f: _d(px, py, f.x, f.y) * (.6 + f.hp / max(1, f.maxhp)))
            goal = (f.x, f.y); note = "pushing the enemy"
        else:
            goal = inst.red_base; note = "pushing the enemy base"
    # who to hit
    reach = 2.2 if carrying else 10.0
    near = [f for f in foes if _d(px, py, f.x, f.y) <= reach]
    if hold is not None:
        near = [f for f in near if _d(f.x, f.y, hold["x"], hold["y"]) < 13]      # don't get dragged off the point
    t = None
    if chase is not None and _d(px, py, chase.x, chase.y) <= 14: t = chase
    elif near:
        t = min(near, key=lambda f: (0 if f.has_flag else 1, _d(px, py, f.x, f.y) * (.55 + f.hp / max(1, f.maxhp))))
    o["target"] = t
    if t is not None and not carrying:
        o.update(mode="fight", fight=True, note=note)
        return
    if hold is not None and _d(px, py, hold["x"], hold["y"]) < 1.5: goal = None
    o.update(mode="move", goal=goal, note=note)


# ------------------------------------------------------------------ spells
def _party_low(w, inst, hpf):
    fr = [a.hp / max(1, a.maxhp) for a in inst.alive_allies()]
    if getattr(inst, "is_arena", False):
        p = w.player
        fr = [a.hp / max(1, a.maxhp) for a in inst.alive_allies() if _d(a.x, a.y, p["x"], p["y"]) < 12]
    return min(fr + [hpf])


def _enemies(w, inst):
    if getattr(inst, "is_arena", False): return [r for r in inst.reds if not r.dead]
    return [m for m in inst._live_mobs() if not (m.role == "boss" and inst.boss_immune(m))]


def _pick_cast(w, inst, o, hpf, mf):
    """The hotbar key to cast now (or None)."""
    p = w.player; px, py = p["x"], p["y"]
    role = role_of(w)
    try: spells = w.ability_info()
    except Exception: return None
    mana = p.get("mana", 0); mm = max(1, w.max_mana())
    usable = [s for s in spells if not s["locked"] and s["ready"] and mana >= s["mana"] and s["kind"] not in SKIP_KINDS]
    enemies = _enemies(w, inst)
    close = [e for e in enemies if _d(px, py, e.x, e.y) <= 6]
    party_low = _party_low(w, inst, hpf)
    # defence first
    for s in usable:
        if s["cat"] != "defense": continue
        k = s["kind"]
        if k in ("heal", "hot"):
            if hpf < .6 or (role == "Healer" and party_low < (.75 if k == "hot" else .65)): return s["slot"]
        elif k == "mana":
            if mf < .35: return s["slot"]
        elif k in ("shield", "armor", "dodge"):
            if o["brace"] or (close and hpf < .75) or (role == "Tank" and close and hpf < .9): return s["slot"]
    # interrupt a boss cast
    b = o.get("interrupt")
    if b is not None:
        db = _d(px, py, b.x, b.y)
        for s in usable:
            if s["cat"] != "attack": continue
            if not (s["kind"] in ("stun", "silence", "charge") or s.get("stun")): continue
            if db <= s["range"]:
                w.selected_target = b.id; o["target"] = b
                return s["slot"]
    # attack
    t = o.get("target")
    reserve = mm * (.5 if role == "Healer" else .12)
    for s in usable:
        if s["cat"] != "attack": continue
        if s["mana"] > 0 and mana - s["mana"] < reserve: continue
        if s["kind"] == "nova":
            if any(_d(px, py, e.x, e.y) <= s["range"] for e in enemies): return s["slot"]
            continue
        if t is None: continue
        if _d(px, py, t.x, t.y) <= s["range"]:
            w.selected_target = t.id
            return s["slot"]
    return None


# ------------------------------------------------------------------ headless driver (tests)
def reach(w):
    return 1.3 if w.class_name() in MELEE else 4.6


def drive(w, ticks):
    """Play `ticks` simulation ticks on auto-play with no screen: walk, swing, cast, drink, loot, move on."""
    from types import SimpleNamespace
    body = SimpleNamespace(id=-424242, kind="ally", x=0.0, y=0.0)
    for _ in range(ticks):
        inst = w.inst
        if inst is None: break
        p = w.player
        o = think(w)
        if o["potion"]: w.use_potion()
        if o["mana_potion"]: w.use_mana_potion()
        if o["ready"]: w.instance_ready()
        if o["loot"]: w.pickup_loot()
        t = o["target"]
        if t is not None: w.selected_target = t.id
        goal = o["goal"]
        if o["fight"] and t is not None:
            goal = _toward(p["x"], p["y"], t.x, t.y, reach(w) - .2)
        if goal is not None and not inst.player_down():
            body.x, body.y = p["x"], p["y"]
            inst._nav(body, goal[0], goal[1], 4.6 * w.move_speed() * .25)
            p["x"], p["y"] = body.x, body.y
        if o["cast"]: w.use_ability(o["cast"])
        if t is not None and w.tick % 4 == 0 and not inst.player_down() and t.hp > 0:
            w.attack_target(t.id)
        w.update(1)
