"""LiveWorld RPG 1.0.26 - the Tavern, in every town, city and capital.

* DRINKS - buy a drink at the bar for a short buff (speed, armour, mana, damage, crit, strength, a hearty stew), or the
  Barkeep's Surprise (a random drink at one and a half times the strength).  Each drink is one buff kind, like elixirs:
  a drink whose kind is already active cannot be stacked.  Buy a Round for the House: everyone near cheers you and the
  Tavern's hirelings cost 20% less for 10 minutes.
* DUELS - the tavern's regulars (adventurers of your side in this town, near your level) always accept a challenge here,
  and its pit fighters (always near your level, so there is someone to fight in every town) wait for a challenger.
  Pick Friendly (no stakes) or Wager gold.  Duels stop at the last hit point, as anywhere.  Tavern wins are counted.
* HIRELINGS - sellswords for hire: a tank, a healer and a damage dealer at three grades (Sellsword, Veteran, Champion).
  They join your party at once (they take a party place, up to 3), follow and fight like any companion, and serve for one
  hour of play; renew the contract at any Tavern.  Dismissed or expired hirelings go home.
State is kept in the world's meta table (keys "hirelings", "tavern"), so older saves simply start with none.
"""
import json
import math
import random

# key: (name, buff kind, base value, value per level, seconds, gold per level, description)
DRINKS = [
    ("honey_mead", "Honey Mead", "haste", .12, 0, 600, 3, "+12% run speed for 10 minutes"),
    ("dwarven_stout", "Dwarven Stout", "def", .08, 0, 600, 4, "8% less damage taken for 10 minutes"),
    ("elven_moonwine", "Elven Moonwine", "mreg", .60, 0, 600, 4, "+60% mana regeneration for 10 minutes"),
    ("firebrand_whisky", "Firebrand Whisky", "might", .08, 0, 600, 6, "+8% damage for 10 minutes"),
    ("rogues_cider", "Rogue's Cider", "crit", .05, 0, 600, 5, "+5% critical strike chance for 10 minutes"),
    ("ogres_grog", "Ogre's Grog", "e_str", 6, .35, 600, 4, "+Strength for 10 minutes (6 + a third of your level)"),
    ("hearty_stew", "Hearty Stew", "regen", .015, 0, 30, 2, "Recover 1.5% health a second for 30 s, even in combat"),
]
DRINK_BY_KEY = {d[0]: d for d in DRINKS}
SURPRISE_MULT = 1.5
ROUND_TICKS = 4 * 600                  # 10 minutes of cheaper hirelings after a round for the house
HIRE_TICKS = 4 * 3600                  # a contract is one hour of play
HIRE_BASE = 9600                       # hireling actor ids 9600-9799 (roamers use 9000-9199)
PIT_BASE = 9800                        # pit fighters, 9800-9899: they exist only while they duel you
PIT_FIRST = ["Grak", "Sable", "Hrolf", "Kestra", "Mungo", "Ysolde", "Brakka", "Tobin", "Zarra", "Ewan"]
PIT_LAST = ["the Brawler", "Two-Fists", "the Pit Queen", "Bonecrusher", "the Quick", "Ironjaw", "the Unbeaten", "Scarbelly"]
# grade: (title, level offset, gear grade, gold per level)
GRADES = [("Sellsword", -2, "Rare", 40), ("Veteran", 0, "Epic", 110), ("Champion", 2, "Legendary", 300)]
ROLE_CLASSES = {"Tank": ("Warrior", "Paladin", "Juggernaut"), "Healer": ("Cleric", "Druid", "Shaman"),
                "DPS": ("Ranger", "Mage", "Rogue", "Warlock", "Berserker", "Monk")}
HIRE_FIRST = ["Bram", "Hilde", "Osric", "Wenna", "Garrick", "Tamsin", "Ulf", "Maera", "Dorn", "Sigrun", "Fenn", "Liora", "Corvin", "Yrsa",
              "Aldric", "Brisa", "Torvald", "Nell", "Rurik", "Vesna"]
HIRE_LAST = ["Ironhand", "the Bold", "Ashmantle", "Greycloak", "Stoutheart", "of the Road", "Blackbriar", "Swiftblade", "Oakshield",
             "the Unbowed", "Coldwater", "Redmane"]


class TavernMixin:
    """Mixed into engine.World."""

    # ------------------------------------------------------------ where
    def at_tavern(self):
        return bool(self._near_station("tavern", 7.0)) and not self.inst

    def _tavern_town(self):
        p = self.player
        return min(self.towns, key=lambda t: (t.x - p["x"]) ** 2 + (t.y - p["y"]) ** 2) if self.towns else None

    def _tv(self):
        st = getattr(self, "_tv_cache", None)
        if st is None:
            st = self._jmeta("tavern", None)
            if not isinstance(st.get("wins"), int): st["wins"] = 0
            if not isinstance(st.get("losses"), int): st["losses"] = 0
            if not isinstance(st.get("round"), dict): st["round"] = {}
            self._tv_cache = st
        return st

    def _tv_save(self):
        self._setmeta("tavern", json.dumps(self._tv())); self.db.commit()

    # ------------------------------------------------------------ drinks
    def drink_value(self, d, mult=1.0):
        lvl = self.player["level"]
        v = (d[3] + d[4] * lvl) * mult
        return int(round(v)) if d[2].startswith("e_") else round(v, 3)

    def drink_price(self, d):
        return max(5, int(d[6] * max(1, self.player["level"]) * getattr(self, "BUY_MULT", 1)))

    def surprise_price(self):
        return max(8, int(4 * max(1, self.player["level"]) * getattr(self, "BUY_MULT", 1)))

    def round_price(self):
        return max(20, int(25 * max(1, self.player["level"]) * getattr(self, "BUY_MULT", 1)))

    def buy_drink(self, key):
        if not self.at_tavern(): return "Visit a Tavern in any town to buy a drink."
        p = self.player
        if key == "surprise":
            d = self.rng.choice(DRINKS); price = self.surprise_price(); mult = SURPRISE_MULT; title = "Barkeep's Surprise"
        else:
            d = DRINK_BY_KEY.get(key)
            if d is None: return "The barkeep has never heard of that one."
            price = self.drink_price(d); mult = 1.0; title = d[1]
        if p["gold"] < price: return f"{title} costs {price:,} gold. You have {p['gold']:,}."
        if self._buff(d[2]): return f"You already feel the effect of something like {d[1]} - wait until it wears off."
        p["gold"] -= price
        val = self.drink_value(d, mult)
        self.buffs[d[2]] = {"name": d[1], "kind": d[2], "until": self.tick + d[5] * 4, "value": val}
        if d[2] == "regen": self._heal(self._effective_maxhp() * .4)
        self._save_player_fast()
        extra = f" (Barkeep's Surprise: {d[1]}, half again as strong!)" if key == "surprise" else ""
        return f"You drink a {d[1]}: {self._drink_text(d, val)}.{extra}"

    def _drink_text(self, d, val):
        k = d[2]
        if k == "e_str": return f"+{val} Strength for 10 minutes"
        if k == "regen": return f"recover {val * 100:.1f}% health a second for 30 s"
        pct = int(round(val * 100))
        return {"haste": f"+{pct}% run speed", "def": f"{pct}% less damage taken", "mreg": f"+{pct}% mana regeneration",
                "might": f"+{pct}% damage", "crit": f"+{pct}% critical strike chance"}.get(k, d[7]) + " for 10 minutes"

    def buy_round(self):
        if not self.at_tavern(): return "Visit a Tavern to buy a round."
        p = self.player; price = self.round_price(); t = self._tavern_town()
        if p["gold"] < price: return f"A round for the house costs {price:,} gold. You have {p['gold']:,}."
        p["gold"] -= price
        st = self._tv(); st["round"][str(t.id)] = self.tick + ROUND_TICKS; self._tv_save()
        n = 0
        for a in self.actors:
            if a.kind == "adventurer" and a.hp > 0 and (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2 < 14 * 14:
                a.say = self.rng.choice(("Cheers!", f"To {p['name']}!", "Now that's a hero!", "Drinks are on them!", "Huzzah!"))
                a.say_until = self.tick + 30; a.say_seq = getattr(a, "say_seq", 0) + 1; n += 1
        self._save_player_fast()
        return f"You buy a round for the house! {n} patrons cheer, and the Tavern's hirelings cost 20% less for 10 minutes."

    def _round_active(self, t):
        return t is not None and self._tv()["round"].get(str(t.id), 0) > self.tick

    # ------------------------------------------------------------ duels
    def tavern_duelists(self, limit=6):
        """Regulars at this town's Tavern: adventurers of your side in town, near your level, free to fight."""
        t = self._tavern_town(); p = self.player
        if t is None: return []
        from . import engine as E
        out = []
        for a in self.actors:
            if a.kind != "adventurer" or a.hp <= 0 or a.party or a.faction != p["faction"]: continue
            if a.state in ("aiduel", "duel", "offer", "fight", "defend", "pparty"): continue
            if (a.x - t.x) ** 2 + (a.y - t.y) ** 2 > (E.TOWN_WALL_R + 6) ** 2: continue
            if abs(a.level - p["level"]) > 12: continue
            out.append(a)
        out.sort(key=lambda a: (abs(a.level - p["level"]), a.id))
        return out[:limit]

    def pit_fighters(self):
        """Three pit fighters near your level - the same faces all day in each Tavern."""
        t = self._tavern_town(); p = self.player
        if t is None: return []
        r = random.Random(f"pit:{t.id}:{self.day}")
        out = []
        for k in range(3):
            lvl = max(1, min(100, p["level"] + (-2, 0, 3)[k]))
            out.append({"id": f"pit{k}", "name": f"{r.choice(PIT_FIRST)} {r.choice(PIT_LAST)}", "level": lvl,
                        "cls": r.choice(("Warrior", "Rogue", "Berserker", "Monk", "Ranger", "Mage", "Paladin")),
                        "gear": ("Rare", "Epic", "Elite")[k], "wins": r.randint(5, 40), "losses": r.randint(0, 12), "pit": True})
        return out

    def _spawn_pit(self, k):
        f = next((x for x in self.pit_fighters() if x["id"] == k), None)
        if f is None: return None
        from . import engine as E
        used = {a.id for a in self.actors}
        aid = next((i for i in range(PIT_BASE, PIT_BASE + 100) if i not in used), None)
        if aid is None: return None
        p = self.player
        a = E.Actor(aid, f["name"], p["faction"], f["level"], p["x"] + 2.5, p["y"] + 1.5, 100, 100, "adventurer", f["cls"], "town", -1, self.area(p["x"], p["y"])[0], 10, 0)
        a.gear = f["gear"]; a.persona = "proud"; a.setl = ""; a.setp = (); a.wins = f["wins"]; a.losses = f["losses"]; a.pxp = 0
        self._person_stats(a, heal=True); self._person_reset_goal(a)
        self.actors.append(a); self.by_id[a.id] = a
        return a

    def tavern_wager(self, a):
        return max(20, min(self.player["gold"] // 5, 50 + a.level * 30))

    def tavern_duel(self, aid, wager=True):
        if not self.at_tavern(): return "Challenges are made at the Tavern."
        if self.duel: return "You are already in a duel."
        if self.inst or getattr(self, "city_raid", None): return "Not now - there are more important fights."
        if self.tick - self.last_combat_tick < 20: return "You are still in combat."
        if isinstance(aid, str) and aid.startswith("pit"):
            f = next((x for x in self.pit_fighters() if x["id"] == aid), None)
            if f is None: return "They have left the Tavern."
            stake = max(20, min(self.player["gold"] // 5, 50 + f["level"] * 30)) if wager else 0
            if wager and self.player["gold"] < stake: return f"The wager is {stake:,} gold - you cannot cover it."
            a = self._spawn_pit(aid)
            if a is None: return "The pit is busy - try again in a moment."
        else:
            a = self.by_id.get(aid)
            if a is None or a not in self.tavern_duelists(50): return "They have left the Tavern."
            stake = self.tavern_wager(a) if wager else 0
        if wager and self.player["gold"] < stake: return f"The wager is {stake:,} gold - you cannot cover it."
        p = self.player
        ang = (a.id * 2.399) % 6.283
        a.x, a.y = p["x"] + math.cos(ang) * 3.0, p["y"] + math.sin(ang) * 3.0       # they step out of the crowd to face you
        a.say = self.rng.choice(("You're on!", "Outside, then!", "Let's settle this.", "First to fall buys the next round!"))
        a.say_until = self.tick + 24; a.say_seq = getattr(a, "say_seq", 0) + 1
        r = self._start_duel(a, stake)
        if self.duel: self.duel["tavern"] = True
        return r or f"{a.name} accepts your challenge!" + (f" Wager {stake:,}g." if stake else " A friendly bout.")

    def _tavern_duel_done(self, won):
        st = self._tv()
        if won: st["wins"] += 1
        else: st["losses"] += 1
        self._tv_save()

    # ------------------------------------------------------------ hirelings
    def _hst(self):
        v = getattr(self, "_hire_cache", None)
        if v is None:
            raw = self._jmeta("hirelings", None)
            v = {}
            for k, h in raw.items():
                try:
                    if isinstance(h, dict) and isinstance(h.get("until"), int): v[int(k)] = h
                except (TypeError, ValueError):
                    continue
            self._hire_cache = v
        return v

    def _hst_save(self):
        self._setmeta("hirelings", json.dumps({str(k): v for k, v in self._hst().items()})); self.db.commit()

    def hire_offers(self):
        """Eight sellswords at three grades - tanks, healers and damage dealers; the faces change each day."""
        t = self._tavern_town(); p = self.player
        if t is None: return []
        r = random.Random(f"hire:{t.id}:{self.day}")
        disc = .8 if self._round_active(t) else 1.0
        out = []
        for gi, (gname, off, gear, gpl) in enumerate(GRADES):
            for role in ("Tank", "Healer", "DPS"):
                if gi == 0 and role == "DPS": continue                  # eight offers: a Sellsword tank and healer, and a Veteran and a Champion of each role
                cls = r.choice(ROLE_CLASSES[role])
                lvl = max(1, min(100, p["level"] + off))
                name = f"{r.choice(HIRE_FIRST)} {r.choice(HIRE_LAST)}"
                price = int(gpl * lvl * disc * getattr(self, "BUY_MULT", 1))
                out.append({"key": f"{gi}:{role}", "grade": gname, "role": role, "cls": cls, "level": lvl, "gear": gear, "name": name, "price": price})
        return out

    def hire(self, key):
        if not self.at_tavern(): return "Hirelings are hired at a Tavern."
        if self.inst or getattr(self, "city_raid", None): return "Not now."
        from .partyup import PARTY_MAX
        if len(self.party_members()) >= PARTY_MAX: return f"Your party is full ({PARTY_MAX} companions). Dismiss someone first."
        o = next((x for x in self.hire_offers() if x["key"] == key), None)
        if o is None: return "That sellsword has already left."
        if any(h.get("offer") == f"{self.day}:{self._tavern_town().id}:{key}" for h in self._hst().values()):
            return f"{o['name']} already rides with you."
        p = self.player
        if p["gold"] < o["price"]: return f"{o['name']} wants {o['price']:,} gold for an hour's work. You have {p['gold']:,}."
        from . import engine as E
        used = {a.id for a in self.actors}
        aid = next((i for i in range(HIRE_BASE, HIRE_BASE + 200) if i not in used and i not in self._hst()), None)
        if aid is None: return "No sellswords are free right now."
        p["gold"] -= o["price"]
        ang = self.rng.uniform(0, 6.283)
        a = E.Actor(aid, o["name"], p["faction"], o["level"], p["x"] + math.cos(ang) * 1.8, p["y"] + math.sin(ang) * 1.8, 100, 100,
                    "adventurer", o["cls"], "pparty", -1, self.area(p["x"], p["y"])[0], 10, -1)
        a.gear = o["gear"]; a.persona = "guardian"; a.setl = ""; a.setp = (); a.wins = 0; a.losses = 0; a.pxp = 0
        self._person_stats(a, heal=True); self._person_reset_goal(a); a.state = "pparty"; a.party = -1
        self.actors.append(a); self.by_id[a.id] = a
        ids = self._pp_ids(); ids.append(aid); self._pp_save(ids)
        self._hst()[aid] = {"until": self.tick + HIRE_TICKS, "offer": f"{self.day}:{self._tavern_town().id}:{key}", "grade": o["grade"], "price": o["price"]}
        self._hst_save(); self._save_player_fast()
        a.say = self.rng.choice(("Lead the way.", "My blade is yours.", "Gold well spent - you'll see.", "Where's the fight?"))
        a.say_until = self.tick + 30; a.say_seq = 1
        return f"{o['name']} ({o['grade']}, level {o['level']} {o['cls']}) joins your party for one hour."

    def renew_hireling(self, aid):
        if not self.at_tavern(): return "Renew a contract at any Tavern."
        h = self._hst().get(aid); a = self.by_id.get(aid)
        if h is None or a is None: return "They are not in your service."
        price = int(h.get("price", 0) * .8)
        if self.player["gold"] < price: return f"Another hour costs {price:,} gold."
        self.player["gold"] -= price; h["until"] = max(h["until"], self.tick) + HIRE_TICKS
        self._hst_save(); self._save_player_fast()
        return f"{a.name} signs on for another hour ({price:,} gold)."

    def dismiss_hireling(self, aid, why="goes home"):
        h = self._hst().pop(aid, None)
        if h is None: return "They are not in your service."
        a = self.by_id.pop(aid, None)
        ids = [i for i in self._pp_ids() if i != aid]; self._pp_save(ids)
        if a is not None:
            self.actors = [x for x in self.actors if x.id != aid]
            if getattr(self, "selected_target", None) == aid: self.selected_target = None
        self._hst_save()
        return f"{a.name if a else 'Your hireling'} {why}."

    def hirelings_info(self):
        out = []
        for aid, h in self._hst().items():
            a = self.by_id.get(aid)
            if a is None: continue
            out.append({"id": aid, "name": a.name, "cls": a.role, "level": a.level, "grade": h.get("grade", ""), "hp": int(a.hp), "maxhp": int(a.maxhp),
                        "left": max(0, (h["until"] - self.tick) // 4), "renew": int(h.get("price", 0) * .8)})
        return out

    def _tavern_tick(self):
        if self.tick % 20: return
        du_ = getattr(self, "duel", None)
        pits = [a for a in self.actors if PIT_BASE <= a.id < PIT_BASE + 100 and not (du_ and du_.get("id") == a.id)]
        if pits:                                # a pit fighter goes back to the pit once your duel is over
            gone = {a.id for a in pits}
            self.actors = [a for a in self.actors if a.id not in gone]
            for i in gone: self.by_id.pop(i, None)
        hs = self._hst()
        if not hs: return
        for aid in list(hs):
            a = self.by_id.get(aid)
            if a is None and not self.inst:
                hs.pop(aid, None); self._hst_save(); continue
            if self.tick >= hs[aid]["until"] and not self.inst:
                self.events.append(self.dismiss_hireling(aid, "has served the hour and heads home - renew at a Tavern next time"))
            elif aid not in self._pp_ids() and not self.inst:       # dismissed from the party window: they go home too
                self.dismiss_hireling(aid)

    # ------------------------------------------------------------ the window
    def tavern_view(self):
        if not self.at_tavern(): return None
        t = self._tavern_town(); p = self.player; st = self._tv()
        drinks = [{"key": d[0], "name": d[1], "kind": d[2], "price": self.drink_price(d), "desc": self._drink_text(d, self.drink_value(d)),
                   "active": bool(self._buff(d[2]))} for d in DRINKS]
        duel = [{"id": a.id, "name": a.name, "level": a.level, "cls": a.role, "gear": getattr(a, "gear", "Common"),
                 "wins": getattr(a, "wins", 0), "losses": getattr(a, "losses", 0), "wager": self.tavern_wager(a), "pit": False} for a in self.tavern_duelists(4)]
        for f in self.pit_fighters():
            f = dict(f); f["wager"] = max(20, min(p["gold"] // 5, 50 + f["level"] * 30)); duel.append(f)
        return {"town": t.name if t else "", "gold": p["gold"], "drinks": drinks, "surprise": self.surprise_price(), "round": self.round_price(),
                "round_on": self._round_active(t), "duelists": duel, "wins": st["wins"], "losses": st["losses"], "in_duel": bool(self.duel),
                "offers": self.hire_offers(), "hired": self.hirelings_info(), "party_n": len(self.party_members())}
