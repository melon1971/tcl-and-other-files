#!/usr/bin/python3
"""5.0-14: the dashboard runs under a Content-Security-Policy without 'unsafe-inline' for scripts. Serves the real
page with the real request handler (commands stubbed, both halves in one process), opens it in headless Chromium
(Playwright), visits every page and uses each kind of action (click, change, input, Enter), and checks that:
no CSP violation or script error occurs, the actions reach the server, and injected inline script does NOT run.
Needs python3-playwright with a Chromium; skips (exit 0) without it. Port 8765 must be free.
Throwaway container or VM only (creates /var/lib/locsecd), as root.
Usage: test_csp_5014.py path/to/locsecd.py"""
import sys, os, subprocess, threading, http.server, importlib.util, collections, shutil, time
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print('SKIP: python3 playwright is not installed'); sys.exit(0)
REC = []
def fake_run(argv, *a, stdout=None, text=False, **k):
    REC.append([str(x) for x in argv])
    if hasattr(stdout, 'write'): return subprocess.CompletedProcess(argv, 0)
    return subprocess.CompletedProcess(argv, 0, stdout='' if text else b'', stderr='')
class FakeProc:
    pid = 999998; returncode = 0
    def __init__(self, *a, **k): pass
    def poll(self): return 0
    def wait(self, timeout=None): return 0
    def communicate(self, *a, **k): return (b'', b'')
    def terminate(self): pass
    def kill(self): pass
_REAL_POPEN = subprocess.Popen
def fake_popen(argv, *a, **k):
    # Playwright's own driver goes through Popen too; only LocSec's commands are stubbed.
    if any('playwright' in str(x) or str(x).endswith('/node') for x in (argv if isinstance(argv, (list, tuple)) else [argv])):
        return _REAL_POPEN(argv, *a, **k)
    REC.append([str(x) for x in argv]); return FakeProc()
subprocess.run = fake_run; subprocess.Popen = fake_popen
subprocess.check_output = lambda *a, **k: ''
os.environ['LOCSEC_INPROCESS_BROKER'] = '1'
spec = importlib.util.spec_from_file_location('locsecd_csp', sys.argv[1]); m = importlib.util.module_from_spec(spec)
sys.argv = [sys.argv[1]]; spec.loader.exec_module(m)
m.have = lambda c: False      # nothing installed: every page renders its "not installed" state, quickly
POSTS = []
class H(m.Handler):
    def do_POST(self):
        POSTS.append(self.path.split('?')[0]); return super().do_POST()
srv = http.server.ThreadingHTTPServer(('127.0.0.1', int(m.CFG['port'])), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
base = f"http://127.0.0.1:{m.CFG['port']}"
errors, csp, warns = [], [], []
with sync_playwright() as pw:
    b = pw.chromium.launch(executable_path=os.environ.get('LOCSEC_CHROMIUM') or None)
    pg = b.new_page()
    pg.add_init_script("document.addEventListener('securitypolicyviolation',e=>console.error('CSPV '+e.violatedDirective+' '+(e.sample||'')),true)")
    pg.on('console', lambda msg: (csp if msg.text.startswith('CSPV') else errors if msg.type == 'error' else warns if msg.type == 'warning' else []).append(msg.text))
    pg.on('pageerror', lambda e: errors.append('pageerror: ' + str(e)))
    NOTFOUND = []
    pg.on('response', lambda r: NOTFOUND.append(r.url) if r.status == 404 else None)
    resp = pg.goto(base + '/dashboard?code=' + m.mint_login_code())
    hdr = resp.headers.get('content-security-policy', '')
    check('the page is served (200)', resp.status == 200)
    check("the CSP has a nonce and no 'unsafe-inline' for scripts", "script-src 'nonce-" in hdr and "script-src 'unsafe-inline'" not in hdr and "script-src-attr 'none'" in hdr)
    nonce1 = hdr.split("'nonce-")[1].split("'")[0]
    pg.wait_for_selector('#pagebody', timeout=15000); time.sleep(1)
    pages = pg.eval_on_selector_all('nav [data-click="page"], [data-click="page"]', 'els=>els.map(e=>JSON.parse(e.getAttribute("data-args"))[0])')
    check(f'the navigation has every page ({len(set(pages))})', len(set(pages)) >= 13)
    for name in dict.fromkeys(pages):
        pg.click(f'[data-click="page"][data-args*="{name}"]'); time.sleep(0.6)
    check('no inline onclick/onchange/... attribute is left anywhere in the rendered pages',
          pg.evaluate("[...document.querySelectorAll('*')].every(e=>![...e.attributes].some(a=>/^on/i.test(a.name)))"))
    # click with arguments -> a POST
    pg.click('[data-click="page"][data-args*="services"]'); time.sleep(0.8)
    pg.fill('#svcname', 'bluetooth')                      # data-input -> setManualUnit(this.value)
    check('data-input passes the value to its action', pg.evaluate('MANUAL_UNIT') == 'bluetooth')
    n0 = len(POSTS); pg.press('#svcname', 'Enter'); time.sleep(0.8)   # data-enter -> manualSvc('start')
    check('data-enter (Enter in the unit box) runs its action and reaches the server', '/api/service/action' in POSTS[n0:])
    n0 = len(POSTS); pg.click('[data-click="manualSvc"][data-args*="restart"]'); time.sleep(0.8)
    check('a click with a static argument reaches the server', '/api/service/action' in POSTS[n0:])
    pg.click('[data-click="page"][data-args*="scans"]'); time.sleep(0.8)
    n0 = len(POSTS); pg.click('[data-click="run"][data-args*="lynis"]'); time.sleep(1.0)
    check('run(url, {job}, this) through data-args reaches the server', '/api/scan-job' in POSTS[n0:])
    pg.click('[data-click="page"][data-args*="logs"]'); time.sleep(0.8)
    pg.select_option('#logfilter', index=1); time.sleep(0.6)  # data-change -> setLogFilter(this.value)
    check('data-change passes the selected value', pg.evaluate('LOG_FILTER') != 'all')
    pg.click('[data-click="page"][data-args*="firewall"]'); time.sleep(0.8)
    n0 = len(POSTS); pg.click('[data-click="runThen"][data-args*="firewall/enable"]'); time.sleep(1.0)
    check('runThen (run, then redraw a page) reaches the server', '/api/firewall/enable' in POSTS[n0:])
    # The browser asks for /favicon.ico by itself; the dashboard has never served one (a 404 that is not the page's).
    nf = [u for u in NOTFOUND if not u.endswith('/favicon.ico')]
    errors = [e for e in errors if not (e.startswith('Failed to load resource') and '404' in e and not nf)]
    check('no request from the page itself gets a 404: ' + (', '.join(nf) or 'none'), not nf)
    check('no script error on any page or action: ' + ('; '.join(errors)[:300] or 'none'), not errors)
    check('no CSP violation by the page itself: ' + ('; '.join(csp)[:300] or 'none'), not csp)
    check('no unknown-action warning: ' + ('; '.join(w for w in warns if 'LocSec' in w)[:200] or 'none'), not any('LocSec' in w for w in warns))
    # an injection must not run
    pg.evaluate("""()=>{const d=document.createElement('div');d.innerHTML='<img src="data:," onerror="window.__pwned=1"><button id="evil" onclick="window.__pwned=2">x</button>';document.body.appendChild(d)}""")
    time.sleep(0.5); pg.evaluate("document.getElementById('evil').click()"); time.sleep(0.3)
    check('injected inline handlers do not run', pg.evaluate('window.__pwned') is None)
    check('and the browser reports them as CSP violations', any('script-src-attr' in c for c in csp))
    pg.evaluate("""()=>{const s=document.createElement('script');s.textContent='window.__pwned=3';document.body.appendChild(s)}""")
    time.sleep(0.3)
    check('an injected <script> without the nonce does not run', pg.evaluate('window.__pwned') is None)
    pg.evaluate("""()=>{const d=document.createElement('div');d.innerHTML='<button id="evil2" data-click="fetch" data-args="[&quot;/x&quot;]">y</button>';document.body.appendChild(d)}""")
    n0 = len(warns); pg.evaluate("document.getElementById('evil2').click()"); time.sleep(0.3)
    check('a data-click naming a function outside the allowlist is refused', any('unknown action fetch' in w for w in warns[n0:]))
    resp2 = pg.goto(base + '/dashboard'); hdr2 = resp2.headers.get('content-security-policy', '')
    check('every page load gets a new nonce', "'nonce-" in hdr2 and hdr2.split("'nonce-")[1].split("'")[0] != nonce1)
    b.close()
srv.shutdown()
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
