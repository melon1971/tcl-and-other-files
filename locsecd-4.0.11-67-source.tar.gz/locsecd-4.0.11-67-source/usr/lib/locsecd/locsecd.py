#!/usr/bin/python3
# LocSec -- local host security daemon and dashboard.
# Copyright (C) 2025-2026 LocSec Project
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <https://www.gnu.org/licenses/>.
import os, sys, json, time, re, stat, errno, ipaddress, subprocess, threading, queue, urllib.request, urllib.error, urllib.parse, hashlib, signal, hmac, tempfile, shutil, fcntl, uuid, secrets, shlex
from pathlib import Path
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP='locsecd'
VERSION_FALLBACK='4.0.11-67'

def _installed_version():
    try:
        p=subprocess.run(['dpkg-query','-W','-f=${Version}',APP],text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=3,check=False)
        v=p.stdout.strip()
        if p.returncode==0 and v and re.fullmatch(r'[0-9A-Za-z.+:~_-]+',v):
            return v
    except Exception:
        pass
    return VERSION_FALLBACK

VERSION=_installed_version()

def _os_release():
    info={}
    try:
        for line in Path('/etc/os-release').read_text().splitlines():
            if '=' in line:
                k,_,v=line.partition('='); info[k]=v.strip().strip('"')
    except Exception: pass
    return info

_OS=_os_release()
# Debian proper, or a Debian-based derivative that is not Ubuntu-based --
# LMDE reports ID=linuxmint (like regular Mint) but ID_LIKE=debian, and its
# packages are Debian's, so debsecan's Debian feed applies to it. Regular Mint
# and other Ubuntu derivatives carry "ubuntu" in ID_LIKE.
_ID_LIKE=_OS.get('ID_LIKE','').split()
IS_DEBIAN_NATIVE = _OS.get('ID')=='debian' or ('debian' in _ID_LIKE and 'ubuntu' not in _ID_LIKE and _OS.get('ID')!='ubuntu')
# LMDE's VERSION_CODENAME is its own (faye, gigi); DEBIAN_CODENAME is the suite.
DEBIAN_SUITE = (_OS.get('DEBIAN_CODENAME') or _OS.get('VERSION_CODENAME') or 'trixie') if IS_DEBIAN_NATIVE else 'trixie'
ETC=Path('/etc/locsecd')
STATE=Path('/var/lib/locsecd')
LOG=Path('/var/log/locsecd/locsecd.log')
# Log sources selectable from the GUI's Logs page. Each is read-only tailed
# server-side; the key is what the GUI passes as ?source=. Only files that
# exist and are readable at request time are ever offered/returned.
#
# Every source also names a systemd-journal fallback ('jargs', plus 'jfilter'
# for a substring the journal has no field for). Debian 12 and 13 install
# without rsyslog, so auth.log, syslog and ufw.log never
# exist there, and the page showed nearly every source as "not found" while the
# same records sat in the journal. Mint and Ubuntu ship rsyslog, which is why
# the file-only version worked there. The file is still preferred when present.
LOG_SOURCES={
    'locsecd':   {'label':'LocSec (locsecd.log)',        'paths':[Path('/var/log/locsecd/locsecd.log')],
                  'jargs':['-u','locsecd.service'],'jlabel':'-u locsecd'},
    'auth':      {'label':'Authentication (auth.log)',    'paths':[Path('/var/log/auth.log')],
                  # Same field given twice is OR'd by journalctl: auth (4) or authpriv (10).
                  'jargs':['SYSLOG_FACILITY=4','SYSLOG_FACILITY=10'],'jlabel':'auth, authpriv'},
    'rkhunter':  {'label':'rkhunter',                     'paths':[Path('/var/log/rkhunter.log')],
                  'hint':'rkhunter writes this file on its first run; run rkhunter from the Scans page'},
    'clamav':    {'label':'ClamAV (freshclam)',           'paths':[Path('/var/log/clamav/freshclam.log')],
                  'jargs':['-u','clamav-freshclam.service'],'jlabel':'-u clamav-freshclam'},
    # The newest LocSec AIDE check (reports/aide-full-*.txt) comes first; see
    # _source_paths(). aide.log is only written by the aide package's own daily
    # check, which LocSec switches off from 4.0.11-65.
    'aide':      {'label':'AIDE (latest check)',          'paths':[Path('/var/log/aide/aide.log')],
                  'jargs':['-u','dailyaidecheck.service'],'jlabel':'-u dailyaidecheck',
                  'hint':'AIDE has not run yet; press "AIDE only" on the Scans page'},
    'ufw':       {'label':'UFW (kernel firewall log)',    'paths':[Path('/var/log/ufw.log')],
                  'jargs':['_TRANSPORT=kernel'],'jfilter':('[UFW ','[LOCSEC BLOCK]'),
                  'jregex':r'kernel: \[(?:UFW|LOCSEC) [A-Z ]+\] IN=\S* OUT=\S* (?:MAC=\S* )?SRC=\S+ DST=','jlabel':'kernel, [UFW ...] and [LOCSEC BLOCK] lines, all boots',
                  'hint':'UFW logs only when logging is on (sudo ufw logging low) and something has been denied'},
    'syslog':    {'label':'System log (syslog)',          'paths':[Path('/var/log/syslog')],
                  'jargs':[],'jlabel':'all messages'},
}
TOKEN=STATE/'api.token'
CONF=ETC/'locsecd.conf'
BLOCKS=STATE/'blocks.json'
FEEDS=STATE/'feeds.json'
REPORTS=STATE/'reports'
CAPTURES=STATE/'captures'
QUAR=STATE/'quarantine'
SVCWATCH=STATE/'service_watch.json'
AUTHSEEN=STATE/'auth_seen.json'
SECURITYSEEN=STATE/'security_seen.json'
JOURNALSTATE=STATE/'journal_cursor.json'
# When each scheduled job last ran. The scheduler used to read this from the
# report files' times only; reports are now deleted after
# report_retention_days, so the times are kept here as well.
JOBRUNS=STATE/'job_runs.json'
INCIDENTS=STATE/'incidents.jsonl'
INCIDENT_ACTIONS=STATE/'incident-actions.jsonl'
LOCK=threading.RLock()
class _JobLock:
    """The maintenance-job lock, plus a record of which job holds it.

    A refused request used to say only "another maintenance job is already
    running", with no way to tell a ten-second feed refresh from a three-hour
    AIDE check short of reading the journal."""
    def __init__(self):
        self._lock=threading.Lock(); self._meta=threading.Lock(); self.job=None
    def acquire(self,blocking=True,timeout=-1,job='maintenance job',origin='dashboard'):
        if not self._lock.acquire(blocking,timeout): return False
        with self._meta: self.job={'name':str(job),'origin':str(origin),'since':time.time()}
        return True
    def release(self):
        with self._meta: self.job=None
        self._lock.release()
    def current(self):
        with self._meta: return dict(self.job) if self.job else None
    def busy_message(self):
        j=self.current()
        if not j: return 'another maintenance job is already running'
        mins=int(max(0,time.time()-j['since'])//60)
        started=datetime.fromtimestamp(j['since']).strftime('%H:%M')
        ago='under a minute' if mins<1 else (f'{mins} min' if mins<120 else f'{mins//60} h {mins%60} min')
        return (f'another maintenance job is already running: {j["name"]} ({j["origin"]}), '
                f'started {started}, running for {ago}. Only one runs at a time; try again when it finishes.')

JOB_LOCK=_JobLock()
AIDE_LOCK_PATH=Path('/run/lock/locsecd-aide.lock')
AIDE_DB=Path('/var/lib/aide/aide.db')
AIDE_DB_NEW=Path('/var/lib/aide/aide.db.new')
MAX_BODY=1024*1024
MAX_FEED_BYTES=8*1024*1024

class _HTTPSOnlyRedirect(urllib.request.HTTPRedirectHandler):
    # The HTTPS-only rule for feeds must hold across redirects too: urllib would
    # otherwise follow an https:// feed to an http:// location.
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urllib.parse.urlparse(newurl).scheme!='https':
            raise urllib.error.HTTPError(newurl,code,'redirect to a non-HTTPS URL refused',headers,fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)
_FEED_OPENER=urllib.request.build_opener(_HTTPSOnlyRedirect)
COOKIE='locsec_session'
CAPTURE_LOCK=threading.Lock()
ACTIVE_CAPTURES=[]
MAX_CONCURRENT_CAPTURES=3
MIN_CAPTURE_FREE_BYTES=1024*1024*1024      # refuse to start a new capture below 1GB free
HARD_MIN_CAPTURE_FREE_BYTES=256*1024*1024  # kill an in-progress capture below 256MB free

# systemd-run spawns apt-get/unattended-upgrade/freshclam (run_privileged())
# and aideinit (aide_init()) as *sibling* transient units, deliberately outside
# locsecd.service's own cgroup, so they can get capabilities our own
# CapabilityBoundingSet denies us. That means locsecd.service's cgroup-kill on
# stop/restart (KillMode=control-group) does NOT reach them: without this
# tracking, a locsecd restart/kill mid-job would leave the transient unit
# running unsupervised, orphaned from JOB_LOCK/the AIDE flock, able to race a
# freshly-started locsecd doing the same job again. Track every such unit name
# so _shutdown_handler can explicitly stop it too.
INFLIGHT_PRIV_UNITS=set()
INFLIGHT_LOCK=threading.Lock()

def _run_transient(cmd, timeout=60, input_text=None, prefix='locsecd-priv', props=None, head=0, save_to=None, tail=20000):
    # Shared helper for run_privileged()/aide_init()/the scan jobs: run cmd in a
    # named transient unit (falling back to a plain subprocess if systemd-run is
    # unavailable) and track the unit name for shutdown-time cleanup.
    #
    # A transient unit is a sibling of locsecd.service managed by PID 1, so it
    # gets NONE of this daemon's sandboxing: full capability set, the real
    # (host) mount namespace, a writable /etc and /usr, visible /lib/modules,
    # and no MemoryMax of ours. That is exactly what apt/freshclam/aideinit
    # need to sandbox themselves as _apt/clamav, what Lynis and rkhunter need
    # to audit the real system rather than our sandboxed view of it, and what
    # clamdscan needs so the file descriptors it hands to clamd (AppArmor-
    # confined) resolve to real paths instead of "disconnected path" denials.
    if not have('systemd-run'):
        # No systemd-run to isolate this in a sibling unit: at least make sure
        # a timeout here kills the whole process group (see run()'s
        # kill_group), not just this one PID -- apt-get/unattended-upgrade/
        # aideinit can all spawn children of their own.
        return run(cmd, timeout, input_text, kill_group=True, head=head, save_to=save_to, tail=tail)
    # The owning daemon's pid is part of the name, so a later instance can tell
    # which units a dead predecessor left running (see _sweep_orphan_units).
    unit=f'{prefix}-p{os.getpid()}-{uuid.uuid4().hex[:8]}.service'
    with INFLIGHT_LOCK:
        # Shutdown stops the units in flight once; one started after that would
        # be outside every cgroup we kill, so refuse to start new ones.
        if STOP_EVENT.is_set(): return 130,'service is stopping'
        INFLIGHT_PRIV_UNITS.add(unit)
    try:
        args=['systemd-run','--pipe','--wait','--collect','--quiet',
              f'--unit={unit}',
              '--property=CapabilityBoundingSet=~','--property=AmbientCapabilities=~',
              '--setenv=DEBIAN_FRONTEND=noninteractive',
              # Belt and braces: even if we lose track of this unit, systemd itself ends it.
              f'--property=RuntimeMaxSec={int(timeout)+120}',
              # Restrictions no job here needs to give up (kernel modules, kernel log,
              # namespaces and the like are left alone because Lynis and rkhunter read them).
              '--property=LockPersonality=yes','--property=RestrictRealtime=yes','--property=ProtectClock=yes',
              '--property=ProtectHostname=yes','--property=SystemCallArchitectures=native']
        if DAEMON_MODE and not unit.startswith(_APT_UNIT_PREFIX):
            args+=['--property=BindsTo=locsecd.service','--property=After=locsecd.service']
        for pr in (props or []): args.append('--property='+str(pr))
        rc,out=run(args+list(cmd), timeout, input_text, head=head, save_to=save_to, tail=tail)
        if rc==124 and not unit.startswith(_APT_UNIT_PREFIX):
            # Our timeout only killed the systemd-run *client*; the unit itself
            # would otherwise keep running unsupervised. Stop it explicitly.
            # Never an apt/dpkg unit: killing dpkg mid-run leaves packages
            # half-configured; RuntimeMaxSec still ends it if it truly hangs.
            try: subprocess.run(['systemctl','stop',unit], timeout=30, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            except Exception: pass
        return rc,out
    finally:
        with INFLIGHT_LOCK: INFLIGHT_PRIV_UNITS.discard(unit)

_APT_UNIT_PREFIX='locsecd-apt-'
# Set by main() for the long-running service. Its transient units are bound to it, so
# systemd stops them when locsecd.service stops, restarts or is killed: the cgroup kill
# reaches the systemd-run client first and the in-flight list is empty by the time
# server() would stop them. apt/dpkg units are never bound (a half-run dpkg is worse).
DAEMON_MODE=False

def _stop_inflight_priv_units():
    # Called on shutdown: cgroup-kill on locsecd.service cannot reach these
    # sibling transient units, so stop them explicitly rather than leaving
    # scans running unsupervised after we exit. One non-blocking call: systemd
    # finishes the stops after we are gone, so a slow unit cannot eat the
    # stop timeout. apt/dpkg units are left to finish -- stopping one mid-run
    # is how dpkg ends up needing "dpkg --configure -a".
    with INFLIGHT_LOCK:
        units=[u for u in INFLIGHT_PRIV_UNITS if not u.startswith(_APT_UNIT_PREFIX)]
    if not units: return
    try: subprocess.run(['systemctl','stop','--no-block','--']+units, timeout=10,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    except Exception: pass

def _sweep_orphan_units():
    # A SIGKILL, OOM kill or crash skips the shutdown path, so the scans the
    # dead instance started keep running -- and it held the AIDE lock, which
    # died with it, so a new instance could start a second aideinit racing the
    # first. Stop every LocSec unit whose owning pid is gone. apt units are
    # left to finish (see _stop_inflight_priv_units).
    if not have('systemctl'): return
    rc,out=run(['systemctl','list-units','--type=service','--state=active,activating','--plain','--no-legend','--no-pager','locsecd-*'],15)
    if rc!=0: return
    stale=[]
    for line in out.splitlines():
        u=(line.split() or [''])[0]
        if not u.endswith('.service') or u=='locsecd.service' or u.startswith(_APT_UNIT_PREFIX): continue
        m=re.search(r'-p(\d+)-[0-9a-f]{8}\.service$',u)
        if m and m.group(1)!=str(os.getpid()) and Path(f'/proc/{m.group(1)}').exists(): continue   # a live locsecctl run
        if m and m.group(1)==str(os.getpid()): continue
        stale.append(u)
    if stale:
        run(['systemctl','stop','--']+stale,60)
        log(f'stopped {len(stale)} scan unit(s) left running by a previous LocSec instance: {", ".join(stale[:10])}','WARN')

def _reap_captures():
    # Drop finished/dead tcpdump processes from the tracking list; called with
    # CAPTURE_LOCK held. Guards against the list growing stale if a capture's
    # own stop-timer thread hasn't run yet but the process already exited.
    for p in list(ACTIVE_CAPTURES):
        if p.poll() is not None: ACTIVE_CAPTURES.remove(p)

# Import-time state setup. A non-root invocation (e.g. someone running this
# file directly to read --help) cannot mkdir/chmod under /etc and /var, and an
# unhandled PermissionError here would replace main()'s clear "must run as
# root" message with a traceback. Best-effort: main() still refuses to start
# as non-root, and a genuinely broken /var/lib/locsecd surfaces at first use.
for p in (ETC,STATE,REPORTS,CAPTURES,QUAR):
    try: p.mkdir(parents=True, exist_ok=True)
    except OSError: pass
for p,mode in ((STATE,0o700),(REPORTS,0o700),(CAPTURES,0o700),(QUAR,0o700)):
    try: os.chmod(p,mode)
    except OSError: pass
try:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(LOG.parent,0o750)
except OSError: pass

DEFAULTS={
 'listen':'127.0.0.1','port':8765,'idle_load':1.0,'idle_seconds':600,
 'auth_threshold':5,'auth_window':900,'feed_interval':43200,
 # AIDE/Lynis/Debsecan/rkhunter/ports+fw/CVE run once a week each,
 # staggered scan_stagger_seconds apart so a week's worth of scans doesn't
 # land on the same day. ClamAV is on its own daily interval instead (see
 # clamav_scan_interval) since a rootkit/audit cadence that's fine weekly is
 # too slow for antivirus. update_interval is the separate apt-security-patch
 # cadence (twice a day), independent of the weekly scan schedule.
 # scan_stagger_seconds defaults to a full day (not an hour) so the six
 # weekly jobs land on six different calendar days rather than clustering
 # within a few hours of each other. scan_jobs_per_day is the actual
 # enforcement of that spacing: even if several jobs become overdue at once
 # (e.g. after the host was busy/offline for days), at most this many weekly
 # jobs are allowed to start per calendar day -- the rest simply wait for
 # the next day(s) rather than firing back-to-back the moment the machine
 # goes idle.
 'scan_interval':604800,'clamav_scan_interval':86400,'scan_stagger_seconds':86400,'scan_jobs_per_day':1,'clamav_batch_size':20000,
 'update_interval':43200,'update_lead_seconds':1800,'defs_update_interval':86400,
 'feed_auto_block':True,'feed_auto_block_limit':500,'update_security_only':True,
 'auto_block':True,'auto_update':True,'max_auto_block_prefix':8,'include_phased_updates':False,
 'ipv6_auto_block':True,'incident_retention':10000,'event_poll_seconds':60,'block_ttl_days':30,'incident_ttl_days':30,
 'dashboard_report_max_mb':100,'max_report_count':100,'max_capture_count':20,
 # Per-tool wall-clock limits (seconds). AIDE on a large home directory legitimately needs well over an
 # hour (Debian's own daily check was measured at ~80 min), so its default is 3h.
 'aide_scan_timeout':10800,'lynis_timeout':3600,'clamav_timeout':7200,
 # ClamAV only scans these paths (default: users' home directories). Everything else on the system is
 # covered by package verification (AIDE/debsums-style) and rkhunter, not by an antivirus walk of /usr.
 'clamav_scan_paths':['/home'],'clamav_max_file_mb':100,'clamav_extra_excludes':[],'rkhunter_ignore':[],
 # report_retention_days: every file under reports/ (scan, CVE and update
 # reports, and the full AIDE outputs) is deleted once it is this many days
 # old, so reports never fill the disk. retention_days still covers captures
 # and LocSec's rotated log files.
 'retention_days':14,'report_retention_days':7,'log_auth_each_attempt':True,'log_network_denials':True,'log_app_connection_failures':True,
 'notify_on':{'virus-found':True,'rootkit-warning':True,'block':False,'login-failure':False,'port-scan':True,'firewall-fallback':True},
 'response_auth_block':True,'response_feed_block':True,
 # Port-scan detection reads the firewall's own "denied" log lines (UFW's, or
 # the fallback firewall's below) and blocks a source that probes scan_ports
 # different ports within scan_window seconds. UFW rate-limits its logging to
 # a burst of 10 lines, so scan_ports must stay below that to see a fast scan.
 'scan_detect':True,'response_scan_block':True,'scan_ports':8,'scan_window':600,
 # A scan block is short and rate-limited: the source address of a probe can be forged, so a
 # forged scan must not be able to lock out many hosts, or one host for long.
 'scan_block_hours':24,'scan_block_max_per_hour':10,
 # When UFW is installed but not enabled, LocSec installs its own nftables
 # default-deny input chain until UFW is enabled again. Ports listed here stay
 # reachable while it is on.
 'fallback_firewall':True,'fallback_allow_tcp':[],'fallback_allow_udp':[],
 'feed_urls':['https://www.spamhaus.org/drop/drop.txt','https://feodotracker.abuse.ch/downloads/ipblocklist_recommended.txt'],
 'allow_ips':['127.0.0.0/8','10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','::1/128','fc00::/7'],
}

_LOG_RATE={'minute':0,'n':0,'dropped':0}
_LOG_RATE_LOCK=threading.Lock()
_LOG_MAX_PER_MIN=600

def log(msg, level='INFO'):
    # One record per line. A newline inside a message split it into stray rows on the Logs
    # page (the empty "Heads up"), and text quoted from another log could forge an entry.
    msg=re.sub(r'[\r\n]+',' | ',str(msg)).strip()[:8000]
    # At most _LOG_MAX_PER_MIN lines a minute: every attempt of a brute force, every
    # dropped packet and every connection failure ends up here, and logrotate only
    # runs once a day. ERROR lines always get through.
    now=datetime.now(timezone.utc); minute=int(time.time()//60); note=None
    with _LOG_RATE_LOCK:
        r=_LOG_RATE
        if r['minute']!=minute:
            if r['dropped']: note=f"{now.isoformat()} WARN log flood: {r['dropped']} lines were not written in the previous minute (more than {_LOG_MAX_PER_MIN})"
            r.update(minute=minute,n=0,dropped=0)
        r['n']+=1
        if r['n']>_LOG_MAX_PER_MIN and level!='ERROR':
            r['dropped']+=1; return
    try:
        if note: append_line(LOG, note, 0o640)
        append_line(LOG, f"{now.isoformat()} {level} {msg}", 0o640)
    except Exception: pass


def load_conf():
    cfg=dict(DEFAULTS)
    if CONF.exists():
        try:
            data=json.loads(CONF.read_text())
            if isinstance(data,dict): cfg.update(data)
        except Exception as e: log(f'configuration parse error: {e}','ERROR')
    return cfg
CFG=load_conf()
LISTEN_ADDR='127.0.0.1'

def _normalize_config():
    # Clamp operator-controlled numeric settings so malformed JSON cannot
    # create zero/negative timers, invalid ports, or unbounded report limits.
    int_rules={
        'port':(1,65535,8765),'auth_threshold':(1,100000,5),'auth_window':(15,604800,900),
        'feed_interval':(60,2592000,43200),'scan_interval':(300,31536000,604800),
        'clamav_scan_interval':(300,31536000,86400),'scan_stagger_seconds':(0,604800,86400),
        'scan_jobs_per_day':(1,10,1),
        'clamav_batch_size':(500,500000,20000),
        'update_interval':(300,31536000,43200),'update_lead_seconds':(0,86400,1800),
        'defs_update_interval':(300,31536000,86400),'event_poll_seconds':(15,3600,60),
        'idle_seconds':(30,86400,600),'incident_retention':(100,100000,10000),
        'retention_days':(1,3650,14),'report_retention_days':(1,3650,7),'block_ttl_days':(1,3650,30),'incident_ttl_days':(1,3650,30),
        'max_auto_block_prefix':(1,100000,8),
        'feed_auto_block_limit':(0,10000,500),
        'dashboard_report_max_mb':(1,1024,100),'max_report_count':(10,1000,100),
        'aide_scan_timeout':(300,259200,10800),'lynis_timeout':(60,86400,3600),'clamav_timeout':(60,259200,7200),
        'clamav_max_file_mb':(1,4096,100),
        'max_capture_count':(1,100,20),'scan_nice':(-20,19,10),
        'scan_ports':(3,1000,8),'scan_window':(60,86400,600),
        'scan_block_hours':(1,720,24),'scan_block_max_per_hour':(1,1000,10)
    }
    for k,(lo,hi,default) in int_rules.items():
        try: v=int(CFG.get(k,default))
        except Exception: v=default
        CFG[k]=max(lo,min(hi,v))
    try: v=float(CFG.get('idle_load',1.0)); CFG['idle_load']=max(0.01,min(100.0,v))
    except Exception: CFG['idle_load']=1.0
    # The dashboard is a root control panel, so it is reachable from this
    # machine only. "listen" stays in the configuration so the address is
    # visible, but it is pinned: any other value is replaced by 127.0.0.1, and
    # the log says so, rather than exposing the API to the network.
    lv=CFG.get('listen')
    if lv not in ('127.0.0.1','localhost'):
        log(f'listen={lv!r} in {CONF} is not allowed: the dashboard only listens on {LISTEN_ADDR}','WARN')
    CFG['listen']=LISTEN_ADDR
    if not isinstance(CFG.get('feed_urls'),list): CFG['feed_urls']=list(DEFAULTS['feed_urls'])
    # HTTPS only: a feed fetched over plain HTTP can be rewritten in transit,
    # and whoever rewrites it chooses what this machine blocks.
    dropped=[x for x in CFG['feed_urls'][:32] if isinstance(x,str) and x.startswith('http://')]
    if dropped: log(f'ignoring {len(dropped)} feed URL(s) that are not HTTPS: {", ".join(str(d)[:120] for d in dropped)}','WARN')
    CFG['feed_urls']=[str(x)[:2048] for x in CFG['feed_urls'][:32] if isinstance(x,str) and x.startswith('https://')]
    if not CFG['feed_urls']: CFG['feed_urls']=list(DEFAULTS['feed_urls'])
    # clamav_scan_paths: absolute paths only; anything malformed falls back to /home.
    sp=CFG.get('clamav_scan_paths')
    if not isinstance(sp,list): sp=list(DEFAULTS['clamav_scan_paths'])
    sp=[str(x)[:1024] for x in sp[:32] if isinstance(x,str) and x.startswith('/')]
    CFG['clamav_scan_paths']=sp or list(DEFAULTS['clamav_scan_paths'])
    for k in ('clamav_extra_excludes','rkhunter_ignore'):
        if not isinstance(CFG.get(k),list): CFG[k]=[]
        CFG[k]=[str(x)[:512] for x in CFG[k][:128] if isinstance(x,str)]
    for k in ('fallback_allow_tcp','fallback_allow_udp'):
        v=CFG.get(k); ports=[]
        for x in (v if isinstance(v,list) else [])[:64]:
            try: n=int(x)
            except Exception: continue
            if 1<=n<=65535 and n not in ports: ports.append(n)
        CFG[k]=ports
    for k in ('scan_detect','response_scan_block','fallback_firewall'):
        if not isinstance(CFG.get(k),bool): CFG[k]=DEFAULTS[k]
    no=CFG.get('notify_on')
    CFG['notify_on']={str(k)[:64]:v for k,v in (no.items() if isinstance(no,dict) else DEFAULTS['notify_on'].items()) if isinstance(v,bool)}
    if not isinstance(CFG.get('allow_ips'),list): CFG['allow_ips']=list(DEFAULTS['allow_ips'])
    CFG['allow_ips']=[str(x)[:128] for x in CFG['allow_ips'][:256]]

_normalize_config()
_POLICY_KEYS=('auto_block','response_auth_block','response_feed_block','ipv6_auto_block','response_scan_block','fallback_firewall')
_POLICY_LABELS={'auto_block':'automatic blocking','response_auth_block':'failed-login blocking','response_feed_block':'threat-feed blocking',
                'ipv6_auto_block':'IPv6 blocking','response_scan_block':'port-scan blocking','fallback_firewall':'spare wall when UFW is off'}
RUNTIME_POLICY=ETC/'runtime-policy.json'
if RUNTIME_POLICY.exists():
    try:
        rp=json.loads(RUNTIME_POLICY.read_text())
        if isinstance(rp,dict):
            for k in _POLICY_KEYS:
                if isinstance(rp.get(k),bool): CFG[k]=rp[k]
            if isinstance(rp.get('notify_on'),dict):
                merged=dict(CFG.get('notify_on',{}))
                for k,v in rp['notify_on'].items():
                    if isinstance(v,bool): merged[str(k)[:64]]=v
                CFG['notify_on']=merged
    except Exception: pass


# Tools that colourise their output even when stdout is not a TTY (rkhunter
# does) leave ANSI escape sequences in everything we capture. Left in, they
# render as escape garbage in the dashboard and in stored JSON reports -- and a
# colour code in front of "Warning:" also defeats rkhunter warning
# classification, which matches on the start of the line.
_ANSI_CSI=re.compile(r'\x1b\[[0-9;?]*[ -/]*[@-~]')
_ANSI_REST=re.compile(r'\x1b[@-Z\\-_]|[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')

def _strip_ansi(text):
    # ESC[<n>C (cursor-forward) is how rkhunter pads its columns; turn it into a
    # single space so words don't run together, then drop the remaining codes.
    text=re.sub(r'\x1b\[[0-9]+C',' ',text)
    return _ANSI_REST.sub('',_ANSI_CSI.sub('',text))

def _bounded_read(buf, tail=20000, head=0):
    # Return at most head+tail characters of a spooled output file: the first
    # `head` bytes (useful when a tool prints its summary first, e.g. AIDE) and
    # the last `tail` bytes (useful when it prints the summary last).
    size=buf.seek(0,2)
    if head and size>head+tail:
        buf.seek(0); h=buf.read(head)
        buf.seek(size-tail); t=buf.read()
        return _strip_ansi(h.decode('utf-8','replace')+f'\n... [{size-head-tail} bytes omitted] ...\n'+t.decode('utf-8','replace'))
    buf.seek(max(0,size-tail))
    return _strip_ansi(buf.read().decode('utf-8','replace'))

def run(cmd, timeout=60, input_text=None, kill_group=False, head=0, save_to=None, tail=20000):
    # Long scans (clamscan/lynis/rkhunter over "/") can emit output far larger
    # than fits comfortably in RAM if buffered through subprocess.PIPE -- a
    # multi-GB stdout blob has previously been observed to bloat the daemon's
    # resident memory during heavy_scan(). Spool to a temp file on disk instead
    # and only ever read back the bounded portion we actually keep.
    #
    # kill_group=True additionally runs cmd in its own session and, on
    # timeout, kills that whole process group rather than just the direct
    # child -- for commands like apt-get/unattended-upgrade that can spawn
    # their own children (e.g. dpkg); subprocess.run's own timeout handling
    # only ever signals the one PID it started, which can leave such a child
    # running (and a lock held) after we've already given up and moved on.
    #
    # save_to=<path> additionally writes the COMPLETE output there (mode 0600)
    # for callers that must parse all of it rather than just the tail.
    # head=N keeps the first N bytes as well as the tail when output is large.
    try:
        # /tmp is a RAM-backed tmpfs on Debian 13, and PrivateTmp pages are charged to
        # this service's MemoryMax: spool large outputs on disk beside LocSec's state.
        spool=str(STATE) if STATE.is_dir() and os.access(STATE,os.W_OK) else None
        with tempfile.TemporaryFile(mode='w+b',dir=spool) as buf:
            data=input_text.encode('utf-8','replace') if input_text is not None else None
            timed_out=False
            if kill_group:
                proc=subprocess.Popen(cmd, stdin=subprocess.PIPE if data is not None else None,
                                       stdout=buf, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    proc.communicate(input=data, timeout=timeout)
                    rc=proc.returncode
                except subprocess.TimeoutExpired:
                    timed_out=True; rc=124
                    try: os.killpg(proc.pid, signal.SIGTERM)
                    except Exception: pass
                    try: proc.wait(timeout=5)
                    except Exception:
                        try: os.killpg(proc.pid, signal.SIGKILL)
                        except Exception: pass
                        try: proc.wait(timeout=5)
                        except Exception: pass
            else:
                try:
                    p=subprocess.run(cmd, input=data, stdout=buf, stderr=subprocess.STDOUT, timeout=timeout, check=False)
                    rc=p.returncode
                except subprocess.TimeoutExpired:
                    timed_out=True; rc=124
            if save_to:
                try:
                    buf.seek(0)
                    with open(save_to,'wb') as f:
                        os.chmod(save_to,0o600); shutil.copyfileobj(buf,f)
                except Exception as e: log(f'could not save command output to {save_to}: {e}','ERROR')
            out=_bounded_read(buf,tail,head)
            if timed_out:
                out+=f'\n(timed out after {timeout}s'+('; process group terminated)' if kill_group else ')')
            return rc,out
    except Exception as e: return 127,str(e)


def have(cmd):
    return shutil.which(str(cmd)) is not None


def append_line(path, text, mode=0o600):
    """Append one newline-terminated record, repairing a truncated last line.

    These logs are appended to constantly and the daemon can be killed at any
    moment -- SIGKILL after TimeoutStopSec, an OOM kill, power loss. A write
    interrupted part-way leaves a line with no terminating newline, and the
    next plain append then lands on that same line: the partial record is
    unparseable (readers skip it, which is correct) but so is the good record
    welded onto it, so a crash silently costs the NEXT incident as well as the
    interrupted one. Checking the final byte first costs one seek per append
    and confines the damage to the record that was actually interrupted.
    """
    with open(path,'a+',encoding='utf-8') as f:
        try:
            f.seek(0,os.SEEK_END)
            if f.tell():
                f.seek(f.tell()-1)
                if f.read(1)!='\n':
                    f.write('\n')
        except OSError:
            pass                      # unseekable is not a reason to drop the record
        f.write(text if text.endswith('\n') else text+'\n')
    try: os.chmod(path,mode)
    except OSError: pass

def atomic_json(path,data):
    # A unique temporary name: two writers (the daemon and a locsecctl one-shot) used the
    # same "<file>.tmp", so one could rename the other's half-written file into place.
    fd,tmp=tempfile.mkstemp(prefix='.'+path.name+'.',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            f.write(json.dumps(data,indent=2,sort_keys=True))
        os.chmod(tmp,0o600)
        os.replace(tmp,path)
    except BaseException:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def prune_runtime_state():
    # Keep bounded local state so a 24/7 daemon cannot grow without limit.
    for root,pattern,keep in ((REPORTS,'*.json',int(CFG.get('max_report_count',100))),(REPORTS,'aide-full-*.txt',10),(CAPTURES,'*.pcapng',int(CFG.get('max_capture_count',20)))):
        try:
            files=sorted(root.glob(pattern),key=lambda x:x.stat().st_mtime,reverse=True)
            for f in files[keep:]: f.unlink(missing_ok=True)
        except Exception as e: log(f'state prune failed for {root}: {e}','ERROR')
    # Age-based retention: delete reports, quarantine metadata and old incident
    # lines past retention_days regardless of the count caps above. Runs on
    # every prune cycle (same cadence as the count-based prune).
    try:
        days=max(1,int(CFG.get('retention_days',14))); cutoff=time.time()-days*86400
        # Incidents have their own retention window (incident_ttl_days), separate from the
        # reports/captures/log window above -- an incident timeline is usually worth keeping
        # longer than the raw scan output that produced it.
        inc_cutoff=time.time()-max(1,int(CFG.get('incident_ttl_days',30)))*86400
        for root,pattern in ((CAPTURES,'*.pcapng',),):
            for f in root.glob(pattern):
                try:
                    if f.stat().st_mtime<cutoff: f.unlink(missing_ok=True)
                except Exception: pass
        # Reports: everything in the reports directory, whatever its name,
        # once it is report_retention_days old (7 by default).
        rdays=max(1,int(CFG.get('report_retention_days',7))); rcut=time.time()-rdays*86400; gone=0
        try: entries=list(REPORTS.iterdir())
        except OSError: entries=[]
        for f in entries:
            try:
                if f.is_symlink() or not f.is_file(): continue
                if f.stat().st_mtime<rcut: f.unlink(); gone+=1
            except OSError: pass
        if gone: log(f'reports older than {rdays} days removed: {gone}')
        # Both rewrites below hold LOCK. incident() and _action_log() append to
        # these files from the HTTP and monitor threads; a rewrite that read the
        # file, let an append land, then replaced it dropped that record for good.
        with LOCK:
            if INCIDENTS.exists():
                kept=[]
                for line in INCIDENTS.read_text(errors='replace').splitlines():
                    try:
                        rec=json.loads(line)
                        ts=float(rec.get('updated') or rec.get('ts') or 0)
                        if ts>=inc_cutoff: kept.append(line)
                    except Exception:
                        continue
                tmp=INCIDENTS.with_suffix('.tmp'); tmp.write_text('\n'.join(kept)+('\n' if kept else ''),encoding='utf-8')
                os.chmod(tmp,0o600); os.replace(tmp,INCIDENTS)
                _INC['loaded']=False       # the in-memory index described the old file
            # incident-actions.jsonl had no retention at all: every Investigate,
            # Contain, Resolve and Confirm appended a line that was never removed.
            if INCIDENT_ACTIONS.exists():
                rows=[l for l in _tail_lines(INCIDENT_ACTIONS,20000) if l.strip()]
                kept=[]
                for l in rows:
                    try:
                        if float(json.loads(l).get('ts',0))>=inc_cutoff: kept.append(l)
                    except Exception: continue
                if len(kept)!=len(rows) or INCIDENT_ACTIONS.stat().st_size>4*1024*1024:
                    tmp=INCIDENT_ACTIONS.with_suffix('.tmp')
                    tmp.write_text('\n'.join(kept)+('\n' if kept else ''),encoding='utf-8')
                    os.chmod(tmp,0o600); os.replace(tmp,INCIDENT_ACTIONS)
        for logfile in list(LOG.parent.glob('locsecd.log*')):
            try:
                if logfile.stat().st_mtime<cutoff: logfile.unlink(missing_ok=True)
            except Exception: pass
    except Exception as e: log(f'age-based retention prune failed: {e}','ERROR')



def _tail_lines(path, limit, max_bytes=2000000):
    # Read only the end of a growing append-only file. recent_incidents() used to
    # pull the whole incidents log into memory and then keep the last few lines:
    # with incident_retention at its 10000 default that is several megabytes read,
    # decoded and split on every /api/status call.
    try:
        with open(path,'rb') as f:
            size=f.seek(0,2)
            f.seek(max(0,size-max_bytes))
            data=f.read()
    except OSError:
        return []
    lines=data.decode('utf-8','replace').splitlines()
    # A partial first line is possible whenever the window started mid-file.
    if size>max_bytes and lines: lines=lines[1:]
    return lines[-limit:] if limit else lines

def _incident_key(rec):
    return (str(rec.get('kind','')), str(rec.get('source','')), str(rec.get('indicator','')))

# ---------------------------------------------------------------------------
# Incident store: append-only log with periodic compaction.
#
# incidents.jsonl holds one complete record per line, and for any given id the
# LAST line wins. A delete appends a tombstone. Nothing rewrites the file except
# compact_incidents().
#
# The previous design read the entire file, mutated a list and wrote all of it
# back for every single detection. At the 10000-record default that is a
# multi-megabyte read-modify-write per event while holding LOCK, so a port-scan
# burst turned into tens of megabytes of I/O per second.
#
# What stays in memory is deliberately small: the active incidents (the only
# ones eligible for deduplication, normally a handful) and the set of live ids
# (for the Overview counter). Operations on an arbitrary id read a bounded
# window from the end of the log -- which is where anything the dashboard can
# show came from -- and widen to the whole file only if that misses.
# ---------------------------------------------------------------------------
_INC_ACTIVE_STATES=('new','investigating','contained')
_INC={'loaded':False,'active':{},'ids':set(),'appends':0}
_INC_COMPACT_APPENDS=2000
_INC_LOAD_MAX_BYTES=256*1024*1024

def _incident_retention():
    return max(100,min(100000,int(CFG.get('incident_retention',10000))))

def _inc_resolve(lines):
    """Collapse raw log lines into the current record per id, in first-seen order."""
    order=[]; byid={}
    for line in lines:
        if not line.strip(): continue
        try: rec=json.loads(line)
        except Exception: continue
        if not isinstance(rec,dict): continue
        ident=str(rec.get('id',''))
        if rec.get('_op')=='delete':
            byid.pop(ident,None); continue
        if not ident: continue
        if ident not in byid: order.append(ident)
        byid[ident]=rec
    return [byid[i] for i in order if i in byid]

def _inc_load():
    """Build the in-memory index once per process. Call with LOCK held."""
    if _INC['loaded']: return
    active={}; ids=set()
    for rec in _inc_resolve(_tail_lines(INCIDENTS,0,max_bytes=_INC_LOAD_MAX_BYTES)):
        ids.add(str(rec.get('id','')))
        if str(rec.get('state','new')) in _INC_ACTIVE_STATES:
            active[_incident_key(rec)]=rec
    _INC['active']=active; _INC['ids']=ids; _INC['appends']=0; _INC['loaded']=True

def _inc_append(obj):
    append_line(INCIDENTS, json.dumps(obj,separators=(',',':')))
    _INC['appends']+=1

def _inc_find(ident):
    """Current record for one id, without reading more of the log than needed."""
    ident=str(ident)[:64]
    if not ident: return None
    try: size=INCIDENTS.stat().st_size
    except OSError: return None
    windows=[4*1024*1024]
    if size>windows[0]: windows.append(_INC_LOAD_MAX_BYTES)
    for w in windows:
        for rec in reversed(_inc_resolve(_tail_lines(INCIDENTS,0,max_bytes=w))):
            if str(rec.get('id',''))==ident: return rec
    return None

def _inc_store(rec):
    """Persist a new or changed record and keep the in-memory view in step."""
    ident=str(rec.get('id','')); key=_incident_key(rec)
    _inc_append(rec)
    _INC['ids'].add(ident)
    if str(rec.get('state','new')) in _INC_ACTIVE_STATES:
        cur=_INC['active'].get(key)
        # Reopening an old record must not hide a newer active one for the same key.
        if cur is None or str(cur.get('id',''))==ident or float(cur.get('ts') or 0)<=float(rec.get('ts') or 0):
            _INC['active'][key]=rec
    else:
        cur=_INC['active'].get(key)
        if cur is not None and str(cur.get('id',''))==ident: _INC['active'].pop(key,None)
    if _INC['appends']>=_INC_COMPACT_APPENDS: compact_incidents()

def _inc_forget(ident):
    ident=str(ident)[:64]
    _inc_append({'_op':'delete','id':ident,'ts':time.time()})
    _INC['ids'].discard(ident)
    for k,v in list(_INC['active'].items()):
        if str(v.get('id',''))==ident: _INC['active'].pop(k,None)

def compact_incidents():
    """The only writer that rewrites the log: one current record per incident,
    oldest first, within incident_retention and incident_ttl_days."""
    try:
        recs=_inc_resolve(_tail_lines(INCIDENTS,0,max_bytes=_INC_LOAD_MAX_BYTES))
        cutoff=time.time()-max(1,int(CFG.get('incident_ttl_days',30)))*86400
        def _ts(r):
            try: return float(r.get('updated') or r.get('ts') or 0)
            except Exception: return 0.0
        kept=[r for r in recs if _ts(r)>=cutoff]
        kept.sort(key=_ts)
        kept=kept[-_incident_retention():]
        tmp=INCIDENTS.with_suffix('.tmp')
        with tmp.open('w',encoding='utf-8') as f:
            for rec in kept: f.write(json.dumps(rec,separators=(',',':'))+'\n')
        os.chmod(tmp,0o600); os.replace(tmp,INCIDENTS)
        _INC['loaded']=False; _inc_load()
        return len(kept)
    except Exception as e:
        log(f'incident log compaction failed: {e}','ERROR'); return -1

def _action_log(rec_id, action, message, detail=''):
    entry={'ts':time.time(),'incident_id':str(rec_id)[:64],'action':str(action)[:32],
           'message':str(message)[:1000],'detail':str(detail)[:4000]}
    try:
        with LOCK: append_line(INCIDENT_ACTIONS, json.dumps(entry,separators=(',',':')))
    except Exception as e: log(f'incident action log failed: {e}','ERROR')
    log(f'incident={rec_id} action={action}: {message}')

# Desktop notifications. The daemon sends them itself, as a normal desktop
# notification in the session of each logged-in graphical user, so they appear
# (and are kept in the desktop's notification list) whether or not the
# dashboard window is open. Each one asks for a 10 second display time.
_NOTIFY_TITLES={'virus-found':'Virus found','rootkit-warning':'Rootkit warning','block':'IP blocked',
                'login-failure':'Failed login','port-scan':'Port scan detected',
                'firewall-fallback':'Fallback firewall turned on','test':'Test notification'}
_NOTIFY_ICONS={'virus-found':'dialog-error','rootkit-warning':'dialog-error','test':'dialog-information'}
_NOTIFY_SECONDS=10
_NOTIFY_KINDS=('virus-found','rootkit-warning','block','login-failure','port-scan','firewall-fallback')
_NOTIFY_Q=queue.Queue(maxsize=200)
_NOTIFY_SEEN={}
_NOTIFY_LOCK=threading.Lock()

def _notify_desktop(rec,force=False):
    """Queue a notification for a new incident of a kind the operator ticked."""
    kind=str(rec.get('kind',''))
    if not force and not CFG.get('notify_on',{}).get(kind): return
    ind=str(rec.get('indicator',''))
    if not force:
        now=time.time()
        with _NOTIFY_LOCK:
            # The same kind and address is not announced again for ten minutes.
            if now-_NOTIFY_SEEN.get((kind,ind),0)<600: return
            if len(_NOTIFY_SEEN)>2000: _NOTIFY_SEEN.clear()
            _NOTIFY_SEEN[(kind,ind)]=now
    try: _NOTIFY_Q.put_nowait((kind,ind,str(rec.get('detail',''))))
    except queue.Full: pass

def _desktop_users():
    """Uids with an active local graphical session and a session bus."""
    uids=[]
    if not have('loginctl'): return uids
    rc,out=run(['loginctl','list-sessions','--no-legend','--no-pager'],10)
    if rc!=0: return uids
    for line in out.splitlines():
        parts=line.split()
        if len(parts)<2 or not parts[1].isdigit() or int(parts[1])==0 or int(parts[1]) in uids: continue
        if not re.fullmatch(r'[A-Za-z0-9_.-]+',parts[0]): continue
        rc,o=run(['loginctl','show-session',parts[0],'-p','Type','-p','Active','-p','Remote'],10)
        info=dict(l.split('=',1) for l in o.splitlines() if '=' in l)
        if (rc==0 and info.get('Type') in ('x11','wayland') and info.get('Active')=='yes'
                and info.get('Remote','no')=='no' and os.path.exists(f'/run/user/{int(parts[1])}/bus')):
            uids.append(int(parts[1]))
    return uids

def _desktop_send(uid,kind,title,body):
    clean=lambda t: re.sub(r'[\x00-\x1f\x7f]+',' ',str(t)).strip()
    title=clean(title)[:80]
    # Notification bodies accept a little markup; text from logs must not.
    body=clean(body)[:300].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    icon=_NOTIFY_ICONS.get(kind,'dialog-warning'); ms=_NOTIFY_SECONDS*1000
    if have('notify-send'):
        cmd=['notify-send','--app-name=LocSec','--icon='+icon,f'--expire-time={ms}','--urgency=normal','--',title,body]
    elif have('gdbus'):
        gv=lambda t:"'"+t.replace('\\','\\\\').replace("'","\\'")+"'"
        cmd=['gdbus','call','--session','--dest','org.freedesktop.Notifications','--object-path','/org/freedesktop/Notifications',
             '--method','org.freedesktop.Notifications.Notify','LocSec','0',icon,gv(title),gv(body),'[]','{}',str(ms)]
    else:
        return False
    # The notification helper needs nothing but the user's session bus socket.
    props=[f'User={int(uid)}','NoNewPrivileges=yes','CapabilityBoundingSet=','AmbientCapabilities=',
           'ProtectSystem=strict','PrivateTmp=yes','RestrictAddressFamilies=AF_UNIX','RestrictNamespaces=yes',
           'ProtectKernelTunables=yes','ProtectKernelModules=yes','ProtectKernelLogs=yes','ProtectControlGroups=yes',
           'SystemCallFilter=@system-service','UMask=0077',
           f'Environment=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{int(uid)}/bus XDG_RUNTIME_DIR=/run/user/{int(uid)}']
    rc,out=_run_transient(cmd,20,prefix='locsecd-notify',props=props)
    if rc!=0: log(f'desktop notification for uid {uid} failed: {out.strip()[-200:]}','WARN')
    return rc==0

def _deliver_notifications(batch):
    users=_desktop_users()
    if not users:
        log('desktop notification not shown: no local graphical session is active','INFO'); return
    by={}
    for kind,ind,detail in batch: by.setdefault(kind,[]).append((ind,detail))
    msgs=[]
    single=len(batch)<=3
    for kind,items in by.items():
        title='LocSec: '+_NOTIFY_TITLES.get(kind,kind.replace('-',' '))
        if single or len(items)==1:
            for ind,detail in items: msgs.append((kind,title,(ind+' \u2014 ' if ind and detail else ind)+detail))
        else:
            sample=', '.join(i for i,_ in items[:4] if i)
            msgs.append((kind,title,f'{len(items)} new'+(f': {sample}' if sample else '')+(', ...' if len(items)>4 else '')))
    for uid in users:
        for kind,title,body in msgs[:6]: _desktop_send(uid,kind,title,body)

def _notifier_loop():
    while not STOP_EVENT.is_set():
        try: first=_NOTIFY_Q.get(timeout=2)
        except queue.Empty: continue
        batch=[first]
        STOP_EVENT.wait(1.5)     # let a burst (a feed refresh blocking many addresses) collect
        while True:
            try: batch.append(_NOTIFY_Q.get_nowait())
            except queue.Empty: break
        try: _deliver_notifications(batch)
        except Exception as e: log(f'desktop notifier: {e}','ERROR')

def incident(kind, source, indicator='', severity='medium', action='logged', detail=''):
    """Upsert an active incident; repeated polling/feed observations become count/last_seen."""
    key=(str(kind)[:64],str(source)[:64],str(indicator)[:512]); now=time.time()
    try:
        with LOCK:
            _inc_load()
            rec=_INC['active'].get(key)
            if rec is not None:
                rec['last_seen']=now; rec['count']=int(rec.get('count',1))+1
                rec['severity']=str(severity)[:16]; rec['action']=str(action)[:64]
                rec['detail']=str(detail)[:2000]; rec['updated']=now
                _inc_store(rec)
                return rec
            rec={'id':hashlib.sha256(f'{time.time_ns()}|{kind}|{source}|{indicator}'.encode()).hexdigest()[:24],
                 'ts':now,'last_seen':now,'count':1,'kind':key[0],'source':key[1],
                 'indicator':key[2],'severity':str(severity)[:16],'action':str(action)[:64],
                 'detail':str(detail)[:2000],'state':'new'}
            _inc_store(rec)
        _action_log(rec['id'],'create',f'New {kind} incident from {source}',detail)
        _notify_desktop(rec)
        return rec
    except Exception as e:
        log(f'incident write failed: {e}','ERROR'); return {'id':'','state':'new'}

def delete_incident(identifier):
    ident=str(identifier)[:64]
    with LOCK:
        _inc_load()
        if ident not in _INC['ids'] and _inc_find(ident) is None:
            return {'ok':False,'error':'incident not found'}
        _inc_forget(ident)
    try:
        with LOCK:
            if INCIDENT_ACTIONS.exists():
                # Guard each line: an unparseable one used to raise out of the whole
                # comprehension, so a single corrupt record left every deleted
                # incident's action rows behind from then on.
                lines=[]
                for l in INCIDENT_ACTIONS.read_text(errors='replace').splitlines():
                    if not l.strip(): continue
                    try: drop=json.loads(l).get('incident_id','')==ident
                    except Exception: drop=False
                    if not drop: lines.append(l)
                tmp=INCIDENT_ACTIONS.with_suffix('.tmp'); tmp.write_text('\n'.join(lines)+('\n' if lines else ''),encoding='utf-8')
                os.chmod(tmp,0o600); os.replace(tmp,INCIDENT_ACTIONS)
    except Exception as e: log(f'incident action-log cleanup failed: {e}','ERROR')
    log(f'incident {ident} deleted')
    return {'ok':True}

def delete_all_incidents():
    with LOCK:
        try:
            INCIDENTS.write_text('',encoding='utf-8'); os.chmod(INCIDENTS,0o600)
        except OSError as e: log(f'incident log clear failed: {e}','ERROR')
        _INC['active']={}; _INC['ids']=set(); _INC['appends']=0; _INC['loaded']=True
    try:
        if INCIDENT_ACTIONS.exists():
            os.chmod(INCIDENT_ACTIONS,0o600); INCIDENT_ACTIONS.write_text('',encoding='utf-8')
    except Exception as e: log(f'incident action-log clear failed: {e}','ERROR')
    log('all incidents deleted','WARN')
    return {'ok':True}

def incident_actions(identifier, limit=100):
    ident=str(identifier)[:64]
    try:
        rows=[]
        for line in _tail_lines(INCIDENT_ACTIONS,1000):
            try:
                x=json.loads(line)
                if str(x.get('incident_id',''))==ident: rows.append(x)
            except Exception: pass
        return rows[-max(1,min(int(limit),200)):]
    except Exception: return []

def _incident_evidence(rec):
    """Collect bounded local evidence for a human-readable incident explanation."""
    indicator=str(rec.get('indicator','')); evidence=[]
    if indicator and have('journalctl'):
        # indicator can come from threat-feed or log data outside our control;
        # --grep treats it as a PCRE regex, so escape it rather than passing it
        # through raw.
        _,out=run(['journalctl','--no-pager','--since','-30 minutes','--grep',re.escape(indicator.split('/')[0])],20)
        if out.strip(): evidence.append('Recent journal matches:\n'+out[-5000:])
    if indicator and have('ss'):
        _,out=run(['ss','-Hntup'],15)
        hits=[x for x in out.splitlines() if indicator.split('/')[0] in x][:40]
        if hits: evidence.append('Current socket matches:\n'+'\n'.join(hits))
    detail=str(rec.get('detail',''))
    if detail: evidence.append('Recorded detector detail:\n'+detail[:4000])
    return '\n\n'.join(evidence)[-10000:] or 'No additional local evidence was available.'

def incident_action(identifier, action):
    ident=str(identifier)[:64]; action=str(action).lower().strip()
    action={'investigate':'explain','contain':'fix','resolve':'resolve'}.get(action,action)
    if action not in {'explain','fix','resolve'}: return {'ok':False,'error':'invalid incident action'}
    with LOCK:
        _inc_load(); rec=_inc_find(ident)
    if not rec: return {'ok':False,'error':'incident not found'}
    rec=dict(rec); indicator=str(rec.get('indicator','')); did=None; new_state=str(rec.get('state','new'))
    if action=='explain':
        if new_state=='new': new_state='investigating'
        summary='Explained'
    elif action=='fix':
        k=str(rec.get('kind',''))
        if k=='virus-found' and indicator:
            res=quarantine_file(indicator,signature=str(rec.get('detail','') or 'detected'))
            if res.get('ok'):
                did='Moved the file into quarantine. It cannot run there. Malware / Quarantine can put it back or delete it.'; new_state='resolved'
            else:
                did='Could not quarantine it: '+str(res.get('error','unknown error'))+(' Use Malware / Quarantine with "Force" if you are sure.' if 'system directory' in str(res.get('error','')) else '')
        elif k in _INC_NET_KINDS and _incident_ip(rec):
            ip=_incident_ip(rec)
            if _is_blocked(ip): did=f'{ip} is already blocked.'; new_state='contained'
            else:
                ok,msg=block_ip(ip,f'blocked from incident {ident}','incident-action')
                _BLOCKS_MEMO['t']=0
                if ok:
                    did=f'Blocked {ip}: it can no longer reach this computer. The block lifts by itself after {int(CFG.get("block_ttl_days",30))} days, or unblock it on Firewall & Blocks.'; new_state='contained'
                elif msg=='allowlisted': did=f'LocSec did not block {ip}: it is on your own network (allow_ips), and LocSec never blocks those so you cannot lock yourself out.'
                else: did=f'LocSec did not block {ip}: {msg}'
        else:
            did='LocSec cannot fix this kind of incident by itself. The steps under "What you should do" are the fix.'
        summary=did
    else:
        new_state='resolved'; summary='Marked solved'
        if indicator and _is_blocked(indicator): summary+=f'; {indicator} stays blocked until its block runs out'
        did=summary+'.'
    with LOCK:
        _inc_load(); target=_inc_find(ident)
        if not target: return {'ok':False,'error':'incident not found (deleted during processing)'}
        target['state']=new_state; target['updated']=time.time(); target['note']=str(summary)[:1000]; _inc_store(target)
    evidence=_incident_evidence(target) if action=='explain' else ''
    _action_log(ident,action,str(summary)[:200],str(did or '')[:1000])
    return {'ok':True,'incident':target,'explain':incident_explain(target,did),'evidence':evidence,'actions':incident_actions(ident)}

def recent_incidents(limit=200):
    # The log can carry several lines for one incident, so read a wider window
    # than the row count and collapse it to the current record per id.
    n=max(1,min(int(limit),1000))
    try:
        recs=_inc_resolve(_tail_lines(INCIDENTS,0,max_bytes=max(2000000,n*4096)))
        # Newest activity last (the dashboard reverses it). Ordering by first
        # sighting, as this did, buried an old incident that was still counting
        # up at the bottom of the page while quiet newer ones sat above it.
        def _seen(r):
            try: return float(r.get('updated') or r.get('last_seen') or r.get('ts') or 0)
            except Exception: return 0.0
        recs.sort(key=_seen)
        return recs[-n:]
    except Exception: return []

def prune_incidents():
    # Retention and log compaction are the same operation now.
    with LOCK:
        _inc_load(); compact_incidents()

# Single-use browser login codes. The Qt window hands the dashboard the API
# token in the URL and the daemon swaps it for the session cookie with a
# redirect -- safe there, but an ordinary browser would record that long-lived
# token in its history. On systems without PyQt6 (Ubuntu 22.04 / Mint 21) the
# launcher opens the default browser instead, so it first exchanges the token
# (sent in a header, never in a URL) for one of these: 256 random bits, valid
# for 60 seconds, consumed on first use. What reaches the browser history is a
# dead code.
_LOGIN_CODES={}
_LOGIN_CODES_LOCK=threading.Lock()
_LOGIN_CODE_TTL=60

def mint_login_code():
    code=secrets.token_urlsafe(32); now=time.time()
    with _LOGIN_CODES_LOCK:
        for k in [k for k,exp in _LOGIN_CODES.items() if exp<now]: _LOGIN_CODES.pop(k,None)
        if len(_LOGIN_CODES)>=16: return None
        _LOGIN_CODES[code]=now+_LOGIN_CODE_TTL
    return code

def consume_login_code(code):
    code=str(code or '')
    if not code or len(code)>100 or not code.isascii(): return False
    now=time.time()
    with _LOGIN_CODES_LOCK:
        match=None
        for k in list(_LOGIN_CODES):
            if hmac.compare_digest(k,code): match=k
        if match is None: return False
        exp=_LOGIN_CODES.pop(match)
    return exp>=now

# Browser/GUI sessions. The cookie holds a random session id, never the API
# token, so a stolen cookie is not the long-lived root credential: it expires
# (8 h idle, 3 days at most), is stored only as a hash on disk so it survives a
# service restart, and the 32 newest sessions are kept. Only the token file
# (root-readable) can mint a new one, through a single-use login code.
SESSIONS_FILE=STATE/'sessions.json'
_SESSION_IDLE=8*3600
_SESSION_MAX=3*86400
_SESSION_LIMIT=32
_SESSIONS={'loaded':False,'data':{}}
_SESSIONS_LOCK=threading.Lock()

def _sessions_data():
    if not _SESSIONS['loaded']:
        _SESSIONS['loaded']=True
        try:
            d=json.loads(SESSIONS_FILE.read_text())
            if isinstance(d,dict): _SESSIONS['data']=d
        except Exception: pass
    return _SESSIONS['data']

def _sessions_save():
    try: atomic_json(SESSIONS_FILE,_SESSIONS['data'])
    except Exception as e: log(f'could not save sessions: {e}','WARN')

def new_session():
    now=time.time(); sid=secrets.token_urlsafe(32)
    with _SESSIONS_LOCK:
        d=_sessions_data()
        for k in [k for k,v in d.items() if not isinstance(v,dict) or now-float(v.get('created',0))>_SESSION_MAX or now-float(v.get('last',0))>_SESSION_IDLE]: d.pop(k,None)
        while len(d)>=_SESSION_LIMIT: d.pop(min(d,key=lambda k:float(d[k].get('last',0))),None)
        d[hashlib.sha256(sid.encode()).hexdigest()]={'created':now,'last':now}
        _sessions_save()
    return sid

def session_ok(sid):
    if not sid or len(sid)>100: return False
    now=time.time(); h=hashlib.sha256(sid.encode()).hexdigest()
    with _SESSIONS_LOCK:
        d=_sessions_data(); rec=d.get(h)
        if not isinstance(rec,dict): return False
        if now-float(rec.get('created',0))>_SESSION_MAX or now-float(rec.get('last',0))>_SESSION_IDLE:
            d.pop(h,None); _sessions_save(); return False
        if now-float(rec.get('last',0))>60: rec['last']=now; _sessions_save()
        return True

def token_value():
    # Fast path: every authenticated request reads this, so stay out of LOCK
    # unless the token genuinely has to be created.
    try:
        tok=TOKEN.read_text().strip()
        if tok: return tok
    except OSError: pass
    # First start (or a truncated token file). Create it exactly once: without
    # this, two concurrent requests could each generate and write a different
    # token, and whichever wrote first would have handed out a value the file
    # no longer contains.
    with LOCK:
        try:
            tok=TOKEN.read_text().strip()
            if tok: return tok
        except OSError: pass
        try:
            if TOKEN.exists(): TOKEN.unlink()
        except OSError: pass
        try:
            fd=os.open(str(TOKEN),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            try: os.write(fd,hashlib.sha256(os.urandom(64)).hexdigest().encode('ascii'))
            finally: os.close(fd)
        except FileExistsError: pass
        except OSError as e:
            log(f'could not create the API token: {e}','ERROR'); return ''
        try: return TOKEN.read_text().strip()
        except OSError: return ''


def safe_ip(s):
    # ipaddress accepts any text after '%' as an IPv6 scope id (newlines
    # included), which would let a request write forged lines into the log.
    if '%' in str(s): return None
    try: return ipaddress.ip_address(str(s).strip())
    except (ValueError, TypeError): return None


def safe_network(s):
    if '%' in str(s): return None
    try: return ipaddress.ip_network(str(s).strip(),strict=False)
    except (ValueError, TypeError): return None


def allowed_ip(ip):
    a=safe_ip(ip)
    if not a: return False
    for n in CFG.get('allow_ips',[]):
        try:
            if a in ipaddress.ip_network(n,strict=False): return True
        except ValueError: pass
    return False


def allowed_network(net):
    n=safe_network(net)
    if not n: return False
    for x in CFG.get('allow_ips',[]):
        allow=safe_network(x)
        if not allow or allow.version!=n.version: continue
        try:
            if n.subnet_of(allow): return True
        except (TypeError,ValueError): pass
    return False


BLOCK_TTL_SECONDS_DEFAULT=30*86400

# Addresses this machine depends on to work at all: its DNS servers and default
# gateways. Private ranges are already in allow_ips, but a public resolver
# (1.1.1.1, 8.8.8.8, the ISP's) is not, and blocking one -- because a feed
# lists it, or a forged probe claimed to come from it -- cuts off name
# resolution for the whole machine. Automatic blocks never touch these; a block
# asked for by hand still does exactly what it was asked.
_INFRA_CACHE={'ts':0.0,'ips':frozenset()}
_INFRA_TTL=300
_MANUAL_BLOCK_SOURCES=('manual','incident-action')

def infrastructure_ips():
    now=time.time()
    if now-_INFRA_CACHE['ts']<_INFRA_TTL: return _INFRA_CACHE['ips']
    found=set()
    for f in ('/etc/resolv.conf','/run/systemd/resolve/resolv.conf','/run/NetworkManager/resolv.conf'):
        try:
            for line in Path(f).read_text(errors='replace').splitlines():
                parts=line.split()
                if len(parts)>=2 and parts[0]=='nameserver': found.add(parts[1].split('%')[0])
        except OSError: pass
    if have('nmcli'):
        # Terse multi-line output: one "IP4.DNS[1]:1.1.1.1" per line.
        rc,out=run(['nmcli','-t','-f','IP4.DNS,IP6.DNS,IP4.GATEWAY,IP6.GATEWAY','device','show'],10)
        if rc==0:
            for line in out.splitlines():
                _,_,val=line.partition(':')
                found.add(val.strip().replace('\\:',':'))
    if have('ip'):
        for fam in ('-4','-6'):
            rc,out=run(['ip',fam,'route','show','default'],10)
            if rc==0:
                for m in re.finditer(r'\bvia\s+(\S+)',out): found.add(m.group(1))
    ips=frozenset(str(a) for a in (safe_ip(x) for x in found if x) if a is not None and not a.is_loopback and not a.is_unspecified)
    _INFRA_CACHE.update(ts=now,ips=ips)
    return ips

def _infra_conflict(target):
    """The infrastructure address a block target would cover, or ''."""
    infra=infrastructure_ips()
    if not infra: return ''
    if isinstance(target,(ipaddress.IPv4Address,ipaddress.IPv6Address)):
        return str(target) if str(target) in infra else ''
    for x in infra:
        a=safe_ip(x)
        if a is not None and a.version==target.version and a in target: return x
    return ''

def block_expiry_seconds():
    try: return max(86400, min(90*86400, int(CFG.get('block_ttl_days',30))*86400))
    except Exception: return BLOCK_TTL_SECONDS_DEFAULT

def _remove_firewall_rule(key):
    try: ufw(['delete','deny','from',key])
    except Exception: pass
    try:
        n=safe_network(key)
        if n and have('nft'):
            setname='blocked4' if n.version==4 else 'blocked6'
            run(['nft','delete','element','inet','locsec',setname,'{',key,'}'],20)
    except Exception: pass

def prune_expired_blocks():
    now=time.time(); expired=[]
    with LOCK:
        blocks=load_blocks(); kept={}
        for key,meta in blocks.items():
            if not isinstance(meta,dict):
                # Not a record this version writes (a hand edit or a damaged file):
                # drop it and take its firewall rule down with it.
                log(f'block list: dropped an unreadable entry for {key}','WARN')
                expired.append(key); continue
            try: created=float(meta.get('ts') or now)
            except Exception: created=now
            try: expires=float(meta.get('expires') or (created+block_expiry_seconds()))
            except Exception: expires=created+block_expiry_seconds()
            meta['expires']=expires
            if expires<=now:
                expired.append(key)
            else:
                kept[key]=meta
        if kept!=blocks: atomic_json(BLOCKS,kept)
    for key in expired:
        with LOCK:
            # Re-blocked since the list above was read: keep its rule.
            if key in load_blocks(): continue
            _remove_firewall_rule(key)
        log(f'block expired: {key}','INFO')
    return expired

def load_blocks():
    if not BLOCKS.exists(): return {}
    try:
        x=json.loads(BLOCKS.read_text()); return x if isinstance(x,dict) else {}
    except Exception as e:
        log(f'block database read error: {e}','ERROR'); return {}



def ufw(args,timeout=30):
    if not have('ufw'): return 127,'ufw is not installed'
    return run(['ufw']+args,timeout)


def ensure_nft():
    if not have('nft'): return False
    specs=[
      ['nft','add','table','inet','locsec'],
      ['nft','add','set','inet','locsec','blocked4','{','type','ipv4_addr',';','flags','interval',';','}'],
      ['nft','add','set','inet','locsec','blocked6','{','type','ipv6_addr',';','flags','interval',';','}'],
      ['nft','add','chain','inet','locsec','input','{','type','filter','hook','input','priority','-5',';','policy','accept',';','}'],
    ]
    for c in specs: run(c,30)
    rc,chain=run(['nft','list','chain','inet','locsec','input'],30)
    if rc!=0: return False
    if '@blocked4 drop' not in chain: run(['nft','add','rule','inet','locsec','input','ip','saddr','@blocked4','drop'],30)
    if '@blocked6 drop' not in chain: run(['nft','add','rule','inet','locsec','input','ip6','saddr','@blocked6','drop'],30)
    return True

def firewall_active():
    rc,out=ufw(['status'])
    return rc==0 and re.search(r'^Status:\s+active',out,re.I|re.M) is not None

def ufw_state():
    """'active', 'inactive', or 'unknown' when ufw could not answer.

    Only an explicit "Status: inactive" counts as off. A ufw that timed out or
    failed (its lock held during an upgrade, say) must not switch the fallback
    firewall on over the top of a working UFW and its allow rules."""
    if not have('ufw'): return 'inactive'
    rc,out=ufw(['status'])
    if rc!=0: return 'unknown'
    if re.search(r'^Status:\s+active',out,re.I|re.M): return 'active'
    if re.search(r'^Status:\s+inactive',out,re.I|re.M): return 'inactive'
    return 'unknown'

# Fallback firewall: a default-deny input chain in LocSec's own nftables table,
# present only while UFW is installed but not enabled. It sits next to UFW's
# tables rather than inside them, so turning UFW on never conflicts with it,
# and it is removed on the next check once UFW is active. It stays in place if
# locsecd stops (fail closed); removing the package deletes the table.
_FALLBACK_LOG_PREFIX='[LOCSEC BLOCK] '
_FALLBACK={'on':None,'inactive_reads':0,'script':''}

def _fallback_ssh_ports():
    """TCP ports of SSH sessions in use right now. Dropping new connections must not
    be able to cut off the administrator who is logged in remotely."""
    ports=[]
    if not have('ss'): return ports
    rc,out=run(['ss','-Hntp','state','established'],10)
    if rc!=0: return ports
    for line in out.splitlines():
        if '"sshd' not in line: continue
        parts=line.split()
        if len(parts)<4: continue
        try: p=int(parts[2].rsplit(':',1)[1])
        except Exception: continue
        if 1<=p<=65535 and p not in ports: ports.append(p)
    return ports[:8]

def _fallback_blocked_listeners(extra_tcp=()):
    """Network-facing services the fallback firewall is now cutting off."""
    out=[]
    if not have('ss'): return out
    rc,txt=run(['ss','-Hlntup'],15)
    if rc!=0: return out
    tcp=set(CFG.get('fallback_allow_tcp') or [])|set(extra_tcp); udp=set(CFG.get('fallback_allow_udp') or [])
    for line in txt.splitlines():
        parts=line.split()
        if len(parts)<5: continue
        host,_,port=parts[4].rpartition(':')
        a=safe_ip(host.strip('[]').split('%')[0]) if host.strip('[]') not in ('*','0.0.0.0','::') else None
        if (a is not None and a.is_loopback) or not port.isdigit(): continue
        p=int(port); proto=parts[0]
        if (proto.startswith('tcp') and p in tcp) or (proto.startswith('udp') and (p in udp or p in (68,5353))): continue
        name=(re.search(r'\(\("([^"]+)"',' '.join(parts[6:])) or [None,'unknown'])[1]
        item=f'{proto[:3]} {p} ({name})'
        if item not in out: out.append(item)
    return out[:12]

def _fallback_script(extra_tcp=()):
    t='inet locsec'; c='fallback'
    r=[f'add table {t}',
       f'add chain {t} {c} {{ type filter hook input priority -4 ; policy accept ; }}',
       f'flush chain {t} {c}',
       f'add rule {t} {c} iifname "lo" accept',
       f'add rule {t} {c} ct state established,related accept',
       f'add rule {t} {c} ct state invalid drop',
       f'add rule {t} {c} meta l4proto icmp accept',
       f'add rule {t} {c} meta l4proto ipv6-icmp accept',
       # DHCP and DHCPv6 replies, and the same mDNS allowance UFW's before.rules has.
       f'add rule {t} {c} udp sport 67 udp dport 68 accept',
       f'add rule {t} {c} udp sport 547 udp dport 546 accept',
       f'add rule {t} {c} ip daddr 224.0.0.251 udp dport 5353 accept',
       f'add rule {t} {c} ip6 daddr ff02::fb udp dport 5353 accept']
    for proto,key in (('tcp','fallback_allow_tcp'),('udp','fallback_allow_udp')):
        ports=sorted(set(CFG.get(key) or [])|(set(extra_tcp) if proto=='tcp' else set()))
        if ports: r.append(f'add rule {t} {c} {proto} dport {{ '+', '.join(str(p) for p in ports)+' } accept')
    r.append(f'add rule {t} {c} limit rate 10/second burst 100 packets log prefix "{_FALLBACK_LOG_PREFIX}"')
    r.append(f'add rule {t} {c} drop')
    return '\n'.join(r)+'\n'

def _fallback_present():
    rc,_=run(['nft','list','chain','inet','locsec','fallback'],15)
    return rc==0

def _fallback_remove():
    if not have('nft') or not _fallback_present(): return True
    # One transaction: flush and delete together, so no half-removed chain.
    rc,out=run(['nft','-f','-'],30,input_text='flush chain inet locsec fallback\ndelete chain inet locsec fallback\n')
    if rc!=0: log(f'could not remove the fallback firewall: {out.strip()[-300:]}','ERROR')
    return rc==0

def _fallback_allowed_text(extra_tcp=()):
    tcp=sorted(set(CFG.get('fallback_allow_tcp') or [])|set(extra_tcp)); udp=CFG.get('fallback_allow_udp') or []
    parts=[f'tcp {",".join(map(str,tcp))}' if tcp else '',f'udp {",".join(map(str,udp))}' if udp else '']
    return '; '.join(p for p in parts if p) or 'no ports'

def fallback_firewall_check():
    """Run once a minute: fallback chain on while UFW is off, gone while it is on."""
    st=_FALLBACK
    if not CFG.get('fallback_firewall',True):
        st['inactive_reads']=0
        if st['on'] is not False and _fallback_remove():
            if st['on']: log('fallback firewall removed: it was turned off in the response policy','WARN')
            st['on']=False
        return
    u=ufw_state()
    if u=='unknown': return
    if u=='active':
        st['inactive_reads']=0
        if st['on'] is not False and _fallback_remove():
            if st['on']: log('UFW is active again; the LocSec fallback firewall was removed','INFO')
            st['on']=False
        return
    # Two readings a minute apart, so `ufw reload` or a disable/enable pair
    # does not flip the fallback on for a moment.
    st['inactive_reads']+=1
    if st['inactive_reads']<2 or not have('nft'): return
    ssh=_fallback_ssh_ports()
    script=_fallback_script(ssh)
    if st['on'] and st['script']==script and _fallback_present(): return
    rc,out=run(['nft','-f','-'],30,input_text=script)
    if rc!=0:
        log(f'UFW is not enabled and the fallback firewall could not be installed: {out.strip()[-300:]}','ERROR')
        return
    if not st['on']:
        cut=_fallback_blocked_listeners(ssh)
        cut_txt=('Services on this machine that can no longer be reached from the network: '+'; '.join(cut)+'. ') if cut else 'No service is listening on the network. '
        kept=f' SSH port {", ".join(map(str,ssh))} is kept open because a session is using it.' if ssh else ''
        log(f'UFW is not enabled: LocSec fallback firewall on, unsolicited incoming traffic is dropped (still allowed: {_fallback_allowed_text(ssh)}). {cut_txt}'.strip(),'WARN')
        incident('firewall-fallback','locsecd','', 'high','enabled',
                 'UFW is not enabled, so LocSec installed its own default-deny input firewall. '
                 f'Allowed incoming ports: {_fallback_allowed_text(ssh)}.{kept} {cut_txt}'
                 'To keep a service reachable list its port in fallback_allow_tcp/udp, or enable UFW (sudo ufw enable) to replace this firewall.')
    elif st['script']!=script:
        log(f'fallback firewall updated (still allowed: {_fallback_allowed_text(ssh)})','INFO')
    else:
        log('fallback firewall was missing (ruleset flushed?) and has been put back','WARN')
    st['on']=True; st['script']=script


def _block_meta(reason,source,now,expiry,extra=None):
    meta={'reason':str(reason)[:256],'source':str(source)[:64],'ts':now,'expires':expiry}
    # Only the feed-origin fields, each bounded: what explain_block() reads.
    for k in ('feed','ref','feed_url'):
        if isinstance(extra,dict) and extra.get(k): meta[k]=str(extra[k])[:300]
    return meta

def _block_target(ip):
    """Parse a block target; a /32 or /128 network is the single address, so the
    same host always has one key (unblocking 1.2.3.4 must find 1.2.3.4/32)."""
    t=safe_ip(ip) or safe_network(ip)
    if isinstance(t,(ipaddress.IPv4Network,ipaddress.IPv6Network)) and t.prefixlen==t.max_prefixlen:
        t=t.network_address
    return t

_MAX_AUTO_BLOCKS=20000
_BLOCK_CAP_WARNED=[0.0]

def block_ip(ip,reason='threat',source='locsecd',persist=True,record_incident=True,extra=None,ttl=None):
    target=_block_target(ip)
    if not target: return False,'invalid address/network'
    # Whatever asks, never a range as wide as 0.0.0.0/0: that one rule cuts the
    # machine off from every network, remote access included.
    if isinstance(target,(ipaddress.IPv4Network,ipaddress.IPv6Network)) and target.prefixlen<(8 if target.version==4 else 16):
        return False,f'{target} is too wide to block (at most /8 for IPv4, /16 for IPv6)'
    is_single = isinstance(target, (ipaddress.IPv4Address, ipaddress.IPv6Address))
    if (is_single and allowed_ip(str(target))) or ((not is_single) and allowed_network(str(target))):
        return False,'allowlisted'
    if target.version==6 and not CFG.get('ipv6_auto_block',True): return False,'IPv6 automatic blocking disabled'
    if str(source) not in _MANUAL_BLOCK_SOURCES:
        hit=_infra_conflict(target)
        if hit:
            log(f'automatic block of {target} by {source} refused: it covers {hit}, a DNS server or gateway this machine uses','WARN')
            return False,f'{hit} is a DNS server or gateway this machine uses; it is never blocked automatically'
    key=str(target)
    with LOCK:
        blocks=load_blocks(); meta=blocks.get(key)
        # Automatic blocks are capped: an internet-facing sshd sees thousands of distinct
        # attackers a month, and every block is a firewall rule and a rewrite of this file.
        # Manual blocks are never refused. The cap lifts as old blocks expire.
        if (not meta and str(source) not in _MANUAL_BLOCK_SOURCES
                and sum(1 for v in blocks.values() if not (isinstance(v,dict) and v.get('source') in _MANUAL_BLOCK_SOURCES))>=_MAX_AUTO_BLOCKS):
            if time.time()-_BLOCK_CAP_WARNED[0]>3600:
                _BLOCK_CAP_WARNED[0]=time.time()
                log(f'block list full: {_MAX_AUTO_BLOCKS} automatic blocks are active; {key} was not blocked (old blocks expire after block_ttl_days)','WARN')
            return False,f'the block list already holds {_MAX_AUTO_BLOCKS} automatic blocks'
        if meta:
            exp=float(meta.get('expires') or 0) if isinstance(meta,dict) else 0
            if exp>time.time():
                if record_incident:
                    incident('block',source,key,'high','blocked',reason)
                return False,'already blocked; no duplicate firewall rule or ban was created'
            blocks.pop(key,None); atomic_json(BLOCKS,blocks)
    now=time.time(); expiry=now+(int(ttl) if ttl else block_expiry_seconds())
    # Do not write a persistent block until an enforcement backend confirms it.
    # Otherwise a failed UFW/nft operation would survive a restart and look like
    # a protected address even though the firewall never actually blocked it.
    if firewall_active():
        rc,out=ufw(['insert','1','deny','from',key])
        if rc==0 or re.search(r'(Skipping adding existing rule|already exists)',out,re.I):
            
            if persist:
                with LOCK:
                    blocks=load_blocks(); blocks[key]=_block_meta(reason,source,now,expiry,extra); atomic_json(BLOCKS,blocks)
            if record_incident:
                incident('block',source,key,'high','blocked',reason)
            log(f'blocked address by {source}; expires={int(expiry)}','WARN') if record_incident else None
            return True,out.strip()
    if ensure_nft():
        setname='blocked4' if target.version==4 else 'blocked6'
        rc2,out2=run(['nft','add','element','inet','locsec',setname,'{',key,'}'],30)
        if rc2==0 or 'exists' in out2.lower():
            
            if persist:
                with LOCK:
                    blocks=load_blocks(); blocks[key]=_block_meta(reason,source,now,expiry,extra); atomic_json(BLOCKS,blocks)
            if record_incident:
                incident('block',source,key,'high','blocked',reason)
                log(f'blocked address by {source}; expires={int(expiry)}','WARN')
            return True,out2.strip()
    if record_incident:
        incident('block',source,key,'high','failed',reason)
        log(f'failed to enforce block for {source}','ERROR')
    return False,'no active enforcement backend'

def restore_blocks():
    prune_expired_blocks()
    blocks=load_blocks()
    if not blocks: return
    nft_ready=False; restored=0
    ufw_on=firewall_active()     # once: it is a ufw call, and this loop can be 500 blocks long
    for target in list(blocks):
        if allowed_network(target) or allowed_ip(target): continue
        meta=blocks.get(target) if isinstance(blocks.get(target),dict) else {}
        tgt=safe_ip(target) or safe_network(target)
        if tgt is not None and str(meta.get('source','')) not in _MANUAL_BLOCK_SOURCES and _infra_conflict(tgt):
            # An automatic block from before this check existed, on an address
            # this machine needs (a forged probe "from" its DNS server). Lift it.
            _remove_firewall_rule(target)
            with LOCK:
                cur=load_blocks(); cur.pop(target,None); atomic_json(BLOCKS,cur)
            log(f'lifted automatic block on {target}: it is a DNS server or gateway this machine uses','WARN')
            continue
        if ufw_on:
            rc,out=ufw(['insert','1','deny','from',target])
            if rc==0 or re.search(r'(Skipping adding existing rule|already exists)',out,re.I): restored+=1; continue
        n=safe_network(target)
        if n:
            if not nft_ready: nft_ready=ensure_nft()
            if nft_ready:
                setname='blocked4' if n.version==4 else 'blocked6'
                rc,_=run(['nft','add','element','inet','locsec',setname,'{',str(n),'}'],30)
                if rc==0 or 'exists' in _.lower(): restored+=1
    log(f'restored {restored}/{len(blocks)} active persisted blocks')

def unblock_ip(ip):
    target=_block_target(ip)
    if not target: return False,'invalid address/network'
    key=str(target)
    rc,out=ufw(['delete','deny','from',key]); msgs=[out.strip()] if out.strip() else []
    # Either backend removing the rule (or never having had it) is a successful
    # unblock. Reporting failure just because ufw is not installed, while nft
    # dropped the rule and the persisted entry is gone, made the dashboard say
    # the address was still blocked when it wasn't.
    ufw_ok = rc==0 or 'not found' in out.lower()
    nft_ok = False
    if have('nft'):
        setname='blocked4' if target.version==4 else 'blocked6'
        rc2,out2=run(['nft','delete','element','inet','locsec',setname,'{',key,'}'],30)
        nft_ok = rc2==0 or 'no such' in out2.lower() or 'does not exist' in out2.lower()
        if out2.strip(): msgs.append(out2.strip())
    with LOCK:
        blocks=load_blocks(); blocks.pop(key,None); atomic_json(BLOCKS,blocks)
    detail='; '.join(msgs)
    incident('unblock','manual',key,'low','unblocked',detail)
    log(f'unblocked {key}: {detail}')
    return (ufw_ok or nft_ok),detail

# Which log files this package is entitled to clear from the dashboard, and
# why the others are not.
#
# Only locsecd.log is LocSec's own. auth.log and syslog are the primary
# forensic record of a compromise -- offering a security dashboard a button
# that destroys them is an anti-feature, and anyone who has taken the box
# would use it first. The scan logs belong to rkhunter, ClamAV and AIDE, and
# Every one of them is already rotated by its own package,
# so nothing here grows without bound; the sizes reported alongside make that
# visible instead of asking anyone to take it on trust.
_LOG_CLEARABLE={'locsecd'}
_LOG_ROTATION={
    'locsecd':   'daily, 14 kept, compressed (/etc/logrotate.d/locsecd)',
    'auth':      "rsyslog's own rotation (/etc/logrotate.d/rsyslog)",
    'syslog':    "rsyslog's own rotation (/etc/logrotate.d/rsyslog)",
    'ufw':       "rsyslog's own rotation (/etc/logrotate.d/ufw or rsyslog)",
    'rkhunter':  'the rkhunter package',
    'clamav':    'the clamav-freshclam package',
    'aide':      'the aide package',
}
_LOG_NOT_CLEARABLE_REASON={
    'auth':      'the primary record of who logged in and from where -- the first thing to read after a break-in',
    'syslog':    'the primary system record -- the first thing to read after a break-in',
    'ufw':       'firewall denial history, and rsyslog owns the file',
    'rkhunter':  'owned by the rkhunter package',
    'clamav':    'owned by the clamav-freshclam package',
    'aide':      'owned by the aide package',
}

def _log_rotation(key):
    return _LOG_ROTATION.get(key,'')

def _log_noclear_reason(key):
    return _LOG_NOT_CLEARABLE_REASON.get(key,'it is not a file this package owns')

def _source_paths(key,src):
    paths=list(src['paths'])
    if key=='aide':
        try:
            full=sorted((f for f in REPORTS.glob('aide-full-*.txt') if f.is_file() and not f.is_symlink()),
                        key=lambda f:f.stat().st_mtime,reverse=True)
            if full: paths.insert(0,full[0])
        except OSError: pass
    return paths

def _log_size(src):
    p=next((p for p in src['paths'] if p.exists()),None)
    if p is None: return None,0
    try: return p,p.stat().st_size
    except OSError: return p,0

def clear_log(key):
    key=str(key or '')
    src=LOG_SOURCES.get(key)
    if not src: return {'ok':False,'error':'unknown log source'}
    if key not in _LOG_CLEARABLE:
        why=_log_noclear_reason(key)
        return {'ok':False,'error':f'{LOG_SOURCES[key]["label"]} cannot be cleared from here: {why}. '
                                   f'It is rotated by {_log_rotation(key) or "its own package"}.'}
    p,_=_log_size(src)
    if p is None: return {'ok':False,'error':'that log file does not exist yet'}
    # Confine the target the way report and quarantine paths are confined
    # elsewhere: the only thing this may ever truncate is a file directly
    # inside LocSec's own log directory.
    try:
        resolved=p.resolve()
        resolved.relative_to(LOG.parent.resolve())
    except (OSError,ValueError):
        return {'ok':False,'error':'refusing to clear a path outside LocSec\'s own log directory'}
    try:
        # O_NOFOLLOW, and truncate through the descriptor rather than the
        # path. os.truncate(path) follows symlinks and stats separately from
        # the write, so a symlink left at this path -- or swapped in between
        # the two calls -- would have this daemon truncate whatever it points
        # at, as root. The directory is 0750 root:root so that is not an
        # escalation, but a security tool should not contain a
        # "destroy an arbitrary file" primitive that depends on a directory
        # mode set best-effort at startup.
        #
        # Truncating rather than unlinking is deliberate: locsecd and anything
        # else holding the file open keep their descriptors and carry on
        # writing to the same inode. Deleting it would leave writers appending
        # to an unlinked inode -- the space would not come back until a
        # restart, and the visible log would stop updating.
        # O_NONBLOCK as well: opening a FIFO for writing blocks until a
        # reader appears, which would pin this request thread indefinitely
        # (and, repeated, exhaust the bounded pool). With it, a FIFO fails
        # with ENXIO instead. It has no effect on a regular file.
        fd=os.open(str(p), os.O_WRONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    except OSError as e:
        if getattr(e,'errno',None) in (errno.ELOOP,errno.EMLINK):
            return {'ok':False,'error':f'{p} is a symbolic link; refusing to clear it'}
        if getattr(e,'errno',None)==errno.ENXIO:
            return {'ok':False,'error':f'{p} is a named pipe, not a log file; refusing to clear it'}
        return {'ok':False,'error':f'could not open {p}: {e}'}
    try:
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            return {'ok':False,'error':f'{p} is not a regular file; refusing to clear it'}
        before=st.st_size          # from the same descriptor, so it matches what is truncated
        os.ftruncate(fd,0)
    except OSError as e:
        return {'ok':False,'error':f'could not clear {p}: {e}'}
    finally:
        try: os.close(fd)
        except OSError: pass
    # A security tool destroying its own record says so in the record that
    # replaces it, and in the incident timeline, so the gap is explained.
    log(f'{key} log cleared from the dashboard ({before} bytes discarded)','WARN')
    incident('log-cleared','manual',str(p),'low','success',
             f'{LOG_SOURCES[key]["label"]} cleared from the dashboard; {before} bytes discarded')
    return {'ok':True,'source':key,'path':str(p),'freed':before,
            'output':f'{LOG_SOURCES[key]["label"]} cleared. {before} bytes freed. '
                     f'Rotation is unchanged: {_log_rotation(key)}.'}

def _source_journal(src,n=500):
    """Tail of a log source's journal fallback, or '' if it has none or no entries."""
    if 'jargs' not in src or not have('journalctl'): return ''
    flt=src.get('jfilter')
    # With a substring filter, read further back so n matching lines can be found.
    # At least 2000 lines: the source list probes with n=1, and 20 lines of
    # kernel log rarely include a [UFW line, so UFW read as "(no entries yet)".
    want=max(n*20,2000) if flt else n
    rc,out=run(['journalctl','--no-pager','-q','-o','short-iso','-n',str(min(want,50000))]+list(src['jargs']),20,tail=4000000 if flt else 400000)
    if rc!=0 or not out.strip(): return ''
    lines=out.splitlines()
    # The firewall source has two prefixes: UFW's, and the fallback firewall's
    # while UFW is off, which was filtered out and read as "no entries".
    if flt: lines=[l for l in lines if any(f in l for f in ((flt,) if isinstance(flt,str) else flt))]
    # The exact netfilter layout, so a kernel message that merely quotes the prefix
    # (a crashing program's name) is not shown as a knock.
    if src.get('jregex'): lines=[l for l in lines if re.search(src['jregex'],l)]
    return '\n'.join(lines[-n:])

# ---------------------------------------------------------------------------
# Plain-language log view. Every Logs-page source is turned into rows a person
# with no security background can read: when, a short "what happened", and one
# or two simple sentences. The raw lines are still returned alongside, so
# nothing is hidden. Firewall lines (UFW, or the fallback firewall) also get
# their parts pulled out: who knocked, which door (port), and why it was
# stopped. Nothing here changes any state; it only reads.
# ---------------------------------------------------------------------------
_MON={m:i for i,m in enumerate(('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'),1)}
_ISO_TS=re.compile(r'^(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)(?:[.,](\d+))?(Z|[+-]\d\d:?\d\d)?')
_BSD_TS=re.compile(r'^([A-Z][a-z]{2})\s+(\d{1,2})\s+(\d\d):(\d\d):(\d\d)')
_SYSLOG_REST=re.compile(r'^\s*(\S+)\s+([^\s:\[]+)(?:\[(\d+)\])?:\s?(.*)$')

def _parse_ts(s):
    """(epoch seconds or None, characters consumed) for an ISO or syslog timestamp."""
    m=_ISO_TS.match(s)
    if m:
        try:
            y,mo,d,h,mi,se=(int(x) for x in m.groups()[:6])
            dt=datetime(y,mo,d,h,mi,se,int(((m.group(7) or '0')+'000000')[:6]))
            tz=m.group(8)
            if not tz: return time.mktime(dt.timetuple())+dt.microsecond/1e6, m.end()
            off=0
            if tz!='Z':
                t=tz[1:].replace(':','')
                off=(-1 if tz[0]=='-' else 1)*(int(t[:2])*3600+int(t[2:4])*60)
            return dt.replace(tzinfo=timezone.utc).timestamp()-off, m.end()
        except (ValueError,OverflowError): return None,0
    m=_BSD_TS.match(s)
    if m and m.group(1) in _MON:
        try:
            now=datetime.now()
            def _at(year):
                return time.mktime(datetime(year,_MON[m.group(1)],int(m.group(2)),int(m.group(3)),int(m.group(4)),int(m.group(5))).timetuple())
            ts=_at(now.year)
            if ts>time.time()+86400: ts=_at(now.year-1)   # a December line read in January
            return ts, m.end()
        except (ValueError,OverflowError): return None,0
    return None,0

def _split_syslog(line):
    """(ts, program, message) for a syslog-style or journalctl short-iso line."""
    ts,end=_parse_ts(line)
    if end:
        m=_SYSLOG_REST.match(line[end:])
        if m: return ts,m.group(2),m.group(4)
        return ts,'',line[end:].strip()
    return None,'',line.strip()

def _row(ts,lvl,title,text,raw,**extra):
    r={'ts':ts,'lvl':lvl,'title':str(title)[:200],'text':str(text)[:1200],'raw':str(raw)[:2000]}
    r.update(extra)
    return r

# What each door (port) is normally used for, in everyday words.
_PORT_NAMES={
 20:'FTP file transfer',21:'FTP file transfer',22:'SSH remote login',23:'Telnet (old, unsafe remote login)',
 25:'email sending',53:'DNS (looking up website names)',67:'getting a network address (DHCP)',
 68:'getting a network address (DHCP)',69:'TFTP file transfer',80:'web pages',110:'email (POP3)',
 111:'RPC',123:'clock setting (NTP)',135:'Windows remote control (RPC)',137:'Windows computer names',
 138:'Windows computer names',139:'Windows file sharing',143:'email (IMAP)',161:'device monitoring (SNMP)',
 389:'LDAP directory',443:'secure web pages',445:'Windows file sharing',465:'email sending',514:'system logs',
 546:'getting a network address (DHCPv6)',547:'getting a network address (DHCPv6)',587:'email sending',
 631:'printing',853:'secure DNS',993:'email (IMAP)',995:'email (POP3)',1080:'proxy',1194:'OpenVPN',
 1433:'Microsoft SQL database',1723:'PPTP VPN',1900:'finding devices on the network (UPnP)',2049:'NFS file sharing',
 2375:'Docker remote control',3306:'MySQL database',3389:'Windows Remote Desktop',
 3702:'finding devices on the network (WS-Discovery)',5060:'internet phone calls (SIP)',
 5353:'finding devices on the network (mDNS)',5355:'finding computer names (LLMNR)',5432:'PostgreSQL database',
 5900:'remote screen sharing (VNC)',6379:'Redis database',6667:'IRC chat',6697:'IRC chat (secure)',
 7547:'router remote management',8080:'web pages (spare door)',8443:'secure web pages (spare door)',
 8888:'web pages (spare door)',9200:'Elasticsearch database',11211:'Memcached',17500:'Dropbox on the home network',
 27017:'MongoDB database',51820:'WireGuard VPN'}

def _door(port,proto=''):
    try: p=int(port)
    except (TypeError,ValueError): return ''
    name=_PORT_NAMES.get(p)
    return f'door {p}'+(f' ({name})' if name else '')

class _BlockLookup:
    """Which persisted block (if any) covers an address. Built once per request."""
    def __init__(self):
        self.single={}; self.nets=[]; self.cache={}
        for key,meta in load_blocks().items():
            n=safe_network(key)
            if n is None: continue
            meta=meta if isinstance(meta,dict) else {}
            if n.num_addresses==1: self.single[str(n.network_address)]=(key,meta)
            else: self.nets.append((n,key,meta))
    def match(self,ip):
        if ip in self.cache: return self.cache[ip]
        a=safe_ip(ip); hit=None
        if a is not None:
            hit=self.single.get(str(a))
            if hit is None:
                for n,key,meta in self.nets:
                    if n.version==a.version and a in n: hit=(key,meta); break
        self.cache[ip]=hit
        return hit

def _where(ip):
    a=safe_ip(ip)
    if a is None: return 'unknown'
    if a.is_loopback: return 'this computer'
    # allow_ips is the local-network list (private ranges by default). Not
    # ipaddress.is_private: that also covers documentation and benchmark
    # ranges, which are not anyone's home network.
    if allowed_ip(ip) or a.is_link_local: return 'your own network'
    return 'the internet'

_FW_TAG=re.compile(r'\[(UFW|LOCSEC) ([A-Z ]+?)\]')

def _fw_fields(msg):
    """Pull the parts out of a kernel firewall log line, or None if it is not one."""
    m=_FW_TAG.search(msg)
    if not m: return None
    def f(k):
        x=re.search(r'(?<![A-Z])'+k+r'=(\S*)',msg)
        return x.group(1) if x else ''
    flags=set(re.findall(r'\b(SYN|ACK|RST|FIN|PSH|URG)\b',msg.split('PROTO=',1)[-1]))
    return {'who':m.group(1),'action':m.group(2).strip(),'in':f('IN'),'out':f('OUT'),'src':f('SRC'),'dst':f('DST'),
            'proto':f('PROTO').upper(),'spt':f('SPT'),'dpt':f('DPT'),'flags':flags}

def _fw_explain(msg,ts,raw,blocks):
    """One firewall line in plain words: who knocked, which door, what the wall did and why."""
    x=_fw_fields(msg)
    if x is None: return None
    act=x['action']; src=x['src']; dst=x['dst']; proto=x['proto']
    outgoing=bool(x['out']) and not x['in']
    wall='LocSec\'s spare wall' if x['who']=='LOCSEC' else 'the firewall (UFW)'
    Wall=wall[0].upper()+wall[1:]
    port=x['dpt']; door=_door(port) if port else ''
    ping=proto in ('ICMP','ICMPV6','1','58')
    where=_where(dst if outgoing else src)
    hit=blocks.match(src) if (src and not outgoing) else None
    d=safe_ip(dst)
    broadcast=d is not None and (d.is_multicast or (d.version==4 and str(d).endswith('.255')))
    lvl='info'
    if act=='AUDIT' or act.startswith('AUDIT'):
        verdict='Noted'; title='Written down for the records'
        why=f'{Wall} wrote this down to keep a record. Nothing was stopped.'
    elif 'ALLOW' in act:
        verdict='Let in' if not outgoing else 'Let out'
        title=f'Allowed: {src} {"to" if not outgoing else "from this computer to"} {door or "this computer"}'
        why=f'A rule you (or an installed program) made says this is OK, so {wall} let it through.'
    elif 'LIMIT' in act:
        verdict='Stopped'; lvl='warn'
        title=f'Too many tries from {src} on {door or "a door"}'
        why=(f'{src} knocked on {door or "the same door"} too many times, too fast. '
             f'{Wall} makes fast knockers wait, so this knock was stopped.')
    elif outgoing:
        verdict='Stopped'; lvl='warn'
        title=f'Stopped this computer talking to {dst}'
        why=(f'A program on this computer tried to send something out to {dst} ({where}) through {door or "a door"}. '
             f'A firewall rule says no, so {wall} stopped it.')
    else:
        verdict='Stopped'
        title=f'Stopped a knock from {src or "somewhere"}'+(f' on {door}' if door else '')
        if hit:
            lvl='warn'
            why=(f'{src} is on LocSec\'s block list ({_block_reason_short(hit[1])}), '
                 f'so it is not allowed in at all. {Wall} kept it out.')
        elif ping:
            title=f'Stopped a "ping" from {src or "somewhere"}'
            why=(f'{src} ({_where(src)}) sent a "ping" or another network control message: a little '
                 '"are you there?" note. The wall did not let it in. This is common and harmless.')
        elif broadcast:
            why=('A device on your network called out to everyone at once (a broadcast, like shouting in a room). '
                 'Nothing on this computer is listening for it, so it was ignored. This is normal background chatter.')
        elif proto=='TCP' and x['flags'] and 'SYN' not in x['flags']:
            why=('This was a leftover piece of a conversation that had already finished, not a new "hello". '
                 'The wall threw it away. This is harmless and happens all the time.')
        elif where=='your own network':
            why=(f'Another device in your home or office (a phone, TV, printer or the router) knocked on {door or "a door"}. '
                 'Nothing on this computer opened that door, so the wall said no. Usually harmless.')
        elif where=='this computer':
            why='This came from this same computer. The wall said no because no rule allows it.'
        else:
            why=(f'A computer on the internet ({src}) tried to open {door or "a door"} on your computer. '
                 'You never invited it in, so the wall kept the door shut. Strangers on the internet try doors '
                 'like this all day long, looking for one left open.')
    fields={'verdict':verdict,'from':src,'from_where':_where(src) if src else '','to':dst,
            'door':(f'{port}/{proto.lower()}' if port else ('ping' if ping else proto.lower())),'door_name':_PORT_NAMES.get(int(port),'') if port.isdigit() else ('network "are you there?" check' if ping else ''),
            'direction':'going out' if outgoing else 'coming in','listed':bool(hit)}
    return _row(ts,lvl,title,why,raw,fw=fields)

def _block_reason_short(meta):
    src=str(meta.get('source',''))
    if src=='feed':
        f=_FEED_INFO.get(str(meta.get('feed','')))
        return f'listed by {f["name"]}' if f else 'listed on a threat feed of known-bad computers'
    if src=='auth-monitor': return 'too many wrong passwords'
    if src=='scan-monitor': return 'it was trying every door, a port scan'
    if src in ('manual','incident-action'): return 'you blocked it yourself'
    return str(meta.get('reason') or 'blocked earlier')[:80]

_AUTH_SERVICE={'sudo':'sudo (admin powers)','su':'su (switching user)','sshd':'SSH (remote login)','cron':'a scheduled job',
               'CRON':'a scheduled job','systemd-user':'background services','login':'the text login screen',
               'gdm-password':'the login screen','gdm-autologin':'automatic login','lightdm':'the login screen',
               'sddm':'the login screen','pkexec':'pkexec (admin powers)','polkit-1':'an admin password pop-up',
               'cinnamon-screensaver':'the lock screen','gnome-screensaver':'the lock screen','xscreensaver':'the lock screen'}

def _auth_explain(prog,msg,ts,raw):
    p=prog.split('/')[-1].rstrip(']')
    if 'unlocked login keyring' in msg:
        return _row(ts,'good','Keyring unlocked','Your saved-passwords keyring was unlocked when you logged in.',raw)
    m=re.match(r'Failed (password|publickey|keyboard-interactive\S*) for (invalid user )?',msg)
    if m:
        user,ip=_auth_details(msg); ip=ip or 'an unknown address'
        return _row(ts,'bad','Wrong password',f'Someone at {ip} ({_where(ip)}) tried to log in as "{user}" over SSH and got it wrong.'
                    +(' That name does not even exist here, which is what a guessing robot does.' if m.group(2) else ''),raw)
    if msg.startswith('Invalid user '):
        user,ip=_auth_details(msg); ip=ip or 'an unknown address'
        return _row(ts,'warn','Unknown name tried',f'Someone at {ip} ({_where(ip)}) tried to log in with the name "{user}", which does not exist on this computer. Usually a robot guessing.',raw)
    m=re.match(r'Accepted (password|publickey|keyboard-interactive\S*) for ',msg)
    if m:
        how='a key' if m.group(1)=='publickey' else 'a password'
        user,ip=_auth_details(msg)
        return _row(ts,'good','Logged in',f'"{user}" logged in over SSH from {ip} ({_where(ip)}) using {how}.',raw)
    m=re.search(r'^\s*(\S+) : .*?(\d+) incorrect password attempts?',msg)
    if m:
        return _row(ts,'bad','Wrong admin password',f'"{m.group(1)}" typed the wrong password for sudo (admin powers) {m.group(2)} time(s).',raw)
    if 'NOT in sudoers' in msg or 'user NOT authorized' in msg:
        u=(re.match(r'^\s*(\S+)',msg) or [None,'someone'])[1]
        return _row(ts,'bad','Not allowed to be admin',f'"{u}" tried to use sudo (admin powers) but is not allowed to.',raw)
    m=re.search(r'^\s*(\S+) : .*?USER=(\S+) ; COMMAND=(.*)$',msg)
    if m and p=='sudo':
        return _row(ts,'info','Admin command',f'"{m.group(1)}" used sudo to run this as {m.group(2)}: {m.group(3).strip()[:300]}',raw)
    m=re.search(r'Executing command \[USER=(\S+)\].*?\[COMMAND=(.*?)\]',msg)
    if m:
        u=(re.match(r'^\s*(\S+):',msg) or [None,'Someone'])[1]
        return _row(ts,'info','Admin command',f'{u} used pkexec to run this as {m.group(1)}: {m.group(2)[:300]}',raw)
    m=re.search(r'pam_\w+\(([^:)]+):(\w+)\): (.*)$',msg)
    if m:
        svc=_AUTH_SERVICE.get(m.group(1),m.group(1)); rest=m.group(3)
        u=re.search(r'for user (\S+?)(?:\(uid=\d+\))?(?: by (\S+?)(?:\(uid=\d+\))?)?$',rest)
        who=u.group(1) if u else ''
        if 'session opened' in rest:
            by=u.group(2) if u and u.group(2) else ''
            return _row(ts,'info','Started',f'A session for "{who}" started through {svc}'+(f' (asked for by "{by}")' if by and by!=who else '')+'.',raw)
        if 'session closed' in rest:
            return _row(ts,'info','Finished',f'The session for "{who}" through {svc} ended.',raw)
        if 'authentication failure' in rest:
            uu=re.search(r'\buser=(\S+)',rest); rh=re.search(r'\brhost=(\S+)',rest)
            local=not (rh and rh.group(1)) and m.group(1)!='sshd'
            return _row(ts,'bad','Wrong password',f'Someone typed a wrong password'+(f' for "{uu.group(1)}"' if uu else '')+f' at {svc}'+(' on this computer itself.' if local else '.'),raw,
                        fix=_LOCAL_PW_FIX if local else _LOG_FIXES['Wrong password'])
        if 'unlocked login keyring' in rest:
            return _row(ts,'good','Keyring unlocked','Your saved-passwords keyring was unlocked when you logged in.',raw)
        return _row(ts,'info',f'Login system ({svc})',rest,raw)
    if re.search(r'password check failed for user',msg):
        return _row(ts,'info','Password check said no','The password checker turned down a wrong password. The "Wrong password" row next to it says where it was typed.',raw)
    if 'Error opening rules directory' in msg and 'No such file or directory' in msg:
        return _row(ts,'info','Optional folder not there','The admin-password checker (polkit) looked for an optional rules folder that does not exist on this computer. Normal.',raw)
    if 'Rejected send message' in msg:
        progs=[x.rsplit('/',1)[-1] for x in re.findall(r'comm="([^"]+)"',msg)]
        return _row(ts,'info','Message bus said no',"The system's message bus refused a message"+(f' between {progs[0]} and {progs[1]}' if len(progs)>=2 else '')+'. That is the bus enforcing its rules; with Bluetooth audio (bluetoothd and wireplumber) it is normal.',raw)
    if re.search(r'gkr-pam: (?:unable to locate daemon control file|stashed password)',msg):
        return _row(ts,'info','Keyring getting ready','The saved-passwords keyring is getting ready for your log-in. Normal.',raw)
    m=re.search(r'New session (\S+) of user (\S+?)\.?$',msg)
    if m: return _row(ts,'info','Logged in',f'"{m.group(2)}" logged in (session {m.group(1)}).',raw)
    m=re.search(r'Removed session (\S+?)\.?$',msg)
    if m: return _row(ts,'info','Logged out',f'Session {m.group(1)} ended.',raw)
    m=re.search(r'successfully authenticated as unix-user:(\S+) to gain (\S+) authorization for action (\S+)',msg)
    if m: return _row(ts,'good','Admin password accepted',f'"{m.group(1)}" typed the admin password correctly to allow: {m.group(3)}.',raw)
    if 'Registered Authentication Agent' in msg: return _row(ts,'info','Password pop-up ready','The helper that shows admin password pop-ups started.',raw)
    if 'Unregistered Authentication Agent' in msg: return _row(ts,'info','Password pop-up closed','The helper that shows admin password pop-ups stopped (usually at log out).',raw)
    m=re.search(r'(?:Connection closed|Disconnected from) (?:by )?(?:(?:authenticating|invalid) user (\S+) )?(\S+) port',msg)
    if m: return _row(ts,'info','Left',f'{m.group(2)} ({_where(m.group(2))}) hung up'+(f' while trying the name "{m.group(1)}"' if m.group(1) else '')+'.',raw)
    if re.search(r'(?i)fail|denied|invalid|error',msg):
        return _row(ts,'warn',f'Login system ({p or "unknown"})',msg,raw)
    return _row(ts,'info',f'Login system ({p or "note"})',msg,raw)

_PROG_NAMES={'kernel':'the core of the system (kernel)','systemd':'the system manager','NetworkManager':'the network manager',
             'gnome-shell':'the desktop','cinnamon':'the desktop','dbus-daemon':'the message bus','CRON':'scheduled jobs',
             'cron':'scheduled jobs','rsyslogd':'the log writer','polkitd':'the admin-password checker',
             'wpa_supplicant':'Wi-Fi','avahi-daemon':'device finder (Avahi)','cupsd':'printing','ufw':'the firewall',
             'freshclam':'the virus-list updater','clamd':'the virus scanner','udisksd':'the disk manager',
             'systemd-logind':'the login manager','systemd-resolved':'name lookups (DNS)','packagekitd':'the software updater',
             'locsecd.py':'LocSec','aide':'AIDE','dailyaidecheck':'AIDE daily check'}

def _sys_explain(prog,msg,ts,raw,blocks):
    fw=_fw_explain(msg,ts,raw,blocks)
    if fw: return fw
    who=_PROG_NAMES.get(prog,prog or 'something')
    msg=re.sub(r'^<(?:info|warn|error|debug|trace)>\s+\[[\d.]+\]\s*','',msg)
    m=re.search(r'apparmor="DENIED" operation="([^"]+)".*?profile="([^"]+)"(?:.*?name="([^"]+)")?',msg)
    if m:
        return _row(ts,'warn','Safety guard said no',f'AppArmor (a safety guard) stopped "{m.group(2)}" from doing "{m.group(1)}"'+(f' on {m.group(3)}' if m.group(3) else '')+'. Usually a program asking for more than it is allowed; rarely a problem.',raw)
    if re.match(r'(Started|Starting) ',msg): return _row(ts,'info','Started',f'{who.capitalize()}: {msg}',raw)
    if re.match(r'(Stopped|Stopping|Deactivated) ',msg): return _row(ts,'info','Stopped',f'{who.capitalize()}: {msg}',raw)
    if re.match(r'Finished |Reached target ',msg): return _row(ts,'good','Done',f'{who.capitalize()}: {msg}',raw)
    if re.search(r'(?i)\b(failed|failure|fatal|panic|segfault|oom-kill|out of memory)\b',msg):
        return _row(ts,'bad','Something went wrong',f'{who.capitalize()} reported a problem: {msg}',raw)
    if re.search(r'(?i)\b(error|warning|warn|denied|refused|timed out|timeout)\b',msg):
        return _row(ts,'warn','Heads up',f'{who.capitalize()} said: {msg}',raw)
    return _row(ts,'info',f'Note from {who}',msg,raw)

_LOCSEC_LINE=re.compile(r'^(\S+)\s+(INFO|WARN|WARNING|ERROR|DEBUG)\s+(.*)$')

def _locsec_explain(line,blocks):
    m=_LOCSEC_LINE.match(line)
    if m:
        ts,_=_parse_ts(m.group(1)); level=m.group(2); msg=m.group(3)
    else:
        ts,_,msg=_split_syslog(line); level='INFO'
    raw=line
    base={'INFO':'info','DEBUG':'info','WARN':'warn','WARNING':'warn','ERROR':'bad'}.get(level,'info')
    mm=re.match(r'(denied authentication attempt|successful authentication)(?: user=(\S+))?(?: from=(\S+))?',msg)
    if mm:
        who=f'"{mm.group(2)}"' if mm.group(2) else 'someone'; frm=f' from {mm.group(3)} ({_where(mm.group(3))})' if mm.group(3) else ''
        if mm.group(1).startswith('denied'):
            return _row(ts,'warn','Wrong password',f'A login as {who}{frm} was refused.',raw,**({} if mm.group(3) else {'fix':_LOCAL_PW_FIX}))
        if not mm.group(2) and not mm.group(3):
            return _row(ts,'info','Session opened','A session was opened on this computer: a log in, an admin (sudo) command, or a scheduled job. The Authentication log says which.',raw)
        return _row(ts,'good','Logged in',f'{who.capitalize() if who=="someone" else who} logged in{frm}.',raw)
    if msg.startswith('network-denied') and ':' in msg:
        fw=_fw_explain(msg.split(': ',1)[1] if ': ' in msg else msg,ts,raw,blocks)
        if fw: return fw
    mm=re.match(r'network-denied: (\d+) more',msg)
    if mm: return _row(ts,'info','Lots of knocks',f'The wall stopped {mm.group(1)} more knocks this minute. They were counted, not written down one by one.',raw)
    if msg.startswith('application-connection-failure'):
        body=msg.split(': ',1)[-1]
        if _LOCAL_HW_RX.search(body):
            return _row(ts,'info','Firmware updater note',"The firmware updater (fwupd) could not read one of the computer's own chip settings "
                        '(Intel ME / BootGuard). This is inside the computer, not the internet, and is harmless.',raw,
                        fix='Nothing to do. Newer LocSec versions no longer write these lines.')
        return _row(ts,'info','A program could not connect','A program on this computer tried to reach something and could not. Usually a website or service that was down. '+body[:300],raw,
                    fix='Nothing to do unless something you use stopped working. Then check the internet connection, and look for the same time in the System log.')
    mm=re.match(r'threat feed update: (\d+)/(\d+) source\(s\) reached; (\d+) IPs, (\d+) networks, (\d+) domains; (\d+) newly blocked, (\d+) already blocked',msg)
    if mm:
        a,b,ips,nets,doms,new,old=mm.groups()
        return _row(ts,'good' if a==b else 'warn','Bad-computer lists updated',
                    f'LocSec downloaded the newest lists of known-bad computers from {a} of {b} places: {ips} single addresses, '
                    f'{nets} address groups and {doms} website names. It blocked {new} new ones; {old} were already blocked.',raw)
    if msg.startswith('threat feed update: every source failed'):
        return _row(ts,'warn','Could not get the bad-computer lists','None of the places that publish the lists could be reached (no internet yet?). LocSec kept the old lists and will try again in 15 minutes.',raw)
    mm=re.match(r'feed update failed (\S+): (.*)$',msg)
    if mm: return _row(ts,'warn','One list could not be downloaded',f'{mm.group(1)} could not be reached: {mm.group(2)[:200]}',raw)
    mm=re.match(r'blocked address by (\S+?);?\s*expires=(\d+)',msg)
    if mm:
        until=datetime.fromtimestamp(int(mm.group(2))).strftime('%b %d, %Y')
        why={'auth-monitor':'it got the password wrong too many times','scan-monitor':'it was checking every door (a port scan)',
             'feed':'it is on a list of known-bad computers','manual':'you asked for it'}.get(mm.group(1),f'of {mm.group(1)}')
        return _row(ts,'warn','Blocked a computer',f'LocSec put a computer on the block list because {why}. It stays blocked until {until}. The Firewall & Blocks page shows which one.',raw)
    mm=re.match(r'block expired after (\d+) days: (\S+)',msg)
    if mm: return _row(ts,'info','Block lifted',f'{mm.group(2)} is allowed again: its {mm.group(1)}-day block ran out.',raw)
    mm=re.match(r'unblocked (\S+?):',msg)
    if mm: return _row(ts,'info','Unblocked',f'{mm.group(1)} was taken off the block list.',raw)
    mm=re.match(r'restored (\d+)/(\d+) active persisted blocks',msg)
    if mm: return _row(ts,'good','Blocks put back',f'After starting, LocSec put {mm.group(1)} of its {mm.group(2)} blocks back in the wall.',raw)
    mm=re.match(r'port scan from (\S+): (.*)$',msg)
    if mm: return _row(ts,'bad','Someone checked every door',f'{mm.group(1)} knocked on lots of different doors in a few minutes, looking for one that is open (a port scan). {mm.group(2)[:300]}',raw)
    mm=re.match(r'staggered scan job "(\w+)" completed',msg)
    if mm: return _row(ts,'good','Check finished',f'The {_JOB_LABEL.get(mm.group(1),mm.group(1))} check finished. Its report is on the Reports page.',raw)
    if msg.startswith('heavy scan report written'): return _row(ts,'good','Full scan finished','Every check in the full scan finished. The report is on the Reports page.',raw)
    mm=re.match(r'ClamAV scan completed status=(\S+) scanned=(\d+) infected=(\d+) errors=(\d+)',msg)
    if mm:
        inf=int(mm.group(3))
        return _row(ts,'bad' if inf else 'good','Virus scan finished',
                    f'The virus scan looked at {mm.group(2)} files and found {"no viruses" if not inf else str(inf)+" infected file(s) - see Malware / Quarantine"}.'
                    +(f' {mm.group(4)} file(s) could not be read (normal on a busy computer).' if int(mm.group(4)) else ''),raw)
    mm=re.match(r'(.+?) scan completed rc=(-?\d+)',msg)
    if mm: return _row(ts,'info','Check finished',f'{mm.group(1)} finished (exit code {mm.group(2)}). The result is on the Reports page.',raw)
    mm=re.match(r'package update completed; changed (\d+) packages',msg)
    if mm: return _row(ts,'good','Updates done',f'{mm.group(1)} program(s) were updated.' if mm.group(1)!='0' else 'Looked for updates; nothing needed installing.',raw)
    if re.match(r'(rkhunter definitions update|ClamAV signature update) rc=',msg):
        return _row(ts,'info','Lists refreshed','LocSec fetched the newest virus or rootkit lists.' if msg.endswith('rc=0') else msg,raw)
    if msg.startswith('API/dashboard listening'): return _row(ts,'good','LocSec started','LocSec is running and this dashboard is ready.',raw)
    if msg.startswith('LocSec server shut down cleanly'): return _row(ts,'info','LocSec stopped','LocSec stopped cleanly (a restart or an update does this).',raw)
    mm=re.match(r'deleted report (\S+)',msg)
    if mm: return _row(ts,'info','Report deleted',f'The report {mm.group(1)} was deleted.',raw)
    mm=re.match(r'reports older than (\d+) days removed: (\d+)',msg)
    if mm: return _row(ts,'info','Old reports cleaned up',f'{mm.group(2)} report file(s) older than {mm.group(1)} days were deleted to save disk space.',raw)
    mm=re.match(r'systemctl (\w+) (\S+): rc=(\d+)',msg)
    if mm: return _row(ts,'info' if mm.group(3)=='0' else 'warn','Service '+mm.group(1),f'Someone pressed {mm.group(1)} on {mm.group(2)} in the Services page.',raw)
    if msg.startswith('UFW is not enabled: LocSec fallback firewall on'):
        return _row(ts,'warn','Spare wall switched on','UFW is turned off, so LocSec put up its own spare wall to keep strangers out until UFW is on again.',raw)
    if 'fallback firewall was removed' in msg: return _row(ts,'good','Spare wall taken down','UFW is on again, so LocSec took its spare wall down.',raw)
    mm=re.match(r'incident=(\S+) action=(\w+): (.*)$',msg)
    if mm: return _row(ts,base,'Incident '+mm.group(2),mm.group(3)[:400],raw)
    mm=re.match(r'(response policy|notification settings) changed: (\{.*\})$',msg)
    if mm:
        try:
            import ast
            d=ast.literal_eval(mm.group(2))
            if not isinstance(d,dict): raise ValueError
        except Exception: d=None
        if d is not None:
            names=_POLICY_LABELS if mm.group(1)=='response policy' else _NOTIFY_TITLES
            on=[names.get(k,k) for k,v in d.items() if v is True]; off=[names.get(k,k) for k,v in d.items() if v is False]
            what='Automatic response settings' if mm.group(1)=='response policy' else 'Pop-up notification settings'
            return _row(ts,'info',what+' saved',
                        f'Someone pressed Save on the Incidents page. '+(f'On: {", ".join(on)}. ' if on else '')+(f'Off: {", ".join(off)}.' if off else ''),raw)
    if re.match(r'.* log cleared from the dashboard',msg):
        return _row(ts,'info',"LocSec's log was emptied",'Someone pressed "Clear LocSec\'s log" on the Logs page. '+msg,raw,
                    fix='If you did it, nothing to do. If not, someone else can use your dashboard: log out and change your password with: passwd')
    mm=re.match(r'incident (\S+) deleted$',msg)
    if mm: return _row(ts,'info','Incident deleted','An incident was deleted from the Incidents page.',raw)
    if msg=='all incidents deleted': return _row(ts,'info','All incidents deleted','Every incident was deleted from the Incidents page.',raw)
    mm=re.match(r'threat feed: recorded which list named (\d+)',msg)
    if mm: return _row(ts,'info','Block reasons filled in',f'LocSec noted which bad-computer list named {mm.group(1)} computer(s) it had already blocked, so Firewall & Blocks can say why.',raw)
    if not msg.strip(): return None
    title={'info':'LocSec note','warn':'LocSec warning','bad':'LocSec problem'}[base]
    fix={'warn':'If this keeps coming back, restart LocSec on the Services page. If it still appears, the Troubleshooting page lists the usual causes.',
         'bad':'Restart LocSec on the Services page. If the problem stays, run: sudo journalctl -u locsecd -n 50 and look at the lines around this time.'}.get(base,'')
    return _row(ts,base,title,msg,raw,**({'fix':fix} if fix else {}))

_RKH_GOOD=('[ OK ]','[ Not found ]','[ None found ]','[ Clean ]','[ Not infected ]','[ No update ]','[ Updated ]')

def _rkh_explain(line):
    raw=line; m=re.match(r'^\[\s*(\d\d:\d\d:\d\d)\s*\]\s*(.*)$',line)
    tstr=m.group(1) if m else ''; body=(m.group(2) if m else line).rstrip()
    item=re.sub(r'\s*\[ [^\]]+ \]\s*$','',body).strip()
    if body.startswith('Warning:') or '[ Warning ]' in body:
        return _row(None,'warn','Needs a look',f'rkhunter wants you to look at this: {item.replace("Warning:","").strip()}',raw,tstr=tstr)
    if any(body.endswith(g) for g in _RKH_GOOD):
        return _row(None,'good','Checked, all fine',item,raw,tstr=tstr)
    if body.endswith('[ Skipped ]'): return _row(None,'info','Skipped',item+' (not checked on this computer)',raw,tstr=tstr)
    if body.startswith('Info:'): return _row(None,'info','Note',body[5:].strip(),raw,tstr=tstr)
    if re.search(r'(?i)\berror\b',body): return _row(None,'bad','Problem',body,raw,tstr=tstr)
    return _row(None,'info','Note',body,raw,tstr=tstr)

def _clam_explain(line):
    ts,prog,msg=_split_syslog(line)
    if not prog:
        mm=re.match(r'^(\w{3} \w{3} [ \d]\d \d\d:\d\d:\d\d \d{4}) -> (.*)$',line)   # freshclam.log
        if mm:
            try: ts=time.mktime(time.strptime(mm.group(1),'%a %b %d %H:%M:%S %Y'))
            except ValueError: ts=None
            msg=mm.group(2)
    raw=line; s=msg.strip()
    if not s or set(s)<={'-'}: return None
    mm=re.search(r'(\w+)\.c[lv]d database is up[ -]to[ -]date \(version: (\d+), sigs: (\d+)',s)
    if mm: return _row(ts,'good','Virus list up to date',f'The "{mm.group(1)}" virus list is already the newest one ({int(mm.group(3)):,} kinds of virus it can spot).',raw)
    mm=re.search(r'(\w+)\.c[lv]d updated \(version: (\d+), sigs: (\d+)',s)
    if mm: return _row(ts,'good','Got a newer virus list',f'Downloaded a newer "{mm.group(1)}" virus list ({int(mm.group(3)):,} kinds of virus it can spot).',raw)
    if re.search(r'(?i)database test passed|database updated|database load',s): return _row(ts,'good','Virus list checked','The new virus list was tested and works.',raw)
    if re.search(r'update process started',s): return _row(ts,'info','Checking for a new virus list','The virus-list updater woke up to look for a newer list.',raw)
    if re.search(r'(?i)OUTDATED',s): return _row(ts,'warn','ClamAV is a bit old','ClamAV itself has a newer version. It still works; your normal system updates will bring the new one.',raw)
    if re.search(r'(?i)received signal: wake up',s): return _row(ts,'info','Woke up','The virus-list updater woke up for its regular check.',raw)
    if re.match(r'(?i)warning\b',s):
        return _row(ts,'warn','Heads up',('Could not reach a virus-list server this time; it tries again later. ' if re.search(r"(?i)can't (query|connect|download)",s) else '')+s,raw)
    if re.search(r'(?i)\berror\b|can\'t|failed',s): return _row(ts,'bad','Problem updating the virus list',s,raw)
    if re.search(r'(?i)\bwarning\b',s): return _row(ts,'warn','Heads up',s,raw)
    return _row(ts,'info','Note',s,raw)

# What each AIDE attribute means, in everyday words. Every hash AIDE can record
# means the same thing to a reader: the contents are different.
_AIDE_ATTR={'size':'size','perm':'permissions','uid':'owner','gid':'group','mtime':'last-changed time',
            'lname':'link target','linkcount':'number of links','acl':'access list','xattrs':'extra attributes',
            'selinux':'SELinux label','e2fsattrs':'file flags','caps':'special powers (capabilities)','inode':None,
            'ctime':None,'atime':None,'bcount':None}
_AIDE_HASH=re.compile(r'(?i)^(md5|sha\d*|rmd160|tiger|crc32b?|haval|gost|whirlpool|stribog\d*|sha512_256)$')
_AIDE_FILEHDR=re.compile(r'^(?:File|Directory|Link|FIFO|Socket|Block device|Character device|Door|Port|Entry): (/.*)$')
_AIDE_ATTRLINE=re.compile(r'^\s+([A-Za-z][A-Za-z0-9_]*)\s*:\s*(.*?)\s*\|\s*(.*?)\s*$')
_AIDE_CACHE={}
_AIDE_CACHE_LOCK=threading.Lock()
# Records kept from one AIDE result: every important path, plus this many ordinary ones
# (the Logs page shows 1500 rows). A dist-upgrade changes ~100,000 paths; keeping a
# record for each held hundreds of MB for as long as the result was cached.
_AIDE_KEEP_ORDINARY=1500
_AIDE_KEEP_IMPORTANT=20000

def _pkg_activity():
    """Latest install/upgrade/remove time per package, from dpkg's own log (every route:
    apt, a .deb opened in a software centre, dpkg -i). Returns {package: unix time}."""
    import gzip
    act={}
    files=[Path('/var/log/dpkg.log'),Path('/var/log/dpkg.log.1')]+[Path(f'/var/log/dpkg.log.{i}.gz') for i in range(2,5)]
    rx=re.compile(r'^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) (?:install|upgrade|remove|purge|configure) ([a-z0-9][a-z0-9+.-]*)(?::\S+)? ')
    for f in files:
        try:
            if not f.is_file(): continue
            opener=gzip.open if f.suffix=='.gz' else open
            with opener(f,'rt',errors='replace') as fh:
                for n,line in enumerate(fh):
                    if n>400000: break
                    m=rx.match(line)
                    if not m: continue
                    try: t=time.mktime(time.strptime(m.group(1),'%Y-%m-%d %H:%M:%S'))
                    except ValueError: continue
                    if t>act.get(m.group(2),0): act[m.group(2)]=t
        except (OSError,EOFError): continue
    return act

def _dpkg_owners(paths):
    """{path: [packages]} for the paths an installed package owns, read from dpkg's own
    file lists in one pass (dpkg-query -S re-reads every list for each call, which made
    a few thousand paths take minutes). /usr-merge means dpkg may know a file as /bin/x
    or /usr/bin/x, so both spellings are looked up."""
    want={}
    for p in paths:
        if not p.startswith('/') or '\n' in p: continue
        alts=[p]
        m=re.match(r'^/(bin|sbin|lib|lib32|lib64)(/.*)$',p)
        if m: alts.append('/usr'+p)
        m=re.match(r'^/usr/(bin|sbin|lib|lib32|lib64)(/.*)$',p)
        if m: alts.append(p[4:])
        for x in alts: want.setdefault(x,p)
    owners={}
    if not want: return owners
    try: lists=sorted(Path('/var/lib/dpkg/info').glob('*.list'))
    except OSError: return owners
    for lf in lists:
        pkg=lf.name[:-5].split(':')[0]
        try:
            with open(lf,'r',errors='replace') as f:
                for line in f:
                    orig=want.get(line.rstrip('\n'))
                    if orig is not None:
                        lst=owners.setdefault(orig,[])
                        if pkg not in lst: lst.append(pkg)
        except OSError: continue
    return owners

def _aide_parse(path,limit=200000):
    """Read a full AIDE --check output: verdict, counts, every entry and, where AIDE wrote
    them, the old and new value of each attribute that changed."""
    out={'ts':None,'verdict':None,'counts':{},'entries':[],'details':{}}
    try: out['ts']=Path(path).stat().st_mtime
    except OSError: pass
    section=None; cur=None; detailed=False
    with open(path,'r',errors='replace') as f:
        for n,line in enumerate(f):
            if n>600000: break
            line=line.rstrip('\n'); low=line.strip().lower()
            mm=re.match(r'\s*Start timestamp:\s*(\S+ \S+)\s*([+-]\d{4})?',line)
            if mm:
                t,_=_parse_ts(mm.group(1).replace(' ','T')+(mm.group(2) or ''))
                if t: out['ts']=t
                continue
            if 'found no differences' in low: out['verdict']='same'; continue
            if 'found differences' in low: out['verdict']='changed'; continue
            mm=re.match(r'\s*(Total number of entries|Added entries|Removed entries|Changed entries):\s*(\d+)',line)
            if mm: out['counts'][mm.group(1)]=int(mm.group(2)); continue
            if low in ('added entries:','removed entries:','changed entries:'):
                section=low.split()[0]; detailed=False; continue
            if low.startswith('detailed information about changes'): section=None; detailed=True; continue
            if low.startswith('the attributes of the'): section=None; detailed=False; continue
            if section:
                em=_AIDE_ENTRY.match(line)
                if em and len(out['entries'])<limit: out['entries'].append((section,em.group(1).strip()))
                continue
            if detailed:
                hm=_AIDE_FILEHDR.match(line)
                if hm:
                    cur=hm.group(1).strip()
                    if len(out['details'])<limit: out['details'][cur]={}
                    else: cur=None
                    continue
                am=_AIDE_ATTRLINE.match(line)
                if am and cur is not None and cur in out['details']:
                    out['details'][cur].setdefault(am.group(1).lower(),(am.group(2),am.group(3)))
    return out

def _aide_change_text(d):
    """'contents, size 221 -> 248 bytes, permissions -rw-r--r-- -> -rwsr-xr-x' and whether
    a change is the dangerous kind (gained setuid/setgid or capabilities, changed owner)."""
    parts=[]; danger=[]
    if any(_AIDE_HASH.match(k) for k in d): parts.append('its contents')
    for k,(old,new) in d.items():
        if _AIDE_HASH.match(k): continue
        label=_AIDE_ATTR.get(k,k)
        if label is None: continue
        if k=='size': parts.append(f'size {old} \u2192 {new} bytes')
        elif k in ('perm','uid','gid','lname'): parts.append(f'{label} {old} \u2192 {new}')
        elif k=='mtime': continue
        else: parts.append(label)
        if k=='perm' and re.search(r'[sS]',new[:10]) and not re.search(r'[sS]',old[:10]): danger.append('it can now run with its owner\'s powers (setuid/setgid)')
        if k=='caps' and new.strip() not in ('','-'): danger.append('it was given special powers (capabilities)')
        if k=='uid': danger.append('its owner changed')
    if not parts and 'mtime' in d: parts.append('only its last-changed time')
    return ', '.join(parts),danger

def _when(t):
    try: return datetime.fromtimestamp(t).strftime('%b %d, %Y %H:%M')
    except Exception: return '?'

def aide_analyze(path):
    """Everything the AIDE views need: one record per changed path with what changed, which
    package owns it, whether an install or update since the last snapshot explains it, the
    level and the fix. Cached per file (one at a time), and built by one request at a time."""
    try: st=Path(path).stat(); key=(str(path),st.st_mtime,st.st_size)
    except OSError:
        _AIDE_CACHE.clear(); raise
    with _AIDE_CACHE_LOCK:
        if _AIDE_CACHE.get('key')==key: return _AIDE_CACHE['data']
        _AIDE_CACHE.clear()
        data=_aide_analyze(path)
        _AIDE_CACHE.update({'key':key,'data':data})
        return data

def _aide_analyze(path):
    a=_aide_parse(path)
    try: base=AIDE_DB.stat().st_mtime
    except OSError: base=None
    sens=[p for _,p in a['entries'] if _AIDE_SENSITIVE.search(p)][:_AIDE_KEEP_IMPORTANT]
    owners=_dpkg_owners(sens) if sens else {}
    activity=_pkg_activity() if sens else {}
    since=sorted(((t,p) for p,t in activity.items() if base and t>=base-60),reverse=True)
    recs=[]; ordinary=0; important=0
    for section,p in a['entries']:
        s=bool(_AIDE_SENSITIVE.search(p))
        if s:
            important+=1
            if important>_AIDE_KEEP_IMPORTANT: continue
        else:
            ordinary+=1
            if ordinary>_AIDE_KEEP_ORDINARY: continue
        d=a['details'].get(p,{})
        what,danger=_aide_change_text(d) if section=='changed' else ('',[])
        pkgs=owners.get(p,[])
        hit=[(activity.get(x,0),x) for x in pkgs if base and activity.get(x,0)>=base-60]
        pkg=max(hit)[1] if hit else (pkgs[0] if pkgs else ''); t=activity.get(pkg) if pkg else None
        explained=bool(hit)
        home=p.startswith('/home/') or p.startswith('/root/')
        verb={'added':'is new','removed':'is gone','changed':'was changed'}[section]
        q=shlex.quote(p)
        if not s: lvl='info'
        elif danger: lvl='bad'
        elif explained: lvl='info'
        elif home: lvl='warn' if section=='added' else 'info'
        elif section=='removed' and since and not pkg: lvl='info'
        else: lvl='warn'
        why=''; fix=''
        if s:
            if explained:
                why=f'The package {pkg} was installed or updated on {_when(t)}, after the last snapshot. That explains this.'
                fix='Nothing to fix. When you have read this list, press "Rebuild AIDE baseline" on the Scans page: it takes a new snapshot, so the next check starts from here.'
            elif pkg and section=='removed':
                why=f'It belongs to the package {pkg}, which has not been updated since the last snapshot.'
                fix=f'If you did not delete it, put it back: sudo apt install --reinstall {pkg}'
            elif pkg:
                why=f'It belongs to the package {pkg}, which has not been updated since the last snapshot.'
                fix=(f'Check it: sudo dpkg --verify {pkg}  (no output means the package files are as shipped). '
                     +('Files under /etc are settings: if you edited it yourself, that is the change. ' if p.startswith('/etc/') else '')
                     +f'If it is listed and you did not change it, put the original back: sudo apt install --reinstall {pkg}')
            elif home:
                why='This is a start-up or login file in a home folder.'
                fix=(f'If you or a program you set up changed it, nothing to fix. If not, look inside: cat {q}  '
                     'An unknown line in .bashrc or .profile, or an unknown file in .config/autostart, is how some malware starts itself.')
            elif section=='removed':
                why=('No installed package owns it now. '+(f'{len(since)} package(s) were installed, updated or removed since the last snapshot, so an update most likely took it away.' if since else 'Nothing was installed or updated since the last snapshot.'))
                fix='Nothing to fix if you removed a program or ran updates. Otherwise find out what deleted it before trusting this computer with passwords.'
            else:
                why='No installed package owns this file.'+(f' {len(since)} package(s) changed since the last snapshot; a program\'s setup often writes files like this one.' if since else '')
                fix=(f'If you or a program you installed made it, nothing to fix. If you do not know it, look at it: sudo ls -l {q} ; sudo head -n 20 {q}  '
                     'If it is still a mystery, quarantine it on the Malware / Quarantine page.')
            if danger:
                why=('Warning: '+', and '.join(danger)+'. '+why).strip()
                fix=(f'Find out why: sudo ls -l {q}'+(f' ; sudo dpkg --verify {pkg}' if pkg else '')
                     +('. If no update explains it, reinstall the package: sudo apt install --reinstall '+pkg if pkg else
                       '. A file that suddenly gains these powers and that no package owns should be quarantined.'))
        recs.append({'section':section,'path':p,'sensitive':s,'pkg':pkg,'explained':explained,'what':what,
                     'danger':danger,'lvl':lvl,'verb':verb,'why':why,'fix':fix})
    order={'bad':0,'warn':1,'info':2}
    recs.sort(key=lambda r:(order[r['lvl']],not r['sensitive']))
    sens_recs=[r for r in recs if r['sensitive']]
    return {'ts':a['ts'],'verdict':a['verdict'],'counts':a['counts'],'records':recs,'baseline':base,
            'changed_packages':len(since),'path':str(path),'total':len(a['entries']),
            'n_important':important,'n_ordinary':ordinary,
            'n_bad':sum(1 for r in sens_recs if r['lvl']=='bad'),
            # Important changes past the analysis cap are unexplained as far as anyone knows.
            'n_warn':sum(1 for r in sens_recs if r['lvl']=='warn')+max(0,important-_AIDE_KEEP_IMPORTANT),
            'n_unanalysed':max(0,important-_AIDE_KEEP_IMPORTANT),
            'n_explained':sum(1 for r in sens_recs if r['explained'])}

def _aide_summary_row(a):
    recs=a['records']; ts=a['ts']
    nsens=a['n_important']; nbad=a['n_bad']; nwarn=a['n_warn']; nexpl=a['n_explained']
    base=f' The last snapshot was taken {_when(a["baseline"])}.' if a.get('baseline') else ''
    if a['verdict']=='same' or not recs:
        return _row(ts,'good','Nothing changed','AIDE compared every file with its last snapshot and nothing changed.'+base,'',fix='Nothing to do.')
    if nbad:
        return _row(ts,'bad','Look at this first',f'{nbad} important file(s) gained special powers or changed owner. That is what break-ins do, and updates rarely do it. They are listed first below.'+base,'',
                    fix='Read the first rows below and follow "What to do" on each one before accepting anything.')
    if nwarn:
        return _row(ts,'warn','Some changes are not explained',
                    f'{nsens:,} important file(s) changed. {nexpl:,} are explained by software installed or updated since the last snapshot; '
                    f'{nwarn:,} are not. Those are listed first below.'
                    +(f' {a["n_unanalysed"]:,} of them were too many to check one by one; the full list is in {a["path"]}.' if a.get('n_unanalysed') else '')+base,'',
                    fix='Check each "Heads up" row below and follow its "What to do". When every row is explained, press "Rebuild AIDE baseline" on the Scans page.')
    return _row(ts,'good','Changes are explained',
                f'{nsens:,} important file(s) changed, and software installed or updated since the last snapshot explains all of them. '
                f'The other {a["n_ordinary"]:,} changes are ordinary (caches, logs, your own files).'+base,'',
                fix='Press "Rebuild AIDE baseline" on the Scans page: it takes a new snapshot, so the next check starts from here.')

def _aide_friendly(path,limit=1500):
    """Rows for an AIDE check output: what to do first, the counts, then every changed path
    (most important first) with what changed and how to fix it."""
    try: a=aide_analyze(path)
    except Exception as e:
        return [_row(None,'bad','Could not read the AIDE result',str(e),'')]
    ts=a['ts']; c=a['counts']; rows=[_aide_summary_row(a)]
    t=c.get('Total number of entries')
    if c:
        rows.append(_row(ts,'info','What AIDE counted',(f'It checked {t:,} files and folders: ' if t else '')+
                         f'{c.get("Added entries",0):,} new, {c.get("Removed entries",0):,} gone, {c.get("Changed entries",0):,} changed.',''))
    for r in a['records'][:limit]:
        title=('Important file ' if r['sensitive'] else 'File ')+r['verb']
        text=r['path']+' '+r['verb']+'.'+(f' What changed: {r["what"]}.' if r['what'] else '')+(' '+r['why'] if r['why'] else '')
        extra={'fix':r['fix']} if r['fix'] else {}
        rows.append(_row(ts,r['lvl'],title,text,r['path'],**extra))
    if a['total']>min(limit,len(a['records'])):
        rows.append(_row(ts,'info','More not shown',f'{a["total"]-min(limit,len(a["records"])):,} more changes are in {path}.',''))
    return rows

def friendly_log(key,lines,path=None):
    """Turn raw log lines into plain-language rows, newest first."""
    blocks=_BlockLookup(); rows=[]
    if key=='aide' and path and Path(path).name.startswith('aide-full-'):
        return _aide_friendly(path)
    for line in lines:
        if not line.strip(): continue
        # Log text can carry attacker-chosen content (an SSH user name); keep
        # every regex below working on a bounded string.
        line=line[:4000]
        try:
            if key=='locsecd': r=_locsec_explain(line,blocks)
            elif key=='rkhunter': r=_rkh_explain(line)
            elif key=='clamav': r=_clam_explain(line)
            else:
                ts,prog,msg=_split_syslog(line)
                if key=='auth': r=_auth_explain(prog,msg,ts,line)
                elif key=='ufw': r=_fw_explain(msg,ts,line,blocks) or _row(ts,'info','Firewall note',msg,line)
                elif key=='aide':
                    if re.search(r'(?i)found no differences',msg): r=_row(ts,'good','No changes','AIDE found no changed files.',line)
                    elif re.search(r'(?i)found differences',msg): r=_row(ts,'warn','Some files changed','AIDE found changed files. Run "AIDE only" on the Scans page for the full list.',line)
                    else: r=_sys_explain(prog,msg,ts,line,blocks)
                else: r=_sys_explain(prog,msg,ts,line,blocks)
        except Exception as e:
            r=_row(None,'info','LocSec note' if key=='locsecd' else 'Note',line,line)
        if r: rows.append(r)
    rows=_apply_log_fixes(_collapse_repeats(rows))
    rows.reverse()
    return rows

def _collapse_repeats(rows,window=300):
    """Fold back-to-back rows that say exactly the same thing within a few minutes into one
    row with a count: seven identical "Session opened" rows in one second told nobody anything."""
    out=[]
    for r in rows:
        prev=out[-1] if out else None
        if (prev is not None and prev['lvl']==r['lvl'] and prev['title']==r['title'] and prev['text']==r['text']
                and (r.get('ts') is None or prev.get('ts') is None or abs((r.get('ts') or 0)-(prev.get('last_ts') or prev.get('ts') or 0))<=window)):
            prev['repeat']=int(prev.get('repeat',1))+1
            if r.get('ts'): prev['last_ts']=r['ts']
            continue
        out.append(r)
    return out

# "What to do" for log rows whose explainer did not give one, keyed by the row title.
# Only rows that call for an action get one; ordinary notes stay quiet.
_LOG_FIXES={
 'Wrong password':'If it was you, nothing to do. If not, someone is guessing: LocSec blocks a computer that gets it wrong too often (see Incidents). If you use SSH, log in with a key and set "PasswordAuthentication no" in /etc/ssh/sshd_config.',
 'Unknown name tried':'Nothing to do. This is a robot trying common names; LocSec blocks it after a few tries.',
 'Wrong admin password':'If that was you, nothing to do. If not, someone at this computer knows your user name: lock the screen when you walk away and change your password with: passwd',
 'Not allowed to be admin':'If that user should have admin powers: sudo usermod -aG sudo NAME (then log out and back in). If not, find out who tried.',
 'Safety guard said no':'Usually nothing to do. If a program stopped working at that moment, its AppArmor profile is too tight: tell the program\'s maintainers.',
 'Something went wrong':'Open "Show the original log lines" to see the exact words. If it names a service, run: sudo systemctl status NAME, and restart it on the Services page.',
 'Heads up':'Usually nothing to do. If the same line comes back every few minutes, search the program name and message.',
 'Blocked a computer':'Nothing to do. If it is a computer you trust, unblock it on Firewall & Blocks and add it to allow_ips in /etc/locsecd/locsecd.conf.',
 'Someone checked every door':'Nothing to do: with port-scan blocking on, LocSec blocks the scanner. If it was your own device (a network scanner app), add it to allow_ips in /etc/locsecd/locsecd.conf.',
 'Could not get the bad-computer lists':'Check the internet connection. LocSec tries again by itself every 15 minutes.',
 'One list could not be downloaded':'Check the internet connection. LocSec tries again by itself every 15 minutes; one list missing for a while is fine.',
 'Spare wall switched on':'Turn UFW back on: sudo ufw enable  (first run sudo ufw allow ssh if you log in from another computer). LocSec takes its spare wall down by itself.',
 'Needs a look':'Open the newest rkhunter report on the Reports page: it separates checked-and-fine from needs-review. For a changed file: dpkg -S FILE, then sudo dpkg --verify PACKAGE. If it verifies and you just ran updates, refresh rkhunter\'s record: sudo rkhunter --propupd',
 'Problem updating the virus list':'Check the internet connection, then press "Update virus/rootkit definitions now" on the Scans page, or run: sudo systemctl restart clamav-freshclam',
 'ClamAV is a bit old':'Install system updates (Update system on the Scans page).',
 'Virus scan finished':'Open Malware / Quarantine and press Quarantine on each file it lists.',
 'Some files changed':'Pick "AIDE (latest check)" here after running "AIDE only" on the Scans page: it lists each file with what changed and what to do.',
}

_LOCAL_PW_FIX=('If it was you mistyping, nothing to do. If not, someone has been at your keyboard: lock the screen when you '
               'walk away (Super+L) and change your password with: passwd')

def _apply_log_fixes(rows):
    for r in rows:
        if r.get('fix') or r['lvl'] not in ('warn','bad'): continue
        f=_LOG_FIXES.get(r['title'])
        if f is None and r['title'].startswith('Login system'): f='Usually nothing to do. If it repeats, open "Show the original log lines" for the exact words.'
        if f: r['fix']=f
    return rows

# ---------------------------------------------------------------------------
# Reports: a plain list of what each check found and what to do about it,
# computed when a report is opened so older reports get it too.
# ---------------------------------------------------------------------------
_RKH_FIX_FILE=('An update usually does this. Check: dpkg -S {f} , then sudo dpkg --verify PACKAGE (no output = as shipped). '
               'If it verifies and you just ran updates, refresh rkhunter\'s record: sudo rkhunter --propupd  '
               'If it does not verify, reinstall it: sudo apt install --reinstall PACKAGE')

def _rkh_fix(text):
    m=re.search(r'File:\s*(/\S+)',text) or re.search(r"command '(/[^']+)'",text) or re.search(r'found:\s*(/\S+?):',text)
    f=shlex.quote(m.group(1)) if m else 'FILE'
    t=text.lower()
    if 'properties have changed' in t or 'replaced by a script' in t: return _RKH_FIX_FILE.format(f=f)
    if 'hidden file' in t or 'hidden directory' in t: return f'Look at it: sudo ls -la {f} . If no program you use made it and no package owns it (dpkg -S {f}), quarantine it on the Malware / Quarantine page.'
    if 'root access' in t and 'ssh' in t: return 'Stop root logging in over SSH: set "PermitRootLogin no" in /etc/ssh/sshd_config, then sudo systemctl restart ssh'
    if 'added to the passwd file' in t or 'added to the group file' in t: return 'If you installed a program just before this, it made the account and nothing is wrong: run sudo rkhunter --propupd. If not, check the account: getent passwd NAME'
    if 'shared memory' in t: return 'Usually a desktop program (browsers use large shared memory). If nothing else looks wrong, nothing to do.'
    if 'promisc' in t: return 'A network card is listening to all traffic. Normal while a packet capture runs; otherwise find out which program does it: ip link'
    return 'Read the warning. If an update or a program you installed explains it, run sudo rkhunter --propupd so it is not reported again. If nothing explains it, ask for help before ignoring it.'

def explain_result(r):
    name=str(r.get('name','')); st=str(r.get('status') or ''); out=str(r.get('output',''))
    items=[]
    def add(lvl,title,text,fix=''): items.append({'lvl':lvl,'title':title,'text':text,'fix':fix})
    if st=='not-installed': add('info','Not installed',f'{name} is not installed, so this check did not run.','Install it with "Add" on the Overview page.'); return items
    if st=='skipped': add('info','Not used here',out[:300] or 'This check does not apply to this computer.'); return items
    if st=='busy': add('info','Skipped this time',out[:300] or 'Another check was busy.','Run it again later from the Scans page.'); return items
    if st=='timeout': add('warn','Ran out of time',f'{name} did not finish in the time allowed, so the results are not complete.','Run it again when the computer is not busy, or raise its time limit in /etc/locsecd/locsecd.conf.')
    if st=='not-initialized': add('warn','No snapshot yet','AIDE has no snapshot of your files to compare with.','Press "Rebuild AIDE baseline" on the Scans page once; checks work from then on.'); return items
    if st=='error':
        first=next((l for l in out.splitlines() if l.strip()),'')[:300]
        add('bad','The check could not run',first or f'{name} stopped with an error.',
            'Check the internet connection if it downloads data, then run it again. If it keeps failing, the Troubleshooting page lists the usual causes.')
        return items
    low=name.lower()
    if low=='aide':
        fp=r.get('full_output')
        if fp and Path(fp).is_file():
            try:
                a=aide_analyze(fp); s=_aide_summary_row(a)
                add(s['lvl'],s['title'],s['text'],s.get('fix',''))
                for x in [x for x in a['records'] if x['lvl'] in ('bad','warn')][:25]:
                    add(x['lvl'],('Important file ' if x['sensitive'] else 'File ')+x['verb'],
                        x['path']+' '+x['verb']+'.'+(f' What changed: {x["what"]}.' if x['what'] else '')+(' '+x['why'] if x['why'] else ''),x['fix'])
                n=len([x for x in a['records'] if x['lvl'] in ('bad','warn')])
                if n>25: add('info','More to look at',f'{n-25} more changes need a look. Logs > AIDE (latest check) lists all of them.')
            except Exception as e: add('info','Summary unavailable',f'The full AIDE output could not be read: {e}')
        elif st=='ok': add('good','Nothing changed','AIDE compared every file with its snapshot and nothing changed.')
        else: add('info','Full list not kept','This report is older than the full AIDE output files (kept 7 days).','Run "AIDE only" on the Scans page for a fresh list with what to do.')
        return items
    if low=='lynis':
        m=re.search(r'Hardening index: (\S+)/100',out)
        if m: add('info','Safety score',f'Lynis gave this computer {m.group(1)} out of 100. Higher is safer; desktops usually score 60-75.')
        sec=None
        for line in out.splitlines():
            if line.startswith('Warnings'): sec='w'; continue
            if line.startswith('Suggestions'): sec='s'; continue
            mm=re.match(r'^ - ([A-Z]+-\d+): (.*)$',line)
            if mm and sec=='w': add('warn','Lynis warning',f'{mm.group(2)} ({mm.group(1)})',f'See what it means and how to fix it: sudo lynis show details {mm.group(1)}')
        ns=int(r.get('suggestions') or 0)
        if ns: add('info',f'{ns} ideas to make it safer','These are suggestions, not problems. Lynis is written for servers, so some do not fit a desktop.',
                   'Read them in the full output below. For any one of them: sudo lynis show details TEST-ID')
        if not r.get('warnings') and not ns and not m: add('good','All fine','Lynis found nothing to warn about.')
        return items
    if low.startswith('debsecan') or 'cve' in low:
        known=r.get('known'); fixable=r.get('fixable')
        if fixable: add('warn','Fixes are waiting',f'{fixable} known security problem(s) already have a fix you have not installed yet.','Press "Update system" on the Scans page. (LocSec also installs security updates by itself.)')
        if known and known!=fixable:
            add('info','Known problems with no fix yet',f'{(known or 0)-(fixable or 0)} known problem(s) in installed programs have no fix from Debian yet.','Nothing you can do yet. When Debian ships the fix, LocSec installs it automatically.')
        if known==0: add('good','No known problems','No known security problems in the installed programs.')
        if known is None:
            n=len(re.findall(r'^(?:CVE|TEMP)-\S+',out,re.M))
            if n: add('info','Known problems listed',f'This older report lists {n} known problem(s) without saying which have a fix.','Run the CVE scan again for a list that separates the ones you can fix now.')
        return items
    if low=='rkhunter':
        blocks=[]; sec=None
        for line in out.splitlines():
            if line.startswith('NEEDS REVIEW'): sec='r'; continue
            if line.startswith('INFORMATIONAL'): sec='i'; continue
            if sec=='r':
                if line.startswith('Warning:'): blocks.append([line])
                elif blocks and line.strip(): blocks[-1].append(line.strip())
        for bl in blocks[:30]:
            t=' '.join(bl); add('warn','rkhunter wants a look',t.replace('Warning:','').strip()[:400],_rkh_fix(t))
        m=re.search(r'(\d+) informational',out)
        if m and int(m.group(1)): add('info','Checked and fine',f'{m.group(1)} warning(s) were checked by LocSec and are normal for this computer (listed in the full output).')
        if not blocks: add('good','No rootkit found','rkhunter found nothing that needs a look.')
        return items
    if low.startswith('clamav'):
        inf=[l for l in out.splitlines() if l.rstrip().endswith('FOUND')]
        for l in inf[:30]:
            path,_,sig=l.rpartition(': ')
            add('bad','Virus found',f'{path.strip()} has {sig.replace("FOUND","").strip()} in it.','Open Malware / Quarantine and press Quarantine on this file. It can be put back later if it was a mistake.')
        if not inf and st=='ok': add('good','No viruses','The virus scan found nothing.')
        m=re.search(r'^Errors: (\d+)',out,re.M)
        if m and int(m.group(1)) and st!='warning': add('info','A few files could not be read',f'{m.group(1)} file(s) changed or vanished while being scanned. Normal on a computer in use.')
        if st=='warning': add('warn','Many files could not be read','More files than usual could not be scanned.','Run the scan again; if it repeats, restart clamav-daemon on the Services page.')
        return items
    if low=='apt security candidates':
        pk=re.findall(r'^Inst (\S+) \[',out,re.M)
        if pk: add('warn',f'{len(pk)} update(s) waiting',', '.join(pk[:30])+('...' if len(pk)>30 else ''),'Press "Update system" on the Scans page. LocSec also installs security updates by itself.')
        else: add('good','Up to date','No updates are waiting.')
        if 'apt autoremove' in out: add('info','Leftover packages','Some packages are no longer needed by anything.','To tidy up: sudo apt autoremove')
        return items
    if low=='listening ports':
        pub=[]
        for line in out.splitlines():
            parts=line.split()
            if len(parts)<5 or parts[0] not in ('tcp','udp'): continue
            loc=parts[4]
            if re.match(r'^(127\.|\[::1\]|::1|\[::ffff:127\.)',loc): continue
            if parts[0]=='tcp' and parts[1]!='LISTEN': continue
            prog=(re.search(r'\("([^"]+)"',line) or [None,'unknown program'])[1]
            pub.append(f'{parts[0]} {loc} ({prog})')
        if pub: add('info','Doors open to other computers',f'{len(pub)} door(s) are open to the network: '+'; '.join(pub[:15]),
                    'Your firewall (UFW) still keeps other computers out unless you allowed a door. If you do not use one of these programs, stop it on the Services page.')
        else: add('good','No open doors','Nothing on this computer is reachable from other computers; every listener is private to this machine.')
        return items
    if low=='ufw status':
        if re.search(r'Status:\s*inactive',out): add('warn','The firewall is off','UFW is switched off.','Turn it on: sudo ufw enable  (first run sudo ufw allow ssh if you log in from another computer).')
        elif re.search(r'Status:\s*active',out):
            n=len(re.findall(r'^\[\s*\d+\]',out,re.M))
            add('good','The firewall is on',f'UFW is on with {n} rule(s). Anything not allowed by a rule is kept out.')
        return items
    if isinstance(r.get('changed'),list):
        add('good','Updates installed' if r['changed'] else 'Nothing to install',f'{len(r["changed"])} package(s) were updated.' if r['changed'] else 'Everything was already up to date.')
        return items
    if st in ('ok','info'): add('good','All fine',f'{name} found nothing that needs a look.')
    elif st in ('warning','findings-or-error'):
        first=[l for l in out.splitlines() if l.strip()][:3]
        add('warn','Something to look at',' / '.join(first)[:400] or f'{name} found something.','Read the full output below.')
    return items

def _explain_report(rep):
    try:
        res=rep.get('results') if isinstance(rep,dict) else None
        if isinstance(res,list):
            for r in res:
                if isinstance(r,dict): r['explain']=explain_result(r)
        elif isinstance(rep,dict) and isinstance(rep.get('result'),dict):
            rep['result']['explain']=explain_result(rep['result'])
    except Exception as e: log(f'report explanation failed: {e}','ERROR')
    return rep

# ---------------------------------------------------------------------------
# Incidents: what happened, what LocSec did and what to do, in plain words.
# ---------------------------------------------------------------------------
_INC_NET_KINDS=('login-failure','port-scan','block')

def _incident_ip(rec):
    ind=str(rec.get('indicator','')).strip()
    return ind if ind and _block_target(ind) else ''

_BLOCKS_MEMO={'t':0,'b':{}}
def _is_blocked(ind):
    try:
        t=_block_target(ind)
        if time.time()-_BLOCKS_MEMO['t']>2: _BLOCKS_MEMO.update(t=time.time(),b=load_blocks())
        b=_BLOCKS_MEMO['b']
        return bool(t) and (str(t) in b or ind in b)
    except Exception: return False

def _never_blocked(ip):
    try:
        t=_block_target(ip)
        return allowed_ip(str(t)) if isinstance(t,(ipaddress.IPv4Address,ipaddress.IPv6Address)) else allowed_network(str(t))
    except Exception: return False

def incident_can_fix(rec):
    k=str(rec.get('kind','')); st=str(rec.get('state','new'))
    if st=='resolved': return False
    if k=='virus-found': return bool(rec.get('indicator')) and str(rec.get('action'))!='quarantined'
    if k in _INC_NET_KINDS:
        ip=_incident_ip(rec)
        return bool(ip) and not _is_blocked(ip) and not _never_blocked(ip)
    return False

def _incident_story(rec):
    """(level, what happened, what LocSec did, what to do)"""
    k=str(rec.get('kind','')); ind=str(rec.get('indicator','')); det=str(rec.get('detail',''))
    n=int(rec.get('count',1) or 1); times=f' It happened {n} times.' if n>1 else ''
    ip=_incident_ip(rec); where=f' ({_where(ip.split("/")[0])})' if ip else ''
    blocked=_is_blocked(ip) if ip else False
    if k=='login-failure':
        if ip and _never_blocked(ip) and not blocked:
            return ('warn',f'Someone at {ip}{where} typed a wrong password trying to log in.{times}',
                    'Wrote it down. LocSec never blocks devices on your own network.',
                    'If that was you, press Mark solved. If not, a device in your home is guessing passwords: find it in your router\'s list of connected devices, and change your password with: passwd')
        if ip:
            return ('warn',f'Someone at {ip}{where} typed a wrong password trying to log in.{times}',
                    'LocSec blocked that computer.' if blocked else 'LocSec wrote it down. It blocks a computer that keeps getting it wrong.',
                    'If that was you, nothing to do: press Mark solved.' if blocked else 'If it was not you, press "Fix it" to block that computer. If it was you, press Mark solved.')
        u=re.search(r'\buser=(\S+)',det); svc=re.search(r'pam_\w+\(([^:)]+)',det)
        place=_AUTH_SERVICE.get(svc.group(1),svc.group(1)) if svc else 'a login prompt'
        return ('info',f'Someone typed a wrong password'+(f' for "{u.group(1)}"' if u else '')+f' at {place} on this computer itself (not over the network).{times}',
                'Nothing: there is no other computer to block.',
                'If that was you mistyping, nothing to do: press Mark solved. If it was not you, someone has been at your keyboard: lock the screen when you leave (Super+L) and change your password with: passwd')
    if k=='port-scan':
        return ('warn',f'{ind}{where} knocked on lots of different doors (ports) in a few minutes, looking for one that is open.{times}',
                'LocSec blocked it.' if blocked else ('LocSec wrote it down. It never blocks devices on your own network.' if ip and _never_blocked(ip) else 'LocSec wrote it down but did not block it (port-scan blocking may be off).'),
                'Nothing to do.' if blocked else ('If you know that device (a phone, TV or a network app), press Mark solved. If you do not, find it in your router\'s list of connected devices.' if ip and _never_blocked(ip) else 'If you do not know that device, press "Fix it" to block it. If it is your own, press Mark solved.'))
    if k=='block':
        return ('info',f'LocSec put {ind}{where} on the block list. Reason: {det[:200] or "not recorded"}.',
                f'That computer cannot reach this one while the block lasts.' if str(rec.get('action'))=='blocked' else 'LocSec tried but the block did not work: '+det[:200],
                'Nothing to do. If you trust that computer, unblock it on Firewall & Blocks.' if str(rec.get('action'))=='blocked' else 'Press "Fix it" to try again. If it fails again, check that UFW or nftables is working (Troubleshooting page).')
    if k=='unblock':
        return ('info',f'{ind} was taken off the block list.','Nothing more.','Nothing to do.')
    if k=='virus-found':
        return ('bad',f'The virus scanner found "{det[:120]}" in the file {ind}.',
                'Moved it into quarantine.' if str(rec.get('state'))=='resolved' else 'Nothing yet: the file is still where it was.',
                'Press "Fix it" to move the file into quarantine. It cannot run there, and it can be put back from Malware / Quarantine if this was a mistake.')
    if k=='rootkit-warning':
        return ('warn','rkhunter (the rootkit checker) reported: '+det.split('\n')[0].replace('Warning:','').strip()[:300],
                'Wrote it down. LocSec cannot fix this by itself.',_rkh_fix(det))
    if k=='firewall-fallback':
        return ('warn','UFW (the firewall) was switched off.','LocSec put up its own spare wall, so strangers still cannot get in.',
                'Turn UFW back on: sudo ufw enable  (first run sudo ufw allow ssh if you log in from another computer). LocSec removes its spare wall by itself.')
    if k=='log-cleared':
        return ('info',f'The log {ind} was emptied from the dashboard.','Nothing more.',
                'If you did it, nothing to do. If not, someone else can use your dashboard: log out of the desktop and change your password with: passwd')
    if k=='service-action':
        return ('info',f'The service {ind} was changed from the Services page: {det[:200]}','Nothing more.','Nothing to do if that was you.')
    if k=='tool-add':
        return ('info',f'The tool {ind} was installed from the Overview page.','Nothing more.','Nothing to do.')
    return ('info',f'{k} from {rec.get("source","")}: {ind} {det[:200]}'.strip(),'Wrote it down.','Nothing to do unless you know it was not you.')

def incident_explain(rec,did=None):
    lvl,happened,done,todo=_incident_story(rec)
    st=str(rec.get('state','new'))
    if st=='resolved': todo='Nothing more to do. If it happens again, LocSec opens a new incident.'
    elif st=='contained': todo='Nothing more to do. Press Mark solved when you have read this.'
    return {'level':lvl,'happened':happened,'did':did or done,'todo':todo,'can_fix':incident_can_fix(rec)}


def ufw_summary(rows):
    """Who knocked most and which doors, for the top of the UFW view."""
    srcs={}; doors={}; stopped=allowed=0
    for r in rows:
        f=r.get('fw')
        if not f: continue
        n=int(r.get('repeat',1))
        if f['verdict']=='Stopped': stopped+=n
        elif f['verdict'].startswith('Let'): allowed+=n
        if f['direction']=='coming in' and f['from']:
            s=srcs.setdefault(f['from'],{'ip':f['from'],'count':0,'where':f['from_where'],'doors':set(),'listed':f['listed']})
            s['count']+=n
            if f['door']: s['doors'].add(f['door'])
        if f['door']:
            d=doors.setdefault(f['door'],{'door':f['door'],'name':f['door_name'],'count':0}); d['count']+=n
    need=int(CFG.get('scan_ports',8))
    top=sorted(srcs.values(),key=lambda x:-x['count'])[:10]
    for s in top:
        s['scanner']=len(s['doors'])>=need
        s['doors']=sorted(s['doors'])[:12]
    return {'stopped':stopped,'allowed':allowed,'sources':len(srcs),'top_sources':top,
            'top_doors':sorted(doors.values(),key=lambda x:-x['count'])[:10]}

# Which threat feed an indicator came from, in plain words. Keys are stored in
# the block record ("feed"), so the Firewall page can say who listed it and why.
_FEED_INFO={
 'spamhaus-drop':{'name':'Spamhaus DROP list','home':'https://www.spamhaus.org/blocklists/do-not-route-or-peer/',
    'why':('This whole group of internet addresses has been taken over by spammers or criminals ("hijacked"), '
           'or is rented out to them. Spamhaus says no normal traffic comes from it, so nobody should talk to it.'),
    'trust':('Yes. Spamhaus has run spam and crime blocklists since 1998, and many internet providers and companies '
             'block this exact list. It only lists address groups it has checked by hand.')},
 'feodo':{'name':'abuse.ch Feodo Tracker','home':'https://feodotracker.abuse.ch/',
    'why':('This computer gives orders to a gang of infected computers (a botnet "command server") for banking '
           'viruses such as Emotet, QakBot, Dridex or TrickBot. Infected PCs phone it to ask what to do next. '
           'Blocking it means a virus on this machine could not get its orders.'),
    'trust':('Yes. abuse.ch is a free, long-running security research project whose lists are used by many firewalls. '
             'This is its "recommended" list, which keeps only servers it has confirmed, to avoid mistakes.')},
 'urlhaus':{'name':'abuse.ch URLhaus','home':'https://urlhaus.abuse.ch/',
    'why':('This computer was caught handing out a virus or other harmful program for download. '
           'Blocking it stops anything on this machine from downloading from it.'),
    'trust':('Yes, but these change fast: the address is often a hacked home router or a cheap rented server '
             'that gets cleaned up later. That is why every block lifts by itself after the block time.')},
 'other':{'name':'a threat feed','home':'',
    'why':'This address is on a public list of known-bad computers that LocSec downloads.',
    'trust':'Depends on the list. You added this list yourself in feed_urls; check who publishes it.'},
}

def _feed_kind(url):
    u=str(url).lower()
    if 'spamhaus.org' in u and 'drop' in u: return 'spamhaus-drop'
    if 'feodotracker.abuse.ch' in u: return 'feodo'
    if 'urlhaus.abuse.ch' in u: return 'urlhaus'
    return 'other'

def explain_block(key,meta):
    """One persisted block in plain words: what it covers, why, who said so, whether to trust it."""
    meta=meta if isinstance(meta,dict) else {}
    n=safe_network(key); src=str(meta.get('source','')); reason=str(meta.get('reason',''))
    if n is None: what=f'{key}'; size=0
    elif n.num_addresses==1: what=f'One computer: {n.network_address}'; size=1
    else:
        size=n.num_addresses
        what=(f'A group of {size:,} internet addresses ({n}), from {n.network_address} to {n.broadcast_address}. '
              'Every computer in that range is blocked.')
    addr=str(n.network_address) if (n is not None and n.num_addresses==1) else key
    out={'key':key,'address':addr,'size':size,'what':what,'source':src,'reason':reason,
         'added':meta.get('ts'),'expires':meta.get('expires'),'who':'','who_home':'','ref':'','ref_page':'','why':'','trust':'','seen_at':''}
    if src=='feed':
        fk=str(meta.get('feed',''))
        info=_FEED_INFO.get(fk)
        if info:
            out.update(who=info['name'],who_home=info['home'],why=info['why'],trust=info['trust'])
            ref=str(meta.get('ref',''))
            if fk=='spamhaus-drop' and re.fullmatch(r'SBL\d+',ref):
                out['ref']=ref; out['ref_page']=f'https://check.spamhaus.org/sbl/query/{ref}'
            elif fk=='feodo':
                out['ref_page']=f'https://feodotracker.abuse.ch/browse/host/{addr}/'
            elif fk=='urlhaus':
                out['ref_page']=f'https://urlhaus.abuse.ch/host/{addr}/'
                if ref: out['seen_at']=ref
            if fk=='other' and meta.get('feed_url'): out['who']=urllib.parse.urlparse(str(meta['feed_url'])).hostname or 'a threat feed'
        else:
            out.update(who='a threat feed (list not recorded yet)',
                       why='This address is on one of the public lists of known-bad computers LocSec downloads. '
                           'The next feed update (every 12 hours, or "Update feeds now" on Threat Intelligence) fills in which list and why.',
                       trust='The lists LocSec uses by default are Spamhaus DROP, Feodo Tracker and URLhaus, all widely trusted.')
    elif src=='auth-monitor':
        mm=re.match(r'(\d+) failed',reason)
        out.update(who='LocSec (login watcher)',
                   why=(f'This computer got the password wrong {mm.group(1) if mm else "too many"} times while trying to log in to this machine, '
                        'so LocSec locked it out. That is what a password-guessing robot looks like.'),
                   trust='Yes, unless this was you or someone you know mistyping. Then press Unblock.')
    elif src=='scan-monitor':
        mm=re.search(r'(\d+) different closed ports probed within (\d+) min',reason)
        out.update(who='LocSec (door watcher)',
                   why=(f'This computer knocked on {mm.group(1) if mm else "many"} different doors (ports) in {mm.group(2) if mm else "a few"} minutes, '
                        'looking for one left open. That is called a port scan, and it is how break-ins start.'),
                   trust='Yes. Normal computers do not knock on lots of closed doors.')
    elif src=='manual':
        out.update(who='You',why='You blocked this yourself on this page'+(f' ("{reason}")' if reason and reason!='manual dashboard block' else '')+'.',trust='Your call.')
    elif src=='incident-action':
        out.update(who='You',why='You pressed Fix it on an incident about this address.',trust='Your call.')
    else:
        out.update(who=src or 'unknown',why=reason or 'No reason was recorded.',trust='Unknown. Unblock it if you do not want it.')
    return out

# Programs whose failed logins count towards automatic blocking. Only these accept logins
# from the network; a wrong password typed at this computer has no address to block.
_AUTH_NET_PROGRAMS={'sshd','sshd-session','sshd-auth'}

def _sshd_uids():
    uids={0}
    try:
        import pwd
        for name in ('sshd','_sshd'):
            try: uids.add(pwd.getpwnam(name).pw_uid)
            except KeyError: pass
    except ImportError: pass
    return uids

def _auth_trusted(comm,uid):
    """True when journald says the record came from sshd itself. _COMM and _UID are
    added by journald from the sending process and cannot be set by it, unlike the
    SYSLOG_IDENTIFIER that "logger -t sshd" or any program can choose."""
    try: return str(comm) in _AUTH_NET_PROGRAMS and int(uid) in _sshd_uids()
    except (TypeError,ValueError): return False

def auth_lines():
    """Recent auth/authpriv records as {'line','trusted'}. 'trusted' is True only for records
    journald attributes to sshd; the auth.log fallback cannot tell, so it is trusted as before."""
    window=max(60,min(86400,int(CFG.get('auth_window',900))))
    seen=set(); out=[]; journal_ok=False
    if have('journalctl'):
        # 200 KB tail: on a noisy host the generic cap could cover only seconds of the
        # auth window. --facility needs journalctl >= 245; older ones fall back to the
        # whole journal for the window.
        base=['journalctl','--no-pager','--since',f'{window} seconds ago','-o','json','-n','20000',
              '--output-fields=MESSAGE,SYSLOG_IDENTIFIER,SYSLOG_PID,_COMM,_PID,_UID,_HOSTNAME']
        rc,s=run(base+['--facility=auth','--facility=authpriv'],30,tail=2000000)
        if rc!=0: rc,s=run(base,30,tail=2000000)
        if rc==0:
            journal_ok=True
            for raw in s.splitlines():
                try: e=json.loads(raw)
                except Exception: continue
                msg=e.get('MESSAGE','')
                if not isinstance(msg,str): continue      # binary payloads come as byte arrays
                try: ts=datetime.fromtimestamp(int(e.get('__REALTIME_TIMESTAMP','0'))/1e6).astimezone().isoformat(timespec='seconds')
                except Exception: ts=''
                ident=str(e.get('SYSLOG_IDENTIFIER') or e.get('_COMM') or '')[:64]
                pid=str(e.get('_PID') or e.get('SYSLOG_PID') or '')[:16]
                line=f"{ts} {e.get('_HOSTNAME','')} {ident}{f'[{pid}]' if pid else ''}: {msg[:4000]}"
                if line in seen: continue
                seen.add(line); out.append({'line':line,'msg':msg[:4000],'trusted':_auth_trusted(e.get('_COMM'),e.get('_UID'))})
    # /var/log/auth.log only on a system without a usable journal. While the journal
    # works it is the only source: auth.log is written by rsyslog from whatever any
    # program sends (logger -t sshd), and an empty journal window is normal.
    if not journal_ok and Path('/var/log/auth.log').exists():
        rc,s=run(['tail','-n','2000','/var/log/auth.log'],30,tail=200000)
        if rc==0:
            cutoff=time.time()-window
            for line in s.splitlines():
                if line in seen: continue
                ts,prog,msg=_split_syslog(line)
                if ts is None or ts<cutoff: continue
                seen.add(line)
                out.append({'line':line,'msg':msg,'trusted':prog.split('/')[-1] in _AUTH_NET_PROGRAMS})
    return out

def _load_seen(path, limit=20000):
    # An insertion-ordered dict, used as an ordered set: membership is O(1) and
    # the order is the order things were seen. The previous version kept a plain
    # set and trimmed with sorted(), which evicts the lexicographically smallest
    # hashes -- effectively at random -- so an event already handled could fall
    # out of the window and be reported a second time while newer markers stayed.
    try:
        data=json.loads(path.read_text())
        return dict.fromkeys(data[-limit:]) if isinstance(data,list) else {}
    except Exception:
        return {}

def _remember_seen(path, seen, limit=20000):
    try:
        atomic_json(path,list(seen)[-limit:])
    except Exception:
        pass

# The sshd records that carry a remote address, each matched whole from start to end.
# A user name, a client's disconnect reason or a banner can contain "ADDRESS port N",
# but it can never make one of these match with the attacker's text in the address
# group: the user name is the greedy group, and the line must end exactly where sshd
# ends it. Anything else (Received disconnect, banners, PAM errors) yields no address.
_P=r'(?: \[preauth\])?$'
_SSHD_ADDR=[re.compile(x) for x in (
    r'^Failed \S+ for (?:invalid user )?(?P<user>.*) from (?P<addr>\S+) port \d+ ssh2'+_P,
    r'^Invalid user (?P<user>.*) from (?P<addr>\S+) port \d+'+_P,
    r'^(?:Connection closed by|Disconnected from) (?:invalid |authenticating )?user (?P<user>.*) (?P<addr>\S+) port \d+'+_P,
    r'^Disconnecting (?:invalid |authenticating )?user (?P<user>.*) (?P<addr>\S+) port \d+: Too many authentication failures'+_P,
    r'^maximum authentication attempts exceeded for (?:invalid user )?(?P<user>.*) from (?P<addr>\S+) port \d+ ssh2'+_P,
    r'^Accepted \S+ for (?P<user>.*) from (?P<addr>\S+) port \d+ ssh2(?:: \S+ \S+)?$',
)]
# PAM writes rhost= before user=, and sshd always fills rhost in, so the first one is real.
_PAM_SSHD=re.compile(r'^pam_\w+\(sshd:auth\): authentication failure;.*? rhost=(?P<addr>\S*)(?:\s+user=(?P<user>.*))?$')

def _auth_parse(msg):
    for rx in _SSHD_ADDR:
        m=rx.match(msg)
        if m: return m.group('user'),m.group('addr')
    m=_PAM_SSHD.match(msg)
    if m: return (m.group('user') or ''),m.group('addr')
    return '',''

def _auth_ip(msg):
    """The remote address of an sshd record, or '' when the record is not one of the
    known sshd formats (see _SSHD_ADDR)."""
    _,cand=_auth_parse(msg)
    a=safe_ip(cand.strip('[]')) if cand else None
    return str(a) if a is not None else ''

def _auth_details(line):
    """(user, address) for display and counting."""
    user,_=_auth_parse(line); ip=_auth_ip(line)
    if not user:
        m=re.search(r'\buser=(\S+)',line); user=m.group(1) if m else ''
    return user[:128],ip

def record_auth_events(raw_events):
    # log_auth_each_attempt=false keeps the per-attempt lines out of locsecd.log
    # (they are still in the system journal); detection, counting and automatic
    # blocking are unaffected -- those run off parse_auth() in login_monitor().
    if not CFG.get('log_auth_each_attempt',True): return
    seen=_load_seen(AUTHSEEN); changed=False
    for ev in raw_events:
        line=str(ev.get('line',''))[:2000]
        msg=str(ev.get('msg',line))[:2000]
        if not line: continue
        kind=str(ev.get('kind','auth-failure'))
        marker=hashlib.sha256(f'{kind}|{line}'.encode(errors='replace')).hexdigest()
        if marker in seen: continue
        seen[marker]=None; changed=True
        user,ip=_auth_details(msg)
        if not ev.get('trusted',True): ip=''      # not written by sshd: its "from" is not evidence
        # A user name is chosen by whoever connects; keep it to one token so it
        # cannot add a second "from=" to this line.
        user=re.sub(r'[\s=]+','_',user)
        who=f' user={user}' if user else ''
        src=f' from={ip}' if ip else ''
        if kind=='auth-success':
            log(f'successful authentication{who}{src}','INFO')
        else:
            log(f'denied authentication attempt{who}{src}','WARN')
    if changed: _remember_seen(AUTHSEEN,seen)

def parse_auth():
    """Failed-login counts per remote address (for automatic blocking), successes, and
    raw records. Only records journald attributes to sshd are counted: a local user can
    write "Failed password ... from 8.8.8.8" to the auth log with logger, and must not be
    able to make LocSec block an address of their choosing."""
    fail={}; success=[]; raw=[]
    rx=re.compile(r'(?i)(?:failed|failure|invalid user|authentication failure)')
    okrx=re.compile(r'(?i)(?:accepted|session opened)')
    for rec in auth_lines():
        line=rec['line']; msg=rec['msg']
        if rx.search(msg):
            user,ip=_auth_details(msg)
            if ip and rec['trusted']: fail[ip]=fail.get(ip,0)+1
            raw.append({'kind':'auth-failure','line':line,'msg':msg,'trusted':rec['trusted']})
        if okrx.search(msg):
            user,ip=_auth_details(msg)
            success.append({'user':user,'ip':ip if rec['trusted'] else '','line':line})
            raw.append({'kind':'auth-success','line':line,'msg':msg,'trusted':rec['trusted']})
    return fail,success,raw


def journal_events():
    """Read only newly arrived security-relevant journal records."""
    if not have('journalctl'):
        return []
    since='-2 minutes'; prev=0.0
    try:
        if JOURNALSTATE.exists():
            state=json.loads(JOURNALSTATE.read_text())
            ts=float(state.get('ts',0))
            if ts>0:
                # Never more than 15 minutes back: after a long stop or a clock jump the
                # backlog could take longer to print than the 45 s allowed, and the same,
                # growing backlog was asked for again every minute from then on.
                prev=max(ts,time.time()-900)
                since=datetime.fromtimestamp(max(0,prev-2),timezone.utc).isoformat()
    except Exception:
        pass
    # -o json emits every field of every record (~900 bytes each), so run()'s
    # default 20 KB tail held only ~22 records per 60s poll: on any busy host the
    # rest of the window was discarded before it was ever examined, and the cursor
    # below then advanced past them for good. Ask for only the two fields used here
    # (journalctl always adds the mandatory __REALTIME_TIMESTAMP alongside) and keep
    # a 400 KB tail, the same reasoning as auth_lines(). --output-fields needs
    # systemd >= 236; fall back to the unfiltered form rather than returning nothing.
    cmd=['journalctl','--no-pager','-o','json','--output-fields=MESSAGE,_SYSTEMD_UNIT,_TRANSPORT,_COMM,_UID','--since',since]
    rc,out=run(cmd,45,tail=400000)
    if rc!=0 and rc!=124:
        rc,out=run(['journalctl','--no-pager','-o','json','--since',since],45,tail=400000)
    if rc!=0:
        if rc==124:
            # Too much to read in time: skip ahead rather than retrying the same window.
            atomic_json(JOURNALSTATE,{'ts':time.time()-60})
            log('journal monitor: reading the journal timed out; skipped ahead to the last minute','WARN')
        return []
    events=[]; denials=[]; newest=0.0
    for line in out.splitlines():
        try: e=json.loads(line)
        except Exception: continue
        try: rts=float(e.get('__REALTIME_TIMESTAMP','0'))/1000000.0
        except Exception: rts=0.0
        newest=max(newest,min(rts,time.time()))
        # The window starts 2s before the last record seen, so the tail of the
        # previous poll comes back again. Those records were already handled;
        # counting them twice inflated every failed-login incident near a poll.
        if prev and rts and rts<=prev: continue
        msg=e.get('MESSAGE','')
        if not isinstance(msg,str): continue
        msg=msg[:2000]
        unit=str(e.get('_SYSTEMD_UNIT',''))[:128]
        trusted=_auth_trusted(e.get('_COMM'),e.get('_UID'))
        if _FW_DENY_RX.search(msg):
            # Only the kernel writes real firewall drops. Anything else carrying the
            # prefix was written by a program (logger, a user) and is not a packet.
            if e.get('_TRANSPORT')!='kernel' or not _FW_LINE_RX.match(msg): continue
            # Firewall drops arrive in bursts (a single scan is hundreds), so
            # they are kept apart and capped on their own; mixed into the list
            # below they pushed failed logins out of its 500-record window.
            denials.append({'ts':rts or newest or time.time(),'unit':unit,'message':msg})
        elif re.search(r'(?i)(failed password|authentication failure|invalid user|accepted password|accepted publickey|sudo:|port.?scan|blocked|denied|connection refused|failed to connect|connect failed|connection timed out|connection denied)',msg):
            events.append({'ts':rts or newest or time.time(),'unit':unit,'message':msg,'trusted':trusted})
    if newest:
        atomic_json(JOURNALSTATE,{'ts':newest})
    return denials[-5000:]+events[-500:]

# Kernel log lines for dropped packets: UFW's "[UFW BLOCK]" and the fallback
# firewall's own prefix. Either one is the packet-level record that a port scan
# leaves behind.
_FW_DENY_RX=re.compile(r'\[(?:UFW BLOCK|LOCSEC BLOCK)\]')
# The whole netfilter LOG layout, from the first character. A kernel message that only
# quotes the prefix (a crashing program named "[UFW BLOCK] IN=...": its name is at most
# 15 bytes, then "[pid]: segfault") cannot match.
_FW_LINE_RX=re.compile(r'^\[(?:UFW|LOCSEC) [A-Z ]+\] IN=\S* OUT=\S* (?:MAC=\S* )?SRC=\S+ DST=\S+ ')
_LOCAL_HW_RX=re.compile(r'(?i)\bFuEngine\b|\bfwupd\b|\bMKHI\b|BootGuard')

def _network_event_details(msg):
    src=''; dst=''; proto=''; dpt=''; spt=''
    m=re.search(r'(?i)SRC=([^\s]+)',msg); src=m.group(1) if m else ''
    m=re.search(r'(?i)DST=([^\s]+)',msg); dst=m.group(1) if m else ''
    m=re.search(r'(?i)PROTO=([^\s]+)',msg); proto=m.group(1) if m else ''
    m=re.search(r'(?i)DPT=(\d+)',msg); dpt=m.group(1) if m else ''
    m=re.search(r'(?i)SPT=(\d+)',msg); spt=m.group(1) if m else ''
    return src,dst,proto,spt,dpt

def record_network_events(events):
    if not (CFG.get('log_network_denials',True) or CFG.get('log_app_connection_failures',True)): return
    seen=_load_seen(SECURITYSEEN); changed=False; denied_logged=0; denied_skipped=0
    for e in events:
        msg=str(e.get('message',''))[:2000]
        if not msg: continue
        lower=msg.lower()
        is_ufw=(('ufw block' in lower) or ('locsec block' in lower) or ('kernel:' in lower and '[ufw' in lower) or (' [ufw ' in lower)) and ('dpt=' in lower or 'src=' in lower)
        is_portscan=('port scan' in lower or 'portscan' in lower)
        is_connfail=bool(re.search(r'(?i)(connection refused|connect(?:ion)?(?: to)? .* failed|failed to connect|connect\(\).*failed|connection timed out|connection denied|connect failed)',msg))
        # fwupd talking to the computer's own chips (Intel ME "MKHI", BootGuard) is not a
        # program failing to reach the network; it filled the diary on every boot.
        if is_connfail and _LOCAL_HW_RX.search(msg+' '+str(e.get('unit',''))): is_connfail=False
        if is_ufw and CFG.get('log_network_denials',True): kind='network-denied'
        elif is_portscan and CFG.get('log_network_denials',True): kind='port-probe'
        elif is_connfail and CFG.get('log_app_connection_failures',True): kind='application-connection-failure'
        else: continue
        marker=hashlib.sha256(f'{kind}|{e.get("ts",0)}|{msg}'.encode(errors='replace')).hexdigest()
        if marker in seen: continue
        seen[marker]=None; changed=True
        if kind=='network-denied':
            # One line per dropped packet would put a whole scan in the log.
            if denied_logged>=50: denied_skipped+=1; continue
            denied_logged+=1
        src,dst,proto,spt,dpt=_network_event_details(msg)
        details=[]
        if src: details.append(f'src={src}')
        if dst: details.append(f'dst={dst}')
        if proto: details.append(f'proto={proto}')
        if spt: details.append(f'sport={spt}')
        if dpt: details.append(f'dport={dpt}')
        suffix=(' '+' '.join(details)) if details else ''
        level='WARN' if kind!='application-connection-failure' else 'INFO'
        log(f'{kind}{suffix}: {msg}',level)
    if denied_skipped: log(f'network-denied: {denied_skipped} more dropped packets this minute were not logged one by one','WARN')
    if changed: _remember_seen(SECURITYSEEN,seen)

def monitor_journal():
    events=journal_events()
    record_network_events(events)
    try: detect_port_scans(events)
    except Exception as e: log(f'port-scan detection: {e}','ERROR')
    for e in events:
        msg=e['message']
        failed=bool(re.search(r'(?i)(failed password|authentication failure|invalid user)',msg))
        if not failed: continue
        # Every address in the line used to become an incident, including one typed
        # into the user name. Only the sshd record's own remote address counts, and
        # only when journald attributes the record to sshd.
        ip=_auth_ip(msg) if e.get('trusted') else ''
        incident('login-failure','journal',ip,'medium','denied',msg)
    return len(events)


# Port-scan detection (replaces PortSentry). PortSentry opened decoy ports and
# reacted to connections on them; this reads the firewall's own record of
# dropped packets instead, so nothing new listens on the network. A source that
# sends new-connection packets to scan_ports different closed ports within
# scan_window seconds is blocked like any other automatic block: allowlisted
# (LAN) addresses and this machine's DNS servers and gateways are only
# recorded, never blocked.
_SCAN_TRACK={}    # source -> {"TCP/22": last seen}
_SCAN_FLAGGED={}  # source -> when it was last acted on
_SCAN_MAX_SOURCES=4096
_SCAN_MAX_PORTS=256
_SCAN_BLOCKS=[]   # when each automatic scan block was made, for the hourly cap

def _established_peers():
    """Remote addresses this machine currently has an established TCP connection with."""
    peers=set()
    if not have('ss'): return peers
    rc,out=run(['ss','-Hnt','state','established'],10)
    if rc!=0: return peers
    for line in out.splitlines():
        parts=line.split()
        if len(parts)<4: continue
        a=safe_ip(parts[3].rsplit(':',1)[0].strip('[]').split('%')[0])
        if a is not None and a.version==6 and a.ipv4_mapped: a=a.ipv4_mapped
        if a is not None: peers.add(str(a))
    return peers

def detect_port_scans(events):
    if not CFG.get('scan_detect',True): return
    now=time.time(); window=int(CFG['scan_window']); need=int(CFG['scan_ports'])
    for e in events:
        msg=str(e.get('message',''))
        if not _FW_DENY_RX.search(msg): continue
        # Inbound only: UFW also logs blocked outgoing packets (OUT=<iface>).
        if not re.search(r'\bIN=\S',msg) or re.search(r'\bOUT=\S',msg): continue
        src,dst,proto,_,dpt=_network_event_details(msg)
        proto=proto.upper()
        if not dpt or proto not in ('TCP','UDP'): continue
        # TCP: count connection attempts only. A late ACK/RST from a server this
        # machine talked to earlier is not a probe.
        if proto=='TCP' and (not re.search(r'\bSYN\b',msg) or re.search(r'\bACK\b',msg)): continue
        a=safe_ip(src); d=safe_ip(dst)
        if a is None or a.is_loopback or a.is_multicast or a.is_unspecified: continue
        if d is not None and (d.is_multicast or str(d)=='255.255.255.255'): continue
        key=str(a); ports=_SCAN_TRACK.get(key)
        if ports is None:
            if len(_SCAN_TRACK)>=_SCAN_MAX_SOURCES:
                # Evict the source seen longest ago rather than ignoring newcomers,
                # so a flood of forged single-packet sources cannot blind the detector.
                _SCAN_TRACK.pop(min(_SCAN_TRACK,key=lambda k:max(_SCAN_TRACK[k].values(),default=0)),None)
            ports=_SCAN_TRACK[key]={}
        pk=f'{proto}/{dpt}'
        if pk in ports or len(ports)<_SCAN_MAX_PORTS:
            try: ports[pk]=float(e.get('ts') or now)
            except Exception: ports[pk]=now
    cutoff=now-window
    for k in [k for k,t in _SCAN_FLAGGED.items() if now-t>=3600]: _SCAN_FLAGGED.pop(k,None)
    for key in list(_SCAN_TRACK):
        ports={p:t for p,t in _SCAN_TRACK[key].items() if t>=cutoff}
        if not ports: _SCAN_TRACK.pop(key,None); continue
        _SCAN_TRACK[key]=ports
        if len(ports)<need or key in _SCAN_FLAGGED: continue
        _SCAN_FLAGGED[key]=now
        a=safe_ip(key)
        sample=', '.join(sorted(ports,key=ports.get)[:20])+(', ...' if len(ports)>20 else '')
        detail=f'{len(ports)} different closed ports probed within {max(1,window//60)} min: {sample}'
        lan=allowed_ip(key) or (a is not None and a.is_link_local)
        skip=''
        _SCAN_BLOCKS[:]=[t for t in _SCAN_BLOCKS if now-t<3600]
        if lan: skip='allowlisted or local-network address'
        elif key in _established_peers(): skip='this machine has an open connection with that address, so the probe may be forged'
        elif len(_SCAN_BLOCKS)>=int(CFG['scan_block_max_per_hour']): skip=f'already {len(_SCAN_BLOCKS)} scan blocks this hour (a forged scan could otherwise lock out many addresses)'
        elif not (CFG.get('auto_block') and CFG.get('response_scan_block',True)): skip='automatic port-scan blocking is off'
        if not skip:
            ok,why=block_ip(key,'port scan: '+detail,'scan-monitor',ttl=int(CFG['scan_block_hours'])*3600)
            if ok:
                _SCAN_BLOCKS.append(now)
                log(f'port scan from {key}: {detail}; blocked for {int(CFG["scan_block_hours"])} h','WARN'); continue
            if why.startswith('already blocked'): continue
            skip=why
        detail+=f' (not blocked: {skip})'
        incident('port-scan','scan-monitor',key,'medium' if lan else 'high','detected',detail)
        log(f'port scan from {key}: {detail}','WARN')

def network_connections():
    if not have('ss'): return []
    rc,out=run(['ss','-Hntup'],30)
    if rc!=0: return []
    rows=[]
    for line in out.splitlines()[:1000]:
        parts=line.split()
        if len(parts)>=5:
            rows.append({'proto':parts[0], 'state':parts[1], 'local':parts[4] if len(parts)>4 else '', 'peer':parts[5] if len(parts)>5 else ''})
    return rows

def login_monitor():
    fails,success,raw=parse_auth(); record_auth_events(raw)
    for ip,n in fails.items():
        if n>=int(CFG['auth_threshold']) and CFG.get('auto_block') and CFG.get('response_auth_block',True) and not allowed_ip(ip):
            block_ip(ip,f'{n} failed authentication events','auth-monitor')
    return {'failed':fails,'successful':success[:100]}

def feed_update():
    prune_expired_blocks()
    urls=CFG.get('feed_urls',[]); hits=0; domains=set(); networks=set(); errors=[]
    # A URL feed (URLhaus and friends) carries hundreds of thousands of entries.
    # Without a ceiling the sets, the JSON on disk and every later read of it grow
    # with whatever the feed publishes that day; the daemon runs under MemoryMax=2G.
    max_ind=200000; capped=False
    # Where each address came from (which list, plus the list's own reference:
    # a Spamhaus SBL number, or the URLhaus download address it was seen
    # serving). Only used to explain blocks; first list to name it wins.
    origin={}
    for url in urls:
        fkind=_feed_kind(url)
        try:
            if urllib.parse.urlparse(str(url)).scheme!='https':
                raise ValueError('feed URL must use HTTPS')
            req=urllib.request.Request(str(url),headers={'User-Agent':f'locsecd/{VERSION}'})
            with _FEED_OPENER.open(req,timeout=30) as r:
                # A total deadline, not just a per-read one: a server dripping a
                # byte every few seconds would otherwise hold the job lock for hours.
                buf=bytearray(); deadline=time.time()+120
                while len(buf)<=MAX_FEED_BYTES:
                    if time.time()>deadline: raise TimeoutError('feed download took longer than 120 seconds')
                    chunk=r.read(65536)
                    if not chunk: break
                    buf+=chunk
                data=bytes(buf)
            if len(data)>MAX_FEED_BYTES: raise ValueError('feed exceeds size limit')
            text=data.decode('utf-8','replace')
            for line in text.splitlines():
                line=line.strip()
                if not line or line.startswith('#'): continue
                # Handle CIDRs (e.g. Spamhaus DROP), single IPs, and URLs/domains.
                for token in re.findall(r'(?<![\w:.])(?:\d{1,3}\.){3}\d{1,3}(?:/\d{1,2})?(?![\w.])',line):
                    n=safe_network(token)
                    if n and n.version==4 and len(networks)<max_ind:
                        networks.add(str(n))
                        if str(n) not in origin:
                            ref=''
                            if fkind=='spamhaus-drop':
                                sm=re.search(r';\s*(SBL\d+)',line); ref=sm.group(1) if sm else ''
                            elif fkind=='urlhaus' and '://' in line:
                                ref=line.split()[0][:300]
                            origin[str(n)]=(fkind,ref,str(url)[:300])
                for token in re.findall(r'https?://[^\s]+',line):
                    try:
                        host=urllib.parse.urlparse(token.rstrip('.,;')).hostname
                        if host and re.fullmatch(r'[A-Za-z0-9.-]{1,253}',host) and len(domains)<max_ind: domains.add(host.lower().rstrip('.'))
                    except Exception: pass
                plain=line.split()[0] if line.split() else ''
                if re.fullmatch(r'[A-Za-z0-9.-]{1,253}',plain) and '.' in plain and len(domains)<max_ind: domains.add(plain.lower().rstrip('.'))
                if len(domains)>=max_ind or len(networks)>=max_ind:
                    capped=True; break
            hits+=1
        except Exception as e:
            errors.append(f'{url}: {e}'); log(f'feed update failed {url}: {e}','ERROR')
    # One pass, one ipaddress object per entry: the previous two comprehensions
    # parsed every indicator twice more just to split hosts from networks.
    single=[]; nets=[]
    for x in networks:
        nw=safe_network(x)
        if not nw: continue
        (single if nw.prefixlen==32 else nets).append(str(nw))
    single.sort(); nets.sort()
    if capped:
        errors.append(f'indicator list truncated at {max_ind} entries per category; raise nothing and it stays bounded, the newest feed contents are kept')
    if urls and not hits:
        # Every source failed (no network or DNS yet, typically right after boot).
        # Writing the empty result here used to replace the whole indicator
        # database with nothing, so reputation checks matched nothing until the
        # next successful run 12 hours later. Keep the last good copy, and record
        # the failed attempt beside it.
        try: prev=json.loads(FEEDS.read_text())
        except Exception: prev={}
        if not isinstance(prev,dict): prev={}
        prev.update({'interval_seconds':int(CFG.get('feed_interval',900)),'sources':urls,'errors':errors,
                     'last_attempt':time.time(),'last_attempt_ok':False})
        for k in ('domains','ips','networks'):
            if not isinstance(prev.get(k),list): prev[k]=[]
        atomic_json(FEEDS,prev)
        log(f'threat feed update: every source failed; kept the previous indicators '
            f'({len(prev["ips"])} IPs, {len(prev["networks"])} networks, {len(prev["domains"])} domains)','WARN')
        return {'sources_ok':0,'domains':len(prev['domains']),'ips':len(prev['ips']),'networks':len(prev['networks']),
                'blocked':0,'already_blocked':0,'errors':errors,'kept_previous':True}
    now=time.time()
    data={'updated':now,'last_attempt':now,'last_attempt_ok':True,'interval_seconds':int(CFG.get('feed_interval',900)),'sources':urls,
          'domains':sorted(domains),'ips':single,'networks':nets,'errors':errors}
    atomic_json(FEEDS,data)
    blocked=0; skipped_already_blocked=0
    if CFG.get('feed_auto_block') and CFG.get('auto_block') and CFG.get('response_feed_block',True):
        limit=max(0,min(2000,int(CFG.get('feed_auto_block_limit',500))))
        indicators=data['ips']+data['networks']
        max_prefix=max(0,min(32,int(CFG.get('max_auto_block_prefix',8))))
        # Skip indicators already persisted from a prior cycle: re-running ufw/nft
        # for the same ~500 already-blocked entries every feed_interval was costing
        # minutes of held JOB_LOCK for no effect (feed order is stable, so it's
        # usually the exact same set every time).
        already=set(load_blocks().keys())
        for target in indicators[:limit]:
            n=safe_network(target)
            if n and n.prefixlen < max_prefix: continue
            if str(n or target) in already or target in already:
                skipped_already_blocked+=1; continue
            fk,ref,furl=origin.get(target,('other','',''))
            label=_FEED_INFO.get(fk,_FEED_INFO['other'])['name']
            if block_ip(target,f'threat-intelligence feed: {label}'+(f' ({ref})' if ref and fk=='spamhaus-drop' else ''),'feed',
                        record_incident=False,extra={'feed':fk,'ref':ref,'feed_url':furl})[0]: blocked+=1
    # Feed blocks made before 4.0.11-65 (or by an earlier run) recorded only
    # "threat-intelligence feed". Fill in which list named them and why, so the
    # Firewall page can explain every one. Metadata only: expiry is untouched.
    try:
        with LOCK:
            cur=load_blocks(); changed=0
            for key,meta in cur.items():
                if not isinstance(meta,dict) or meta.get('source')!='feed': continue
                o=origin.get(key)
                if not o: continue
                fk,ref,furl=o
                if meta.get('feed')!=fk or (ref and meta.get('ref')!=ref):
                    meta['feed']=fk; meta['ref']=ref; meta['feed_url']=furl
                    label=_FEED_INFO.get(fk,_FEED_INFO['other'])['name']
                    meta['reason']=f'threat-intelligence feed: {label}'+(f' ({ref})' if ref and fk=='spamhaus-drop' else '')
                    changed+=1
            if changed: atomic_json(BLOCKS,cur)
        if changed: log(f'threat feed: recorded which list named {changed} existing feed block(s)')
    except Exception as e: log(f'threat feed: could not annotate existing blocks: {e}','ERROR')
    # skipped_already_blocked used to be counted and then dropped, so a feed
    # run that blocked nothing reported blocked=0 with no way to tell whether
    # the feed was empty, everything was filtered out, or -- the usual case --
    # it had all been blocked on a previous cycle already.
    # A successful run used to log nothing, so the log showed only failures and
    # an old failure read as the current state.
    log(f'threat feed update: {hits}/{len(urls)} source(s) reached; {len(data["ips"])} IPs, {len(data["networks"])} networks, '
        f'{len(domains)} domains; {blocked} newly blocked, {skipped_already_blocked} already blocked'
        +(f'; {len(errors)} error(s)' if errors else ''),'INFO' if not errors else 'WARN')
    return {'sources_ok':hits,'domains':len(domains),'ips':len(data['ips']),'networks':len(data['networks']),
            'blocked':blocked,'already_blocked':skipped_already_blocked,'errors':errors}

# A false-positive ClamAV hit moving a live system binary out from under a
# running system is worse than the malware it's meant to catch. Require an
# explicit override to quarantine anything under these trees.
_SYSTEM_PATHS=('/bin','/sbin','/usr/bin','/usr/sbin','/usr/lib','/usr/lib64','/lib','/lib64','/etc','/boot')

QUAR_HELPER='/usr/lib/locsecd/locsec-quarantine'
_QUAR_ID_RE=re.compile(r'^[0-9a-f]{16}$')
QUAR_LOCK=threading.Lock()

def _quarantine_helper(args,timeout=600):
    """Run the privileged quarantine helper in a sibling transient unit (the daemon itself
    is sandboxed read-only for /home and has no CAP_DAC_OVERRIDE/CAP_CHOWN) and return its
    JSON result."""
    h=Path(QUAR_HELPER)
    if not h.is_file() or h.is_symlink(): return {'ok':False,'error':'quarantine helper is missing; reinstall locsecd'}
    with QUAR_LOCK:
        rc,out=_run_transient([str(h)]+[str(a) for a in args],timeout,prefix='locsecd-quarantine')
    try: res=json.loads(out.strip().splitlines()[-1]) if out.strip() else None
    except Exception: res=None
    if not isinstance(res,dict): return {'ok':False,'rc':rc,'error':'quarantine helper returned no valid result','output':str(out)[-2000:]}
    if rc!=0 and res.get('ok') is True: res['ok']=False
    return res

def _incident_mark(ident,state,note):
    try:
        with LOCK:
            _inc_load(); rec=_inc_find(str(ident)[:64])
            if not rec: return
            rec['state']=state; rec['updated']=time.time(); rec['note']=str(note)[:1000]; _inc_store(rec)
        _action_log(rec['id'],state,str(note)[:200],str(note)[:1000])
    except Exception as e: log(f'incident update after quarantine failed: {e}','ERROR')

def quarantine_file(path,force=False,anyway=False,signature='',incident_id=''):
    """Move a file into the quarantine vault with its original location recorded so it can
    be restored. Without `signature` the file is scanned first and only quarantined if
    ClamAV flags it; `anyway` quarantines a file ClamAV does not flag."""
    raw=Path(path)
    if not raw.is_absolute(): return {'ok':False,'error':'path must be absolute'}
    # Resolve the directory only: a symlink is never followed, so quarantining one can
    # never move or delete the file it points at.
    src=raw.parent.resolve()/raw.name
    if src.is_symlink(): return {'ok':False,'error':f'{src} is a symbolic link; quarantine the file it points to instead'}
    if not src.is_file(): return {'ok':False,'error':'file not found'}
    if str(src).startswith(str(QUAR.resolve())+os.sep): return {'ok':False,'error':'file already quarantined'}
    if not force and any(str(src)==p or str(src).startswith(p+os.sep) for p in _SYSTEM_PATHS):
        return {'ok':False,'error':f'{src} is under a system directory; quarantining it could break the system. Pass force=true to override.'}
    sig=str(signature or '').strip()[:300]
    if not sig:
        if not have('clamscan'): return {'ok':False,'error':'clamscan not installed'}
        rc,out=run(['clamscan','--infected','--no-summary',str(src)],300)
        log(f'quarantine scan {src}: rc={rc}')
        if rc==1:
            for line in str(out).splitlines():
                if line.rstrip().endswith('FOUND'):
                    sig=line.rstrip()[:-5].rpartition(': ')[2].strip(); break
            sig=sig or 'detected'
        elif rc==0:
            if not anyway:
                return {'ok':False,'clean':True,'rc':0,'error':'ClamAV found nothing in this file, so it was not quarantined. Tick "Quarantine even if clean" to quarantine it anyway.'}
            sig='Manually quarantined (no detection)'
        else:
            return {'ok':False,'rc':rc,'error':'ClamAV could not scan this file','output':out}
    res=_quarantine_helper(['quarantine',str(src),sig])
    log(f'quarantine {src}: ok={res.get("ok")} {res.get("error","")}','WARN' if res.get('ok') else 'ERROR')
    if res.get('ok') and incident_id:
        _incident_mark(incident_id,'resolved',f'File quarantined ({sig}); it can be restored or deleted from Malware / Quarantine.')
    return res

def list_quarantine():
    items=[]
    try: entries=sorted(QUAR.iterdir())
    except OSError: return {'items':[]}
    ids=set()
    for m in entries:
        if m.suffix!='.json' or not _QUAR_ID_RE.match(m.stem) or m.is_symlink(): continue
        try: rec=json.loads(m.read_text())
        except Exception: continue
        data=QUAR/(m.stem+'.qf')
        ids.add(m.stem)
        items.append({'id':m.stem,'original_path':str(rec.get('original_path','')),'signature':str(rec.get('signature','')),
                      'size':int(rec.get('size',0)),'quarantined_at':rec.get('quarantined_at'),
                      'restorable':data.is_file() and not data.is_symlink()})
    for f in entries:
        # Path('<id>.json.tmp').stem is '<id>.json', so the id test never matched a
        # half-written metadata file and it was listed as an un-restorable item.
        if f.suffix=='.tmp': continue
        if f.suffix=='.json' and _QUAR_ID_RE.match(f.stem): continue
        if f.suffix=='.qf' and f.stem in ids: continue
        try:
            if f.is_symlink() or not f.is_file(): continue
            st=f.stat()
        except OSError: continue
        # A file with no metadata record (quarantine interrupted part-way, or a record
        # deleted by hand): listed so it can still be seen and deleted.
        items.append({'id':f.name,'original_path':'(unknown - its quarantine record is missing)','signature':'',
                      'size':st.st_size,'quarantined_at':st.st_mtime,'restorable':False})
    items.sort(key=lambda x:x.get('quarantined_at') or 0,reverse=True)
    return {'items':items}

def restore_quarantined(qid,overwrite=False):
    qid=str(qid or '')
    if not _QUAR_ID_RE.match(qid): return {'ok':False,'error':'this item has no recorded original location and cannot be restored; delete it instead'}
    args=['restore',qid]+(['--overwrite'] if overwrite else [])
    res=_quarantine_helper(args)
    log(f'quarantine restore {qid}: ok={res.get("ok")} {res.get("restored_to","") or res.get("error","")}','WARN')
    return res

def delete_quarantine_item(ident):
    """Permanently delete one quarantined item by id, or a stray file by name."""
    ident=str(ident or '')
    with QUAR_LOCK:
        if _QUAR_ID_RE.match(ident):
            n=0
            for suf in ('.qf','.json'):
                p=QUAR/(ident+suf)
                try:
                    if p.is_symlink() or p.is_file(): p.unlink(); n+=1
                except OSError as e: return {'ok':False,'error':str(e)}
            if not n: return {'ok':False,'error':'quarantined item not found'}
        else:
            if not ident or '/' in ident or ident in ('.','..'): return {'ok':False,'error':'invalid item'}
            p=QUAR/ident
            try:
                if not (p.is_file() or p.is_symlink()): return {'ok':False,'error':'quarantined item not found'}
                p.unlink()
            except OSError as e: return {'ok':False,'error':str(e)}
    log(f'deleted quarantined item {ident}','WARN')
    return {'ok':True}

def delete_all_quarantine():
    n=0
    with QUAR_LOCK:
        try: entries=list(QUAR.iterdir())
        except OSError: entries=[]
        for p in entries:
            try:
                if p.is_symlink() or p.is_file(): p.unlink(); n+=1
            except OSError: pass
    log(f'deleted all quarantined items ({n} files)','WARN')
    return {'ok':True,'deleted':n}

_PRIVILEGED_COMMANDS={'apt-get','unattended-upgrade','freshclam'}

def run_privileged(cmd,timeout=60,input_text=None):
    if not isinstance(cmd,(list,tuple)) or not cmd or str(cmd[0]) not in _PRIVILEGED_COMMANDS:
        return 126,'refused privileged command'
    # apt-get/unattended-upgrade need to setuid/setgid down to the unprivileged
    # _apt sandbox user before fetching anything; our systemd unit deliberately
    # runs the long-lived daemon with a minimal CapabilityBoundingSet (no
    # CAP_SETUID/CAP_SETGID), and a child process can never exceed its parent's
    # bounding set even as root, so a plain subprocess call always fails that
    # step ("setgroups/setegid/seteuid ... Operation not permitted"). Same
    # workaround as aide_init(): run it in its own transient unit with the
    # full capability set instead of inheriting ours.
    # NOTE: locsecd.service also sets PrivateTmp=true, so this daemon's own
    # /tmp is a private mount namespace invisible to the transient unit that
    # systemd-run spawns (that unit is a sibling managed directly by PID 1,
    # not a child that inherits our namespace). Never pass a /tmp filepath
    # from this process into a command run via run_privileged() -- it will
    # not exist from the transient unit's point of view and will fail with
    # a confusing "no such file" instead of a permissions error. Pass data
    # via input_text (stdin) instead; --pipe below forwards it through.
    pre='locsecd-apt' if str(cmd[0]) in ('apt-get','unattended-upgrade') else 'locsecd-priv'
    rc,out=_run_transient(cmd,timeout,input_text,prefix=pre)
    if rc!=0 and 'Operation not permitted' in out:
        out+='\n(systemd-run not available to grant this command the extra capabilities it needs to sandbox itself as _apt; run it manually with sudo instead.)'
    return rc,out

def _apt_pending(phase_opt):
    # Simulate an upgrade and return [(pkg, old, new, [origins], is_security)] for packages that
    # are already installed (i.e. real upgrades), plus the raw simulation output.
    rc,out=run_privileged(['apt-get','-s','--with-new-pkgs']+phase_opt+['upgrade'],180)
    pending=[]
    for line in out.splitlines():
        m=re.match(r'^Inst (\S+)(?: \[([^\]]*)\])? \((\S+) (.*?)\)\s*(?:\[[^\]]*\]\s*)?$',line)
        if not m or m.group(2) is None: continue   # no "[old]" = brand-new dependency, pulled in automatically
        origins=re.sub(r'\s*\[[^\]]*\]\s*$','',m.group(4))
        olist=[o.strip() for o in origins.split(',') if o.strip()]
        pending.append((m.group(1),m.group(2),m.group(3),olist,any('security' in o.lower() for o in olist)))
    return rc,pending,out

def package_update():
    if not have('apt-get'): return {'ok':False,'output':'apt-get not found'}
    before=run(['dpkg-query','-W','-f=${binary:Package} ${Version}\n'],120,tail=8000000)[1]
    out=[]; note_parts=[]
    rc,s=run_privileged(['apt-get','update'],300); out.append(s)
    if rc!=0:
        # A single unreachable third-party repo (or a transient mirror error) must not stop security
        # patches from the repos that did refresh; carry on with the lists apt has.
        note_parts.append('apt-get update reported errors (see output); continuing with the package lists that are available.')
    phase_opt=['-o','APT::Get::Always-Include-Phased-Updates=true'] if CFG.get('include_phased_updates') else []
    rc_sim,pending,sim=_apt_pending(phase_opt); out.append(sim[-6000:])
    if rc_sim!=0 and not pending:
        return {'ok':False,'changed':[],'needs_reboot':Path('/var/run/reboot-required').exists(),
                'note':'Could not compute the list of pending updates; see the output.','output':'\n'.join(out)[-30000:]}
    # Origin policy is decided HERE from apt's own metadata instead of unattended-upgrade's
    # Allowed-Origins list, which is distro-specific and on Linux Mint (whose default list names only
    # Mint's own repos) silently excludes the upstream Ubuntu security packages Mint actually runs.
    security_only=bool(CFG.get('update_security_only'))
    chosen=[p for p in pending if p[4]] if security_only else list(pending)
    held=[p for p in pending if p not in chosen]
    install_rc=0
    if chosen and CFG.get('auto_update'):
        names=[p[0] for p in chosen]
        rc_i,s=run_privileged(['apt-get','install','-y','--only-upgrade',
                               '-o','Dpkg::Options::=--force-confold','-o','Dpkg::Options::=--force-confdef','-o','Dpkg::Use-Pty=0']
                              +phase_opt+names,3600)
        out.append(s); install_rc=rc_i
        if rc_i!=0:
            if re.search(r'Could not get lock|Unable to acquire the dpkg frontend lock|held by process',s):
                note_parts.append('Another package manager is running (Update Manager, unattended-upgrades or apt); nothing was changed. Retry when it finishes.')
            else:
                note_parts.append(f'apt-get install exited with status {rc_i}; see the output for the failing package.')
    after=run(['dpkg-query','-W','-f=${binary:Package} ${Version}\n'],120,tail=8000000)[1]
    old={line.split(' ',1)[0]:line.split(' ',1)[1] for line in before.splitlines() if ' ' in line}
    changed=[]
    for line in after.splitlines():
        if ' ' in line:
            pkg,ver=line.split(' ',1)
            if old.get(pkg)!=ver: changed.append(f'{pkg}: {old.get(pkg,"not-installed")} -> {ver}')
    needs_restart=Path('/var/run/reboot-required').exists()
    if not pending:
        note_parts.append('The system is up to date: no pending package updates.')
    elif not CFG.get('auto_update'):
        note_parts.append(f'auto_update is off: {len(chosen)} update(s) are ready ({", ".join(p[0] for p in chosen[:10])}{"..." if len(chosen)>10 else ""}) but were not applied.')
    if held:
        if security_only:
            note_parts.append(f'{len(held)} non-security update(s) were left alone because update_security_only is true ({", ".join(p[0] for p in held[:10])}{"..." if len(held)>10 else ""}). Set update_security_only to false to apply everything.')
    if not changed and pending and chosen and CFG.get('auto_update') and install_rc==0:
        # Nothing changed although apt reported candidates and did not fail: phased rollout.
        # run_privileged, not run: apt drops to the _apt sandbox user even for a
        # simulation, which this daemon's own capability set cannot allow.
        _,cand=run_privileged(['apt-get','-s','upgrade'],120)
        phased=re.findall(r'deferred due to phasing.*?\n((?:^\s+\S.*\n?)*)',cand,re.M)
        phased_pkgs=[p for line in phased for p in line.split()]
        if phased_pkgs:
            note_parts.append(f'{len(phased_pkgs)} package(s) are held back by Ubuntu\'s phased rollout ({", ".join(phased_pkgs[:10])}); apt releases them to every machine within a few days. Set include_phased_updates to true to apply immediately.')
    ok = install_rc==0
    result={'ok':ok,'changed':changed,'needs_reboot':needs_restart,'note':' '.join(note_parts),'output':'\n'.join(out)[-30000:]}
    report=REPORTS/f'update-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'; atomic_json(report,{'ts':time.time(),'result':result})
    result['report']=str(report)
    log(f'package update completed; changed {len(changed)} packages; report={report}')
    return result

def _scan_props(io='idle'):
    # CPU/I-O priority for scans that run in their own transient unit (where
    # a nice/ionice wrapper would just be one more thing to get wrong).
    props=[f'Nice={int(CFG.get("scan_nice",10))}']
    if io=='idle': props.append('IOSchedulingClass=idle')
    else: props+=['IOSchedulingClass=best-effort','IOSchedulingPriority=7']
    return props

def scan_tool(name,cmd,timeout=1800,transient=False,io='idle',head=0,tail=20000,save_to=None):
    if not have(cmd[0]): return {'name':name,'status':'not-installed','output':f'{cmd[0]} not found'}
    # Heavy scans are deliberately background-friendly: lower CPU priority and
    # idle I/O prevent LocSec from competing with interactive workloads.
    #
    # transient=True runs the tool in its own systemd transient unit instead of
    # inside locsecd.service's sandbox. The daemon's unit deliberately runs with
    # a minimal capability set, a read-only /etc and /usr, no /lib/modules and a
    # private mount namespace -- fine for a monitor, wrong for an auditor:
    # Lynis/apt failed to drop privileges ("setgroups ... Operation not
    # permitted"), rkhunter saw "/lib/modules is missing or empty", and AIDE
    # would read attributes under a different capability set than aideinit used
    # to build its baseline.
    if transient:
        rc,out=_run_transient(list(cmd),timeout,prefix='locsecd-scan',props=_scan_props(io),head=head,tail=tail,save_to=save_to)
    else:
        run_cmd=list(cmd)
        if have('nice') and have('ionice'):
            run_cmd=['nice','-n',str(int(CFG.get('scan_nice',10))),'ionice','-c','3']+run_cmd
        rc,out=run(run_cmd,timeout,head=head,tail=tail,save_to=save_to)
    log(f'{name} scan completed rc={rc}')
    return {'name':name,'status':'ok' if rc==0 else 'findings-or-error','rc':rc,'output':out}


def _aide_lock(blocking=False):
    """Acquire the cross-process AIDE lock and return its open fd, or None."""
    try:
        AIDE_LOCK_PATH.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        fd=os.open(str(AIDE_LOCK_PATH), os.O_RDWR|os.O_CREAT, 0o660)
        try:
            os.chmod(fd,0o660)
        except Exception:
            pass
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except OSError:
            os.close(fd)
            return None
        return fd
    except Exception as e:
        log(f'AIDE lock acquisition failed: {e}','ERROR')
        return None


def _aide_unlock(fd):
    if fd is None: return
    try: fcntl.flock(fd, fcntl.LOCK_UN)
    except Exception: pass
    try: os.close(fd)
    except Exception: pass


def _aide_systemd_busy():
    if not have('systemctl'): return False
    rc,_=run(['systemctl','is-active','--quiet','dailyaidecheck.service'],10)
    return rc==0


def _aide_processes_running():
    # Defensive check for AIDE invocations which did not use our shared systemd lock.
    try:
        out=subprocess.check_output(['pgrep','-a','-f',r'(^|/)(aide|aideinit)( |$)'],text=True,stderr=subprocess.DEVNULL,timeout=5)
        return [line for line in out.splitlines() if line.strip()]
    except Exception:
        return []


def external_aide():
    """An AIDE run LocSec did not start, so the Scans page can say what is using the CPU.

    The aide package's own daily check (dailyaidecheck.service, run as _aide)
    is the usual one: LocSec's own AIDE runs always hold JOB_LOCK, so this is
    only asked when no LocSec job is running."""
    procs=[]
    for line in _aide_processes_running()[:10]:
        pid=(line.split() or [''])[0]
        user=''
        try:
            uid=int(next(l.split()[1] for l in Path(f'/proc/{pid}/status').read_text().splitlines() if l.startswith('Uid:')))
            import pwd
            user=pwd.getpwuid(uid).pw_name
        except Exception: pass
        procs.append({'pid':pid,'user':user,'cmd':line.split(None,1)[1][:200] if ' ' in line else line})
    daily=_aide_systemd_busy()
    if not procs and not daily: return None
    timer=''
    if have('systemctl'):
        _,timer=run(['systemctl','is-enabled','dailyaidecheck.timer'],10); timer=timer.strip().splitlines()[0] if timer.strip() else ''
    if daily or any(p['user']=='_aide' for p in procs):
        msg=('AIDE is running, but LocSec did not start it: this is the aide package\'s own daily check '
             '(dailyaidecheck, run as the _aide user). '+
             ('LocSec turns that daily check off when it is installed; this run was already going and will finish on its own.'
              if timer!='enabled' else
              'It is still switched on (dailyaidecheck.timer is enabled), so it runs every day on top of LocSec\'s weekly check. '
              'Turn it off with: sudo systemctl disable --now dailyaidecheck.timer'))
    else:
        msg='AIDE is running, but LocSec did not start it (started by hand or by another program).'
    return {'what':'AIDE','message':msg,'processes':procs,'daily_timer':timer}


def _aide_db_state():
    state={}
    for label,path in (('database',AIDE_DB),('new_database',AIDE_DB_NEW)):
        try:
            st=path.stat()
            state[label]={'path':str(path),'exists':True,'size':st.st_size,'mode':oct(st.st_mode & 0o777),'uid':st.st_uid,'gid':st.st_gid,'mtime':st.st_mtime}
        except FileNotFoundError:
            state[label]={'path':str(path),'exists':False}
        except Exception as e:
            state[label]={'path':str(path),'exists':False,'error':str(e)}
    return state


def _aide_preflight():
    """Acquire the shared AIDE lock and reject concurrent AIDE work."""
    fd=_aide_lock(False)
    if fd is None:
        return None, {'ok':False,'error':'another AIDE operation is already running'}
    if _aide_systemd_busy():
        _aide_unlock(fd)
        return None, {'ok':False,'error':'Debian dailyaidecheck.service is currently running; wait for it to finish before changing the AIDE baseline'}
    running=_aide_processes_running()
    if running:
        _aide_unlock(fd)
        return None, {'ok':False,'error':'another AIDE process is currently running; operation was refused','processes':running[:10]}
    return fd, None


def _aide_regular_file(path):
    try:
        st=path.stat()
        return path.is_file() and st.st_size>0 and not path.is_symlink()
    except OSError:
        return False


def _aide_timeout():
    """Single time limit for every AIDE run (check, initialize, rebuild): aide_scan_timeout."""
    try: t=int(CFG.get('aide_scan_timeout',10800))
    except (TypeError,ValueError): t=10800
    return max(300,min(259200,t))

def aide_init():
    """Initialize AIDE only when no baseline exists; never overwrite one silently."""
    if not have('aideinit'): return {'ok':False,'error':'aideinit not installed'}
    fd,err=_aide_preflight()
    if err: return err
    try:
        state=_aide_db_state()
        if AIDE_DB.exists():
            # A valid existing baseline means AIDE is already initialized. The old
            # implementation returned an error here, making the dashboard button
            # look broken on every already-initialized machine. Do not overwrite it.
            valid=_aide_regular_file(AIDE_DB)
            pending=_aide_regular_file(AIDE_DB_NEW)
            return {'ok':valid,'initialized':valid,'already_initialized':valid,
                    'pending_database':pending,
                    'message':('AIDE is already initialized; the existing baseline was not changed.' if valid else 'AIDE database exists but is not a valid regular non-empty file.'),
                    'database':state}
        if AIDE_DB_NEW.exists():
            return {'ok':False,'error':'AIDE has an existing pending database at aide.db.new; use Accept pending baseline after reviewing it','database':state}
        # aideinit writes to /var/log/aide and internally re-execs aide via capsh with
        # extra capabilities. The LocSec service has a deliberately narrow capability
        # bounding set, so run aideinit in a transient systemd unit with its own full
        # bounding set. The shared flock is held by this parent for the entire operation.
        rc,out=_run_transient(['aideinit','--yes'],_aide_timeout(),prefix='locsecd-aideinit')
        if rc!=0 and not have('systemd-run'):
            out+='\n(systemd-run not available to grant aideinit the extra capabilities it needs; run "sudo aideinit --yes" manually instead.)'
        if rc==124: out=(out+'\n' if out else '')+f'aideinit did not finish within {_aide_timeout()}s (aide_scan_timeout in /etc/locsecd/locsecd.conf). Raise the limit or exclude large trees in /etc/aide/aide.conf.d, then run it again.'
        state=_aide_db_state()
        valid=state.get('database',{}).get('exists') and state.get('database',{}).get('size',0)>0
        ok=(rc==0 and valid)
        if not ok and rc==0:
            out=(out+'\n' if out else '')+'aideinit returned success but no non-empty aide.db was produced.'
        log(f'AIDE initialization rc={rc} db_valid={valid} state={json.dumps(state,separators=(",",":"))}')
        return {'ok':ok,'rc':rc,'output':out,'database':state}
    finally:
        _aide_unlock(fd)


def aide_accept_pending(confirm=False):
    """Explicitly promote Debian's pending AIDE database to the active baseline.

    The long-lived LocSec service deliberately has a reduced capability set. Debian's
    dailyaidecheck creates aide.db.new as _aide, so chmod/chown cannot safely be done
    in that constrained daemon. Perform only this narrowly-scoped promotion in a
    short-lived root transient unit, while the parent keeps the shared AIDE lock.
    """
    if not confirm:
        return {'ok':False,'error':'explicit confirmation required to replace the active AIDE baseline','required_confirmation':'ACCEPT_PENDING'}
    fd,err=_aide_preflight()
    if err: return err
    try:
        if not _aide_regular_file(AIDE_DB_NEW):
            return {'ok':False,'error':'no valid non-empty aide.db.new is available','database':_aide_db_state()}
        helper=Path('/usr/lib/locsecd/aide-accept-pending')
        if not helper.exists() or not helper.is_file() or helper.is_symlink():
            return {'ok':False,'error':'AIDE pending-database helper is missing or invalid','database':_aide_db_state()}
        # The helper is root-owned mode 0700 and is invoked only in a sibling
        # transient unit with the host capability set. The daemon's reduced
        # CapabilityBoundingSet therefore remains unchanged.
        rc,out=_run_transient([str(helper)],120,prefix='locsecd-aide-accept')
        payload=None
        try:
            payload=json.loads(out.strip().splitlines()[-1]) if out.strip() else None
        except Exception:
            payload=None
        if isinstance(payload,dict):
            payload.setdefault('rc',rc)
            if rc!=0 and payload.get('ok') is True:
                payload['ok']=False
            return payload
        return {'ok':False,'rc':rc,'error':'AIDE promotion helper returned no valid JSON result','output':out[-12000:],'database':_aide_db_state()}
    finally:
        _aide_unlock(fd)

def aide_reinitialize(confirm=False):
    """Explicitly rebuild and replace the AIDE baseline using aideinit --force."""
    if not confirm:
        return {'ok':False,'error':'explicit confirmation required to replace the active AIDE baseline','required_confirmation':'REPLACE_BASELINE'}
    if not have('aideinit'): return {'ok':False,'error':'aideinit not installed'}
    fd,err=_aide_preflight()
    if err: return err
    try:
        # Debian's aideinit documents --force as the explicit operation that replaces
        # the existing database; --yes only permits overwriting database_out.
        rc,out=_run_transient(['aideinit','--yes','--force'],_aide_timeout(),prefix='locsecd-aide-reinit')
        state=_aide_db_state()
        valid=_aide_regular_file(AIDE_DB)
        ok=(rc==0 and valid and state['database']['uid']==0 and state['database']['gid']==0 and state['database']['mode']=='0o600')
        if rc!=0 and not have('systemd-run'):
            out+='\n(systemd-run not available; run "sudo aideinit --yes --force" manually instead.)'
        if rc==124: out=(out+'\n' if out else '')+f'aideinit did not finish within {_aide_timeout()}s (aide_scan_timeout in /etc/locsecd/locsecd.conf). The existing baseline was not replaced. Raise the limit or exclude large trees in /etc/aide/aide.conf.d, then run it again.'
        log(f'AIDE reinitialization rc={rc} db_valid={valid} state={json.dumps(state,separators=(",",":"))}')
        return {'ok':ok,'rc':rc,'output':out,'action':'reinitialize','database':state}
    finally:
        _aide_unlock(fd)


# Paths whose change is worth a person's attention: system binaries and
# libraries, configuration, boot files, root's home, scheduled jobs, and the
# places in a user's home that run code at login or accept remote logins.
_AIDE_SENSITIVE=re.compile(r'^/(?:etc|boot|root|bin|sbin|lib|lib32|lib64|usr/(?:bin|sbin|lib|lib32|lib64|libexec|local)|var/spool/cron|opt)(?:/|$)'
                           r'|^/home/[^/]+/(?:\.ssh|\.bashrc|\.bash_profile|\.profile|\.bash_logout|\.zshrc|\.xprofile|\.xsessionrc|\.config/autostart|\.config/systemd|\.config/environment\.d|\.local/bin|\.gnupg)(?:/|$)')
_AIDE_ENTRY=re.compile(r'^[fdlpsbcDPL!][^:]{0,40}: (/.*)$')

def _aide_digest(path, list_max=150):
    """Summarise a full AIDE --check output: every security-relevant path, and
    everything else counted by directory, so thousands of cache and catalogue
    changes cannot bury the one that matters."""
    section=None; counts={'added':0,'removed':0,'changed':0}
    sensitive={'added':[],'removed':[],'changed':[]}; nsens={'added':0,'removed':0,'changed':0}; areas={}
    with open(path,'r',errors='replace') as f:
        for line in f:
            line=line.rstrip('\n')
            h=line.strip().lower()
            if h in ('added entries:','removed entries:','changed entries:'): section=h.split()[0]; continue
            if h.startswith('detailed information about changes') or h.startswith('the attributes of the'): section=None; continue
            if not section: continue
            m=_AIDE_ENTRY.match(line)
            if not m: continue
            p=m.group(1).strip(); counts[section]+=1
            if _AIDE_SENSITIVE.search(p):
                nsens[section]+=1
                if len(sensitive[section])<list_max: sensitive[section].append(p)
            else:
                parts=[x for x in p.split('/') if x]
                key='/'+'/'.join(parts[:3])
                areas[key]=areas.get(key,0)+1
    lines=['LocSec summary of this AIDE check',
           f'  {counts["added"]} added, {counts["removed"]} removed, {counts["changed"]} changed.',
           f'  Security-relevant (system binaries, libraries, /etc, /boot, root, cron, login and SSH files): '
           f'{nsens["added"]} added, {nsens["removed"]} removed, {nsens["changed"]} changed.']
    for sec in ('added','removed','changed'):
        if sensitive[sec]:
            lines+=['',f'SECURITY-RELEVANT, {sec.upper()} ({nsens[sec]}):']+['  '+x for x in sensitive[sec]]
            if nsens[sec]>len(sensitive[sec]): lines.append(f'  ... and {nsens[sec]-len(sensitive[sec])} more in the full output')
    if any(nsens.values()):
        lines+=['','Changes under /usr, /lib and /etc right after a package update are expected: compare the times with',
                'the apt history (grep -A3 "Start-Date" /var/log/apt/history.log). A change nothing explains needs a look.']
    else:
        lines+=['','Nothing security-relevant changed. Everything below is ordinary churn (caches, catalogues, logs).']
    if areas:
        lines+=['','Other changes by directory (largest first):']
        for k,v in sorted(areas.items(),key=lambda kv:-kv[1])[:25]: lines.append(f'  {v:7d}  {k}')
        if len(areas)>25: lines.append(f'  ... and {len(areas)-25} more directories')
    lines+=['',f'Full AIDE output: {path}','--- AIDE output (beginning and end) ---']
    return '\n'.join(lines)

def _aide_config():
    # Debian/Ubuntu's aide package ships aide.wrapper (used by cron/aideinit),
    # which knows where its config lives; the raw `aide` binary invoked
    # directly does not have a compiled-in default and fails with "missing
    # configuration" unless --config is passed explicitly. /etc/aide/aide.conf
    # is where the package puts it; Debian also generates a merged
    # /var/lib/aide/aide.conf.autogenerated that includes it.
    for c in (Path('/etc/aide/aide.conf'),Path('/var/lib/aide/aide.conf.autogenerated')):
        if c.exists(): return str(c)
    return None

def _scan_aide():
    if not have('aide'): return None
    if _aide_systemd_busy():
        return {'name':'AIDE','status':'busy','output':'Debian dailyaidecheck.service is running; LocSec skipped AIDE to avoid competing for the reference database.'}
    fd=_aide_lock(False)
    if fd is None:
        return {'name':'AIDE','status':'busy','output':'Another AIDE operation is running; LocSec skipped AIDE.'}
    try:
        running=_aide_processes_running()
        if running:
            return {'name':'AIDE','status':'busy','output':'Another AIDE process is running; LocSec skipped AIDE.\n'+'\n'.join(running[:10])}
        if not AIDE_DB.exists():
            return {'name':'AIDE','status':'not-initialized','output':'AIDE database not found; use Rebuild AIDE baseline on the Scans page before checking integrity'}
        conf=_aide_config()
        if not conf:
            return {'name':'AIDE','status':'error','output':'AIDE config not found at /etc/aide/aide.conf; reinstall the aide package or run aideinit to regenerate it.'}
        timeout=_aide_timeout()
        # The complete output goes to a file beside the reports: the dashboard copy
        # keeps only the head and tail, and a check with thousands of changes had
        # everything in between -- usually the part that matters -- thrown away.
        full=REPORTS/f'aide-full-{datetime.now().strftime("%Y%m%d-%H%M%S")}.txt'
        # Best-effort (not idle) I/O class: under idle-class I/O a busy desktop can starve AIDE
        # for hours. head=8000 keeps AIDE's summary block, which it prints BEFORE the long detail lists.
        result=scan_tool('AIDE',['aide','--config',conf,'--check'],timeout,transient=True,io='besteffort',head=8000,save_to=str(full))
        rc=result.get('rc')
        if isinstance(rc,int) and 1<=rc<=7 and full.is_file():
            try:
                result['output']=_aide_digest(full)+'\n\n'+str(result.get('output',''))
                result['full_output']=str(full)
            except Exception as e: log(f'AIDE digest failed: {e}','ERROR')
        # aide exit status is a bitmask: 1=added 2=removed 4=changed (any of 1..7 = differences found,
        # which is a finding, not a failure); 14+ are real errors (write/argument/config/IO/version).
        if rc==0: result['status']='ok'
        elif rc==124:
            result['status']='timeout'
            result['output']=(f'AIDE did not finish within {timeout}s (aide_scan_timeout in /etc/locsecd/locsecd.conf). '
                              'The check was stopped; raise the limit and re-run, or exclude large volatile trees in /etc/aide/aide.conf.d.\n')+str(result.get('output',''))
        elif isinstance(rc,int) and 1<=rc<=7: result['status']='findings-or-error'
        else: result['status']='error'
        result['database']=_aide_db_state()
        return result
    finally:
        _aide_unlock(fd)

_LYNIS_NOISE=re.compile(r'(?:\[WARNING\]: Test \S+ had a long execution|^pgrep: pattern that searches for process name longer|^Try `pgrep -f. option|Cannot initialize device-mapper)')

def _scan_lynis():
    if not have('lynis'): return None
    started=time.time()
    r=scan_tool('Lynis',['lynis','audit','system','--quick','--no-colors','--quiet'],int(CFG.get('lynis_timeout',3600)),transient=True)
    rc=r.get('rc')
    # Lynis's own report file is the authoritative record of what it found; stdout with --quiet is
    # just warnings plus internal timing chatter. Read the report instead of guessing from stdout.
    def _field(line,prefix):
        # lynis-report.dat rows are "<prefix>TEST-ID|text|details|solution|".
        f=line[len(prefix):].split('|')
        out=(f[0]+': '+(f[1] if len(f)>1 else '')).strip()
        det=(f[2] if len(f)>2 else '').strip()
        if det and det not in ('-','') and len(det)<=120: out+=f'  [{det}]'
        return out
    warns=[]; suggs=[]; idx=None; have_report=False
    try:
        rp=Path('/var/log/lynis-report.dat')
        if rp.is_file() and rp.stat().st_mtime>=started-5:
            have_report=True
            for line in rp.read_text(errors='replace').splitlines():
                if line.startswith('warning[]='):
                    warns.append(_field(line,'warning[]='))
                elif line.startswith('suggestion[]='):
                    # Previously only counted. The report file is root-only, so an
                    # operator reading the dashboard was told "Suggestions: 51" and
                    # then pointed at a file they could not open; list them here.
                    suggs.append(_field(line,'suggestion[]='))
                elif line.startswith('hardening_index='): idx=line.split('=',1)[1].strip()
    except Exception as e: log(f'could not read Lynis report: {e}','ERROR')
    raw=[l for l in str(r.get('output','')).splitlines() if l.strip()]
    noise=[l for l in raw if _LYNIS_NOISE.search(l)]
    other=[l for l in raw if l not in noise]
    if rc==124: status='timeout'
    elif not have_report and rc not in (0,): status='error'
    elif warns: status='warning'
    else: status='ok'
    lines=[]
    if have_report:
        lines.append(f'Lynis audit complete. Hardening index: {idx if idx is not None else "n/a"}/100. Warnings: {len(warns)}. Suggestions: {len(suggs)}.')
    if warns: lines+=['','Warnings (review these first):']+[' - '+w for w in warns[:100]]
    if suggs:
        lines+=['',f'Suggestions ({len(suggs)}) -- hardening opportunities, not findings:']+[' - '+x for x in suggs[:150]]
        if len(suggs)>150: lines.append(f' ... and {len(suggs)-150} more (see the report file).')
        lines+=['','Lynis is written for servers, so some suggestions do not apply to a desktop. Treat them as a',
                'list to decide on deliberately rather than a score to raise. Anything that tightens /var/log',
                'so rsyslog cannot write works against LocSec itself -- check a suggestion against the rest',
                'of the system before applying it.']
    if noise: lines+=['',f'Informational: {len(noise)} internal timing/environment note(s) from Lynis (slow tests, missing device-mapper) -- not findings.']
    if other: lines+=['','Other output:']+other[:60]
    if have_report: lines+=['','Full report: /var/log/lynis-report.dat']
    r['status']=status
    r['output']='\n'.join(lines) if lines else str(r.get('output',''))
    r['warnings']=len(warns); r['suggestions']=len(suggs); r['suggestion_list']=suggs[:150]
    return r

_DEBSECAN_LINE=re.compile(r'^((?:CVE|TEMP)-\S+)\s+(\S+)(?:\s+\((.*)\))?\s*$')

def _debsecan_result(name):
    # debsecan exits 0 whether it lists nothing or hundreds of CVEs, so the
    # result used to be labelled "Clean / no findings" above a long list; and
    # the list itself was the last 20 KB of output, so most of it was dropped.
    # Run it twice -- everything known, and only what already has a fix -- and
    # report the numbers that decide what to do.
    s=scan_tool(name,['debsecan','--suite',DEBIAN_SUITE],1800,tail=4000000)
    if s.get('status')=='not-installed': return s
    if s.get('rc')!=0:
        s['status']='error'
        s['output']='debsecan could not run (it downloads the Debian security tracker data, so this is usually no network):\n'+str(s.get('output',''))[-3000:]
        return s
    f=scan_tool(name,['debsecan','--suite',DEBIAN_SUITE,'--only-fixed'],1800,tail=4000000)
    def parse(out):
        rows=[]
        for line in str(out).splitlines():
            m=_DEBSECAN_LINE.match(line.strip())
            if m: rows.append((m.group(1),m.group(2),m.group(3) or ''))
        return rows
    known=parse(s.get('output','')); fixed=parse(f.get('output','')) if f.get('rc')==0 else []
    fixkeys={(c,p) for c,p,_ in fixed}
    per={}
    for c,pkg,_f in known:
        if (c,pkg) not in fixkeys: per[pkg]=per.get(pkg,0)+1
    high=[r for r in known if 'high urgency' in r[2] or 'remotely exploitable' in r[2]]
    lines=[f'debsecan ({DEBIAN_SUITE}): {len(known)} known vulnerabilit{"y" if len(known)==1 else "ies"} in {len(per)} installed package(s); '
           f'{len(fixed)} ha{"s" if len(fixed)==1 else "ve"} a fix available now.']
    if f.get('rc')!=0: lines.append('(The fixed-only query failed, so the number with a fix is not known this time.)')
    if fixed:
        lines+=['','FIX AVAILABLE -- install with Update system (or wait for the automatic update):']
        lines+=[f'  {c}  {p}'+(f'  ({fl})' if fl else '') for c,p,fl in fixed[:200]]
        if len(fixed)>200: lines.append(f'  ... and {len(fixed)-200} more')
    if high:
        lines+=['',f'Marked remotely exploitable or high urgency ({len(high)}):']+[f'  {c}  {p}  ({fl})' for c,p,fl in high[:50]]
    if per:
        lines+=['','Known but not yet fixed in Debian, by package (largest first). Nothing to install for these;',
                'they clear when Debian ships a fix, which LocSec then installs automatically:']
        for pkg,n in sorted(per.items(),key=lambda kv:-kv[1])[:40]: lines.append(f'  {n:5d}  {pkg}')
        if len(per)>40: lines.append(f'  ... and {len(per)-40} more packages')
    s['status']='warning' if fixed else ('info' if known else 'ok')
    s['known']=len(known); s['fixable']=len(fixed)
    s['output']='\n'.join(lines)
    return s

def _scan_debsecan():
    if not have('debsecan'): return None
    if IS_DEBIAN_NATIVE: return _debsecan_result('Debsecan')
    return {'name':'Debsecan','status':'skipped','output':'skipped on Ubuntu/Mint: the Debian vulnerability feed does not match Ubuntu package versions; see APT security candidates instead'}

def _dpkg_file_intact(path):
    # True only when the file is owned by an installed package AND dpkg's own
    # verification (md5sums) reports it unmodified. Used to tell "a package shipped
    # this as a script" apart from "something replaced a system binary".
    try:
        if not path.startswith('/') or '\n' in path: return False
        rc,out=run(['dpkg','-S',path],20)
        if rc!=0: return False
        pkg=out.split(':',1)[0].split(',')[0].strip()
        if not re.fullmatch(r'[A-Za-z0-9.+_-]+(?::[a-z0-9]+)?',pkg): return False
        rc,v=run(['dpkg','--verify',pkg],120)
        return rc==0 and path not in v
    except Exception:
        return False

# Files systemd/other base components create that rkhunter's "hidden file" check reports on every run.
_RKH_BENIGN_HIDDEN={'/etc/.updated','/etc/.resolv.conf.systemd-resolved.bak','/etc/.pwd.lock','/etc/.java',
                    '/usr/share/man/man5/.k5identity.5.gz','/usr/share/man/man5/.k5login.5.gz','/dev/.udev','/dev/.mdadm'}

# Groups whose membership grants root or raw hardware/disk access. A new one of
# these is never waved through as "created by a package".
_RKH_PRIVILEGED_GROUPS={'root','sudo','wheel','adm','shadow','disk','kmem','docker','lxd','libvirt','kvm','staff'}

def _is_login_user(name):
    try:
        import pwd
        return pwd.getpwnam(name).pw_uid>=1000
    except Exception:
        return False

def _rkhunter_classify(block):
    # block = [ 'Warning: ...', '   continuation', ... ]. Returns (benign, reason).
    head=block[0]; body=block[1:]
    text='\n'.join(block)
    for pat in CFG.get('rkhunter_ignore',[]):
        try:
            if re.search(pat,text): return True,'matched rkhunter_ignore in locsecd.conf'
        except re.error: pass
    m=re.search(r"The command '([^']+)' has been replaced by a script",head)
    if m:
        return (_dpkg_file_intact(m.group(1)),'shipped as a script by its package and verifies unmodified (dpkg --verify)')
    if 'suspicious (large) shared memory segments' in head:
        owners=set(re.findall(r'Owner:\s+(\S+)',' '.join(body)))
        if owners and all(_is_login_user(o) for o in owners):
            return True,'shared-memory segments owned by a normal login user (desktop applications / X11 IPC)'
        return False,''
    if head.startswith('Warning: Hidden file found:'):
        m=re.match(r'Warning: Hidden file found: (.+?): ',head)
        path=m.group(1) if m else ''
        if path in _RKH_BENIGN_HIDDEN: return True,'known systemd/base-system hidden file'
        return (_dpkg_file_intact(path) if path else False),'owned by a package and verifies unmodified'
    if 'Suspicious file types found in /dev' in head:
        entries=[b.strip() for b in body if b.strip()]
        if entries and all(re.match(r'/dev/shm/(?:ecryptfs-[^/]+-Private|lttng-ust-wait-\d+(?:-\d+)?):',e) for e in entries):
            return True,'eCryptfs signature or LTTng tracing wait file in /dev/shm (cleared at reboot)'
        return False,''
    # A new system account is what installing a service package does (clamav,
    # _aide, wireshark ...). Treat it as informational only when it really is
    # one: an unprivileged id in the system range, and for a user no login
    # shell. A new uid-0, login-capable or regular-range account still needs
    # review, as does any change to an existing group's members (sudo).
    m=re.match(r"Warning: User '([^']+)' has been added to the passwd file",head)
    if m:
        try:
            import pwd
            u=pwd.getpwnam(m.group(1))
            if 100<=u.pw_uid<1000 and (u.pw_shell.endswith('nologin') or u.pw_shell.endswith('/false')):
                return True,f'system account (uid {u.pw_uid}, no login shell) created by a package'
        except (KeyError,ImportError): pass
        return False,''
    m=re.match(r"Warning: Group '([^']+)' has been added to the group file",head)
    if m:
        try:
            import grp
            g=grp.getgrnam(m.group(1))
            if 100<=g.gr_gid<1000 and m.group(1) not in _RKH_PRIVILEGED_GROUPS:
                return True,f'system group (gid {g.gr_gid}) created by a package'
        except (KeyError,ImportError): pass
        return False,''
    return False,''

def _scan_rkhunter():
    if not have('rkhunter'): return None
    fix_rkhunter_web_cmd()
    _run_transient(['rkhunter','--update'],600,prefix='locsecd-scan',props=_scan_props('idle'))
    # 200 KB, not the generic 20 KB tail: the warning classifier parses findings
    # out of this output, so anything the tail cut off was silently not reported.
    r=scan_tool('rkhunter',['rkhunter','--check','--skip-keypress','--rwo'],3600,transient=True,tail=200000)
    rc=r.get('rc'); out=str(r.get('output',''))
    # --rwo (warnings-only output): each 'Warning:' line starts a finding; indented lines under it belong to it.
    blocks=[]
    for line in out.splitlines():
        if not line.strip(): continue
        if line.startswith('Warning:') or not blocks: blocks.append([line])
        else: blocks[-1].append(line)
    review=[]; benign=[]
    for bl in blocks:
        if not bl[0].startswith('Warning:'):
            review.append((bl,'')); continue
        ok,why=_rkhunter_classify(bl)
        (benign if ok else review).append((bl,why))
    if rc==124: status='timeout'
    elif rc not in (0,1): status='error'
    elif review: status='findings-or-error'
    elif benign: status='info'
    else: status='ok'
    lines=[f'rkhunter: {len(review)} finding(s) need review, {len(benign)} informational (verified benign).']
    if review:
        lines+=['','NEEDS REVIEW:']
        for bl,_ in review: lines+=bl
    if benign:
        lines+=['','INFORMATIONAL (checked, no action needed):']
        for bl,why in benign:
            lines.append(bl[0]+('  -- '+why if why else ''))
            lines+=bl[1:6]
            if len(bl)>6: lines.append(f'         ... and {len(bl)-6} more')
    r['status']=status
    r['output']='\n'.join(lines) if (blocks or rc in (0,1)) else out
    for bl,_ in review[:50]:
        key=re.sub(r'\s+',' ',bl[0])[:120]
        incident('rootkit-warning','rkhunter',key,'high','detected','\n'.join(bl)[:1500])
    return r

def _clamav_incident(result):
    # clamscan/clamdscan exit 1 means "infected files found" (0=clean,
    # 2=error). Surface each infected line as its own incident so the
    # timeline names the actual file and signature, not just "scan ran".
    if not result or result.get('rc')!=1: return
    lines=[l for l in str(result.get('output','')).splitlines() if l.rstrip().endswith('FOUND')]
    for line in lines[:50]:
        path,_,sig=line.rpartition(': ')
        incident('virus-found','clamav',path.strip(),'critical','detected',sig.strip())

# Trees never worth walking with an antivirus even if an operator points
# clamav_scan_paths at "/": pseudo filesystems, other volumes' mirrors,
# eCryptfs's encrypted lower directory (scanning ciphertext is pointless; the
# decrypted view is scanned through the user's mounted home), package/vendor
# static content. Extendable per-host via clamav_extra_excludes in locsecd.conf
# (list of anchored path regexes).
CLAMAV_DEFAULT_EXCLUDES=[
    r'^/proc', r'^/sys', r'^/dev', r'^/run', r'^/snap',
    r'^/home/\.ecryptfs',
    r'^/usr/src',
    r'^/usr/lib/firmware',
    r'^/usr/share/icons',
    r'^/usr/share/themes',
    r'^/usr/share/doc',
    r'^/usr/share/man',
    r'^/var/lib/dpkg/info',
    r'^/var/lib/flatpak',
    r'^/var/cache/apparmor',
    r'^/var/lib/locsecd/quarantine',
]
def _clamav_excludes():
    extra=CFG.get('clamav_extra_excludes',[])
    if not isinstance(extra,list): extra=[]
    seen=set(); out=[]
    for pat in CLAMAV_DEFAULT_EXCLUDES+list(extra):
        if pat not in seen:
            seen.add(pat); out.append(pat)
    return out

def _clamav_build_list(paths, out_path, max_bytes):
    # Walk the scan paths as root (this process) and write one regular-file path
    # per line. Symlinks, sockets, device nodes and oversize files are skipped
    # here instead of being handed to clamd to reject one by one.
    excl=[]
    for pat in _clamav_excludes():
        try: excl.append(re.compile(pat))
        except re.error: log(f'ignoring invalid ClamAV exclude regex: {pat}','WARN')
    st={'listed':0,'too_big':0,'special':0,'excluded':0,'unreadable_dirs':0}
    with open(out_path,'w',encoding='utf-8',errors='surrogateescape') as f:
        os.chmod(out_path,0o600)
        for top in paths:
            stack=[top]
            while stack and not STOP_EVENT.is_set():
                d=stack.pop()
                try: it=os.scandir(d)
                except OSError: st['unreadable_dirs']+=1; continue
                with it:
                    for e in it:
                        try:
                            path=e.path
                            if '\n' in path: continue
                            if any(rx.match(path) for rx in excl): st['excluded']+=1; continue
                            if e.is_symlink(): continue
                            if e.is_dir(follow_symlinks=False): stack.append(path); continue
                            if not e.is_file(follow_symlinks=False): st['special']+=1; continue
                            size=e.stat(follow_symlinks=False).st_size
                            if size==0: continue
                            if size>max_bytes: st['too_big']+=1; continue
                            f.write(path+'\n'); st['listed']+=1
                        except OSError: continue
    return st

def _clamav_parse_output(path):
    # Stream the full saved clamd/clamscan output: infected lines, error lines and the summary.
    r={'infected':[], 'found':0, 'errors':0, 'err_sample':[], 'have_summary':False, 'sum_infected':None, 'sum_errors':None}
    try:
        with open(path,'r',errors='replace') as f:
            for line in f:
                line=line.rstrip('\n')
                if line.endswith(' FOUND'):
                    r['found']=r.get('found',0)+1
                    # Keep the count exact but the list bounded: a badly
                    # misconfigured scan can report every file as infected.
                    if len(r['infected'])<500: r['infected'].append(line)
                elif line.endswith('ERROR') and ': ' in line:
                    r['errors']+=1
                    if len(r['err_sample'])<20: r['err_sample'].append(line)
                m=re.match(r'Infected files:\s*(\d+)',line)
                if m: r['sum_infected']=int(m.group(1)); r['have_summary']=True
                m=re.match(r'Total errors:\s*(\d+)',line)
                if m: r['sum_errors']=int(m.group(1))
    except OSError: pass
    if r['sum_errors'] is not None: r['errors']=max(r['errors'],r['sum_errors'])
    return r

# Work files carry this process's pid and a random tag. They used to be fixed
# names in STATE, which a second locsecd.py process -- `locsecctl scan-clamav`
# or `locsecctl scan`, neither of which can see the daemon's in-process
# JOB_LOCK -- would truncate and unlink underneath a scan the daemon was
# already running, losing or corrupting both sets of results.
_CLAMAV_RUN_TAG=f'{os.getpid()}-{uuid.uuid4().hex[:8]}'

_CLAMAV_WORKFILE_RE=re.compile(r'^clamav-(?:filelist|batch|out)-(\d+)-[0-9a-f]{8}(?:-\d+)?$')

def _clamav_sweep_stale():
    # A SIGKILL/OOM/power loss mid-scan leaves the file list and the current
    # batch behind (a list of every file under clamav_scan_paths is not small).
    # Nothing else ever removed them, so they accumulated one set per crash.
    # Only files whose owning process is gone are removed: a `locsecctl
    # scan-clamav` started before this daemon must not have its work files
    # deleted out from under it just because the daemon restarted.
    for f in list(STATE.glob('clamav-*.txt'))[:5000]:
        try:
            if not f.is_file() or f.is_symlink(): continue
            m=_CLAMAV_WORKFILE_RE.match(f.stem)
            if m and (Path('/proc')/m.group(1)).exists(): continue   # owner still running
            f.unlink()
        except OSError: pass

def _clamav_run_batch(mode, files, idx, timeout):
    bf=STATE/f'clamav-batch-{_CLAMAV_RUN_TAG}-{idx}.txt'; of=STATE/f'clamav-out-{_CLAMAV_RUN_TAG}-{idx}.txt'
    try:
        with open(bf,'w',encoding='utf-8',errors='surrogateescape') as f:
            os.chmod(bf,0o600); f.write('\n'.join(files)+'\n')
        if mode=='fdpass': cmd=['clamdscan','--infected','--fdpass',f'--file-list={bf}']
        elif mode=='stream': cmd=['clamdscan','--infected','--stream',f'--file-list={bf}']
        else: cmd=['clamscan','--infected',f'--file-list={bf}']
        rc,out=_run_transient(cmd,timeout,prefix='locsecd-clamav',props=_scan_props('idle'),save_to=str(of))
        res=_clamav_parse_output(of); res['rc']=rc; res['tail']=out[-2000:]
        return res
    finally:
        for x in (bf,of):
            try: x.unlink()
            except OSError: pass

def _clamd_active():
    if not have('systemctl'): return False
    rc,_=run(['systemctl','is-active','--quiet','clamav-daemon.service'],15)
    if rc==0: return True
    run(['systemctl','start','clamav-daemon.service'],120)
    rc,_=run(['systemctl','is-active','--quiet','clamav-daemon.service'],15)
    return rc==0

def _scan_clamav():
    paths=[p for p in CFG.get('clamav_scan_paths',['/home']) if os.path.isdir(p)]
    if not paths:
        return {'name':'ClamAV','status':'error','rc':2,'output':'None of the configured clamav_scan_paths exist: '+', '.join(CFG.get('clamav_scan_paths',[]))}
    # Methods, best first. clamdscan --fdpass hands clamd open file descriptors, so clamd never needs
    # permission to read the user's files (eCryptfs homes included). That only works if the caller
    # is in the host mount namespace -- which is why the scan runs in its own transient unit and
    # not inside locsecd.service's private one (under AppArmor, a descriptor from another mount
    # namespace has no resolvable path: "Failed name lookup - disconnected path", and clamd then
    # reports every file as "Not a regular file ERROR"). If that still fails systemically we
    # fall back to streaming the content, then to standalone clamscan.
    modes=[]
    if have('clamdscan') and _clamd_active(): modes+=['fdpass','stream']
    if have('clamscan'): modes.append('clamscan')
    if not modes: return None
    max_mb=int(CFG.get('clamav_max_file_mb',100))
    max_bytes=max_mb*1024*1024
    listfile=STATE/f'clamav-filelist-{_CLAMAV_RUN_TAG}.txt'
    started=time.time(); deadline=started+int(CFG.get('clamav_timeout',7200))
    try:
        st=_clamav_build_list(paths,listfile,max_bytes)
    except Exception as e:
        return {'name':'ClamAV','status':'error','rc':2,'output':f'could not build the scan file list: {e}'}
    batch_size=int(CFG.get('clamav_batch_size',20000))
    mi=0; notes=[]; infected=[]; infected_total=0; errors=0; err_sample=[]; scanned=0; timed_out=False; idx=0
    stream_max=None
    try:
        with open(listfile,'r',encoding='utf-8',errors='surrogateescape') as lf:
            while not STOP_EVENT.is_set():
                batch=[]
                for line in lf:
                    line=line.rstrip('\n')
                    if line: batch.append(line)
                    if len(batch)>=batch_size: break
                if not batch: break
                # Files can vanish between listing and scanning (editor saves, caches); drop those
                # up front so they are not counted as scan errors.
                live=[x for x in batch if os.path.exists(x)]
                if not live: continue
                while True:
                    now=time.time()
                    if now>=deadline: timed_out=True; break
                    mode=modes[mi]
                    files=live
                    if mode=='stream':
                        # clamd refuses streams larger than StreamMaxLength; those would be errors, not scans.
                        if stream_max is None:
                            stream_max=_size_to_bytes(_clamd_conf_value('StreamMaxLength','25M'),25*1024*1024)
                        files=[]
                        for x in live:
                            try:
                                if os.stat(x).st_size<=stream_max: files.append(x)
                            except OSError: pass
                        # Every file in this batch is over StreamMaxLength. Sent as an
                        # empty list, clamdscan printed no summary, which read as a
                        # systemic failure and dropped the rest of the scan to clamscan.
                        if not files:
                            notes.append(f'{len(live)} file(s) in one batch are larger than clamd\'s StreamMaxLength and were skipped in stream mode.')
                            break
                    idx+=1
                    res=_clamav_run_batch(mode,files,idx,int(min(3600,max(60,deadline-now))))
                    n=len(files)
                    systemic=(not res['have_summary']) or res['errors']>=max(1,min(50,n//2))
                    if systemic and not res['infected'] and mi+1<len(modes):
                        notes.append(f'{mode} failed systemically on a batch of {n} file(s) (rc={res["rc"]}, {res["errors"]} error(s)); switching to {modes[mi+1]}.')
                        log(f'ClamAV {mode} failed systemically (rc={res["rc"]}, errors={res["errors"]}/{n}); falling back to {modes[mi+1]}','WARN')
                        mi+=1; continue
                    infected=(infected+res['infected'])[:500]; infected_total+=res.get('found',len(res['infected'])); errors+=res['errors']
                    err_sample=(err_sample+res['err_sample'])[:20]
                    scanned+=max(0,n-res['errors'])
                    break
                if timed_out: break
    finally:
        try: listfile.unlink()
        except OSError: pass
    secs=int(time.time()-started)
    mode=modes[mi]
    desc={'fdpass':'clamdscan --fdpass (clamd daemon)','stream':'clamdscan --stream (clamd daemon)','clamscan':'clamscan (standalone engine)'}[mode]
    tol=max(10,int(scanned*0.001))
    if infected_total: status='findings-or-error'; rc=1
    elif STOP_EVENT.is_set(): status='interrupted'; rc=130
    elif timed_out: status='timeout'; rc=124
    elif errors>tol: status='warning'; rc=2
    elif errors>0: status='info'; rc=0
    else: status='ok'; rc=0
    lines=[f'ClamAV scan of: {", ".join(paths)}',
           f'Method: {desc}',
           f'Files listed: {st["listed"]}  (skipped: {st["too_big"]} larger than {max_mb} MB, {st["special"]} special files, {st["unreadable_dirs"]} unreadable directories)',
           f'Files scanned: {scanned}',
           f'Infected files: {infected_total}',
           f'Errors: {errors}',
           f'Time: {secs}s']
    if timed_out: lines.append(f'The scan hit clamav_timeout ({int(CFG.get("clamav_timeout",7200))}s) and was stopped; results above are partial.')
    if errors and status=='info': lines.append('A handful of errors is normal on a live system (files that changed or vanished mid-scan).')
    lines+=notes
    if infected:
        lines+=['','INFECTED:']+infected[:100]
        if infected_total>len(infected[:100]): lines.append(f'... and {infected_total-len(infected[:100])} more (see the report file).')
    if err_sample: lines+=['','Error sample (first 20):']+err_sample
    log(f'ClamAV scan completed status={status} scanned={scanned} infected={infected_total} errors={errors} method={mode} time={secs}s')
    r={'name':'ClamAV daemon' if mode!='clamscan' else 'ClamAV','status':status,'rc':rc,'output':'\n'.join(lines),'infected':infected_total,'errors':errors,'scanned':scanned}
    _clamav_incident(r); return r

def _clamd_conf_value(key,default=None):
    try:
        for line in Path('/etc/clamav/clamd.conf').read_text(errors='replace').splitlines():
            parts=line.split(None,1)
            if len(parts)==2 and parts[0]==key: return parts[1].strip()
    except OSError: pass
    return default

def _size_to_bytes(text,default):
    m=re.fullmatch(r'(\d+)\s*([KkMmGg]?)',str(text or '').strip())
    if not m: return default
    return int(m.group(1))*{'':1,'k':1024,'m':1024**2,'g':1024**3}[m.group(2).lower()]

def _scan_ports_fw():
    results=[]
    # These are inventories, not scans with a pass/fail verdict: label them informational instead
    # of "clean".
    if have('ss'):
        r=scan_tool('Listening ports',['ss','-lntup'],120); r['status']='info' if r.get('rc')==0 else 'error'; results.append(r)
    if have('ufw'):
        r=scan_tool('UFW status',['ufw','status','numbered'],120); r['status']='info' if r.get('rc')==0 else 'error'; results.append(r)
    return results or None

# Individual scan jobs the background loop runs one at a time, staggered by
# scan_stagger_seconds so a week's worth of scanning doesn't all land on the
# CPU/disk at once. Each still runs once every scan_interval (default:
# weekly), just offset from the others. The manual "Full scan" button in the
# GUI bypasses this and runs everything immediately via heavy_scan() below.
# ClamAV is intentionally not in this list -- see CLAMAV_JOB below, which
# runs on its own daily clamav_scan_interval instead of the weekly one.
SCAN_JOBS=[('aide',_scan_aide),('lynis',_scan_lynis),('debsecan',_scan_debsecan),
           ('rkhunter',_scan_rkhunter),('ports_fw',_scan_ports_fw)]
CLAMAV_JOB=('clamav',_scan_clamav)
_JOB_LABEL={'aide':'AIDE','lynis':'Lynis','debsecan':'Debsecan','rkhunter':'rkhunter','ports_fw':'Ports/firewall','clamav':'ClamAV','cve':'CVE'}

def _mark_job_run(*keys):
    try:
        with LOCK:
            try: runs=json.loads(JOBRUNS.read_text())
            except Exception: runs={}
            if not isinstance(runs,dict): runs={}
            for k in keys: runs[str(k)]=time.time()
            atomic_json(JOBRUNS,runs)
    except Exception as e: log(f'could not record the job run time: {e}','ERROR')

def _job_runs():
    try:
        runs=json.loads(JOBRUNS.read_text())
        return {str(k):float(v) for k,v in runs.items()} if isinstance(runs,dict) else {}
    except Exception: return {}

def _job_busy(result):
    rs=result if isinstance(result,list) else [result]
    return bool(rs) and all(isinstance(r,dict) and r.get('status')=='busy' for r in rs)

def run_scan_job(key,fn):
    result=fn()
    # Stopped part-way (service stop/restart, package upgrade): no report, and not
    # marked as run, so it is due again as soon as LocSec is back.
    if STOP_EVENT.is_set():
        log(f'scan job "{key}" interrupted by shutdown; it will run again','WARN')
        return {'interrupted':True}
    if result is not None and _job_busy(result):
        log(f'scan job "{key}" skipped: {(result if isinstance(result,dict) else result[0]).get("output","busy")[:200]}','INFO')
        return {'busy':True,'results':result if isinstance(result,list) else [result]}
    _mark_job_run(key)
    if result is None: return None
    results=result if isinstance(result,list) else [result]
    report=REPORTS/f'scan-{key}-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'
    atomic_json(report,{'ts':time.time(),'job':key,'results':results})
    log(f'staggered scan job "{key}" completed, report={report}')
    return {'report':str(report),'results':results}

def heavy_scan():
    # Manual/on-demand full scan: run every tool immediately, ignoring the
    # weekly/daily stagger schedules used by the background loop.
    results=[]
    for _,fn in SCAN_JOBS+[CLAMAV_JOB]:
        r=fn()
        if STOP_EVENT.is_set():
            log('full scan interrupted by shutdown; no report written','WARN')
            return {'interrupted':True,'results':results}
        if r is None: continue
        results.extend(r if isinstance(r,list) else [r])
    _mark_job_run(*[k for k,_ in SCAN_JOBS+[CLAMAV_JOB]])
    report=REPORTS/f'report-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'; atomic_json(report,{'ts':time.time(),'results':results})
    log(f'heavy scan report written {report}')
    return {'report':str(report),'results':results}


def idle_enough():
    try: load=float(Path('/proc/loadavg').read_text().split()[0])
    except Exception: return False
    return load <= float(CFG.get('idle_load',1.0))


def cve_scan():
    # Known vulnerabilities in installed packages, from the distribution's own
    # data: debsecan (Debian and LMDE, against the Debian security tracker) and
    # the security updates APT has pending. Trivy was removed in 4.0.11-62: it
    # needed a third-party APT repository that apt trusted as root.
    out=[]
    if have('debsecan') and IS_DEBIAN_NATIVE: out.append(_debsecan_result('Debian CVE scan'))
    elif have('debsecan'): out.append({'name':'Debian CVE scan','status':'skipped','output':'skipped on Ubuntu/Mint: the Debian vulnerability feed does not match Ubuntu package versions; the APT security candidates below cover this system'})
    if have('apt-get'):
        rc,ss=run_privileged(['apt-get','-s','upgrade'],180); out.append({'name':'APT security candidates','rc':rc,'output':ss[-20000:]})
    if STOP_EVENT.is_set():
        log('CVE scan interrupted by shutdown; no report written','WARN')
        return {'interrupted':True,'results':out}
    _mark_job_run('cve')
    report=REPORTS/f'cve-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'; atomic_json(report,{'ts':time.time(),'results':out})
    return {'report':str(report),'results':out}

# Units LocSec coordinates. These stay on the Services list even when they are
# not running: the list is otherwise "currently running", so stopping one made
# it disappear from the page (and from the Overview card) with no way to start
# it again except by typing its name into the manual box.
_MANAGED_UNITS_BASE=('locsecd.service','ufw.service','clamav-daemon.service',
                      'clamav-freshclam.service','rsyslog.service')

def _managed_units():
    return _MANAGED_UNITS_BASE

def _unit_states(units):
    """ActiveState/SubState/LoadState/Description for several units in one call."""
    out_map={}
    if not units or not have('systemctl'): return out_map
    rc,out=run(['systemctl','show','--no-pager','-p','Id','-p','LoadState','-p','ActiveState',
                '-p','SubState','-p','UnitFileState','-p','Description','--']+list(units),30)
    if rc!=0: return out_map
    cur={}
    for line in out.splitlines():
        if not line.strip():
            if cur.get('Id'): out_map[cur['Id']]=cur
            cur={}; continue
        k,_,v=line.partition('=')
        cur[k.strip()]=v.strip()
    if cur.get('Id'): out_map[cur['Id']]=cur
    return out_map

# systemd reports two orthogonal things: ActiveState (is the unit up?) and
# SubState (what is the process doing?). A Type=oneshot unit with
# RemainAfterExit=yes -- ufw.service is exactly that -- sits at
# ActiveState=active / SubState=exited for its whole working life. Showing the
# SubState verbatim made a correctly running firewall read as "exited" on the
# Services page and in the Overview card, which is alarming and wrong. Show a
# state derived from ActiveState, and only fall back to the SubState when it
# genuinely adds something.
_SETTLED_SUBSTATES={'exited','mounted','plugged','listening','waiting','active'}

def _display_state(active,sub):
    a=str(active or '').strip(); b=str(sub or '').strip()
    if a=='active':
        if b=='running': return 'running'
        if b in _SETTLED_SUBSTATES or not b: return 'active'
        return b
    if a=='inactive': return 'stopped'
    if a in ('failed','activating','deactivating','reloading'): return a
    return a or 'unknown'

_TRANSITIONAL=('activating','deactivating','reloading','refreshing')

def _settle_unit_state(unit,tries=6,delay=0.5):
    # systemctl returns when the job is enqueued and run, but a unit that is
    # D-Bus- or socket-activated (bluetooth.service is both on a desktop) can
    # be pulled straight back up by whatever wanted it, and a unit with a slow
    # ExecStart can still read as "activating" the instant the job completes.
    # Sampling once produced "stop ... ok (running -> activating)": a stop that
    # had already been undone, reported as a success. Wait for the unit to
    # settle out of a transitional state before judging the outcome.
    st=_unit_state_one(unit)
    for _ in range(max(0,tries)):
        if st['active'] not in _TRANSITIONAL: return st
        time.sleep(delay)
        st=_unit_state_one(unit)
    return st

def _unit_state_one(unit):
    st=_unit_states([unit]).get(unit,{})
    a=str(st.get('ActiveState','')); b=str(st.get('SubState',''))
    return {'active':a,'sub':b,'load':str(st.get('LoadState','')),
            'file':str(st.get('UnitFileState','')),
            'running':a=='active','state':_display_state(a,b)}

# Units the operator has acted on from the dashboard. 4.0.11-31 made
# LocSec-managed units stay listed when stopped, but every other unit still
# vanished the moment it left the running list -- stop bluetooth.service and
# the row disappeared, leaving no way to start it again except typing the name
# into the manual box. Anything acted on here stays listed whatever its state.
_SVCWATCH_MAX=60

def _watched_units():
    return list(_load_seen(SVCWATCH,_SVCWATCH_MAX))

def _watch_unit(unit):
    try:
        seen=_load_seen(SVCWATCH,_SVCWATCH_MAX)
        seen.pop(unit,None)          # re-insert so it counts as most recent
        seen[unit]=None
        _remember_seen(SVCWATCH,seen,_SVCWATCH_MAX)
    except Exception:
        pass

def _unwatch_units(units):
    # Drop units from the watch list. Used both by the Forget button and
    # automatically once a watched unit is running again: at that point it
    # appears in the ordinary running list on its own, so keeping a watch on
    # it only makes the row outlive its purpose.
    units=set(units)
    if not units: return False
    try:
        seen=_load_seen(SVCWATCH,_SVCWATCH_MAX)
        if not units & set(seen): return False
        for u in units: seen.pop(u,None)
        _remember_seen(SVCWATCH,seen,_SVCWATCH_MAX)
        return True
    except Exception:
        return False

def service_forget(unit):
    unit=_normalize_unit(unit)
    if not unit: return {'ok':False,'error':'enter a unit name'}
    if not _unwatch_units([unit]):
        return {'ok':False,'error':f'{unit} was not on the list'}
    log(f'stopped tracking {unit} on the Services page')
    return {'ok':True,'unit':unit,'output':f'{unit} removed from the Services page. '
            f'It will be listed again whenever it is running, or if you act on it from here.'}

def service_list():
    if not have('systemctl'):
        return []
    managed=_managed_units()
    rc,out=run(['systemctl','list-units','--type=service','--state=running','--no-legend','--no-pager'],30)
    if rc!=0:
        return []
    items=[]; seen=set()
    for line in out.splitlines():
        parts=line.split(None,4)
        if len(parts)>=5:
            unit=parts[0]; seen.add(unit)
            items.append({'unit':unit,'load':parts[1],'active':parts[2],'sub':parts[3],
                          'state':_display_state(parts[2],parts[3]),
                          'description':parts[4][:500],'running':parts[2]=='active',
                          'managed':unit in managed,'protected':unit in _PROTECTED_UNITS})
    watched=[u for u in _watched_units() if u not in managed]
    # A watched unit that is running again is in the list above on its own
    # merit, so stop tracking it -- otherwise a row you asked for once stayed
    # until 60 other units pushed it off the end.
    back_up=[u for u in watched if u in seen]
    if back_up:
        _unwatch_units(back_up)
        watched=[u for u in watched if u not in back_up]
    extra=list(managed)+watched
    missing=[u for u in extra if u not in seen]
    for unit,st in _unit_states(missing).items():
        if str(st.get('LoadState',''))=='not-found': continue   # package not installed here
        items.append({'unit':unit,'load':st.get('LoadState',''),'active':st.get('ActiveState',''),
                      'sub':st.get('SubState',''),
                      'state':('masked' if str(st.get('LoadState',''))=='masked' and st.get('ActiveState')!='active'
                               else _display_state(st.get('ActiveState',''),st.get('SubState',''))),
                      'description':str(st.get('Description',''))[:500],
                      'running':st.get('ActiveState')=='active',
                      'managed':unit in managed,
                      'watched':unit not in managed,
                      'protected':unit in _PROTECTED_UNITS})
    # Managed units first, then anything stopped that the operator acted on --
    # a unit you just stopped is the one you are most likely to want back, so
    # it should not be buried alphabetically among the running ones.
    items.sort(key=lambda x:(not x['managed'],
                             not x.get('watched'),
                             x['unit']))
    return items[:500]

_FEEDS_CACHE={'key':None,'data':{}}
_FEEDS_LOCK=threading.Lock()

def _feeds():
    """The parsed feeds.json, re-read only when the file changes."""
    try: st=FEEDS.stat(); key=(st.st_mtime_ns,st.st_size)
    except OSError: return {}
    with _FEEDS_LOCK:
        if _FEEDS_CACHE['key']!=key:
            try: d=json.loads(FEEDS.read_text())
            except Exception: d={}
            _FEEDS_CACHE.update(key=key,data=d if isinstance(d,dict) else {})
        return _FEEDS_CACHE['data']

def reputation_check(indicator):
    raw=str(indicator or '').strip()[:512]
    if not raw:
        return {'ok':False,'error':'indicator required'}
    host=raw
    try:
        if '://' in raw:
            host=urllib.parse.urlparse(raw).hostname or ''
        elif '/' in raw and not safe_network(raw):
            host=raw.split('/',1)[0]
        host=host.strip().lower().rstrip('.')
    except Exception:
        host=''
    feeds=_feeds()
    matches=[]
    addr=safe_ip(host)
    if addr:
        for item in feeds.get('ips',[])+feeds.get('networks',[]):
            n=safe_network(item)
            if n and addr in n: matches.append(item)
    else:
        for d in feeds.get('domains',[]):
            d=str(d).lower().rstrip('.')
            if host==d or host.endswith('.'+d): matches.append(d)
    return {'ok':True,'indicator':raw,'normalized':host,'malicious':bool(matches),'matches':sorted(set(matches))[:100], 'feed_updated':feeds.get('updated')}

# How much serialized JSON the dashboard will render inline. dashboard_report_max_mb
# is the safety cap on reading a report at all; this is the much smaller amount a
# browser can actually lay out. A 32 MiB report pushed through
# JSON.stringify + innerHTML is what used to freeze the window on "View".
_DASHBOARD_INLINE_MAX=1500000

def _display_report(n,path,size,data):
    """Return something the dashboard can render without locking up the browser."""
    if size>_DASHBOARD_INLINE_MAX:
        # Read a bounded slice of the file rather than re-serialising the parsed
        # object: json.dumps(indent=2) of a 90 MiB report allocates another
        # ~150 MiB on top of the parsed structure, all to throw it away.
        try:
            with open(path,'r',errors='replace') as f: head=f.read(_DASHBOARD_INLINE_MAX)
        except OSError as e:
            head=f'(could not read the report: {e})'
        return {'ts':path.stat().st_mtime,'results':[{'name':n,'status':'info',
                'output':(f'This report is {size/1048576:.1f} MiB -- too large to display in full.\n'
                          f'First {_DASHBOARD_INLINE_MAX//1024} KiB of the file:\n\n')+head
                          +f'\n\n... truncated for display. Full document: {path}'}]},True
    return data,False

def read_report(name):
    n=Path(str(name)).name
    if n!=str(name) or not n.endswith('.json'):
        return {'ok':False,'error':'invalid report name'}
    path=(REPORTS/n).resolve()
    try: path.relative_to(REPORTS.resolve())
    except ValueError: return {'ok':False,'error':'invalid report path'}
    if not path.is_file(): return {'ok':False,'error':'report not found'}
    try:
        size=path.stat().st_size
        limit=int(CFG.get('dashboard_report_max_mb',100))*1024*1024
        if size > limit:
            return {'ok':False,'error':f'report is {size/1048576:.1f} MiB and exceeds the {limit/1048576:.0f} MiB dashboard display limit; use the report file directly or delete it.'}
        if size>_DASHBOARD_INLINE_MAX: data=None     # shown as its beginning; parsing it all is wasted
        else:
            with open(path,'r',errors='replace') as rf: data=json.load(rf)
        report,summarized=_display_report(n,path,size,data)
        if not summarized: report=_explain_report(report)
        return {'ok':True,'name':n,'bytes':size,'summarized':summarized,'report':report}
    except (OSError,ValueError,json.JSONDecodeError) as e:
        return {'ok':False,'error':f'cannot read report safely: {e}'}
    except MemoryError:
        return {'ok':False,'error':'report is too large to load into memory; open the file on disk instead'}

def delete_report(name):
    n=Path(str(name)).name
    if n!=str(name) or not n.endswith('.json'):
        return {'ok':False,'error':'invalid report name'}
    path=(REPORTS/n).resolve()
    try: path.relative_to(REPORTS.resolve())
    except ValueError: return {'ok':False,'error':'invalid report path'}
    if not path.is_file(): return {'ok':False,'error':'report not found'}
    path.unlink(); log(f'deleted report {n}'); return {'ok':True}

# Units that must never be stopped/disabled/restarted from the dashboard: doing
# so either cuts off the operator's own access to the box (ssh/networking) or
# disables the security monitoring this daemon exists to provide (locsecd
# itself, and the login-session/system bus other units depend on). 'start' and
# 'enable' are still allowed on any of these -- only the disruptive actions
# are blocked.
# Stopping, restarting or disabling any of these cuts off your own access to the
# machine or to the desktop session the dashboard is displayed in. 'start' and
# 'enable' stay allowed on all of them.
_PROTECTED_UNITS={'locsecd.service','ssh.service','sshd.service','systemd-logind.service',
                   'dbus.service','networking.service','NetworkManager.service','systemd-journald.service',
                   'systemd-udevd.service','systemd-networkd.service',
                   # A desktop session dies with its display manager, taking the
                   # dashboard window with it; polkit is how the GUI reads the token.
                   'display-manager.service','lightdm.service','gdm.service','gdm3.service',
                   'sddm.service','polkit.service','polkitd.service'}
_DISRUPTIVE_ACTIONS={'stop','restart','disable'}

def _normalize_unit(unit):
    # The manual-control box is typed into by hand, so it gets what a person
    # would type: "bluetooth", a pasted name with a stray space, or the full
    # "bluetooth.service". Only the last of those used to be accepted; the
    # other two came back as "invalid unit name", which reads as a rejection
    # of the service rather than of the spelling. Normalise first, and keep
    # the regex as the actual guard.
    u=str(unit or '').strip().strip('\'"')
    if not u: return ''
    # A name beginning with '-' is not a unit, it is an option: `systemctl stop
    # -h.service` prints the help text and exits 0, which this code then reported
    # as a successful stop. Refuse it here rather than hand it to systemctl.
    if u.startswith('-'): return ''
    if not u.endswith('.service'):
        # Only add the suffix when there isn't some other unit type already.
        if '.' not in u.rsplit('/',1)[-1] or u.rsplit('.',1)[-1] not in (
                'socket','timer','target','mount','path','slice','scope','device','swap','automount'):
            u=u.split('.')[0]+'.service' if '.' not in u else u
    return u

def service_action(unit,action):
    if not have('systemctl'): return {'ok':False,'error':'systemctl not installed'}
    raw=str(unit or '').strip()
    unit=_normalize_unit(unit)
    if not unit: return {'ok':False,'error':'enter a unit name'}
    if not re.fullmatch(r'[A-Za-z0-9_.@-]{1,128}\.service',unit):
        return {'ok':False,'error':f'"{raw}" is not a valid service unit name. This page controls .service units only.'}
    if action not in ('start','stop','restart','enable','disable'): return {'ok':False,'error':'invalid action'}
    # Previously every unit outside a five-entry allowlist was refused, while the
    # Services page drew Stop/Restart buttons for every running unit -- so almost
    # every button on that page failed with "restricted to supported LocSec-managed
    # services". The dashboard already requires the root-only API token, so the
    # meaningful limit is the protected set below, not an arbitrary allowlist.
    # An alias (dbus-org.freedesktop.login1.service is systemd-logind) must not
    # get round the protected list: compare the unit systemd resolves it to.
    rc_id,canon=run(['systemctl','show','-p','Id','--value','--',unit],10)
    canon=canon.strip() if rc_id==0 else ''
    if (unit in _PROTECTED_UNITS or canon in _PROTECTED_UNITS) and action in _DISRUPTIVE_ACTIONS:
        incident('service-action','manual',unit,'medium','blocked',f'refused {action}: protected unit')
        return {'ok':False,'error':f'{unit} is protected; {action} is blocked to avoid locking you out or disabling security monitoring'}
    # NOTE: unit=='locsecd.service' and action in ('restart','stop') means this
    # call tells systemd to stop the very process handling this request. This
    # subprocess still returns (systemd-run/systemctl itself isn't killed until
    # the daemon's own process has exited and, for restart, been replaced), but
    # this process may be torn down before the response below is ever written
    # to the socket -- the caller should expect a dropped connection rather
    # than a JSON body in that case, not treat it as a crash.
    before=_unit_state_one(unit)
    if before.get('load')=='not-found':
        return {'ok':False,'unit':unit,'action':action,
                'error':f'{unit} is not installed on this system (systemd reports it as not-found)'}
    _watch_unit(unit)
    # A plain systemctl call. 4.0.11-37 added a retry in a transient unit here,
    # on the theory that this daemon's trimmed CapabilityBoundingSet could make
    # PID 1 refuse a control request. Testing on a real system showed control
    # actions work directly and that the retry never fired -- the original
    # "stop and restart do nothing" was entirely a reporting problem, fixed in
    # -37 and -38. Removed in -40 rather than left in as dead speculation.
    t0=int(time.time())-1
    rc,out=run(['systemctl',action,'--',unit],30)
    # The Overview card and the tool table come from a 30s cache; without this a
    # service you just stopped or started keeps its old state there for half a
    # minute, which reads as the action having done nothing.
    _slow_status_cache['ts']=0.0
    after=_settle_unit_state(unit) if action in ('start','stop','restart') else _unit_state_one(unit)
    # systemctl exiting 0 is not by itself proof the unit did what was asked:
    # confirm against the state systemd reports afterwards, so a silent no-op
    # is reported as a failure here instead of looking like success on a page
    # that then redraws unchanged.
    ok=rc==0
    note=''
    if ok and action in ('start','restart'):
        if after['active'] in _TRANSITIONAL:
            note=f'{unit} is still {after["state"]}; it is taking longer than expected to come up. Check systemctl status {unit}.'
        elif not after['running']:
            ok=False
            note=f'systemctl reported success but {unit} is {after["state"]}.'
            if after.get('file')=='masked':
                note=(f'{unit} is masked, so it cannot start. Unmask it first: '
                      f'sudo systemctl unmask {unit}')
    elif ok and action in ('enable','disable'):
        # ActiveState does not move on enable/disable, so reporting it as the
        # before/after was meaningless here ("running -> running"). The unit
        # file state is what these two actually change.
        fs=after.get('file','')
        if action=='enable' and fs in ('disabled','masked'):
            ok=False; note=f'systemctl reported success but {unit} is {fs}.'
        elif action=='disable' and fs.startswith('enabled'):
            ok=False; note=f'systemctl reported success but {unit} is still {fs}.'
    elif ok and action=='stop':
        # "activating" here is not a partial success -- it means the unit is on
        # its way back up. Judging on ActiveState=='active' alone reported that
        # as a clean stop, which is what "stop bluetooth.service: ok (running
        # -> activating)" was.
        if after['active'] in ('active','activating','reloading','refreshing'):
            ok=False
            note=(f'{unit} is {after["state"]} again -- the stop was undone immediately. '
                  f'Something on the system pulled it back up: D-Bus or socket activation, another '
                  f'unit that Requires= it, or Restart= in its own unit file. '
                  f'Check with: systemctl list-dependencies --reverse {unit}  and  systemctl cat {unit}. '
                  f'A unit like this cannot be held down by stopping it; mask it instead if you really want it off.')
    # A masked unit makes systemctl start/restart/enable exit non-zero, so the
    # masked note above (success branch only) never fired for the real case and
    # the incident read just "rc=1 stopped->stopped". Say so whatever rc was.
    masked=action in ('start','restart','enable') and 'masked' in (after.get('file'),before.get('file'))
    if masked and not note:
        ok=False
        note=(f'{unit} is masked, so it cannot be {"enabled" if action=="enable" else action+"ed"}. Masking is set outside LocSec '
              f'(LocSec never masks units). Unmask it first: sudo systemctl unmask {unit}')
    detail=(out or '').strip()
    if not detail and ok:
        if action in ('enable','disable'):
            detail=f'{unit}: {before.get("file") or "unknown"} -> {after.get("file") or "unknown"}'
        else:
            detail=f'{unit}: {before["state"]} -> {after["state"]}'
    if note: detail=(note+'\n'+detail).strip()
    # On failure, systemctl's own output is only "Job for X failed... see
    # journalctl -xeu X", which told the user nothing (the incident read just
    # "rc=1 stopped->stopped"). Attach the unit's journal from this attempt so
    # the reason -- bad config, port already bound, missing binary -- is in the
    # incident itself.
    why=''
    if not ok and action in ('start','stop','restart') and have('journalctl'):
        jrc,jout=run(['journalctl','--no-pager','-q','-o','short-iso','-u',unit,'--since',f'@{t0}','-n','20'],15)
        if jrc!=0 or not jout.strip():
            jrc,jout=run(['journalctl','--no-pager','-q','-o','short-iso','-u',unit,'-b','-n','20'],15)
        jout=(jout or '').strip() if jrc==0 else ''
        if jout:
            detail=(detail+'\n--- journalctl -u '+unit+' ---\n'+jout).strip()
            # Prefer the unit's own last message over systemd's generic
            # "Failed with result 'exit-code'" trailer.
            jl=jout.splitlines()
            own=[l for l in jl if ' systemd[1]: ' not in l]
            why=(own or jl)[-1][-300:]
    incident('service-action','manual',unit,'low','success' if ok else 'failed',f'{action}: {detail[-1990:] if len(detail)>1990 else detail}')
    log(f'systemctl {action} {unit}: rc={rc} {before["state"]}->{after["state"]}'+(f' last journal line: {why}' if why else ''),'INFO' if ok else 'WARN')
    if action in ('enable','disable'):
        b_state,a_state=before.get('file') or 'unknown',after.get('file') or 'unknown'
    else:
        b_state,a_state=before['state'],after['state']
    return {'ok':ok,'rc':rc,'unit':unit,'action':action,
            'before':b_state,'after':a_state,'file':after.get('file',''),
            'output':detail}

_SLOW_STATUS_TTL=30
_slow_status_cache={'ts':0.0,'data':None}
_STATUS_TOOLS=['ufw','aide','lynis','debsecan','rkhunter','clamscan','clamdscan','tshark','tcpdump','ss','nft']

def slow_status_parts():
    # Tool presence, firewall state and the running-service list are all
    # expensive (many subprocess spawns) and change rarely, so they are
    # recomputed at most once per _SLOW_STATUS_TTL seconds instead of on every
    # /api/status call.
    now=time.time()
    cached=_slow_status_cache['data']
    if cached is not None and (now-_slow_status_cache['ts'])<_SLOW_STATUS_TTL:
        return cached
    data={
        'tools':{x:have(x) for x in _STATUS_TOOLS},
        'firewall_active':firewall_active(),
        'services':service_list(),
        'missing':missing_components(),
        'exposure':_exposure(),
    }
    _slow_status_cache['ts']=now
    _slow_status_cache['data']=data
    return data

def _exposure():
    """Configuration a remote attacker would look at first, with the fix for each."""
    items=[]
    def add(level,item,detail,fix=''):
        items.append({'level':level,'item':item,'detail':detail,'fix':fix})
    if have('ufw'):
        rc,out=ufw(['status','verbose'])
        if rc==0 and re.search(r'^Status:\s+active',out,re.M):
            m=re.search(r'Default:\s*(\w+)\s*\(incoming\)',out)
            pol=m.group(1).lower() if m else 'unknown'
            if pol in ('deny','reject'): add('ok','Firewall',f'UFW is active; unsolicited incoming traffic is {"denied" if pol=="deny" else "rejected"} by default.')
            else: add('warn','Firewall',f'UFW is active but the default incoming policy is "{pol}", so anything listening is reachable.','sudo ufw default deny incoming')
        elif _FALLBACK.get('on'):
            add('warn','Firewall',f'UFW is not enabled. LocSec\'s fallback firewall is dropping unsolicited incoming traffic (still allowed: {_fallback_allowed_text(_fallback_ssh_ports())}). Port-scan detection keeps working through it.',
                'sudo ufw enable  (run sudo ufw allow ssh first if you log in remotely); the fallback is removed automatically')
        else:
            add('warn','Firewall','UFW is not enabled: every listening service is reachable from the network.'+('' if CFG.get('fallback_firewall',True) else ' The LocSec fallback firewall is turned off in the response policy.'),'sudo ufw enable  (run sudo ufw allow ssh first if you log in remotely)')
    if have('ss'):
        rc,out=run(['ss','-Hlntup'],15)
        pub=[]
        if rc==0:
            for line in out.splitlines():
                parts=line.split()
                if len(parts)<5: continue
                local=parts[4]; proc=' '.join(parts[6:]) if len(parts)>6 else ''
                host=local.rsplit(':',1)[0].strip('[]').split('%')[0]
                a=safe_ip(host) if host not in ('*','0.0.0.0','::') else None
                if a is not None and a.is_loopback: continue
                name=(re.search(r'\(\("([^"]+)"',proc) or [None,'unknown'])[1]
                pub.append(f'{parts[0]} {local} ({name})')
        if pub:
            add('warn','Network-facing services',
                f'{len(pub)} socket(s) listen on a non-loopback address: '+'; '.join(pub[:12])+('; ...' if len(pub)>12 else ''),
                'Stop or uninstall any service you do not use; the firewall covers the rest while its incoming policy is deny.')
        else:
            add('ok','Network-facing services','Nothing listens on a network address; every service is local to this machine.')
    if have('sshd'):
        rc,out=run(['sshd','-T'],15)
        if rc==0:
            cfg={}
            for line in out.splitlines():
                k,_,v=line.partition(' ')
                cfg[k.lower()]=v.strip().lower()
            bad=[]
            if cfg.get('permitrootlogin') in ('yes',): bad.append('root may log in with a password')
            if cfg.get('passwordauthentication')=='yes': bad.append('password logins are allowed')
            if bad: add('warn','SSH server','OpenSSH is installed and '+' and '.join(bad)+'.',
                        'Use keys, then set PasswordAuthentication no and PermitRootLogin no in /etc/ssh/sshd_config.d/ and run sudo systemctl reload ssh. If you never log in remotely: sudo apt purge openssh-server')
            else: add('ok','SSH server','OpenSSH allows key logins only, and no password login for root.')
    if have('lsblk'):
        rc,out=run(['lsblk','-rno','TYPE'],10)
        if rc==0:
            if 'crypt' in out.split(): add('ok','Disk encryption','An encrypted (LUKS) volume is in use.')
            else: add('warn','Disk encryption','No encrypted volume found: anyone who takes the disk can read it.',
                      'Encryption is chosen at install time (Debian installer: Guided - use entire disk and set up encrypted LVM).')
    return items

def incidents_count():
    # Avoid re-reading and re-parsing up to 10000 JSON lines on every status call;
    # only recount when the incidents log has actually changed on disk.
    try:
        with LOCK:
            _inc_load(); return len(_INC['ids'])
    except Exception: return 0

_AUTH_SUMMARY_TTL=30
_auth_summary_cache={'ts':0.0,'data':None}

def auth_summary():
    # The Overview/Logins pages call /api/status on every page switch, and
    # parse_auth() shells out to journalctl for the whole auth_window each time
    # (seconds of work, a 30s timeout in the worst case). These two numbers are
    # display-only, so serve them from a short cache like slow_status_parts().
    # login_monitor() still calls parse_auth() directly on its own schedule --
    # detection, counting and automatic blocking never read this cache.
    now=time.time()
    data=_auth_summary_cache['data']
    if data is not None and (now-_auth_summary_cache['ts'])<_AUTH_SUMMARY_TTL:
        return data
    fails,success,_raw=parse_auth()
    data=(sum(fails.values()),len(success))
    _auth_summary_cache['ts']=now; _auth_summary_cache['data']=data
    return data

def status():
    slow=slow_status_parts()
    auth_failures,auth_successes=auth_summary()
    try: load=Path('/proc/loadavg').read_text().split()[:3]
    except Exception: load=[]
    return {'version':VERSION,'time':time.time(),'load':load,'idle':idle_enough(),'tools':slow['tools'],'blocks':len(load_blocks()),'auth_failures':auth_failures,'auth_successes':auth_successes,'firewall_active':slow['firewall_active'],'incidents':incidents_count(),'recent_incidents':recent_incidents(20),'services':slow['services'],'missing':slow['missing'],'exposure':slow.get('exposure',[])}

def health():
    # Cheap liveness endpoint for the 15s frontend ping: no subprocess spawns,
    # no log parsing. Just proves the daemon is alive and responsive.
    try: load=Path('/proc/loadavg').read_text().split()[:3]
    except Exception: load=[]
    return {'ok':True,'version':VERSION,'time':time.time(),'load':load}

def analyze_capture(name):
    n=Path(str(name)).name
    if n!=str(name) or not n.endswith('.pcapng'):
        return {'ok':False,'error':'invalid capture name'}
    path=(CAPTURES/n).resolve()
    try: path.relative_to(CAPTURES.resolve())
    except ValueError: return {'ok':False,'error':'invalid capture path'}
    if not path.is_file(): return {'ok':False,'error':'capture not found'}
    if not have('tshark'): return {'ok':False,'error':'tshark is not installed'}
    # Bounded protocol/endpoint summary; the capture itself is never executed or
    # modified. tshark's dissectors have a long history of parser CVEs and the
    # bytes in a capture came off the wire, so whoever sent the packets chose
    # them. Run it in a transient unit that cannot reach the network, cannot
    # touch devices or home directories, cannot gain privileges and is capped at
    # 512 MB, so a dissector bug lands somewhere with nothing worth reaching.
    props=['PrivateNetwork=yes','PrivateDevices=yes','ProtectHome=yes',
           'NoNewPrivileges=yes','MemoryMax=512M','LockPersonality=yes']
    rc,summary=_run_transient(['tshark','-r',str(path),'-q','-z','io,phs'],120,prefix='locsecd-tshark',props=props)
    rc2,endpoints=_run_transient(['tshark','-r',str(path),'-T','fields','-e','ip.src','-e','ip.dst','-e','tcp.dstport','-e','udp.dstport','-E','separator=|'],120,prefix='locsecd-tshark',props=props)
    return {'ok':rc==0 or rc2==0,'protocols':summary[-20000:],'endpoints':endpoints[-20000:],'rc':rc if rc!=0 else rc2}

def _terminate_capture(proc, wait=True):
    # wait=False is for the signal handler: ask the capture to stop, but do
    # not block waiting for it. See _shutdown_handler.
    if proc is None or proc.poll() is not None:
        return
    try: os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError: return
    except Exception: pass
    if not wait: return
    try: proc.wait(timeout=5)
    except Exception:
        try: os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        except Exception: pass
        try: proc.wait(timeout=5)
        except Exception: pass


STOP_EVENT=threading.Event()

def _shutdown_handler(signum, frame):
    # This runs on the main thread, interrupting whatever it was doing, and
    # every second spent here comes out of the unit's TimeoutStopSec=30 budget
    # before systemd sends SIGKILL. So it does the least possible: set the
    # stop flag and ask any capture to exit. It does NOT wait for them.
    #
    # It used to wait: _terminate_capture() blocks up to 5s for SIGTERM and
    # another 5s after SIGKILL, so three hung captures could burn the whole
    # 30s here. systemd would then SIGKILL us mid-handler and server()'s
    # cleanup would never run -- meaning the sibling transient units
    # (apt/aideinit/scan jobs) would be left running unsupervised, which is
    # the exact thing that cleanup exists to prevent. The waiting now happens
    # in server()'s finally, outside signal context, where it belongs.
    #
    # Not taking CAPTURE_LOCK is also deliberate: blocking on a lock another
    # thread already holds would deadlock the shutdown. Copying the list is
    # atomic enough, and anything started microseconds later is still reached
    # by the cgroup teardown and by server()'s own cleanup.
    STOP_EVENT.set()
    for proc in list(ACTIVE_CAPTURES):
        _terminate_capture(proc, wait=False)


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    request_queue_size=32
    max_workers=32

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._slots=threading.BoundedSemaphore(self.max_workers)

    def process_request(self,request,client_address):
        if not self._slots.acquire(blocking=False):
            try: request.close()
            except Exception: pass
            return
        try:
            super().process_request(request,client_address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self,request,client_address):
        try:
            super().process_request_thread(request,client_address)
        finally:
            self._slots.release()

class Handler(BaseHTTPRequestHandler):
    # A ThreadingHTTPServer spawns one thread per connection with no built-in
    # cap; a handful of slow/idle clients holding sockets open (Slowloris)
    # can pin threads indefinitely if this is ever exposed beyond loopback.
    # `timeout` makes socketserver abort a connection that goes quiet for
    # this long instead of waiting forever.
    timeout=30
    def handle_timeout(self):
        pass
    def log_message(self,*args): pass
    def auth(self):
        tok=token_value()
        header=self.headers.get('X-LocSec-Token','')
        if header and hmac.compare_digest(header.encode('utf-8','replace'),tok.encode()): return True
        for item in self.headers.get('Cookie','').split(';'):
            k,_,v=item.strip().partition('=')
            if k==COOKIE and v and session_ok(v): return True
        return False
    def sendj(self,obj,code=200):
        data=json.dumps(obj,default=str).encode()
        try:
            self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','no-referrer'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        except (BrokenPipeError,ConnectionError,OSError) as e:
            # The client went away (shell timeout, closed window, network blip) while a long job was
            # running. The job itself is unaffected and its report is on disk; one WARN line is enough.
            log(f'client disconnected before the response could be sent ({type(e).__name__}); the job result was not lost','WARN')
    def _host_ok(self):
        # A page elsewhere can point its own hostname at 127.0.0.1 (DNS
        # rebinding) and then talk to this port as if it were same-origin.
        # The token still stops it, but only requests addressed to this
        # machine by name are answered at all.
        host=(self.headers.get('Host') or '').strip().lower()
        return host in {f'127.0.0.1:{CFG["port"]}',f'localhost:{CFG["port"]}','127.0.0.1','localhost'}
    def do_GET(self):
        if not self._host_ok(): return self.sendj({'error':'unexpected Host header'},421)
        path=self.path.split('?',1)[0]
        self._code_ok=False
        if path=='/dashboard' and not self.auth():
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            if q.get('code',[''])[0]:
                self._code_ok=consume_login_code(q.get('code',[''])[0])
                if not self._code_ok: return self.sendj({'error':'unauthorized: login code expired or already used -- open LocSec again'},401)
            else: return self.sendj({'error':'unauthorized'},401)
        elif not self.auth(): return self.sendj({'error':'unauthorized'},401)
        if path=='/api/health': return self.sendj(health())
        if path=='/api/job':
            cur=JOB_LOCK.current()
            return self.sendj({'running':cur,'message':JOB_LOCK.busy_message() if cur else 'No maintenance job is running.',
                               'external':None if cur else external_aide(),'schedule':schedule_status()})
        if path=='/api/status': return self.sendj(status())
        if path=='/api/blocks': return self.sendj(load_blocks())
        if path=='/api/blocks/explained':
            rows=[explain_block(k,v) for k,v in load_blocks().items()]
            rows.sort(key=lambda r:-(float(r.get('added') or 0)))
            return self.sendj({'blocks':rows[:500],'total':len(rows)})
        if path=='/api/log-sources':
            avail=[]
            for key,src in LOG_SOURCES.items():
                p=next((p for p in _source_paths(key,src) if p.exists()),None)
                if p is None and _source_journal(src,1):
                    avail.append({'key':key,'label':src['label'],'available':True,'clearable':False,
                                  'path':f"systemd journal ({src.get('jlabel','')})"}); continue
                regular=False
                if p is not None:
                    try: regular=stat.S_ISREG(p.lstat().st_mode)   # lstat: a symlink here is not a log this may clear
                    except OSError: regular=False
                avail.append({'key':key,'label':src['label'],'available':p is not None,
                              # Match clear_log()'s own test, so the page never
                              # offers a Clear button that is certain to fail.
                              'clearable':key in _LOG_CLEARABLE and regular,
                              'path':str(p) if p else str(src['paths'][0])})
            return self.sendj({'sources':avail})
        if path=='/api/logs':
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            src_key=q.get('source',['locsecd'])[0]
            if src_key not in LOG_SOURCES: src_key='locsecd'
            src=LOG_SOURCES[src_key]
            # The firewall view is the one people read entry by entry, so it
            # gets a longer stretch of history than the others.
            nlines=1000 if src_key=='ufw' else 500
            def _reply(lines,path,fpath=None):
                ev=friendly_log(src_key,lines,fpath)
                out={'lines':lines,'path':path,'events':ev,'source':src_key}
                if src_key=='ufw': out['summary']=ufw_summary(ev)
                return self.sendj(out)
            p=next((p for p in _source_paths(src_key,src) if p.exists()),None)
            if p is None:
                jt=_source_journal(src,nlines)
                if jt: return _reply(jt.splitlines()[-nlines:],f"systemd journal ({src.get('jlabel','')})")
                why=f"{src['paths'][0]} does not exist"+(' and the systemd journal has no matching entries' if 'jargs' in src else '')
                if src.get('hint'): why+=f" -- {src['hint']}"
                return self.sendj({'lines':[],'path':None,'error':why,'events':[],'source':src_key})
            try:
                # readable-only; large files are tailed rather than fully loaded.
                # An AIDE check prints its verdict and counts first, so that one
                # is read from the top.
                full_aide=src_key=='aide' and p.name.startswith('aide-full-')
                rc,out=run(['head' if full_aide else 'tail','-n',str(nlines),str(p)],10,tail=4000000)
                lines=out.splitlines() if rc==0 else _tail_lines(p,nlines,4000000)
                return _reply(lines,str(p),str(p) if full_aide else None)
            except PermissionError:
                return self.sendj({'lines':[],'path':str(p),'error':'permission denied (locsecd runs as root; try sudo tail on this file directly)'})
            except Exception as e:
                return self.sendj({'lines':[],'path':str(p),'error':str(e)})
        if path=='/api/reports': return self.sendj({'reports':[x.name for x in sorted(REPORTS.glob('*.json'),reverse=True)[:50]]})
        if path=='/api/ports':
            rc,out=run(['ss','-lntup'],30); return self.sendj({'output':out})
        if path=='/api/firewall':
            rc,out=ufw(['status','verbose']); return self.sendj({'rc':rc,'output':out})
        if path=='/api/feeds':
            # Counts only. Sending the full arrays meant the Threat Intelligence
            # page downloaded and parsed the entire indicator database (megabytes)
            # just to render three numbers -- the same failure mode as the oversize
            # report view. Reputation lookups are answered server-side by
            # /api/reputation, which reads the file directly.
            try:
                f=_feeds()
                return self.sendj({'updated':f.get('updated'),'interval_seconds':f.get('interval_seconds'),
                                   'last_attempt':f.get('last_attempt'),'last_attempt_ok':f.get('last_attempt_ok',True),
                                   'sources':f.get('sources',[]),'errors':f.get('errors',[])[:20],
                                   'domains':len(f.get('domains',[])),'ips':len(f.get('ips',[])),
                                   'networks':len(f.get('networks',[]))})
            except Exception: return self.sendj({'domains':0,'ips':0,'networks':0,'sources':[],'errors':[]})
        if path=='/api/captures': return self.sendj({'captures':[x.name for x in sorted(CAPTURES.glob('*.pcapng'),reverse=True)[:50]]})
        if path=='/api/quarantine/list': return self.sendj(list_quarantine())
        if path=='/api/incidents':
            incs=recent_incidents(300)
            for i in incs:
                try: i['can_fix']=incident_can_fix(i)
                except Exception: i['can_fix']=False
            return self.sendj({'incidents':incs,'notify_on':CFG.get('notify_on',{})})
        if path=='/api/notify-settings': return self.sendj({'notify_on':CFG.get('notify_on',{})})
        if path=='/api/connections': return self.sendj({'connections':network_connections()})
        if path=='/api/services': return self.sendj({'services':service_list()})
        if path=='/api/response-policy': return self.sendj({'policy':{k:CFG.get(k) for k in _POLICY_KEYS}})
        if path=='/dashboard':
            q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            cookie_ok=self.auth()
            # Only a single-use login code (minted with the API token) starts a session.
            token_ok=self._code_ok
            if not cookie_ok and not token_ok: return self.sendj({'error':'unauthorized'},401)
            if token_ok and not cookie_ok:
                # Fresh login via a single-use code: exchange it for a session
                # cookie and redirect to the bare URL. The cookie is a random,
                # expiring session id, not the API token.
                self.send_response(302)
                self.send_header('Set-Cookie',f'{COOKIE}={new_session()}; HttpOnly; SameSite=Strict; Path=/; Max-Age={_SESSION_MAX}')
                self.send_header('Location','/dashboard')
                self.send_header('Cache-Control','no-store'); self.send_header('Content-Length','0'); self.end_headers()
                return
            html=DASHBOARD.replace('__REPORT_DAYS__',str(int(CFG.get('report_retention_days',7))))
            data=html.encode(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'");
            self.send_header('X-Frame-Options','DENY'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','no-referrer'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        return self.sendj({'error':'not found'},404)
    def _same_origin(self):
        # Defence in depth behind the SameSite=Strict session cookie: a browser
        # attaches Origin to every cross-site POST, so anything that arrives
        # with a foreign Origin is refused even if it somehow carried the
        # cookie. Requests with no Origin at all (curl, locsecctl, the GUI's
        # own XHR on some Qt builds) are unaffected -- those cannot be driven
        # by a third-party page in the first place.
        origin=self.headers.get('Origin')
        if not origin: return True
        try: o=urllib.parse.urlsplit(origin)
        except ValueError: return False
        return bool(o.netloc) and o.netloc==self.headers.get('Host','')
    def do_POST(self):
        if not self._host_ok(): return self.sendj({'error':'unexpected Host header'},421)
        if not self.auth(): return self.sendj({'error':'unauthorized'},401)
        if not self._same_origin(): return self.sendj({'error':'cross-origin request refused'},403)
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n < 0 or n > MAX_BODY: return self.sendj({'error':'request body too large'},413)
            body=json.loads(self.rfile.read(n) or b'{}')
            if not isinstance(body,dict): return self.sendj({'error':'JSON object required'},400)
        except Exception: return self.sendj({'error':'bad json'},400)
        p=self.path.split('?',1)[0]
        try:
            if p=='/api/login-code':
                c=mint_login_code()
                return self.sendj({'ok':True,'code':c,'ttl':_LOGIN_CODE_TTL} if c else {'ok':False,'error':'too many outstanding login codes; wait a minute'},200 if c else 429)
            if p=='/api/incident/action': return self.sendj(incident_action(body.get('id',''),body.get('action','')))
            if p=='/api/incident/delete': return self.sendj(delete_incident(body.get('id','')))
            if p=='/api/incident/delete-all': return self.sendj(delete_all_incidents())
            if p=='/api/response-policy':
                allowed=set(_POLICY_KEYS)
                changed={}
                for k,v in body.items():
                    if k in allowed and isinstance(v,bool): CFG[k]=v; changed[k]=v
                if changed:
                    with LOCK:
                        try: persisted=json.loads(RUNTIME_POLICY.read_text())
                        except Exception: persisted={}
                        if not isinstance(persisted,dict): persisted={}
                        persisted.update(changed)
                        atomic_json(RUNTIME_POLICY,persisted)
                log(f'response policy changed: {changed}')
                return self.sendj({'ok':True,'changed':changed})
            if p=='/api/notify-test':
                if not (have('notify-send') or have('gdbus')): return self.sendj({'ok':False,'error':'Neither notify-send nor gdbus is installed. Install it with: sudo apt install libnotify-bin'})
                users=_desktop_users()
                if not users: return self.sendj({'ok':False,'error':'No local graphical session is active, so there is nowhere to show a notification.'})
                _notify_desktop({'kind':'test','indicator':'','detail':'Desktop notifications from LocSec are working.'},force=True)
                return self.sendj({'ok':True,'sessions':len(users)})
            if p=='/api/notify-settings':
                cur=dict(CFG.get('notify_on',{}))
                changed={}
                for k,v in body.items():
                    # Only the kinds the dashboard offers; anything else would grow
                    # the configuration (and every response carrying it) unbounded.
                    if isinstance(v,bool) and k in _NOTIFY_KINDS: cur[k]=v; changed[k]=v
                CFG['notify_on']=cur
                if changed:
                    with LOCK:
                        try: persisted=json.loads(RUNTIME_POLICY.read_text())
                        except Exception: persisted={}
                        if not isinstance(persisted,dict): persisted={}
                        no=dict(persisted.get('notify_on',{})) if isinstance(persisted.get('notify_on'),dict) else {}
                        no.update(changed); persisted['notify_on']=no
                        atomic_json(RUNTIME_POLICY,persisted)
                log(f'notification settings changed: {changed}')
                return self.sendj({'ok':True,'notify_on':cur})
            if p=='/api/block': return self.sendj({'ok':block_ip(body.get('ip',''),body.get('reason','manual'),'manual')[0]})
            if p=='/api/unblock': return self.sendj({'ok':unblock_ip(body.get('ip',''))[0]})
            if p in ('/api/scan','/api/cve','/api/update','/api/feed','/api/defs-update'):
                if not JOB_LOCK.acquire(blocking=False,job={'/api/scan': 'Full scan', '/api/cve': 'CVE scan', '/api/update': 'System update', '/api/feed': 'Threat-feed update', '/api/defs-update': 'Virus/rootkit definition update'}[p]): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try:
                    result={'/api/scan':heavy_scan,'/api/cve':cve_scan,'/api/update':package_update,'/api/feed':feed_update,'/api/defs-update':update_definitions}[p]()
                    return self.sendj(result)
                finally: JOB_LOCK.release()
            if p=='/api/scan-job':
                # Single-job scan: run just one tool immediately instead of
                # the full sequence /api/scan runs (heavy_scan). Same job
                # names locsecctl's scan-<name> shortcuts use.
                jobs=dict(SCAN_JOBS+[CLAMAV_JOB])
                key=str(body.get('job',''))
                if key not in jobs: return self.sendj({'ok':False,'error':f'unknown job "{key}"'},400)
                if not JOB_LOCK.acquire(blocking=False,job=_JOB_LABEL.get(key,key)+' scan'): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try: return self.sendj(run_scan_job(key,jobs[key]) or {'ok':False,'error':f'{key} is not installed or produced no result'})
                finally: JOB_LOCK.release()
            if p in ('/api/aide/accept','/api/aide/reinitialize'):
                if not JOB_LOCK.acquire(blocking=False,job={'/api/aide/accept':'Accept pending AIDE baseline','/api/aide/reinitialize':'Rebuild AIDE baseline'}[p]): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try:
                    if p=='/api/aide/accept': return self.sendj(aide_accept_pending(body.get('confirm')=='ACCEPT_PENDING'))
                    return self.sendj(aide_reinitialize(body.get('confirm')=='REPLACE_BASELINE'))
                finally: JOB_LOCK.release()
            if p=='/api/tool/add':
                if not JOB_LOCK.acquire(blocking=False,job=f"Installing {str(body.get('tool',''))[:40]}"): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try: return self.sendj(tool_add(body.get('tool','')))
                finally: JOB_LOCK.release()
            if p=='/api/reputation': return self.sendj(reputation_check(body.get('indicator','')))
            if p=='/api/capture/analyze': return self.sendj(analyze_capture(body.get('name','')))
            if p=='/api/report/read': return self.sendj(read_report(body.get('name','')))
            if p=='/api/report/delete': return self.sendj(delete_report(body.get('name','')))
            if p=='/api/log/clear':
                return self.sendj(clear_log(str(body.get('source',''))))
            if p=='/api/service/forget':
                return self.sendj(service_forget(str(body.get('unit',''))))
            if p=='/api/service/action':
                return self.sendj(service_action(str(body.get('unit','')),str(body.get('action',''))))
            if p=='/api/install-missing':
                if not JOB_LOCK.acquire(blocking=False,job='Installing missing components'): return self.sendj({'ok':False,'error':JOB_LOCK.busy_message(),'running':JOB_LOCK.current()},409)
                try: return self.sendj(install_missing())
                finally: JOB_LOCK.release()
            if p=='/api/quarantine': return self.sendj(quarantine_file(str(body.get('path','')),force=bool(body.get('force',False)),anyway=bool(body.get('anyway',False)),signature=str(body.get('signature','')),incident_id=str(body.get('incident_id',''))))
            if p=='/api/quarantine/restore': return self.sendj(restore_quarantined(str(body.get('id','')),overwrite=bool(body.get('overwrite',False))))
            if p=='/api/quarantine/delete': return self.sendj(delete_quarantine_item(str(body.get('id',''))))
            if p=='/api/quarantine/delete-all': return self.sendj(delete_all_quarantine())
            if p=='/api/firewall/enable':
                rc,out=ufw(['--force','enable']); log(f'ufw enable: {out.strip()}'); return self.sendj({'ok':rc==0,'output':out})
            if p=='/api/firewall/disable':
                rc,out=ufw(['disable']); log(f'ufw disable: {out.strip()}'); return self.sendj({'ok':rc==0,'output':out})
            if p=='/api/port/open':
                port=str(body.get('port','')); proto=str(body.get('proto','tcp')).lower()
                if not re.fullmatch(r'[0-9]{1,5}',port) or not (1 <= int(port) <= 65535) or proto not in ('tcp','udp'): return self.sendj({'error':'invalid port'},400)
                rc,out=ufw(['allow',f'{port}/{proto}']); log(f'ufw open {port}/{proto}: {out.strip()}'); return self.sendj({'ok':rc==0,'output':out})
            if p=='/api/port/close':
                port=str(body.get('port','')); proto=str(body.get('proto','tcp')).lower()
                if not re.fullmatch(r'[0-9]{1,5}',port) or not (1 <= int(port) <= 65535) or proto not in ('tcp','udp'): return self.sendj({'error':'invalid port'},400)
                rc,out=ufw(['delete','allow',f'{port}/{proto}']); log(f'ufw close {port}/{proto}: {out.strip()}'); return self.sendj({'ok':rc==0,'output':out})
            if p=='/api/capture/start':
                iface=str(body.get('iface','any')); dur=min(max(int(body.get('seconds',60)),5),3600)
                if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,32}',iface): return self.sendj({'error':'invalid interface'},400)
                if not have('tcpdump'): return self.sendj({'error':'tcpdump is not installed'},503)
                # Cap concurrent captures: an unbounded number of simultaneous
                # tcpdump processes each writing an unbounded pcapng file is an
                # easy way to fill the disk (or exhaust memory/fds) from the
                # dashboard alone. -s 0 already caps per-packet size; this caps
                # fan-out.
                try:
                    free_bytes=shutil.disk_usage(CAPTURES).free
                except Exception: free_bytes=None
                if free_bytes is not None and free_bytes<MIN_CAPTURE_FREE_BYTES:
                    return self.sendj({'error':f'only {free_bytes//(1024*1024)}MB free on the capture volume; refusing to start a capture below {MIN_CAPTURE_FREE_BYTES//(1024*1024)}MB free'},507)
                with CAPTURE_LOCK:
                    _reap_captures()
                    if len(ACTIVE_CAPTURES)>=MAX_CONCURRENT_CAPTURES:
                        return self.sendj({'error':f'too many packet captures already running (max {MAX_CONCURRENT_CAPTURES}); wait for one to finish'},429)
                    fn=CAPTURES/f'capture-{datetime.now().strftime("%Y%m%d-%H%M%S-%f")}.pcapng'
                    # Debian's tcpdump drops to its own "tcpdump" user after opening
                    # the interface, and that user cannot create files in this
                    # root-only directory, so "-w <file>" produced nothing. Open the
                    # file here, as root, and let tcpdump write to its stdout.
                    fd=os.open(str(fn),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
                    try:
                        proc=subprocess.Popen(['tcpdump','-Z','root','-i',iface,'-nn','-s','0','-U','-w','-'],stdout=fd,stderr=subprocess.DEVNULL,start_new_session=True)
                    finally: os.close(fd)
                    ACTIVE_CAPTURES.append(proc)
                def stop():
                    # Poll instead of a single sleep so a capture that fills the
                    # disk mid-run gets killed early rather than running the full
                    # duration regardless.
                    deadline=time.time()+dur
                    while time.time()<deadline and proc.poll() is None:
                        try:
                            if shutil.disk_usage(CAPTURES).free<HARD_MIN_CAPTURE_FREE_BYTES:
                                log(f'packet capture {fn} stopped early: disk nearly full','WARN'); break
                        except Exception: pass
                        time.sleep(2)
                    _terminate_capture(proc)
                    with CAPTURE_LOCK:
                        if proc in ACTIVE_CAPTURES: ACTIVE_CAPTURES.remove(proc)
                threading.Thread(target=stop,daemon=True).start(); log(f'packet capture started {fn} iface={iface} duration={dur}s'); return self.sendj({'ok':True,'file':str(fn)})
        except Exception as e:
            log(f'API error {p}: {e}','ERROR'); return self.sendj({'error':str(e)},500)
        return self.sendj({'error':'not found'},404)

DASHBOARD='''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LocSec Security Center</title><style>
:root{--bg:#0b0d12;--panel:#12151d;--panel2:#171b26;--line:#232838;--txt:#e6e9f2;--muted:#8b93a7;--accent:#5b8cff;--accent2:#7c5cff;--ok:#33d69f;--bad:#ff5d7a;--warn:#ffb547}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
.card{scroll-margin-top:76px}
.card a{color:var(--accent);text-decoration:none}
.card a:hover{text-decoration:underline}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,sans-serif;background:radial-gradient(1200px 600px at 10% -10%,#161b2b 0%,var(--bg) 55%);color:var(--txt);-webkit-font-smoothing:antialiased}
header{position:fixed;z-index:5;left:0;right:0;top:0;height:60px;background:rgba(18,21,29,.9);backdrop-filter:blur(10px);border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 22px;gap:12px}
header .logo{width:26px;height:26px;border-radius:8px;background:linear-gradient(135deg,var(--accent),var(--accent2));flex:none}
header .title{font-size:15px;font-weight:600;letter-spacing:.2px}
header .sub{font-size:11px;color:var(--muted)}
header .status{margin-left:auto;display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted)}
header .dot{width:8px;height:8px;border-radius:50%;background:var(--muted)}
header .dot.up{background:var(--ok);box-shadow:0 0 8px var(--ok)}
header .dot.down{background:var(--bad);box-shadow:0 0 8px var(--bad)}
nav{position:fixed;top:60px;bottom:0;left:0;width:216px;background:var(--panel);border-right:1px solid var(--line);padding:14px 10px;overflow:auto}
nav button{display:flex;align-items:center;gap:10px;width:100%;padding:13px 14px;margin-bottom:4px;background:none;border:0;border-radius:8px;color:var(--muted);text-align:left;font-size:15.5px;cursor:pointer;transition:background .12s,color .12s}
nav button:hover{background:var(--panel2);color:var(--txt)}
nav button.active{background:linear-gradient(90deg,rgba(91,140,255,.18),rgba(124,92,255,.08));color:var(--txt);box-shadow:inset 2px 0 0 var(--accent)}
main{margin-left:216px;padding:84px 26px 40px;max-width:1180px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px}
.card{background:linear-gradient(180deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:16px;box-shadow:0 8px 24px rgba(0,0,0,.25)}
.card h2{margin:0 0 12px;font-size:15px;font-weight:600}
.card h3{margin:18px 0 8px;font-size:13px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
.metric{font-size:28px;font-weight:700;letter-spacing:-.02em}
.muted{color:var(--muted);font-size:12px}
.ok{color:var(--ok)}
.bad{color:var(--bad)}
.pill{display:inline-block;padding:2px 9px;border-radius:99px;font-size:11px;font-weight:600}
.pill.ok{background:rgba(51,214,159,.14);color:var(--ok)}
.pill.bad{background:rgba(255,93,122,.14);color:var(--bad)}
button.act{appearance:none;-webkit-appearance:none;font-family:inherit;line-height:1.2;padding:8px 14px;border:1px solid var(--accent);border-radius:9px;background:rgba(91,140,255,.12);color:var(--accent);margin:3px 6px 3px 0;cursor:pointer;font-size:13px;font-weight:600;transition:filter .12s,transform .08s}
button.act:hover{filter:brightness(1.25)}
button.act:active{transform:scale(.97)}
button.act:disabled{opacity:.5;cursor:default;filter:none}
button.danger{background:rgba(255,93,122,.12);border-color:var(--bad);color:var(--bad)}
button.ghost{background:rgba(139,147,167,.10);border-color:var(--muted);color:var(--txt)}
input,select,textarea{color-scheme:dark;accent-color:var(--accent);font:inherit;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:#0e111a;color:var(--txt)}
select{appearance:none;-webkit-appearance:none;padding-right:30px;cursor:pointer;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M1 1l4 4 4-4' fill='none' stroke='%238b93a7' stroke-width='1.5'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 11px center}
input::placeholder,textarea::placeholder{color:#5b6376}
input{min-width:240px}
input[type=checkbox]{min-width:0;width:auto;padding:0;margin:0}
.toolbar label{display:inline-flex;align-items:center;gap:7px}
table{width:100%;border-collapse:collapse;font-size:13px}
td,th{padding:9px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{color:var(--muted);font-weight:600;font-size:11.5px;text-transform:uppercase;letter-spacing:.05em}
.scroll{max-height:430px;overflow:auto}
.scroll.tall{max-height:72vh}
code.wrap{white-space:normal;word-break:break-all;font-size:11.5px;color:#c9d3e6}
.pill.warn{background:rgba(255,181,71,.14);color:var(--warn)}
.pill.note{background:rgba(91,140,255,.14);color:var(--accent)}
.intro{font-size:14.5px;line-height:1.55;margin:4px 0 12px}
.tally{display:flex;gap:14px;flex-wrap:wrap;align-items:center;margin-bottom:10px;font-size:13px}
table.loglist{table-layout:fixed}
table.loglist td{font-size:13.5px;line-height:1.45}
td,.fix,.explain .item,.story p{overflow-wrap:anywhere;word-break:break-word}
details>summary{cursor:pointer;display:inline-block;padding:6px 12px;border:1px solid var(--accent);border-radius:8px;color:var(--accent);font-weight:600;font-size:12.5px;margin:4px 0;user-select:none}
details>summary:hover{background:rgba(91,140,255,.12)}
details[open]>summary{margin-bottom:8px}
tr.lv-bad td:first-child{box-shadow:inset 3px 0 0 var(--bad)}
tr.lv-warn td:first-child{box-shadow:inset 3px 0 0 var(--warn)}
.fwsum .big{font-size:16px;margin-top:0}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;margin-bottom:6px}
details.raw{margin-top:12px}
.logcard pre#r:empty{display:none}
.fix{margin-top:6px;padding:7px 10px;border-left:3px solid var(--ok);background:rgba(51,214,159,.07);border-radius:4px;font-size:13px;line-height:1.45}
.fix b{color:var(--ok)}
.rep{color:var(--muted);font-weight:400;font-size:12px}
.explain .item{padding:9px 0;border-bottom:1px solid var(--line);font-size:13.5px;line-height:1.45}
.explain .item:last-child{border-bottom:0}
.explain h3{margin:16px 0 4px}
.story h3{margin:16px 0 4px;font-size:14px}.story p{margin:0;line-height:1.5}
.modalbg{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:9999;display:flex;align-items:center;justify-content:center;padding:24px}
@media print{
 body.printing > *:not(.modalbg){display:none!important}
 body.printing{background:#fff!important}
 body.printing .modalbg{position:static;background:#fff;padding:0;display:block}
 body.printing .modalbg .card{max-height:none!important;overflow:visible!important;background:#fff!important;color:#000!important;box-shadow:none!important;border:0!important}
 body.printing .noprint{display:none!important}
 body.printing .fix{background:#f2f2f2;color:#000;border-left-color:#888}
 body.printing .fix b{color:#000}
 body.printing details{display:none}
 body.printing .explain .item{border-bottom-color:#ccc}
}
pre{max-height:460px;overflow:auto;background:#0a0c12;color:#c9d3e6;padding:14px;border-radius:10px;white-space:pre-wrap;word-break:break-word;font-size:12.5px;border:1px solid var(--line)}
.toolbar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px}
.incident-actions{display:grid;grid-template-columns:repeat(2,max-content);gap:2px 4px;align-items:center}.incident-actions button.act,td button.act{margin:0;padding:6px 10px;font-size:12px}
.banner{display:none;background:rgba(255,93,122,.12);border:1px solid var(--bad);color:#ffd6dd;border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:13px;align-items:center;gap:10px}
.banner.show{display:flex}
.banner button{margin-left:auto}
.skel{height:64px;border-radius:12px;background:linear-gradient(90deg,var(--panel2),var(--panel),var(--panel2));background-size:200% 100%;animation:sh 1.2s infinite}
@keyframes sh{0%{background-position:200% 0}100%{background-position:-200% 0}}
</style></head><body>
<header><div class="logo"></div><div><div class="title">LocSec Security Center</div><div class="sub">24/7 local host protection</div></div><div class="status"><span class="dot" id="hdot"></span><span id="htext">Checking…</span></div></header>
<nav id="nav">
<button data-p="overview" onclick="page('overview')">Overview</button>
<button data-p="firewall" onclick="page('firewall')">Firewall &amp; Blocks</button>
<button data-p="logins" onclick="page('logins')">Login Activity</button>
<button data-p="incidents" onclick="page('incidents')">Incidents</button>
<button data-p="scans" onclick="page('scans')">Scans &amp; CVEs</button>
<button data-p="malware" onclick="page('malware')">Malware / Quarantine</button>
<button data-p="threats" onclick="page('threats')">Threat Intelligence</button>
<button data-p="network" onclick="page('network')">Ports &amp; Capture</button>
<button data-p="services" onclick="page('services')">Services</button>
<button data-p="reports" onclick="page('reports')">Reports</button>
<button data-p="logs" onclick="page('logs')">Logs</button>
<button data-p="troubleshooting" onclick="page('troubleshooting')">Troubleshooting</button>
<button data-p="help" onclick="page('help')">Help</button>
</nav>
<main id="app"><div class="banner" id="banner"><span></span><button class="act ghost" onclick="dismissFlash()">Dismiss</button></div><div id="pagebody"></div></main>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let currentPage='overview';
const REPORT_DAYS=Number('__REPORT_DAYS__')||7;

async function api(u,o={}){
  o.headers=Object.assign({'Content-Type':'application/json'},o.headers||{});
  let r;
  try{ r=await fetch(u,o); }
  catch(e){ throw new Error('Cannot reach the LocSec service ('+(e&&e.message?e.message:'network error')+'). Is locsecd running?'); }
  let j;
  try{ j=await r.json(); }
  catch(e){ j={error:'invalid server response'}; }
  if(!r.ok){
    const msg=(j&&j.error)?j.error:('HTTP '+r.status);
    if(r.status===401) document.title='LocSec - session expired';
    throw new Error(r.status===401?'Session expired — reopen LocSec to sign in again.':msg);
  }
  return j;
}

function show(x){let r=document.getElementById('r');if(r)r.textContent=typeof x==='string'?x:JSON.stringify(x,null,2)}

async function toolAdd(tool,btn){await run('/api/tool/add',{tool:tool},btn);page('overview')}
async function run(u,b={},btn){
  if(btn) btn.disabled=true;
  try{
    let x=await api(u,{method:'POST',body:JSON.stringify(b)});
    show(x); return x;
  }catch(e){
    show('Error: '+e.message); flash(e.message); return {ok:false,error:e.message};
  }finally{
    if(btn) btn.disabled=false;
    if(document.getElementById('jobnow')) showJob();
  }
}

function flash(msg){
  const b=document.getElementById('banner');
  if(!b) return;
  b.querySelector('span').textContent=msg;
  b.classList.add('show');
}
function dismissFlash(){const b=document.getElementById('banner');if(b)b.classList.remove('show')}

function nav(p){document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.p===p))}

async function page(p){
  currentPage=p; nav(p); dismissFlash();
  let a=document.getElementById('pagebody');
  a.innerHTML='<div class="skel"></div><div class="skel" style="margin-top:10px"></div>';
  try{
    await renderPage(p,a);
  }catch(e){
    a.innerHTML=`<div class="card"><p class="bad">Could not load this page.</p><button class="act ghost" onclick="page('${p}')">Retry</button></div>`;
    flash(e.message);
  }
}

async function renderPage(p,a){
if(p==='overview'){let s=await api('/api/status');let m=s.missing||{};let need=[];if(m['clamav-daemon'])need.push('ClamAV daemon');
a.innerHTML=`<div class="grid"><div class="card"><div class="muted">Version</div><div class="metric">${esc(s.version)}</div></div><div class="card"><div class="muted">Blocks</div><div class="metric">${esc(s.blocks)}</div></div><div class="card"><div class="muted">Auth failures</div><div class="metric">${esc(s.auth_failures)}</div></div><div class="card"><div class="muted">Load</div><div class="metric">${esc((s.load||[])[0]||'?')}</div><div class="muted">${s.idle?'idle scan eligible':'busy'}</div></div></div>`+
(need.length?`<div class="card"><h2>Setup incomplete</h2><p class="muted">Not installed yet: ${need.map(esc).join(', ')}.</p><div class="toolbar">${m['clamav-daemon']?`<button class="act" onclick="run('/api/install-missing',{},this).then(()=>page('overview'))">Install missing components</button>`:''}</div><pre id="r"></pre></div>`:'')+
`<div class="card"><h2>Protection status</h2><table><tr><th>Component</th><th>Status</th><th>Action</th></tr>${Object.entries(s.tools||{}).map(([k,v])=>`<tr><td>${esc(k)}</td><td><span class="pill ${v?'ok':'bad'}">${v?'installed':'missing'}</span></td><td>${v?'<span class="muted">required</span>':`<div class="incident-actions"><button class="act" onclick="toolAdd(${esc(JSON.stringify(k))},this)">Add</button></div>`}</td></tr>`).join('')}</table><p>Firewall: <span class="pill ${s.firewall_active?'ok':'bad'}">${s.firewall_active?'active':'inactive'}</span></p></div>${(s.exposure||[]).length?`<div class="card"><h2>Exposure</h2><p class="muted">What an attacker on the network would try first. LocSec reports these; it does not change them for you.</p><table><tr><th>Check</th><th>State</th><th>Detail</th></tr>${s.exposure.map(e=>`<tr><td>${esc(e.item)}</td><td><span class="pill ${e.level==='ok'?'ok':'bad'}">${e.level==='ok'?'ok':'review'}</span></td><td>${esc(e.detail)}${e.fix?`<br><span class="muted">Fix: <code>${esc(e.fix)}</code></span>`:''}</td></tr>`).join('')}</table></div>`:''}<div class="card"><h2>Services</h2><table><tr><th>Unit</th><th>State</th></tr>${(s.services||[]).filter(x=>x.managed).map(x=>`<tr><td>${esc(x.unit)}</td><td><span class="pill ${x.running?'ok':'bad'}">${esc(x.state||(x.running?'running':'stopped'))}</span></td></tr>`).join('')||'<tr><td colspan="2" class="muted">No LocSec-managed services found.</td></tr>'}</table><p class="muted">The Services page lists these plus everything else currently running.</p></div>`}
if(p==='firewall'){let b=await api('/api/blocks/explained'),f=await api('/api/firewall'),ports=await api('/api/ports');window._blk=b.blocks||[];a.innerHTML=`<div class="card"><h2>Firewall</h2><div class="toolbar"><button class="act" onclick="run('/api/firewall/enable',{},this)">Enable UFW</button><button class="act danger" onclick="run('/api/firewall/disable',{},this)">Disable UFW</button><input id="ip" placeholder="IP or CIDR"><button class="act" onclick="manualBlock()">Block</button></div><div class="toolbar"><input id="fwport" placeholder="Port 1-65535" type="number" min="1" max="65535"><select id="fwproto"><option>tcp</option><option>udp</option></select><button class="act" onclick="portRule('open')">Open port</button><button class="act danger" onclick="portRule('close')">Close port</button></div><pre>${esc(f.output||'')}</pre><h3>Listening ports</h3><pre>${esc(ports.output||'')}</pre></div>`+blocksCard(b)+`<pre id="r"></pre>`}
if(p==='logins'){let s=await api('/api/status');a.innerHTML=`<div class="grid"><div class="card"><div class="muted">Failed events</div><div class="metric">${esc(s.auth_failures)}</div></div><div class="card"><div class="muted">Successful events</div><div class="metric">${esc(s.auth_successes)}</div></div></div><div class="card"><h2>Authentication / intrusion monitoring</h2><p class="muted">Repeated failures can trigger automatic blocking.</p></div>`}
if(p==='incidents'){let x=await api('/api/incidents');a.innerHTML=`<div class="card"><h2>Automatic response policy</h2><p class="muted">These controls govern automatic containment. Allowlisted addresses are never blocked.</p><div class="toolbar"><label><input id="pol_auto" type="checkbox"> Automatic blocking</label><label><input id="pol_auth" type="checkbox"> Failed-login blocking</label><label><input id="pol_feed" type="checkbox"> Threat-feed blocking</label><label><input id="pol_v6" type="checkbox"> IPv6 blocking</label><label><input id="pol_scan" type="checkbox"> Port-scan blocking</label><label><input id="pol_fb" type="checkbox"> Fallback firewall when UFW is off</label><button class="act" onclick="savePolicy()">Save policy</button></div><pre id="policyout"></pre></div><div class="card"><h2>Desktop notifications</h2><p class="muted">A new incident of a checked type pops up as a desktop notification for about 10 seconds, even when this window is closed, and stays in your notification list. The same address is announced at most once every 10 minutes.</p><div class="toolbar"><label><input id="ntf_virus" type="checkbox"> Virus found</label><label><input id="ntf_rootkit" type="checkbox"> Rootkit warning</label><label><input id="ntf_block" type="checkbox"> IP blocked</label><label><input id="ntf_login" type="checkbox"> Failed login</label><label><input id="ntf_scan" type="checkbox"> Port scan</label><label><input id="ntf_fb" type="checkbox"> Fallback firewall on</label><button class="act" onclick="saveNotifySettings()">Save</button><button class="act" onclick="testNotification()">Send test notification</button></div><pre id="notifyout"></pre></div><div class="card"><h2>Incident timeline</h2><div class="toolbar"><button class="act danger" onclick="deleteAllIncidents()">Delete all</button></div><p class="muted"><b>Explain</b> says in plain words what happened, what LocSec did and what you should do. <b>Fix it</b> appears only when LocSec can fix it by itself (block that computer, or move the file into quarantine). <b>Mark solved</b> closes it. Every result can be printed or copied.</p><p class="muted">Repeated observations are folded into one incident <b>while it is open</b> &mdash; the Seen column counts them. Resolving or dismissing closes it for good: a later observation of the same thing opens a new incident with its own timestamp, so closure stays meaningful and the history of the old one is preserved. Feed entries are intelligence indicators, not proof that the listed address actually connected to this computer. Network blocks expire after 30 days unless refreshed by a new confirmed event.</p><div class="scroll"><table><tr><th>Time</th><th>Type</th><th>Source</th><th>Indicator</th><th>Severity</th><th>State</th><th>Seen</th><th>Action</th></tr>${(x.incidents||[]).slice().reverse().map(i=>`<tr><td>${esc(new Date((i.ts||0)*1000).toLocaleString())}</td><td>${esc(KIND_LABEL[i.kind]||i.kind)}</td><td>${esc(i.source)}</td><td>${esc(i.indicator)}</td><td>${esc(i.severity)}</td><td>${esc(STATE_LABEL[i.state||'new']||i.state)}</td><td>${esc(i.count||1)}<br><small>${i.last_seen?esc(new Date(i.last_seen*1000).toLocaleString()):''}</small></td><td><div class="incident-actions"><button class="act" onclick="incidentAction(${esc(JSON.stringify(i.id))},'explain')">Explain</button>${i.can_fix?`<button class="act" onclick="incidentAction(${esc(JSON.stringify(i.id))},'fix')">Fix it</button>`:''}${i.state!=='resolved'?`<button class="act" onclick="incidentAction(${esc(JSON.stringify(i.id))},'resolve')">Mark solved</button>`:''}<button class="act danger" onclick="deleteIncident(${esc(JSON.stringify(i.id))})">Delete</button></div></td></tr>`).join('')||'<tr><td colspan="8" class="muted">No incidents recorded.</td></tr>'}</table></div></div>`;await loadPolicy()}
if(p==='scans'){setTimeout(showJob,0);a.innerHTML=`<div class="card"><h2>Security scans</h2><p class="muted">AIDE, Lynis, Debsecan, rkhunter, a port/firewall snapshot and a CVE check each run automatically once a week, staggered a day apart and at most one per day, so they don't all hit the CPU/disk together. ClamAV runs separately once a day, and rkhunter/ClamAV signature definitions refresh once a day in the background. Scheduled runs wait until the machine has been idle (load at or below <code>idle_load</code> for <code>idle_seconds</code>); buttons here start at once. Only one maintenance job runs at a time. The aide package's own daily check (dailyaidecheck) is switched off when LocSec is installed, so AIDE runs once a week, not every day. Reports are deleted automatically after ${esc(REPORT_DAYS)} days.</p><p id="jobnow" class="muted"></p><div id="schedule"></div><div class="toolbar"><button class="act" onclick="run('/api/scan',{},this)">Full scan</button><button class="act" onclick="run('/api/update',{},this)">Update system</button><button class="act" onclick="run('/api/defs-update',{},this)">Update virus/rootkit definitions now</button><button class="act" onclick="aideAcceptPending(this)">Accept pending AIDE baseline</button><button class="act danger" onclick="aideReinitialize(this)">Rebuild AIDE baseline</button></div><p class="muted">Run a single tool instead of waiting through the whole full scan above:</p><div class="toolbar"><button class="act" onclick="run('/api/scan-job',{job:'aide'},this)">AIDE only</button><button class="act" onclick="run('/api/scan-job',{job:'lynis'},this)">Lynis only</button><button class="act" onclick="run('/api/scan-job',{job:'debsecan'},this)">Debsecan only</button><button class="act" onclick="run('/api/scan-job',{job:'rkhunter'},this)">rkhunter only</button><button class="act" onclick="run('/api/scan-job',{job:'clamav'},this)">ClamAV only</button><button class="act" onclick="run('/api/scan-job',{job:'ports_fw'},this)">Ports/firewall only</button><button class="act" onclick="run('/api/cve',{},this)">CVE scan</button></div><pre id="r"></pre></div>`}
if(p==='malware'){let q=await api('/api/quarantine/list');let inc=await api('/api/incidents');window._qitems=q.items||[];window._qdet=(inc.incidents||[]).filter(i=>i.kind==='virus-found'&&i.state!=='resolved'&&i.indicator).reverse();a.innerHTML=`<div class="card"><h2>Quarantine</h2><p class="muted">Quarantined files are moved out of place, stripped of any way to run them, and kept with their original location so they can be restored. Files under system directories (/bin, /usr/lib, /etc, ...) are refused by default to avoid a false positive breaking the system.</p><div class="toolbar"><input id="mal" placeholder="Absolute file path"><label><input id="malforce" type="checkbox"> Force (allow system paths)</label><label><input id="malany" type="checkbox"> Quarantine even if clean</label><button class="act" onclick="qAdd(this)">Scan &amp; quarantine</button></div></div><div class="card"><h2>Detections awaiting action</h2><p class="muted">Infected files found by ClamAV scans that have not been quarantined yet.</p><div class="scroll"><table><tr><th>Time</th><th>File</th><th>Signature</th><th>Action</th></tr>${window._qdet.map((d,n)=>`<tr><td>${esc(new Date((d.ts||0)*1000).toLocaleString())}</td><td>${esc(d.indicator)}</td><td>${esc(d.detail)}</td><td><div class="incident-actions"><button class="act" onclick="qDetect(${n},this)">Quarantine</button></div></td></tr>`).join('')||'<tr><td colspan="4" class="muted">No unhandled detections.</td></tr>'}</table></div></div><div class="card"><h2>Quarantined files</h2><div class="toolbar"><button class="act danger" onclick="qDeleteAll()">Delete all</button></div><div class="scroll"><table><tr><th>Quarantined</th><th>Original location</th><th>Signature</th><th>Size</th><th>Action</th></tr>${window._qitems.map((x,n)=>`<tr><td>${esc(x.quarantined_at?new Date(x.quarantined_at*1000).toLocaleString():'')}</td><td>${esc(x.original_path)}</td><td>${esc(x.signature)}</td><td>${esc(fmtBytes(x.size))}</td><td><div class="incident-actions">${x.restorable?`<button class="act" onclick="qRestore(${n})">Restore</button>`:''}<button class="act danger" onclick="qDelete(${n})">Delete</button></div></td></tr>`).join('')||'<tr><td colspan="5" class="muted">Quarantine is empty.</td></tr>'}</table></div></div><div class="card"><pre id="r"></pre></div>`}
if(p==='threats'){let f=await api('/api/feeds');let cnt=x=>typeof x==='number'?x:(x||[]).length;let mins=Math.round((f.interval_seconds||43200)/60);let when=f.updated?new Date(f.updated*1000).toLocaleString():'never';let age=f.updated?Math.round((Date.now()/1000-f.updated)/60):null;
a.innerHTML=`<div class="card"><h2>Threat intelligence</h2><p class="muted">Auto-updates every ${mins} minute(s) in the background (no action needed). Last updated: ${esc(when)}${age!==null?` (${age} min ago)`:''}.</p>${f.last_attempt_ok===false?`<p class="bad">The last update, ${esc(new Date((f.last_attempt||0)*1000).toLocaleString())}, reached none of the sources (errors below). The indicators shown are from the last successful update, and LocSec retries every 15 minutes until one succeeds.</p>`:''}<div class="toolbar"><button class="act" onclick="run('/api/feed',{},this)">Update feeds now</button><input id="rep" placeholder="domain, IP or URL"><button class="act" onclick="repcheck()">Check reputation</button></div><p class="muted">Checks the local IOC database; LocSec does not visit submitted sites.</p><div class="grid"><div class="card"><div class="muted">Domains</div><div class="metric">${esc(cnt(f.domains))}</div></div><div class="card"><div class="muted">IPs</div><div class="metric">${esc(cnt(f.ips))}</div></div><div class="card"><div class="muted">Networks</div><div class="metric">${esc(cnt(f.networks))}</div></div></div>${(f.errors&&f.errors.length)?`<pre>${esc(JSON.stringify(f.errors,null,2))}</pre>`:''}<pre id="r"></pre></div>`}
if(p==='network'){let c=await api('/api/captures'),ports=await api('/api/ports'),con=await api('/api/connections');a.innerHTML=`<div class="card"><h2>Ports &amp; packet capture</h2><h3>Current connections</h3><pre>${esc(JSON.stringify(con.connections||[],null,2))}</pre><h3>Listening ports</h3><pre>${esc(ports.output||'')}</pre><div class="toolbar"><input id="iface" value="any"><input id="secs" value="60" type="number" min="5" max="3600"><button class="act" onclick="capture()">Start capture</button></div><p class="muted">pcapng captures can be opened in Wireshark.</p><div class="toolbar"><input id="capname" placeholder="capture filename"><button class="act" onclick="run('/api/capture/analyze',{name:document.getElementById('capname').value},this)">Analyze capture</button></div>${(c.captures||[]).length?`<h3>Saved captures</h3><div class="scroll"><table><tr><th>File</th><th>Action</th></tr>${(c.captures||[]).map(f=>`<tr><td>${esc(f)}</td><td><div class="incident-actions"><button class="act" onclick="analyzeCapture(${esc(JSON.stringify(f))})">Analyze</button></div></td></tr>`).join('')}</table></div>`:''}<pre id="r"></pre></div>`}
if(p==='services'){let s=await api('/api/services');a.innerHTML=`<div class="card"><h2>Services</h2><p class="muted">Units LocSec coordinates are listed first and stay listed when stopped, so you can start them again. Everything else currently running follows. Units your own access depends on (ssh, networking, the display manager, polkit, locsecd itself) can be started and enabled here but never stopped, restarted or disabled.</p><div class="scroll"><table><tr><th>Unit</th><th>State</th><th>Description</th><th>Action</th></tr>${(s.services||[]).map(x=>`<tr><td>${esc(x.unit)}${x.managed?' <span class="pill ok">LocSec</span>':''}</td><td><span class="pill ${x.running?'ok':'bad'}">${esc(x.state||(x.running?'running':'stopped'))}</span></td><td>${esc(x.description)}</td><td><div class="incident-actions">${x.protected?`<button class="act" onclick="svc(${esc(JSON.stringify(x.unit))},'start')">Start</button><span class="muted">protected</span>`:x.running?`<button class="act" onclick="svc(${esc(JSON.stringify(x.unit))},'restart')">Restart</button><button class="act danger" onclick="svc(${esc(JSON.stringify(x.unit))},'stop')">Stop</button>`:`<button class="act" onclick="svc(${esc(JSON.stringify(x.unit))},'start')">Start</button>`}${x.watched?`<button class="act ghost" title="Stop listing this unit here while it is not running" onclick="svcForget(${esc(JSON.stringify(x.unit))})">Forget</button>`:''}</div></td></tr>`).join('')}</table></div><h3>Manual control</h3><p class="muted">For a unit that is not listed above. The name may be typed with or without the <code>.service</code> suffix. Enter runs Start.</p><div class="toolbar"><input id="svcname" placeholder="bluetooth (or bluetooth.service)" value="${esc(MANUAL_UNIT)}" onkeydown="if(event.key==='Enter'){manualSvc('start')}" oninput="MANUAL_UNIT=this.value"><button class="act" onclick="manualSvc('start')">Start</button><button class="act" onclick="manualSvc('restart')">Restart</button><button class="act danger" onclick="manualSvc('stop')">Stop</button><button class="act" onclick="manualSvc('enable')">Enable</button><button class="act danger" onclick="manualSvc('disable')">Disable</button></div><pre id="r"></pre></div>`}
if(p==='reports'){let r=await api('/api/reports');a.innerHTML=`<div class="card"><h2>Reports</h2><p class="muted">Every report is deleted automatically once it is ${esc(REPORT_DAYS)} days old, so reports never fill up the disk (<code>report_retention_days</code> in the configuration).</p><div class="scroll"><table><tr><th>Report</th><th>Action</th></tr>${(r.reports||[]).map(x=>`<tr><td>${esc(x)}</td><td><div class="incident-actions"><button class="act" onclick="readReport(${esc(JSON.stringify(x))})">View</button><button class="act danger" onclick="deleteReport(${esc(JSON.stringify(x))})">Delete</button></div></td></tr>`).join('')||'<tr><td colspan="2" class="muted">No reports yet.</td></tr>'}</table></div></div><div id="reportview"></div>`}
if(p==='logs'){await renderLogs('locsecd')}
if(p==='troubleshooting'){a.innerHTML=TROUBLESHOOTING_HTML}
if(p==='help'){a.innerHTML=HELP_HTML}
}

async function showJob(){
  // Which maintenance job holds the lock, so a refused button explains itself.
  try{
    let j=await api('/api/job'); let el=document.getElementById('jobnow'); if(!el) return;
    if(j.running){ let m=Math.floor((Date.now()/1000-j.running.since)/60);
      el.innerHTML='<span class="pill" style="background:rgba(255,181,71,.14);color:var(--warn)">Running now</span> '+esc(j.running.name)+' ('+esc(j.running.origin)+'), started '+esc(new Date(j.running.since*1000).toLocaleTimeString())+', '+(m<1?'under a minute':m+' min')+' ago.';
    } else if(j.external){ el.innerHTML='<span class="pill warn">AIDE running, not started by LocSec</span> '+esc(j.external.message);
    } else el.textContent='No maintenance job is running.';
    let sch=document.getElementById('schedule'); if(sch) sch.innerHTML=scheduleHtml(j.schedule);
  }catch(e){}
}
async function aideAcceptPending(btn){
  if(!await uiConfirm('Accept pending AIDE baseline','Accept /var/lib/aide/aide.db.new as the active AIDE baseline? This records current changes as accepted. The previous baseline will be retained as aide.db.locsec-backup.','Accept',false)) return;
  await run('/api/aide/accept',{confirm:'ACCEPT_PENDING'},btn);
}
async function aideReinitialize(btn){
  if(!await uiConfirm('Rebuild AIDE baseline','Build the AIDE baseline from the current filesystem? If a baseline already exists it is replaced, so review the AIDE report first. On a machine with no baseline yet this creates the first one.','Rebuild',true)) return;
  await run('/api/aide/reinitialize',{confirm:'REPLACE_BASELINE'},btn);
}

function fmtWhen(t){return t?new Date(t*1000).toLocaleString([], {year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):''}
function blocksCard(b){
  const rows=b.blocks||[];const by={};rows.forEach(x=>{by[x.who||'unknown']=(by[x.who||'unknown']||0)+1});
  const who=Object.entries(by).sort((p,q)=>q[1]-p[1]).map(([k,v])=>`<b>${esc(v)}</b> from ${esc(k)}`).join(', ');
  return `<div class="card"><h2>Blocked computers</h2>
<p>These are computers LocSec will not let talk to this one. Each row says <b>what</b> is blocked, <b>why</b>, and <b>who said</b> it is bad. Every block goes away by itself on the date shown.</p>
<p class="muted">LocSec blocks computers by their internet address (IP). It does not block ads or websites by name: when a list says an address was handing out a harmful download, the address it was seen at is shown, so you know what it was. Web addresses here are shown as text on purpose, so they cannot be clicked by accident.</p>
${rows.length?`<p class="muted">${esc(b.total)} blocked${b.total>rows.length?` (newest ${rows.length} shown; the full list is /var/lib/locsecd/blocks.json)`:''}: ${who}.</p>`:''}
<div class="scroll tall"><table><tr><th style="width:24%">What is blocked</th><th>Why, in plain words</th><th style="width:20%">Who said so</th><th style="width:14%">Blocked / lifts</th><th>Action</th></tr>${rows.map((x,n)=>`<tr><td><b>${esc(x.address)}</b><br><span class="muted">${esc(x.what)}</span>${x.seen_at?`<br><span class="muted">Harmful download seen at:</span><br><code class="wrap">${esc(x.seen_at)}</code>`:''}</td><td>${esc(x.why)}${x.trust?`<br><span class="muted"><b>Can you trust this?</b> ${esc(x.trust)}</span>`:''}</td><td>${esc(x.who)}${x.ref?`<br><span class="muted">Reference ${esc(x.ref)}</span>`:''}${x.ref_page?`<br><span class="muted">Look it up:</span><br><code class="wrap">${esc(x.ref_page)}</code>`:''}</td><td>${esc(fmtWhen(x.added))}<br><span class="muted">lifts ${x.expires?esc(fmtWhen(x.expires)):'after 30 days'}</span></td><td><div class="incident-actions"><button class="act danger" onclick="unblock(window._blk[${n}].key)">Unblock</button></div></td></tr>`).join('')||'<tr><td colspan="5" class="muted">Nothing is blocked right now.</td></tr>'}</table></div></div>`;
}
async function manualBlock(){let x=document.getElementById('ip').value;if(x){await run('/api/block',{ip:x,reason:'manual dashboard block'});page('firewall')}}
async function portRule(action){let port=Number(document.getElementById('fwport').value),proto=document.getElementById('fwproto').value;if(Number.isInteger(port)&&port>=1&&port<=65535){await run('/api/port/'+action,{port:String(port),proto});page('firewall')}else{flash('Enter a port between 1 and 65535.')}}
async function incidentAction(id,action){
  let j=await api('/api/incident/action',{method:'POST',body:JSON.stringify({id,action})});
  if(!j||!j.ok){flash((j&&j.error)||'That did not work.');return}
  const x=j.explain||{}, i=j.incident||{};
  const hist=(j.actions||[]).map(a=>new Date((a.ts||0)*1000).toLocaleString()+'  '+a.action+': '+a.message).join(NL);
  const title={explain:'What happened',fix:'Fix it',resolve:'Marked solved'}[action]||'Result';
  const body=`<div class="story">${lvlPill(x.level||'info')} <b>${esc(KIND_LABEL[i.kind]||i.kind||'')}</b>${i.count>1?` <span class="rep">(seen ${esc(i.count)} times)</span>`:''}<h3>What happened</h3><p>${esc(x.happened||'')}</p><h3>What LocSec did</h3><p>${esc(x.did||'')}</p><h3>What you should do</h3><div class="fix">${esc(x.todo||'')}</div>${x.can_fix&&action!=='fix'?'<p class="muted">LocSec can do this for you: close this and press <b>Fix it</b>.</p>':''}</div><details class="raw"><summary>Technical details (for experts)</summary><pre>${esc((j.evidence?j.evidence+NL+NL:'')+'History:'+NL+hist)}</pre></details>`;
  const text='What happened: '+(x.happened||'')+NL+NL+'What LocSec did: '+(x.did||'')+NL+NL+'What you should do: '+(x.todo||'');
  showSheet(title,'',body,text,()=>page('incidents'));
}
function uiConfirm(title,message,okLabel,danger){
  return new Promise(resolve=>{
    let d=document.createElement('div');
    d.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:9999;display:flex;align-items:center;justify-content:center;padding:24px';
    d.innerHTML='<div class="card" role="dialog" aria-modal="true" style="max-width:460px;width:100%;margin-bottom:0"><h2>'+esc(title)+'</h2><p class="muted" style="white-space:pre-line">'+esc(message)+'</p><div class="toolbar" style="justify-content:flex-end;margin-bottom:0"><button class="act ghost" id="ui-cancel">Cancel</button><button class="act'+(danger?' danger':'')+'" id="ui-ok">'+esc(okLabel||'OK')+'</button></div></div>';
    document.body.appendChild(d);
    let onKey=e=>{if(e.key==='Escape')done(false)};
    let done=v=>{document.removeEventListener('keydown',onKey);d.remove();resolve(v)};
    document.addEventListener('keydown',onKey);
    d.onclick=e=>{if(e.target===d)done(false)};
    document.getElementById('ui-cancel').onclick=()=>done(false);
    let ok=document.getElementById('ui-ok');ok.onclick=()=>done(true);ok.focus();
  });
}
async function qAdd(btn){
  let path=document.getElementById('mal').value.trim(); if(!path){show('Enter an absolute file path.');return}
  let x=await run('/api/quarantine',{path:path,force:document.getElementById('malforce').checked,anyway:document.getElementById('malany').checked},btn);
  if(x&&x.ok) page('malware');
}
async function qDetect(n,btn){
  let d=(window._qdet||[])[n]; if(!d) return;
  // Never force on the first attempt: a ClamAV false positive on a system binary
  // would be moved out from under a running system with one unconfirmed click.
  let b={path:d.indicator,signature:d.detail||'detected',incident_id:d.id};
  let x=await run('/api/quarantine',b,btn);
  if(x&&x.error&&/system directory/.test(x.error)){
    if(!await uiConfirm('Quarantine a system file',x.error+'\\n\\nQuarantine it anyway?','Quarantine anyway',true)) return;
    x=await run('/api/quarantine',Object.assign({force:true},b),btn);
  }
  if(x&&x.ok) page('malware');
}
async function qRestore(n){
  let it=(window._qitems||[])[n]; if(!it) return;
  if(!await uiConfirm('Restore file','Put this file back at '+it.original_path+'? It was quarantined for a reason: only restore it if you are sure it is safe.','Restore',false)) return;
  let x=await run('/api/quarantine/restore',{id:it.id,overwrite:false});
  if(x&&x.error&&/already exists/.test(x.error)){
    if(await uiConfirm('Replace existing file',x.error+' Replace it with the quarantined copy?','Replace',true)) x=await run('/api/quarantine/restore',{id:it.id,overwrite:true});
  }
  if(x&&x.ok) page('malware');
}
async function qDelete(n){
  let it=(window._qitems||[])[n]; if(!it) return;
  if(!await uiConfirm('Delete quarantined file','Delete this file permanently? This cannot be undone.','Delete',true)) return;
  let x=await run('/api/quarantine/delete',{id:it.id});
  if(x&&x.ok) page('malware');
}
async function qDeleteAll(){
  if(!await uiConfirm('Delete all quarantined files','Delete ALL quarantined files permanently? This cannot be undone.','Delete all',true)) return;
  let x=await run('/api/quarantine/delete-all',{});
  if(x&&x.ok) page('malware');
}
async function deleteIncident(id){
  if(!await uiConfirm('Delete incident','Delete this incident and its action log from the dashboard permanently? This cannot be undone.','Delete',true)) return;
  await api('/api/incident/delete',{method:'POST',body:JSON.stringify({id})});
  page('incidents');
}
async function deleteAllIncidents(){
  if(!await uiConfirm('Delete all incidents','Delete ALL incidents permanently? This cannot be undone.','Delete all',true)) return;
  await api('/api/incident/delete-all',{method:'POST',body:'{}'});
  page('incidents');
}
function fmtBytes(n){
  n=Number(n)||0;
  if(n<1024) return n+' B';
  const u=['KB','MB','GB','TB']; let i=-1;
  do{ n/=1024; i++; }while(n>=1024 && i<u.length-1);
  return n.toFixed(n<10?1:0)+' '+u[i];
}
async function refreshLogs(){
  // The page only reloaded when the source dropdown changed, so watching a
  // log meant re-picking the same entry. This re-reads the current source
  // and the sizes alongside it. renderLogs rebuilds the DOM, so the button
  // is looked up by id each time rather than held across the rebuild.
  const el=document.getElementById('logsrc');
  const src=el?el.value:'locsecd';
  const btn=document.getElementById('logrefresh');
  if(btn) btn.disabled=true;
  try{ await renderLogs(src); }
  catch(e){ const b=document.getElementById('logrefresh'); if(b) b.disabled=false; flash(e.message); }
}
async function clearLog(key){
  if(!await uiConfirm('Clear this log?','The file is emptied in place, not deleted, so logging continues normally. Its rotation is unchanged. This cannot be undone, and the action itself is recorded as an incident.','Clear',true)) return;
  let x=await run('/api/log/clear',{source:key});
  await renderLogs(document.getElementById('logsrc')?document.getElementById('logsrc').value:key);
  let r=document.getElementById('r');
  if(r&&x) r.textContent=x.ok?(x.output||'Cleared.'):('Error: '+(x.error||'could not clear that log'));
}
const NL=String.fromCharCode(10);
// An opened "Show the original log lines" (or full output) appears below the fold; bring it into view.
document.addEventListener('toggle',e=>{const t=e.target;if(t&&t.tagName==='DETAILS'&&t.open){const x=t.querySelector('pre')||t;setTimeout(()=>x.scrollIntoView({block:'nearest',behavior:'smooth'}),30)}},true);
function fmtEvery(sec){sec=Number(sec)||0;if(sec%604800===0)return sec===604800?'once a week':'every '+(sec/604800)+' weeks';if(sec%86400===0)return sec===86400?'once a day':'every '+(sec/86400)+' days';if(sec%3600===0)return sec===3600?'every hour':'every '+(sec/3600)+' hours';return 'every '+Math.round(sec/60)+' minutes'}
function scheduleHtml(sc){
  if(!sc||!sc.ready) return '<p class="muted">The scheduler is starting; the plan appears within a minute.</p>';
  const now=sc.now, idleFor=sc.idle_since?Math.floor((now-sc.idle_since)/60):0, idleNow=sc.idle_since&&(now-sc.idle_since)>=sc.idle_seconds;
  const capped=sc.weekly_today>=sc.weekly_per_day;
  const rows=sc.rows.map(r=>{let nxt;
    if(r.next>now) nxt=new Date(r.next*1000).toLocaleString([],{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
    else if(r.weekly&&capped) nxt='Due; waits until tomorrow (one weekly check per day)';
    else if(r.idle&&!idleNow) nxt='Due; starts when the computer is idle';
    else nxt='Due; starts within a minute';
    return `<tr><td><b>${esc(r.name)}</b></td><td>${esc(fmtEvery(r.every))}${r.idle?'<br><span class="muted">when idle</span>':''}</td><td>${r.last?esc(new Date(r.last*1000).toLocaleString([],{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})):'<span class="muted">not yet</span>'}</td><td>${esc(nxt)}</td></tr>`}).join('');
  return `<h3>Schedule</h3><p class="muted">Checks have no fixed clock time: each one is due a set time after it last ran, and the ones marked "when idle" wait until the computer has been quiet (load ${esc(sc.idle_load)} or less) for ${esc(Math.round(sc.idle_seconds/60))} minutes. Right now the load is ${esc(sc.load??'?')}${idleNow?', so the computer counts as idle':(sc.idle_since?`, quiet for ${esc(idleFor)} minute(s)`:', so it is busy')}. At most ${esc(sc.weekly_per_day)} weekly check starts per day (${esc(sc.weekly_today)} today).</p><table><tr><th>Check</th><th>How often</th><th>Last ran</th><th>Next</th></tr>${rows}</table>`;
}
const KIND_LABEL={'login-failure':'Wrong password','port-scan':'Door-checking (port scan)','block':'Computer blocked','unblock':'Computer unblocked','virus-found':'Virus found','rootkit-warning':'Rootkit warning','firewall-fallback':'Firewall was off','log-cleared':'Log emptied','service-action':'Service changed','tool-add':'Tool installed'};
const STATE_LABEL={new:'New',investigating:'Looked at',contained:'Fixed',resolved:'Solved'};
function fixHtml(f){return f?`<div class="fix"><b>What to do:</b> ${esc(f)}</div>`:''}
function repHtml(e){return e.repeat>1?` <span class="rep">(${esc(e.repeat)} times)</span>`:''}
function itemsHtml(items){return items.map(e=>`<div class="item">${lvlPill(e.lvl)} <b>${esc(e.title)}</b>${repHtml(e)}${e.more?` <span class="rep">and ${esc(e.more)} more like it</span>`:''}<div>${esc(e.text)}</div>${fixHtml(e.fix)}</div>`).join('')}
function itemsText(items){return items.map(e=>'['+(LVL[e.lvl]||LVL.info)[1]+'] '+e.title+(e.repeat>1?' ('+e.repeat+' times)':'')+(e.more?' and '+e.more+' more like it':'')+NL+e.text+(e.fix?NL+'What to do: '+e.fix:'')).join(NL+NL)}
function showSheet(title,intro,bodyHtml,text,onClose){
  let d=document.createElement('div'); d.className='modalbg';
  d.innerHTML=`<div class="card" role="dialog" aria-modal="true" style="max-width:1000px;max-height:85vh;overflow:auto;width:100%;margin-bottom:0"><h2>${esc(title)}</h2>${intro?`<p class="muted">${esc(intro)}</p>`:''}<div class="explain">${bodyHtml}</div><div class="toolbar noprint" style="margin-top:14px;margin-bottom:0"><button class="act" data-k="print">Print</button><button class="act" data-k="copy">Copy as text</button><button class="act ghost" data-k="close">Close</button></div></div>`;
  document.body.appendChild(d);
  let onKey=e=>{if(e.key==='Escape')close()};
  let close=()=>{document.removeEventListener('keydown',onKey);document.body.classList.remove('printing');d.remove();if(onClose)onClose()};
  document.addEventListener('keydown',onKey);
  d.onclick=e=>{if(e.target===d)close()};
  d.querySelector('[data-k=close]').onclick=close;
  // The class stays until the sheet closes: the desktop window turns window.print() into a
  // PDF in the background, after this handler has already returned.
  d.querySelector('[data-k=print]').onclick=()=>{document.body.classList.add('printing');window.print()};
  d.querySelector('[data-k=copy]').onclick=async ev=>{
    const full=title+NL+NL+(intro?intro+NL+NL:'')+text, b=ev.target;
    try{await navigator.clipboard.writeText(full);b.textContent='Copied'}
    catch(_){let t=document.createElement('textarea');t.value=full;document.body.appendChild(t);t.select();try{document.execCommand('copy');b.textContent='Copied'}catch(__){}t.remove()}
  };
  d.querySelector('[data-k=close]').focus();
  return d;
}
function logFixes(){
  const l=window._lastLog||{}, ev=l.events||[], aide=l.source==='aide';
  let groups=[],seen={};
  ev.filter(e=>e.lvl==='bad'||e.lvl==='warn').forEach(e=>{
    const k=e.title+'|'+(e.fix||'')+(aide?'|'+e.text:'');
    if(seen[k]){seen[k].more=(seen[k].more||0)+1}else{seen[k]=Object.assign({},e);groups.push(seen[k])}
  });
  if(aide&&ev.length&&ev[0].lvl!=='warn'&&ev[0].lvl!=='bad') groups.unshift(ev[0]);
  if(!groups.length) groups=[{lvl:'good',title:'Nothing needs fixing',text:'Nothing in this log needs a look right now.',fix:''}];
  const order={bad:0,warn:1,good:2,info:3}; if(!aide) groups.sort((a,b)=>order[a.lvl]-order[b.lvl]);
  showSheet('What to do: '+(l.label||'log'),'Everything in this log that needs a look, in plain words, with how to fix it. Made '+new Date().toLocaleString()+'.',itemsHtml(groups),itemsText(groups));
}
const LOG_INTRO={
 locsecd:`This is LocSec's own diary. It writes down everything it does: blocking bad computers, running its checks and updating its lists.`,
 auth:`This is the log-in diary. Every time someone logs in, types a password, or uses admin powers (sudo), it is written down here.`,
 rkhunter:`rkhunter looks for "rootkits": sneaky programs that try to hide inside the system. Each line is one thing it checked, and whether it was fine.`,
 clamav:`This is the diary of the virus-list updater. ClamAV can only spot viruses it knows about, so it fetches a fresh list of them every day.`,
 aide:`AIDE takes a "photo" of every important file, and later checks each file against that photo. If a file is new, gone or changed, it is listed here. Updates change files too, so a change is not always bad.`,
 ufw:`The firewall is a wall around your computer with lots of doors (ports). When something knocks on a door you did not open, the wall says no and writes it down here. Most knocks are robots on the internet trying doors to see if any are open.`,
 syslog:`This is the computer's main diary. Every program writes notes here: things starting, things stopping, and problems.`
};
const LVL={good:['ok','Fine'],info:['note','Note'],warn:['warn','Heads up'],bad:['bad','Problem']};
let LOG_FILTER='all';
function lvlPill(l){const x=LVL[l]||LVL.info;return `<span class="pill ${x[0]}">${x[1]}</span>`}
function logWhen(e){return e.ts?esc(new Date(e.ts*1000).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit',second:'2-digit'})):esc(e.tstr||'')}
function setLogFilter(v){LOG_FILTER=v;const el=document.getElementById('logsrc');renderLogs(el?el.value:'locsecd')}
function ufwView(l,shown){
  const s=l.summary||{};
  const top=(s.top_sources||[]).map(x=>`<tr><td><b>${esc(x.ip)}</b><br><span class="muted">from ${esc(x.where)}</span></td><td>${esc(x.count)}</td><td>${esc((x.doors||[]).join(', '))}</td><td>${x.listed?'<span class="pill warn">on the block list</span> ':''}${x.scanner?'<span class="pill bad">tried lots of doors</span>':''}${(!x.listed&&!x.scanner)?'<span class="muted">just knocking</span>':''}</td></tr>`).join('');
  const doors=(s.top_doors||[]).map(d=>`<tr><td><b>${esc(d.door)}</b></td><td>${esc(d.name||'not a common door')}</td><td>${esc(d.count)}</td></tr>`).join('');
  return `<div class="fwsum"><p class="big">The wall stopped <b>${esc(s.stopped||0)}</b> knock(s)${s.allowed?` and let <b>${esc(s.allowed)}</b> through`:''}, from <b>${esc(s.sources||0)}</b> different computer(s).</p>
<div class="grid2"><div><h3>Who knocked the most</h3><table><tr><th>Computer</th><th>Knocks</th><th>Doors tried</th><th>Worry?</th></tr>${top||'<tr><td colspan="4" class="muted">Nobody.</td></tr>'}</table></div><div><h3>Doors that were knocked on</h3><table><tr><th>Door</th><th>What it is for</th><th>Knocks</th></tr>${doors||'<tr><td colspan="3" class="muted">None.</td></tr>'}</table></div></div></div>
<h3>Every knock, newest first</h3><div class="scroll tall"><table class="loglist"><tr><th style="width:130px">When</th><th style="width:96px">What the wall did</th><th style="width:170px">Who knocked</th><th style="width:170px">Which door</th><th>Why</th></tr>${shown.map(e=>{const f=e.fw||{};return `<tr class="lv-${esc(e.lvl)}"><td class="muted">${logWhen(e)}${e.repeat>1?`<br><span class="rep">${esc(e.repeat)} times</span>`:''}</td><td><span class="pill ${f.verdict==='Stopped'?'ok':'note'}">${esc(f.verdict||'Note')}</span></td><td>${f.from?`<b>${esc(f.from)}</b><br><span class="muted">${esc(f.direction==='going out'?'this computer, sending to '+(f.to||'?'):'from '+(f.from_where||'?'))}</span>`:'<span class="muted">-</span>'}${f.listed?'<br><span class="pill warn">on the block list</span>':''}</td><td>${f.door?`<b>${esc(f.door)}</b>${f.door_name?`<br><span class="muted">${esc(f.door_name)}</span>`:''}`:'<span class="muted">-</span>'}</td><td>${esc(e.text)}</td></tr>`}).join('')||'<tr><td colspan="5" class="muted">Nothing that needs a look.</td></tr>'}</table></div>`;
}
async function renderLogs(src){
  let a=document.getElementById('pagebody');
  let s=await api('/api/log-sources');
  let opts=(s.sources||[]).map(x=>`<option value="${esc(x.key)}" ${x.key===src?'selected':''}>${esc(x.label)}${x.available?'':' (no entries yet)'}</option>`).join('');
  let cur=(s.sources||[]).find(x=>x.key===src)||{};
  let l=await api('/api/logs?source='+encodeURIComponent(src));
  let ev=l.events||[]; l.label=cur.label||src; window._lastLog=l;
  let cnt={good:0,info:0,warn:0,bad:0};ev.forEach(e=>{cnt[e.lvl]=(cnt[e.lvl]||0)+1});
  let shown=LOG_FILTER==='attention'?ev.filter(e=>e.lvl==='warn'||e.lvl==='bad'):ev;
  let list;
  if(l.error) list=`<p>${esc(l.error)}</p>`;
  else if(!ev.length) list=`<p class="muted">Nothing is written here yet.</p>`;
  else if(src==='ufw') list=ufwView(l,shown);
  else list=`<div class="scroll tall"><table class="loglist"><tr><th style="width:140px">When</th><th style="width:96px">Kind</th><th>What happened</th></tr>${shown.map(e=>`<tr class="lv-${esc(e.lvl)}"><td class="muted">${logWhen(e)}</td><td>${lvlPill(e.lvl)}</td><td><b>${esc(e.title)}</b>${repHtml(e)}<br>${esc(e.text)}${fixHtml(e.fix)}</td></tr>`).join('')||'<tr><td colspan="3" class="muted">Nothing that needs a look. Everything here is fine.</td></tr>'}</table></div>`;
  let raw=(l.lines||[]).length?`<details class="raw"><summary>Show the original log lines (${esc((l.lines||[]).length)})</summary><pre>${esc((l.lines||[]).join('\\n'))}</pre></details>`:'';
  a.innerHTML=`<div class="card logcard"><h2>Security logs</h2><div class="toolbar"><label>Log: <select id="logsrc" onchange="renderLogs(this.value)">${opts}</select></label><label>Show: <select id="logfilter" onchange="setLogFilter(this.value)"><option value="all" ${LOG_FILTER==='all'?'selected':''}>Everything</option><option value="attention" ${LOG_FILTER==='attention'?'selected':''}>Only things to look at</option></select></label><button class="act" id="logrefresh" onclick="refreshLogs()">Refresh</button>${l.error?'':'<button class="act" onclick="logFixes()">What to do</button>'}${cur.clearable?`<button class="act danger" onclick="clearLog(${esc(JSON.stringify(src))})">Clear LocSec's log</button>`:''}<span class="muted">Loaded ${esc(new Date().toLocaleTimeString())}</span></div>
<p class="intro">${esc(LOG_INTRO[src]||'')}</p>
${l.error?'':`<div class="tally">${['bad','warn','good','info'].map(k=>`<span>${lvlPill(k)} ${esc(cnt[k]||0)}</span>`).join('')}<span class="muted">${src==='aide'&&(l.path||'').indexOf('aide-full-')>=0?'Most important first':'Newest first'}. ${esc(ev.length)} entries${l.path?', from '+esc(l.path):''}.</span></div>`}
${list}${raw}<pre id="r"></pre></div>`;
}
async function unblock(ip){await run('/api/unblock',{ip});page('firewall')}
async function repcheck(){show(await run('/api/reputation',{indicator:document.getElementById('rep').value}))}
async function capture(){show(await run('/api/capture/start',{iface:document.getElementById('iface').value,seconds:Number(document.getElementById('secs').value)}))}
const STATUS_LABEL={'ok':'Clean / no findings','info':'Informational (no action needed)','warning':'Warnings (review output)','findings-or-error':'Findings (review output)','timeout':'Timed out','error':'Scan error','busy':'Skipped (another job is running)','not-installed':'Tool not installed','not-initialized':'Not initialized yet','skipped':'Skipped (not applicable on this OS)'};
function statusPill(status,rc){
  let label = STATUS_LABEL[status] || status || (rc===0?'OK':(rc!==undefined?`Exit code ${esc(rc)}`:''));
  let cls = (status==='ok'||status==='info'||(rc===0&&!status)) ? 'ok' : (status==='not-installed'||status==='skipped'||status==='not-initialized'||status==='busy'||status==='warning') ? '' : 'bad';
  return `<span class="pill ${cls||'bad'}" style="${cls?'':'background:rgba(255,181,71,.14);color:var(--warn)'}">${esc(label)}</span>`;
}
function renderAptUpgrade(text){
  let rows=[];
  (text||'').split('\\n').forEach(line=>{
    let m=line.match(/^Inst (\\S+) \\[(.*?)\\] \\((\\S+)/);
    if(m) rows.push({pkg:m[1],old:m[2],neu:m[3]});
  });
  if(!rows.length) return `<p class="muted">No pending security/maintenance updates found.</p>`;
  return `<p class="muted">${rows.length} package(s) have an update available (security or maintenance):</p><table><tr><th>Package</th><th>Installed</th><th>Available</th></tr>${rows.map(r=>`<tr><td>${esc(r.pkg)}</td><td>${esc(r.old)}</td><td>${esc(r.neu)}</td></tr>`).join('')}</table>`;
}
const PRE_MAX=200000;
function capText(t){
  t=String(t??'');
  return t.length>PRE_MAX ? t.slice(0,PRE_MAX)+'\\n\\n... display truncated at '+PRE_MAX+' characters. Open the report file on disk for the rest.' : t;
}
function renderResult(r){
  const name=r.name||'Result';
  const body = (name==='APT security candidates') ? renderAptUpgrade(r.output) : `<pre>${esc(capText(r.output!==undefined?r.output:JSON.stringify(r,null,2)))}</pre>`;
  const note = r.note ? `<div class="banner show" style="position:static;margin-bottom:12px"><span>${esc(r.note)}</span></div>` : '';
  const ex = Array.isArray(r.explain)&&r.explain.length ? `<div class="explain">${itemsHtml(r.explain)}</div>` : '';
  const changedList = Array.isArray(r.changed) ? (r.changed.length?`<p class="muted">${r.changed.length} package(s) applied:</p><ul style="margin:0 0 10px;padding-left:18px">${r.changed.map(c=>`<li>${esc(c)}</li>`).join('')}</ul>`:'<p class="muted">No packages were applied.</p>') : '';
  const shown = ex ? (name==='APT security candidates' ? ex+body : ex+`<details class="raw"><summary>Show the full output</summary>${body}</details>`) : body;
  return `<div class="card"><h3>${esc(name)} ${statusPill(r.status,r.rc)}</h3>${note}${changedList}${shown}</div>`;
}
function renderReport(x){
  if(!x||!x.ok) return `<div class="card"><p class="bad">${esc((x&&x.error)||'Could not load report.')}</p></div>`;
  const rep=x.report||{};
  const when=rep.ts?new Date(rep.ts*1000).toLocaleString():'';
  let body;
  if(Array.isArray(rep.results)) body=rep.results.map(renderResult).join('');
  else if(rep.result) body=renderResult(Object.assign({name:'Result'},rep.result));
  else body=`<pre>${esc(capText(JSON.stringify(rep,null,2)))}</pre>`;
  const note = x.summarized ? `<p class="muted">Large report: shown as a summary. The complete document is on disk under /var/lib/locsecd/reports/.</p>` : '';
  window._lastReport=x;
  const fixBtn = (rep.results||[rep.result||{}]).some(r=>r&&Array.isArray(r.explain)&&r.explain.length) ? `<div class="toolbar" style="margin-bottom:0"><button class="act" onclick="reportFixes()">What to do</button></div>` : '';
  return `<div class="card"><h2>${esc(x.name)}</h2><p class="muted">${esc(when)}</p>${note}${fixBtn}</div>${body}`;
}
function reportFixes(){
  const x=window._lastReport||{}, rep=x.report||{}, res=Array.isArray(rep.results)?rep.results:(rep.result?[Object.assign({name:'Result'},rep.result)]:[]);
  let html='',text='';
  res.filter(r=>Array.isArray(r.explain)&&r.explain.length).forEach(r=>{html+=`<h3>${esc(r.name||'Result')}</h3>`+itemsHtml(r.explain);text+=(r.name||'Result').toUpperCase()+NL+itemsText(r.explain)+NL+NL});
  const when=rep.ts?new Date(rep.ts*1000).toLocaleString():'';
  showSheet('What to do: '+(x.name||'report'),'What each check found, in plain words, with how to fix it. Report from '+when+'.',html||'<p>Nothing to show.</p>',text);
}
async function readReport(name){
  const target=document.getElementById('reportview');
  const x=await run('/api/report/read',{name});
  if(target) target.innerHTML=renderReport(x);
}
async function deleteReport(name){await run('/api/report/delete',{name});page('reports')}
async function analyzeCapture(name){const i=document.getElementById('capname');if(i)i.value=name;await run('/api/capture/analyze',{name:name})}
// The redraw after an action rebuilds the manual-control input, which used to
// clear whatever had been typed -- so a start-then-enable on the same unit
// meant typing the name twice. Keep it across redraws.
let MANUAL_UNIT='';
async function manualSvc(action){
  let el=document.getElementById('svcname');
  if(el) MANUAL_UNIT=el.value;
  if(!MANUAL_UNIT.trim()){ show('Enter a unit name first.'); return; }
  await svc(MANUAL_UNIT,action);
}
async function svcForget(unit){
  let x=await run('/api/service/forget',{unit});
  await page('services');
  let r=document.getElementById('r');
  if(r&&x) r.textContent=x.ok?(x.output||`${unit} removed from the list.`):('Error: '+(x.error||'could not remove that unit'));
}
async function svc(unit,action){
  if(!unit)return;
  let x=await run('/api/service/action',{unit,action});
  // The redraw below rebuilds the page and with it the output box, so the
  // result has to be written back afterwards. Without this every action --
  // including every failure and its reason -- was erased the instant it
  // arrived, and the page simply redrew, which is why a refused stop or
  // restart looked like a button that did nothing at all.
  await page('services');
  let r=document.getElementById('r'); if(!r||!x) return;
  if(x.ok===false||x.error){
    r.textContent=(x.error?x.error:`${action} ${unit} failed`)
      +(x.rc!==undefined?` (exit ${x.rc})`:'')
      +(x.before!==undefined?`\nstate: ${x.before} -> ${x.after}`:'')
      +(x.output?`\n\n${x.output}`:'');
  }else{
    r.textContent=`${action} ${unit}: ok`
      +(x.before!==undefined?` (${x.before} -> ${x.after})`:'')
      +(x.output?`\n\n${x.output}`:'');
  }
}
async function savePolicy(){
  try{
    let b={auto_block:pol_auto.checked,response_auth_block:pol_auth.checked,response_feed_block:pol_feed.checked,ipv6_auto_block:pol_v6.checked,response_scan_block:pol_scan.checked,fallback_firewall:pol_fb.checked};
    let x=await api('/api/response-policy',{method:'POST',body:JSON.stringify(b)});
    let ch=Object.entries(x.changed||{}).map(([k,v])=>k+' = '+v).join(', ');
    document.getElementById('policyout').textContent=x.ok?('Saved. Applies immediately and survives restarts.'+(ch?'\\n'+ch:'')):JSON.stringify(x);
  }catch(e){ flash(e.message); }
}
async function loadPolicy(){
  try{
    let x=await api('/api/response-policy');let p=x.policy||{};
    for(let [id,k] of [['pol_auto','auto_block'],['pol_auth','response_auth_block'],['pol_feed','response_feed_block'],['pol_v6','ipv6_auto_block'],['pol_scan','response_scan_block'],['pol_fb','fallback_firewall']]){let e=document.getElementById(id);if(e)e.checked=!!p[k]}
  }catch(e){ flash(e.message); }
  loadNotifySettings();
}
// --- Desktop notifications -------------------------------------------------
// Maps the checkbox id shown on the Incidents page to the incident "kind"
// the daemon records. The daemon sends the notification itself; this page only
// edits which kinds are enabled and can send a test.
const NOTIFY_KINDS={ntf_virus:'virus-found',ntf_rootkit:'rootkit-warning',ntf_block:'block',ntf_login:'login-failure',ntf_scan:'port-scan',ntf_fb:'firewall-fallback'};
async function saveNotifySettings(){
  try{
    let b={}; for(let [id,kind] of Object.entries(NOTIFY_KINDS)){let e=document.getElementById(id); if(e) b[kind]=e.checked}
    await api('/api/notify-settings',{method:'POST',body:JSON.stringify(b)});
    document.getElementById('notifyout').textContent='Saved. Applies immediately and survives restarts.';
  }catch(e){ flash(e.message); }
}
async function loadNotifySettings(){
  try{
    let x=await api('/api/notify-settings');
    for(let [id,kind] of Object.entries(NOTIFY_KINDS)){let e=document.getElementById(id); if(e) e.checked=!!(x.notify_on||{})[kind]}
  }catch(e){ /* Incidents page may not be open; ignore. */ }
}
async function testNotification(){
  try{
    let x=await api('/api/notify-test',{method:'POST',body:'{}'});
    document.getElementById('notifyout').textContent=x.ok?'Test notification sent to '+x.sessions+' desktop session(s).':(x.error||'Not sent.');
  }catch(e){ flash(e.message); }
}

async function healthPing(){
  const dot=document.getElementById('hdot'),txt=document.getElementById('htext');
  try{
    await api('/api/health');
    dot.className='dot up'; txt.textContent='Service online';
    if(document.getElementById('jobnow')) showJob();
  }catch(e){
    dot.className='dot down'; txt.textContent='Service unreachable';
  }
}

const TROUBLESHOOTING_HTML=`
<div class="card"><h2>Troubleshooting</h2><p class="muted">Start with the symptom, then follow the checks in order. Every command below can be run from a terminal; anything that needs root is shown with <code>sudo</code>. For deeper diagnosis, open the <a href="#ts-log">Logs page</a> or run <code>locsecctl logs</code>.</p>
<table><tr><th>Area</th><th>Symptoms covered</th></tr>
<tr><td><a href="#ts-service">Service &amp; access</a></td><td>Dashboard unreachable, missing token, password prompt, "not in the sudoers file", blank desktop window, panel icon</td></tr>
<tr><td><a href="#ts-status">Reading scan statuses</a></td><td>What each status label means and when to act</td></tr>
<tr><td><a href="#ts-clamav">ClamAV</a></td><td>Errors, repeated summaries, scan scope, AppArmor messages, clamscan vs clamdscan</td></tr>
<tr><td><a href="#ts-aide">AIDE</a></td><td>Timeouts, a slow Rebuild or Initialize, differences after updates, pending database</td></tr>
<tr><td><a href="#ts-quarantine">Quarantine</a></td><td>A file will not quarantine or restore, older items, where quarantined files live</td></tr>
<tr><td><a href="#ts-lynis">Lynis &amp; rkhunter</a></td><td>Informational warnings, sandbox messages, hidden files</td></tr>
<tr><td><a href="#ts-cve">CVE scan &amp; reports</a></td><td>What the CVE scan covers, large reports</td></tr>
<tr><td><a href="#ts-updates">Updates</a></td><td>Updates that do not apply, held packages, apt lock</td></tr>
<tr><td><a href="#ts-fallback">UFW is off: fallback firewall and port-scan blocks</a></td><td>What protects the machine while UFW is disabled, and what a scan block means</td></tr>
<tr><td><a href="#ts-schedule">Schedules &amp; jobs</a></td><td>Scans that never start, "another job is running", threat feeds failing to update</td></tr>
<tr><td><a href="#ts-notify">Notifications</a></td><td>No desktop notification appears</td></tr>
<tr><td><a href="#ts-incidents">Incident grouping</a></td><td>Repeat rows for one address, a count that stopped rising</td></tr>
<tr><td><a href="#ts-services">Services page</a></td><td>Stop/Restart not working, why an action failed, services disappearing from the list</td></tr>
<tr><td><a href="#ts-exited">Service state</a></td><td>ufw or another unit shown as "exited" while it is running</td></tr>
<tr><td><a href="#ts-bounce">Service will not stop</a></td><td>A stopped unit restarts itself, or its row disappears</td></tr>
<tr><td><a href="#ts-manual">Manual control</a></td><td>"invalid unit name"; enable/disable results; masked units</td></tr>
<tr><td><a href="#ts-verify">Verifying the install</a></td><td>Checking installed files against what the package shipped</td></tr>
<tr><td><a href="#ts-logsrc">Logs page sources</a></td><td>Sources shown as "not found" or "(no entries yet)", especially on Debian</td></tr>
<tr><td><a href="#ts-logs">Log and report disk use</a></td><td>Whether logs or reports fill up the disk, and clearing LocSec's log</td></tr>
<tr><td><a href="#ts-kill">Stop, restart, kill</a></td><td>What each leaves behind, and what a kill can lose</td></tr>
<tr><td><a href="#ts-harden">Post-install changes</a></td><td>The kernel hardening the package applies, and how to revert it</td></tr>
<tr><td><a href="#ts-log">Collecting diagnostics</a></td><td>What to gather before asking for help</td></tr>
</table></div>

<div class="card" id="ts-service"><h2>Service &amp; access</h2>
<h3>Dashboard unreachable, or "service not running / API token missing"</h3>
<ol>
<li>Check the service: <code>locsecctl status</code>. If it is not active, run <code>sudo systemctl restart locsecd.service</code> and read <code>locsecctl logs</code> for the reason.</li>
<li>Confirm the listener: <code>sudo ss -ltnp | grep 8765</code>. The dashboard binds to <code>127.0.0.1:8765</code> (the port is <code>port</code> in the configuration). It only ever listens on this machine. <code>listen</code> stays in the configuration at <code>127.0.0.1</code> so the address is visible, but it is pinned: from 4.0.11-62 any other value is replaced by 127.0.0.1 and the log says so, because the dashboard is a root control panel and must never be reachable from the network. Requests addressed to any other host name are refused (421), which stops DNS-rebinding pages.</li>
<li>The API token lives in <code>/var/lib/locsecd/api.token</code> and is readable only by root. The desktop app reads it through a one-time <code>pkexec</code> prompt (packages <code>pkexec</code> and <code>polkitd</code>). GNOME, KDE Plasma, Cinnamon, MATE and LXQt provide the polkit agent that shows that prompt. On a session with no agent (bare Xfce, i3 and other window managers) the app asks for your <code>sudo</code> password instead; to get the normal prompt there, install one agent, e.g. <code>sudo apt install mate-polkit</code>, and log in again.</li>
<li><b>Ubuntu 22.04 and Linux Mint 21</b> do not package PyQt6, so the desktop window cannot be installed there. "LocSec Security Center" then opens the dashboard in your default browser instead. It reads the token through <code>pkexec</code> as usual, sends it once in a request header to get a single-use login code that is valid for 60 seconds, and opens the browser with only that code in the address. The long-lived token never reaches browser history, and a code copied from history afterwards is refused. If the browser shows "login code expired or already used", open LocSec again. On releases that do package it, <code>sudo apt install python3-pyqt6.qtwebengine</code> brings back the desktop window.</li>
<li>The <code>sudo</code> fallback only works if your account may use sudo. "<i>user</i> is not in the sudoers file" means it may not: Debian 13 does not add the first user to the <code>sudo</code> group when a root password is set during installation. Become root with <code>su -</code>, run <code>usermod -aG sudo <i>user</i></code>, then log out and back in. <code>groups</code> should then list <code>sudo</code>. Until then, run privileged commands from this page as root via <code>su -</code>.</li>
</ol>
<h3>Calling the API from a script</h3>
<p>Every JSON endpoint requires the token in an <code>X-LocSec-Token</code> header. The dashboard page itself is opened with a single-use login code (<code>POST /api/login-code</code>, then <code>/dashboard?code=...</code>); the <code>?token=</code> parameter is no longer accepted.</p>
<pre>TOKEN=$(sudo cat /var/lib/locsecd/api.token)
curl -s -X POST http://127.0.0.1:8765/api/scan-job -H "X-LocSec-Token: $TOKEN" -H "Content-Type: application/json" -d '{"job":"clamav"}'</pre>
<h3>Desktop window is blank or white</h3>
<p>Some hybrid-graphics, virtual-machine and XWayland setups fail to render the embedded view. GPU acceleration is already disabled in the app. If the window is still blank, launch it once with <code>QTWEBENGINE_DISABLE_SANDBOX=1 locsec-gui</code> (this disables the Chromium sandbox; use it only on a trusted desktop session), or open <code>http://127.0.0.1:8765/dashboard</code> in a normal browser.</p>
<h3>Panel icon</h3>
<p>From 4.0.11-63 LocSec puts a shield icon in the panel's status area (next to the clock, volume and network icons) when you log in, and that icon is LocSec's only panel entry: the window is kept off the taskbar. The icon is blue while <code>locsecd</code> is running and turns amber with an exclamation mark, with a notification, when the service stops or fails. Click it to show or hide the dashboard; its menu has <b>Open LocSec Security Center</b>, the service state, <b>Start at login</b> and <b>Quit panel icon</b>. Closing the window hides it to the panel. Quitting the icon only closes the desktop app; the <code>locsecd</code> service keeps protecting the machine. Opening LocSec again from the applications menu, or running <code>locsecctl tray</code>, brings the icon back. Only one copy runs per user. No password is asked at login; the dashboard asks for it the first time you open the window.</p>
<ul>
<li><b>GNOME</b> on Debian shows panel icons only through the AppIndicator extension: <code>sudo apt install gnome-shell-extension-appindicator</code>, then log out and back in. LocSec switches the extension on for your account if it is installed but off. Ubuntu ships it enabled.</li>
<li><b>KDE Plasma, Cinnamon, Xfce, MATE, LXQt</b> show it with no extra setup. On Xfce or MATE the panel needs its Status Tray / Notification Area item (present by default).</li>
<li>To stop it starting at login, untick <b>Start at login</b> in its menu (per user), or remove it in your desktop's Startup Applications. The system-wide entry is <code>/etc/xdg/autostart/locsec-tray.desktop</code>.</li>
<li>On a Wayland session other than GNOME the window runs through XWayland so it can stay off the taskbar. Set <code>QT_QPA_PLATFORM=wayland</code> before launching to run it natively instead; the window then shows a taskbar button while it is open.</li>
</ul></div>

<div class="card" id="ts-status"><h2>Reading scan statuses</h2><p>Each scan result carries a status label. The label reflects what the tool actually reported, not just whether it ran.</p>
<table><tr><th>Status</th><th>Meaning</th><th>Action</th></tr>
<tr><td>Clean / no findings</td><td>The tool completed and reported nothing of concern.</td><td>None.</td></tr>
<tr><td>Informational</td><td>The tool completed; remaining output is expected noise (for example Lynis timing notes).</td><td>None. Review only if curious.</td></tr>
<tr><td>Warnings</td><td>Completed with warnings or hardening suggestions.</td><td>Review the output and the Lynis suggestions.</td></tr>
<tr><td>Findings</td><td>Completed and found something that needs a decision: infected files, changed files, rootkit warnings, open CVEs.</td><td>Open the report and act on each item.</td></tr>
<tr><td>Timed out</td><td>The job exceeded its time limit and was stopped cleanly.</td><td>Raise the matching timeout key (see AIDE below) and run it again.</td></tr>
<tr><td>Scan error</td><td>The tool failed to run or to produce usable output.</td><td>Read the output tail in the report, then see the section for that tool.</td></tr>
<tr><td>Skipped</td><td>Not applicable here (for example debsecan on Ubuntu or Mint; LMDE runs it), or another job held the lock.</td><td>None; re-run later if it was the lock.</td></tr>
<tr><td>Tool not installed / Not initialized</td><td>A required package is missing, or AIDE has no baseline yet.</td><td>Use <b>Add</b> on the Overview page, or <b>Rebuild AIDE baseline</b> on the Scans page.</td></tr>
</table></div>

<div class="card" id="ts-clamav"><h2>ClamAV</h2>
<h3>Scope and how the scan runs</h3>
<p>The scheduled ClamAV job scans the directories listed in <code>clamav_scan_paths</code> (default: <code>/home</code>) in a single pass and produces one summary. Files larger than <code>clamav_max_file_mb</code> (100 MB by default) are skipped, and the job is limited by <code>clamav_timeout</code>. Pseudo and virtual filesystems (<code>/proc</code>, <code>/sys</code>, <code>/dev</code>, <code>/run</code>, <code>/snap</code>) and eCryptFS internals are excluded through <code>clamd.conf</code> by the installer. The job runs in a separate systemd unit so that clamd receives regular file descriptors; if a batch fails as a whole, LocSec retries it through a stream scan and then through <code>clamscan</code>.</p>
<h3>Do I need both clamscan and clamdscan?</h3>
<p>Yes, keep both installed (packages <code>clamav</code> and <code>clamav-daemon</code>). Scheduled scans use <code>clamdscan</code> through the clamd daemon, which is much faster because the signature database stays loaded. <code>clamscan</code> is the fallback if clamd is down or a batch fails, and it is what scans a single file for the Malware / Quarantine page.</p>
<h3>Scan reports many errors, or shows more than one summary</h3>
<ol>
<li>Confirm you are on the current version: <code>dpkg -s locsecd | grep Version</code>. Older builds scanned the whole filesystem and printed a summary per batch.</li>
<li>Check the excludes: <code>grep ExcludePath /etc/clamav/clamd.conf</code>. Restart the daemon after editing: <code>sudo systemctl restart clamav-daemon</code>.</li>
<li>Check the daemon is healthy: <code>systemctl status clamav-daemon</code> and <code>sudo journalctl -u clamav-daemon -n 50 --no-pager</code>.</li>
<li>Add site-specific exclusions with <code>clamav_extra_excludes</code> in <code>/etc/locsecd/locsecd.conf</code>, then restart LocSec.</li>
</ol>
<h3>AppArmor "DENIED" messages for clamd</h3>
<p>Occasional entries of the form <code>Failed name lookup - disconnected path</code> mean a file was removed or renamed while it was being scanned, which is normal on a busy desktop. A sustained high rate is worth investigating: <code>sudo journalctl -k --since "1 hour ago" | grep -i "apparmor.*clamd"</code>.</p></div>

<div class="card" id="ts-aide"><h2>AIDE</h2>
<h3>Check, Initialize or Rebuild timed out</h3>
<p>One limit covers all three: <code>aide_scan_timeout</code> (10800 seconds by default). A large home directory or slow disk can need more; raise the value, restart LocSec and run the check again. AIDE runs at idle I/O priority, so it is slower on a busy machine by design.</p>
<h3>Rebuild or Initialize is taking a long time</h3>
<p>Hashing every file takes as long as a full check: minutes on a small SSD, an hour or more on a large home directory or a slow disk. It is not stuck if <code>ps -eo pid,etime,stat,pcpu,cmd | grep [a]ide</code> shows exactly one <code>aide --init</code> using CPU. The new database is written only when hashing finishes, so <code>aide.db.new</code> does not grow while it runs and memory use climbs until the end.</p>
<ul style="margin:0;padding-left:18px;line-height:1.7">
<li>Output goes to <code>/var/log/aide/aideinit.log</code> and <code>/var/log/aide/aideinit.errors</code>. A steady trickle of warnings is normal; a flood from <code>/home/.ecryptfs</code> means the eCryptfs exclude is missing.</li>
<li>It is finished when no aide process remains and the database is fresh: <code>sudo ls -l /var/lib/aide/</code>.</li>
<li>Do not click Rebuild again or start <code>aide --init</code> by hand while it runs; two writers race on the same database.</li>
<li>If it reaches <code>aide_scan_timeout</code> it is stopped and the existing baseline is left unchanged. Raise the limit or exclude large trees you do not need checked, then run it again.</li>
</ul>
<h3>Thousands of differences, or the report is cut off in the middle</h3>
<p>A desktop changes thousands of files a day that say nothing about tampering: browser caches, the software-centre icon catalogue, logs. From 4.0.11-61 an AIDE result opens with a <b>LocSec summary</b>: every change in a security-relevant place listed by name (system binaries and libraries, <code>/etc</code>, <code>/boot</code>, root's home, cron, and the login, autostart and SSH files in each home), and everything else counted by directory. The dashboard copy of the raw output is still shortened; the complete output is saved as <code>/var/lib/locsecd/reports/aide-full-&lt;time&gt;.txt</code> (the newest 10 are kept, each for 7 days). Read it with <code>sudo less</code>, or pick <b>AIDE (latest check)</b> on the Logs page.</p>
<p>The same release stops AIDE checking <code>~/.cache</code>, <code>/root/.cache</code>, <code>/var/lib/swcatalog</code> LocSec's own state and log directories, the transient units LocSec starts for each scan, its AIDE lock file and aideinit's logs, and fixes the <code>/run/user</code> exclude that still let AIDE fail on <code>/run/user/1000/doc</code> and <code>gvfs</code>. The existing baseline still contains those paths, so after reviewing the current report use <b>Rebuild AIDE baseline</b> once; later checks are then short. Add your own excludes as files in <code>/etc/aide/aide.conf.d/</code>, for example <code>!/home/[^/]+/Downloads</code>.</p>
<h3>Differences reported after package updates</h3>
<p>Upgrades legitimately change files. Review the list: changes under package-managed paths that line up with an apt upgrade (for example the Postfix chroot under <code>/var/spool/postfix</code>, which is rebuilt on every restart) are expected. Do not accept changes merely because AIDE reported them; review the differences first.</p>
<h3>Both aide.db and aide.db.new exist</h3>
<p>If <code>/var/lib/aide/aide.db.new</code> exists alongside the active database, the aide package's daily job produced a pending reference database (before 4.0.11-65 switched that job off, or because you turned it back on). Seeing both files is normal. Review the AIDE differences first, then use <b>Accept pending AIDE baseline</b> on the Scans page if you intentionally want to promote it. LocSec secures the pending file as <code>root:root</code> mode <code>0600</code>, retains the previous active database as <code>/var/lib/aide/aide.db.locsec-backup</code>, and atomically promotes the pending database.</p>
<p>If you need a completely fresh baseline instead, or the machine has no baseline yet, use <b>Rebuild AIDE baseline</b>. It is explicitly confirmed and uses AIDE's force/rebuild path, so it creates the first baseline or replaces an existing one.</p>
<h3>Useful commands</h3>
<pre>locsecctl aide-init             # initialize only if no active baseline exists
locsecctl aide-accept           # explicitly accept aide.db.new
locsecctl aide-reinitialize     # explicitly rebuild and replace the baseline
locsecctl scan-aide              # check the current baseline
sudo stat /var/lib/aide/aide.db /var/lib/aide/aide.db.new
sudo journalctl -u dailyaidecheck.service --since "yesterday"
systemctl cat dailyaidecheck.service</pre>
<h3>Pending database has the wrong owner</h3>
<p><code>aide.db.new</code> may be created by Debian's AIDE job as user <code>_aide</code>. That is expected. Do not manually copy it over <code>aide.db</code>. Use <b>Accept pending AIDE baseline</b>, which validates and changes ownership to <code>root:root</code> mode <code>0600</code> before the atomic replacement.</p>
<h3>Pending database is present but should not be accepted</h3>
<p>Leave <code>aide.db.new</code> in place while investigating. It is evidence of the database produced by the daily job. If you decide the changes should not become the new baseline, leave the active <code>aide.db</code> unchanged and let the next AIDE cycle produce a new pending database according to Debian's configuration.</p>
<h3>AIDE runs every day, or "No maintenance job is running" while AIDE uses the CPU</h3>
<p>That is the aide package's own daily check, <code>dailyaidecheck</code>, which runs a full AIDE check every day as the <code>_aide</code> user. It is not a LocSec job, so the Scans page said no job was running while <code>top</code> showed <code>_aide</code> near 100% CPU. LocSec already checks AIDE once a week, so from 4.0.11-65 the installer switches the daily check off (<code>systemctl disable --now dailyaidecheck.timer</code>), and the Scans page now says when an AIDE run LocSec did not start is going. A run already in progress during the upgrade is left to finish: stopping it part-way could leave a half-written <code>aide.db.new</code>. Removing LocSec switches the daily check back on if LocSec was what turned it off.</p>
<p>Check it with <code>systemctl is-enabled dailyaidecheck.timer</code> (should print <code>disabled</code>). If you want the daily check anyway, <code>sudo systemctl enable --now dailyaidecheck.timer</code>; LocSec shares <code>/run/lock/locsecd-aide.lock</code> with it so the two never run together.</p></div>

<div class="card" id="ts-quarantine"><h2>Quarantine</h2>
<h3>Where quarantined files live</h3>
<p>In <code>/var/lib/locsecd/quarantine</code>, root-only. Each item is a <code>.qf</code> data file and a <code>.json</code> record of its original path, owner, mode, size, SHA-256 and detection name. Back this directory up if you want quarantined files to survive a purge.</p>
<h3>A file will not quarantine</h3>
<ul style="margin:0;padding-left:18px;line-height:1.7">
<li><b>ClamAV found nothing in this file</b>: it is clean as far as ClamAV can tell. Tick <b>Quarantine even if clean</b> to quarantine it anyway.</li>
<li><b>Under a system directory</b>: tick <b>Force</b> only if you are sure; quarantining a system binary can break the system.</li>
<li><b>Is a symbolic link</b>: links are never followed. Quarantine the file it points to.</li>
<li><b>Quarantine helper is missing</b>: reinstall the package. The helper is <code>/usr/lib/locsecd/locsec-quarantine</code>, root, mode 0700.</li>
</ul>
<h3>Restore is refused</h3>
<ul style="margin:0;padding-left:18px;line-height:1.7">
<li><b>Already exists</b>: a file is at the original path. Confirm the prompt to replace it, or move it first.</li>
<li><b>Directory no longer exists, or is now a symlink</b>: recreate the directory, or delete the item instead. LocSec will not write through a symlinked directory.</li>
<li><b>Does not match its recorded checksum</b>: the quarantined data was altered, so it is not restored. Delete it.</li>
<li><b>No Restore button</b>: the file was quarantined by a version older than the one that records locations. It can only be deleted.</li>
</ul>
<p>Restored files get their original owner, permissions and modification time, but never setuid or setgid bits. A restored file that was detected as malware will be detected again by the next scan.</p></div>

<div class="card" id="ts-lynis"><h2>Lynis &amp; rkhunter</h2>
<h3>Lynis</h3>
<p>Lynis runs in a separate systemd unit with full capabilities, so the privilege-drop errors seen in older builds no longer occur. Results come from the Lynis report file: the hardening index, the warnings and the suggestions, all listed in the scan result. Slow-test timing notes, device-mapper messages and <code>pgrep</code> chatter are informational and do not change the status.</p><p><b>Warnings</b> are what to review first. <b>Suggestions</b> are hardening opportunities, not findings: Lynis is written for servers, so on a desktop many of them do not apply, and the hardening index is a ratio of tests passed against its whole catalogue rather than a security score to chase. Decide on each one deliberately, and check it against the rest of this system first — a suggestion that tightens <code>/var/log</code> so rsyslog can no longer write works against LocSec itself.</p>
<h3>rkhunter</h3>
<p>Each warning is checked before it is reported. Hidden files that belong to the system, scripts that match their package checksums (verified with <code>dpkg</code>), files owned by real login users, new system accounts and groups a package created (an unprivileged id below 1000, and for a user no login shell), and eCryptfs or LTTng tracing files in <code>/dev/shm</code> are classed as informational. Anything else is a finding, including a new account with uid 0 or a login shell, and any change to an existing group's members, such as a user added to <code>sudo</code>. rkhunter compares against its own snapshot: after reviewing a report, <code>sudo rkhunter --propupd</code> records the current state so the same changes are not reported again. To silence a known-good item permanently, add a matching pattern to <code>rkhunter_ignore</code> in the configuration; the report notes which entries were suppressed and why. LocSec repairs a rejected rkhunter configuration automatically before each run.</p></div>

<div class="card" id="ts-cve"><h2>CVE scan &amp; reports</h2>
<ul>
<li><b>What the CVE scan covers.</b> On Debian and LMDE it runs <code>debsecan</code> against the Debian security tracker, and on every system it lists the security updates APT has waiting (<b>APT security candidates</b>). Those updates are installed automatically every 12 hours while <code>auto_update</code> is on.</li>
<li><b>Reading the debsecan result.</b> The first line gives the number of known vulnerabilities and how many have a fix available now. Only the ones with a fix are something to act on: they are listed first and install with <b>Update system</b>. Everything else is known to Debian but not fixed yet, counted by package; hundreds are normal on a desktop (most are kernel headers, <code>linux-libc-dev</code>). The status is <b>Warnings</b> when a fix is waiting and <b>Informational</b> when none is. Before 4.0.11-62 debsecan's exit status alone decided the label, so a long list read as <i>Clean / no findings</i>, and only the last 20 KB of the list was kept.</li>
<li><b>Report too large.</b> Reading a report is capped by <code>dashboard_report_max_mb</code> (100 MB). Opening a large report shows its beginning instead of the whole document, so the window does not lock up.</li>
</ul></div>

<div class="card" id="ts-updates"><h2>Updates</h2>
<p><b>Update system</b> works out what is pending with a simulated <code>apt-get upgrade</code>, installs the selected packages (security-only unless <code>update_security_only</code> is false) without interactive prompts, and keeps your existing configuration files. The result lists what was installed and explains anything left over.</p>
<table><tr><th>Message</th><th>Cause and remedy</th></tr>
<tr><td>Nothing to update</td><td>No packages are pending for the selected policy. Non-security updates are skipped when <code>update_security_only</code> is true; set it to false to include them.</td></tr>
<tr><td>Packages held back (phased rollout)</td><td>Ubuntu and Mint release some updates gradually. They arrive on their own within a few days, or set <code>include_phased_updates</code> to true.</td></tr>
<tr><td>Could not get the apt lock</td><td>Another package manager (Update Manager, unattended-upgrades, apt) is running. Wait for it to finish, or check with <code>sudo lsof /var/lib/dpkg/lock-frontend</code>, and try again.</td></tr>
<tr><td>Repository refresh failed</td><td>A network or third-party repository problem. The update continues with cached lists; fix the repository with <code>sudo apt-get update</code> and read its error.</td></tr>
<tr><td>Automatic updates skipped</td><td><code>auto_update</code> is false. Apply manually from the Scans page, or enable it in the configuration.</td></tr>
</table></div>

<div class="card" id="ts-fallback"><h2>UFW is off: fallback firewall and port-scan blocks</h2>
<p><b>Port-scan detection.</b> LocSec reads the firewall's "dropped packet" log lines (<code>[UFW BLOCK]</code>, or <code>[LOCSEC BLOCK]</code> from the fallback below) and blocks a public address that sends new connections to <code>scan_ports</code> (8) different closed ports within <code>scan_window</code> seconds (600). It opens no ports. The block appears under Persisted blocks with source <code>scan-monitor</code>, and a <code>port-scan</code> incident is recorded. Addresses on your allowlist (the local network by default) and your DNS servers and gateways are only recorded as an incident, never blocked. Turn it off with <b>Port-scan blocking</b> on the Incidents page, or <code>scan_detect</code> in the configuration. It needs UFW logging on: <code>sudo ufw logging on</code>. UFW itself logs only about 3 dropped packets a minute after an initial burst of 10, so very slow scans are only partly seen. Because the source address of a probe can be forged, scan blocks last <code>scan_block_hours</code> (24) rather than the usual 30 days, at most <code>scan_block_max_per_hour</code> (10) are made per hour, and an address this machine has an open connection with is only recorded as an incident.</p>
<p><b>Fallback firewall.</b> If UFW is installed but not enabled (and has been for two checks in a row, about two minutes), LocSec adds its own nftables chain <code>inet locsec fallback</code> that drops unsolicited incoming traffic. It allows loopback, replies to connections this machine started, ICMP, DHCP, mDNS, and any ports listed in <code>fallback_allow_tcp</code> and <code>fallback_allow_udp</code>. Everything else is dropped and logged. An SSH session that is open when the fallback turns on keeps its port open while it lasts, so you cannot be cut off mid-session. The incident and the log line list which network services were cut off. The Overview Firewall card says when it is active. <b>If you accept incoming connections (SSH, file sharing, a web server) list those ports before turning UFW off</b>, for example <code>"fallback_allow_tcp": [22]</code> in <code>/etc/locsecd/locsecd.conf</code>, then restart locsecd. Enabling UFW (<code>sudo ufw enable</code>) removes the fallback within a minute, since UFW's rules take over. Turn it off with <b>Fallback firewall when UFW is off</b> on the Incidents page or <code>"fallback_firewall": false</code>.</p>
<p>The fallback is not saved across a reboot by itself: after boot it returns about two minutes after locsecd starts. It stays in place if locsecd is stopped, so an incoming service that suddenly stopped answering can be this. Check with <code>sudo nft list chain inet locsec fallback</code>; to remove it for good, enable UFW or set <code>fallback_firewall</code> to false (LocSec puts it back within two minutes otherwise).</p></div>

<div class="card" id="ts-schedule"><h2>Schedules &amp; jobs</h2>
<ul>
<li><b>A scheduled scan never starts.</b> Heavy jobs wait until the load is at or below <code>idle_load</code> for <code>idle_seconds</code>. On a machine that is rarely idle, run the job from the Scans page, which bypasses the wait.</li>
<li><b>"Another maintenance job is already running".</b> Only one maintenance job runs at a time. The message names the job that holds the lock, whether it was started from the dashboard or by the schedule, and how long it has been running, and the Scans page shows the same under <b>Running now</b>. Scheduled scans start on their own once the machine is idle, so a button can be refused by a job nobody clicked. Wait for it to finish; a ClamAV or AIDE run can take an hour or more. To see the tool itself: <code>systemctl list-units 'locsecd-*' --no-pager</code>. If a job is stuck after a crash, <code>sudo systemctl restart locsecd.service</code> clears it.</li>
<li><b>A client disconnected mid-job.</b> The job keeps running and its report is still written to <code>/var/lib/locsecd/reports/</code>. Look for the new report instead of starting the job again.</li>
<li><b>Real-time protection is not affected by load.</b> Login monitoring and blocking run continuously.</li>
<li><b>Threat feeds show "Temporary failure in name resolution".</b> The machine could not look up the feed servers when the update ran, usually because it ran seconds after boot, before the network or DNS was up. From 4.0.11-61 a run that reaches no source keeps the previous indicators (it used to replace them with nothing), says so on the Threat Intelligence page, and is retried every 15 minutes instead of 12 hours. If it keeps failing, test DNS on the machine itself: <code>getent hosts www.spamhaus.org</code>. No output means the machine has no working DNS; check the connection with <code>nmcli general status</code> and <code>cat /etc/resolv.conf</code>. If that works, click <b>Update feeds now</b>.</li>
</ul></div>

<div class="card" id="ts-notify"><h2>Notifications</h2>
<h3>No desktop notification appears</h3>
<ul>
<li>Tick the kinds you want and press <b>Save</b>, then <b>Send test notification</b> on the Incidents page. The test says whether a graphical session was found.</li>
<li>LocSec sends the notification itself, to every user logged in at a local desktop (X11 or Wayland), so the dashboard window does not need to be open. A remote (SSH) or locked-out session gets none.</li>
<li>It uses <code>notify-send</code> (package <code>libnotify-bin</code>) or, if that is missing, <code>gdbus</code>. It asks the desktop to show it for 10 seconds; the desktop's notification service decides how: GNOME shows a banner and keeps the entry in its notification list, KDE Plasma and desktops with a tray show a bubble by the tray icon.</li>
<li>Do Not Disturb hides the banner but the entry is still kept in the list.</li>
<li>A new incident of a ticked kind notifies once; the same kind and address is not announced again for 10 minutes, and a burst (for example a feed refresh blocking many addresses) becomes one summary.</li>
</ul>
</div>

<div class="card" id="ts-incidents"><h2>Two incidents for the same address, or a count that stopped rising</h2>
<p>Both are the grouping rules working as intended.</p>
<ul>
<li><b>The Seen count stopped going up.</b> The incident was resolved or dismissed. A closed incident never absorbs another observation; the next one opens a new incident. Look for a newer row with the same indicator.</li>
<li><b>Two (or more) rows for one address.</b> Each row is one incident that was opened, counted and then closed. A source that keeps coming back after you resolve it produces one row per round, each with its own first-seen and last-seen times. That is the history of the source, not duplicate reporting.</li>
<li><b>An incident you updated several times appears once.</b> Correct: the list shows the current state of each incident. Every state change is kept in the action log and is visible through Investigate/Contain/Resolve on that incident.</li>
<li><b>Genuinely duplicated rows in the same state</b> would mean the kind, source or indicator differ &mdash; compare those three columns. Feed-sourced and login-monitor observations of the same address are different incidents by design, because they are different kinds of evidence.</li>
</ul>
<p>If you want a clean slate, <b>Delete all</b> on the Incidents page clears the timeline; individual rows can be deleted one at a time. Neither touches firewall state.</p></div>

<div class="card" id="ts-services"><h2>A service action does nothing, or a service disappears from the list</h2>
<p>Both were defects, fixed in 4.0.11-31:</p>
<ul>
<li><b>Stop and Restart failed on almost every row.</b> The page drew buttons for every running unit, but the daemon only permitted five specific ones and refused the rest with "service action is restricted to supported LocSec-managed services". Any unit can now be controlled, except the protected ones below.</li>
<li><b>A stopped service vanished.</b> The list showed only <i>running</i> units, so stopping one removed it from the Services page and from the Overview card, with no way to start it again except by typing its name into the manual box. LocSec-managed units now stay listed with their state, and a stopped one offers <b>Start</b>.</li>
</ul>
<p>What is still refused, on purpose: <b>stop</b>, <b>restart</b> and <b>disable</b> on ssh, sshd, networking, NetworkManager, systemd-networkd, dbus, systemd-logind, systemd-journald, systemd-udevd, the display manager (lightdm, gdm, gdm3, sddm), polkit and <code>locsecd</code> itself. Those either disconnect you from the machine or kill the desktop session showing this window. <b>Start</b> and <b>enable</b> are allowed on all of them. Use <code>systemctl</code> in a terminal if you really need one of the blocked combinations.</p>
<p>A third defect was fixed in 4.0.11-37: the result of an action was written to the output box and then immediately erased, because the page redrew itself straight afterwards and rebuilt that box empty. Every action looked like a button that did nothing, whether it had succeeded or been refused, and the reason for a refusal was never visible. The outcome is now written after the redraw and stays on screen.</p>
<p>The same release stopped trusting <code>systemctl</code>'s exit status on its own. LocSec now reads the unit's state before and after, reports it as <code>stopped -&gt; running</code>, and calls the action a failure if the state did not actually move -- so a silent no-op is reported as one instead of looking like success.</p>
<p>If an action still reports a failure, read the output box. A unit that is not installed reports "Unit ... not found". From 4.0.11-58 a failed start, stop or restart also carries the unit's own journal lines from that attempt (up to 20, under a <code>--- journalctl -u &lt;unit&gt; ---</code> marker), and the same text is stored in the incident, so the reason is visible without a terminal. Before -58 the incident held only systemctl's generic "Job ... failed" line, cut to 500 characters, and the LocSec log read just <code>rc=1 stopped-&gt;stopped</code>. The log line is now a WARN and ends with the unit's last journal message.</p>
<p>A tracked unit that is masked shows <b>masked</b> in the State column rather than stopped, so a unit that cannot be started is not mistaken for one that merely is not running. A <b>masked</b> unit is reported as masked, with the <code>systemctl unmask</code> command to fix it; see <a href="#ts-manual">Manual control</a>. If the output box has no journal section, the unit wrote nothing during the attempt; <code>sudo systemctl status &lt;unit&gt;</code> and <code>sudo journalctl -u &lt;unit&gt; -b -n 50</code> are the next step. Reading another unit's journal needs root or membership of the <code>adm</code> or <code>systemd-journal</code> group: as an ordinary user it prints "No entries" even when there are some.</p>
<p>Repeating a failed action does not add a row. It folds into the open incident for that unit, and the <b>Seen</b> count rises, as described under <a href="#ts-incidents">Incident grouping</a>.</p></div>

<div class="card" id="ts-exited"><h2>ufw (or another service) shows "exited" but is really running</h2>
<p>Fixed in 4.0.11-37. systemd reports two separate things about a unit: <b>ActiveState</b>, meaning is it up, and <b>SubState</b>, meaning what its process is doing. A <code>Type=oneshot</code> unit with <code>RemainAfterExit=yes</code> -- which is exactly what <code>ufw.service</code> is -- applies its rules, exits, and then sits at <code>active (exited)</code> for as long as the firewall is up. That is the normal, healthy state for it, not a stopped service.</p>
<p>The Services page and the Overview card were showing the SubState verbatim, so a working firewall read as <b>exited</b>. They now show a state derived from ActiveState: <b>running</b> for a unit with a live process, <b>active</b> for a settled oneshot unit like ufw, <b>stopped</b>, <b>failed</b> or <b>activating</b> otherwise.</p>
<p>Confirm the firewall independently at any time with <code>sudo ufw status</code>, or <code>systemctl show ufw.service -p ActiveState -p SubState</code>.</p></div>

<div class="card" id="ts-bounce"><h2>A service will not stay stopped, or vanishes when you stop it</h2>
<p>Both were fixed in 4.0.11-38, and the first is usually the system working as designed rather than a fault.</p>
<p><b>"Stop" reported success and the unit came straight back.</b> Up to 4.0.11-37 the check after a stop asked only whether the unit was <i>active</i>. A unit caught mid-restart reads as <code>activating</code>, which is not active, so a stop that had already been undone was reported as <code>ok (running -&gt; activating)</code>. LocSec now waits for the unit to settle out of a transitional state before judging, and treats coming back up as a failed stop.</p>
<p>Plenty of units legitimately restart themselves the moment they are stopped. <code>bluetooth.service</code> on a desktop is the usual example: it is D-Bus activated, so the Bluetooth applet in the panel asks for it again immediately. The same goes for socket-activated units and anything another running unit <code>Requires=</code>. Find out what is pulling it up, and stop that instead:</p>
<pre>systemctl list-dependencies --reverse bluetooth.service
systemctl cat bluetooth.service</pre>
<p>Stopping cannot hold such a unit down. If you genuinely want it off, mask it — <code>sudo systemctl mask bluetooth.service</code> — and <code>unmask</code> to undo. LocSec does not offer masking from the dashboard on purpose: it survives reboots and is easy to forget you did.</p>
<p><b>The row disappeared.</b> 4.0.11-31 made LocSec-managed units stay listed when stopped, but every other unit still dropped off the page the instant it stopped running, leaving no way to start it again except typing the name into the manual box. Any unit you act on from this page now keeps its row whatever its state, with a <b>Start</b> button, and stopped ones sort just below the managed units. The last 60 are remembered, oldest dropped first.</p>
<p>A stopped unit that briefly seemed missing and returned after a browser refresh was the same settling problem: the page redrew while the unit was still <code>activating</code>. The redraw now happens after the state settles.</p>
<p>From 4.0.11-40 such a row does not outstay its welcome. A tracked unit is dropped automatically as soon as it is running again, because at that point it is in the ordinary list on its own merit, and a <b>Forget</b> button on the row removes it by hand. Forgetting only stops LocSec listing a unit while it is <i>not</i> running -- it does not stop, disable or mask anything, and the unit reappears the moment it runs or you act on it again.</p></div>

<div class="card" id="ts-kill"><h2>What a restart, a stop or a kill leaves behind</h2>
<p><b>Ordinary stop or restart.</b> On SIGTERM the daemon sets its stop flag and asks any running packet capture to exit, then returns immediately; the waiting happens in the shutdown path proper. It closes the listener, asks systemd to stop the sibling transient units (aideinit, a running scan) that <code>KillMode=control-group</code> cannot reach because systemd owns them, not LocSec, and gives the captures 5 seconds in total before killing them. An apt or dpkg job is deliberately <b>not</b> stopped: killing dpkg mid-run leaves packages half-configured, so it is left to finish on its own. "LocSec server shut down cleanly" in the log means all of that finished.</p>
<p>Before 4.0.11-48 the signal handler did the waiting itself: up to 5 seconds per capture for SIGTERM and 5 more after SIGKILL, so three unresponsive captures could consume the unit's whole <code>TimeoutStopSec=30</code>. systemd would then SIGKILL the daemon mid-handler and the transient-unit cleanup would never run -- leaving exactly the orphaned jobs that cleanup exists to prevent.</p>
<p><b>SIGKILL, an OOM kill or power loss.</b> Nothing gets to run, so:</p>
<ul>
<li>Ordinary children (scans, captures) die with the cgroup. Transient units survive, but from 4.0.11-62 each is named after the daemon process that started it, and the next instance stops every one whose owner is gone as soon as it starts (apt jobs excepted, as above). Before that they ran on until their <code>RuntimeMaxSec</code> -- and an orphaned aideinit could race a new one, because the AIDE lock died with the old daemon.</li>
<li>If the kill landed while definitions were updating, <code>clamav-freshclam.service</code> was left stopped for good. From 4.0.11-62 the next start turns it back on when it is enabled.</li>
<li>If the monitoring thread itself ever stops, the daemon exits on purpose so systemd restarts it whole, rather than serving the dashboard with no monitoring behind it.</li>
<li>The AIDE lock is an <code>flock()</code> on an open descriptor; the kernel releases it when the process dies. The in-memory maintenance lock simply ceases to exist. Neither can be left stuck by a kill.</li>
<li>State written through the atomic path (blocks, feeds, seen-markers, compaction) is either the old file or the new one, never a mixture.</li>
<li>The append-only logs -- incidents, incident actions, events, the text log -- can lose the record that was being written. From 4.0.11-48 that is <i>all</i> they lose: an append now repairs a missing final newline first. Previously the next record written after a kill landed on the truncated line and was lost with it, so one crash cost two incidents rather than one.</li>
</ul>
<p>After an unclean stop, <code>sudo journalctl -u locsecd -b</code> shows whether the clean-shutdown line was ever reached, and <code>systemctl list-units 'locsecd-*'</code> lists any transient job still running. LocSec does not reload its configuration on SIGHUP (that signal is ignored, so log rotation cannot kill it); after editing <code>locsecd.conf</code>, restart it with <code>sudo systemctl restart locsecd</code>.</p></div>

<div class="card" id="ts-logsrc"><h2>Logs page sources show "not found" or "(no entries yet)"</h2>
<p><b>On Debian 12 and 13 this was a defect, fixed in 4.0.11-58.</b> Debian installs without rsyslog and logs only to the systemd journal, so <code>/var/log/auth.log</code>, <code>syslog</code> and <code>ufw.log</code> never exist there. The page read files only, so those sources showed "not found". Mint and Ubuntu ship rsyslog, which is why the same build worked there. Every source now falls back to the journal when its file is missing; the path line under the source shows which one was read.</p>
<p>A source that still shows <i>(no entries yet)</i> has neither a file nor any matching journal entries. Select it to see why. The usual reasons:</p>
<ul><li><b>rkhunter</b>: writes <code>/var/log/rkhunter.log</code> only, on its first run. Run it from the Scans page.</li>
<li><b>AIDE</b>: LocSec's weekly AIDE check has not run yet (or its output is older than 7 days and was deleted), or no baseline exists. Press <b>AIDE only</b> on the Scans page, or <b>Rebuild AIDE baseline</b> first if there is no baseline.</li>
<li><b>UFW</b>: UFW logs only when logging is on and something has been denied. Check with <code>sudo ufw status verbose</code> and turn it on with <code>sudo ufw logging low</code>.</li>
</ul>
<p>If you would rather have the classic files, <code>sudo apt install rsyslog</code> creates them from then on. LocSec reads the file once it exists. Check the journal directly with <code>sudo journalctl -u clamav-freshclam -n 20</code>, <code>sudo journalctl SYSLOG_FACILITY=4 SYSLOG_FACILITY=10 -n 20</code> or <code>sudo journalctl -k | grep "UFW "</code>.</p></div>

<div class="card" id="ts-logs"><h2>Are logs or reports going to fill up the disk?</h2>
<p>No.</p>
<ul>
<li><b>Reports</b> (everything in <code>/var/lib/locsecd/reports/</code>: scan, CVE and update reports and the full AIDE outputs) are deleted automatically once they are 7 days old (<code>report_retention_days</code>). The check runs every hour.</li>
<li><b>LocSec's own log</b> is rotated daily, 14 kept, compressed (<code>/etc/logrotate.d/locsecd</code>).</li>
<li><b>auth.log, syslog, ufw.log</b> are rotated by rsyslog where it is installed (Mint and Ubuntu). Debian 12 and 13 keep these in the systemd journal instead, which journald trims within the limits in <code>/etc/systemd/journald.conf</code>.</li>
<li><b>rkhunter, ClamAV, AIDE</b> logs are rotated by their own packages.</li>
</ul>
<p>The Logs page used to show a "Disk use and rotation" table under every log. It was removed in 4.0.11-65; the rules above have not changed. If something really is growing, find it with <code>sudo du -h /var/log /var/lib/locsecd --max-depth=2 | sort -h | tail -20</code>.</p>
<p>Only LocSec's own log can be cleared from the Logs page (<b>Clear LocSec's log</b>, shown when that log is selected). It is emptied in place rather than deleted, and the clear is recorded as an incident. The other logs are deliberately not clearable from the dashboard: see the Logs section of the Help page.</p></div>

<div class="card" id="ts-verify"><h2>Confirming the installed files are the ones the package shipped</h2>
<p>Every file is checksummed at build time, so dpkg can tell you if anything on disk has changed since installation &mdash; whether by an edit you forgot, a failed upgrade, or something you did not do:</p>
<pre>sudo debsums -c locsecd          # lists only files whose checksum no longer matches
dpkg -V locsecd                  # same idea, no extra package needed
dpkg -s locsecd | grep Version   # the installed version</pre>
<p>Configuration files under <code>/etc</code> are expected to differ once you have edited them; dpkg flags those separately as conffiles and never silently overwrites them. A mismatch on anything under <code>/usr</code> or <code>/lib</code> is worth investigating, because nothing in normal operation writes there.</p>
<p>If you want to rebuild from source and compare against what you are running, see <b>Source and licence</b> on the Help page.</p>
<p>Note for anyone comparing an older package: releases up to 4.0.11-40 shipped a stray Python byte-cache file under <code>/usr/lib/locsecd/__pycache__/</code>. It was a build artefact, it was never loaded, and it is gone from 4.0.11-41 onward.</p></div>

<div class="card" id="ts-manual"><h2>The manual control box says "invalid unit name"</h2>
<p>Fixed in 4.0.11-38. The box required the exact full unit name, so <code>bluetooth</code> was refused and only <code>bluetooth.service</code> was accepted -- and a leading or trailing space from a paste was refused the same way, with the same message, which reads as a rejection of the service rather than of the spelling. The name is now trimmed and given a <code>.service</code> suffix if it has none, so all three spellings work. A name that is still not a service unit is refused with the name quoted back, so you can see what was actually read.</p>
<p>Also fixed in the same release: the box lost whatever was typed on every action, because the page redraws afterwards and rebuilt the field empty -- so starting and then enabling the same unit meant typing it twice. It keeps its contents now, <b>Restart</b> was added to match the buttons on the rows above, and Enter runs Start.</p>
<p><b>Enable and disable</b> report the unit file state (<code>disabled -&gt; enabled</code>) rather than the running state. They do not change whether the unit is running now, only whether it starts at boot; ActiveState was previously reported for these, which made the result read as "running -&gt; running". A unit that is <b>masked</b> cannot be started or enabled at all. The action now says so and gives the <code>systemctl unmask</code> command. That check was added in 4.0.11-38 but only ran when systemctl exited 0, and a start on a masked unit always exits 1, so until 4.0.11-58 the result was a bare failure with no reason. LocSec never masks a unit itself; masking comes from an administrator, a hardening script or a setup tool. Check with <code>systemctl is-enabled &lt;unit&gt;</code>, which prints <code>masked</code>.</p>
<p>This box controls <code>.service</code> units only. For timers, sockets and other unit types, use <code>systemctl</code> in a terminal.</p></div>

<div class="card" id="ts-harden"><h2>Something changed after installing or upgrading LocSec</h2>
<p>The package applies two hardening files at install time. They are conservative, and nothing in them should affect normal desktop or laptop use, but this is where to look first if the timing points at a LocSec install.</p>
<table><tr><th>File</th><th>What it sets</th></tr>
<tr><td><code>/etc/sysctl.d/60-locsec-hardening.conf</code></td><td>Kernel information leaks, ICMP redirects, source routing, martian logging, SUID core dumps.</td></tr>
<tr><td><code>/etc/modprobe.d/60-locsec-disable-unused-protocols.conf</code></td><td>Stops the dccp, sctp, rds and tipc modules from loading.</td></tr>
</table>
<h3>Effects you may notice, all intended</h3>
<ul>
<li><code>dmesg</code> now needs <code>sudo</code> (<code>kernel.dmesg_restrict=1</code>). The journal is unaffected: use <code>journalctl -k</code>.</li>
<li>Kernel addresses read as zeros in <code>/proc</code> for non-root (<code>kernel.kptr_restrict=2</code>); some profiling and debugging tools report less detail unless run as root.</li>
<li>New <code>martian source</code> lines in the kernel log (<code>log_martians=1</code>). Those are spoofed or impossible source addresses being logged on purpose, not errors.</li>
</ul>
<h3>Inspect and revert</h3>
<pre>sysctl -a --pattern 'dmesg_restrict|kptr_restrict|log_martians|redirects|source_route'
sysctl net.ipv4.conf.all.accept_redirects        # read one value

sudo rm /etc/sysctl.d/60-locsec-hardening.conf   # opt out of all of it
sudo rm /etc/modprobe.d/60-locsec-disable-unused-protocols.conf
sudo reboot                                      # values already applied persist until reboot</pre>
<p>Both are configuration files owned by the package, so a deletion or an edit survives future upgrades; LocSec will not put them back. To change one setting rather than all of them, edit the file and run <code>sudo sysctl --system</code>.</p>
<p>What LocSec deliberately does <b>not</b> set, because each breaks something real: strict reverse-path filtering (VPNs and multi-homed hosts), disabling IPv6 router advertisements (IPv6 autoconfiguration), disabling magic SysRq (emergency shutdown on a wedged laptop) and restricting user namespaces (Flatpak and the Chromium sandbox). Each omission is documented in the sysctl file itself. If you applied one of those by hand and networking or an application broke afterwards, that is the first thing to undo.</p></div>

<div class="card" id="ts-log"><h2>Collecting diagnostics</h2><p>Before asking for help, gather:</p>
<pre>dpkg -s locsecd | grep Version
locsecctl status
sudo journalctl -u locsecd -n 200 --no-pager
sudo tail -n 100 /var/log/locsecd/locsecd.log
ls -lt /var/lib/locsecd/reports | head
systemctl is-enabled &lt;unit&gt;; sudo journalctl -u &lt;unit&gt; -b -n 50 --no-pager   # for a service that will not start</pre>
<p>Include the failing report from the Reports page (or the newest file under <code>/var/lib/locsecd/reports/</code>) and your Linux distribution and version.</p></div>
`
const HELP_HTML=`
<div class="card"><h2>About LocSec</h2><p>LocSec is a local security daemon and dashboard for this machine. It watches logins and system logs; blocks hostile addresses through UFW (or nftables when UFW is inactive); runs AIDE, Lynis, rkhunter, ClamAV, debsecan and CVE checks; and applies security updates. Nothing leaves the machine: there is no cloud service, no telemetry, and since 4.0.11-47 no AI component of any kind.</p>
<p class="muted">Supported on Debian 12 and 13, Ubuntu 22.04, 24.04 and 26.04 LTS, Linux Mint 21 and 22, and LMDE 6 and 7. The Troubleshooting page covers what to do when something behaves differently from what is described here.</p></div>

<div class="card" id="help-top"><h2>Contents</h2><table><tr><th>Topic</th><th>What it covers</th></tr>
<tr><td><a href="#help-overview">Overview</a></td><td>Status, protection tools, load and idle rules.</td></tr>
<tr><td><a href="#help-firewall">Firewall &amp; Blocks</a></td><td>UFW, ports, manual and automatic blocks.</td></tr>
<tr><td><a href="#help-logins">Login Activity</a></td><td>Authentication events and the auto-block threshold.</td></tr>
<tr><td><a href="#help-incidents">Incidents</a></td><td>Timeline, response policy, desktop notifications.</td></tr>
<tr><td><a href="#help-scans">Scans &amp; CVEs</a></td><td>Scan tools, statuses, schedules and updates.</td></tr>
<tr><td><a href="#help-malware">Malware / Quarantine</a></td><td>Quarantine, restore and delete.</td></tr>
<tr><td><a href="#help-threats">Threat Intelligence</a></td><td>IOC feeds and reputation checks.</td></tr>
<tr><td><a href="#help-network">Ports &amp; Capture</a></td><td>Connections, listening ports, packet capture.</td></tr>
<tr><td><a href="#help-services">Services</a></td><td>systemd service control.</td></tr>
<tr><td><a href="#help-reports">Reports</a></td><td>Scan, CVE and update reports.</td></tr>
<tr><td><a href="#help-logs">Logs</a></td><td>Log sources and where each comes from.</td></tr>
<tr><td><a href="#help-schedule">Schedules &amp; resource use</a></td><td>When each job runs and how it limits its impact.</td></tr>
<tr><td><a href="#help-config">Configuration</a></td><td>Key settings in locsecd.conf.</td></tr>
<tr><td><a href="#help-cli">Command line</a></td><td>locsecctl and systemd commands, installing and upgrading.</td></tr>
<tr><td><a href="#help-security">Security model</a></td><td>How the dashboard and daemon are protected.</td></tr>
<tr><td><a href="#help-source">Source and licence</a></td><td>Rebuilding the package yourself, and the licence.</td></tr>
</table></div>

<div class="card" id="help-overview"><h2>Overview</h2><p>The landing page shows the installed version, the number of active blocks, recent authentication failures and the current load. The load figure also shows whether the machine counts as idle: load must stay at or below <code>idle_load</code> for <code>idle_seconds</code> before background scans and updates start.</p>
<p>The <b>Protection status</b> table lists every tool LocSec coordinates. A missing component has an <b>Add</b> button that installs just that package; <b>Install missing components</b> installs everything that is absent.</p><p>The <b>Exposure</b> card checks what an attacker on the network would try first: whether UFW is on and denies incoming traffic by default, which services listen on a network address, whether OpenSSH allows password or root logins, and whether the disk is encrypted. Each warning carries the command that fixes it. LocSec only reports these; it does not change your firewall or SSH configuration for you.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-firewall"><h2>Firewall &amp; Blocks</h2><p>Enable or disable UFW, open or close a port (1 to 65535, tcp or udp), and block or unblock a single address or CIDR range. Manual blocks are recorded as <code>manual</code>.</p><p>The <b>Blocked computers</b> table explains every current block in plain words: <b>what</b> is blocked (one computer, or a whole group of addresses and how many), <b>why</b>, <b>who said</b> it is bad, whether that source can be trusted, when it was blocked and when it lifts. For threat-feed blocks it names the list: <b>Spamhaus DROP</b> (address groups taken over by spammers or criminals, with the Spamhaus SBL reference), <b>abuse.ch Feodo Tracker</b> (command servers for banking-virus botnets) or <b>abuse.ch URLhaus</b> (computers handing out malware, with the download address it was seen at). Lookup pages and download addresses are shown as text, not links, so a malware address cannot be opened by accident. LocSec blocks by IP address only; it does not block ads or websites by name. Feed blocks made before 4.0.11-65 recorded only "threat-intelligence feed"; the next feed update fills in which list named them.</p><p>When UFW is not enabled, LocSec runs a fallback default-deny firewall of its own and keeps detecting port scans; see Troubleshooting, "UFW is off".</p><p>Automatic blocks (login monitor, port-scan monitor, threat feeds) never cover this machine's own DNS servers or default gateways, read from <code>/etc/resolv.conf</code>, NetworkManager and the routing table. That stops a feed entry or a forged probe from cutting off name resolution. A block you enter by hand is still applied. An automatic block of such an address made by an earlier version is lifted when LocSec starts.</p>
<p>Networks in <code>allow_ips</code> (loopback and private ranges by default) are never blocked automatically. LocSec never force-enables UFW; while UFW is inactive it uses its own nftables table.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-logins"><h2>Login Activity</h2><p>Successful and failed authentication events from the system journal and <code>auth.log</code>. When one source reaches <code>auth_threshold</code> failures (5) within <code>auth_window</code> seconds (900) it is blocked, provided <code>auto_block</code> and <code>response_auth_block</code> are on. Logs are read every <code>event_poll_seconds</code> (60).</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-incidents"><h2>Incidents</h2><p>Every block, scan finding and login event is recorded as an incident, newest first. The <b>Automatic response policy</b> switches control what may block automatically (failed logins, port scans, threat feeds, IPv6) and whether the fallback firewall runs while UFW is off; turning off <b>Automatic blocking</b> disables all of them. Changes apply immediately and survive restarts.</p>
<p><b>Explain</b> opens a plain-words page: what happened, what LocSec did, and what you should do, with the technical evidence folded away underneath. <b>Fix it</b> appears only when LocSec can fix the incident by itself: it blocks the computer behind a failed login or port scan (never one on your own network), or moves an infected file into quarantine. Everything else (a rootkit warning, the firewall being off, a wrong password typed at this keyboard) has no automatic fix, so Explain lists the steps instead. <b>Mark solved</b> closes the incident; existing blocks stay until they run out. The State column reads New, Looked at, Fixed or Solved. Every result can be printed or copied. No AI is involved: the explanations are fixed rules written into LocSec.</p>
<h3>How repeats are grouped</h3><p>An incident is identified by its kind, its source and its indicator &mdash; for example a failed-login incident for 203.0.113.7. While that incident is <b>open</b> (new, investigating or contained), every further observation of the same thing folds into it: the <b>Seen</b> column counts them and shows when it was last seen, rather than adding a row.</p>
<p>Once you <b>resolve or dismiss</b> it, the incident is closed permanently. A later observation of the same kind, source and indicator opens a <b>new</b> incident with its own timestamp and its own count. That is deliberate: a closed case stays closed and keeps its history, and a scanner that comes back a month later is genuinely a new event rather than an old row quietly ticking upward. Expect to see more than one row for a persistent source over time &mdash; that is the timeline working, not duplication.</p>
<p>The list shows one row per incident in its current state, however many times it has been updated. Two rows with the same indicator are therefore two separate incidents, distinguishable by their timestamps.</p>
<p><b>Delete</b> permanently removes that incident and its action log from the dashboard (after a confirmation prompt); <b>Delete all</b> clears the whole timeline. Deleting does not remove firewall blocks. The most recent <code>incident_retention</code> incidents are kept.</p>
<p><b>Desktop notifications</b> pop up for about 10 seconds, even with the dashboard closed, for new incidents of the kinds you tick (virus, rootkit, IP blocked, failed login, port scan, fallback firewall on), and stay in the desktop notification list. Save your selection, then use <b>Send test notification</b>.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-scans"><h2>Scans &amp; CVEs</h2>
<p><b>Full scan</b> runs AIDE, Lynis, debsecan, rkhunter, the ports and firewall snapshot and ClamAV in sequence; the CVE scan is a separate button. Single-tool buttons run one tool immediately. <b>CVE scan</b> (after Ports/firewall only) runs debsecan (Debian and LMDE) and lists the security updates APT has waiting. <b>Update system</b> installs pending updates (see below). <b>Update definitions now</b> refreshes ClamAV signatures and rkhunter data. If Debian has produced <code>aide.db.new</code>, <b>Accept pending AIDE baseline</b> explicitly promotes it after review, retains the previous baseline as <code>aide.db.locsec-backup</code>, and secures the promoted file as <code>root:root</code> mode <code>0600</code>. <b>Rebuild AIDE baseline</b> is an explicitly confirmed operation that creates the first baseline on a new machine or replaces an existing one. The <b>Schedule</b> table on the Scans page shows, for every check, how often it runs, when it last ran and when it is next due. Checks have no fixed clock time: each is due a set time after it last ran, and the ones marked "when idle" wait until the load has stayed at or below <code>idle_load</code> for <code>idle_seconds</code>.</p>
<h3>Tools</h3>
<table><tr><th>Tool</th><th>Checks</th><th>Notes</th></tr>
<tr><td>AIDE</td><td>File integrity against the baseline.</td><td>Limit <code>aide_scan_timeout</code> (3 hours), which also covers Rebuild AIDE baseline. Runs at idle I/O priority. Differences after package upgrades are expected.</td></tr>
<tr><td>Lynis</td><td>System hardening audit.</td><td>Reports the hardening index, the warnings and the full suggestion list from the Lynis report file (which is root-only on disk).</td></tr>
<tr><td>rkhunter</td><td>Rootkits and suspicious files.</td><td>Warnings are verified against the package database; benign items are labelled informational.</td></tr>
<tr><td>ClamAV</td><td>Malware in <code>clamav_scan_paths</code> (<code>/home</code>).</td><td>One pass, one summary. Files over <code>clamav_max_file_mb</code> are skipped.</td></tr>
<tr><td>CVE scan</td><td>Known CVEs in installed packages (debsecan) and pending security updates.</td><td>Security updates install automatically while <code>auto_update</code> is on.</td></tr>
<tr><td>debsecan</td><td>Debian CVE feed.</td><td>Reports how many known CVEs affect installed packages and lists the ones with a fix available. Runs on Debian and LMDE (against LMDE's Debian suite); skipped on Ubuntu and Ubuntu-based Mint, where its Debian feed does not match the package versions.</td></tr>
<tr><td>Ports &amp; firewall</td><td>Listening sockets and firewall state.</td><td>An inventory, marked informational.</td></tr>
</table>
<h3>Statuses</h3>
<p>Each result shows a status: <b>Clean</b>, <b>Informational</b> (expected noise, no action), <b>Warnings</b> or <b>Findings</b> (review the report), <b>Timed out</b>, <b>Scan error</b>, <b>Skipped</b>, <b>Tool not installed</b> or <b>Not initialized</b>. A scan is only labelled clean when the tool completed and reported nothing of concern.</p>
<h3>Updates</h3>
<p><b>Update system</b> simulates <code>apt-get upgrade</code>, then installs the pending packages (security only while <code>update_security_only</code> is true) without prompts and keeps your configuration files. The result lists what was installed and explains anything left over: phased-rollout holds, a busy apt lock, or automatic updates being disabled.</p>
<p>Only one maintenance job runs at a time. A second request is refused with the name of the job that is running, where it came from (dashboard or schedule) and how long it has run; the Scans page shows it under <b>Running now</b>.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-malware"><h2>Malware / Quarantine</h2><p>Quarantine moves a file out of place into a private vault, keeps it from running, and records where it came from. Enter an absolute path to scan one file with ClamAV; an infected file is quarantined (tick <b>Quarantine even if clean</b> to quarantine a file ClamAV does not flag). Infected files found by scheduled scans are listed under <b>Detections awaiting action</b> with a <b>Quarantine</b> button each. In <b>Quarantined files</b>, <b>Restore</b> puts a file back exactly where it was, with its original owner and permissions (setuid/setgid bits are not restored), and <b>Delete</b> removes it permanently; <b>Delete all</b> empties the vault. A file whose quarantine record is missing (an interrupted quarantine) has no recorded location, so it can only be deleted. Paths under core system directories (<code>/bin</code>, <code>/usr/lib</code>, <code>/etc</code> and similar) are refused unless you tick <b>Force</b>, so a false positive cannot disable a working system binary.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-threats"><h2>Threat Intelligence</h2><p>LocSec keeps a local copy of public feeds (Spamhaus DROP, Feodo Tracker and URLhaus by default, set in <code>feed_urls</code>) and refreshes it every <code>feed_interval</code> seconds (12 hours). Each feed is capped at 8 MB on download and the stored indicator list at 200,000 entries per category, so a feed that suddenly publishes millions of entries cannot grow the daemon's memory or the state directory without limit; the page shows counts rather than downloading the indicator list itself. <b>Check reputation</b> searches that local copy only; nothing you enter is sent anywhere. With <code>feed_auto_block</code> on, feed addresses are blocked automatically, at most <code>feed_auto_block_limit</code> per refresh.</p><p>If an update reaches none of the sources (no network or DNS), the previous indicators are kept, the page says the last attempt failed, and the update is retried every 15 minutes until it succeeds. <b>Last updated</b> is the time of the last successful update.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-network"><h2>Ports &amp; Capture</h2><p>Live connections and listening ports come from <code>ss</code>. <b>Start capture</b> runs tcpdump for 5 to 3600 seconds and saves the capture under <code>/var/lib/locsecd/captures/</code>; Wireshark opens it. Before 4.0.11-62 captures could come out missing or empty on Debian, whose tcpdump drops to its own <code>tcpdump</code> user and could not write into that root-only directory; LocSec now opens the file itself and tcpdump writes into it. Saved captures are listed underneath with an <b>Analyze</b> button each (tshark summary); the filename box is there for a capture that is not in the list. Captures will not start with less than 1 GB free, stop early below 256 MB, and at most 3 run at once.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-services"><h2>Services</h2><p>Lists the units LocSec coordinates first — these stay listed when stopped, so you can start them again — followed by everything else currently running. Each row offers the actions that apply to its current state: <b>Start</b> when stopped, <b>Restart</b> and <b>Stop</b> when running. The manual box below takes any unit name for start, stop, enable or disable.</p><p>Units your own access depends on are marked <b>protected</b> and offer only Start: ssh, networking, NetworkManager, dbus, logind, journald, udev, the display manager, polkit and locsecd itself. Stopping any of those either cuts your connection to the machine or kills the desktop session this window is displayed in, so the dashboard refuses; use the command line if you genuinely need to.</p><p>A failed start, stop or restart shows why in the output box: systemd's message plus the unit's own journal lines from that attempt. The same text is kept in the <b>service-action</b> incident. A masked unit is named as masked, with the command to unmask it, and a tracked masked unit shows <b>masked</b> in the State column. LocSec never masks or unmasks units itself.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-reports"><h2>Reports</h2><p>Every scan, CVE check and update writes a JSON report to <code>/var/lib/locsecd/reports/</code>. The page lists the 50 most recent; <b>View</b> opens one and <b>Delete</b> removes it. Each check in a report starts with what it found in plain words and what to do about it; the tool's own output is under <b>Show the full output</b>. <b>What to do</b> collects all of it on one page that can be printed or copied. A very large report is shown in part rather than in full, so opening it cannot lock up the window; the complete file stays on disk. Every file in the reports directory, including the full AIDE outputs, is deleted automatically once it is <code>report_retention_days</code> old (7 days), so reports cannot fill the disk.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-logs"><h2>Logs</h2><p>Pick a log from the <b>Log</b> list. Each line is turned into plain words: <b>when</b> it happened, a coloured <b>kind</b> (Fine, Note, Heads up, Problem) and <b>what happened</b> in a sentence or two. A short line at the top says what that log is for. The counts next to the coloured labels add up what is on screen.</p>
<p><b>Show: Only things to look at</b> hides everything marked Fine or Note, leaving the Heads up and Problem rows. <b>Show the original log lines</b>, at the bottom, opens the exact text the computer wrote, so nothing is hidden. <b>Refresh</b> reads the log again. The same line repeated within a few minutes is shown once, with how many times it happened.</p>
<p>Rows that need action carry a green <b>What to do</b> box with the fix. <b>What to do</b> in the toolbar collects every Heads up and Problem in that log on one page, with the fix for each; <b>Print</b> on that page prints it (the desktop window saves it as a PDF in Documents and opens it, so you can print from the PDF viewer), and <b>Copy as text</b> copies it.</p>
<p><b>AIDE (latest check)</b> lists the most important changes first. For each changed file it says <i>what</i> changed (contents, size, permissions, owner), which package owns it, and whether software installed or updated since the last snapshot explains it (from <code>/var/log/dpkg.log</code>). Explained changes are Notes; unexplained ones are Heads up; a file that gains setuid/setgid or capabilities, or changes owner, is a Problem.</p>
<h3>The firewall (UFW) log</h3>
<p>Think of the firewall as a wall with doors (ports). This view reads the last 1000 firewall lines and shows:</p>
<ul>
<li>a sentence saying how many knocks the wall stopped, and from how many different computers;</li>
<li><b>Who knocked the most</b>: each computer's address, whether it is on the internet or your own network, the doors it tried, and a warning if it is on the block list or tried lots of doors (a port scan);</li>
<li><b>Doors that were knocked on</b>: each door number and what it is normally used for (22 is SSH remote login, 445 is Windows file sharing, and so on);</li>
<li><b>Every knock</b>: when, what the wall did (Stopped, Let in, Noted), who knocked, which door, and why, in plain words. Broadcasts from your own network, leftover pieces of finished conversations, and strangers trying doors are each explained differently, because they mean different things.</li>
</ul>
<p>Most knocks from the internet are robots trying doors on every computer they can find. They are stopped and need nothing from you. A computer marked <b>tried lots of doors</b> is blocked automatically by LocSec's port-scan watcher.</p>
<h3>Clearing</h3>
<p>Only <code>locsecd.log</code> can be cleared here, with <b>Clear LocSec's log</b>. It is emptied in place rather than deleted, so LocSec keeps writing to the same file, and the clear is recorded as an incident. The file is opened with <code>O_NOFOLLOW</code> and truncated through that descriptor, never by path, and must be a regular file inside LocSec's own log directory, so a symbolic link left there cannot point the clear at another file. <code>auth.log</code> and <code>syslog</code> are the first thing anyone reads after a break-in, and the scan logs belong to rkhunter, ClamAV and AIDE, so none of them can be cleared from the dashboard. To clear one anyway, use a terminal: <code>sudo truncate -s 0 /var/log/&lt;file&gt;</code>.</p>
<h3>Where each log comes from</h3>
<table><tr><th>Log</th><th>File, when present</th><th>Otherwise, the systemd journal</th></tr>
<tr><td>LocSec</td><td><code>/var/log/locsecd/locsecd.log</code></td><td><code>journalctl -u locsecd</code></td></tr>
<tr><td>Authentication</td><td><code>/var/log/auth.log</code></td><td>auth and authpriv facilities (<code>journalctl SYSLOG_FACILITY=4 SYSLOG_FACILITY=10</code>)</td></tr>
<tr><td>rkhunter</td><td><code>/var/log/rkhunter.log</code></td><td>none; rkhunter writes only its file, created on its first run</td></tr>
<tr><td>ClamAV (freshclam)</td><td><code>/var/log/clamav/freshclam.log</code></td><td><code>journalctl -u clamav-freshclam</code></td></tr>
<tr><td>AIDE (latest check)</td><td>the newest <code>/var/lib/locsecd/reports/aide-full-*.txt</code>, else <code>/var/log/aide/aide.log</code></td><td><code>journalctl -u dailyaidecheck</code></td></tr>
<tr><td>UFW</td><td><code>/var/log/ufw.log</code></td><td>kernel messages containing <code>[UFW </code> (<code>journalctl -k</code>)</td></tr>
<tr><td>System</td><td><code>/var/log/syslog</code></td><td>the whole journal</td></tr>
</table>
<p>The authentication, system and UFW files are written by rsyslog, which Mint and Ubuntu install and Debian 12 and 13 do not. Every log falls back to the journal when its file is missing, and the line above the list says which one was read. A log with neither is marked <i>(no entries yet)</i>, and selecting it says why. The UFW log needs firewall logging on: <code>sudo ufw logging low</code>.</p><p><a href="#help-top">Back to contents</a></p></div>


<div class="card" id="help-schedule"><h2>Schedules &amp; resource use</h2>
<table><tr><th>Job</th><th>Default cadence</th><th>Setting</th></tr>
<tr><td>AIDE, Lynis, debsecan, rkhunter, ports snapshot, CVE scan</td><td>Weekly, staggered a day apart</td><td><code>scan_interval</code>, <code>scan_stagger_seconds</code></td></tr>
<tr><td>ClamAV</td><td>Daily</td><td><code>clamav_scan_interval</code></td></tr>
<tr><td>Security updates</td><td>Every 12 hours</td><td><code>update_interval</code>, <code>auto_update</code></td></tr>
<tr><td>Virus and rootkit definitions</td><td>Daily</td><td><code>defs_update_interval</code></td></tr>
<tr><td>Threat-intelligence feeds</td><td>Every 12 hours</td><td><code>feed_interval</code></td></tr>
</table>
<p>Scheduled scans and updates wait for an idle machine, run at low CPU and idle I/O priority, and never run together. Manual runs start immediately. Real-time protection (login monitoring, blocking) is not delayed by load. Scan tools run in a separate systemd unit with their own time limit, so a stuck tool is stopped cleanly rather than hanging the service.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-config"><h2>Configuration</h2><p>Settings live in <code>/etc/locsecd/locsecd.conf</code> (JSON). After editing, run <code>sudo systemctl restart locsecd.service</code>. The response switches on the Incidents page are saved separately and take effect immediately.</p>
<p class="muted">Two further files belong to the package but are not read by the daemon: <code>/etc/sysctl.d/60-locsec-hardening.conf</code> and <code>/etc/modprobe.d/60-locsec-disable-unused-protocols.conf</code> apply kernel and network hardening at install time. See the Troubleshooting page for what they set and how to opt out.</p>
<table><tr><th>Key</th><th>Default</th><th>Purpose</th></tr>
<tr><td>listen / port</td><td>127.0.0.1 / 8765</td><td>Dashboard address. <code>listen</code> is pinned to 127.0.0.1: any other value is replaced and logged.</td></tr>
<tr><td>auth_threshold / auth_window</td><td>5 / 900</td><td>Failures within the window that trigger a block.</td></tr>
<tr><td>scan_detect / scan_ports / scan_window</td><td>true / 8 / 600</td><td>Block a public address that probes this many different closed ports within the window (seconds). Needs firewall logging.</td></tr>
<tr><td>scan_block_hours / scan_block_max_per_hour</td><td>24 / 10</td><td>How long a port-scan block lasts, and the most that are made per hour (scan source addresses can be forged).</td></tr>
<tr><td>fallback_firewall</td><td>true</td><td>Install LocSec's own default-deny input chain while UFW is installed but not enabled.</td></tr>
<tr><td>fallback_allow_tcp / fallback_allow_udp</td><td>[]</td><td>Incoming ports the fallback firewall leaves open, for example [22].</td></tr>
<tr><td>allow_ips</td><td>loopback and private ranges</td><td>Never blocked automatically.</td></tr>
<tr><td>idle_load / idle_seconds</td><td>1.0 / 600</td><td>Idle rule for heavy jobs.</td></tr>
<tr><td>clamav_scan_paths</td><td>["/home"]</td><td>Directories ClamAV scans.</td></tr>
<tr><td>clamav_max_file_mb / clamav_timeout</td><td>100 / 7200</td><td>Largest file scanned, job time limit (seconds).</td></tr>
<tr><td>clamav_extra_excludes</td><td>[]</td><td>Additional paths or patterns to skip.</td></tr>
<tr><td>aide_scan_timeout</td><td>10800</td><td>AIDE time limit for checks, Initialize and Rebuild (seconds).</td></tr>
<tr><td>lynis_timeout</td><td>3600</td><td>Lynis time limit (seconds).</td></tr>
<tr><td>rkhunter_ignore</td><td>[]</td><td>Patterns for known-good rkhunter warnings.</td></tr>
<tr><td>auto_update / update_security_only</td><td>true / true</td><td>Apply updates automatically; security updates only.</td></tr>
<tr><td>include_phased_updates</td><td>false</td><td>Apply phased-rollout packages immediately.</td></tr>
<tr><td>dashboard_report_max_mb</td><td>100</td><td>Largest report the dashboard will open.</td></tr>
<tr><td>report_retention_days</td><td>7</td><td>Every file in the reports directory is deleted once it is this many days old.</td></tr>
<tr><td>retention_days</td><td>14</td><td>Packet captures and LocSec's rotated log files are deleted after this many days.</td></tr>
</table><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-cli"><h2>Command line</h2>
<pre>locsecctl status | start | stop | restart | enable | disable
locsecctl scan            # full scan now
locsecctl scan-aide       # also: scan-lynis, scan-rkhunter, scan-clamav,
                          #       scan-debsecan, scan-ports
locsecctl cve             # CVE scan now
locsecctl update          # apply updates now
locsecctl feed-update     # refresh threat feeds now
locsecctl aide-init       # initialize only if no active AIDE baseline exists
locsecctl aide-accept     # explicitly promote /var/lib/aide/aide.db.new
locsecctl aide-reinitialize # explicitly rebuild and replace the active baseline
locsecctl logs            # last 200 journal lines
locsecctl gui             # open the desktop window (browser if PyQt6 is missing)
locsecctl tray            # start the panel icon without opening the window
locsecctl uninstall --dry-run # staged removal plan; also --keep-tools, --all,
                          #   --include-firewall, -y (run with sudo)
sudo journalctl -u locsecd.service -f
sudo tail -f /var/log/locsecd/locsecd.log</pre>
<h3>Installing and upgrading the package</h3>
<p>Install or upgrade with apt, from a terminal, so dependencies resolve and the installer's own messages (ClamAV's first signature download, AIDE) are visible as they happen. The installer restarts <code>locsecd</code> itself.</p>
<pre>sudo apt install ./locsecd_&lt;version&gt;_amd64.deb
sudo apt install --reinstall ./locsecd_&lt;version&gt;_amd64.deb   # a rebuilt package with the same version number</pre>
<p><b>gdebi</b> resolves dependencies the same way and works as well. Prefer <code>sudo gdebi ./locsecd_&lt;version&gt;_amd64.deb</code> in a terminal: the gdebi window hides the installer's output in a collapsed details pane and can look stalled during the first ClamAV download. For a same-version rebuild the window offers <b>Reinstall Package</b>. Avoid <code>dpkg -i</code> alone; it does not fetch missing dependencies, and if you used it, follow with <code>sudo apt-get install -f</code>.</p><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-security"><h2>Security model</h2><ul style="margin:0;padding-left:18px;line-height:1.7">
<li>The dashboard listens on 127.0.0.1 only (<code>listen</code> is pinned there) and every request needs the per-install token in <code>/var/lib/locsecd/api.token</code> (root only). Requests whose <code>Host</code> is not 127.0.0.1 or localhost are refused, so a web page cannot reach the API through DNS rebinding, and cross-site POSTs are refused.</li>
<li>Threat feeds are fetched over HTTPS only. A plain <code>http://</code> URL in <code>feed_urls</code> is ignored with a warning, because whoever can rewrite a feed in transit chooses what this machine blocks.</li>
<li>The daemon runs under a systemd sandbox with a restricted capability set. Scan tools run in a separate, time-limited unit.</li>
<li>Allowlisted networks are never auto-blocked, and feed blocking is capped per refresh. Port-scan blocks last 24 hours, are limited to 10 an hour, and skip any address this machine is connected to, because probe source addresses can be forged.</li>
<li>The browser or desktop window signs in with a single-use login code and then holds a random session cookie that expires (8 hours idle, 3 days at most). The cookie is never the API token, so a stolen cookie does not give lasting access; the token itself is in a root-only file. The desktop window signs in again by itself when its session expires. Scan, apt and notification jobs run in their own units with extra restrictions (the notification helper has no privileges at all). An example AppArmor profile for the daemon is in <code>/usr/share/doc/locsecd/examples/</code>; it is not loaded by default.</li>
<li>Quarantine refuses system directories unless forced; restore refuses to write through a symlinked directory or over a non-regular file; captures are limited by free disk space.</li>
<li>The package installs conservative kernel and network hardening (<code>/etc/sysctl.d/60-locsec-hardening.conf</code>) and blocks four unused network protocol modules (<code>/etc/modprobe.d/60-locsec-disable-unused-protocols.conf</code>). Both are configuration files: edit or delete them and the change survives upgrades. Each documents what was deliberately left out — reverse-path filtering, IPv6 router advertisements, magic SysRq and user namespaces — because those break roaming laptops or desktop sandboxes.</li>
</ul><p><a href="#help-top">Back to contents</a></p></div>

<div class="card" id="help-source"><h2>Source and licence</h2>
<p><b>Licence: GPL-3 or later.</b> The full text is at <code>/usr/share/common-licenses/GPL-3</code>, and <code>/usr/share/doc/locsecd/copyright</code> records it in machine-readable form. Every executable file in the package carries a GPL notice header. Releases before 4.0.11-42 stated no licence anywhere, which was an omission rather than a different licence.</p>
<p>The desktop window imports PyQt6, which is GPLv3-or-commercial, so the GUI is a derived work of it. The daemon runs UFW, AIDE, Lynis, rkhunter and the rest as separate processes, which does not make it a derived work of those, but the package ships as one unit under one licence.</p>
<p>No third-party code is bundled. The package is thirty text files &mdash; Python, shell, systemd units, configuration and one SVG icon &mdash; with no binaries, blobs or vendored dependencies. Everything else it uses comes from your distribution.</p>
<p><b>Rebuilding it yourself.</b> From 4.0.11-41 LocSec ships as a Debian source package. The only build dependency is <code>dpkg-dev</code> &mdash; no debhelper, no compiler, no fakeroot &mdash; so it can be rebuilt on the machine it protects without installing a build toolchain.</p>
<pre>sudo apt install dpkg-dev
dpkg-source -x locsecd_4.0.11-&lt;rev&gt;.dsc
cd locsecd-4.0.11
dpkg-buildpackage -us -uc -b
sudo apt install -y ../locsecd_4.0.11-&lt;rev&gt;_amd64.deb</pre>
<p><code>debian/rules build</code> syntax-checks the Python and shell that ships without producing a package. The source tree mirrors the installed filesystem, so a file you want to read sits at the path it installs to. Appendix C of the installation guide covers the layout and the three files a release bump touches.</p>
<p><a href="#help-top">Back to contents</a></p></div>
`;

page('overview');
healthPing();
setInterval(healthPing,15000);
</script></body></html>'''



def server(worker=None):
    srv=BoundedThreadingHTTPServer((LISTEN_ADDR,int(CFG['port'])),Handler)
    srv.timeout=1
    log(f'API/dashboard listening on {LISTEN_ADDR}:{CFG["port"]}')
    rc=0
    try:
        while not STOP_EVENT.is_set():
            srv.handle_request()
            # The monitoring thread catches errors per tick, but anything that
            # escapes kills it silently while the dashboard keeps answering:
            # no login monitoring, no scans, no updates, and nothing to say so.
            # Exit instead, so systemd (Restart=always) brings up a whole one.
            if worker is not None and not worker.is_alive() and not STOP_EVENT.is_set():
                log('the background monitoring thread stopped unexpectedly; exiting so systemd restarts LocSec','ERROR')
                rc=1; break
    finally:
        srv.server_close()
        # The blocking half of capture teardown, outside signal context: the
        # handler has already sent SIGTERM, so these waits usually return at
        # once. cgroup-kill (KillMode=control-group) reaches every ordinary
        # child of ours anyway; this is what makes the exit orderly rather
        # than relying on it.
        # Sibling units first: that is one non-blocking call, and it must not
        # be starved by capture teardown if systemd's stop timeout runs short.
        _stop_inflight_priv_units()
        if _FRESHCLAM_STOPPED.is_set():
            try: subprocess.run(['systemctl','start','--no-block','clamav-freshclam.service'],timeout=10,
                                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
            except Exception: pass
        with CAPTURE_LOCK:
            captures=list(ACTIVE_CAPTURES)
        # All captures already got SIGTERM from the signal handler; wait for
        # them together (5s in total, not 10s each), then SIGKILL what is left.
        deadline=time.time()+5
        for proc in captures:
            try: proc.wait(timeout=max(0.1,deadline-time.time()))
            except Exception: pass
        for proc in captures:
            if proc.poll() is None:
                try: os.killpg(proc.pid, signal.SIGKILL)
                except Exception: pass
        log('LocSec server shut down cleanly')
    return rc

def fix_rkhunter_web_cmd():
    # Debian's rkhunter package ships /etc/rkhunter.conf with two settings
    # that between them make "rkhunter --update" fail out of the box:
    #
    # 1. WEB_CMD="/bin/false" (meant to just disable the online-version
    #    check) but rkhunter's own config validator rejects that value
    #    outright: "Invalid WEB_CMD configuration option: Relative
    #    pathname". WEB_CMD="" is the value that actually disables the
    #    check without failing validation.
    # 2. MIRRORS_MODE=1 ("only use local mirrors") -- Debian's own default,
    #    documented in rkhunter's README, deliberately ships this way so
    #    rkhunter never contacts a remote mirror unless you opt in. With no
    #    local mirrors configured either, every data-file download fails
    #    with "Unable to determine the latest version number" because it
    #    never has anywhere to fetch from. MIRRORS_MODE=0 lets it use the
    #    real (SourceForge) mirror list -- required for the auto-update
    #    feature to do anything at all.
    #
    # Both idempotent; safe to call before every rkhunter invocation.
    conf=Path('/etc/rkhunter.conf')
    try:
        if not conf.is_file(): return False
        text=conf.read_text()
        fixed=re.sub(r'(?m)^WEB_CMD\s*=\s*"?/bin/false"?\s*$','WEB_CMD=""',text)
        fixed=re.sub(r'(?m)^MIRRORS_MODE\s*=\s*1\s*$','MIRRORS_MODE=0',fixed)
        if fixed!=text:
            # locsecd.service mounts /etc read-only (ProtectSystem=full); edit it from a transient unit.
            rc,out=_run_transient(['sed','-i','-E',
                r's|^WEB_CMD[[:space:]]*=[[:space:]]*"?/bin/false"?[[:space:]]*$|WEB_CMD=""|;s|^MIRRORS_MODE[[:space:]]*=[[:space:]]*1[[:space:]]*$|MIRRORS_MODE=0|',
                str(conf)],30,prefix='locsecd-priv')
            if rc!=0:
                log(f'could not patch rkhunter.conf (rc={rc}): {out[-300:]}','ERROR'); return False
            log('patched rkhunter.conf: WEB_CMD -> "" and MIRRORS_MODE -> 0 (Debian defaults otherwise block --update entirely)')
            return True
    except Exception as e:
        log(f'could not patch rkhunter.conf: {e}','ERROR')
    return False

def update_definitions():
    # Keep the signature/definition databases for the scan tools themselves
    # fresh, independent of the (potentially infrequent) full heavy_scan()
    # cycle. clamav-freshclam already runs as its own systemd service/timer
    # (enabled in postinst) so ClamAV signatures update on their own; this
    # covers the tools that only refresh when explicitly told to.
    results={}
    if have('rkhunter'):
        fix_rkhunter_web_cmd()
        # Same transient unit the rkhunter scan uses: --update writes under
        # /var/lib/rkhunter and re-reads /etc/rkhunter.conf, and inside this
        # daemon's sandbox it behaves differently from the scheduled scan.
        rc,out=_run_transient(['rkhunter','--update'],600,prefix='locsecd-priv')
        if rc!=0 and 'Update failed' in out:
            # rkhunter's own summary never says *why* a file failed to fetch
            # (network/DNS/TLS/mirror problem); its log does.
            _,tail=run(['tail','-n','60','/var/log/rkhunter.log'],10)
            out += '\n--- /var/log/rkhunter.log (tail) ---\n'+tail
        results['rkhunter']={'rc':rc,'output':out[-6000:]}
        log(f'rkhunter definitions update rc={rc}')
    if have('freshclam'):
        # Two problems here, both stemming from the same cause: clamav-freshclam.service
        # already runs continuously in the background (enabled by postinst) and holds
        # a lock on /var/log/clamav/freshclam.log. (1) freshclam drops from root to the
        # clamav user via initgroups()/setuid, which locsecd's own restricted capability
        # set can't grant -- same class of fix as aide_init()/package_update(), run it
        # in its own transient unit with the full capability set. (2) even with that
        # fixed, a manual run competes with the always-on service for the same log
        # lock ("Failed to lock the log file ... Resource temporarily unavailable").
        # Stop the service for the duration of the manual run, same as postinst does
        # during install, so there's only ever one freshclam touching that lock.
        run(['systemctl','stop','clamav-freshclam.service'],30)
        _FRESHCLAM_STOPPED.set()
        try:
            rc,out=run_privileged(['freshclam','--quiet'],120)
        finally:
            run(['systemctl','start','clamav-freshclam.service'],30)
            _FRESHCLAM_STOPPED.clear()
        # rc=1 from freshclam commonly just means "already up to date" -- not a real failure.
        results['clamav']={'rc':rc,'output':out[-4000:]}
        log(f'ClamAV signature update rc={rc}')
    return results

# Set while update_definitions() has clamav-freshclam.service stopped; server() starts
# it again on the way out if a stop arrives in that minute.
_FRESHCLAM_STOPPED=threading.Event()

def _restore_freshclam():
    # update_definitions() stops clamav-freshclam.service for its own freshclam
    # run and starts it again in a finally -- which a SIGKILL, an OOM kill or a
    # stop during that minute skips, leaving signature updates off for good.
    if not have('systemctl'): return
    rc,st=run(['systemctl','is-enabled','clamav-freshclam.service'],10)
    if rc==0 and st.strip().startswith('enabled'):
        rc,_=run(['systemctl','is-active','--quiet','clamav-freshclam.service'],10)
        if rc!=0:
            run(['systemctl','start','clamav-freshclam.service'],60)
            log('clamav-freshclam.service was stopped although enabled; started it again','WARN')

def missing_components():
    # What postinst tries to set up automatically but can silently skip if a
    # 60-300s network timeout was hit during install (slow mirror, congested
    # link, etc). Checked by dpkg status / binary presence, not by re-running
    # apt, so this is cheap enough to surface on every /api/status call.
    out={}
    rc,_=run(['dpkg-query','-W','-f=${Status}','clamav-daemon'],10)
    out['clamav-daemon']=rc!=0
    return out

# Packages the Overview table's Add button may install. Every entry is a real
# Depends: of LocSec, so there is deliberately no removal path: apt would take
# LocSec out with it.
_TOOL_INFO={
 'ufw':{'pkg':'ufw'},
 'aide':{'pkg':'aide'},
 'lynis':{'pkg':'lynis'},
 'debsecan':{'pkg':'debsecan'},
 'rkhunter':{'pkg':'rkhunter'},
 'clamscan':{'pkg':'clamav'},
 'clamdscan':{'pkg':'clamav-daemon'},
 'tshark':{'pkg':'tshark'},
 'tcpdump':{'pkg':'tcpdump'},
 'ss':{'pkg':'iproute2'},
 'nft':{'pkg':'nftables'},
}

def tool_add(tool):
    tool=str(tool)
    info=_TOOL_INFO.get(tool)
    if not info: return {'ok':False,'error':'unknown component'}
    if not have('apt-get'): return {'ok':False,'error':'apt-get not found'}
    pkg=info['pkg']
    rc,_=run(['dpkg-query','-W',pkg],10)
    if rc==0:
        return {'ok':True,'output':f'{pkg} already installed'}
    rc,out=run_privileged(['apt-get','install','-y','--no-install-recommends',pkg],180)
    if rc==0 and pkg=='clamav-daemon':
        run(['systemctl','enable','--now','clamav-freshclam.service'],30)
        run(['systemctl','enable','--now','clamav-daemon.service'],30)
    incident('tool-add','manual',tool,'low','success' if rc==0 else 'failed',out[-1000:])
    return {'ok':rc==0,'output':out[-4000:]}

def install_missing():
    # On-demand retry of whatever postinst's network-bounded steps skipped,
    # without having to reinstall the whole .deb. Same timeouts/behavior as
    # postinst, just re-runnable from the dashboard.
    results=[]
    if not have('apt-get'):
        return {'ok':False,'results':['apt-get not found']}
    rc,_=run(['dpkg-query','-W','clamav-daemon'],10)
    if rc!=0:
        rc,out=run_privileged(['apt-get','install','-y','--no-install-recommends','clamav-daemon','clamav-freshclam'],180)
        results.append({'component':'clamav-daemon','rc':rc,'output':out[-4000:]})
        if rc==0:
            run(['systemctl','enable','--now','clamav-freshclam.service'],30)
            run(['systemctl','enable','--now','clamav-daemon.service'],30)
    else:
        results.append({'component':'clamav-daemon','rc':0,'output':'already installed'})
    for r in results:
        if r.get('rc')!=0:
            log(f'install-missing: {r["component"]} failed (rc={r.get("rc")}): {str(r.get("output",""))[-1000:]}','ERROR')
    log(f'install-missing run: {[(r["component"],r.get("rc")) for r in results]}')
    return {'ok':all(r['rc']==0 for r in results),'results':results}

# What the scheduler below is waiting for, for the Scans page. Written by background() once a
# minute; read-only everywhere else.
_SCHED={}

def schedule_status():
    if not _SCHED: return {'ready':False}
    now=time.time(); runs=_job_runs()
    def last_real(key,patterns):
        newest=runs.get(key,0.0)
        for pat in patterns:
            for f in REPORTS.glob(pat):
                try: newest=max(newest,f.stat().st_mtime)
                except OSError: pass
        return newest or None
    rows=[]; si=_SCHED['scan_interval']
    for key,_ in _SCHED['jobs_list']:
        pats=['cve-*.json'] if key=='cve' else [f'scan-{key}-*.json','report-*.json']
        rows.append({'key':key,'name':_JOB_LABEL.get(key,key),'every':si,'last':last_real(key,pats),
                     'next':_SCHED['jobs'][key]+si,'idle':True,'weekly':True})
    rows.append({'key':'clamav','name':'ClamAV virus scan','every':_SCHED['clamav_interval'],'last':last_real('clamav',['scan-clamav-*.json','report-*.json']),
                 'next':_SCHED['clamav']+_SCHED['clamav_interval'],'idle':True})
    if CFG.get('auto_update'):
        rows.append({'key':'update','name':'System updates','every':_SCHED['update_interval'],'last':_SCHED['update'] if _SCHED['update_ran'] else None,
                     'next':_SCHED['update']+_SCHED['update_interval'],'idle':True})
    rows.append({'key':'feed','name':'Bad-computer lists','every':int(CFG['feed_interval']),'last':_SCHED['feed'] or None,
                 'next':(_SCHED['feed'] or now)+int(CFG['feed_interval']),'idle':False})
    rows.append({'key':'defs','name':'Virus/rootkit definitions','every':int(CFG.get('defs_update_interval',43200)),'last':_SCHED['defs'] or None,
                 'next':(_SCHED['defs'] or now)+int(CFG.get('defs_update_interval',43200)),'idle':True})
    try: load=float(Path('/proc/loadavg').read_text().split()[0])
    except Exception: load=None
    return {'ready':True,'now':now,'rows':rows,'load':load,'idle_load':float(CFG.get('idle_load',1.0)),
            'idle_seconds':int(CFG.get('idle_seconds',600)),'idle_since':_SCHED['idle_since'] or None,
            'weekly_today':_SCHED['started_today'],'weekly_per_day':_SCHED['per_day']}

def background():
    last_feed=last_defs=0; idle_since=0
    now0=time.time()
    scan_interval=int(CFG.get('scan_interval',604800))
    clamav_interval=int(CFG.get('clamav_scan_interval',86400))
    stagger=int(CFG.get('scan_stagger_seconds',3600))
    update_interval=int(CFG.get('update_interval',43200))
    update_lead=int(CFG.get('update_lead_seconds',1800))
    # Jobs (AIDE/Lynis/Debsecan/rkhunter/ports+fw/CVE) each run once every
    # scan_interval (weekly by default), but seeded here so their first runs
    # land stagger seconds apart from each other instead of all firing in the
    # same tick -- so a week's worth of scanning is spread across the week.
    ALL_JOBS=SCAN_JOBS+[('cve',cve_scan)]
    last_scan_job={key: now0-scan_interval+i*stagger for i,(key,_) in enumerate(ALL_JOBS)}
    # The seeds above are in memory only, so every restart -- including each
    # package upgrade or reinstall -- made the first job (AIDE, hours on a big
    # home directory) due again at once, however recently it had run. The
    # reports on disk record when each job last ran; never schedule a job
    # earlier than scan_interval after its newest report.
    def _last_report(*patterns):
        newest=0.0
        for pat in patterns:
            for f in REPORTS.glob(pat):
                try: newest=max(newest,f.stat().st_mtime)
                except OSError: pass
        return newest
    runs=_job_runs()
    for key,_ in ALL_JOBS:
        # A full scan (report-*.json) runs every job except the CVE scan.
        seen=_last_report('cve-*.json') if key=='cve' else _last_report(f'scan-{key}-*.json','report-*.json')
        seen=max(seen,runs.get(key,0.0))
        if seen>last_scan_job[key]: last_scan_job[key]=seen
    # Hard per-calendar-day cap on how many weekly jobs are allowed to
    # *start*, independent of how many are due. Staggering (above) only
    # spaces out when jobs first become due -- it does nothing to stop a
    # pile-up of overdue jobs (host was busy/offline for a few days, several
    # weekly jobs are now all overdue at once) from firing back-to-back the
    # instant the machine finally goes idle. This counter is what actually
    # enforces "no more than scan_jobs_per_day weekly jobs start on the same
    # day" regardless of how the due-list looks. Resets whenever the local
    # calendar date changes; like everything else here it's in-memory and
    # reseeds on a service restart (same as last_scan_job above).
    scan_jobs_per_day=int(CFG.get('scan_jobs_per_day',1))
    jobs_started_today=0
    last_job_date=time.strftime('%Y-%m-%d', time.localtime(now0))
    # ClamAV runs on its own, faster, daily cadence -- seeded half a stagger
    # step off the weekly jobs' offsets so it doesn't land on the same tick.
    last_clamav=now0-clamav_interval+(stagger//2)
    last_clamav=max(last_clamav,_last_report('scan-clamav-*.json','report-*.json'),runs.get('clamav',0.0))
    # Package updates run twice a day (update_interval), independent of the
    # weekly scan cadence now; seeded update_lead seconds before a clamav run
    # so patches land before that day's antivirus pass rather than racing it.
    last_update=now0-update_interval+max(0,(stagger//2)-update_lead)
    update_ran=False
    while not STOP_EVENT.is_set():
        try:
            now=time.time()
            _SCHED.update(jobs=dict(last_scan_job),jobs_list=ALL_JOBS,scan_interval=scan_interval,clamav=last_clamav,
                          clamav_interval=clamav_interval,update=last_update,update_ran=update_ran,update_interval=update_interval,
                          feed=last_feed,defs=last_defs,idle_since=idle_since,started_today=jobs_started_today,per_day=scan_jobs_per_day)
            # The monitors (logins, journal, fallback firewall, block pruning) run
            # on their own thread, monitor_loop(), so a scan that takes hours here
            # no longer stops brute-force blocking or port-scan detection.
            if idle_enough():
                idle_since = idle_since or now
            else:
                idle_since = 0
            if now-last_defs>=int(CFG.get('defs_update_interval',43200)) and idle_since and now-idle_since>=int(CFG.get('idle_seconds',600)):
                if JOB_LOCK.acquire(blocking=False,job='Virus/rootkit definition update',origin='scheduled'):
                    try: update_definitions()
                    finally: JOB_LOCK.release(); last_defs=now
            if now-last_feed>=int(CFG['feed_interval']):
                # Only mark this cycle done when the job actually ran. Previously
                # last_feed was stamped even when JOB_LOCK was busy (another job
                # in progress), which could silently starve feed updates forever
                # under sustained contention instead of retrying next minute like
                # heavy_scan/package_update already do.
                if JOB_LOCK.acquire(blocking=False,job='Threat-feed update',origin='scheduled'):
                    fr=None
                    try: fr=feed_update()
                    finally: JOB_LOCK.release(); last_feed=now
                    # The first run happens seconds after the service starts, which
                    # at boot is often before DNS works. A run where every source
                    # failed is retried in 15 minutes instead of waiting a full
                    # feed_interval (12 hours by default).
                    if isinstance(fr,dict) and fr.get('kept_previous'):
                        last_feed=now-int(CFG['feed_interval'])+900
            # Staggered weekly scans: due once every scan_interval per job, but
            # (as before) only actually started once the machine has been
            # idle for idle_seconds straight. A due-but-not-idle job just
            # waits -- it isn't skipped, it fires as soon as idle_seconds is
            # met. Only one job (whichever is most overdue) starts per tick,
            # so a full week's worth of scans still land roughly stagger
            # seconds apart rather than all firing back-to-back once idle.
            # On top of that spacing, scan_jobs_per_day hard-caps how many
            # weekly jobs can *start* on the same calendar day -- if several
            # are overdue at once (host was busy/offline for a while), only
            # the cap's worth start today; the rest wait for the following
            # day(s) instead of running back-to-back.
            today=time.strftime('%Y-%m-%d', time.localtime(now))
            if today!=last_job_date:
                last_job_date=today; jobs_started_today=0
            if (idle_since and now-idle_since>=int(CFG.get('idle_seconds',600))
                    and jobs_started_today<scan_jobs_per_day):
                due=[(key,fn) for key,fn in ALL_JOBS if now-last_scan_job[key]>=scan_interval]
                if due:
                    key,fn=min(due,key=lambda kv: last_scan_job[kv[0]])
                    if JOB_LOCK.acquire(blocking=False,job=_JOB_LABEL.get(key,key)+' scan',origin='scheduled'):
                        # Stamped even if the job raises (a report write failing after a
                        # three-hour AIDE run), or it would start again next minute.
                        res=None
                        try:
                            res=cve_scan() if key=='cve' else run_scan_job(key,fn)
                        finally:
                            JOB_LOCK.release()
                            if isinstance(res,dict) and res.get('busy'):
                                # Another AIDE run held the database: try again in an hour.
                                last_scan_job[key]=now-scan_interval+3600
                            elif not (isinstance(res,dict) and res.get('interrupted')):
                                # Stamped even if the job raised, or it would start again next minute.
                                last_scan_job[key]=now; jobs_started_today+=1
            # ClamAV: same idle gate as the weekly scans above, but on its own
            # daily clamav_interval, separate from the once-a-week jobs.
            if idle_since and now-idle_since>=int(CFG.get('idle_seconds',600)) and now-last_clamav>=clamav_interval:
                if JOB_LOCK.acquire(blocking=False,job='ClamAV scan',origin='scheduled'):
                    res=None
                    try: res=run_scan_job(*CLAMAV_JOB)
                    finally:
                        JOB_LOCK.release()
                        if not (isinstance(res,dict) and res.get('interrupted')): last_clamav=now
            # Package updates: twice a day (update_interval), same idle gate
            # as the scans -- a due update waits for the machine to be idle
            # before running rather than being skipped.
            if CFG.get('auto_update') and idle_since and now-idle_since>=int(CFG.get('idle_seconds',600)) and now-last_update>=update_interval:
                if JOB_LOCK.acquire(blocking=False,job='System update',origin='scheduled'):
                    try: package_update()
                    finally: JOB_LOCK.release(); last_update=now; update_ran=True
        except Exception as e: log(f'background loop: {e}','ERROR')
        STOP_EVENT.wait(60)

def monitor_loop():
    """Detection that must keep running whatever the scheduler is doing: failed
    logins, the journal (port scans, firewall drops), the fallback firewall, and
    hourly expiry of blocks and old state. Each step is isolated, so one failing
    (a full disk, a tool that hangs and times out) does not skip the others."""
    last_auth=0.0; last_prune=0.0
    def step(name,fn):
        try: fn()
        except Exception as e: log(f'{name}: {e}','ERROR')
    while not STOP_EVENT.is_set():
        now=time.time()
        if now-last_auth>=max(15,int(CFG.get('event_poll_seconds',60))):
            step('login monitor',login_monitor); last_auth=now
        step('fallback firewall',fallback_firewall_check)
        step('journal monitor',monitor_journal)
        if now-last_prune>=3600:
            step('block expiry',prune_expired_blocks); step('state cleanup',prune_runtime_state); step('incident cleanup',prune_incidents)
            last_prune=now
        STOP_EVENT.wait(60)

def main():
    if os.geteuid()!=0: print('locsecd must run as root',file=sys.stderr); return 1
    # logrotate sends SIGHUP after rotating our log; log() reopens the file on
    # every write already so there's nothing to reopen, but SIGHUP's default
    # action is to terminate the process -- ignore it so a weekly log rotation
    # doesn't kill the daemon (dropping in-progress captures/scans/JOB_LOCK).
    signal.signal(signal.SIGHUP, signal.SIG_IGN)
    oneshot=any(a in sys.argv for a in ('--once-scan','--once-cve','--update','--feed-update','--aide-init','--aide-accept','--aide-reinitialize','--once-job'))
    if oneshot:
        def _oneshot_stop(signum,frame):
            # Ctrl-C or a kill during "locsecctl scan" and friends: stop the transient
            # unit doing the work now (it would otherwise run on until RuntimeMaxSec),
            # and unwind without writing a report or marking the job as run.
            STOP_EVENT.set(); _stop_inflight_priv_units()
            raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, _oneshot_stop); signal.signal(signal.SIGINT, _oneshot_stop)
        try: return _main_oneshot()
        except KeyboardInterrupt:
            print('locsecd: interrupted; the running job was stopped and nothing was recorded',file=sys.stderr); return 130
    signal.signal(signal.SIGTERM, _shutdown_handler)
    signal.signal(signal.SIGINT, _shutdown_handler)
    return _main_daemon()

def _daemon_running():
    if not have('systemctl'): return False
    rc,_=run(['systemctl','is-active','--quiet','locsecd.service'],10)
    return rc==0

def _main_oneshot():
    token_value()
    # The one-shot modes (locsecctl scan, scan-*, cve, update, feed-update)
    # used to replay every persisted block first. That is the running daemon's
    # job, it cost one ufw/nft call per block before the requested work began,
    # and it pruned and rewrote blocks.json from a second process that shares
    # no lock with the daemon, so a block the daemon added meanwhile could be
    # dropped from the file.
    if '--once-scan' in sys.argv: print(json.dumps(heavy_scan(),indent=2)); return 0
    if '--once-cve' in sys.argv: print(json.dumps(cve_scan(),indent=2)); return 0
    if '--update' in sys.argv: print(json.dumps(package_update(),indent=2)); return 0
    if '--feed-update' in sys.argv:
        # A feed update rewrites blocks.json and the firewall; two processes doing that
        # at once lose each other's blocks (the lock is per process). The running
        # service updates the feeds itself; use the dashboard's button to ask now.
        if _daemon_running():
            print(json.dumps({'ok':False,'error':'locsecd.service is running and owns the block list. Use "Update feeds now" '
                              'on the Threat Intelligence page, or stop the service first (sudo systemctl stop locsecd).'},indent=2))
            return 1
        print(json.dumps(feed_update(),indent=2)); return 0
    if '--aide-init' in sys.argv: print(json.dumps(aide_init(),indent=2)); return 0
    if '--aide-accept' in sys.argv:
        print(json.dumps(aide_accept_pending(True),indent=2)); return 0
    if '--aide-reinitialize' in sys.argv:
        print(json.dumps(aide_reinitialize(True),indent=2)); return 0
    if '--once-job' in sys.argv:
        # Run a single scan job immediately by name, bypassing the weekly/daily
        # schedule -- e.g. `locsecctl scan-aide` when you only want AIDE's
        # result and don't want to wait through a full ClamAV pass first.
        i=sys.argv.index('--once-job')
        key=sys.argv[i+1] if i+1<len(sys.argv) else ''
        jobs=dict(SCAN_JOBS+[CLAMAV_JOB])
        if key not in jobs:
            print(json.dumps({'ok':False,'error':f'unknown job "{key}"; choices: {sorted(jobs)}'},indent=2)); return 1
        print(json.dumps(run_scan_job(key,jobs[key]),indent=2)); return 0
    return 2

def _main_daemon():
    global DAEMON_MODE
    DAEMON_MODE=True
    token_value()
    # restore_blocks() replays every persisted block through ufw/nft (one subprocess
    # call each, ~0.2-0.3s apiece); with a large blocks.json that can take minutes.
    # Run it in the background thread instead of blocking startup, so the
    # dashboard/API comes up immediately even with hundreds+ of persisted blocks.
    def background_with_restore():
        # A failure in one startup step (a full disk while restoring blocks) must
        # not kill the scheduler: server() would then exit and systemd restart
        # straight back into the same failure.
        def fallback_state():
            # A fallback chain left by the previous run (it stays on purpose while UFW is
            # off): adopt it, rather than "installing" it again with a new incident and a
            # desktop notification on every restart.
            if have('nft') and _fallback_present(): _FALLBACK['on']=True
        for name,fn in (('orphan unit sweep',_sweep_orphan_units),('freshclam restore',_restore_freshclam),
                        ('ClamAV cleanup',_clamav_sweep_stale),('fallback state',fallback_state)):
            try: fn()
            except Exception as e: log(f'startup {name}: {e}','ERROR')
        # Detection first: putting hundreds of blocks back can take minutes.
        threading.Thread(target=monitor_loop,daemon=True,name='monitor').start()
        try: restore_blocks()
        except Exception as e: log(f'startup block restore: {e}','ERROR')
        background()
    t=threading.Thread(target=background_with_restore,daemon=True,name='background'); t.start()
    threading.Thread(target=_notifier_loop,daemon=True,name='notifier').start()
    return server(t)
if __name__=='__main__': sys.exit(main())
