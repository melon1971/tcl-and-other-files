"""0.45: numpy ground texturing.

The ground colour field (biome colour, lush/dry patches, hills) is painted by gfx.render_chunk_steps.
This module adds the fine surface on top of it, per pixel and world-aligned so it runs seamlessly
across chunks: leafy clumps with lit tips and shaded gaps on grass, grit and pebbles on soil,
a soft grain on sand and snow, and only faint ripples on water.  Everything is built once from
tileable FFT noise, then each chunk is a handful of numpy array operations (a few ms).

numpy ships with python3-pygame on Debian/Ubuntu; if it is missing, HAVE_NP is False and the
game keeps the old multiply texture.
"""
try:
    import numpy as np
    import pygame.surfarray as _sa
    HAVE_NP = True
except Exception:          # pragma: no cover - old path stays available
    np = None; _sa = None
    HAVE_NP = False

N = 512                     # texture period in screen pixels (big enough that repeats don't show)
_T = {}


def _band(rng, lo, hi, aniso=2.0):
    """Tileable noise with features between `lo` and `hi` pixels across, squashed 2:1 for the iso ground."""
    white = rng.standard_normal((N, N)).astype(np.float32)
    fy = np.fft.fftfreq(N)[:, None] * aniso      # iso: features are half as tall as they are wide
    fx = np.fft.fftfreq(N)[None, :]
    f = np.sqrt(fx * fx + fy * fy) + 1e-9
    band = ((f >= 1.0 / hi) & (f <= 1.0 / lo)).astype(np.float32)
    band = band * np.exp(-((np.log(f * lo)) ** 2) * .15)
    out = np.real(np.fft.ifft2(np.fft.fft2(white) * band)).astype(np.float32)
    out -= out.mean(); out /= (out.std() + 1e-6)
    return out


def _build():
    if _T: return _T
    rng = np.random.default_rng(4512)
    leaf = _band(rng, 2.5, 7)            # single grass clumps
    clump = _band(rng, 7, 22)            # tussocks
    mid = _band(rng, 20, 70)             # light / shade patches
    macro = _band(rng, 70, 220)          # broad swells
    grain = rng.standard_normal((N, N)).astype(np.float32)
    # grass: crisp leafy clumps (tanh keeps them punchy), dark crevices between them
    lc = np.tanh(leaf * 1.3 + clump * .55)
    crev = np.clip(-(leaf + .35 * clump) - .9, 0, 2)
    _T["grass_l"] = (1.0 + .13 * lc + .07 * mid + .05 * macro + .025 * grain - .16 * crev).astype(np.float32)
    _T["grass_t"] = lc.astype(np.float32)               # +1 lit tip, -1 shaded base: drives the hue shift
    # soil: grit, small stones (bright specks with a shadow under them), soft patches
    peb = np.clip(_band(rng, 2, 5) - 1.6, 0, 3)
    peb_sh = np.roll(peb, 2, axis=0)
    _T["dirt_l"] = (1.0 + .06 * leaf + .07 * clump + .07 * mid + .04 * macro + .05 * grain + .22 * peb - .18 * peb_sh).astype(np.float32)
    # sand / snow / paving: very soft, so bright ground stays clean and readable
    _T["soft_l"] = (1.0 + .025 * leaf + .035 * mid + .03 * macro + .02 * grain).astype(np.float32)
    # water: long soft ripples only (kept for the old path)
    rip = _band(rng, 6, 30, aniso=4.0)
    _T["water_l"] = (1.0 + .05 * rip + .03 * macro).astype(np.float32)
    # 1.0.19: realistic water - a wave height field (wind ripples on top of a slow swell), lit like a surface:
    # the slope toward the sun brightens, the slope away darkens, and the steepest sun-facing crests sparkle
    wave = (_band(rng, 3, 9, aniso=3.0) * .55 + _band(rng, 9, 26, aniso=3.0) * .35 + _band(rng, 26, 90, aniso=2.5) * .25)
    gx_ = (np.roll(wave, -1, 1) - np.roll(wave, 1, 1)) * .5
    gy_ = (np.roll(wave, -1, 0) - np.roll(wave, 1, 0)) * .5
    lit = -(gx_ * .55 + gy_ * .85)                         # sun from the upper left
    lit = lit / (lit.std() + 1e-6)
    _T["wave_lit"] = np.tanh(lit * .9).astype(np.float32)
    spark = np.clip(lit - 2.1, 0, 3) * np.clip(_band(rng, 1.5, 4) - .3, 0, 3)
    _T["wave_spark"] = np.clip(spark / (spark.max() + 1e-6) * 3.0, 0, 1).astype(np.float32)
    _T["water_sky"] = _band(rng, 60, 260, aniso=1.5).astype(np.float32)      # broad patches of reflected sky
    return _T


def _tile(t, gx, gy, w, h):
    """The w x h window of tileable texture t that starts at world screen pixel (gx, gy)."""
    ys = (np.arange(h) + gy) % N
    xs = (np.arange(w) + gx) % N
    return t[ys[:, None], xs[None, :]]


def texture_ground(surf, gx, gy, kinds=None):
    """Apply the ground surface texture in place to an opaque Surface whose top-left is world screen pixel (gx, gy)."""
    T = _build()
    px = _sa.pixels3d(surf)                       # (w, h, 3) view, x-major like pygame
    w, h = px.shape[0], px.shape[1]
    c = px.astype(np.float32).transpose(1, 0, 2)  # (h, w, 3)
    R, G, B = c[..., 0], c[..., 1], c[..., 2]
    lum = (R * .3 + G * .59 + B * .11)
    # what kind of ground each pixel is, from its colour (soft weights, so transitions blend)
    wg = np.clip((G - (R + B) * .5 - 4) / 22.0, 0, 1)                    # green -> grass
    if kinds is not None:                                                  # surface type from the tiles themselves
        k = _sa.pixels3d(kinds).transpose(1, 0, 2).astype(np.float32) / 255.0
        ww = k[..., 0]; ws = np.maximum(k[..., 1], np.clip((lum - 200) / 30.0, 0, 1)) * (1 - wg)
    else:
        ww = np.clip((B - R - 18) / 30.0, 0, 1) * np.clip((B - G + 30) / 30.0, 0, 1)   # blue -> water
        ws = np.clip((lum - 168) / 40.0, 0, 1) * (1 - wg)                  # bright -> sand / snow / paving
    wg = wg * (1 - ws)
    wg = wg * (1 - ww); ws = ws * (1 - ww)
    wd = np.clip(1 - wg - ww - ws, 0, 1)                                   # the rest -> soil
    L = (_tile(T["grass_l"], gx, gy, w, h) * wg + _tile(T["dirt_l"], gx, gy, w, h) * wd +
         _tile(T["soft_l"], gx, gy, w, h) * ws + ww)
    out = c * L[..., None]
    if ww.max() > 0:
        # 1.0.19 realistic water: depth (kinds blue channel, 0 at the shore .. 1 deep) - a sandy bottom shows through
        # the shallows and the colour sinks toward deep blue-green; then lit wind ripples, sky reflection and sun glints
        dep = k[..., 2] if kinds is not None else np.full_like(ww, .7)
        dep = np.clip(dep, 0, 1)
        base = out
        lumw = (base[..., 0] * .3 + base[..., 1] * .59 + base[..., 2] * .11)[..., None]
        bottom = np.stack([lumw[..., 0] * 1.05 + 30, lumw[..., 0] * 1.0 + 22, lumw[..., 0] * .72 + 4], -1)   # sand / silt under clear shallows
        deep = base * np.array([.58, .76, .84], np.float32)
        sh = np.clip(1 - dep / .55, 0, 1)[..., None]                       # 1 at the waterline, 0 from ~half depth
        dk = np.clip((dep - .25) / .75, 0, 1)[..., None]
        wc = base * (1 - dk) + deep * dk
        wc = wc * (1 - sh * .62) + bottom * (sh * .62)
        lit = _tile(T["wave_lit"], gx, gy, w, h)
        sky = _tile(T["water_sky"], gx, gy, w, h)
        amp = (.35 + .65 * np.clip(dep * 1.6, 0, 1))                        # calmer right at the edge
        wc = wc * (1 + (.16 * lit * amp))[..., None]
        refl = np.clip(.15 + .08 * sky, 0, .3)[..., None] * (.4 + .6 * dk)  # a pale sky sheen over open water
        wc = wc * (1 - refl) + np.array([178, 204, 222], np.float32) * refl
        sp = _tile(T["wave_spark"], gx, gy, w, h) * amp
        wc = wc + (sp * 150.0)[..., None]
        m = ww[..., None]
        out = out * (1 - m) + wc * m
    # grass hue: lit tips lean warm yellow-green, shaded bases lean cool blue-green (D2-style depth, still bright)
    tt = _tile(T["grass_t"], gx, gy, w, h) * wg
    out[..., 0] += tt * 7.0
    out[..., 1] += tt * 9.0
    out[..., 2] -= tt * 6.0
    np.clip(out, 0, 255, out=out)
    px[...] = out.transpose(1, 0, 2).astype(np.uint8)
    del px


def enhance_sprite(spr, sat=1.14, sharp=.55):
    """0.45: finishing pass for characters and monsters - a touch more colour and a crisper edge, so figures stand out
    on the textured ground.  Works in place on a copy; returns the original if numpy is missing."""
    if not HAVE_NP: return spr
    try:
        out = spr.copy()
        px = _sa.pixels3d(out); al = _sa.pixels_alpha(out)
        c = px.astype(np.float32)
        a = al.astype(np.float32) / 255.0
        lum = (c[..., 0] * .3 + c[..., 1] * .59 + c[..., 2] * .11)[..., None]
        c = lum + (c - lum) * sat                                   # saturation
        # unsharp mask with a 3x3 box blur (alpha-weighted so the transparent edge does not bleed in)
        w = a[..., None]
        num = c * w; den = w.copy()
        bn = np.zeros_like(num); bd = np.zeros_like(den)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                bn += np.roll(np.roll(num, dx, 0), dy, 1); bd += np.roll(np.roll(den, dx, 0), dy, 1)
        blur = bn / np.maximum(bd, 1e-3)
        c = c + (c - blur) * sharp
        np.clip(c, 0, 255, out=c)
        px[...] = c.astype(np.uint8)
        del px, al
        return out
    except Exception:
        return spr


def relight(spr, radius=7.0, strength=.85, detail=.35, metal=.55):
    """1.0.19: volumetric relighting for a finished sprite (characters, NPCs, monsters, buildings).
    A rounded surface is inferred from the silhouette (distance to the edge, rounded like a cylinder) plus the sprite's own
    shading (lighter reads as nearer), then lit: sun from the upper left, cool sky fill from above, a specular highlight
    that is strongest on bright, low-saturation pixels (metal, polish) and a soft rim light.  Returns a new surface."""
    if not HAVE_NP: return spr
    try:
        out = spr.copy()
        px = _sa.pixels3d(out); al = _sa.pixels_alpha(out)
        c = px.astype(np.float32).transpose(1, 0, 2)               # (h, w, 3)
        a = al.astype(np.float32).T / 255.0
        h, w = a.shape
        inside = a > .5
        # distance to the silhouette edge (4-neighbour erosion), capped at radius
        d = np.zeros((h, w), np.float32); cur = inside.copy()
        R = int(max(2, radius))
        for i in range(R):
            d += cur
            nxt = cur.copy()
            nxt[1:, :] &= cur[:-1, :]; nxt[:-1, :] &= cur[1:, :]; nxt[:, 1:] &= cur[:, :-1]; nxt[:, :-1] &= cur[:, 1:]
            nxt[0, :] = False; nxt[-1, :] = False; nxt[:, 0] = False; nxt[:, -1] = False
            cur = nxt
            if not cur.any(): break
        t = np.clip(d / R, 0, 1)
        H = np.sqrt(np.clip(1 - (1 - t) ** 2, 0, 1)) * R              # rounded profile
        lum = c[..., 0] * .3 + c[..., 1] * .59 + c[..., 2] * .11
        # local detail from the sprite's own shading (high-pass of luminance)
        bl = lum.copy()
        for _ in range(2):
            bl = (bl + np.roll(bl, 1, 0) + np.roll(bl, -1, 0) + np.roll(bl, 1, 1) + np.roll(bl, -1, 1)) / 5.0
        H = H + (lum - bl) / 255.0 * R * detail * 2.0
        gx = np.zeros_like(H); gy = np.zeros_like(H)
        gx[:, 1:-1] = (H[:, 2:] - H[:, :-2]) * .5
        gy[1:-1, :] = (H[2:, :] - H[:-2, :]) * .5
        n = np.stack([-gx, -gy, np.ones_like(H) * 1.1], -1)
        n /= np.linalg.norm(n, axis=-1, keepdims=True) + 1e-6
        L = np.array([-.55, -.68, .6], np.float32); L /= np.linalg.norm(L)
        diff = np.clip(n @ L, 0, 1)
        sky = np.clip(-n[..., 1] * .5 + .5, 0, 1)
        hv = L + np.array([0, 0, 1], np.float32); hv /= np.linalg.norm(hv)
        mx = c.max(-1); mn = c.min(-1)
        sat = (mx - mn) / (mx + 1e-3)
        shiny = np.clip((lum - 90) / 120.0, 0, 1) * np.clip(1 - sat * 1.6, 0, 1) * metal
        spec = np.clip(n @ hv, 0, 1) ** 18 * shiny
        rim = np.clip(1 - n[..., 2], 0, 1) ** 2
        shade = (.62 + .14 * sky) + .52 * diff
        lit = c * shade[..., None] + (spec * 230.0)[..., None] + rim[..., None] * np.array([40, 46, 60], np.float32) * .6
        res = c * (1 - strength) + lit * strength
        np.clip(res, 0, 255, out=res)
        m = inside[..., None]
        px[...] = np.where(m, res, c).transpose(1, 0, 2).astype(np.uint8)
        del px, al
        return out
    except Exception:
        return spr


def material_relief(surf, bump=1.5, ao=.45, base_shadow=.3):
    """1.0.21: give painted materials real depth (buildings, walls, stations).  The fine detail already in the picture -
    stone joints, roof tiles, planks, mortar - is read as a bump map: joints and grooves sink, faces bulge; the bumps are lit
    from the sun (upper left), crevices darken (cavity occlusion) and the foot of the object darkens toward the ground.
    Works in place on an RGBA surface at its full drawing resolution."""
    if not HAVE_NP: return surf
    try:
        px = _sa.pixels3d(surf); al = _sa.pixels_alpha(surf)
        c = px.astype(np.float32).transpose(1, 0, 2)
        a = al.T.astype(np.float32) / 255.0
        inside = a > .5
        if not inside.any():
            del px, al; return surf
        lum = c[..., 0] * .3 + c[..., 1] * .59 + c[..., 2] * .11
        def blur(x, n):
            for _ in range(n):
                x = (x * 2 + np.roll(x, 1, 0) + np.roll(x, -1, 0) + np.roll(x, 1, 1) + np.roll(x, -1, 1)) / 6.0
            return x
        lb = blur(lum, 3)
        hgt = (lum - blur(lum, 9)) / 40.0 * bump                     # local relief from the drawing's own shading
        hgt = blur(hgt, 1)
        gx = np.zeros_like(hgt); gy = np.zeros_like(hgt)
        gx[:, 1:-1] = (hgt[:, 2:] - hgt[:, :-2]) * .5; gy[1:-1, :] = (hgt[2:, :] - hgt[:-2, :]) * .5
        Lx, Ly = -.6, -.7
        lit = np.clip(-(gx * Lx + gy * Ly) * 2.2, -.35, .35)          # slopes facing the sun brighten
        cav = np.clip((lb - lum) / 60.0, 0, 1) * ao                     # crevices and joints darken
        # darken toward the bottom of the object (ambient occlusion from the ground)
        h, w = lum.shape
        rows = np.arange(h, dtype=np.float32)[:, None]
        colmask = inside.any(axis=0)
        bot = np.where(colmask, h - 1 - np.argmax(inside[::-1, :], axis=0), 0).astype(np.float32)[None, :]
        dist = np.clip((bot - rows) / 40.0, 0, 1)
        foot = (1 - dist) ** 2 * base_shadow
        k = (1 + lit) * (1 - cav) * (1 - foot)
        res = c * k[..., None]
        np.clip(res, 0, 255, out=res)
        px[...] = np.where(inside[..., None], res, c).transpose(1, 0, 2).astype(np.uint8)
        del px, al
    except Exception:
        pass
    return surf
