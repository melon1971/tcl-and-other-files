"""Procedural isometric graphics for LiveWorld RPG (Conquer-style 2.5D).

Everything is drawn with pygame primitives at 2x resolution and smoothscaled
down, so the game ships without any image assets.  Sprites are cached.
"""
import math, pygame, collections, time as _time
from . import terrain as _terrain

_LP = [0.0]


def pump():
    """Keep the window responsive while a slow sprite/chunk is being built (stops the OS 'not responding' prompt)."""
    n = _time.time()
    if n - _LP[0] > .15:
        _LP[0] = n
        try: pygame.event.pump()
        except Exception: pass

from .engine import BIOME_OF, bz, AREAS, W, H, WORLD_H, TOWN_PLAZA_R, TOWN_WALL_R, TOWN_BLOCK_R, TOWN_CLEAR_R, SHOP_POSTS, KING_POST, BUILDING_ROLES, TS

TW, TH = 64, 32           # isometric tile size in pixels
HTW, HTH = TW // 2, TH // 2
CS = 8                    # ground chunk size in tiles
CO_STYLE = True           # town architecture, plazas and lanterns (0.16; medieval since 0.45)

def iso(x, y):
    return (x - y) * HTW, (x + y) * HTH

def uniso(sx, sy):
    a = sx / HTW; b = sy / HTH
    return (a + b) / 2, (b - a) / 2

def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3])

def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def h01(x, y, salt=0):
    n = (int(x) * 374761393 + int(y) * 668265263 + salt * 2147483647) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0

def vnoise(x, y, cell=6, salt=0):
    gx, gy = x / cell, y / cell
    x0, y0 = math.floor(gx), math.floor(gy); fx, fy = gx - x0, gy - y0
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy)
    a = h01(x0, y0, salt); b = h01(x0 + 1, y0, salt); c = h01(x0, y0 + 1, salt); d = h01(x0 + 1, y0 + 1, salt)
    return (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy

# ---------------------------------------------------------------- biomes
BIOMES = {
 "Greenfields":    dict(base=(82,142,64),  alt=(104,158,72), speck=(130,180,90), decor=[("oak",4),("willow",3),("pine",2),("bush",3),("rock",1),("flowers",4),("tallgrass",4),("fern",2),("stump",1),("log",1),("boulders",1)], density=.09),
 "Ashen Vale":     dict(base=(104,92,72),  alt=(122,100,70), speck=(80,70,60),   decor=[("dead",5),("rock",3),("drybush",3),("stump",2),("log",1),("boulders",2),("bones",1),("ruin",1)], density=.08),
 "Ironwood":       dict(base=(52,102,50),  alt=(66,116,56),  speck=(40,80,40),   decor=[("pine",6),("oak",4),("bush",2),("rock",1),("fern",4),("stump",2),("log",2),("mushroom",1),("boulders",1),("glowshroom",1)], density=.19),
 "Frostmarch":     dict(base=(218,226,238),alt=(196,210,228),speck=(250,252,255),decor=[("snowpine",7),("icerock",3),("iceshard",3),("stump",1),("ribs",1),("boulders",1)], density=.1),
 "Storm Coast":    dict(base=(172,162,118),alt=(110,146,88), speck=(200,190,150),decor=[("rock",5),("bush",3),("palm",3),("dunegrass",4),("log",2),("boulders",2),("ribs",1)], density=.07),
 "Bloodfen":       dict(base=(70,84,52),   alt=(92,62,58),   speck=(50,60,40),   decor=[("mushroom",4),("dead",4),("reeds",4),("glowshroom",2),("log",2),("stump",2),("fern",2),("bones",1)], density=.11),
 "Crownlands":     dict(base=(98,158,74),  alt=(118,170,82), speck=(150,200,100),decor=[("oak",4),("willow",3),("bush",2),("flowers",4),("tallgrass",3),("haystack",1),("ruin",1),("stump",1),("fern",1)], density=.07),
 "Dreadmoor":      dict(base=(72,60,84),   alt=(58,54,68),   speck=(100,80,110), decor=[("dead",5),("tomb",4),("rock",2),("ruin",2),("bones",2),("glowshroom",1),("stump",1)], density=.09),
 "Sunscar Desert": dict(base=(214,182,120),alt=(198,164,102),speck=(230,200,140),decor=[("cactus",5),("rock",4),("bones",2),("dunegrass",3),("ribs",2),("boulders",2),("ruin",1),("drybush",2)], density=.06),
 "Ember Highlands":dict(base=(74,54,46),   alt=(96,60,42),   speck=(140,70,40),  decor=[("lavarock",5),("dead",3),("rock",2),("vent",2),("boulders",2),("ribs",1),("ruin",1)], density=.08),
 "Wyrmreach":      dict(base=(60,74,82),   alt=(76,68,94),   speck=(100,120,140),decor=[("crystal",5),("rock",5),("boulders",3),("menhir",1),("ribs",1),("iceshard",1)], density=.08),
 "Shadowlands":    dict(base=(42,32,54),   alt=(58,38,74),   speck=(90,60,120),  decor=[("darkcrystal",5),("dead",3),("tomb",2),("menhir",1),("ruin",2),("glowshroom",2),("bones",1)], density=.08),
}

# 0.23: the darker biomes are lifted so the world reads clearly in daylight (no more murky brown/black fields)
GROUND_LIFT = {"Ashen Vale": 1.24, "Ironwood": 1.18, "Bloodfen": 1.22, "Dreadmoor": 1.28, "Ember Highlands": 1.28,
               "Wyrmreach": 1.22, "Shadowlands": 1.38, "Storm Coast": 1.05}
for _n, _b in BIOME_OF.items():          # 0.35.1: the newer zones wear the look of an original one
    BIOMES[_n] = BIOMES[_b]
    if _b in GROUND_LIFT: GROUND_LIFT[_n] = GROUND_LIFT[_b]

def _area_rect(x, y):
    for a in AREAS:
        if a[1] <= x < a[1] + a[3] and a[2] <= y < a[2] + a[4]:
            return a
    return None

_NEAR = {}
def near_items(items, x, y, r):
    """0.46.27: the entries of `items` (tuples whose first two fields are x, y) that may lie within r of (x, y).  The world has
    thousands of props and buildings and they used to be scanned in full several times a frame; a coarse grid is built once.
    Callers keep their own exact distance test."""
    e = _NEAR.get(id(items))
    if e is None or e[0] is not items or e[1] != len(items):
        grid = {}
        for it in items:
            grid.setdefault((math.floor(it[0]) >> 4, math.floor(it[1]) >> 4), []).append(it)
        if len(_NEAR) > 6: _NEAR.clear()
        _NEAR[id(items)] = e = (items, len(items), grid)
    g = e[2]; out = []
    for cx in range(math.floor(x - r) >> 4, (math.floor(x + r) >> 4) + 1):
        for cy in range(math.floor(y - r) >> 4, (math.floor(y + r) >> 4) + 1):
            c = g.get((cx, cy))
            if c: out.extend(c)
    return out

_AREA_C = {}
_WARP = {}
def _warp_pt(gx, gy):
    """Border wobble at a 4-tile lattice point (sampled once, then interpolated: far cheaper than noise on every tile)."""
    v = _WARP.get((gx, gy))
    if v is None:
        if len(_WARP) > 40000: _WARP.clear()          # 0.45: bounded (cheap to refill)
        x, y = gx * 4, gy * 4
        v = _WARP[(gx, gy)] = ((vnoise(x, y, 48, 33) - .5) * 70 + (vnoise(x, y, 20, 31) - .5) * 24,
                               (vnoise(x, y, 48, 34) - .5) * 70 + (vnoise(x, y, 20, 32) - .5) * 24)
    return v
def area_at(x, y):
    """Biome at a tile.  Zone borders wander in broad smooth curves (a real coastline/treeline, not a ruler line)
    instead of following the zone rectangles, and the lookup is cached."""
    k = (math.floor(x), math.floor(y))
    v = _AREA_C.get(k, 0)
    if v == 0:
        gx, gy = k[0] >> 2, k[1] >> 2; fx, fy = (k[0] & 3) / 4, (k[1] & 3) / 4
        a, b, c, d = _warp_pt(gx, gy), _warp_pt(gx + 1, gy), _warp_pt(gx, gy + 1), _warp_pt(gx + 1, gy + 1)
        wx = (a[0] * (1 - fx) + b[0] * fx) * (1 - fy) + (c[0] * (1 - fx) + d[0] * fx) * fy
        wy = (a[1] * (1 - fx) + b[1] * fx) * (1 - fy) + (c[1] * (1 - fx) + d[1] * fx) * fy
        jx = k[0] + .5 + wx + (h01(k[0], k[1], 11) - .5) * 1.4
        jy = k[1] + .5 + wy + (h01(k[0], k[1], 12) - .5) * 1.4
        v = _area_rect(min(W - .01, max(0, jx)), min(H - .01, max(0, jy))) or _area_rect(x, y)
        if len(_AREA_C) > 150000: _AREA_C.clear()          # 0.46.27: was 900000 (~100 MB on a big world)
        _AREA_C[k] = v
    return v

# ------------------------------------------------------------- world map
STATION_POSTS = {"forge": (10.6, -9.2), "hut": (-13.4, -1.2), "press": (10.8, 9.6), "warhall": (-9.5, -11.5), "magic": (-8.8, 11.0),
                 # 0.39: buildings that replace shopkeepers: the Apothecary beside the Wine Press, the Inn beside the Skill Shop,
                 # and the Jeweler with its Kiln next door
                 "apothecary": (6.6, 13.6), "inn": (-4.0, 14.6), "jeweler": (14.4, 3.4), "kiln": (14.2, -1.0),
                 # 0.40: the Blacksmith's shop beside the Forge, and a General Store on the west side
                 "smithy": (13.8, -5.6), "general": (-12.6, 5.8), "enchanter": (-14.0, -6.4),
                 "bank": (10.6, 1.0),         # 0.40: the Banker works inside the Bank
                 "stable": (3.6, -12.6),      # 0.40.1: the Stable Master works inside the Stable,
                 "market": (1.0, 12.0)}       # and the Market Warden inside the Trade Market
STATION_POSTS = {k: (v[0] * TS, v[1] * TS) for k, v in STATION_POSTS.items()}     # 0.41: bigger towns


class WorldLayout:
    """Static layout derived from the engine's towns and dungeons: a road network, big walled
    cities with streets and districts, wayside camps, farms and wilderness landmarks."""
    def __init__(self, world):
        self.road = set(); self.plaza = set(); self.street = set(); self.blocked = set(); self.buildings = []
        self.roadlines = []; self.gates = {}
        towns = world.towns
        self.towns = towns; self.dungeons = world.dungeons
        # --- road network: every town reaches the others (spanning tree), plus its two nearest neighbours
        #     and the nearest town of another zone, so the realm is a web of travelled roads rather than a few spokes.
        by_id = {t.id: t for t in towns}
        edges = set()
        if towns:
            inside = {towns[0].id}
            while len(inside) < len(towns):
                best = None
                for i in inside:
                    for o in towns:
                        if o.id in inside: continue
                        dd = (by_id[i].x - o.x) ** 2 + (by_id[i].y - o.y) ** 2
                        if best is None or dd < best[0]: best = (dd, i, o.id)
                inside.add(best[2]); edges.add(tuple(sorted((best[1], best[2]))))
        for t in towns:
            others = sorted((o for o in towns if o.id != t.id), key=lambda o: (o.x - t.x) ** 2 + (o.y - t.y) ** 2)
            for o in others[:2]: edges.add(tuple(sorted((t.id, o.id))))
            foreign = [o for o in others if o.area != t.area]
            if foreign: edges.add(tuple(sorted((t.id, foreign[0].id))))
        for (ia, ib) in sorted(edges):
            a, b = by_id[ia], by_id[ib]
            self._road(a.x, a.y, b.x, b.y)
            self.gates.setdefault(a.id, []).append(math.atan2(b.y - a.y, b.x - a.x))
            self.gates.setdefault(b.id, []).append(math.atan2(a.y - b.y, a.x - b.x))
        # every city has at least four gates, with a short country lane leaving through each extra one
        for t in towns:
            gl = self.gates.setdefault(t.id, [])
            for k in range(4):
                ang = k * math.pi / 2 + .55 + h01(t.id, k, 8) * .3
                if all(abs((g - ang + math.pi) % math.tau - math.pi) > .6 for g in gl):
                    gl.append(ang)
                    self._road(t.x, t.y, t.x + math.cos(ang) * (TOWN_WALL_R + 16), t.y + math.sin(ang) * (TOWN_WALL_R + 16), 0, wander=False)
        for d in world.dungeons:
            t = min(towns, key=lambda t: (t.x - d.x) ** 2 + (t.y - d.y) ** 2)
            self._road(t.x, t.y, d.x, d.y, width=0)
            for dx in range(-2, 3):
                for dy in range(-2, 3):
                    self.blocked.add((int(d.x) + dx, int(d.y) + dy))
        # --- cities
        self.walls = set(); self.props = []
        for t in towns: self._town(t, world)
        self._make_ponds(world)
        self._detail(world)
        self._road_furniture()
        # wall ends next to a gate get a taller tower post
        self.wall_posts = {w for w in self.walls if sum(((w[0] + dx, w[1] + dy) in self.walls) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, -1), (1, -1), (-1, 1))) <= 1}

    # ------------------------------------------------------------ a walled city
    def _town(self, t, world):
        cx, cy = int(t.x), int(t.y); hid = t.id
        R = int(TOWN_BLOCK_R) + 1
        for dx in range(-R, R + 1):
            for dy in range(-R, R + 1):
                dd = math.hypot(cx + dx + .5 - t.x, cy + dy + .5 - t.y)
                if dd <= TOWN_PLAZA_R: self.plaza.add((cx + dx, cy + dy))
                if dd <= TOWN_BLOCK_R: self.blocked.add((cx + dx, cy + dy))
        style = t.faction if t.faction in ("Alliance", "Horde") else "Neutral"
        gates = self.gates.get(t.id, [])
        # streets: a ring road round the market and a broad avenue from the centre to every gate
        for dx in range(-R, R + 1):
            for dy in range(-R, R + 1):
                dd = math.hypot(cx + dx + .5 - t.x, cy + dy + .5 - t.y)
                if 7.4 * TS <= dd < 9.0 * TS: self.street.add((cx + dx, cy + dy))
        for g in gates:
            for s10 in range(30, int(TOWN_PLAZA_R * 10) + 25, 5):
                s = s10 / 10
                x = t.x + math.cos(g) * s; y = t.y + math.sin(g) * s
                for w_ in (-1.1, 0, 1.1):
                    self.street.add((int(x - math.sin(g) * w_), int(y + math.cos(g) * w_)))
        # market square with a fountain (0.39: no market stalls - every trade has its own labelled building)
        self.buildings.append((t.x - .5, t.y - .5, "fountain", style, 0))
        # keep clear: the posts of the townsfolk who still stand outside (quest giver, stable master, banker, ...)
        folk = [(t.x + px, t.y + py) for role_, (px, py) in SHOP_POSTS.items() if role_ not in BUILDING_ROLES]
        keep = folk + [(t.x, t.y)]
        placed_st = []
        self.stations = getattr(self, "stations", {})
        for kind_, (ox, oy) in STATION_POSTS.items():
            base = math.atan2(oy, ox); rad = math.hypot(ox, oy); placed = False
            for da in (0, .1, -.1, .2, -.2, .3, -.3, .45, -.45):
                for dr in (0, 1.5, -1.5, 3.0):
                    bx = t.x + math.cos(base + da) * (rad + dr) - 1; by = t.y + math.sin(base + da) * (rad + dr) - 1
                    if any((int(bx + i), int(by + j)) in self.street for i in (0, 1, 2) for j in (0, 1, 2)): continue
                    if any((bx - q[0]) ** 2 + (by - q[1]) ** 2 < 3.4 ** 2 for q in placed_st): continue      # 0.39: never on top of another
                    if any((bx + 1 - kx) ** 2 + (by + 1 - ky) ** 2 < 2.2 ** 2 for kx, ky in folk): continue    # nor on a townsperson
                    self.buildings.append((bx, by, kind_, style, 0)); self.stations.setdefault(kind_, []).append((bx + 1, by + 1)); keep.append((bx + 1, by + 1)); placed_st.append((bx, by)); placed = True; break
                if placed: break
        def ok_spot(bx, by, r=3.4):
            if (int(bx), int(by)) in self.street or (int(bx + 1), int(by + 1)) in self.street or (int(bx + 2), int(by)) in self.street or (int(bx), int(by + 2)) in self.street:
                return False
            return all((bx + 1 - kx) ** 2 + (by + 1 - ky) ** 2 > r * r for kx, ky in keep) and \
                   all(((bx - b[0]) ** 2 + (by - b[1]) ** 2) > 7.0 for b in self.buildings if b[2] in ("house", "tower"))
        # districts: keeps and temples on an inner ring, houses in two outer rings
        a0 = h01(hid, 1, 6) * math.tau
        tier = world.town_tier(t) if hasattr(world, "town_tier") else "city"
        nkeeps = {"capital": 5, "city": 3, "town": 2}[tier]
        for i in range(nkeeps):
            ang = a0 + i * math.tau / nkeeps; r = (12.0 if tier != "capital" else 13.2) * TS
            bx, by = t.x + math.cos(ang) * r - .7, t.y + math.sin(ang) * r - .7
            if ok_spot(bx, by, 3.0): self.buildings.append((bx, by, "tower", style, int(h01(hid, i, 5) * 3)))
        rings = ((10.4, 9, .9), (14.0, 15, 1.2), (16.2, 18, .5)) if tier != "town" else ((10.4, 7, .9), (14.0, 11, 1.2))
        rings = tuple((r0 * TS, int(round(n * TS)), jit) for (r0, n, jit) in rings)      # 0.41: bigger towns, more houses
        for ring, (r0, n, jit) in enumerate(rings):
            for i in range(n):
                ang = i / n * math.tau + h01(hid, i + ring * 40, 3) * .5 + ring * .21
                r = r0 + h01(hid, i + ring * 40, 4) * jit
                bx, by = t.x + math.cos(ang) * r - 1, t.y + math.sin(ang) * r - 1
                if ok_spot(bx, by): self.buildings.append((bx, by, "house", style, int(h01(hid, i + ring * 40, 5) * 3)))
        # 0.46.36: the major city of every zone has a Waygate: one of its existing houses becomes the teleport building
        if hasattr(world, "teleport_town_ids") and t.id in world.teleport_town_ids():
            hs_ = [(math.hypot(b[0] + 1 - t.x, b[1] + 1 - t.y), i_) for i_, b in enumerate(self.buildings) if b[2] == "house"]
            hs_ = [h_ for h_ in hs_ if 6.0 < h_[0] < 19 * TS]
            if hs_:
                _, i_ = min(hs_); b_ = self.buildings[i_]
                self.buildings[i_] = (b_[0], b_[1], "teleport", b_[3], 0); self.stations.setdefault("teleport", []).append((b_[0] + 1, b_[1] + 1))
        # --- city wall with a gate wherever a road leaves
        cxf, cyf = t.x, t.y
        for x in range(int(cxf) - int(TOWN_WALL_R) - 3, int(cxf) + int(TOWN_WALL_R) + 4):
            for y in range(int(cyf) - int(TOWN_WALL_R) - 3, int(cyf) + int(TOWN_WALL_R) + 4):
                d = math.hypot(x + .5 - cxf, y + .5 - cyf)
                if not (TOWN_WALL_R - .55 <= d < TOWN_WALL_R + .6) or not (0 <= x < W and 0 <= y < H): continue
                if any((x + dx, y + dy) in self.road for dx in (-1, 0, 1) for dy in (-1, 0, 1)): continue
                self.walls.add((x, y))
        # --- street furniture
        P = self.props
        for k in range(8):                      # lamps round the market
            ang = k / 8 * math.tau + .2
            P.append((t.x + math.cos(ang) * 7.4 * TS, t.y + math.sin(ang) * 7.4 * TS, "lamp", 0))
        for k in range(6):                      # benches and planters round the fountain
            ang = k / 6 * math.tau + .5
            P.append((t.x + math.cos(ang) * 3.3, t.y + math.sin(ang) * 3.3, "bench" if k % 2 == 0 else "planter", k % 3))
        kx, ky = t.x + KING_POST[0], t.y + KING_POST[1]       # the ruler's dais
        for sx_ in (-3.0, 3.0): P.append((kx + sx_, ky + .4, "banner", {"Alliance": 0, "Horde": 1}.get(style, 2)))
        for sx_ in (-1.8, 1.8): P.append((kx + sx_, ky - 1.2, "brazier", 0))
        if tier == "capital":
            for sx_ in (-5.2, 5.2): P.append((kx + sx_, ky + .8, "banner", {"Alliance": 0, "Horde": 1}.get(style, 2))); P.append((kx + sx_ * .75, ky - 1.8, "brazier", 0))
        for g in gates:                         # lamps and banners down each avenue
            for s in (10.5 * TS, 14.0 * TS, 17.0 * TS):
                for side in (-2.7, 2.7):
                    x = t.x + math.cos(g) * s - math.sin(g) * side; y = t.y + math.sin(g) * s + math.cos(g) * side
                    P.append((x, y, "banner", {"Alliance": 0, "Horde": 1}.get(style, 2)) if s == 14.0 * TS else (x, y, "lamp", 0))
        for (kind, ang, r) in (("well", 2.4, 9.6), ("cart", 4.0, 11.4), ("well", .35, 12.8), ("cart", 5.6, 13.6)):
            ang += h01(hid, int(ang * 10), 130) * .4
            x, y = t.x + math.cos(ang) * r * TS, t.y + math.sin(ang) * r * TS
            if (int(x), int(y)) not in self.street and all((x - b[0] - 1) ** 2 + (y - b[1] - 1) ** 2 > 5 for b in self.buildings if b[2] in ("house", "tower")):
                P.append((x, y, kind, int(h01(hid, int(ang * 10), 131) * 3)))
        # signposts at every gate, just outside the walls
        for g in gates:
            x = t.x + math.cos(g) * (TOWN_WALL_R + 2.6) - math.sin(g) * 2.6; y = t.y + math.sin(g) * (TOWN_WALL_R + 2.6) + math.cos(g) * 2.6
            if 0 <= x < W and 0 <= y < H and (int(x), int(y)) not in self.road: P.append((x, y, "signpost", 0))

    # ------------------------------------------------------------ wilderness
    POND_PLAN = {"Greenfields": 3, "Ashen Vale": 2, "Ironwood": 3, "Frostmarch": 3, "Storm Coast": 2, "Bloodfen": 2, "Crownlands": 3,
                 "Dreadmoor": 2, "Sunscar Desert": 1, "Ember Highlands": 0, "Wyrmreach": 2, "Shadowlands": 2}

    def _make_ponds(self, world):
        """Small ponds and larger lakes scattered through every zone, kept clear of towns, roads and portals."""
        self.ponds = []; self.pond_tiles = {}; self.rivers = []
        # 0.42: rivers - winding chains of round pools that run down through every green zone, steering round towns and dungeon doors.
        # Road tiles are never water, so every road that meets a river crosses it on a bridge and nothing is cut off.
        for a in AREAS:
            if bz(a[0]) in ("Ember Highlands", "Sunscar Desert"): continue
            kind = {"Frostmarch": "ice", "Dreadmoor": "dark", "Shadowlands": "dark", "Wyrmreach": "dark", "Bloodfen": "murk"}.get(bz(a[0]), "fresh")
            for rv in range(3 if a[3] >= 100 else 2):
                sd = a[1] * 13 + a[2] * 7 + rv * 101
                obst = [(o.x, o.y, TOWN_WALL_R + 3) for o in self.towns] + [(o.x, o.y, 11) for o in self.dungeons]
                obst = [o for o in obst if a[1] - 90 < o[0] < a[1] + a[3] + 90 and a[2] - 40 < o[1] < a[2] + a[4] + 40]      # 0.45: only nearby ones
                def course(k):
                    """A meandering course from the zone's top edge to its bottom edge; k picks the endpoints."""
                    x0 = a[1] + 18 + h01(sd, k, 321) * (a[3] - 36); x1 = min(a[1] + a[3] - 12, max(a[1] + 12, x0 + (h01(sd, k, 322) - .5) * 60))
                    ph = h01(sd, k, 325) * 6.28; am = 4 + h01(sd, k, 326) * 8; pts = []
                    for s_ in range(0, 36):
                        f = s_ / 35; y = a[2] + 3 + f * (a[4] - 6)
                        x = x0 + (x1 - x0) * f + math.sin(f * 9.4 + ph) * am * math.sin(f * 3.14159) + (vnoise(f * 40, rv * 9 + k, 5, 327) - .5) * 5
                        pts.append((x, y))
                    return pts
                def bad(pts): return sum(any((x - ox) ** 2 + (y - oy) ** 2 < rr * rr for ox, oy, rr in obst) for x, y in pts)
                best = min((course(k) for k in range(60)), key=bad)
                run = []
                stream = rv >= 2 or (rv == 1 and a[3] < 100)     # 0.44.21: a narrow stream beside the big river, so roads cross water far more often
                if stream:
                    nb = len(best); best = [(best[i][0] + (best[min(i + 1, nb - 1)][0] - best[i][0]) * f, best[i][1] + (best[min(i + 1, nb - 1)][1] - best[i][1]) * f) for i in range(nb) for f in (0, .5)]
                for n, (cx, cy) in enumerate(best):
                    r_ = (1.7 + h01(sd, n, 324) * .3) if stream else (3.6 + h01(sd, n, 324) * .5 + n * .015)
                    if any((cx - ox) ** 2 + (cy - oy) ** 2 < (rr + r_) ** 2 for ox, oy, rr in obst):      # water never touches a town or a dungeon door
                        if len(run) > 2: self.rivers.append((run, kind))
                        run = []; continue
                    self.ponds.append((cx, cy, r_, kind, r_, r_, 0.0)); run.append((cx, cy))
                if len(run) > 2: self.rivers.append((run, kind))
        # 0.44.21: crossing streams - a brook cut straight across most long roads, so travellers meet a bridge every few minutes
        obst2 = [(o.x, o.y, TOWN_WALL_R + 6) for o in self.towns] + [(o.x, o.y, 13) for o in self.dungeons]
        for ri, (pts, width) in enumerate(self.roadlines):
            L_ = len(pts)
            if L_ < 40: continue
            for ci in range(2 if L_ > 120 else 1):
                if h01(ri, ci, 611) < (.22 if ci else .1): continue
                i = int(L_ * (.2 + .6 * h01(ri, ci, 612))) if ci == 0 else int(L_ * (.2 + .6 * h01(ri, 9, 613)))
                x, y = pts[i]; x2, y2 = pts[min(L_ - 1, i + 2)]; x1, y1 = pts[max(0, i - 2)]
                dx, dy = x2 - x1, y2 - y1; dd = math.hypot(dx, dy) or 1.0
                nx_, ny_ = -dy / dd, dx / dd
                ar_ = area_at(int(x), int(y))
                if not ar_ or bz(ar_[0]) in ("Ember Highlands", "Sunscar Desert"): continue
                kind = {"Frostmarch": "ice", "Dreadmoor": "dark", "Shadowlands": "dark", "Wyrmreach": "dark", "Bloodfen": "murk"}.get(bz(ar_[0]), "fresh")
                sd = ri * 31 + ci * 7; ph = h01(sd, 1, 614) * 6.28; run = []
                for k in range(-18, 19):
                    f = k * 1.15; w_ = math.sin(f * .31 + ph) * 3.0
                    px, py = x + nx_ * f + dx / dd * w_, y + ny_ * f + dy / dd * w_
                    r_ = 1.6 + h01(sd, k, 615) * .3
                    if not (3 < px < W - 3 and 3 < py < H - 3) or any((px - ox) ** 2 + (py - oy) ** 2 < (rr + r_) ** 2 for ox, oy, rr in obst2):
                        if len(run) > 3: self.rivers.append((run, kind))
                        run = []; continue
                    a2 = area_at(int(px), int(py))
                    if not a2 or a2[0] != ar_[0]:
                        if len(run) > 3: self.rivers.append((run, kind))
                        run = []; continue
                    self.ponds.append((px, py, r_, kind, r_, r_, 0.0)); run.append((px, py))
                if len(run) > 3: self.rivers.append((run, kind))
        nriv = len(self.ponds)                # 0.44.20: rivers are laid first, so the ponds can keep away from them
        for a in AREAS:
            want = self.POND_PLAN.get(bz(a[0]), 2)
            tries = 0; placed = 0
            while placed < want and tries < 240:
                tries += 1
                cx = a[1] + 16 + h01(a[1], a[2] * 7 + tries, 301) * (a[3] - 32)
                cy = a[2] + 16 + h01(a[2], a[1] * 5 + tries, 302) * (a[4] - 32)
                big = placed == 0 and want >= 3 or h01(tries, a[1], 303) < .25
                rx = (7 + h01(tries, a[2], 304) * 5) if big else (3.2 + h01(tries, a[2], 305) * 3)
                ry = rx * (.55 + h01(tries, a[1], 306) * .35)
                R = max(rx, ry) + 4
                ca = area_at(int(cx), int(cy))
                if not ca or ca[0] != a[0]: continue
                if any((t.x - cx) ** 2 + (t.y - cy) ** 2 < (TOWN_WALL_R + R + 8) ** 2 for t in self.towns): continue
                if any((d.x - cx) ** 2 + (d.y - cy) ** 2 < (R + 6) ** 2 for d in self.dungeons): continue
                if any((p[0] - cx) ** 2 + (p[1] - cy) ** 2 < (R + p[2] + 6) ** 2 for p in self.ponds[nriv:]): continue
                if any((p[0] - cx) ** 2 + (p[1] - cy) ** 2 < (R + p[2] + 16) ** 2 for p in self.ponds[:nriv]): continue     # 0.44.20: no pond hard against a river
                bad = False
                for k in range(24):
                    ang = k / 24 * math.tau
                    for rr in (.5, 1.0, 1.4):
                        if (int(cx + math.cos(ang) * rx * rr * 1.1), int(cy + math.sin(ang) * ry * rr * 1.1)) in self.road: bad = True; break
                    if bad: break
                if bad: continue
                kind = {"Frostmarch": "ice", "Sunscar Desert": "oasis", "Dreadmoor": "dark", "Shadowlands": "dark", "Wyrmreach": "dark", "Bloodfen": "murk"}.get(bz(a[0]), "fresh")
                self.ponds.append((cx, cy, max(rx, ry), kind, rx, ry, h01(tries, a[1], 307) * math.pi)); placed += 1
        # rasterise once so tile lookups are O(1)
        nz = {}                                # 0.45: the shoreline noise of a tile is the same for every overlapping river pool
        for i, (cx, cy, R, kind, rx, ry, rot) in enumerate(self.ponds):
            cr, sr = math.cos(rot), math.sin(rot)
            for x in range(int(cx - R - 3), int(cx + R + 4)):
                for y in range(int(cy - R - 3), int(cy + R + 4)):
                    dx, dy = x + .5 - cx, y + .5 - cy
                    u = (dx * cr + dy * sr) / rx; v = (-dx * sr + dy * cr) / ry
                    q = u * u + v * v
                    if q > 1.5: continue           # can't be water even with the strongest wobble (+/- .475)
                    n_ = nz.get((x, y))
                    if n_ is None: n_ = nz[(x, y)] = (vnoise(x, y, 4, 61) - .5) * .7 + (vnoise(x, y, 2, 62) - .5) * .25
                    d = q + n_
                    if d < 1.0 and (x, y) not in self.road and (x, y) not in self.plaza:
                        self.pond_tiles[(x, y)] = (i, d)

    def pond_push(self, x, y):
        """If (x, y) is in a pond, return the nearest dry point; otherwise None."""
        t = self.pond_tiles.get((int(math.floor(x)), int(math.floor(y))))
        if not t: return None
        cx, cy = self.ponds[t[0]][0], self.ponds[t[0]][1]
        dx, dy = x - cx, y - cy; d = math.hypot(dx, dy) or 1
        for k in range(1, 40):
            nx, ny = x + dx / d * k * .5, y + dy / d * k * .5
            if (int(math.floor(nx)), int(math.floor(ny))) not in self.pond_tiles: return (nx, ny)
        return (x + 12, y)

    def _detail(self, world):
        """Farms round every city, and camps, ruins and standing stones scattered over the wilds."""
        props = self.props
        grid = {}; seen = [0]                  # 0.45: props bucketed in 8-tile cells (was a scan of every prop, every check)
        def free(x, y, d=1.5):
            for p in props[seen[0]:]:
                grid.setdefault((int(p[0]) // 8, int(p[1]) // 8), []).append(p)
            seen[0] = len(props)
            r = int(d // 8) + 1; gx, gy = int(x) // 8, int(y) // 8
            for cx_ in range(gx - r, gx + r + 1):
                for cy_ in range(gy - r, gy + r + 1):
                    for p in grid.get((cx_, cy_), ()):
                        if (x - p[0]) ** 2 + (y - p[1]) ** 2 <= d * d: return False
            return True
        def clear_ground(x, y, rad=2):
            return all(tile_info(self, int(x) + ox, int(y) + oy)[0] == "ground" and (int(x) + ox, int(y) + oy) not in self.road
                       for ox in range(-rad, rad + 1) for oy in range(-rad, rad + 1))
        farmland = {"Greenfields", "Crownlands", "Ironwood", "Storm Coast"}
        for t in self.towns:                    # outskirts: farms where the soil is good, a hunters' camp elsewhere
            for k in range(3):
                for att in range(8):
                    ang = h01(t.id, k * 9 + att, 140) * math.tau; r = TOWN_WALL_R + 9 + h01(t.id, k * 9 + att, 141) * 12
                    x, y = t.x + math.cos(ang) * r, t.y + math.sin(ang) * r
                    if not (0 <= x < W and 0 <= y < WORLD_H) or not clear_ground(x, y) or not free(x, y, 7): continue
                    if bz(t.area) in farmland:
                        props += [(x, y, "haystack", 0), (x + 1.8, y + .4, "haystack", 1), (x - 2.4, y - 1.6, "cart", 0)]
                        props += [(x + i + .5, y + 3, "fence", 0) for i in range(-3, 4)]
                        props += [(x + 4 + (j % 2), y - 2 + j * .9, "fence", 0) for j in range(4)]
                    else:
                        props += [(x, y, "campfire", 0), (x - 2.1, y - .6, "tent", k % 3), (x + 1.2, y + 1.8, "woodpile", 0), (x - 1.2, y + 2.2, "barrel", 1)]
                    break
        biome_kit = {
            "Greenfields": ("camp", "farm", "ruins"), "Crownlands": ("farm", "ruins", "camp"), "Ironwood": ("camp", "ruins", "stones"),
            "Ashen Vale": ("camp", "ruins", "ruins"), "Frostmarch": ("camp", "stones", "ruins"), "Storm Coast": ("camp", "ruins", "camp"),
            "Bloodfen": ("ruins", "camp", "stones"), "Dreadmoor": ("ruins", "stones", "ruins"), "Sunscar Desert": ("camp", "ruins", "stones"),
            "Ember Highlands": ("camp", "ruins", "stones"), "Wyrmreach": ("stones", "ruins", "camp"), "Shadowlands": ("stones", "ruins", "ruins")}
        for a in AREAS:
            kit = biome_kit.get(bz(a[0]), ("camp", "ruins", "stones"))
            n_slots = max(10, int(a[3] * a[4] / 520))
            for slot in range(n_slots):
                found = None
                for att in range(14):
                    x = a[1] + 6 + h01(a[1] + att, a[2] + slot, 150) * (a[3] - 12); y = a[2] + 6 + h01(a[2] + att, a[1] + slot, 151) * (a[4] - 12)
                    if any((x - t.x) ** 2 + (y - t.y) ** 2 < TOWN_CLEAR_R ** 2 for t in self.towns): continue
                    if any((x - d.x) ** 2 + (y - d.y) ** 2 < 14 ** 2 for d in world.dungeons): continue
                    if any((x - p[0]) ** 2 + (y - p[1]) ** 2 < 144 for p in props if p[2] in ("campfire", "menhir", "ruin", "haystack")): continue
                    if clear_ground(x, y):
                        found = (x, y); break
                if not found: continue
                x, y = found
                kind = kit[slot % 3]; hv = int(h01(slot, a[1], 152) * 3)
                if kind == "camp":
                    props += [(x, y, "campfire", 0), (x - 2.1, y - .6, "tent", hv), (x + 1.9, y - 1.4, "tent", (hv + 1) % 3), (x + 1.2, y + 1.8, "woodpile", 0),
                              (x - 1.2, y + 2.2, "barrel", 1), (x - 1.0, y + 1.0, "log", 0), (x + 3.0, y + 1.0, "signpost", 0)]
                elif kind == "farm":
                    props += [(x, y, "haystack", 0), (x + 1.8, y + .4, "haystack", 1), (x - 2.4, y - 1.6, "cart", 0), (x + 3.2, y - 2.0, "well", 0)]
                    props += [(x + i + .5, y + 3, "fence", 0) for i in range(-2, 3)]
                else:
                    if kind == "ruins":
                        props += [(x + dx, y + dy, "ruin", (i + hv) % 3) for i, (dx, dy) in enumerate(((0, 0), (2.2, -.8), (-1.8, 1.4), (1.0, 2.4), (-3.4, -1.2), (3.6, 1.8)))]
                        props += [(x - 2.6, y - 1.4, "boulders", 1), (x + 3.0, y + 1.2, "boulders", 2)]
                    else:
                        props += [(x + math.cos(i / 6 * math.tau) * 2.6, y + math.sin(i / 6 * math.tau) * 2.6, "menhir", i % 3) for i in range(6)]
                        props.append((x, y, "campfire", 0) if bz(a[0]) in ("Frostmarch", "Wyrmreach") else (x, y, "boulders", 0))
        # keep the world edge clear
        self.props = [p for p in props if 0 <= p[0] < W and 0 <= p[1] < H]

    def _road_furniture(self):
        """Milestones along every long road and a proper waystation (fire, tents, lamp) halfway between the cities."""
        P = self.props
        for pts, width in self.roadlines:
            L = len(pts)
            if width < 1 or L < 70: continue
            def side_spot(i, off):
                x, y = pts[i]; x2, y2 = pts[min(L - 1, i + 2)]; x1, y1 = pts[max(0, i - 2)]
                dx, dy = x2 - x1, y2 - y1; dd = math.hypot(dx, dy) or 1
                return x - dy / dd * off, y + dx / dd * off
            k = 0
            for i in range(30, L - 30, 28):
                x, y = side_spot(i, 2.7 if k % 2 else -2.7); k += 1
                if (int(x), int(y)) not in self.road and tile_info(self, int(x), int(y))[0] == "ground": P.append((x, y, "signpost", 0))
            mid = L // 2
            x, y = side_spot(mid, 6.2)
            if all(tile_info(self, int(x) + ox, int(y) + oy)[0] == "ground" and (int(x) + ox, int(y) + oy) not in self.road for ox in range(-3, 4) for oy in range(-3, 4)):
                v = int(h01(int(x), int(y), 160) * 3)
                P += [(x, y, "campfire", 0), (x - 2.2, y - .8, "tent", v), (x + 2.0, y - 1.2, "tent", (v + 1) % 3), (x + 1.3, y + 2.0, "woodpile", 0),
                      (x - 1.4, y + 2.3, "barrel", 1), (x + 3.4, y + .4, "signpost", 0), (x - 3.6, y + .8, "lamp", 0), (x + .2, y + 3.4, "cart", 0)]

    def _road(self, x0, y0, x1, y1, width=1, wander=True):
        """A winding road: smooth low-frequency drift sideways, calm near both ends."""
        L = math.hypot(x1 - x0, y1 - y0) or 1.0
        n = int(L * 2) + 1
        nx, ny = -(y1 - y0) / L, (x1 - x0) / L
        amp = min(7.0, L * .07) if wander else 0.0
        pts = []
        for i in range(n + 1):
            t = i / n
            off = (vnoise(t * L, x0 * 3.17 + y0 * 1.31, 20, 17) - .5) * 2 * amp * math.sin(t * math.pi) ** .7
            x = x0 + (x1 - x0) * t + nx * off; y = y0 + (y1 - y0) * t + ny * off
            if i % 2 == 0: pts.append((x, y))
            for dx in range(-width, width + 1):
                for dy in range(-width, width + 1):
                    if abs(dx) + abs(dy) <= width:
                        self.road.add((int(x) + dx, int(y) + dy))
        self.roadlines.append((pts, width))

# ------------------------------------------------------------ tile colours
def tile_info(layout, x, y):
    """Returns (kind, colour) for the ground tile at integer coords."""
    if x < 0 or y < 0 or x >= W or y >= H:
        return "void", (14, 16, 22)
    if y >= WORLD_H:
        from .instance import tile_info_for
        return tile_info_for(x, y)
    a = area_at(x, y) or AREAS[0]
    b = BIOMES.get(a[0], BIOMES["Greenfields"])
    if (x, y) in layout.plaza:
        v = h01(x, y, 2)
        return "plaza", shade((196, 186, 166), .92 + v * .12)
    if (x, y) in layout.road:
        base = (150, 150, 160) if bz(a[0]) == "Frostmarch" else (140, 112, 78)
        return "road", shade(base, .9 + h01(x, y, 2) * .15)
    pt = getattr(layout, "pond_tiles", None)
    if pt:
        pi = pt.get((x, y))
        if pi:
            kind_ = layout.ponds[pi[0]][3]; dd = pi[1]
            base_ = POND_COL[kind_]
            return "water", shade(base_, (.82 + (1 - min(1, dd)) * .22) * (.94 + h01(x, y, 2) * .12))
    if bz(a[0]) == "Storm Coast" and (x < 4 + math.sin(y * .4) * 1.5 if a[1] == 0 else x > W - 5 - math.sin(y * .4) * 1.5):
        return "water", shade((38, 168, 196), .88 + h01(x, y, 2) * .16)
    if bz(a[0]) == "Bloodfen" and vnoise(x, y, 5, 7) > .74 and (x, y) not in layout.blocked:
        return "water", shade((52, 70, 50), .9 + h01(x, y, 2) * .15)
    if bz(a[0]) in ("Ember Highlands",) and vnoise(x, y, 4, 8) > .78 and (x, y) not in layout.blocked:
        return "lava", (230, 96, 30)
    n = vnoise(x, y, 7, 1) * .55 + vnoise(x, y, 23, 2) * .45          # patches of lush / dry ground
    c = mix(b["base"], b["alt"], n)
    # broad hills and hollows: slow brightness drift so open country is not one flat colour
    hill = .90 + .22 * (vnoise(x, y, 31, 9) * .65 + vnoise(x, y, 11, 10) * .35)
    return "ground", shade(c, (.94 + h01(x, y, 3) * .1) * hill * GROUND_LIFT.get(a[0], 1.0))


_TEX = None
def noise_texture():
    """A tileable 256x256 grey texture (soft blotches + fine grain) multiplied over the ground."""
    global _TEX
    if _TEX is not None:
        return _TEX
    import random
    rnd = random.Random(1234)
    N = 256
    t = pygame.Surface((N, N)); t.fill((236, 236, 236))
    for _ in range(1400):
        x, y = rnd.randrange(N), rnd.randrange(N); r = rnd.randint(3, 14); g = rnd.randint(205, 255)
        for ox in (-N, 0, N):
            for oy in (-N, 0, N):
                pygame.draw.circle(t, (g, g, g), (x + ox, y + oy), r)
    t = pygame.transform.smoothscale(pygame.transform.smoothscale(t, (64, 64)), (N, N))
    for _ in range(9000):
        g = rnd.randint(200, 255)
        t.set_at((rnd.randrange(N), rnd.randrange(N)), (g, g, g))
    _TEX = t
    return t

def _inst_mod():
    """The active instance (dungeon / battleground) or None."""
    from . import instance
    return instance.ACTIVE

def _old_texture(big, gx, gy, Wd, Hd):
    """Pre-0.45 ground texture (a grey multiply), used only without numpy."""
    tex = noise_texture()
    ox, oy = -(int(gx) % 256), -(int(gy) % 256)
    for tx in range(ox, Wd, 256):
        for ty in range(oy, Hd, 256):
            big.blit(tex, (tx, ty), special_flags=pygame.BLEND_RGB_MULT)

def reset_world_caches():
    """Forget per-tile data of the previous world (frees memory; called when a world is opened)."""
    _TILE.clear(); _TILE_NR.clear(); _RCOL.clear()

_TILE = {}
def tile_cached(layout, x, y):
    k = (x, y)
    v = _TILE.get(k)
    if v is None:
        v = _TILE[k] = tile_info(layout, x, y)
        if len(_TILE) > 60000:
            _TILE.clear()
    return v

def _ground_color(layout, wx, wy):
    """Bilinear blend of the four nearest tile colours: soft shorelines, road edges and zone borders."""
    u, v = wx - .5, wy - .5
    i, j = math.floor(u), math.floor(v); fu, fv = u - i, v - j
    c00 = tile_cached(layout, i, j)[1]; c10 = tile_cached(layout, i + 1, j)[1]
    c01 = tile_cached(layout, i, j + 1)[1]; c11 = tile_cached(layout, i + 1, j + 1)[1]
    return tuple(int((c00[k] * (1 - fu) + c10[k] * fu) * (1 - fv) + (c01[k] * (1 - fu) + c11[k] * fu) * fv) for k in range(3))


def _pj(pxc, top):
    return lambda u, v: (pxc + (u - v) * HTW, top + (u + v) * HTH)

def _pebbles(surf, x, y, spot, base, n=3, p=.4, salt=200):
    for k in range(n):
        if h01(x, y, salt + k) < p:
            sx, sy = spot(18 + k, .85); w = 3 + int(h01(x, y, salt + 10 + k) * 5)
            c = shade(base, .72 + h01(x, y, salt + 20 + k) * .5)
            pygame.draw.ellipse(surf, shade(c, .55), (sx - w / 2, sy - w / 4 + 1, w, w / 2 + 1))
            pygame.draw.ellipse(surf, c, (sx - w / 2, sy - w / 4, w, w / 2 + 1))
            pygame.draw.line(surf, shade(c, 1.35), (sx - w / 2 + 1, sy - w / 4), (sx + w / 4, sy - w / 4), 1)

def _crack(surf, x, y, spot, k, col, n=4, length=9):
    sx, sy = spot(k, .8); pts = [(sx, sy)]; ang = h01(x, y, 300 + k) * 6.28
    for i in range(n):
        ang += (h01(x, y, 310 + k + i) - .5) * 1.6
        sx += math.cos(ang) * length * .6; sy += math.sin(ang) * length * .3
        pts.append((sx, sy))
    pygame.draw.lines(surf, col, False, pts, 1)

def _ground_extras(surf, name, col, x, y, spot, layout, pxc, top):
    """0.20: per-biome ground detail.  Rendered once per chunk and cached, so it costs nothing per frame."""
    r = lambda salt: h01(x, y, salt)
    P = _pj(pxc, top)
    # soft shoreline: sand (or mud in the fen) where land meets water
    for (dx, dy, e0, e1, inw) in ((-1, 0, (0, 0), (0, 1), (1, 0)), (0, -1, (0, 0), (1, 0), (0, 1)),
                                  (1, 0, (1, 0), (1, 1), (-1, 0)), (0, 1, (0, 1), (1, 1), (0, -1))):
        if tile_cached(layout, x + dx, y + dy)[0] == "water" and (x + dx, y + dy) not in getattr(layout, "pond_tiles", {}):
            wet = (74, 62, 44) if name == "Bloodfen" else (206, 192, 142)
            wd = .26
            q = [P(*e0), P(*e1), P(e1[0] + inw[0] * wd, e1[1] + inw[1] * wd), P(e0[0] + inw[0] * wd, e0[1] + inw[1] * wd)]
            pygame.draw.polygon(surf, mix(col, wet, .65), q)
            q2 = [P(*e0), P(*e1), P(e1[0] + inw[0] * .08, e1[1] + inw[1] * .08), P(e0[0] + inw[0] * .08, e0[1] + inw[1] * .08)]
            pygame.draw.polygon(surf, mix(col, wet, .3) if name != "Bloodfen" else (44, 38, 30), q2)
    if (x, y) not in getattr(layout, "pond_tiles", {}) and any((x + dx, y + dy) in getattr(layout, "pond_tiles", {}) for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
        if r(110) < .45:    # reeds and cattails along ponds
            for k in range(3):
                sx, sy = spot(70 + k, .7); hh = 9 + r(111 + k) * 8
                pygame.draw.line(surf, (66, 112, 52), (sx, sy), (sx + (r(115 + k) - .5) * 4, sy - hh), 1)
                if k == 0: pygame.draw.line(surf, (110, 72, 40), (sx + 1, sy - hh + 1), (sx + 1, sy - hh - 4), 3)
        if r(120) < .25:    # flat stones at the waterline
            sx, sy = spot(75, .7); pygame.draw.ellipse(surf, (126, 124, 118), (sx - 4, sy - 2, 8, 4)); pygame.draw.ellipse(surf, (170, 168, 160), (sx - 3, sy - 2, 5, 2))
    if name in ("Greenfields", "Crownlands"):
        if r(101) < .14:   # clover
            sx, sy = spot(30, .7)
            for o in ((-3, 0), (3, 0), (0, -3)):
                pygame.draw.circle(surf, shade(col, 1.25), (int(sx + o[0]), int(sy + o[1])), 2)
        if r(102) < .1:    # fallen leaves
            sx, sy = spot(31, .7)
            for o in ((-4, 0), (2, 2), (5, -1)):
                pygame.draw.ellipse(surf, ((196, 120, 50), (170, 140, 56), (150, 70, 40))[int(r(103) * 3)], (sx + o[0], sy + o[1], 4, 2))
        if r(104) < .16:   # tall grass with seed heads
            sx, sy = spot(32, .7)
            for o in range(-6, 7, 3):
                pygame.draw.line(surf, shade(col, 1.3), (sx + o, sy), (sx + o + 1, sy - 8 - abs(o) % 3 * 2), 1)
                pygame.draw.circle(surf, (214, 200, 120), (int(sx + o + 1), int(sy - 9 - abs(o) % 3 * 2)), 1)
        if r(105) < .08:   # bare earth scuff
            sx, sy = spot(33, .6)
            surf.blit(_patch_blob(22, 9, (120, 96, 64), 28), (sx - 11, sy - 4))
        _pebbles(surf, x, y, spot, (150, 148, 140), 2, .22)
    elif name == "Ironwood":
        for k in range(3):   # pine-needle litter and twigs
            if r(110 + k) < .55:
                sx, sy = spot(30 + k, .85)
                pygame.draw.line(surf, (96, 70, 44), (sx - 4, sy), (sx + 4, sy + 1), 1)
                pygame.draw.line(surf, (122, 92, 54), (sx - 2, sy - 1), (sx + 3, sy - 2), 1)
        if r(114) < .12:     # moss patch
            sx, sy = spot(34, .6)
            surf.blit(_patch_blob(22, 9, (40, 96, 46), 30), (sx - 11, sy - 4))
        if r(115) < .07:     # twig
            sx, sy = spot(35, .7)
            pygame.draw.line(surf, (84, 60, 40), (sx - 8, sy + 1), (sx + 8, sy - 2), 2)
            pygame.draw.line(surf, (84, 60, 40), (sx + 1, sy), (sx + 6, sy - 5), 1)
        _pebbles(surf, x, y, spot, (118, 116, 108), 2, .2)
    elif name == "Frostmarch":
        if r(121) < .08:     # patch of ice (0.45: soft-edged)
            sx, sy = spot(31, .6)
            surf.blit(_patch_blob(30, 11, (120, 176, 220), 22), (sx - 15, sy - 5))
            surf.blit(_patch_blob(14, 5, (235, 248, 255), 30), (sx - 9, sy - 4))
        if r(122) < .06:     # animal tracks
            sx, sy = spot(32, .6)
            for i in range(4):
                pygame.draw.ellipse(surf, (170, 184, 208), (sx + i * 6 - 10, sy + (i % 2) * 3, 3, 2))
        _pebbles(surf, x, y, spot, (140, 150, 168), 2, .18)
    elif name == "Sunscar Desert":
        if r(130) < .13: _crack(surf, x, y, spot, 30, shade(col, .62), 5, 10)
        if r(131) < .1:      # dry scrub
            sx, sy = spot(31, .7)
            for o in (-4, 0, 4):
                pygame.draw.line(surf, (150, 118, 66), (sx, sy), (sx + o, sy - 6), 1)
        if r(132) < .12:     # wind ripple lines
            sx, sy = spot(32, .7)
            pygame.draw.line(surf, shade(col, 1.14), (sx - 10, sy), (sx + 10, sy - 2), 1)
            pygame.draw.line(surf, shade(col, .84), (sx - 8, sy + 2), (sx + 12, sy), 1)
        _pebbles(surf, x, y, spot, (176, 146, 100), 3, .3)
    elif name == "Bloodfen":
        if r(140) < .22:     # standing puddle
            sx, sy = spot(30, .6)
            surf.blit(_patch_blob(26, 11, (30, 44, 36), 34), (sx - 13, sy - 5)); surf.blit(_patch_blob(12, 4, (120, 150, 130), 30), (sx - 7, sy - 3))
        if r(141) < .2:      # lichen / moss
            sx, sy = spot(31, .7)
            surf.blit(_patch_blob(20, 8, (96, 130, 62), 30), (sx - 10, sy - 4)); pygame.draw.circle(surf, (170, 190, 110), (int(sx - 3), int(sy - 1)), 1)
        if r(142) < .1:      # blood-red fungus bloom
            sx, sy = spot(32, .6)
            pygame.draw.circle(surf, (150, 40, 50), (int(sx), int(sy)), 2); pygame.draw.circle(surf, (190, 70, 70), (int(sx + 3), int(sy + 1)), 1)
        _pebbles(surf, x, y, spot, (88, 84, 72), 2, .15)
    elif name == "Ember Highlands":
        if r(150) < .2:      # ash drift
            sx, sy = spot(30, .6)
            surf.blit(_patch_blob(24, 9, (120, 112, 108), 30), (sx - 12, sy - 4))
        if r(151) < .16:     # glowing fissure
            _crack(surf, x, y, spot, 31, (40, 16, 10), 5, 12)
            sx, sy = spot(31, .8)
            pygame.draw.circle(surf, (255, 120, 40), (int(sx), int(sy)), 1)
        _pebbles(surf, x, y, spot, (60, 50, 46), 3, .3)
    elif name in ("Dreadmoor", "Shadowlands"):
        tint = (120, 82, 150) if name == "Dreadmoor" else (140, 90, 190)
        if r(160) < .2:      # purple moss
            sx, sy = spot(30, .7)
            surf.blit(_patch_blob(22, 8, tint, 26), (sx - 11, sy - 4))
        if r(161) < .12:     # faint spirit wisp
            sx, sy = spot(31, .7)
            pygame.draw.circle(surf, mix(col, (200, 170, 255), .7), (int(sx), int(sy)), 2); pygame.draw.circle(surf, mix(col, tint, .5), (int(sx), int(sy)), 4, 1)
        if r(162) < .1: _crack(surf, x, y, spot, 32, shade(col, .55), 4, 9)
        _pebbles(surf, x, y, spot, (88, 80, 100), 2, .22)
    elif name == "Wyrmreach":
        if r(170) < .3:      # slate slabs
            sx, sy = spot(30, .7)
            pygame.draw.polygon(surf, shade(col, 1.22), [(sx - 9, sy), (sx, sy - 4), (sx + 9, sy), (sx, sy + 4)])
            pygame.draw.polygon(surf, shade(col, .72), [(sx - 9, sy), (sx, sy + 4), (sx + 9, sy), (sx + 9, sy + 2), (sx, sy + 6), (sx - 9, sy + 2)])
        if r(171) < .08:     # crystal glint
            sx, sy = spot(31, .7)
            pygame.draw.polygon(surf, (150, 220, 250), [(sx, sy - 6), (sx + 2, sy), (sx, sy + 1), (sx - 2, sy)])
        _pebbles(surf, x, y, spot, (110, 120, 134), 3, .28)
    elif name == "Storm Coast":
        if r(180) < .3:      # sand ripples
            sx, sy = spot(30, .7)
            pygame.draw.arc(surf, shade(col, 1.14), (sx - 10, sy - 3, 20, 6), .2, 2.9, 1)
            pygame.draw.arc(surf, shade(col, .86), (sx - 10, sy - 1, 20, 6), .2, 2.9, 1)
        if r(181) < .08:     # shell
            sx, sy = spot(31, .7)
            pygame.draw.circle(surf, (246, 226, 216), (int(sx), int(sy)), 2); pygame.draw.line(surf, (214, 170, 160), (sx, sy), (sx, sy - 2), 1)
        if r(182) < .06:     # driftwood
            sx, sy = spot(32, .7)
            pygame.draw.line(surf, (150, 126, 96), (sx - 9, sy + 1), (sx + 9, sy - 2), 3); pygame.draw.line(surf, (190, 166, 130), (sx - 9, sy), (sx + 9, sy - 3), 1)
        _pebbles(surf, x, y, spot, (176, 166, 140), 2, .24)
    elif name == "Ashen Vale":
        if r(190) < .2: _crack(surf, x, y, spot, 30, shade(col, .58), 5, 10)
        if r(191) < .22:     # dead grass
            sx, sy = spot(31, .7)
            for o in (-4, -1, 3):
                pygame.draw.line(surf, (140, 120, 78), (sx + o, sy), (sx + o + 2, sy - 6), 1)
        _pebbles(surf, x, y, spot, (112, 100, 86), 3, .3)

def _road_extras(surf, col, x, y, spot, layout, pxc, top):
    P = _pj(pxc, top)
    nx = sum(tile_cached(layout, x + d, y)[0] in ("road", "plaza") for d in (-1, 1))
    ny = sum(tile_cached(layout, x, y + d)[0] in ("road", "plaza") for d in (-1, 1))
    rut = shade(col, .66); hi = shade(col, 1.12)
    if nx and not ny:        # cart ruts along the road
        for v in (.34, .66):
            pygame.draw.line(surf, rut, P(0, v), P(1, v), 2); pygame.draw.line(surf, hi, P(0, v + .06), P(1, v + .06), 1)
    elif ny and not nx:
        for u in (.34, .66):
            pygame.draw.line(surf, rut, P(u, 0), P(u, 1), 2); pygame.draw.line(surf, hi, P(u + .06, 0), P(u + .06, 1), 1)
    _pebbles(surf, x, y, spot, col, 3, .45, 230)
    # grass/earth fringe where the road meets open ground
    for (dx, dy, e0, e1) in ((-1, 0, (0, 0), (0, 1)), (0, -1, (0, 0), (1, 0)), (1, 0, (1, 0), (1, 1)), (0, 1, (0, 1), (1, 1))):
        nk, nc = tile_cached(layout, x + dx, y + dy)[:2]
        if nk == "ground":
            for i in range(3):
                t = (i + .5 + h01(x, y, 240 + i + dx * 4 + dy * 9) * .4) / 3
                a = P(e0[0] + (e1[0] - e0[0]) * t, e0[1] + (e1[1] - e0[1]) * t)
                for o in (-2, 0, 2):
                    pygame.draw.line(surf, shade(nc, 1.05 + o * .03), (a[0] + o, a[1]), (a[0] + o + 1, a[1] - 5 - i % 2 * 2), 1)


# ---- 0.33: smooth roads.  Roads are painted as soft curved ribbons along their centre lines instead of
# tile by tile, so their edges no longer zig-zag in iso steps; the walkable road tiles are unchanged.
def _road_index(layout):
    idx = getattr(layout, "_road_idx", None)
    if idx is not None:
        return idx
    idx = {}
    for pts, width in getattr(layout, "roadlines", ()):
        hw = width + .42
        for i in range(len(pts) - 1):
            (ax, ay), (bx, by) = pts[i], pts[i + 1]
            seg = (ax, ay, bx, by, hw)
            m = hw + 2
            for ccx in range(int((min(ax, bx) - m) // CS), int((max(ax, bx) + m) // CS) + 1):
                for ccy in range(int((min(ay, by) - m) // CS), int((max(ay, by) + m) // CS) + 1):
                    idx.setdefault((ccx, ccy), []).append(seg)
    layout._road_idx = idx
    return idx

def _road_dist(segs, x, y):
    """(distance - half width) to the nearest road ribbon: negative inside the road."""
    best = 9e9
    for ax, ay, bx, by, hw in segs:
        dx, dy = bx - ax, by - ay; L2 = dx * dx + dy * dy or 1e-9
        t = ((x - ax) * dx + (y - ay) * dy) / L2
        t = 0.0 if t < 0 else 1.0 if t > 1 else t
        ex, ey = ax + dx * t - x, ay + dy * t - y
        d = math.sqrt(ex * ex + ey * ey) - hw
        if d < best: best = d
    return best

_TILE_NR = {}
def _tile_noroad(layout, x, y):
    """The tile as it would look without the road (what the road ribbon is painted onto)."""
    k = (x, y)
    v = _TILE_NR.get(k)
    if v is None:
        v = tile_cached(layout, x, y)
        if v[0] == "road" or (v[0] == "water" and (x, y) in getattr(layout, "pond_tiles", ())):
            rd, pt = layout.road, getattr(layout, "pond_tiles", None)
            try:
                layout.road = (); layout.pond_tiles = {}
                v2 = tile_info(layout, x, y)
            finally:
                layout.road = rd
                if pt is not None: layout.pond_tiles = pt
            v = v2 if v2[0] in ("ground", "plaza") else v
        _TILE_NR[k] = v
        if len(_TILE_NR) > 60000: _TILE_NR.clear()
    return v

_RCOL = {}
def _road_col(layout, x, y):
    k = (int(x * 2), int(y * 2))
    c = _RCOL.get(k)
    if c is None:
        a = area_at(int(x), int(y)) or AREAS[0]
        base = (150, 150, 160) if bz(a[0]) == "Frostmarch" else (140, 112, 78)
        c = _RCOL[k] = shade(base, .9 + vnoise(k[0] * .5, k[1] * .5, 3, 41) * .16)
        if len(_RCOL) > 30000: _RCOL.clear()
    return c

def _ground_color_nr(layout, wx, wy):
    u, v = wx - .5, wy - .5
    i, j = math.floor(u), math.floor(v); fu, fv = u - i, v - j
    c00 = _tile_noroad(layout, i, j)[1]; c10 = _tile_noroad(layout, i + 1, j)[1]
    c01 = _tile_noroad(layout, i, j + 1)[1]; c11 = _tile_noroad(layout, i + 1, j + 1)[1]
    return tuple(int((c00[k] * (1 - fu) + c10[k] * fu) * (1 - fv) + (c01[k] * (1 - fu) + c11[k] * fu) * fv) for k in range(3))

def _road_overlay(layout, cx, cy, segs, Wd, Hd, mask):
    """Ruts, worn verges and pebbles drawn along the road centre lines (continuous across chunks)."""
    lay = pygame.Surface((Wd, Hd), pygame.SRCALPHA)
    gx0, gy0 = iso(cx * CS, cy * CS); gx0 -= CS * HTW
    def S(x, y):
        sx, sy = iso(x, y); return sx - gx0, sy - gy0
    def ok(x, y):
        return tile_cached(layout, int(x), int(y))[0] in ("road", "ground")
    seen = set()
    for ax, ay, bx, by, hw in segs:
        if (ax, ay, bx, by) in seen: continue
        seen.add((ax, ay, bx, by))
        dx, dy = bx - ax, by - ay; L = math.hypot(dx, dy) or 1e-9
        nx, ny = -dy / L, dx / L
        n = max(2, int(L * 4))
        col = _road_col(layout, ax, ay)
        rut, rut_hi, verge = shade(col, .7), shade(col, 1.14), shade(col, .8)
        # two wheel ruts, a darker groove with a lit lip on its lower side
        for off in (-.36, .36):
            o = off * hw
            p0, p1 = (ax + nx * o, ay + ny * o), (bx + nx * o, by + ny * o)
            if ok(*p0) and ok(*p1):
                a0, a1 = S(*p0), S(*p1)
                pygame.draw.line(lay, rut + (150,), a0, a1, 3)
                pygame.draw.line(lay, rut_hi + (110,), (a0[0], a0[1] + 2), (a1[0], a1[1] + 2), 1)
        # crown of the road slightly lighter (worn smooth by feet)
        a0, a1 = S(ax, ay), S(bx, by)
        pygame.draw.line(lay, shade(col, 1.08) + (60,), a0, a1, 4)
        # ragged verges: dark dirt crumbs and grass blades creeping onto the road edge
        for i in range(n):
            t = (i + .5) / n
            px, py = ax + dx * t, ay + dy * t
            for side in (-1, 1):
                j = h01(int(px * 37) + side, int(py * 37), 501)
                e = hw * (.93 + (j - .5) * .16)
                qx, qy = px + nx * e * side, py + ny * e * side
                if tile_cached(layout, int(qx), int(qy))[0] not in ("road", "ground"): continue
                sx, sy = S(qx, qy)
                gc = _tile_noroad(layout, int(qx), int(qy))[1]
                if j < .55:
                    pygame.draw.ellipse(lay, verge + (120,), (sx - 3, sy - 1, 6, 3))
                if gc and j > .25:
                    for b_ in range(2 + int(j * 3)):
                        ox = (h01(int(px * 37) + b_, int(py * 37), 503) - .5) * 8
                        ln = 3 + h01(int(px * 37), int(py * 37) + b_, 505) * 4
                        c = shade(gc, .8 + h01(int(px * 37) + b_, int(py * 37) + b_, 507) * .4)
                        pygame.draw.line(lay, c + (230,), (sx + ox, sy + 1), (sx + ox + (b_ - 1) * 1.2, sy + 1 - ln), 1)
        # loose pebbles on the road surface
        for i in range(int(L * 3)):
            r1 = h01(int(ax * 13) + i, int(ay * 13), 511); r2 = h01(int(ax * 13), int(ay * 13) + i, 513)
            t = r1; o = (r2 - .5) * 1.6 * hw
            qx, qy = ax + dx * t + nx * o, ay + dy * t + ny * o
            if tile_cached(layout, int(qx), int(qy))[0] not in ("road", "ground"): continue
            sx, sy = S(qx, qy); w = 2 + int(h01(i, int(bx * 7), 515) * 3)
            c = shade(col, .7 + h01(i, int(by * 7), 517) * .5)
            pygame.draw.ellipse(lay, shade(c, .6) + (200,), (sx - w / 2, sy - w / 4 + 1, w, w / 2 + 1))
            pygame.draw.ellipse(lay, c + (230,), (sx - w / 2, sy - w / 4, w, w / 2 + 1))
    lay.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return lay

def _bridges(layout):
    """0.45: one bridge per place a road crosses water, found once per world.  A bridge follows the road's own
    curve from dry bank to dry bank: (points, half_width).  Returns (list, {chunk: [bridge, ...]})."""
    bi = getattr(layout, "_bridge_idx", None)
    if bi is not None: return bi
    def wet(x, y): return water_under(layout, x, y)
    out = []; taken = []
    for pts, width in getattr(layout, "roadlines", ()):
        hw = width + .42
        dense = []                                   # the road centre line every quarter tile
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            L = math.hypot(bx - ax, by - ay); n = max(1, int(L * 4))
            for i in range(n): dense.append((ax + (bx - ax) * i / n, ay + (by - ay) * i / n))
        if pts: dense.append(pts[-1])
        flags = [wet(x, y) for x, y in dense]
        i = 0; N_ = len(dense)
        while i < N_:
            if not flags[i]: i += 1; continue
            j = i
            while j + 1 < N_ and (flags[j + 1] or any(flags[j + 2:j + 7])): j += 1     # bridge little dry gaps too
            a_ = max(0, i - 3); b_ = min(N_ - 1, j + 3)                                    # land on dry ground at both ends
            run = dense[a_:b_ + 1:2]
            if dense[b_] != run[-1]: run.append(dense[b_])
            mid = run[len(run) // 2]
            if len(run) >= 3 and not any(abs(mid[0] - m[0]) + abs(mid[1] - m[1]) < 2.5 for m in taken):   # two roads, one crossing
                out.append((run, hw)); taken.append(mid)
            i = j + 1
    idx = {}
    for br in out:
        run, hw = br; m = hw + 2
        xs = [p_[0] for p_ in run]; ys = [p_[1] for p_ in run]
        for ccx in range(int((min(xs) - m) // CS), int((max(xs) + m) // CS) + 1):
            for ccy in range(int((min(ys) - m) // CS), int((max(ys) + m) // CS) + 1):
                idx.setdefault((ccx, ccy), []).append(br)
    layout._bridge_idx = (out, idx)
    return layout._bridge_idx


def _draw_bridge(lay, S, br):
    """A raised timber bridge along a curved road: shadow on the water, pilings with ripples, stone abutments,
    plank deck with thick side beams, and post-and-rail railings.  S maps world (x, y) to layer pixels."""
    run, hw = br
    e = hw * .72 + .15; RISE = 7; n = len(run)
    nrm = []                                      # unit normal at every point (averaged over the neighbours)
    for i in range(n):
        (x0, y0), (x1, y1) = run[max(0, i - 1)], run[min(n - 1, i + 1)]
        dx, dy = x1 - x0, y1 - y0; L = math.hypot(dx, dy) or 1e-9; nrm.append((-dy / L, dx / L))
    def P(i, side, up=0.0):
        x, y = run[i]; nx, ny = nrm[i]
        sx, sy = S(x + nx * e * side, y + ny * e * side); return (sx, sy - up)
    # shadow on the water, offset away from the sun
    sh = [P(i, 1, -4) for i in range(n)] + [P(i, -1, -4) for i in range(n - 1, -1, -1)]
    pygame.draw.polygon(lay, (6, 20, 34, 90), [(x_ + 6, y_ + 3) for x_, y_ in sh])
    # pilings in the water every ~1.2 tiles (skipped on the dry ends)
    step = max(2, int(1.2 / .5))
    for i in range(2, n - 2, step):
        for side in (1, -1):
            px, py = P(i, side, -3)
            pygame.draw.ellipse(lay, (220, 238, 248, 110), (px - 7, py - 2, 14, 6), 1)
            pygame.draw.line(lay, (52, 34, 20, 255), (px, py), (px, py - RISE - 3), 5)
            pygame.draw.line(lay, (96, 66, 40, 255), (px - 1, py - 1), (px - 1, py - RISE - 2), 1)
    # stone abutments at both banks
    for i0, i1 in ((0, 1), (n - 1, n - 2)):
        c0, c1, c2, c3 = P(i0, 1), P(i0, -1), P(i1, -1), P(i1, 1)
        pygame.draw.polygon(lay, (128, 124, 116, 255), [c0, c1, (c1[0], c1[1] - RISE), (c0[0], c0[1] - RISE)])
        for k_ in range(1, 3):
            f = k_ / 3
            pygame.draw.line(lay, (96, 92, 86, 255), (c0[0], c0[1] - RISE * f), (c1[0], c1[1] - RISE * f), 1)
        pygame.draw.polygon(lay, (164, 160, 150, 255), [(c[0], c[1] - RISE) for c in (c0, c1, c2, c3)])
    # side beams (deck thickness): the far side in shade, the near side lit
    for side, col in ((1, (86, 56, 32, 255)), (-1, (112, 76, 44, 255))):
        top = [P(i, side, RISE) for i in range(n)]
        pygame.draw.polygon(lay, col, top + [(x_, y_ + 6) for x_, y_ in reversed(top)])
    # solid deck under the planks, so no water shows through the seams
    pygame.draw.polygon(lay, (96, 66, 40, 255), [P(i, 1, RISE) for i in range(n)] + [P(i, -1, RISE) for i in range(n - 1, -1, -1)])
    # deck: planks across the road (about five per tile), each its own tone, with gaps, grain and nails
    for i in range(n - 1):
        (xa, ya), (xb, yb) = run[i], run[i + 1]
        seg = math.hypot(xb - xa, yb - ya); nb = max(1, int(round(seg * 5)))
        for q in range(nb):
            t0, t1 = q / nb, (q + 1) / nb
            def Q(t, side):
                a_, b_ = P(i, side, RISE), P(i + 1, side, RISE); return (a_[0] + (b_[0] - a_[0]) * t, a_[1] + (b_[1] - a_[1]) * t)
            j_ = int(h01(i * 7 + q, int(xa * 3 + ya * 5), 641) * 18) - 9
            base = (164 + j_, 120 + j_, 72 + j_ // 2)
            pl = [Q(t0, 1), Q(t0, -1), Q(t1, -1), Q(t1, 1)]
            pygame.draw.polygon(lay, base + (255,), pl)
            pygame.draw.line(lay, (186 + j_, 142 + j_, 90 + j_, 255), pl[0], pl[1], 1)
            pygame.draw.line(lay, (78, 52, 30, 255), pl[3], pl[2], 1)
            if h01(i * 7 + q, int(xb * 3), 643) < .45:
                m0 = ((pl[0][0] * 2 + pl[3][0]) / 3, (pl[0][1] * 2 + pl[3][1]) / 3); m1 = ((pl[1][0] * 2 + pl[2][0]) / 3, (pl[1][1] * 2 + pl[2][1]) / 3)
                pygame.draw.line(lay, (140 + j_, 100 + j_, 60, 150), m0, m1, 1)
    # railings: capped posts every ~0.9 tiles, a top rail and a mid rail on each side
    pstep = max(1, int(.9 / .5))
    for side in (1, -1):
        for hh, wd_, col in ((7, 3, (100, 68, 40, 255)), (14, 4, (84, 56, 30, 255)), (15, 1, (210, 170, 116, 255))):
            pygame.draw.lines(lay, col, False, [P(i, side, RISE + hh) for i in range(n)], wd_)
        for i in list(range(0, n, pstep)) + [n - 1]:
            pp = P(i, side, RISE)
            pygame.draw.line(lay, (56, 36, 20, 255), pp, (pp[0], pp[1] - 16), 4)
            pygame.draw.line(lay, (156, 112, 66, 255), (pp[0] - 1, pp[1] - 1), (pp[0] - 1, pp[1] - 15), 1)
            pygame.draw.rect(lay, (200, 160, 106, 255), (pp[0] - 3, pp[1] - 19, 6, 4))


def _bridge_overlay(layout, cx, cy, segs, Wd, Hd, mask):
    """0.44.13 / 0.45: bridges where roads cross water, plus current streaks along the rivers."""
    lay = pygame.Surface((Wd, Hd), pygame.SRCALPHA)
    gx0, gy0 = iso(cx * CS, cy * CS); gx0 -= CS * HTW
    pt = getattr(layout, "pond_tiles", None) or {}
    def S(x, y):
        sx, sy = iso(x, y); return sx - gx0, sy - gy0
    def wet(x, y): return (int(math.floor(x)), int(math.floor(y))) in pt
    drawn = False
    # current streaks: short soft strokes drifting along each river's course (0.45: fainter, so water reads calm)
    for run, kind in getattr(layout, "rivers", ()):
        for (ax, ay), (bx, by) in zip(run, run[1:]):
            if max(ax, bx) < cx * CS - 6 or min(ax, bx) > cx * CS + CS + 6 or max(ay, by) < cy * CS - 6 or min(ay, by) > cy * CS + CS + 6: continue
            dx, dy = bx - ax, by - ay; L = math.hypot(dx, dy) or 1e-9; ux, uy = dx / L, dy / L; nx, ny = -uy, ux
            for k in range(2):                # 0.45: a couple of faint current marks per bend (dense streaks read as rain)
                t = h01(int(ax * 7) + k, int(ay * 7), 601); o = (h01(int(ax * 7), int(ay * 7) + k, 603) - .5) * 4.2
                px, py = ax + dx * t + nx * o, ay + dy * t + ny * o
                if not wet(px, py) or not wet(px + ux * .6, py + uy * .6): continue
                a0, a1 = S(px, py), S(px + ux * .6, py + uy * .6)
                pygame.draw.line(lay, (225, 242, 250, 60), a0, a1, 1); drawn = True
    for br in _bridges(layout)[1].get((cx, cy), ()):
        _draw_bridge(lay, S, br); drawn = True
    if not drawn: return None
    lay.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return lay

# ---- 0.33: smooth ponds.  The pond outline is the same noisy ellipse that decides which tiles are water,
# evaluated continuously, so shores are curved instead of stepped.
POND_COL = {"fresh": (50, 138, 180), "ice": (146, 194, 222), "oasis": (40, 170, 166), "dark": (44, 66, 104), "murk": (64, 86, 60)}
def _pond_noise(wx, wy):
    """The shoreline wobble at a point - the same for every pond, so it is worked out once per point (0.45)."""
    return (vnoise(wx - .5, wy - .5, 4, 61) - .5) * .7 + (vnoise(wx - .5, wy - .5, 2, 62) - .5) * .25

def _pond_d(pond, wx, wy, noise=None):
    cx, cy, R, kind, rx, ry, rot = pond
    dx, dy = wx - cx, wy - cy
    lim = R * 1.45 + 1.0
    if noise is None and (abs(dx) > lim or abs(dy) > lim): return 9.0      # 0.45: far outside the beach ring - no noise needed
    if rot:
        cr, sr = math.cos(rot), math.sin(rot)
        u = (dx * cr + dy * sr) / rx; v = (-dx * sr + dy * cr) / ry
    else:
        u = dx / rx; v = dy / ry
    return u * u + v * v + (_pond_noise(wx, wy) if noise is None else noise)

def _pond_min(ponds, wx, wy):
    """(distance, pond) of the nearest pond to (wx, wy), computing the shoreline noise once."""
    best = None; nz = None
    for p_ in ponds:
        lim = p_[2] * 1.45 + 1.0
        if abs(wx - p_[0]) > lim or abs(wy - p_[1]) > lim:
            continue
        if nz is None: nz = _pond_noise(wx, wy)
        d = _pond_d(p_, wx, wy, nz)
        if best is None or d < best[0]: best = (d, p_)
    return best or (9.0, ponds[0] if ponds else None)

def _pond_grid(layout):
    """0.45: ponds bucketed by chunk, so a lookup no longer scans every pond in the world."""
    g = getattr(layout, "_pond_grid", None)
    if g is None:
        g = {}
        for i, p in enumerate(getattr(layout, "ponds", ())):
            m = p[2] + 4
            for ccx in range(int((p[0] - m - 1) // CS), int((p[0] + m + 1) // CS) + 1):
                for ccy in range(int((p[1] - m - 1) // CS), int((p[1] + m + 1) // CS) + 1):
                    g.setdefault((ccx, ccy), []).append(i)
        layout._pond_grid = g
    return g

def _ponds_near(layout, x0, y0):
    return list(_pond_grid(layout).get((int(x0) // CS, int(y0) // CS), ()))

def water_under(layout, x, y):
    """True where a pond or river lies at (x, y), even under a road (roads are dry tiles over the water)."""
    return _pond_min([layout.ponds[i] for i in _pond_grid(layout).get((int(x) // CS, int(y) // CS), ())], x, y)[0] < 1.0

def _pond_contour(layout, i):
    """Screen-space (iso) points along the shore line d == 1, cached per pond."""
    cache = getattr(layout, "_pond_ct", None)
    if cache is None: cache = layout._pond_ct = {}
    if i in cache: return cache[i]
    p = layout.ponds[i]; cx, cy, R, kind, rx, ry, rot = p
    cr, sr = math.cos(rot), math.sin(rot)
    n = max(32, int(R * 16)); pts = []
    for k in range(n):
        th = k / n * math.tau
        eu, ev = math.cos(th) * rx, math.sin(th) * ry
        ddx, ddy = eu * cr - ev * sr, eu * sr + ev * cr
        lo, hi = .3, 1.9
        for _ in range(14):
            mid = (lo + hi) / 2
            if _pond_d(p, cx + ddx * mid, cy + ddy * mid) < 1: lo = mid
            else: hi = mid
        t = (lo + hi) / 2
        pts.append((cx + ddx * t, cy + ddy * t))
    cache[i] = pts
    return pts

def _pond_overlay(layout, cx, cy, pidx, Wd, Hd, mask):
    lay = pygame.Surface((Wd, Hd), pygame.SRCALPHA)
    gx0, gy0 = iso(cx * CS, cy * CS); gx0 -= CS * HTW
    for i in pidx:
        pts = _pond_contour(layout, i); kind = layout.ponds[i][3]
        wc = POND_COL[kind]
        foam = mix(wc, (240, 248, 250), .75) if kind != "murk" else (120, 140, 96)
        sp = [((x - y) * HTW - gx0, (x + y) * HTH - gy0) for x, y in pts]
        if not any(-40 < a < Wd + 40 and -40 < b < Hd + 40 for a, b in sp): continue
        n = len(sp)
        # 0.43.2: where this pool overlaps its neighbours (a river is a chain of pools) the shore line is left out, so a river is
        # one body of water with two banks instead of a row of circles
        others = [layout.ponds[j] for j in pidx if j != i]
        keep = []
        for k in range(n):
            mx_ = (pts[k][0] + pts[(k + 1) % n][0]) / 2; my_ = (pts[k][1] + pts[(k + 1) % n][1]) / 2
            keep.append(not any(_pond_d(o, mx_, my_) < 1.05 for o in others if abs(o[0] - mx_) < o[2] + 2 and abs(o[1] - my_) < o[2] + 2))
        # dark wet edge just outside the water, then a foam lip and a fainter second wave inside
        for k in range(n):
            if not keep[k]: continue
            a0, a1 = sp[k], sp[(k + 1) % n]
            pygame.draw.line(lay, shade(wc, .45) + (90,), (a0[0], a0[1] + 1), (a1[0], a1[1] + 1), 3)
            w0 = math.sin(k * 1.3) * 1.2
            pygame.draw.line(lay, foam + (125,), (a0[0], a0[1] + 1 + w0), (a1[0], a1[1] + 1 + w0), 2)      # 0.45: softer foam lip
            if k % 3 != 0:
                pygame.draw.line(lay, foam + (55,), (a0[0], a0[1] + 5 + w0), (a1[0], a1[1] + 5 + w0), 1)
        # 0.44.21: shallows - a lighter band just inside the shore, reeds on the bank and a few lily pads / glints on open water
        pc = layout.ponds[i]; ccx, ccy = pc[0], pc[1]
        lite = mix(wc, (210, 240, 235), .38)
        for k in range(n):
            if not keep[k]: continue
            a0 = pts[k]; a1 = pts[(k + 1) % n]
            q0 = (ccx + (a0[0] - ccx) * .86, ccy + (a0[1] - ccy) * .86); q1 = (ccx + (a1[0] - ccx) * .86, ccy + (a1[1] - ccy) * .86)
            s0 = ((q0[0] - q0[1]) * HTW - gx0, (q0[0] + q0[1]) * HTH - gy0); s1 = ((q1[0] - q1[1]) * HTW - gx0, (q1[0] + q1[1]) * HTH - gy0)
            pygame.draw.line(lay, lite + (70,), (s0[0], s0[1] + 3), (s1[0], s1[1] + 3), 4)
            hk = h01(i, k, 651)
            if hk < .16 and kind in ("fresh", "murk", "oasis"):      # reeds
                bx_, by_ = sp[k][0], sp[k][1] + 1
                for r_ in range(3):
                    hx = bx_ + (r_ - 1) * 3; hh = 7 + int(h01(i, k * 3 + r_, 652) * 6)
                    pygame.draw.line(lay, (62, 112, 52, 255), (hx, by_), (hx + (r_ - 1), by_ - hh), 1)
                    pygame.draw.line(lay, (96, 150, 70, 255), (hx + 1, by_), (hx + 1 + (r_ - 1), by_ - hh + 2), 1)
                pygame.draw.line(lay, (110, 80, 44, 255), (bx_ + 3, by_), (bx_ + 3, by_ - 9), 2)
                pygame.draw.ellipse(lay, (84, 56, 34, 255), (bx_ + 1, by_ - 13, 4, 6))        # cattail
            elif hk > .94 and kind in ("fresh", "murk"):             # lily pad
                lx_, ly_ = sp[k][0], sp[k][1] + 7
                pygame.draw.ellipse(lay, (58, 126, 62, 235), (lx_ - 5, ly_ - 2, 10, 5))
                pygame.draw.ellipse(lay, (92, 160, 84, 235), (lx_ - 4, ly_ - 2, 8, 3))
            elif .5 < hk < .56:                                      # glint
                gx_, gy_ = sp[k][0], sp[k][1] + 9
                pygame.draw.line(lay, (240, 250, 255, 190), (gx_ - 2, gy_), (gx_ + 2, gy_), 1)
    lay.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return lay

_PATCH = {}
def _patch_blob(w, h, col, a):
    k = (w, h, col, a)
    b = _PATCH.get(k)
    if b is None:
        tmp = pygame.Surface((w, h), pygame.SRCALPHA)
        for j in range(5):              # stack: centre ends up ~5x the edge alpha, edges feather out
            f = 1 - j / 5
            e = pygame.Surface((max(1, int(w * f)), max(1, int(h * f))), pygame.SRCALPHA)
            pygame.draw.ellipse(e, col + (a,), e.get_rect())
            tmp.blit(e, ((w - e.get_width()) // 2, (h - e.get_height()) // 2))
        if len(_PATCH) > 300: _PATCH.clear()
        b = _PATCH[k] = tmp
    return b

def _soft_patches(layout, surf, x0, y0, Wd, Hd, segs):
    """Feathered light / shade patches on grassy ground (0.33: replaces hard-edged ovals)."""
    for ly in range(CS):
        for lx in range(CS):
            x, y = x0 + lx, y0 + ly
            kind, col = tile_cached(layout, x, y)
            if kind != "ground": continue
            a = area_at(x, y) or AREAS[0]
            if bz(a[0]) in ("Frostmarch", "Sunscar Desert"): continue
            pxc = CS * HTW + (lx - ly) * HTW; top = (lx + ly) * HTH
            for pk in range(2):
                if h01(x, y, 80 + pk) < .45:
                    u = h01(x, y, 31 + pk); v = h01(x, y, 51 + pk)
                    sx, sy = pxc + (u - v) * HTW * .5, top + HTH + (u + v - 1) * HTH * .5
                    dk = h01(x, y, 82 + pk) < .55
                    w = 44 + int(h01(x, y, 84 + pk) * 4) * 8
                    blob = _patch_blob(w, w // 2 - 2, (24, 40, 18) if dk else (236, 240, 170), 9 if dk else 8)
                    surf.blit(blob, (sx - w // 2, sy - w // 4))

def render_chunk_steps(layout, cx, cy):
    """Ground for an 8x8-tile chunk: a smooth colour field (no visible grid), a world-aligned
    texture, then per-tile detail (grass blades, paving, pebbles, ripples, lava glow).
    A generator that yields after every row of work, so the game can spread one chunk over
    several frames; the finished surface is its return value."""
    pump()
    Wd, Hd = CS * TW, CS * TH + 2
    x0, y0 = cx * CS, cy * CS
    F = 8
    sw, sh = Wd // F + 1, Hd // F + 1
    small = pygame.Surface((sw, sh))
    kinds = pygame.Surface((sw, sh))         # 0.45: per-sample surface type for the texture pass (R water, G sand/snow)
    _SOFTB = ("Frostmarch", "Sunscar Desert")
    segs = _road_index(layout).get((cx, cy)) if y0 < WORLD_H else None
    pidx = _ponds_near(layout, x0, y0) if y0 < WORLD_H else []
    ponds = [layout.ponds[i] for i in pidx]
    near = {}            # tile -> the few road segments that can reach it
    if segs:
        for sg in segs:
            ax, ay, bx, by, hw = sg; m = hw + .6
            for ty in range(max(y0 - 1, int(min(ay, by) - m)), min(y0 + CS + 2, int(max(ay, by) + m) + 1)):
                for tx in range(max(x0 - 1, int(min(ax, bx) - m)), min(x0 + CS + 2, int(max(ax, bx) + m) + 1)):
                    near.setdefault((tx, ty), []).append(sg)
    for py in range(sh):
        if py % 4 == 0: yield
        for px in range(sw):
            lx = px * F - CS * HTW; ly = py * F
            wx, wy = uniso(lx, ly); wx += x0; wy += y0
            if ponds:
                pd, pp = _pond_min(ponds, wx, wy)
                if pd < 1.6:
                    c = _ground_color_nr(layout, wx, wy)
                    if pd > 1.0:          # a thin sandy (or muddy) beach, then damp ground
                        sand = (206, 192, 142) if pp[3] in ("fresh", "oasis") else (150, 140, 120) if pp[3] == "ice" else (74, 62, 44)
                        b_ = max(0.0, 1 - (pd - 1.0) / .22)
                        c = mix(shade(c, .82 + .18 * min(1.0, (pd - 1.0) / .6)), sand, .5 * b_ * b_)
                    else:
                        wcol = shade(POND_COL[pp[3]], (1.06 - (1 - pd) * .26) * (.95 + vnoise(wx, wy, 2, 63) * .1))      # 0.45: deeper (darker) toward the middle
                        if pd > .78: wcol = mix(wcol, (196, 226, 214) if pp[3] != "murk" else (110, 120, 80), (pd - .78) / .22 * .35)   # shallows
                        k = min(1.0, (1.0 - pd) / .05)
                        c = mix(c, wcol, k)
                        kinds.set_at((px, py), (int(255 * k), 0, 0))
                    small.set_at((px, py), c); continue
            tk = tile_cached(layout, int(math.floor(wx)), int(math.floor(wy)))[0]
            if tk in ("water", "lava"): kinds.set_at((px, py), (255, 0, 0))
            elif tk == "ground":
                ar_ = area_at(int(wx), int(wy))
                if ar_ and bz(ar_[0]) in _SOFTB: kinds.set_at((px, py), (0, 255, 0))
            if segs:
                ns = near.get((int(wx), int(wy)))
                if ns is None:
                    small.set_at((px, py), _ground_color(layout, wx, wy)); continue
                c = _ground_color_nr(layout, wx, wy)
                d = _road_dist(ns, wx, wy)
                if d < .22 and _tile_noroad(layout, int(wx), int(wy))[0] != "plaza":
                    k = 1.0 if d < -.18 else (.22 - d) / .4
                    c = mix(c, _road_col(layout, wx, wy), k * k * (3 - 2 * k))
                small.set_at((px, py), c)
            else:
                small.set_at((px, py), _ground_color(layout, wx, wy))
    big = pygame.transform.smoothscale(small, (sw * F, sh * F)).subsurface((0, 0, Wd, Hd)).copy()
    # world-aligned texture, so it continues seamlessly across chunks
    gx, gy = iso(x0, y0); gx -= CS * HTW
    if _terrain.HAVE_NP:
        try: _terrain.texture_ground(big, int(gx), int(gy), pygame.transform.smoothscale(kinds, (sw * F, sh * F)).subsurface((0, 0, Wd, Hd)))      # 0.45: per-pixel grass / soil / sand / water surface
        except Exception: _old_texture(big, gx, gy, Wd, Hd)
    else:
        _old_texture(big, gx, gy, Wd, Hd)
    surf = pygame.Surface((Wd, Hd), pygame.SRCALPHA)
    surf.blit(big, (0, 0))
    mask = pygame.Surface((Wd, Hd), pygame.SRCALPHA)
    pygame.draw.polygon(mask, (255, 255, 255, 255), [(CS * HTW, -1), (Wd + 1, CS * HTH), (CS * HTW, CS * TH + 1), (-1, CS * HTH)])
    surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    _soft_patches(layout, surf, x0, y0, Wd, Hd, segs)
    for ly in range(CS):
        pump(); yield
        for lx in range(CS):
            x, y = x0 + lx, y0 + ly
            kind, col = tile_cached(layout, x, y)
            if kind == "void":
                continue
            if ponds and kind in ("water", "ground"):
                pdc = _pond_min(ponds, x + .5, y + .5)[0]
                if kind == "ground" and pdc < 1.15: continue
                if kind == "water" and (x, y) in layout.pond_tiles:
                    if pdc > .82: continue
                    kind = "pondwater"
            if segs and kind in ("road", "ground"):
                if kind == "road": kind, col = _tile_noroad(layout, x, y)
                if kind == "ground" and (x, y) in near and _road_dist(near[(x, y)], x + .5, y + .5) < (.1 if tile_cached(layout, x, y)[0] == "road" else -.3): continue
            pxc = CS * HTW + (lx - ly) * HTW; top = (lx + ly) * HTH
            def spot(k, s=.75):
                u = h01(x, y, 20 + k); v = h01(x, y, 40 + k)
                return pxc + (u - v) * HTW * s, top + HTH + (u + v - 1) * HTH * s
            a = area_at(x, y) or AREAS[0]
            b = BIOMES.get(a[0], BIOMES["Greenfields"])
            if kind == "ground":
                name = bz(a[0])
                if name in ("Frostmarch",):
                    for pk in range(2):      # 0.45: feathered wind-blown drifts (blue shadow side, bright crest) - no hard ovals
                        if h01(x, y, 120 + pk) < .45:
                            sx, sy = spot(14 + pk, .55)
                            surf.blit(_patch_blob(40, 14, (120, 146, 190), 10), (sx - 19, sy - 4))
                            surf.blit(_patch_blob(36, 12, (255, 255, 255), 16), (sx - 19, sy - 9))
                    for k in range(3):
                        sx, sy = spot(k); pygame.draw.circle(surf, (255, 255, 255), (int(sx), int(sy)), 1)
                elif name in ("Sunscar Desert",):
                    if h01(x, y, 125) < .5:      # 0.45: soft dune swell instead of two hard ovals
                        sx, sy = spot(15, .55)
                        surf.blit(_patch_blob(44, 14, (120, 84, 40), 9), (sx - 22, sy - 3))
                        surf.blit(_patch_blob(38, 12, (255, 240, 200), 10), (sx - 22, sy - 8))
                    for k in range(2):
                        sx, sy = spot(k)
                        pygame.draw.arc(surf, shade(col, 1.12), (sx - 10, sy - 3, 20, 8), 0.3, 2.8, 1)
                        pygame.draw.arc(surf, shade(col, .85), (sx - 10, sy - 1, 20, 8), 0.3, 2.8, 1)
                else:
                    dark = shade(col, .8); mid = shade(col, 1.0); light = shade(mix(col, b["speck"], .5), 1.06); hi = shade(col, 1.18)
                    # 0.26: a carpet of fine grass blades so the ground reads as grass, not paint
                    for k in range(14):
                        sx, sy = spot(30 + k, .98)
                        ln = 2 + h01(x, y, 60 + k) * 4
                        c = shade(col, .68 + h01(x, y, 70 + k) * .55)
                        pygame.draw.line(surf, c, (sx, sy), (sx + (h01(x, y, 85 + k) - .5) * 3, sy - ln), 1)
                    if h01(x, y, 99) < .3:          # bare soil showing through (0.45: feathered, not a sticker)
                        sx, sy = spot(13, .6)
                        surf.blit(_patch_blob(18, 8, (112, 92, 64), 26), (sx - 9, sy - 3))
                    # (0.33: the soft light/dark patches are painted in a feathered pre-pass, see _soft_patches)
                    # tufts: little fans of blades in three tones, clumped into lush and sparse stretches
                    lush = vnoise(x, y, 6, 55)
                    for k in range(0 if lush < .3 else 1 if lush < .55 else 2 if lush < .78 else 3):
                        sx, sy = spot(k)
                        base_c = (dark, mid, light, hi)[(k + int(h01(x, y, 90) * 4)) % 4]
                        for bl in range(4):
                            ang = -1.57 + (bl - 1.5) * .5
                            ln = 5 + (bl % 2) * 3 + h01(x, y, 95 + k) * 3
                            pygame.draw.line(surf, base_c, (sx, sy), (sx + math.cos(ang) * ln, sy + math.sin(ang) * ln), 1)
                        pygame.draw.line(surf, dark, (sx - 3, sy + 1), (sx + 3, sy + 1), 1)
                    for k in range(5, 7):
                        sx, sy = spot(k)
                        c = dark if k % 2 else light
                        pygame.draw.line(surf, c, (sx, sy), (sx - 2, sy - 5), 1)
                        pygame.draw.line(surf, c, (sx + 2, sy), (sx + 4, sy - 4), 1)
                    if h01(x, y, 84) < .1:
                        sx, sy = spot(12)
                        for t_ in range(4):
                            pygame.draw.circle(surf, (238, 236, 220), (int(sx + t_ * 3 - 4), int(sy + (t_ % 2) * 2)), 1)
                    if name in ("Greenfields", "Crownlands") and h01(x, y, 61) < .12:
                        sx, sy = spot(9)
                        fc = ((240, 90, 100), (255, 230, 100), (210, 140, 255), (255, 255, 255))[int(h01(x, y, 62) * 4)]
                        for o in ((-3, 0), (3, 1), (0, -2)):
                            pygame.draw.circle(surf, fc, (int(sx + o[0]), int(sy + o[1])), 2)
                _ground_extras(surf, name, col, x, y, spot, layout, pxc, top)
            elif kind == "plaza":
                def P(u, v): return (pxc + (u - v) * HTW, top + (u + v) * HTH)
                tc = min(layout.towns, key=lambda t: (t.x - x - .5) ** 2 + (t.y - y - .5) ** 2) if layout.towns else None
                # 0.23: worn cobblestones - irregular stones in muted greys/browns with dark mortar
                pygame.draw.polygon(surf, (64, 58, 52), [P(0, 0), P(1, 0), P(1, 1), P(0, 1)])
                N = 3
                for su in range(N):
                    for sv in range(N):
                        gx_, gy_ = x * N + su, y * N + sv
                        sd = math.hypot(x + (su + .5) / N - tc.x, y + (sv + .5) / N - tc.y) if tc else 9
                        base = (128, 92, 70) if 4.3 <= sd < 5.1 else ((176, 166, 148) if h01(gx_, gy_, 61) < .5 else (164, 154, 138)) if (x, y) in layout.street else (150, 140, 124) if h01(gx_, gy_, 61) < .5 else (136, 128, 116)
                        if h01(gx_, gy_, 63) < .12: base = (118, 112, 104)
                        c = shade(base, .86 + h01(gx_, gy_, 64) * .2)
                        j = lambda k: (h01(gx_, gy_, 200 + k) - .5) * .09
                        u0, v0, u1, v1 = su / N + .03, sv / N + .03, (su + 1) / N - .03, (sv + 1) / N - .03
                        q = [P(u0 + j(0), v0 + j(1)), P(u1 + j(2), v0 + j(3)), P(u1 + j(4), v1 + j(5)), P(u0 + j(6), v1 + j(7))]
                        pygame.draw.polygon(surf, c, q)
                        pygame.draw.line(surf, shade(c, 1.16), q[0], q[1], 1); pygame.draw.line(surf, shade(c, 1.1), q[0], q[3], 1)
                        pygame.draw.line(surf, shade(c, .7), q[1], q[2], 1); pygame.draw.line(surf, shade(c, .7), q[3], q[2], 1)
                if h01(x, y, 66) < .1:      # moss / grime between the stones
                    q = P(h01(x, y, 67), h01(x, y, 68)); pygame.draw.ellipse(surf, (74, 82, 56), (q[0] - 6, q[1] - 2, 12, 5))
            elif kind == "dfloor" and getattr(_inst_mod(), "is_arena", False):
                # 0.45: battlegrounds are open fields - trampled earth with grit and grass tufts, no tile grid
                if h01(x, y, 70) < .35:
                    sx, sy = spot(70, .7)
                    for o in range(-3, 4, 3): pygame.draw.line(surf, shade(col, .78), (sx + o, sy), (sx + o + 1, sy - 4 - abs(o)), 1)
                if h01(x, y, 71) < .25: _pebbles(surf, x, y, spot, shade(col, .9), 2, .5)
            elif kind == "dfloor":
                def P(u, v): return (pxc + (u - v) * HTW, top + (u + v) * HTH)
                pygame.draw.line(surf, shade(col, .6), P(1, 0), P(1, 1), 1); pygame.draw.line(surf, shade(col, .6), P(0, 1), P(1, 1), 1)
                pygame.draw.line(surf, shade(col, 1.2), P(0, 0), P(1, 0), 1); pygame.draw.line(surf, shade(col, 1.2), P(0, 0), P(0, 1), 1)
                if h01(x, y, 70) < .22:
                    a0 = P(h01(x, y, 71), h01(x, y, 72)); a1 = (a0[0] + (h01(x, y, 73) - .5) * 18, a0[1] + h01(x, y, 74) * 8)
                    pygame.draw.line(surf, shade(col, .55), a0, a1, 1)
                if h01(x, y, 75) < .06:
                    q = P(.5, .5); pygame.draw.circle(surf, shade(col, .7), (int(q[0]), int(q[1])), 2)
            elif kind == "road":
                for k in range(4):
                    sx, sy = spot(k, .8)
                    pygame.draw.ellipse(surf, shade(col, .74 + h01(x, y, 70 + k) * .2), (sx - 2, sy - 1, 4 + k % 2 * 2, 3))
                def _P(u, v): return (pxc + (u - v) * HTW, top + (u + v) * HTH)
                for k in range(2):      # wheel ruts
                    ru = .3 + k * .4
                    pygame.draw.line(surf, shade(col, .72), _P(ru, .05), _P(ru, .95), 1)
                for (dx, dy, e0, e1) in ((-1, 0, (0, 0), (0, 1)), (0, -1, (0, 0), (1, 0)), (1, 0, (1, 0), (1, 1)), (0, 1, (0, 1), (1, 1))):
                    nk = tile_cached(layout, x + dx, y + dy)[0]
                    if nk in ("road", "plaza", "dfloor", "water", "void"): continue
                    pygame.draw.line(surf, shade(col, .62), _P(*e0), _P(*e1), 2)
                    pygame.draw.line(surf, shade(col, 1.18), (_P(*e0)[0], _P(*e0)[1] + 2), (_P(*e1)[0], _P(*e1)[1] + 2), 1)
                    for k in range(3):
                        t = h01(x, y, 170 + k + dx * 5 + dy * 9); a0, a1 = _P(*e0), _P(*e1)
                        gx_ = a0[0] + (a1[0] - a0[0]) * t; gy_ = a0[1] + (a1[1] - a0[1]) * t
                        pygame.draw.circle(surf, shade(col, .55 + h01(x, y, 175 + k) * .3), (int(gx_), int(gy_) + 1), 1)
                _road_extras(surf, col, x, y, spot, layout, pxc, top)
            elif kind == "pondwater":
                if h01(x, y, 159) < .5:                  # 0.45: one soft ripple per tile at most (was three hard ones)
                    sx, sy = spot(50, .6)
                    pygame.draw.line(surf, shade(col, 1.1), (sx - 6, sy), (sx + 6, sy), 1)
                    pygame.draw.line(surf, shade(col, .92), (sx - 4, sy + 2), (sx + 5, sy + 2), 1)
                if h01(x, y, 160) < .3:
                    sx, sy = spot(53, .6); pygame.draw.circle(surf, (235, 248, 255), (int(sx), int(sy)), 1)
                if h01(x, y, 161) < .1 and col[2] > 120:
                    sx, sy = spot(54, .5)
                    pygame.draw.ellipse(surf, (52, 118, 60), (sx - 5, sy - 2, 10, 5)); pygame.draw.ellipse(surf, (104, 170, 90), (sx - 4, sy - 2, 6, 3))
            elif kind == "water":
                nwat = sum(1 for dx_ in (-1, 0, 1) for dy_ in (-1, 0, 1) if (dx_ or dy_) and tile_cached(layout, x + dx_, y + dy_)[0] in ("water", "void"))
                for k in range(3):
                    sx, sy = spot(50 + k, .6)
                    pygame.draw.line(surf, shade(col, 1.25), (sx - 7, sy), (sx + 7, sy), 1)
                    pygame.draw.line(surf, shade(col, .8), (sx - 5, sy + 2), (sx + 6, sy + 2), 1)
                if h01(x, y, 160) < .35:
                    sx, sy = spot(53, .6); pygame.draw.circle(surf, (235, 248, 255), (int(sx), int(sy)), 1)
                    pygame.draw.line(surf, (235, 248, 255), (sx - 3, sy), (sx + 3, sy), 1)
                if nwat <= 6 and h01(x, y, 161) < .18:      # lily pad near the shore
                    sx, sy = spot(54, .5)
                    pygame.draw.ellipse(surf, (52, 118, 60), (sx - 5, sy - 2, 10, 5)); pygame.draw.ellipse(surf, (104, 170, 90), (sx - 4, sy - 2, 6, 3))
                for k in range(2):
                    sx, sy = spot(k, .6)
                    pygame.draw.arc(surf, shade(col, 1.45), (sx - 8, sy - 2, 16, 6), 0.4, 2.7, 1)
                # 0.17: surf foam along shorelines (below the sea-wall face on the far edges)
                def P(u, v): return (pxc + (u - v) * HTW, top + (u + v) * HTH)
                foam = mix(col, (240, 248, 250), .7); foam2 = mix(col, (240, 248, 250), .4)
                for (dx, dy, e0, e1, drop) in ((-1, 0, (0, 0), (0, 1), 14), (0, -1, (0, 0), (1, 0), 14), (1, 0, (1, 0), (1, 1), 0), (0, 1, (0, 1), (1, 1), 0)):
                    nk = tile_cached(layout, x + dx, y + dy)[0]
                    if nk in ("water", "void"): continue
                    if (x, y) in getattr(layout, "pond_tiles", {}): drop = 2 if drop else 0
                    a0, a1 = P(*e0), P(*e1)
                    n = 6
                    for i in range(n):
                        t0, t1 = i / n, (i + 1) / n
                        w0 = math.sin((x * 3 + y * 5 + i) * 1.7) * 1.5; w1 = math.sin((x * 3 + y * 5 + i + 1) * 1.7) * 1.5
                        p0 = (a0[0] + (a1[0] - a0[0]) * t0, a0[1] + (a1[1] - a0[1]) * t0 + drop + 2 + w0)
                        p1 = (a0[0] + (a1[0] - a0[0]) * t1, a0[1] + (a1[1] - a0[1]) * t1 + drop + 2 + w1)
                        pygame.draw.line(surf, foam, p0, p1, 2)
                        pygame.draw.line(surf, foam2, (p0[0], p0[1] + 3), (p1[0], p1[1] + 3), 1)
                    for k in range(3):
                        t = h01(x, y, 140 + k + dx * 3 + dy * 7)
                        bx_ = a0[0] + (a1[0] - a0[0]) * t; by_ = a0[1] + (a1[1] - a0[1]) * t + drop + 6 + h01(x, y, 150 + k) * 4
                        pygame.draw.circle(surf, foam2, (int(bx_), int(by_)), 1)
            elif kind == "lava":
                for k in range(3):
                    sx, sy = spot(k, .6)
                    pygame.draw.circle(surf, (255, 200, 90), (int(sx), int(sy)), 2 + k % 2)
    yield
    if segs:
        try: surf.blit(_road_overlay(layout, cx, cy, segs, Wd, Hd, mask), (0, 0))
        except Exception: pass
    if pidx:
        try: surf.blit(_pond_overlay(layout, cx, cy, pidx, Wd, Hd, mask), (0, 0))
        except Exception: pass
    if y0 < WORLD_H:
        try:
            br = _bridge_overlay(layout, cx, cy, segs, Wd, Hd, mask)
            if br is not None: surf.blit(br, (0, 0))
        except Exception: pass
    # 0.30: broad sun-dapple and shade patches so large fields read as rolling land instead of flat colour
    try:
        lay = pygame.Surface((Wd, Hd), pygame.SRCALPHA)
        for i in range(9):
            u = h01(cx, cy, 300 + i); v = h01(cx, cy, 340 + i); rw = 50 + h01(cx, cy, 380 + i) * 90
            px_ = int(u * Wd); py_ = int(v * Hd)
            if i % 3 == 0:
                for j in range(4):
                    f = 1 - j / 4
                    pygame.draw.ellipse(lay, (255, 244, 200, 9), (px_ - rw * f, py_ - rw * f * .5, rw * 2 * f, rw * f))
            else:
                for j in range(4):
                    f = 1 - j / 4
                    pygame.draw.ellipse(lay, (14, 22, 44, 10), (px_ - rw * f, py_ - rw * f * .5, rw * 2 * f, rw * f))
        lay.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        surf.blit(lay, (0, 0))
    except Exception:
        pass
    return surf

def shadow_sprite(w, h):
    key = ("shadow", int(w), int(h))
    s = _DECOR.get(key)
    if s is None:
        s = pygame.Surface((int(w) * 2, int(h) * 2), pygame.SRCALPHA)
        for i in range(8):
            f = 1 - i / 8
            pygame.draw.ellipse(s, (0, 0, 0, 22), (int(w) * (1 - f), int(h) * (1 - f), int(w) * 2 * f, int(h) * 2 * f))
        _DECOR[key] = s
    return s

class SurfaceCache(collections.OrderedDict):
    """0.37.2: least-recently-used cache of surfaces with a memory budget (MB), so a long session can't grow without bound."""
    def __init__(self, max_mb):
        super().__init__(); self.budget = int(max_mb * 1024 * 1024); self.used = 0
    def get(self, k, default=None):
        v = super().get(k)
        if v is None: return default
        self.move_to_end(k); return v
    def put(self, k, s):
        if k in self: self.used -= _surf_bytes(super().get(k))
        self[k] = s; self.used += _surf_bytes(s)
        while self.used > self.budget and len(self) > 1:
            _, old = self.popitem(last=False); self.used -= _surf_bytes(old)
        return s
    def clear(self):
        super().clear(); self.used = 0

def _surf_bytes(s):
    s = s[0] if isinstance(s, tuple) else s
    return s.get_width() * s.get_height() * s.get_bytesize() if isinstance(s, pygame.Surface) else 0

_GLOW = SurfaceCache(32)
def glow(r, color):
    """Radial glow for additive blending (BLEND_RGB_ADD)."""
    key = (int(r), tuple(color))
    g = _GLOW.get(key)
    if g is None:
        r = max(2, int(r)); g = pygame.Surface((r * 2, r * 2))
        for i in range(r, 0, -2):
            f = (1 - i / r) ** 1.6
            pygame.draw.circle(g, tuple(int(c * f) for c in color), (r, r), i)
        _GLOW.put(key, g)
    return g

def outline(spr, col=(22, 16, 12, 230)):
    m = pygame.mask.from_surface(spr, 60)
    sil = m.to_surface(setcolor=col, unsetcolor=(0, 0, 0, 0))
    out = pygame.Surface((spr.get_width() + 2, spr.get_height() + 2), pygame.SRCALPHA)
    for dx, dy in ((0, 1), (2, 1), (1, 0), (1, 2)):
        out.blit(sil, (dx, dy))
    out.blit(spr, (1, 1))
    return out

# -------------------------------------------------------------- helpers
def _finish(big, scale=.5):
    w, h = big.get_size()
    return pygame.transform.smoothscale(big, (max(1, int(w * scale)), max(1, int(h * scale))))

def _rot(pts, ang, ox, oy):
    c, s = math.cos(ang), math.sin(ang)
    return [(ox + x * c - y * s, oy + x * s + y * c) for x, y in pts]

# --------------------------------------------------------- decorations
DECOR_PROPS = {"well", "fence", "planter", "bench", "cart", "banner", "woodpile", "haystack", "tent", "campfire", "menhir", "ruin", "signpost", "boulders", "stump", "log"}
SOLID_PROPS = {"well", "cart", "haystack", "tent", "campfire", "menhir", "ruin", "boulders", "woodpile", "planter"}
# ---------------------------------------------------------------- 0.26 flora: painterly trees, bushes, mushrooms
# Drawn at 4x on a large canvas, then smooth-scaled down: hundreds of individual leaves with
# directional light from the upper left, bark texture, root flare, soft contact shadow.
import random as _rnd_mod
LIGHT = (-.62, -.78)

def _leaf_col(base, lum, r):
    f = .42 + 1.0 * lum + r.uniform(-.08, .08)
    c = shade(base, f)
    if lum > .78: c = mix(c, (236, 238, 150), (lum - .78) * .9)      # sunlit leaves go yellow-green
    return c

def _soft_shadow(S, bx, by, w, h, a=90):
    """Soft contact shadow.  0.45: each ring on its own layer so the alpha builds up toward the middle
    (drawing straight onto S replaced the alpha, leaving one flat faint disc)."""
    for i in range(6):
        f = 1 - i / 6
        lay = pygame.Surface((max(2, int(w * f)) + 2, max(2, int(h * f)) + 2), pygame.SRCALPHA)
        pygame.draw.ellipse(lay, (0, 0, 0, int(a / 5)), lay.get_rect())
        S.blit(lay, (bx - w * f / 2, by - h * f / 2))

def _canopy(S, cx, cy, rx, ry, base, r, density=1.0, leaf=(14, 10), clusters=None):
    """A leafy crown: dark interior, clusters of individual leaves lit from the upper left."""
    if clusters is None:
        clusters = []
        n = int(16 * density + 6)
        for i in range(n):
            a = r.uniform(0, math.tau); d = math.sqrt(r.random())
            ox = math.cos(a) * d * rx * .82; oy = math.sin(a) * d * ry * .78
            rad = r.uniform(.24, .38) * (rx + ry) * .5
            clusters.append((cx + ox, cy + oy, rad))
    # deep shadow mass
    for (x, y, rad) in clusters:
        pygame.draw.circle(S, shade(base, .26), (int(x + 5), int(y + 8)), int(rad * .82))
    for (x, y, rad) in clusters:
        pygame.draw.circle(S, shade(base, .38), (int(x + 2), int(y + 3)), int(rad * .78))
    # leaves, back clusters first
    lw, lh = leaf
    for (x, y, rad) in sorted(clusters, key=lambda c: c[1]):
        nl = int(rad * rad * .055 * density) + 10
        for _ in range(nl):
            a = r.uniform(0, math.tau); d = (r.random() ** .38) * rad * 1.02
            px = x + math.cos(a) * d; py = y + math.sin(a) * d * .9
            # light: position on the whole crown and inside the cluster
            gx = (px - cx) / max(1, rx); gy = (py - cy) / max(1, ry)
            lx = (px - x) / max(1, rad); ly = (py - y) / max(1, rad)
            lum = .5 - .32 * (gx * LIGHT[0] + gy * LIGHT[1]) - .3 * (lx * LIGHT[0] + ly * LIGHT[1]) + (.08 if d > rad * .7 else -.04)
            lum = max(0.0, min(1.0, lum))
            c = _leaf_col(base, lum, r)
            edge = d > rad * .75
            ang = r.uniform(0, math.tau); w_ = lw * r.uniform(.8, 1.35) * (1.25 if edge else 1); h_ = lh * r.uniform(.6, 1.1) * (1.15 if edge else 1)
            ca, sa = math.cos(ang), math.sin(ang)
            pts = [(px + ca * w_ * .5, py + sa * w_ * .5), (px - sa * h_ * .5, py + ca * h_ * .5),
                   (px - ca * w_ * .5, py - sa * w_ * .5), (px + sa * h_ * .5, py - ca * h_ * .5)]
            pygame.draw.polygon(S, c, pts)
        # a few bright flecks and dark gaps per cluster
        for _ in range(int(rad * .06)):
            a = r.uniform(3.6, 5.0); d = r.uniform(.4, .85) * rad
            pygame.draw.circle(S, mix(shade(base, 1.55), (250, 250, 180), .3), (int(x + math.cos(a) * d), int(y + math.sin(a) * d)), 2)
        for _ in range(int(rad * .04)):
            a = r.uniform(.3, 2.6); d = r.uniform(.2, .6) * rad
            pygame.draw.circle(S, shade(base, .36), (int(x + math.cos(a) * d), int(y + math.sin(a) * d)), int(r.uniform(2, 4)))
    return clusters

def _bark_trunk(S, bx, by, top_y, w0, w1, col, r, lean=0.0):
    """Tapered trunk with bark furrows, lit edge and root flare (4x space)."""
    tl = (bx - w1 / 2 + lean, top_y); tr = (bx + w1 / 2 + lean, top_y)
    poly = [(bx - w0 / 2 - 10, by + 4), (bx - w0 / 2, by - 14), tl, tr, (bx + w0 / 2, by - 14), (bx + w0 / 2 + 12, by + 4)]
    pygame.draw.polygon(S, shade(col, .55), poly)
    inner = [(bx - w0 / 2 + 3, by - 2), tl, (tl[0] + w1 * .6, top_y), (bx + w0 * .1, by)]
    pygame.draw.polygon(S, col, inner)
    hl = [(bx - w0 / 2 + 4, by - 10), (tl[0] + 2, top_y), (tl[0] + w1 * .22, top_y), (bx - w0 * .25, by - 10)]
    pygame.draw.polygon(S, shade(col, 1.28), hl)
    h = by - top_y
    for i in range(int(w0 / 4)):
        t = (i + .5) / (w0 / 4)
        x0 = bx - w0 / 2 + t * w0; x1 = tl[0] + t * w1
        pts = []
        for k in range(9):
            f = k / 8
            pts.append((x0 + (x1 - x0) * f + r.uniform(-1.6, 1.6), by - 6 - h * f))
        pygame.draw.lines(S, shade(col, .38 if i % 2 else .62), False, pts, 2)
    for k in range(int(h / 14)):                     # knots and bark plates
        y = by - 10 - r.uniform(0, h - 20); f = (by - y) / h
        x = bx + lean * f + r.uniform(-w0 * .3, w0 * .3) * (1 - f * .5)
        pygame.draw.ellipse(S, shade(col, .4), (x - 4, y - 2, 8, 5))
        pygame.draw.arc(S, shade(col, 1.25), (x - 5, y - 4, 10, 8), .4, 2.7, 1)
    # roots
    for sg in (-1, 1):
        for j in range(2):
            ex = bx + sg * (w0 * .5 + 14 + j * 10); ey = by + 6 + j * 3
            pygame.draw.line(S, shade(col, .5), (bx + sg * w0 * .25, by - 10), (ex, ey), 9 - j * 3)
            pygame.draw.line(S, shade(col, .85 if sg < 0 else .6), (bx + sg * w0 * .25, by - 12), (ex, ey - 2), 4 - j)

def _branch(S, p0, p1, w, col):
    pygame.draw.line(S, shade(col, .5), p0, p1, w)
    pygame.draw.line(S, shade(col, 1.05), (p0[0] - 1, p0[1] - 1), (p1[0] - 1, p1[1] - 1), max(1, w // 3))

def _grass_skirt(S, bx, by, w, base, r, n=40):
    for _ in range(n):
        x = bx + r.uniform(-w / 2, w / 2); y = by + r.uniform(-4, 8)
        hh = r.uniform(10, 26)
        c = shade(base, r.uniform(.55, 1.25))
        pygame.draw.line(S, c, (x, y), (x + r.uniform(-6, 6), y - hh), 2)

def flora_sprite(kind, var):
    r = _rnd_mod.Random(f"flora:{kind}:{var}")
    v = var / 3.0
    if kind == "oak":
        S = pygame.Surface((420, 520), pygame.SRCALPHA); bx, by = 210, 500
        _soft_shadow(S, bx + 14, by, 260, 70, 120)
        tr = shade((96, 70, 48), .9 + v * .2)
        top = by - 150 - var * 6
        _bark_trunk(S, bx, by, top, 46, 26, tr, r, lean=r.uniform(-8, 8))
        for (sx_, ang, ln, w) in ((-.2, -2.3, 92, 14), (.2, -.9, 96, 13), (0, -1.7, 70, 11), (-.1, -2.8, 70, 9), (.1, -.35, 70, 9)):
            p0 = (bx + sx_ * 20, top + 30); p1 = (p0[0] + math.cos(ang) * ln, p0[1] + math.sin(ang) * ln)
            _branch(S, p0, p1, w, tr)
        g = shade(((58, 122, 48), (70, 132, 52), (52, 112, 58), (82, 128, 44))[var % 4], .92 + v * .1)
        rx, ry = 168 + var * 6, 132 + var * 5
        _canopy(S, bx + r.uniform(-8, 8), top - ry * .42, rx, ry, g, r, density=1.3, leaf=(17, 11))
        sc = .31
    elif kind in ("pine", "snowpine"):
        S = pygame.Surface((340, 560), pygame.SRCALPHA); bx, by = 170, 540
        _soft_shadow(S, bx + 12, by, 200, 56, 120)
        tr = (78, 56, 40)
        H = 420 + var * 26
        _bark_trunk(S, bx, by, by - 120, 26, 16, tr, r)
        g = (32, 88, 50) if kind == "pine" else (40, 84, 70)
        g = shade(g, .92 + v * .18)
        tiers = 7 + var % 3
        for i in range(tiers):
            f = i / tiers
            yb = by - 70 - f * H * .86 + r.uniform(-8, 8)
            wdt = (150 - f * 128) * (1 + r.uniform(-.06, .06))
            th = H * .2 * (1 - f * .4)
            # dense dark core
            pygame.draw.polygon(S, shade(g, .32), [(bx - wdt * .9, yb + 6), (bx, yb - th), (bx + wdt * .9, yb + 6), (bx, yb + 16)])
            nb = int(14 + wdt * .18)
            for j in range(nb):
                t = (j + .5) / nb * 2 - 1                          # -1 left .. 1 right
                L = wdt * r.uniform(.78, 1.12)
                ex = bx + t * L; ey = yb + abs(t) * r.uniform(10, 26) - (1 - abs(t)) * 6 + r.uniform(-4, 4)
                sx_, sy_ = bx + t * 6, yb - th * (1 - abs(t) * .35)
                lum = .55 - .45 * t * LIGHT[0] * -1 * -1 - .25 * f      # left side lit
                lum = max(0, min(1, .5 - .42 * t + .18 * (1 - f)))
                c = _leaf_col(g, lum * .9, r)
                pygame.draw.line(S, shade(c, .6), (sx_, sy_), (ex, ey + 4), 5)
                # needles hanging off the branch
                for k in range(7):
                    q = (k + 1) / 8
                    nx = sx_ + (ex - sx_) * q; ny = sy_ + (ey - sy_) * q
                    pygame.draw.line(S, c, (nx, ny), (nx + r.uniform(-5, 5), ny + r.uniform(7, 14)), 2)
                    if lum > .6 and r.random() < .4:
                        pygame.draw.line(S, shade(c, 1.25), (nx, ny), (nx + r.uniform(-3, 3), ny + r.uniform(4, 9)), 1)
                if kind == "snowpine" and r.random() < .8:
                    pygame.draw.line(S, (238, 244, 252), (sx_ + (ex - sx_) * .2, sy_ + (ey - sy_) * .2 - 2), (sx_ + (ex - sx_) * .85, sy_ + (ey - sy_) * .85 - 2), 4)
        tip = by - 70 - H * .92
        pygame.draw.line(S, shade(g, .7), (bx, tip + 40), (bx, tip - 10), 5)
        if kind == "snowpine": pygame.draw.circle(S, (244, 248, 255), (bx, int(tip + 2)), 7)
        sc = .31
    elif kind in ("bush", "drybush"):
        S = pygame.Surface((260, 200), pygame.SRCALPHA); bx, by = 130, 180
        _soft_shadow(S, bx + 8, by, 170, 44, 110)
        g = (60, 122, 52) if kind == "bush" else (128, 108, 62)
        g = shade(g, .88 + v * .22)
        _canopy(S, bx, by - 58, 92, 56, g, r, density=1.0, leaf=(13, 9))
        if kind == "bush" and var % 2:
            for _ in range(12):
                a = r.uniform(3.3, 6.1); d = r.uniform(.2, .85)
                x = bx + math.cos(a) * 80 * d; y = by - 58 + math.sin(a) * 50 * d
                pygame.draw.circle(S, (120, 20, 30), (int(x + 1), int(y + 1)), 5); pygame.draw.circle(S, (222, 50, 64), (int(x), int(y)), 4)
                pygame.draw.circle(S, (255, 190, 190), (int(x - 1), int(y - 1)), 1)
        _grass_skirt(S, bx, by - 6, 150, g, r, 30)
        sc = .25
    elif kind == "mushroom":
        # a small cluster of toadstools, knee-high, not tree-sized
        S = pygame.Surface((200, 160), pygame.SRCALPHA); bx, by = 100, 146
        _soft_shadow(S, bx + 4, by, 120, 30, 100)
        cap = ((176, 46, 52), (140, 76, 168), (196, 108, 52))[var % 3]
        for (ox, hh, cr) in sorted(((-34, 44, 26), (6, 70, 38), (40, 34, 20), (-10, 26, 16)), key=lambda t: t[1], reverse=True):
            x = bx + ox; y = by - hh
            pygame.draw.polygon(S, (204, 194, 172), [(x - 7, by - 2), (x - 5, y), (x + 5, y), (x + 8, by - 2)])
            pygame.draw.line(S, (240, 234, 218), (x - 3, by - 4), (x - 2, y + 2), 3)
            pygame.draw.ellipse(S, shade(cap, .45), (x - cr, y - cr * .55 + 4, cr * 2, cr * 1.1))
            pygame.draw.ellipse(S, cap, (x - cr, y - cr * .62, cr * 2, cr * 1.04))
            pygame.draw.ellipse(S, shade(cap, 1.3), (x - cr * .7, y - cr * .58, cr * .9, cr * .5))
            pygame.draw.arc(S, shade(cap, .5), (x - cr, y - cr * .62, cr * 2, cr * 1.04), 3.4, 6.0, 2)
            for k in range(5):
                a = r.uniform(3.4, 6.0); d = r.uniform(.3, .8)
                pygame.draw.circle(S, (246, 240, 226), (int(x + math.cos(a) * cr * d), int(y + math.sin(a) * cr * .5 * d)), max(2, cr // 9))
        _grass_skirt(S, bx, by - 4, 120, (70, 120, 50), r, 18)
        sc = .3
    else:
        return None
    spr = outline(_finish(S, sc), (18, 24, 12, 42))
    return spr, (spr.get_width() // 2, int(by * sc) + 1)

def _rock_shape(S, cx, cy, rx, ry, col, r, lichen=True, hot=False, ice=False):
    """A faceted boulder lit from the upper left (4x space); cy is the ground line."""
    n = r.randint(7, 10)
    angs = sorted(r.uniform(0, math.tau) for _ in range(n))
    pts = []
    for a in angs:
        rr = r.uniform(.78, 1.08)
        x = cx + math.cos(a) * rx * rr
        y = cy - ry * .55 + math.sin(a) * ry * rr * (.62 if math.sin(a) > 0 else 1.0)
        pts.append((x, min(cy + 4, y)))
    peak = (cx - rx * .18, cy - ry * 1.0)
    pygame.draw.polygon(S, shade(col, .38), [(p[0] + 4, p[1] + 5) for p in pts])
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        mx, my = (a[0] + b[0]) / 2 - peak[0], (a[1] + b[1]) / 2 - peak[1]
        L = math.hypot(mx, my) or 1
        lum = .55 - .5 * (mx / L * LIGHT[0] + my / L * LIGHT[1]) + r.uniform(-.06, .06)
        c = shade(col, .5 + .85 * max(0, min(1, lum)))
        pygame.draw.polygon(S, c, [peak, a, b])
        pygame.draw.line(S, shade(c, .7), peak, a, 1)
    # top facet highlight
    pygame.draw.polygon(S, shade(col, 1.35), [peak, (peak[0] - rx * .3, peak[1] + ry * .3), (peak[0] + rx * .15, peak[1] + ry * .25)])
    for _ in range(int(rx * .25)):                                       # grain
        x = cx + r.uniform(-rx * .8, rx * .8); y = cy - r.uniform(ry * .1, ry * 1.1)
        pygame.draw.circle(S, shade(col, r.uniform(.6, 1.3)), (int(x), int(y)), 1)
    for _ in range(r.randint(1, 3)):                                     # cracks
        x = cx + r.uniform(-rx * .5, rx * .5); y = cy - r.uniform(ry * .3, ry * .9)
        p = [(x, y)]
        for k in range(4): p.append((p[-1][0] + r.uniform(-6, 6), p[-1][1] + r.uniform(4, 9)))
        pygame.draw.lines(S, shade(col, .35), False, p, 2)
    if lichen and not hot and not ice:
        for _ in range(int(rx * .5)):
            a = r.uniform(3.5, 5.6); d = r.uniform(.2, .9)
            x = cx + math.cos(a) * rx * d * .7; y = cy - ry * .5 + math.sin(a) * ry * d * .45
            pygame.draw.circle(S, r.choice(((88, 128, 60), (110, 140, 70), (170, 170, 90))), (int(x), int(y)), r.randint(2, 4))
    if hot:
        p = [(cx - rx * .5, cy - ry * .4)]
        for k in range(5): p.append((p[-1][0] + rx * .22, p[-1][1] + r.uniform(-8, 8)))
        pygame.draw.lines(S, (255, 110, 30), False, p, 4); pygame.draw.lines(S, (255, 210, 90), False, p, 2)
    if ice:
        pygame.draw.line(S, (255, 255, 255), (peak[0] - rx * .2, peak[1] + 6), (peak[0] + rx * .3, peak[1] + ry * .4), 3)

def _wood_cyl(S, x0, y0, x1, y1, rad, col, r, end_face=True):
    """A lying log from (x0,y0) to (x1,y1) (4x space)."""
    ang = math.atan2(y1 - y0, x1 - x0); nx, ny = -math.sin(ang), math.cos(ang)
    pts = [(x0 + nx * rad, y0 + ny * rad), (x1 + nx * rad, y1 + ny * rad), (x1 - nx * rad, y1 - ny * rad), (x0 - nx * rad, y0 - ny * rad)]
    pygame.draw.polygon(S, shade(col, .55), pts)
    pygame.draw.polygon(S, col, [(x0 - nx * rad * .1, y0 - ny * rad * .1), (x1 - nx * rad * .1, y1 - ny * rad * .1), pts[2], pts[3]])
    pygame.draw.line(S, shade(col, 1.3), (x0 - nx * rad * .7, y0 - ny * rad * .7), (x1 - nx * rad * .7, y1 - ny * rad * .7), 3)
    L = math.hypot(x1 - x0, y1 - y0)
    for k in range(int(L / 7)):
        t = r.random(); off = r.uniform(-.85, .85)
        a = (x0 + (x1 - x0) * t + nx * rad * off, y0 + (y1 - y0) * t + ny * rad * off)
        b = (a[0] + math.cos(ang) * r.uniform(8, 20), a[1] + math.sin(ang) * r.uniform(8, 20))
        pygame.draw.line(S, shade(col, .38 if r.random() < .6 else 1.2), a, b, 2)
    if end_face:
        ex, ey = x1, y1
        pygame.draw.ellipse(S, shade(col, .5), (ex - rad * .55, ey - rad, rad * 1.1, rad * 2))
        pygame.draw.ellipse(S, (196, 160, 110), (ex - rad * .45, ey - rad * .88, rad * .9, rad * 1.76))
        for k in range(1, 4):
            f = 1 - k * .22
            pygame.draw.ellipse(S, (150, 116, 76), (ex - rad * .45 * f, ey - rad * .88 * f, rad * .9 * f, rad * 1.76 * f), 1)

def _moss(S, x, y, w, r, n=10):
    for _ in range(n):
        pygame.draw.circle(S, r.choice(((74, 118, 52), (92, 136, 60), (60, 100, 46))), (int(x + r.uniform(-w / 2, w / 2)), int(y + r.uniform(-4, 4))), r.randint(3, 6))

def flora2_sprite(kind, var):
    r = _rnd_mod.Random(f"flora2:{kind}:{var}")
    v = var / 3.0
    if kind in ("rock", "icerock", "lavarock"):
        S = pygame.Surface((280, 220), pygame.SRCALPHA); bx, by = 140, 196
        _soft_shadow(S, bx + 10, by, 200, 50, 110)
        c = {"rock": (128, 124, 116), "icerock": (168, 204, 232), "lavarock": (60, 48, 46)}[kind]
        c = shade(c, .85 + v * .3); s_ = 1 + var * .22
        _rock_shape(S, bx, by, 74 * s_, 54 * s_, c, r, hot=kind == "lavarock", ice=kind == "icerock")
        if kind == "rock":
            for k in range(4):
                px_ = bx + r.choice((-1, 1)) * r.uniform(62, 84) * s_; py_ = by + r.uniform(-2, 8); w_ = r.uniform(8, 14)
                pygame.draw.ellipse(S, shade(c, .5), (px_ - w_ / 2 + 2, py_ - w_ * .3 + 2, w_, w_ * .6)); pygame.draw.ellipse(S, shade(c, 1.05), (px_ - w_ / 2, py_ - w_ * .3, w_, w_ * .6))
            _grass_skirt(S, bx, by - 2, 150 * s_, (70, 120, 50), r, 22)
        sc = .25
    elif kind == "boulders":
        S = pygame.Surface((300, 220), pygame.SRCALPHA); bx, by = 150, 196
        _soft_shadow(S, bx + 10, by, 240, 56, 110)
        c = shade((126, 122, 114), .9 + v * .2)
        _rock_shape(S, bx - 50, by - 6, 50, 60, shade(c, .92), r)
        _rock_shape(S, bx + 44, by - 2, 58, 52, c, r)
        _rock_shape(S, bx - 4, by + 6, 40, 34, shade(c, 1.05), r)
        _grass_skirt(S, bx, by, 220, (70, 120, 50), r, 26)
        sc = .25
    elif kind == "stump":
        S = pygame.Surface((220, 220), pygame.SRCALPHA); bx, by = 110, 190
        _soft_shadow(S, bx + 6, by, 140, 40, 110)
        tr = (104, 74, 48)
        w0 = 70; h = 64
        pygame.draw.polygon(S, shade(tr, .55), [(bx - w0 / 2 - 14, by + 4), (bx - w0 / 2, by - h), (bx + w0 / 2, by - h), (bx + w0 / 2 + 14, by + 4)])
        pygame.draw.polygon(S, tr, [(bx - w0 / 2 - 8, by), (bx - w0 / 2 + 2, by - h), (bx + 4, by - h), (bx + 2, by)])
        for k in range(9):
            x = bx - w0 / 2 + 4 + k * 8
            pygame.draw.line(S, shade(tr, .4 if k % 2 else 1.15), (x, by - h + 6), (x + r.uniform(-3, 3) - (4 if k < 4 else -4), by), 2)
        pygame.draw.ellipse(S, shade(tr, .6), (bx - w0 / 2 - 2, by - h - 18, w0 + 4, 36))
        pygame.draw.ellipse(S, (200, 164, 112), (bx - w0 / 2 + 3, by - h - 15, w0 - 6, 30))
        for k in range(1, 5):
            f = 1 - k * .19
            pygame.draw.ellipse(S, (152, 116, 76), (bx - (w0 / 2 - 3) * f, by - h - 15 * f, (w0 - 6) * f, 30 * f), 1)
        pygame.draw.line(S, (120, 90, 60), (bx - 4, by - h), (bx + 18, by - h - 6), 2)        # crack
        _moss(S, bx - w0 / 2 + 6, by - 12, 30, r, 12)
        _grass_skirt(S, bx, by, 130, (70, 120, 50), r, 18)
        sc = .25
    elif kind == "log":
        S = pygame.Surface((300, 160), pygame.SRCALPHA); bx, by = 150, 140
        _soft_shadow(S, bx + 6, by, 240, 40, 110)
        tr = (100, 72, 48)
        _wood_cyl(S, bx - 110, by - 26, bx + 104, by - 20, 24, tr, r)
        _moss(S, bx - 40, by - 46, 70, r, 14)
        if var % 2:
            for k in range(3):
                x = bx - 70 + k * 14
                pygame.draw.ellipse(S, (210, 180, 130), (x - 7, by - 50 - k * 2, 14, 7)); pygame.draw.line(S, (230, 220, 200), (x, by - 46 - k * 2), (x, by - 40), 2)
        _grass_skirt(S, bx, by - 2, 240, (70, 120, 50), r, 24)
        sc = .25
    elif kind == "dead":
        S = pygame.Surface((320, 460), pygame.SRCALPHA); bx, by = 160, 440
        _soft_shadow(S, bx + 10, by, 150, 40, 110)
        c = shade((84, 70, 60), .9 + v * .25)
        _bark_trunk(S, bx, by, by - 260, 34, 14, c, r, lean=r.uniform(-14, 14))
        def limb(x, y, ang, ln, w, depth):
            ex, ey = x + math.cos(ang) * ln, y + math.sin(ang) * ln
            pygame.draw.line(S, shade(c, .55), (x, y), (ex, ey), max(1, int(w)))
            pygame.draw.line(S, shade(c, 1.15), (x - 1, y - 1), (ex - 1, ey - 1), max(1, int(w / 3)))
            if depth > 0:
                for da in (-.5, .45):
                    limb(ex, ey, ang + da + r.uniform(-.2, .2), ln * r.uniform(.55, .75), w * .62, depth - 1)
        for (y0, a0) in ((150, -2.4), (190, -.75), (230, -2.0), (250, -1.1)):
            limb(bx + r.uniform(-4, 4), by - y0, a0 + r.uniform(-.2, .2), r.uniform(60, 90), 10, 3)
        sc = .31
    else:
        return None
    spr = outline(_finish(S, sc), (18, 24, 12, 42))
    return spr, (spr.get_width() // 2, int(by * sc) + 1)

_DECOR = {}

def _bez(p0, p1, p2, n=14):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0], (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in [i / n for i in range(n + 1)]]

def _tube(S, pts, w0, w1, col, rings=0, r=None):
    """Smooth shaded tube along a polyline (4x space): dark edge, body, lit stripe, optional ring marks."""
    n = len(pts)
    for i in range(n - 1):
        w = w0 + (w1 - w0) * i / (n - 1)
        pygame.draw.line(S, shade(col, .45), pts[i], pts[i + 1], int(w) + 4)
    for i in range(n - 1):
        w = w0 + (w1 - w0) * i / (n - 1)
        pygame.draw.line(S, shade(col, .85), pts[i], pts[i + 1], int(w))
        pygame.draw.circle(S, shade(col, .85), (int(pts[i][0]), int(pts[i][1])), int(w / 2))
    for i in range(n - 1):
        w = w0 + (w1 - w0) * i / (n - 1)
        pygame.draw.line(S, col, (pts[i][0] - w * .14, pts[i][1]), (pts[i + 1][0] - w * .14, pts[i + 1][1]), max(2, int(w * .56)))
    for i in range(n - 1):
        w = w0 + (w1 - w0) * i / (n - 1)
        pygame.draw.line(S, shade(col, 1.3), (pts[i][0] - w * .27, pts[i][1]), (pts[i + 1][0] - w * .27, pts[i + 1][1]), max(1, int(w * .16)))
    if rings:
        for i in range(1, n - 1, max(1, rings)):
            w = w0 + (w1 - w0) * i / (n - 1); x, y = pts[i]
            pygame.draw.arc(S, shade(col, .42), (x - w / 2, y - 5, w, 11), 3.35, 6.1, 3)
            pygame.draw.arc(S, shade(col, 1.2), (x - w / 2, y - 7, w, 11), 3.5, 5.0, 2)

def _frond(S, base, tip, ctrl, col, r, leaflets=17, ln=64, droop=.5):
    sp = _bez(base, ctrl, tip, 16)
    pygame.draw.lines(S, shade(col, .5), False, sp, 5)
    for i in range(2, len(sp) - 1):
        x, y = sp[i]; px, py = sp[i - 1]
        dx, dy = x - px, y - py; d = math.hypot(dx, dy) or 1
        nx, ny = -dy / d, dx / d
        f = i / len(sp); L = ln * math.sin(math.pi * min(1, f * 1.05)) * .85 + 10
        for sg in (-1, 1):
            ex = x + nx * sg * L * .8 + dx / d * L * .25; ey = y + ny * sg * L * .5 + L * droop * .55 + dy / d * L * .2
            lum = max(0, min(1, .55 + .25 * (-sg) - .2 * f))
            c = _leaf_col(col, lum, r)
            pygame.draw.line(S, shade(c, .6), (x, y), (ex, ey), 4)
            pygame.draw.line(S, c, (x, y - 1), (ex, ey - 1), 2)

def _bat_wing(S, root, ta, tb, col):
    """Bat-style wing: arched leading edge, scalloped trailing edge between finger bones, shaded membrane."""
    rx, ry = root
    mid = ((ta[0] + tb[0]) / 2, (ta[1] + tb[1]) / 2)
    pts = _bez(root, ((rx + ta[0]) / 2 + (ta[1] - ry) * .08, (ry + ta[1]) / 2 - 10), ta, 6)
    prev = ta
    for k in (1, 2, 3):
        q = k / 3.0
        ex, ey = ta[0] + (tb[0] - ta[0]) * q, ta[1] + (tb[1] - ta[1]) * q
        sx, sy = (prev[0] + ex) / 2 + (rx - mid[0]) * .22, (prev[1] + ey) / 2 + (ry - mid[1]) * .22
        pts += [(sx, sy), (ex, ey)]; prev = (ex, ey)
    pts.append(((tb[0] + rx) / 2, (tb[1] + ry) / 2 + 2))
    _shp(S, pts, col, lo=.55, hi=1.05, top=1.1, bot=.75)

def flora3_sprite(kind, var):
    r = _rnd_mod.Random(f"flora3:{kind}:{var}")
    v = var / 3.0
    if kind == "willow":
        S = pygame.Surface((460, 540), pygame.SRCALPHA); bx, by = 230, 520
        _soft_shadow(S, bx + 14, by, 290, 70, 120)
        tr = shade((92, 72, 54), .9 + v * .2)
        top = by - 150
        _bark_trunk(S, bx, by, top, 58, 34, tr, r, lean=r.uniform(-10, 10))
        for (ang, ln, w) in ((-2.4, 100, 16), (-.75, 104, 15), (-1.6, 80, 12)):
            p0 = (bx, top + 24); _branch(S, p0, (p0[0] + math.cos(ang) * ln, p0[1] + math.sin(ang) * ln), w, tr)
        g = shade(((96, 142, 62), (110, 152, 66), (84, 132, 70), (120, 150, 60))[var % 4], .95)
        _canopy(S, bx, top - 62, 170, 84, g, r, density=1.3, leaf=(15, 9))
        # long drooping strands, front ones last
        strands = []
        for k in range(44):
            a = r.uniform(.05, math.pi - .05); rr = r.uniform(.55, 1.0)
            x0 = bx + math.cos(a) * 170 * rr; y0 = top - 56 + math.sin(a) * 50 * rr + 20
            L = r.uniform(70, 190) * (1 - .55 * max(0, 1 - abs(x0 - bx) / 70))     # shorter near the trunk so it stays visible
            strands.append((y0, x0, L))
        for (y0, x0, L) in sorted(strands):
            sway = r.uniform(-14, 14); pts = _bez((x0, y0), (x0 + sway, y0 + L * .5), (x0 + sway * .5, y0 + L), 8)
            lum = max(0, min(1, .62 - .4 * ((x0 - bx) / 160) * -LIGHT[0] * -1 * -1 + r.uniform(-.12, .12)))
            c = _leaf_col(g, lum, r)
            pygame.draw.lines(S, shade(c, .6), False, pts, 4)
            for j, (px, py) in enumerate(pts[1:], 1):
                for sg in (-1, 1):
                    pygame.draw.line(S, shade(c, .85 + .3 * (j % 2)), (px, py), (px + sg * r.uniform(6, 12), py + r.uniform(1, 6)), 2)
        sc = .31
    elif kind == "palm":
        S = pygame.Surface((460, 560), pygame.SRCALPHA); bx, by = 200, 540
        _soft_shadow(S, bx + 20, by, 190, 50, 120)
        lean = 34 + var * 9
        tr = shade((140, 108, 70), .9 + v * .15)
        trunk = _bez((bx, by), (bx - 14, by - 200), (bx + lean, by - 380), 18)
        _tube(S, trunk, 38, 24, tr, rings=1, r=r)
        tx, ty = trunk[-1]
        for i in range(8):                                                # nuts under the crown
            a = r.uniform(0, math.tau); pygame.draw.circle(S, (86, 58, 34), (int(tx + math.cos(a) * 14), int(ty + 14 + math.sin(a) * 8)), 8)
            pygame.draw.circle(S, (140, 98, 58), (int(tx + math.cos(a) * 14 - 2), int(ty + 12 + math.sin(a) * 8)), 4)
        g = (60, 128, 58)
        fr = [(-150, 40, -90), (-120, -30, -150), (-60, -80, -110), (10, -100, -40), (70, -80, 40), (120, -30, 110), (150, 40, 150), (-30, 60, -60), (50, 60, 60)]
        for i, (ex, ey, cx_) in enumerate(sorted(fr, key=lambda f: f[1], reverse=True)):
            tip = (tx + ex * 1.35, ty + ey + 70 + (30 if abs(ex) > 100 else 0)); ctrl = (tx + ex * .55, ty - 60 - abs(ey) * .25 + (r.uniform(-8, 8)))
            _frond(S, (tx, ty), tip, ctrl, shade(g, .85 + .3 * (ex < 0)), r, ln=58)
        sc = .31
    elif kind == "cactus":
        S = pygame.Surface((340, 520), pygame.SRCALPHA); bx, by = 170, 500
        _soft_shadow(S, bx + 10, by, 180, 40, 120)
        g = shade((68, 140, 82), .9 + v * .2)
        arms = [(-1, 150, 90), (1, 210, 70)] if var % 2 == 0 else [(1, 160, 100), (-1, 240, 60)]
        main = [(bx + math.sin(i / 10 * 1.3) * 3, by - i * 33) for i in range(11)]
        for sd, hgt, ln in arms:
            pts = [(bx + sd * 8, by - hgt), (bx + sd * 62, by - hgt - 6), (bx + sd * 76, by - hgt - 20), (bx + sd * 78, by - hgt - ln - 30)]
            _tube(S, _bez(pts[0], pts[1], pts[3], 10), 36, 30, g)
        _tube(S, main, 62, 50, g)
        for i in range(4):                                                  # vertical ribs, a lit and a dark
            x = bx - 24 + i * 16
            pygame.draw.line(S, shade(g, .55), (x, by - 14), (x + 1, by - 340), 2)
            pygame.draw.line(S, shade(g, 1.25), (x - 4, by - 20), (x - 3, by - 336), 2)
        for k in range(46):
            y = by - 20 - r.uniform(0, 320); x = bx + r.uniform(-24, 24)
            pygame.draw.line(S, (238, 228, 190), (x, y), (x + r.uniform(-5, 5), y - r.uniform(5, 10)), 1)
        if var % 2 == 0:
            pygame.draw.circle(S, (214, 70, 110), (bx + 6, by - 352), 12); pygame.draw.circle(S, (250, 170, 190), (bx + 3, by - 355), 6)
        sc = .31
    elif kind in ("crystal", "darkcrystal"):
        S = pygame.Surface((360, 400), pygame.SRCALPHA); bx, by = 180, 380
        _soft_shadow(S, bx + 8, by, 220, 46, 130)
        c = (110, 200, 230) if kind == "crystal" else (160, 90, 220)
        g = pygame.Surface((360, 400), pygame.SRCALPHA)
        for rad, a in ((120, 26), (80, 40)):
            pygame.draw.circle(g, (*c, a), (bx, by - 70), rad)
        S.blit(g, (0, 0))
        spec = [(-80, 190, 38, -.14), (-30, 300, 48, -.05), (30, 240, 44, .08), (84, 150, 34, .18), (-4, 120, 30, .0), (-55, 110, 26, -.3)]
        for (ox, hh, w, tilt) in sorted(spec, key=lambda t: -t[1]):
            x = bx + ox; ytop = by - hh
            tx2 = x + tilt * hh
            base_l, base_r = (x - w, by - 6), (x + w, by - 6)
            tl, tr_ = (tx2 - w * .55, ytop + w * 1.2), (tx2 + w * .55, ytop + w * 1.2)
            tip = (tx2 + 2, ytop)
            mid = (x + w * .05, by - 6 - 0)
            for (poly, f) in (([base_l, tl, tip, (tx2 - w * .05, ytop + w * 1.3), mid], .78),
                              ([mid, (tx2 - w * .05, ytop + w * 1.3), tip, tr_, base_r], .52)):
                _shp(S, poly, shade(c, f * 1.1), lo=.7, hi=1.0, top=1.1, bot=.7)
            pygame.draw.line(S, (235, 252, 255), (tl[0] + 3, tl[1] + 6), (base_l[0] + 8, by - 30), 3)
            pygame.draw.line(S, shade(c, 1.6), tip, (tx2 - w * .3, ytop + w * 1.1), 2)
        sc = .31
    else:
        return None
    spr = outline(_finish(S, sc), (18, 24, 12, 42))
    return spr, (spr.get_width() // 2, int(by * sc) + 1)


def _plank(S, p0, p1, th, col, r, grain=True):
    """A wooden board from p0 to p1 with thickness th (4x space): dark edge, lit top, grain and nail heads."""
    ang = math.atan2(p1[1] - p0[1], p1[0] - p0[0]); nx, ny = -math.sin(ang), math.cos(ang)
    q = [(p0[0] + nx * th / 2, p0[1] + ny * th / 2), (p1[0] + nx * th / 2, p1[1] + ny * th / 2), (p1[0] - nx * th / 2, p1[1] - ny * th / 2), (p0[0] - nx * th / 2, p0[1] - ny * th / 2)]
    _shp(S, q, col, lo=.62, hi=1.0, top=1.12, bot=.82)
    if grain:
        L = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
        for _ in range(int(L / 14) + 1):
            t = r.random(); o = r.uniform(-.38, .38)
            a = (p0[0] + (p1[0] - p0[0]) * t + nx * th * o, p0[1] + (p1[1] - p0[1]) * t + ny * th * o)
            b = (a[0] + math.cos(ang) * r.uniform(10, 30), a[1] + math.sin(ang) * r.uniform(10, 30))
            pygame.draw.line(S, shade(col, r.choice((.55, 1.25))), a, b, 1)
    for t in (.1, .9):
        pygame.draw.circle(S, shade(col, .4), (int(p0[0] + (p1[0] - p0[0]) * t), int(p0[1] + (p1[1] - p0[1]) * t)), 2)

def _stone_blocks(S, x0, y0, x1, y1, col, r, rows=4):
    h = (y1 - y0) / rows
    for i in range(rows):
        y = y0 + i * h; off = (i % 2) * .5
        n = max(2, int((x1 - x0) / 34))
        for j in range(-1, n + 1):
            xa = x0 + (j + off) * (x1 - x0) / n; xb = xa + (x1 - x0) / n - 3
            xa = max(x0, xa); xb = min(x1, xb)
            if xb - xa < 4: continue
            c = shade(col, r.uniform(.8, 1.2))
            _shp(S, [(xa, y + 2), (xb, y + 2), (xb - 1, y + h - 2), (xa + 1, y + h - 2)], c, lo=.62, top=1.12, bot=.82)

def flora4_sprite(kind, var):
    r = _rnd_mod.Random(f"flora4:{kind}:{var}")
    v = var / 3.0
    wood = shade((132, 92, 56), .9 + v * .2)
    if kind == "well":
        S = pygame.Surface((220, 300), pygame.SRCALPHA); bx, by = 110, 284
        _soft_shadow(S, bx + 8, by, 160, 40, 110)
        stone = (136, 132, 124)
        pygame.draw.ellipse(S, shade(stone, .5), (bx - 62, by - 62, 124, 54))
        _stone_blocks(S, bx - 60, by - 62, bx + 60, by - 16, stone, r, rows=3)
        pygame.draw.ellipse(S, shade(stone, 1.15), (bx - 60, by - 82, 120, 44)); pygame.draw.ellipse(S, (22, 36, 54), (bx - 46, by - 76, 92, 32))
        pygame.draw.ellipse(S, (60, 120, 170), (bx - 42, by - 72, 84, 26)); pygame.draw.ellipse(S, (170, 214, 240), (bx - 30, by - 70, 30, 8))
        for sd in (-1, 1): _plank(S, (bx + sd * 52, by - 62), (bx + sd * 52, by - 178), 12, wood, r)
        _plank(S, (bx, by - 160), (bx, by - 120), 4, (96, 72, 46), r, False)
        pygame.draw.rect(S, shade(wood, .7), (bx - 8, by - 124, 16, 12), border_radius=3)
        _plank(S, (bx - 58, by - 154), (bx + 58, by - 154), 14, shade(wood, .8), r)
        for k in range(2):
            sg = -1 if k == 0 else 1
            _shp(S, [(bx + sg * 66, by - 150), (bx, by - 218), (bx + sg * 4, by - 160)], shade((176, 82, 52), .85 + .2 * k), lo=.5)
        _shp(S, [(bx - 70, by - 150), (bx, by - 222), (bx + 70, by - 150)], (172, 80, 50), lo=.5, top=1.15)
        for k in range(7): pygame.draw.line(S, (110, 46, 30), (bx - 62 + k * 18, by - 152), (bx + (k - 3) * 3, by - 216), 2)
        sc = .25
    elif kind == "fence":
        S = pygame.Surface((220, 180), pygame.SRCALPHA); bx, by = 110, 168
        _soft_shadow(S, bx + 8, by, 190, 30, 90)
        for x in (-80, 0, 80):
            _plank(S, (bx + x, by + 4), (bx + x, by - 100 - r.randint(0, 10)), 18, shade(wood, .9), r)
            pygame.draw.polygon(S, shade(wood, 1.2), [(bx + x - 9, by - 104), (bx + x, by - 114), (bx + x + 9, by - 104)])
        for yy, tilt in ((-78, 4), (-40, -3)):
            _plank(S, (bx - 100, by + yy + tilt), (bx + 100, by + yy - tilt), 14, wood, r)
        sc = .25
    elif kind == "planter":
        S = pygame.Surface((180, 160), pygame.SRCALPHA); bx, by = 90, 148
        _soft_shadow(S, bx + 6, by, 140, 30, 100)
        _shp(S, [(bx - 62, by - 56), (bx + 62, by - 56), (bx + 54, by), (bx - 54, by)], shade(wood, .85), lo=.55)
        for k in range(1, 4): pygame.draw.line(S, shade(wood, .45), (bx - 56 + k * 28, by - 54), (bx - 52 + k * 26, by - 2), 2)
        pygame.draw.rect(S, shade(wood, 1.2), (bx - 64, by - 62, 128, 10), border_radius=3)
        pygame.draw.ellipse(S, (60, 40, 28), (bx - 60, by - 70, 120, 20))
        for k in range(26):
            x = bx + r.uniform(-54, 54); y = by - 62 - r.uniform(6, 34)
            pygame.draw.line(S, (52, 120, 50), (x, by - 58), (x + r.uniform(-4, 4), y), 3)
        for k in range(10):
            x = bx + r.uniform(-50, 50); y = by - 72 - r.uniform(10, 36)
            c_ = ((226, 74, 96), (250, 210, 80), (190, 120, 220), (255, 255, 255))[k % 4]
            pygame.draw.circle(S, shade(c_, .6), (int(x + 1), int(y + 1)), 7); pygame.draw.circle(S, c_, (int(x), int(y)), 6); pygame.draw.circle(S, (255, 240, 160), (int(x), int(y)), 2)
        sc = .25
    elif kind == "bench":
        S = pygame.Surface((220, 160), pygame.SRCALPHA); bx, by = 110, 150
        _soft_shadow(S, bx + 6, by, 170, 30, 90)
        for x in (-70, 70):
            _plank(S, (bx + x - 6, by - 8), (bx + x + 4, by - 62), 14, shade(wood, .8), r)
        _plank(S, (bx - 88, by - 70), (bx + 88, by - 70), 18, wood, r)
        _plank(S, (bx - 88, by - 50), (bx + 88, by - 50), 14, shade(wood, 1.05), r)
        for yy in (-118, -96): _plank(S, (bx - 84, by + yy + 12), (bx + 84, by + yy + 12), 14, shade(wood, .92), r)
        for x in (-70, 70): _plank(S, (bx + x, by - 70), (bx + x, by - 126), 10, shade(wood, .7), r, False)
        sc = .25
    elif kind == "cart":
        S = pygame.Surface((300, 220), pygame.SRCALPHA); bx, by = 150, 206
        _soft_shadow(S, bx + 8, by, 240, 36, 100)
        _shp(S, [(bx - 100, by - 100), (bx + 70, by - 100), (bx + 56, by - 36), (bx - 84, by - 36)], shade(wood, .88), lo=.55)
        for k in range(1, 5): pygame.draw.line(S, shade(wood, .45), (bx - 100 + k * 34, by - 98), (bx - 90 + k * 32, by - 38), 2)
        pygame.draw.rect(S, shade(wood, 1.2), (bx - 104, by - 106, 178, 10), border_radius=3)
        for k in range(14):
            x = bx - 86 + k * 11; y = by - 114 - r.randint(0, 12)
            c_ = ((200, 52, 44), (232, 180, 56), (112, 164, 60), (230, 110, 40))[k % 4]
            pygame.draw.circle(S, shade(c_, .55), (x + 1, y + 2), 12); pygame.draw.circle(S, c_, (x, y), 11); pygame.draw.circle(S, shade(c_, 1.5), (x - 4, y - 4), 3)
        _plank(S, (bx + 66, by - 70), (bx + 140, by - 50), 8, shade(wood, .8), r)
        pygame.draw.circle(S, shade(wood, .45), (bx - 20, by - 26), 38); pygame.draw.circle(S, wood, (bx - 20, by - 26), 34); pygame.draw.circle(S, shade(wood, .55), (bx - 20, by - 26), 24, 4)
        for k in range(6):
            a = k * math.pi / 3; pygame.draw.line(S, shade(wood, .6), (bx - 20, by - 26), (bx - 20 + math.cos(a) * 32, by - 26 + math.sin(a) * 32), 4)
        pygame.draw.circle(S, (60, 50, 46), (bx - 20, by - 26), 6)
        sc = .25
    elif kind == "woodpile":
        S = pygame.Surface((200, 150), pygame.SRCALPHA); bx, by = 100, 140
        _soft_shadow(S, bx + 6, by, 150, 28, 100)
        rows = ((5, 0), (4, 1), (3, 2), (2, 3))
        for (n, row) in rows:
            for i in range(n):
                x = bx - (n - 1) * 17 + i * 34; y = by - 20 - row * 30
                pygame.draw.circle(S, shade(wood, .42), (x, y), 19); pygame.draw.circle(S, shade(wood, .9 + r.uniform(-.1, .1)), (x, y), 16)
                pygame.draw.circle(S, (214, 178, 124), (x, y), 12); pygame.draw.circle(S, (170, 130, 84), (x, y), 8, 2); pygame.draw.circle(S, (170, 130, 84), (x, y), 3)
                pygame.draw.arc(S, (255, 240, 200), (x - 15, y - 15, 30, 30), 2.2, 3.3, 2)
        sc = .25
    elif kind == "haystack":
        S = pygame.Surface((220, 240), pygame.SRCALPHA); bx, by = 110, 226
        _soft_shadow(S, bx + 6, by, 190, 36, 100)
        hay = (214, 176, 84)
        pygame.draw.ellipse(S, shade(hay, .5), (bx - 88, by - 40, 176, 50))
        pygame.draw.rect(S, shade(hay, .5), (bx - 88, by - 120, 176, 90))
        pygame.draw.ellipse(S, shade(hay, .5), (bx - 88, by - 200, 176, 160))
        pygame.draw.ellipse(S, shade(hay, .85), (bx - 84, by - 196, 160, 150))
        pygame.draw.rect(S, shade(hay, .85), (bx - 84, by - 120, 160, 86))
        pygame.draw.ellipse(S, hay, (bx - 82, by - 190, 120, 130))
        pygame.draw.rect(S, hay, (bx - 82, by - 120, 120, 84))
        for k in range(120):
            x = bx + r.uniform(-80, 80); y = by - r.uniform(14, 190)
            if ((x - bx) / 84) ** 2 + ((y - (by - 118)) / 82) ** 2 > 1 and y < by - 118: continue
            pygame.draw.line(S, shade(hay, r.choice((.6, .8, 1.25, 1.4))), (x, y), (x + r.uniform(-8, 8), y + r.uniform(8, 20)), 2)
        for yy in (-88, -52):
            pygame.draw.line(S, (112, 78, 44), (bx - 84, by + yy + 30), (bx + 84, by + yy + 30), 5)
        sc = .25
    elif kind == "tent":
        S = pygame.Surface((280, 300), pygame.SRCALPHA); bx, by = 140, 286
        _soft_shadow(S, bx + 8, by, 220, 40, 100)
        col = ((176, 56, 48), (60, 100, 170), (190, 160, 90))[var % 3]
        _shp(S, [(bx - 110, by - 4), (bx - 4, by - 220), (bx + 4, by - 4)], shade(col, .78), lo=.55, top=1.1, bot=.7)
        _shp(S, [(bx - 4, by - 220), (bx + 118, by - 6), (bx + 4, by - 4)], col, lo=.62, top=1.1, bot=.7)
        for k in range(1, 5):
            pygame.draw.line(S, shade(col, .55), (bx - 4, by - 220), (bx - 110 + k * 4 + (k - 2) * 14, by - 4), 2)
            pygame.draw.line(S, shade(col, 1.25), (bx - 2, by - 220), (bx + 30 * k, by - 6), 1)
        _shp(S, [(bx - 30, by - 4), (bx + 4, by - 130), (bx + 40, by - 4)], (30, 22, 24), lo=.9)
        pygame.draw.line(S, shade(col, 1.4), (bx + 4, by - 130), (bx + 40, by - 4), 3)
        pygame.draw.line(S, (96, 70, 44), (bx - 4, by - 222), (bx - 4, by - 250), 4)
        _shp(S, [(bx - 2, by - 250), (bx + 46, by - 238), (bx - 2, by - 226)], (220, 50, 48), lo=.6)
        sc = .25
    elif kind == "campfire":
        S = pygame.Surface((200, 200), pygame.SRCALPHA); bx, by = 100, 186
        _soft_shadow(S, bx + 4, by, 150, 30, 110)
        glow = pygame.Surface((200, 200), pygame.SRCALPHA)
        for rr, aa in ((86, 20), (62, 34), (40, 50)): pygame.draw.circle(glow, (255, 150, 50, aa), (bx, by - 40), rr)
        S.blit(glow, (0, 0))
        for k in range(10):
            a = k / 10 * math.tau; x = bx + math.cos(a) * 62; y = by - 10 + math.sin(a) * 22
            c_ = shade((124, 120, 114), r.uniform(.7, 1.15)); pygame.draw.ellipse(S, shade(c_, .45), (x - 17, y - 10, 34, 24)); pygame.draw.ellipse(S, c_, (x - 15, y - 12, 30, 20)); pygame.draw.ellipse(S, shade(c_, 1.3), (x - 11, y - 11, 14, 7))
        for (a, L) in ((-.6, 62), (.5, 58), (1.9, 54), (-2.1, 56)):
            _wood_cyl(S, bx - math.cos(a) * L * .5, by - 12 - math.sin(a) * 8, bx + math.cos(a) * L * .5, by - 24 + math.sin(a) * 8, 9, (92, 60, 38), r)
        for (dx, hh, col) in ((-18, 70, (230, 80, 24)), (14, 84, (240, 110, 30)), (0, 100, (255, 140, 40)), (24, 52, (230, 80, 24)), (-28, 48, (230, 80, 24))):
            pygame.draw.polygon(S, col, [(bx + dx - 16, by - 26), (bx + dx - 4, by - 26 - hh * .55), (bx + dx + 4, by - 26 - hh), (bx + dx + 10, by - 26 - hh * .5), (bx + dx + 18, by - 26)])
        for (dx, hh) in ((-6, 56), (10, 44), (0, 74)):
            pygame.draw.polygon(S, (255, 220, 110), [(bx + dx - 9, by - 26), (bx + dx, by - 26 - hh), (bx + dx + 9, by - 26)])
        pygame.draw.polygon(S, (255, 250, 220), [(bx - 4, by - 26), (bx, by - 26 - 36), (bx + 5, by - 26)])
        for k in range(6): pygame.draw.circle(S, (255, 190, 80), (int(bx + r.uniform(-30, 30)), int(by - r.uniform(70, 130))), 2)
        sc = .25
    elif kind == "menhir":
        S = pygame.Surface((160, 320), pygame.SRCALPHA); bx, by = 80, 304
        _soft_shadow(S, bx + 6, by, 110, 28, 110)
        col = shade((96, 98, 112), .9 + v * .2)
        pts = [(bx - 34, by), (bx - 30, by - 120), (bx - 20, by - 220), (bx - 2, by - 270), (bx + 22, by - 214), (bx + 32, by - 110), (bx + 38, by)]
        _shp(S, pts, col, True, lo=.45, spec_x=.2, top=1.15, bot=.75)
        _shp(S, [(bx - 2, by - 270), (bx + 22, by - 214), (bx + 32, by - 110), (bx + 38, by), (bx + 8, by - 2), (bx + 6, by - 150)], shade(col, .65), lo=.6)
        for k in range(3):
            y = by - 80 - k * 56; pygame.draw.lines(S, (110, 210, 240), False, [(bx - 12, y), (bx - 4, y - 14), (bx + 8, y - 4), (bx + 14, y - 20)], 4)
            pygame.draw.lines(S, (220, 250, 255), False, [(bx - 12, y), (bx - 4, y - 14), (bx + 8, y - 4), (bx + 14, y - 20)], 1)
        _moss(S, bx, by - 4, 70, r, 12)
        sc = .25
    elif kind == "ruin":
        S = pygame.Surface((320, 320), pygame.SRCALPHA); bx, by = 160, 304
        _soft_shadow(S, bx + 10, by, 260, 44, 110)
        col = (126, 124, 116)
        _stone_blocks(S, bx - 130, by - 120, bx - 40, by, col, r, rows=5)
        _shp(S, [(bx - 130, by - 120), (bx - 90, by - 150), (bx - 70, by - 128), (bx - 40, by - 140), (bx - 40, by - 120)], shade(col, 1.0), lo=.6)
        _stone_blocks(S, bx + 20, by - 230, bx + 80, by, col, r, rows=8)
        _shp(S, [(bx + 18, by - 230), (bx + 44, by - 250), (bx + 82, by - 232), (bx + 80, by - 220), (bx + 18, by - 220)], shade(col, 1.1), lo=.6)
        for k in range(5):
            x = bx - 20 + r.uniform(-50, 70); y = by - r.uniform(0, 26)
            _shp(S, [(x - 20, y), (x - 14, y - 22), (x + 12, y - 24), (x + 22, y)], shade(col, r.uniform(.7, 1.0)), lo=.55)
        _moss(S, bx - 80, by - 118, 90, r, 10); _moss(S, bx + 50, by - 6, 100, r, 12)
        for k in range(6):
            x = bx - 124 + k * 14; pygame.draw.line(S, (66, 120, 50), (x, by - 118), (x + r.uniform(-3, 3), by - 118 + r.uniform(20, 70)), 3)
        sc = .25
    elif kind == "signpost":
        S = pygame.Surface((240, 320), pygame.SRCALPHA); bx, by = 120, 306
        _soft_shadow(S, bx + 6, by, 100, 24, 100)
        _plank(S, (bx, by + 2), (bx, by - 250), 22, shade(wood, .85), r)
        for (yy, dr) in ((by - 218, 1), (by - 168, -1)):
            x0, x1 = bx - 90 if dr < 0 else bx - 20, bx + 90 if dr > 0 else bx + 20
            tip = (x1 + dr * 18, yy) if dr > 0 else (x0 - 18, yy)
            pts = [(x0, yy - 20), (x1, yy - 20), tip, (x1, yy + 20), (x0, yy + 20)] if dr > 0 else [(x1, yy - 20), (x0, yy - 20), tip, (x0, yy + 20), (x1, yy + 20)]
            _shp(S, pts, shade(wood, 1.1), lo=.6)
            for k in range(3): pygame.draw.line(S, shade(wood, .5), (x0 + 8, yy - 10 + k * 10), (x1 - 8, yy - 10 + k * 10), 1)
            pygame.draw.circle(S, shade(wood, .4), (bx, yy), 4)
        sc = .25
    elif kind in ("tallgrass", "dunegrass", "fern", "flowers"):
        S = pygame.Surface((200, 200), pygame.SRCALPHA); bx, by = 100, 188
        g = {"tallgrass": (92, 150, 62), "dunegrass": (176, 160, 92), "fern": (86, 160, 70), "flowers": (70, 130, 56)}[kind]
        g = shade(g, .9 + v * .25)
        if kind == "fern":
            for k in range(9):
                a = -2.9 + k * .4 + r.uniform(-.08, .08); L = r.uniform(64, 96)
                tip = (bx + math.cos(a) * L, by + math.sin(a) * L * .8 + 6); ctrl = (bx + math.cos(a) * L * .45, by + math.sin(a) * L * .8 - 30)
                _frond(S, (bx, by), tip, ctrl, shade(g, .95 + .25 * (k % 2)), r, leaflets=15, ln=26)
        else:
            n = 22 if kind != "flowers" else 14
            for k in range(n):
                x = bx + r.uniform(-48, 48); hh = r.uniform(60, 130) if kind == "tallgrass" else r.uniform(44, 84) if kind == "dunegrass" else r.uniform(26, 56)
                lean = r.uniform(-18, 18); c = shade(g, r.uniform(.6, 1.35))
                pts = _bez((x, by), (x + lean * .3, by - hh * .6), (x + lean, by - hh), 6)
                pygame.draw.lines(S, shade(c, .55), False, pts, 5); pygame.draw.lines(S, c, False, pts, 3)
                if kind == "tallgrass" and k % 5 == 0:
                    pygame.draw.ellipse(S, (214, 190, 96), (pts[-1][0] - 4, pts[-1][1] - 16, 9, 22)); pygame.draw.ellipse(S, (244, 224, 140), (pts[-1][0] - 2, pts[-1][1] - 14, 4, 14))
                if kind == "flowers":
                    c_ = ((226, 74, 96), (250, 210, 80), (190, 120, 220), (255, 255, 255))[k % 4]; tx, ty = pts[-1]
                    for q in range(5):
                        a = q * 1.256; pygame.draw.circle(S, shade(c_, .75), (int(tx + math.cos(a) * 8), int(ty + math.sin(a) * 8)), 6); pygame.draw.circle(S, c_, (int(tx + math.cos(a) * 7), int(ty + math.sin(a) * 7 - 1)), 5)
                    pygame.draw.circle(S, (250, 220, 90), (int(tx), int(ty)), 4)
        sc = .25
    elif kind == "iceshard":
        S = pygame.Surface((220, 300), pygame.SRCALPHA); bx, by = 110, 286
        _soft_shadow(S, bx + 6, by, 150, 30, 110)
        c = (150, 204, 236)
        for (ox, hh, w, tilt) in sorted(((-40, 140, 28, -.1), (0, 230, 36, .03), (40, 110, 26, .12), (-14, 90, 22, -.2)), key=lambda t: -t[1]):
            x = bx + ox; tip = (x + tilt * hh, by - hh)
            _shp(S, [(x - w, by), (x - w * .6, tip[1] + w * 1.4), tip, (x, by - 4)], shade(c, 1.1), True, lo=.6)
            _shp(S, [(x, by - 4), tip, (x + w * .6, tip[1] + w * 1.4), (x + w, by)], shade(c, .7), lo=.6)
            pygame.draw.line(S, (240, 252, 255), (x - w * .5, by - 20), (tip[0] - w * .1, tip[1] + 24), 3)
        sc = .25
    elif kind == "ribs":
        S = pygame.Surface((300, 200), pygame.SRCALPHA); bx, by = 150, 188
        _soft_shadow(S, bx + 6, by, 240, 30, 100)
        bone = (226, 216, 190)
        pygame.draw.line(S, shade(bone, .55), (bx - 120, by - 6), (bx + 120, by - 6), 12); pygame.draw.line(S, bone, (bx - 120, by - 9), (bx + 120, by - 9), 8)
        for k in range(6):
            x = bx - 100 + k * 40; h = 120 - abs(k - 2.5) * 12
            pts = _bez((x, by - 8), (x + 10, by - h - 14), (x + 54 - k * 2, by - h + 30), 10)
            pygame.draw.lines(S, shade(bone, .5), False, pts, 12); pygame.draw.lines(S, bone, False, pts, 8); pygame.draw.lines(S, shade(bone, 1.2), False, [(p[0] - 2, p[1] - 2) for p in pts], 2)
        sc = .25
    elif kind == "bones":
        S = pygame.Surface((160, 120), pygame.SRCALPHA); bx, by = 80, 108
        _soft_shadow(S, bx + 4, by, 120, 22, 90)
        bone = (226, 216, 190)
        for (x0, y0, x1, y1) in ((-50, -8, 18, -30), (-40, -36, 30, -4)):
            pygame.draw.line(S, shade(bone, .55), (bx + x0, by + y0), (bx + x1, by + y1), 14); pygame.draw.line(S, bone, (bx + x0, by + y0 - 2), (bx + x1, by + y1 - 2), 9)
            for (x, y) in ((x0, y0), (x1, y1)):
                for sg in (-1, 1): pygame.draw.circle(S, shade(bone, .55), (bx + x, by + y + sg * 8), 9); pygame.draw.circle(S, bone, (bx + x, by + y + sg * 8 - 1), 7)
        _sphere(S, (bx + 40, by - 26), 24, bone)
        for dx in (-8, 8): pygame.draw.circle(S, (30, 20, 20), (bx + 40 + dx, by - 28), 6)
        pygame.draw.polygon(S, (30, 20, 20), [(bx + 38, by - 22), (bx + 42, by - 22), (bx + 40, by - 14)])
        pygame.draw.rect(S, bone, (bx + 30, by - 10, 20, 12), border_radius=3)
        for k in range(4): pygame.draw.line(S, (110, 96, 80), (bx + 33 + k * 5, by - 8), (bx + 33 + k * 5, by), 1)
        sc = .25
    elif kind == "reeds":
        S = pygame.Surface((200, 240), pygame.SRCALPHA); bx, by = 100, 228
        _soft_shadow(S, bx + 4, by, 130, 26, 90)
        g = (74, 118, 56)
        for k in range(20):
            x = bx + r.uniform(-44, 44); hh = r.uniform(110, 190); lean = r.uniform(-16, 16); c = shade(g, r.uniform(.6, 1.3))
            pts = _bez((x, by), (x + lean * .3, by - hh * .6), (x + lean, by - hh), 6)
            pygame.draw.lines(S, shade(c, .5), False, pts, 5); pygame.draw.lines(S, c, False, pts, 3)
            if k % 3 == 0:
                tx, ty = pts[-1]
                pygame.draw.ellipse(S, (70, 40, 26), (tx - 7, ty - 8, 15, 40)); pygame.draw.ellipse(S, (124, 78, 46), (tx - 5, ty - 6, 8, 34))
                pygame.draw.line(S, (190, 170, 110), (tx, ty - 8), (tx, ty - 24), 2)
        sc = .25
    elif kind == "tomb":
        S = pygame.Surface((160, 220), pygame.SRCALPHA); bx, by = 80, 206
        _soft_shadow(S, bx + 4, by, 120, 26, 100)
        col = (112, 112, 124)
        _shp(S, [(bx - 44, by), (bx - 44, by - 100), (bx - 30, by - 140), (bx, by - 156), (bx + 30, by - 140), (bx + 44, by - 100), (bx + 44, by)], col, True, lo=.5, spec_x=.2, top=1.12)
        pygame.draw.line(S, shade(col, .4), (bx - 44, by - 100), (bx - 30, by - 140), 3)
        pygame.draw.line(S, shade(col, .35), (bx, by - 112), (bx, by - 54), 8); pygame.draw.line(S, shade(col, .35), (bx - 18, by - 92), (bx + 18, by - 92), 8)
        pygame.draw.line(S, shade(col, 1.4), (bx - 2, by - 112), (bx - 2, by - 54), 2); pygame.draw.line(S, shade(col, 1.4), (bx - 18, by - 94), (bx + 18, by - 94), 2)
        for k in range(3): pygame.draw.line(S, shade(col, .4), (bx + r.uniform(-30, 30), by - 120 - k), (bx + r.uniform(-30, 30), by - 70), 1)
        _moss(S, bx, by - 6, 80, r, 10)
        mound = pygame.Surface((160, 220), pygame.SRCALPHA); pygame.draw.ellipse(mound, (60, 52, 44, 255), (bx - 54, by - 18, 108, 34)); S.blit(mound, (0, 0))
        _moss(S, bx, by - 2, 100, r, 8)
        sc = .25
    elif kind == "glowshroom":
        S = pygame.Surface((220, 220), pygame.SRCALPHA); bx, by = 110, 206
        glow = pygame.Surface((220, 220), pygame.SRCALPHA)
        for rr, aa in ((100, 22), (74, 34), (50, 48)): pygame.draw.circle(glow, (80, 230, 230, aa), (bx, by - 60), rr)
        S.blit(glow, (0, 0)); _soft_shadow(S, bx + 4, by, 130, 26, 100)
        for (ox, hh, cr) in sorted(((-40, 60, 28), (6, 100, 40), (46, 50, 24), (-8, 40, 18), (30, 78, 20)), key=lambda t: t[1], reverse=True):
            x = bx + ox; y = by - hh
            pygame.draw.polygon(S, (150, 200, 210), [(x - 7, by - 2), (x - 5, y), (x + 5, y), (x + 8, by - 2)]); pygame.draw.line(S, (230, 255, 255), (x - 3, by - 4), (x - 2, y + 2), 3)
            pygame.draw.ellipse(S, (24, 100, 120), (x - cr, y - cr * .55 + 4, cr * 2, cr * 1.1)); pygame.draw.ellipse(S, (60, 200, 214), (x - cr, y - cr * .62, cr * 2, cr * 1.04))
            pygame.draw.ellipse(S, (170, 255, 250), (x - cr * .7, y - cr * .58, cr * .9, cr * .5))
            for k in range(5): pygame.draw.circle(S, (230, 255, 255), (int(x + r.uniform(-cr * .7, cr * .7)), int(y + r.uniform(-cr * .4, cr * .2))), 3)
        for k in range(8): pygame.draw.circle(S, (190, 255, 255), (int(bx + r.uniform(-60, 60)), int(by - r.uniform(60, 160))), 2)
        sc = .25
    elif kind == "vent":
        S = pygame.Surface((220, 200), pygame.SRCALPHA); bx, by = 110, 186
        _soft_shadow(S, bx + 4, by, 160, 34, 110)
        rock = (64, 52, 48)
        pygame.draw.ellipse(S, shade(rock, .5), (bx - 72, by - 50, 144, 52))
        for k in range(10):
            a = k / 10 * math.tau; x = bx + math.cos(a) * 56; y = by - 22 + math.sin(a) * 16
            c = shade(rock, r.uniform(.8, 1.3)); _shp(S, [(x - 18, y + 8), (x - 14, y - 12), (x + 12, y - 14), (x + 18, y + 8)], c, lo=.6)
        pygame.draw.ellipse(S, (40, 20, 14), (bx - 44, by - 40, 88, 32)); pygame.draw.ellipse(S, (230, 90, 24), (bx - 38, by - 38, 76, 26)); pygame.draw.ellipse(S, (255, 200, 80), (bx - 22, by - 34, 44, 14))
        for k in range(5):
            pygame.draw.circle(S, (90, 80, 78, 140), (int(bx + r.uniform(-14, 18) + k * 4), int(by - 56 - k * 22)), 12 + k * 4)
        for k in range(8): pygame.draw.circle(S, (255, 170, 60), (int(bx + r.uniform(-34, 34)), int(by - r.uniform(50, 120))), 2)
        sc = .25
    elif kind == "pebbles":
        S = pygame.Surface((160, 100), pygame.SRCALPHA); bx, by = 80, 88
        for k in range(7):
            x = bx + r.uniform(-50, 50); y = by - r.uniform(2, 22); w = r.uniform(16, 30)
            c = shade((132, 128, 120), r.uniform(.75, 1.2))
            pygame.draw.ellipse(S, shade(c, .4), (x - w / 2 + 2, y - w * .3 + 3, w, w * .6)); pygame.draw.ellipse(S, c, (x - w / 2, y - w * .32, w, w * .62)); pygame.draw.ellipse(S, shade(c, 1.35), (x - w * .3, y - w * .28, w * .4, w * .2))
        sc = .25
    elif kind == "banner":
        S = pygame.Surface((160, 360), pygame.SRCALPHA); bx, by = 80, 346
        _soft_shadow(S, bx + 4, by, 70, 20, 100)
        col = ((60, 100, 190), (186, 52, 46), (214, 176, 70))[var % 3]
        _plank(S, (bx, by), (bx, by - 320), 12, shade(wood, .75), r)
        pygame.draw.circle(S, (222, 182, 80), (bx, by - 326), 9); pygame.draw.circle(S, (255, 240, 170), (bx - 2, by - 328), 3)
        _plank(S, (bx - 44, by - 300), (bx + 44, by - 300), 8, (190, 150, 70), r, False)
        cloth = [(bx - 40, by - 296), (bx + 40, by - 296), (bx + 40, by - 190), (bx, by - 164), (bx - 40, by - 190)]
        _shp(S, cloth, col, lo=.62, top=1.12, bot=.8)
        for k in range(1, 4): pygame.draw.line(S, shade(col, .6), (bx - 40 + k * 20, by - 294), (bx - 40 + k * 20, by - 180 + abs(k - 2) * 0), 1)
        pygame.draw.circle(S, (240, 210, 110), (bx, by - 240), 17); pygame.draw.circle(S, shade(col, .8), (bx, by - 240), 12); pygame.draw.circle(S, (240, 210, 110), (bx, by - 240), 5)
        pygame.draw.lines(S, (214, 176, 70), True, cloth, 3)
        sc = .25
    else:
        return None
    spr = outline(_finish(S, sc), (18, 24, 12, 42))
    return spr, (spr.get_width() // 2, int(by * sc) + 1)

def _decor_raw(kind, var=0):
    pump()
    key = (kind, var)
    if key in _DECOR:
        return _DECOR[key]
    if kind in ("dead", "tent", "bush", "drybush"):      # 0.45: redrawn (props45)
        from . import props45
        res = props45.dead_tree(var) if kind == "dead" else props45.tent(var) if kind == "tent" else props45.bush(var, kind == "drybush")
        _DECOR[key] = res; return res
    if kind in ("oak", "pine", "snowpine", "bush", "drybush", "mushroom"):
        res = flora_sprite(kind, var)
        if res: _DECOR[key] = res; return res
    if kind in ("well", "fence", "planter", "bench", "cart", "woodpile", "haystack", "tent", "campfire", "menhir", "ruin", "signpost",
                "tallgrass", "dunegrass", "fern", "flowers", "iceshard", "ribs", "bones", "reeds", "tomb", "glowshroom", "vent", "pebbles", "banner"):
        res = flora4_sprite(kind, var)
        if res: _DECOR[key] = res; return res
    if kind in ("willow", "palm", "cactus", "crystal", "darkcrystal"):
        res = flora3_sprite(kind, var)
        if res: _DECOR[key] = res; return res
    if kind in ("rock", "icerock", "lavarock", "boulders", "stump", "log", "dead"):
        res = flora2_sprite(kind, var)
        if res: _DECOR[key] = res; return res
    v = var / 3.0
    S = pygame.Surface((160, 220), pygame.SRCALPHA)
    bx, by = 80, 210  # base point in 2x space
    def shadow(w=60, h=20):
        for i_ in range(4):        # 0.26: soft shadow, kept under the outline threshold
            f_ = 1 - i_ / 4
            pygame.draw.ellipse(S, (0, 0, 0, 14), (bx - w * f_ // 2, by - h * f_ // 2, w * f_, h * f_))
    if kind in ("pine", "snowpine"):
        shadow(76, 24)
        g = (34, 90, 48) if kind == "pine" else (44, 88, 70)
        g = shade(g, .9 + v * .25)
        pygame.draw.rect(S, (60, 42, 28), (bx - 7, by - 44, 14, 46))
        pygame.draw.rect(S, (110, 78, 50), (bx - 5, by - 44, 4, 44))
        hgt = 160 + var * 12
        n_t = 5
        for i in range(n_t):
            yb = by - 28 - i * hgt * .17; wdt = 66 - i * 11
            top = yb - hgt * .3
            lft = [(bx - wdt, yb)]
            for j in range(1, 6):
                f_ = j / 6
                lft.append((bx - wdt * (1 - f_) - (4 if j % 2 else -2), yb - (yb - top) * f_ * .0 + (6 if j % 2 else 0) * (1 - f_)))
            pygame.draw.polygon(S, shade(g, .5), [(bx - wdt, yb + 6), (bx, top + 4), (bx + wdt, yb + 6), (bx, yb + 14)])
            pygame.draw.polygon(S, shade(g, .78), [(bx - wdt, yb), (bx, top), (bx, yb + 8)])
            pygame.draw.polygon(S, g, [(bx, top), (bx + wdt, yb), (bx, yb + 8)])
            for k in range(7):
                f_ = (k + .5) / 7
                x0 = bx - wdt * (1 - f_); y0 = top + (yb - top) * f_
                pygame.draw.line(S, shade(g, .55), (x0 + 4, y0 + 2), (x0 + 1, y0 + 9), 2)
                x1 = bx + wdt * (1 - f_); pygame.draw.line(S, shade(g, 1.3), (x1 - 4, y0 + 2), (x1 - 1, y0 + 8), 2)
            pygame.draw.polygon(S, shade(g, 1.35), [(bx - 3, top + 2), (bx + wdt * .5, top + (yb - top) * .55), (bx + wdt * .2, top + (yb - top) * .5)])
            if kind == "snowpine":
                pygame.draw.polygon(S, (240, 246, 255), [(bx - wdt * .55, top + (yb - top) * .5), (bx, top), (bx + wdt * .55, top + (yb - top) * .5), (bx + wdt * .2, top + (yb - top) * .42), (bx - wdt * .1, top + (yb - top) * .55), (bx - wdt * .3, top + (yb - top) * .44)])
    elif kind in ("oak",):
        shadow(100, 30)
        tr = (92, 64, 42)
        pygame.draw.polygon(S, shade(tr, .6), [(bx - 14, by + 2), (bx - 8, by - 74), (bx + 8, by - 74), (bx + 15, by + 2)])
        pygame.draw.polygon(S, tr, [(bx - 11, by), (bx - 6, by - 74), (bx + 2, by - 74), (bx + 2, by)])
        pygame.draw.polygon(S, shade(tr, 1.25), [(bx - 9, by - 4), (bx - 5, by - 70), (bx - 2, by - 70), (bx - 3, by - 4)])
        for sg in (-1, 1):
            pygame.draw.line(S, shade(tr, .75), (bx + sg * 10, by - 2), (bx + sg * 24, by + 4), 6)
        pygame.draw.line(S, tr, (bx, by - 60), (bx - 26, by - 92), 7); pygame.draw.line(S, tr, (bx + 2, by - 64), (bx + 26, by - 94), 6)
        g = shade((62, 128, 52), .85 + v * .3)
        import random as _r
        rr = _r.Random(var * 31 + 7)
        blobs = [(-34, -102, 30), (32, -104, 28), (0, -138, 34), (-16, -86, 26), (20, -84, 26), (-44, -80, 18), (44, -82, 18), (-18, -122, 24), (22, -124, 24)]
        for (ox, oy, r) in blobs:
            pygame.draw.circle(S, shade(g, .55), (bx + ox + 3, by + oy + 8), r)
        for (ox, oy, r) in blobs:
            pygame.draw.circle(S, shade(g, .8), (bx + ox, by + oy + 3), r)
        for (ox, oy, r) in blobs:
            pygame.draw.circle(S, g, (bx + ox - 2, by + oy - 3), int(r * .86))
        for (ox, oy, r) in blobs:
            for _ in range(7):
                a_ = rr.random() * math.tau; d_ = rr.random() * r * .8
                lx = bx + ox - 4 + math.cos(a_) * d_; ly = by + oy - 6 + math.sin(a_) * d_ * .8
                lc = shade(g, 1.05 + rr.random() * .4) if (lx < bx + ox) else shade(g, .78 + rr.random() * .15)
                pygame.draw.ellipse(S, lc, (lx - 6, ly - 4, 12, 8))
            pygame.draw.circle(S, shade(g, 1.45), (bx + ox - r // 3, by + oy - r // 2), max(3, r // 5))
    elif kind == "willow":
        shadow(110, 30)
        tr = (86, 62, 44)
        pygame.draw.polygon(S, shade(tr, .65), [(bx - 13, by + 2), (bx - 6, by - 90), (bx + 8, by - 90), (bx + 14, by + 2)])
        pygame.draw.polygon(S, tr, [(bx - 10, by), (bx - 4, by - 90), (bx + 2, by - 90), (bx + 1, by)])
        pygame.draw.line(S, tr, (bx, by - 80), (bx - 24, by - 112), 6); pygame.draw.line(S, tr, (bx + 2, by - 84), (bx + 28, by - 110), 5)
        g = shade((92, 150, 70), .9 + v * .2)
        for (ox, oy, r) in ((-30, -120, 30), (28, -122, 30), (0, -142, 32), (-6, -112, 26)):
            pygame.draw.circle(S, shade(g, .62), (bx + ox + 2, by + oy + 6), r)
            pygame.draw.circle(S, g, (bx + ox, by + oy), r - 3)
        import random as _r
        rr = _r.Random(var * 17 + 3)
        for i in range(46):
            sx = bx + rr.uniform(-62, 62); sy = by - 150 + rr.uniform(0, 40) + abs(sx - bx) * .25
            ln = rr.uniform(40, 92)
            c = shade(g, rr.uniform(.7, 1.3))
            pts = [(sx + math.sin(j * .7) * 2, sy + j * ln / 6) for j in range(7)]
            pygame.draw.lines(S, c, False, pts, 2)
            pygame.draw.circle(S, shade(c, 1.1), (int(pts[-1][0]), int(pts[-1][1])), 2)
    elif kind == "palm":
        shadow(70, 20)
        for i in range(10):
            pygame.draw.circle(S, (130, 98, 60), (bx + i * 2, by - i * 14), 7)
        top = (bx + 20, by - 140)
        for ang in (-2.6, -2.0, -1.2, -.4, .3):
            ex = top[0] + math.cos(ang) * 60; ey = top[1] + math.sin(ang) * 30 + 20
            pygame.draw.polygon(S, (60, 130, 60), [top, (ex, ey), ((top[0] + ex) / 2, (top[1] + ey) / 2 - 8)])
    elif kind in ("dead",):
        shadow(50, 16)
        c = shade((70, 58, 50), .9 + v * .3)
        pygame.draw.polygon(S, c, [(bx - 8, by), (bx - 3, by - 110), (bx + 3, by - 110), (bx + 8, by)])
        for (a, l, y0) in ((-2.4, 50, 60), (-.7, 45, 75), (-2.0, 35, 95), (-1.0, 30, 100)):
            sx, sy = bx, by - y0; ex, ey = sx + math.cos(a) * l, sy + math.sin(a) * l
            pygame.draw.line(S, c, (sx, sy), (ex, ey), 5)
            pygame.draw.line(S, c, (ex, ey), (ex + math.cos(a - .6) * 16, ey + math.sin(a - .6) * 16), 3)
    elif kind in ("bush", "drybush"):
        shadow(66, 20)
        g = (62, 124, 54) if kind == "bush" else (126, 108, 62)
        g = shade(g, .85 + v * .3)
        blobs = ((-20, -14, 18), (18, -14, 18), (0, -30, 21), (-4, -12, 16))
        for (ox, oy, r) in blobs: pygame.draw.circle(S, shade(g, .55), (bx + ox + 2, by + oy + 5), r)
        for (ox, oy, r) in blobs: pygame.draw.circle(S, shade(g, .8), (bx + ox, by + oy + 2), r)
        for (ox, oy, r) in blobs:
            pygame.draw.circle(S, g, (bx + ox - 2, by + oy - 3), r - 4)
            pygame.draw.circle(S, shade(g, 1.35), (bx + ox - r // 3, by + oy - r // 2), r // 3)
            for k in range(4):
                a_ = h01(k, ox, 5) * math.tau
                pygame.draw.circle(S, shade(g, .7), (int(bx + ox + math.cos(a_) * r * .5), int(by + oy + math.sin(a_) * r * .4)), 3)
        if kind == "bush" and var % 2:
            for k in range(5):
                pygame.draw.circle(S, (230, 70, 80), (int(bx - 22 + k * 11), int(by - 20 - (k % 2) * 14)), 3)
    elif kind == "flowers":
        for i in range(7):
            ox = (h01(i, var, 1) - .5) * 60; oy = (h01(i, var, 2) - .5) * 24
            col = ((230, 80, 90), (250, 220, 90), (200, 120, 230), (255, 255, 255))[i % 4]
            pygame.draw.line(S, (50, 110, 50), (bx + ox, by + oy), (bx + ox, by + oy - 10), 2)
            pygame.draw.circle(S, col, (int(bx + ox), int(by + oy - 12)), 4)
    elif kind in ("rock", "icerock", "lavarock"):
        shadow(64, 20)
        c = {"rock": (128, 126, 122), "icerock": (170, 205, 235), "lavarock": (58, 46, 44)}[kind]
        c = shade(c, .85 + v * .3); s = 1 + var * .25
        pts = [(bx - 30 * s, by), (bx - 26 * s, by - 26 * s), (bx - 6 * s, by - 40 * s), (bx + 22 * s, by - 32 * s), (bx + 32 * s, by - 6 * s), (bx + 10 * s, by + 4)]
        pygame.draw.polygon(S, c, pts)
        pygame.draw.polygon(S, shade(c, 1.25), [(bx - 26 * s, by - 26 * s), (bx - 6 * s, by - 40 * s), (bx + 22 * s, by - 32 * s), (bx, by - 22 * s)])
        pygame.draw.polygon(S, shade(c, .7), [(bx, by - 22 * s), (bx + 22 * s, by - 32 * s), (bx + 32 * s, by - 6 * s), (bx + 10 * s, by + 4)])
        pygame.draw.line(S, shade(c, .5), (bx - 8 * s, by - 34 * s), (bx - 2 * s, by - 18 * s), 2)
        pygame.draw.line(S, shade(c, 1.4), (bx - 24 * s, by - 24 * s), (bx - 8 * s, by - 36 * s), 3)
        if kind == "rock":
            for (mx, my) in ((-20, -26), (-10, -34), (-2, -37), (6, -35)):
                pygame.draw.circle(S, (84, 130, 62), (int(bx + mx * s), int(by + my * s)), 5)
        if kind == "lavarock":
            pygame.draw.line(S, (255, 130, 40), (bx - 14 * s, by - 20 * s), (bx + 4 * s, by - 8 * s), 3)
            pygame.draw.line(S, (255, 180, 60), (bx + 4 * s, by - 8 * s), (bx + 18 * s, by - 18 * s), 2)
    elif kind == "mushroom":
        shadow(60, 18)
        cap = ((170, 50, 60), (140, 70, 160), (190, 90, 50))[var % 3]
        pygame.draw.rect(S, (220, 210, 190), (bx - 8, by - 60, 16, 60), border_radius=6)
        pygame.draw.ellipse(S, shade(cap, .75), (bx - 44, by - 96, 88, 50))
        pygame.draw.ellipse(S, cap, (bx - 42, by - 100, 84, 44))
        for (ox, oy) in ((-20, -84), (8, -90), (22, -78), (-4, -76)):
            pygame.draw.circle(S, (240, 236, 220), (bx + ox, by + oy), 5)
    elif kind == "reeds":
        for i in range(9):
            ox = (i - 4) * 6
            pygame.draw.line(S, (90, 110, 60), (bx + ox, by), (bx + ox + (i % 3 - 1) * 6, by - 50 - (i % 4) * 8), 3)
            if i % 3 == 0:
                pygame.draw.ellipse(S, (100, 70, 40), (bx + ox + (i % 3 - 1) * 6 - 3, by - 64 - (i % 4) * 8, 7, 18))
    elif kind == "tomb":
        shadow(44, 14)
        c = shade((120, 118, 128), .85 + v * .3)
        pygame.draw.rect(S, shade(c, .7), (bx - 14, by - 54, 30, 54), border_top_left_radius=14, border_top_right_radius=14)
        pygame.draw.rect(S, c, (bx - 16, by - 56, 28, 54), border_top_left_radius=14, border_top_right_radius=14)
        pygame.draw.line(S, shade(c, .6), (bx - 2, by - 46), (bx - 2, by - 22), 3)
        pygame.draw.line(S, shade(c, .6), (bx - 10, by - 38), (bx + 6, by - 38), 3)
    elif kind == "cactus":
        shadow(40, 14)
        g = (70, 140, 70)
        pygame.draw.rect(S, g, (bx - 9, by - 100, 18, 100), border_radius=9)
        pygame.draw.rect(S, g, (bx - 34, by - 70, 12, 34), border_radius=6)
        pygame.draw.rect(S, g, (bx - 34, by - 44, 30, 10), border_radius=5)
        pygame.draw.rect(S, g, (bx + 22, by - 84, 12, 34), border_radius=6)
        pygame.draw.rect(S, g, (bx + 4, by - 58, 30, 10), border_radius=5)
        pygame.draw.line(S, shade(g, 1.3), (bx - 3, by - 94), (bx - 3, by - 6), 2)
    elif kind == "bones":
        for (a, b) in (((-24, -4), (10, -10)), ((-6, -16), (20, 2))):
            pygame.draw.line(S, (230, 222, 200), (bx + a[0], by + a[1]), (bx + b[0], by + b[1]), 5)
        pygame.draw.circle(S, (230, 222, 200), (bx + 18, by - 14), 9)
        pygame.draw.circle(S, (60, 50, 40), (bx + 15, by - 15), 2)
    elif kind in ("crystal", "darkcrystal"):
        shadow(50, 16)
        c = (110, 200, 230) if kind == "crystal" else (160, 80, 220)
        c = shade(c, .85 + v * .25)
        for (ox, hh, w) in ((-14, 70, 12), (8, 100, 14), (24, 54, 10)):
            pygame.draw.polygon(S, shade(c, .7), [(bx + ox - w, by), (bx + ox, by - hh), (bx + ox, by + 4)])
            pygame.draw.polygon(S, c, [(bx + ox, by - hh), (bx + ox + w, by), (bx + ox, by + 4)])
            pygame.draw.line(S, shade(c, 1.5), (bx + ox, by - hh), (bx + ox + 2, by - hh * .4), 2)

    # ---- 0.20 additions: forest floor, ruins, camps and village props
    elif kind == "stump":
        shadow(54, 18)
        c = (112, 78, 48)
        pygame.draw.rect(S, shade(c, .7), (bx - 20, by - 38, 40, 40), border_radius=10)
        pygame.draw.rect(S, c, (bx - 20, by - 38, 26, 40), border_radius=10)
        pygame.draw.ellipse(S, shade(c, 1.15), (bx - 22, by - 52, 44, 24))
        for rr in (9, 5):
            pygame.draw.ellipse(S, shade(c, .8), (bx - rr, by - 42 - rr // 3, rr * 2, rr))
        pygame.draw.ellipse(S, shade(c, .6), (bx - 22, by - 52, 44, 24), 2)
        if var: pygame.draw.ellipse(S, (74, 134, 60), (bx - 18, by - 52, 16, 8))
    elif kind == "log":
        shadow(80, 18)
        c = (104, 72, 46)
        pygame.draw.rect(S, shade(c, .7), (bx - 40, by - 30, 80, 26), border_radius=12)
        pygame.draw.rect(S, c, (bx - 40, by - 30, 80, 17), border_radius=10)
        pygame.draw.ellipse(S, shade(c, 1.2), (bx + 28, by - 30, 16, 26)); pygame.draw.ellipse(S, shade(c, .7), (bx + 32, by - 24, 8, 14), 2)
        pygame.draw.line(S, shade(c, .55), (bx - 30, by - 20), (bx + 20, by - 22), 2)
        for i in range(4): pygame.draw.circle(S, (84, 132, 58), (bx - 30 + i * 12, by - 31), 4)
    elif kind == "fern":
        for i in range(9):
            a = -3.14 + (i + .5) / 9 * 3.14; ln = 34 + (i % 3) * 6
            ex, ey = bx + math.cos(a) * ln * .9, by + math.sin(a) * ln
            pygame.draw.line(S, (52, 120, 56), (bx, by), (ex, ey), 4)
            pygame.draw.line(S, (92, 168, 80), (bx, by - 2), (ex, ey - 2), 2)
    elif kind == "tallgrass":
        for i in range(16):
            ox = (h01(i, var, 5) - .5) * 70; hh = 30 + h01(i, var, 6) * 34
            pygame.draw.line(S, (96 + i * 3 % 40, 150, 64), (bx + ox, by), (bx + ox + (h01(i, var, 7) - .5) * 14, by - hh), 3)
            if i % 3 == 0: pygame.draw.ellipse(S, (226, 210, 130), (bx + ox - 2, by - hh - 8, 6, 12))
    elif kind == "dunegrass":
        for i in range(10):
            ox = (i - 5) * 6; hh = 28 + (i * 7) % 20
            pygame.draw.line(S, (190, 168, 98), (bx + ox, by), (bx + ox + (i % 3 - 1) * 9, by - hh), 3)
        pygame.draw.ellipse(S, (190, 160, 100, 120), (bx - 30, by - 4, 60, 10))
    elif kind == "boulders":
        shadow(100, 26)
        for (ox, oy, sc_, cc) in ((-24, -4, 1.0, (120, 118, 114)), (20, -2, .8, (138, 134, 128)), (0, -20, .9, (110, 108, 106))):
            c = shade(cc, .9 + v * .2)
            pts = [(bx + ox - 26 * sc_, by + oy), (bx + ox - 22 * sc_, by + oy - 24 * sc_), (bx + ox, by + oy - 34 * sc_), (bx + ox + 24 * sc_, by + oy - 26 * sc_), (bx + ox + 28 * sc_, by + oy - 4 * sc_), (bx + ox + 8 * sc_, by + oy + 3)]
            pygame.draw.polygon(S, c, pts)
            pygame.draw.polygon(S, shade(c, 1.25), [pts[1], pts[2], pts[3], (bx + ox, by + oy - 20 * sc_)])
            pygame.draw.polygon(S, shade(c, .68), [(bx + ox, by + oy - 20 * sc_), pts[3], pts[4], pts[5]])
            pygame.draw.line(S, shade(c, .5), pts[2], (bx + ox + 4, by + oy - 14 * sc_), 2)
        for i in range(5): pygame.draw.circle(S, (84, 130, 62), (bx - 30 + i * 8, by - 28 - (i % 2) * 6), 4)
    elif kind == "ruin":
        shadow(86, 24)
        c = shade((136, 132, 126), .9 + v * .2)
        pygame.draw.rect(S, shade(c, .7), (bx - 40, by - 12, 80, 14), border_radius=3)
        for (ox, hh) in ((-30, 90), (6, 60)):
            pygame.draw.rect(S, shade(c, .7), (bx + ox - 2, by - hh, 22, hh), border_radius=2)
            pygame.draw.rect(S, c, (bx + ox - 2, by - hh, 14, hh), border_radius=2)
            pygame.draw.polygon(S, shade(c, 1.2), [(bx + ox - 4, by - hh), (bx + ox + 6, by - hh - 8), (bx + ox + 22, by - hh + 2), (bx + ox + 18, by - hh + 8)])
            pygame.draw.line(S, shade(c, .5), (bx + ox + 4, by - hh * .8), (bx + ox + 10, by - hh * .5), 2)
        pygame.draw.polygon(S, shade(c, .85), [(bx - 18, by - 74), (bx + 6, by - 52), (bx + 4, by - 40), (bx - 18, by - 58)])
        for i in range(4):
            pygame.draw.line(S, (58, 120, 56), (bx - 30 + i * 4, by - 22 - i * 10), (bx - 22 + i * 4, by - 4 - i * 4), 3)
        pygame.draw.polygon(S, shade(c, .8), [(bx + 26, by), (bx + 40, by - 18), (bx + 50, by - 6), (bx + 40, by + 2)])
    elif kind == "haystack":
        shadow(70, 20)
        pygame.draw.ellipse(S, (156, 120, 50), (bx - 34, by - 62, 68, 70)); pygame.draw.rect(S, (156, 120, 50), (bx - 34, by - 34, 68, 36))
        pygame.draw.ellipse(S, (214, 176, 80), (bx - 34, by - 62, 52, 62))
        for i in range(7): pygame.draw.line(S, (186, 148, 62), (bx - 24 + i * 8, by - 48 + abs(i - 3) * 6), (bx - 20 + i * 8, by - 4), 2)
        pygame.draw.line(S, (110, 76, 40), (bx - 34, by - 26), (bx + 34, by - 26), 3)
    elif kind == "glowshroom":
        for (ox, hh, w) in ((-18, 40, 14), (4, 56, 18), (22, 34, 12), (-4, 26, 10)):
            pygame.draw.rect(S, (180, 220, 220), (bx + ox - 3, by - hh, 6, hh))
            pygame.draw.ellipse(S, (40, 150, 170), (bx + ox - w, by - hh - w // 2, w * 2, w + 4))
            pygame.draw.ellipse(S, (120, 240, 230), (bx + ox - w + 3, by - hh - w // 2, w * 2 - 8, w - 2))
            pygame.draw.circle(S, (230, 255, 250), (bx + ox - 2, by - hh - 2), 2)
    elif kind == "iceshard":
        shadow(60, 18)
        for (ox, hh, w) in ((-16, 76, 12), (6, 110, 15), (24, 58, 10)):
            pygame.draw.polygon(S, (120, 170, 214), [(bx + ox - w, by), (bx + ox, by - hh), (bx + ox + 2, by + 4)])
            pygame.draw.polygon(S, (200, 232, 250), [(bx + ox, by - hh), (bx + ox + w, by), (bx + ox + 2, by + 4)])
            pygame.draw.line(S, (255, 255, 255), (bx + ox, by - hh), (bx + ox + 2, by - hh * .45), 2)
    elif kind == "ribs":
        shadow(100, 24)
        pygame.draw.line(S, (226, 218, 194), (bx - 50, by - 8), (bx + 50, by - 8), 8)
        for i in range(6):
            ox = -40 + i * 16; hh = 60 - abs(i - 2.5) * 8
            pygame.draw.arc(S, (226, 218, 194), (bx + ox - 12, by - hh - 8, 28, hh * 1.6), 0, 3.14, 6)
    elif kind == "vent":
        shadow(70, 22)
        pygame.draw.ellipse(S, (46, 36, 34), (bx - 34, by - 30, 68, 36)); pygame.draw.ellipse(S, (80, 60, 52), (bx - 34, by - 34, 68, 30))
        pygame.draw.ellipse(S, (36, 22, 20), (bx - 18, by - 32, 36, 16)); pygame.draw.ellipse(S, (255, 120, 40), (bx - 12, by - 29, 24, 10))
        pygame.draw.ellipse(S, (255, 210, 100), (bx - 6, by - 28, 12, 5))
        for i in range(3): pygame.draw.circle(S, (150, 140, 138, 120), (bx + (i - 1) * 8, by - 50 - i * 12), 7 - i)
    elif kind == "signpost":
        shadow(30, 12)
        pygame.draw.rect(S, (92, 66, 42), (bx - 4, by - 100, 8, 100))
        for (yy, w, d) in ((-92, 44, 1), (-72, 38, -1)):
            pts = [(bx, by + yy), (bx + d * w, by + yy), (bx + d * (w + 8), by + yy + 8), (bx + d * w, by + yy + 16), (bx, by + yy + 16)]
            pygame.draw.polygon(S, (150, 112, 70), pts); pygame.draw.polygon(S, (86, 62, 40), pts, 2)
            pygame.draw.line(S, (86, 62, 40), (bx + d * 6, by + yy + 8), (bx + d * (w - 6), by + yy + 8), 2)
    elif kind == "tent":
        shadow(90, 24)
        col = ((178, 70, 56), (66, 112, 168), (190, 160, 90))[var % 3]
        pygame.draw.polygon(S, shade(col, .7), [(bx - 44, by), (bx, by - 80), (bx, by + 8)])
        pygame.draw.polygon(S, col, [(bx, by - 80), (bx + 46, by), (bx, by + 8)])
        pygame.draw.polygon(S, (36, 26, 20), [(bx - 8, by + 4), (bx, by - 32), (bx + 12, by + 2)])
        pygame.draw.line(S, (230, 220, 200), (bx, by - 80), (bx, by + 8), 2)
        pygame.draw.line(S, (92, 66, 42), (bx, by - 80), (bx, by - 98), 3); pygame.draw.polygon(S, shade(col, 1.2), [(bx, by - 98), (bx + 16, by - 92), (bx, by - 86)])
    elif kind == "campfire":
        shadow(56, 18)
        for i in range(8):
            a = i / 8 * 6.28
            pygame.draw.ellipse(S, shade((120, 116, 110), .8 + (i % 3) * .15), (bx + math.cos(a) * 22 - 6, by - 6 + math.sin(a) * 9 - 4, 13, 9))
        pygame.draw.line(S, (96, 66, 40), (bx - 16, by - 4), (bx + 14, by - 14), 6); pygame.draw.line(S, (110, 76, 46), (bx + 16, by - 4), (bx - 14, by - 14), 6)
        pygame.draw.polygon(S, (255, 140, 30), [(bx - 12, by - 12), (bx - 3, by - 42), (bx + 2, by - 28), (bx + 8, by - 46), (bx + 14, by - 12)])
        pygame.draw.polygon(S, (255, 220, 110), [(bx - 5, by - 12), (bx, by - 30), (bx + 7, by - 12)])
    elif kind == "menhir":
        shadow(50, 16)
        c = (118, 120, 132)
        pygame.draw.polygon(S, shade(c, .7), [(bx - 18, by), (bx - 14, by - 90), (bx + 2, by - 108), (bx + 2, by + 4)])
        pygame.draw.polygon(S, c, [(bx + 2, by - 108), (bx + 20, by - 84), (bx + 22, by - 4), (bx + 2, by + 4)])
        for i in range(3):
            pygame.draw.line(S, (110, 190, 230), (bx + 8, by - 76 + i * 18), (bx + 16, by - 70 + i * 18), 2)
    elif kind == "well":
        shadow(70, 22)
        c = (150, 144, 134)
        pygame.draw.ellipse(S, shade(c, .7), (bx - 30, by - 30, 60, 34)); pygame.draw.rect(S, shade(c, .8), (bx - 30, by - 28, 60, 14))
        pygame.draw.rect(S, c, (bx - 30, by - 28, 36, 14)); pygame.draw.ellipse(S, shade(c, 1.2), (bx - 30, by - 42, 60, 30))
        pygame.draw.ellipse(S, (24, 50, 74), (bx - 20, by - 38, 40, 20)); pygame.draw.ellipse(S, (70, 130, 170), (bx - 14, by - 35, 20, 7))
        for sx_ in (-28, 28): pygame.draw.rect(S, (92, 66, 42), (bx + sx_ - 3, by - 90, 6, 62))
        pygame.draw.polygon(S, (130, 70, 50), [(bx - 40, by - 88), (bx, by - 112), (bx + 40, by - 88), (bx, by - 78)])
        pygame.draw.polygon(S, (170, 96, 66), [(bx - 40, by - 88), (bx, by - 112), (bx, by - 78)])
        pygame.draw.line(S, (200, 190, 160), (bx, by - 80), (bx, by - 52), 2); pygame.draw.rect(S, (110, 76, 46), (bx - 5, by - 52, 10, 10))
    elif kind == "fence":
        L = 2 * HTW; Hh = 2 * HTH
        a0 = (bx - L / 2, by - Hh / 2) if var % 2 == 0 else (bx + L / 2, by - Hh / 2)
        a1 = (bx + L / 2, by + Hh / 2) if var % 2 == 0 else (bx - L / 2, by + Hh / 2)
        for t in (0, .5, 1):
            px_ = a0[0] + (a1[0] - a0[0]) * t; py_ = a0[1] + (a1[1] - a0[1]) * t
            pygame.draw.rect(S, (92, 66, 42), (px_ - 3, py_ - 36, 6, 38)); pygame.draw.rect(S, (140, 104, 66), (px_ - 3, py_ - 36, 3, 38))
        for hh in (-28, -16):
            pygame.draw.line(S, (150, 112, 70), (a0[0], a0[1] + hh), (a1[0], a1[1] + hh), 4)
            pygame.draw.line(S, (92, 66, 42), (a0[0], a0[1] + hh + 3), (a1[0], a1[1] + hh + 3), 1)
    elif kind == "planter":
        shadow(54, 16)
        pygame.draw.rect(S, (110, 76, 46), (bx - 26, by - 22, 52, 22), border_radius=3); pygame.draw.rect(S, (146, 104, 64), (bx - 26, by - 22, 20, 22), border_radius=3)
        pygame.draw.ellipse(S, (60, 44, 30), (bx - 26, by - 28, 52, 14))
        for i in range(7):
            ox = -20 + i * 7; col = ((238, 90, 100), (250, 214, 90), (200, 130, 240), (255, 255, 255))[(i + var) % 4]
            pygame.draw.line(S, (54, 112, 54), (bx + ox, by - 20), (bx + ox, by - 36 - i % 3 * 5), 2); pygame.draw.circle(S, col, (bx + ox, by - 38 - i % 3 * 5), 4)
    elif kind == "bench":
        shadow(70, 18)
        pygame.draw.rect(S, (98, 70, 44), (bx - 34, by - 18, 8, 18)); pygame.draw.rect(S, (98, 70, 44), (bx + 26, by - 18, 8, 18))
        pygame.draw.polygon(S, (150, 110, 68), [(bx - 40, by - 24), (bx - 30, by - 30), (bx + 40, by - 30), (bx + 30, by - 24)])
        pygame.draw.polygon(S, (112, 80, 50), [(bx - 40, by - 24), (bx + 30, by - 24), (bx + 30, by - 18), (bx - 40, by - 18)])
        pygame.draw.rect(S, (112, 80, 50), (bx - 38, by - 50, 76, 10), border_radius=3)
    elif kind == "cart":
        shadow(90, 24)
        pygame.draw.polygon(S, (126, 88, 52), [(bx - 40, by - 20), (bx + 36, by - 20), (bx + 28, by - 52), (bx - 32, by - 52)])
        pygame.draw.polygon(S, (92, 64, 40), [(bx - 40, by - 20), (bx + 36, by - 20), (bx + 36, by - 12), (bx - 40, by - 12)])
        pygame.draw.circle(S, (70, 50, 34), (bx - 20, by - 8), 16); pygame.draw.circle(S, (150, 112, 70), (bx - 20, by - 8), 16, 3); pygame.draw.circle(S, (150, 112, 70), (bx - 20, by - 8), 4)
        pygame.draw.line(S, (92, 64, 40), (bx + 36, by - 16), (bx + 66, by - 4), 4)
        for i in range(4): pygame.draw.circle(S, ((200, 60, 50), (230, 180, 60), (110, 170, 70))[i % 3], (bx - 24 + i * 14, by - 56), 8)
    elif kind == "banner":
        shadow(30, 12)
        pygame.draw.rect(S, (88, 62, 40), (bx - 3, by - 130, 6, 130)); pygame.draw.rect(S, (88, 62, 40), (bx - 22, by - 130, 44, 5))
        col = ((60, 110, 210), (200, 50, 40), (210, 180, 70))[var % 3]
        pygame.draw.polygon(S, col, [(bx - 18, by - 125), (bx + 18, by - 125), (bx + 18, by - 66), (bx, by - 80), (bx - 18, by - 66)])
        pygame.draw.polygon(S, shade(col, 1.25), [(bx - 18, by - 125), (bx - 4, by - 125), (bx - 4, by - 76), (bx - 18, by - 66)])
        pygame.draw.circle(S, (240, 220, 140), (bx, by - 104), 6, 2)
    elif kind == "pebbles":
        for (ox, oy, w, cc) in ((-14, -2, 14, (132, 128, 122)), (6, 0, 10, (150, 146, 138)), (-2, -8, 8, (110, 108, 104)), (16, -6, 7, (126, 122, 116))):
            pygame.draw.ellipse(S, shade(cc, .6), (bx + ox - w // 2, by + oy - w // 3 + 2, w, w * .62)); pygame.draw.ellipse(S, cc, (bx + ox - w // 2, by + oy - w // 3, w, w * .62))
            pygame.draw.line(S, shade(cc, 1.3), (bx + ox - w // 3, by + oy - w // 3 + 1), (bx + ox + w // 6, by + oy - w // 3 + 1), 1)
    elif kind == "woodpile":
        shadow(60, 18)
        for row in range(3):
            for i in range(4 - row):
                pygame.draw.ellipse(S, (120, 82, 50), (bx - 26 + i * 14 + row * 7, by - 16 - row * 12, 15, 14))
                pygame.draw.ellipse(S, (190, 150, 96), (bx - 24 + i * 14 + row * 7, by - 14 - row * 12, 9, 9))
    sc = .62 if kind in ("pine", "snowpine", "oak", "palm", "dead", "mushroom", "willow") else .5
    spr = outline(_finish(S, sc), (20, 26, 14, 70))
    _DECOR[key] = (spr, (spr.get_width() // 2, int(by * sc) + 1))
    return _DECOR[key]

# ------------------------------------------------------------ buildings
STYLE = {
 "Alliance": dict(wall=(196, 186, 166), roof=(60, 92, 160), trim=(120, 110, 96), flag=(60, 110, 210)),
 "Horde":    dict(wall=(132, 92, 60),   roof=(152, 50, 40),  trim=(80, 54, 36),   flag=(200, 50, 40)),
 "Neutral":  dict(wall=(206, 194, 164), roof=(116, 76, 48),  trim=(120, 96, 70),  flag=(210, 180, 70)),
}
_BUILD = {}
def _building_raw(kind, style, var=0):
    pump()
    key = (kind, style, var)
    if key in _BUILD:
        return _BUILD[key]
    st = STYLE.get(style, STYLE["Neutral"])
    wall = shade(st["wall"], .92 + var * .05); roof = shade(st["roof"], .9 + var * .08)
    if kind in STATION_KINDS:
        _BUILD[key] = co_station(kind, style)
        return _BUILD[key]
    if kind in ("house", "tower") and CO_STYLE:
        _BUILD[key] = co_building(kind, style, var)
        return _BUILD[key]
    if kind == "fountain" and CO_STYLE:
        spr, anc = co_fountain(); _BUILD[key] = (spr, anc, 1, 1)
        return _BUILD[key]
    if kind in ("house", "tower"):
        w = d = 2.0 if kind == "house" else 1.4
        hgt = 46 + var * 8 if kind == "house" else 96
        roofh = 42 if kind == "house" else 60
        mg = 10 if kind == "house" else 60
        Wd = int((w + d) * HTW) + 20 + 40; Hd = int((w + d) * HTH + hgt + roofh) + 20 + mg
        S = pygame.Surface((Wd * 2, Hd * 2), pygame.SRCALPHA)
        k = 2
        ox, oy = (d * HTW + 10) * k, (hgt + roofh + mg) * k
        T = (ox, oy); R = (ox + w * HTW * k, oy + w * HTH * k)
        B = (ox + (w - d) * HTW * k, oy + (w + d) * HTH * k); L = (ox - d * HTW * k, oy + d * HTH * k)
        up = lambda p, hh: (p[0], p[1] - hh * k)
        pygame.draw.ellipse(S, (0, 0, 0, 60), (L[0] - 10, T[1] + 10, R[0] - L[0] + 40, B[1] - T[1] + 10))
        # walls
        pygame.draw.polygon(S, shade(wall, .78), [L, B, up(B, hgt), up(L, hgt)])
        pygame.draw.polygon(S, wall, [B, R, up(R, hgt), up(B, hgt)])
        # stone courses: staggered blocks on both wall faces
        nrow = 9 if kind == "house" else 18
        for (P, Q, dk) in ((L, B, .62), (B, R, .72)):
            for r_ in range(1, nrow):
                f_ = r_ / nrow
                pygame.draw.line(S, shade(wall, dk), up(P, hgt * f_), up(Q, hgt * f_), 1)
                for j in range(1, 6):
                    t_ = (j + (.5 if r_ % 2 else 0)) / 6
                    if t_ >= 1: continue
                    x_ = P[0] + (Q[0] - P[0]) * t_; y_ = P[1] + (Q[1] - P[1]) * t_
                    pygame.draw.line(S, shade(wall, dk), (x_, y_ - hgt * f_ * k), (x_, y_ - hgt * (f_ - 1 / nrow) * k), 1)
        # timber / stone lines
        for f in (.33, .66):
            pygame.draw.line(S, shade(st["trim"], .9), up(L, hgt * f), up(B, hgt * f), 3)
            pygame.draw.line(S, shade(st["trim"], 1.0), up(B, hgt * f), up(R, hgt * f), 3)
        pygame.draw.line(S, st["trim"], B, up(B, hgt), 5)
        # door on right wall, window on left wall
        def onwall(P, Q, t, hh):
            return (P[0] + (Q[0] - P[0]) * t, P[1] + (Q[1] - P[1]) * t - hh * k)
        if kind == "house":
            dpts = [onwall(B, R, .4, 0), onwall(B, R, .62, 0), onwall(B, R, .62, 26), onwall(B, R, .4, 26)]
            fr = [onwall(B, R, .37, 0), onwall(B, R, .65, 0), onwall(B, R, .65, 29), onwall(B, R, .37, 29)]
            pygame.draw.polygon(S, shade(st["trim"], .8), fr)
            pygame.draw.polygon(S, (86, 54, 32), dpts)
            pygame.draw.line(S, (50, 30, 18), onwall(B, R, .51, 0), onwall(B, R, .51, 26), 2)
            q = onwall(B, R, .58, 12); pygame.draw.circle(S, (240, 200, 90), (int(q[0]), int(q[1])), 3)
            for t in (.3, .65):
                wp = [onwall(L, B, t, 20), onwall(L, B, t + .18, 20), onwall(L, B, t + .18, 34), onwall(L, B, t, 34)]
                pygame.draw.polygon(S, (255, 220, 130), wp); pygame.draw.polygon(S, st["trim"], wp, 3)
                pygame.draw.line(S, st["trim"], onwall(L, B, t + .09, 20), onwall(L, B, t + .09, 34), 2)
                pygame.draw.line(S, st["trim"], onwall(L, B, t, 27), onwall(L, B, t + .18, 27), 2)
                pygame.draw.line(S, shade(st["trim"], .5), onwall(L, B, t, 20), onwall(L, B, t + .18, 20), 4)
        else:
            for hh in (30, 60):
                wp = [onwall(B, R, .4, hh), onwall(B, R, .6, hh), onwall(B, R, .6, hh + 14), onwall(B, R, .4, hh + 14)]
                pygame.draw.polygon(S, (255, 214, 120), wp)
        # roof
        ov = 8 * k
        Tr = (T[0], up(T, hgt)[1] - ov * .5); Rr = (R[0] + ov, up(R, hgt)[1]); Br = (B[0], up(B, hgt)[1] + ov * .6); Lr = (L[0] - ov, up(L, hgt)[1])
        apex = ((Lr[0] + Rr[0]) / 2, (Tr[1] + Br[1]) / 2 - roofh * k)
        pygame.draw.polygon(S, shade(roof, .7), [Lr, Br, apex])
        pygame.draw.polygon(S, roof, [Br, Rr, apex])
        pygame.draw.polygon(S, shade(roof, .55), [Tr, Lr, apex])
        nb = 7
        for i in range(nb):
            t0 = i / nb
            for (A, Bv, dk) in ((Lr, Br, .72), (Br, Rr, 1.0)):
                p0 = (A[0] + (apex[0] - A[0]) * t0, A[1] + (apex[1] - A[1]) * t0); q0 = (Bv[0] + (apex[0] - Bv[0]) * t0, Bv[1] + (apex[1] - Bv[1]) * t0)
                pygame.draw.line(S, shade(roof, dk * .6), p0, q0, 3)
                pygame.draw.line(S, shade(roof, dk * 1.22), (p0[0], p0[1] + 3), (q0[0], q0[1] + 3), 2)
                n_ = 6 - i
                for j in range(1, n_):
                    f_ = j / n_ + (.5 / n_ if i % 2 else 0)
                    if f_ >= 1: continue
                    a_ = (p0[0] + (q0[0] - p0[0]) * f_, p0[1] + (q0[1] - p0[1]) * f_)
                    pygame.draw.line(S, shade(roof, dk * .62), a_, (a_[0], a_[1] + 12), 1)
        pygame.draw.line(S, shade(roof, 1.35), Br, apex, 4)
        pygame.draw.line(S, shade(roof, .4), Lr, Br, 4); pygame.draw.line(S, shade(roof, .45), Br, Rr, 4)
        if kind == "house":
            cx_ = apex[0] + 26 * k; cy_ = apex[1] + 16 * k
            pygame.draw.rect(S, (110, 100, 92), (cx_ - 7 * k, cy_ - 22 * k, 14 * k, 26 * k))
            pygame.draw.rect(S, (70, 62, 58), (cx_ - 9 * k, cy_ - 24 * k, 18 * k, 5 * k))
        if kind == "tower":
            pygame.draw.line(S, (60, 50, 40), apex, (apex[0], apex[1] - 40 * k), 4)
            pygame.draw.polygon(S, st["flag"], [(apex[0], apex[1] - 40 * k), (apex[0] + 30 * k, apex[1] - 33 * k), (apex[0], apex[1] - 26 * k)])
        spr = _finish(S)
        anchor = (int(T[0] / 2), int(T[1] / 2))   # world point (bx,by) → top vertex of footprint
        _BUILD[key] = (spr, anchor, w, d)
    elif kind == "fountain":
        S = pygame.Surface((200, 140), pygame.SRCALPHA)
        c = (150, 146, 140)
        pygame.draw.ellipse(S, (0, 0, 0, 60), (10, 60, 180, 70))
        pygame.draw.ellipse(S, shade(c, .7), (16, 50, 168, 76))
        pygame.draw.ellipse(S, c, (16, 40, 168, 76))
        pygame.draw.ellipse(S, (70, 130, 200), (32, 50, 136, 54))
        pygame.draw.rect(S, c, (90, 14, 20, 52))
        pygame.draw.ellipse(S, shade(c, 1.1), (76, 8, 48, 18))
        for i in range(6):
            pygame.draw.line(S, (170, 210, 255), (100, 12), (100 + (i - 2.5) * 14, 50), 2)
        spr = _finish(S)
        _BUILD[key] = (spr, (50, 40), 1, 1)
    else:
        raise ValueError(f"unknown building kind {kind!r}")
    return _BUILD[key]

def _wall_raw(post=False, style="Neutral"):
    pump()
    key = ("wall", post, style)
    if key in _BUILD:
        return _BUILD[key]
    if CO_STYLE and style != "Dungeon":           # 0.45: medieval curtain wall (straight run when no neighbours are known)
        from . import medieval
        _BUILD[key] = medieval.curtain_wall(style, 5, post)
        return _BUILD[key]
    k = 2; hgt = 58 if post else 36
    S = pygame.Surface((TW * k + 4, (TH + hgt + 16) * k), pygame.SRCALPHA)
    base = {"Alliance": (176, 170, 160), "Horde": (150, 120, 96), "Neutral": (168, 158, 140), "Dungeon": (92, 88, 104)}.get(style, (168, 158, 140))
    T = (HTW * k + 2, (hgt + 12) * k); R = (T[0] + HTW * k, T[1] + HTH * k); B = (T[0], T[1] + TH * k); L = (T[0] - HTW * k, T[1] + HTH * k)
    up = lambda p: (p[0], p[1] - hgt * k)
    pygame.draw.polygon(S, shade(base, .7), [L, B, up(B), up(L)])
    pygame.draw.polygon(S, base, [B, R, up(R), up(B)])
    pygame.draw.polygon(S, shade(base, 1.18), [up(T), up(R), up(B), up(L)])
    for row in range(1, hgt // 9):
        yy = row * 9 * k
        pygame.draw.line(S, shade(base, .55), (L[0], L[1] - yy), (B[0], B[1] - yy), 2)
        pygame.draw.line(S, shade(base, .7), (B[0], B[1] - yy), (R[0], R[1] - yy), 2)
        off = .25 if row % 2 else .6
        for P, Q, c in ((L, B, .55), (B, R, .7)):
            mx = P[0] + (Q[0] - P[0]) * off; my = P[1] + (Q[1] - P[1]) * off
            pygame.draw.line(S, shade(base, c), (mx, my - yy), (mx, my - yy + 9 * k), 2)
    # crenellations
    for i in range(4):
        f = (i + .5) / 4
        px = up(L)[0] + (up(R)[0] - up(L)[0]) * f
        py = up(L)[1] + (up(R)[1] - up(L)[1]) * f - (abs(f - .5) < .3) * 0
        pygame.draw.rect(S, shade(base, 1.05), (px - 5 * k, py - 8 * k + (HTH * k if f < .5 else 0) * (0), 10 * k, 8 * k))
    if post:
        pygame.draw.polygon(S, shade(base, .5), [(up(L)[0] - 4, up(L)[1]), (up(T)[0], up(T)[1] - 22 * k), (up(R)[0] + 4, up(R)[1]), (up(B)[0], up(B)[1] + 4)])
        pygame.draw.polygon(S, shade(base, .38), [(up(L)[0] - 4, up(L)[1]), (up(T)[0], up(T)[1] - 22 * k), (up(B)[0], up(B)[1] + 4)])
    spr = _finish(S)
    _BUILD[key] = (spr, (spr.get_width() // 2, int(T[1] / 2)))
    return _BUILD[key]

def prop_sprite(kind, var=0):
    key = ("prop", kind, var)
    if key in _BUILD:
        return _BUILD[key]
    if kind in DECOR_PROPS:
        return decor_sprite(kind, var)
    if kind == "lamp" and CO_STYLE:
        _BUILD[key] = co_lamp()
        return _BUILD[key]
    if kind in ("barrel", "crate", "brazier"):    # 0.45: redrawn at believable sizes (props45)
        from . import props45
        _BUILD[key] = getattr(props45, kind)(var)
        return _BUILD[key]
    S = pygame.Surface((80, 160), pygame.SRCALPHA); bx, by = 40, 150
    if kind == "lamp":
        pygame.draw.ellipse(S, (0, 0, 0, 70), (bx - 14, by - 6, 28, 12))
        pygame.draw.rect(S, (50, 44, 40), (bx - 4, by - 110, 8, 110))
        pygame.draw.rect(S, (70, 62, 56), (bx - 10, by - 8, 20, 8))
        pygame.draw.polygon(S, (60, 52, 44), [(bx - 12, by - 112), (bx + 12, by - 112), (bx + 8, by - 136), (bx - 8, by - 136)])
        pygame.draw.polygon(S, (255, 214, 120), [(bx - 8, by - 114), (bx + 8, by - 114), (bx + 6, by - 132), (bx - 6, by - 132)])
        pygame.draw.polygon(S, (60, 52, 44), [(bx - 14, by - 136), (bx + 14, by - 136), (bx, by - 148)])
    elif kind == "portal":
        pygame.draw.ellipse(S, (0, 0, 0, 80), (bx - 30, by - 10, 60, 20))
        for px_ in (-24, 24):
            pygame.draw.rect(S, (110, 106, 124), (bx + px_ - 7, by - 90, 14, 84))
            pygame.draw.rect(S, (150, 146, 164), (bx + px_ - 7, by - 90, 5, 84))
        pygame.draw.arc(S, (120, 116, 136), (bx - 28, by - 118, 56, 56), 0, 3.14, 10)
        pygame.draw.ellipse(S, (70, 40, 140), (bx - 20, by - 96, 40, 88))
        pygame.draw.ellipse(S, (130, 90, 230), (bx - 14, by - 86, 28, 70))
        pygame.draw.ellipse(S, (230, 210, 255), (bx - 7, by - 72, 14, 40))
    else:
        pygame.draw.ellipse(S, (0, 0, 0, 70), (bx - 22, by - 8, 44, 14))
        c = shade((160, 120, 70), .9 + var * .06)
        pygame.draw.polygon(S, shade(c, .75), [(bx - 22, by - 10), (bx, by), (bx, by - 30), (bx - 22, by - 40)])
        pygame.draw.polygon(S, c, [(bx, by), (bx + 22, by - 10), (bx + 22, by - 40), (bx, by - 30)])
        pygame.draw.polygon(S, shade(c, 1.2), [(bx - 22, by - 40), (bx, by - 30), (bx + 22, by - 40), (bx, by - 50)])
        pygame.draw.line(S, shade(c, .5), (bx + 2, by - 3), (bx + 20, by - 37), 2)
        pygame.draw.line(S, shade(c, .5), (bx - 2, by - 3), (bx - 20, by - 37), 2)
    scl = locals().get("sc_", .5)
    spr = outline(_finish(S, scl), (20, 16, 12, 80 if scl == .5 else 55))      # 0.45: soft edge, not a black clip-art line
    _BUILD[key] = (spr, (spr.get_width() // 2, int(by * scl) + 1))
    return _BUILD[key]

_PORTAL = {}
def _torch(S, x, y, r):
    pygame.draw.line(S, (60, 42, 28), (x, y), (x, y - 70), 8); pygame.draw.line(S, (130, 94, 56), (x - 2, y - 2), (x - 2, y - 68), 3)
    pygame.draw.rect(S, (60, 56, 56), (x - 9, y - 80, 18, 12), border_radius=3)
    g = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    for rr, aa in ((60, 20), (40, 36), (24, 54)): pygame.draw.circle(g, (255, 150, 50, aa), (x, y - 100), rr)
    S.blit(g, (0, 0))
    pygame.draw.polygon(S, (240, 110, 30), [(x - 12, y - 82), (x - 3, y - 104), (x + 2, y - 128), (x + 8, y - 106), (x + 14, y - 82)])
    pygame.draw.polygon(S, (255, 226, 130), [(x - 6, y - 82), (x, y - 118), (x + 7, y - 82)])

def _swirl(S, cx, cy, rx, ry, col, r):
    for i in range(14):
        f = i / 13
        c = mix(shade(col, .35), (255, 255, 255), f * .85) if f > .8 else shade(col, .35 + f * 1.15)
        pygame.draw.ellipse(S, c, (cx - rx * (1 - f * .92), cy - ry * (1 - f * .92), rx * 2 * (1 - f * .92), ry * 2 * (1 - f * .92)))
    for k in range(5):
        a0 = k * 1.26 + .3
        pts = [(cx + math.cos(a0 + t * 2.4) * rx * (.9 - t * .75), cy + math.sin(a0 + t * 2.4) * ry * (.9 - t * .75)) for t in [i / 12 for i in range(13)]]
        pygame.draw.lines(S, (240, 232, 255), False, pts, 3); pygame.draw.lines(S, shade(col, 1.5), False, [(p[0] + 2, p[1]) for p in pts], 2)

def dungeon_sprite(kind):
    if kind in _PORTAL:
        return _PORTAL[kind]
    r = _rnd_mod.Random(f"portal:{kind}")
    if kind in ("raid", "heroic"):
        S = pygame.Surface((520, 600), pygame.SRCALPHA); bx, by = 260, 560
        heroic = kind == "heroic"
        glow = (230, 60, 40) if heroic else (150, 90, 240)
        stone = (110, 106, 118)
        _soft_shadow(S, bx, by - 10, 460, 100, 130)
        # rune circle on the ground
        rg = pygame.Surface(S.get_size(), pygame.SRCALPHA)
        pygame.draw.ellipse(rg, (*glow, 90), (bx - 210, by - 70, 420, 110), 6); pygame.draw.ellipse(rg, (*glow, 60), (bx - 170, by - 56, 340, 84), 3)
        for k in range(12):
            a = k / 12 * math.tau; pygame.draw.circle(rg, (*glow, 160), (int(bx + math.cos(a) * 190), int(by - 14 + math.sin(a) * 50)), 4)
        S.blit(rg, (0, 0))
        _shp(S, [(bx - 220, by - 10), (bx - 200, by - 50), (bx + 200, by - 50), (bx + 220, by - 10), (bx + 180, by + 14), (bx - 180, by + 14)], shade(stone, .8), True, lo=.6)
        # portal fill
        gl = pygame.Surface(S.get_size(), pygame.SRCALPHA)
        for rr, aa in ((220, 20), (170, 34)): pygame.draw.circle(gl, (*glow, aa), (bx, by - 200), rr)
        S.blit(gl, (0, 0))
        _swirl(S, bx, by - 200, 112, 150, glow, r)
        # pillars with capitals and carved bands
        for sg in (-1, 1):
            x = bx + sg * 138
            _shp(S, [(x - 36, by - 40), (x - 32, by - 340), (x + 32, by - 340), (x + 36, by - 40)], stone, True, lo=.45, spec_x=.22)
            for yy in (-90, -170, -250):
                pygame.draw.line(S, shade(stone, .4), (x - 34, by + yy), (x + 34, by + yy), 4); pygame.draw.line(S, shade(stone, 1.35), (x - 34, by + yy - 3), (x + 34, by + yy - 3), 2)
                pygame.draw.lines(S, (*glow, ), False, [(x - 14, by + yy + 22), (x - 4, by + yy + 10), (x + 6, by + yy + 24), (x + 16, by + yy + 12)], 3)
            _shp(S, [(x - 48, by - 340), (x + 48, by - 340), (x + 40, by - 366), (x - 40, by - 366)], shade(stone, 1.1), True, lo=.5)
            _shp(S, [(x - 44, by - 40), (x + 44, by - 40), (x + 50, by - 14), (x - 50, by - 14)], shade(stone, .9), True, lo=.5)
        # arch lintel with keystone
        _shp(S, [(bx - 188, by - 366), (bx - 150, by - 440), (bx, by - 480), (bx + 150, by - 440), (bx + 188, by - 366), (bx + 120, by - 370), (bx, by - 400), (bx - 120, by - 370)], shade(stone, 1.05), True, lo=.5, spec_x=.3)
        _shp(S, [(bx - 28, by - 404), (bx + 28, by - 404), (bx + 22, by - 484), (bx - 22, by - 484)], shade(stone, 1.25), True, lo=.6)
        pygame.draw.circle(S, glow, (bx, by - 438), 14); pygame.draw.circle(S, (255, 255, 255), (bx - 3, by - 441), 4)
        for sg in (-1, 1): _torch(S, bx + sg * 214, by - 6, r)
        sc = .25
    else:
        S = pygame.Surface((480, 440), pygame.SRCALPHA); bx, by = 240, 400
        _soft_shadow(S, bx, by - 6, 420, 80, 130)
        rock = (104, 100, 98)
        for (ox, oy, rx, ry) in ((-130, 0, 130, 140), (130, 0, 130, 130), (0, -40, 150, 200), (-60, -90, 110, 150), (70, -80, 100, 140)):
            _rock_shape(S, bx + ox, by + oy, rx, ry, shade(rock, r.uniform(.85, 1.15)), r)
        # cave mouth: dark, graded, with a stone frame and steps
        pygame.draw.ellipse(S, (10, 6, 14), (bx - 78, by - 230, 156, 250)); pygame.draw.rect(S, (10, 6, 14), (bx - 78, by - 120, 156, 120))
        for i in range(7):
            pygame.draw.ellipse(S, (24 + i * 6, 14 + i * 3, 30 + i * 7), (bx - 70 + i * 4, by - 214 + i * 6, 140 - i * 8, 230 - i * 6))
        pygame.draw.ellipse(S, (10, 6, 14), (bx - 54, by - 190, 108, 210))
        for sg in (-1, 1): _shp(S, [(bx + sg * 70, by), (bx + sg * 82, by - 150), (bx + sg * 70, by - 230), (bx + sg * 50, by - 232), (bx + sg * 56, by - 150), (bx + sg * 50, by)], shade(rock, 1.15), True, lo=.5)
        _shp(S, [(bx - 90, by - 196), (bx, by - 262), (bx + 90, by - 196), (bx + 70, by - 190), (bx, by - 240), (bx - 70, by - 190)], shade(rock, 1.2), True, lo=.5)
        for i in range(5): _shp(S, [(bx - 60 + i * 4, by - i * 8 + 2), (bx + 60 - i * 4, by - i * 8 + 2), (bx + 58 - i * 4, by - i * 8 - 6), (bx - 58 + i * 4, by - i * 8 - 6)], shade(rock, 1.0 - i * .06), lo=.7)
        _sphere(S, (bx, by - 266), 20, (226, 220, 204))
        for dx in (-7, 7): pygame.draw.circle(S, (30, 14, 18), (bx + dx, by - 268), 5)
        pygame.draw.rect(S, (226, 220, 204), (bx - 10, by - 252, 20, 8))
        for sg in (-1, 1): _torch(S, bx + sg * 120, by - 4, r)
        _moss(S, bx - 110, by - 40, 90, r, 10); _moss(S, bx + 100, by - 36, 90, r, 10)
        sc = .25
    spr = outline(_finish(S, sc), (18, 14, 12, 45))
    _PORTAL[kind] = (spr, (spr.get_width() // 2, int(by * sc)))
    return _PORTAL[kind]

# ----------------------------------------------------------- characters
CLASS_SPEC = {
 "Warrior": dict(body=(150, 156, 168), trim=(206, 164, 60), legs=(84, 86, 96), boots=(60, 50, 44), head="helm", weapon="greatsword"),
 "Ranger":  dict(body=(74, 112, 62), trim=(146, 104, 62), legs=(92, 72, 52), boots=(70, 50, 36), head="hood", hoodc=(60, 92, 52), weapon="bow"),
 "Mage":    dict(body=(92, 60, 166), trim=(226, 192, 92), legs=(60, 40, 110), boots=(50, 36, 70), head="hat", hatc=(70, 44, 142), weapon="staff", orb=(130, 210, 255), robe=True, beard=(196, 196, 204), brow=(180, 180, 188)),
 "Cleric":  dict(body=(232, 226, 212), trim=(214, 172, 62), legs=(200, 194, 180), boots=(140, 110, 70), head="circlet", weapon="mace", shield=True, robe=True, beard=(120, 84, 52)),
 "Rogue":   dict(body=(56, 56, 68), trim=(150, 40, 40), legs=(46, 46, 54), boots=(30, 30, 34), head="hood", hoodc=(40, 40, 50), mask=True, weapon="daggers"),
 "Paladin": dict(body=(226, 196, 112), trim=(250, 244, 214), legs=(160, 140, 90), boots=(110, 86, 50), head="helm", helmc=(236, 206, 118), weapon="mace", shield=True, shieldc=(240, 230, 190)),
 "Shaman":  dict(body=(62, 104, 156), trim=(206, 166, 82), legs=(110, 82, 52), boots=(80, 58, 38), head="feathers", hair=(40, 30, 26), weapon="staff", orb=(140, 210, 255), shield=True, shieldc=(120, 80, 50), beard=(44, 32, 26)),
 "Druid":   dict(body=(92, 112, 62), trim=(176, 134, 72), legs=(104, 82, 52), boots=(70, 52, 34), head="antlers", hair=(110, 70, 40), weapon="staff", orb=(130, 240, 130), robe=True, beard=(104, 68, 40)),
 # 0.18.0 pure-DPS classes
 "Berserker": dict(skin=(214, 168, 132), body=(122, 72, 48), trim=(196, 188, 170), legs=(78, 56, 42), boots=(56, 40, 30), head="warhelm", helmc=(124, 128, 138), hair=(176, 92, 44), weapon="greataxe", warpaint=(170, 30, 30), beard=(170, 88, 40)),
 "Warlock":   dict(body=(46, 30, 58), trim=(120, 220, 80), legs=(34, 22, 44), boots=(26, 18, 30), head="hood", hoodc=(34, 22, 44), eyes=(150, 255, 110), weapon="staff", orb=(120, 255, 90), robe=True),
 "Juggernaut": dict(body=(98, 102, 116), trim=(182, 134, 62), legs=(74, 78, 90), boots=(52, 52, 58), head="helm", helmc=(86, 90, 104), eyes=(255, 196, 90), weapon="hammer", towershield=(150, 40, 36), cape_override=None),
 "Monk":      dict(body=(222, 136, 40), trim=(150, 40, 30), legs=(196, 118, 38), boots=(120, 84, 50), head="topknot", hair=(30, 24, 22), weapon="bostaff", sash=(150, 40, 30)),
}
NPC_SPEC = {
 "vendor":     dict(body=(150, 110, 60), trim=(230, 210, 160), legs=(90, 70, 50), boots=(60, 44, 30), head="hair", hair=(80, 50, 30), weapon="flask", apron=(230, 220, 190)),
 "blacksmith": dict(body=(120, 80, 50), trim=(60, 50, 40), legs=(70, 60, 50), boots=(40, 34, 28), head="hair", hair=(40, 30, 24), weapon="hammer", apron=(90, 60, 40), beard=True),
 "fishmonger": dict(body=(70, 110, 140), trim=(230, 220, 190), legs=(60, 70, 80), boots=(40, 50, 44), head="hat", hatc=(210, 180, 80), weapon="rod", apron=(200, 210, 215)),
 "banker":     dict(body=(36, 48, 78), trim=(232, 196, 90), legs=(40, 40, 52), boots=(30, 26, 26), head="hat", hatc=(28, 28, 34), weapon=None, apron=(214, 200, 160), beard=True),
 "jeweler":    dict(body=(110, 50, 110), trim=(240, 210, 100), legs=(60, 40, 70), boots=(40, 30, 40), head="hair", hair=(60, 40, 30), weapon="gem", apron=(230, 215, 240)),
 "guard":      dict(body=(160, 164, 176), trim=(206, 164, 60), legs=(84, 86, 96), boots=(60, 50, 44), head="helm", weapon="spear", shield=True),
 "stablemaster": dict(body=(112, 84, 52), trim=(214, 172, 62), legs=(80, 62, 44), boots=(54, 40, 30), head="hat", hatc=(120, 84, 44), weapon="staffplain", apron=(150, 110, 70)),
 "innkeeper":  dict(body=(150, 60, 50), trim=(230, 210, 160), legs=(80, 60, 50), boots=(60, 44, 30), head="hair", hair=(150, 110, 60), weapon="mug", apron=(240, 236, 220)),
 "questgiver": dict(body=(70, 90, 140), trim=(236, 204, 90), legs=(60, 60, 80), boots=(50, 40, 34), head="hat", hatc=(60, 76, 120), weapon="staffplain", robe=True),
 "dailygiver": dict(body=(40, 100, 190), trim=(170, 220, 255), legs=(36, 52, 96), boots=(40, 36, 44), head="hat", hatc=(30, 70, 150), weapon="staffplain", robe=True),
 "king":       dict(body=(150, 30, 46), trim=(240, 200, 80), legs=(90, 24, 34), boots=(50, 36, 30), head="crown", hair=(190, 190, 195), weapon="staffplain", robe=True, beard=True, cape_override=(120, 20, 36)),
 "marketeer":  dict(body=(40, 110, 110), trim=(236, 204, 90), legs=(70, 60, 50), boots=(60, 44, 30), head="hat", hatc=(200, 150, 50), weapon=None, apron=(230, 220, 190), pack=True),
 "merchant":   dict(body=(60, 120, 90), trim=(220, 190, 90), legs=(70, 60, 50), boots=(60, 44, 30), head="hat", hatc=(120, 80, 40), weapon="staffplain", robe=True, pack=True),
}
MONSTER_SPEC = {
 "Bandit":      ("human", dict(body=(110, 72, 52), trim=(170, 40, 40), legs=(70, 56, 46), boots=(40, 32, 26), head="bandana", bandana=(170, 40, 40), weapon="sword"), 1.0),
 "Goblin":      ("human", dict(skin=(112, 168, 72), body=(100, 80, 52), trim=(70, 60, 40), legs=(80, 62, 40), boots=(50, 40, 30), head="ears", weapon="club"), .72),
 "Kobold":      ("human", dict(skin=(160, 112, 70), body=(120, 92, 62), trim=(90, 70, 40), legs=(90, 70, 50), boots=(60, 44, 30), head="snout", weapon="dagger", candle=True), .68),
 "Orc":         ("human", dict(skin=(84, 132, 62), body=(92, 72, 60), trim=(150, 40, 40), legs=(70, 56, 46), boots=(40, 32, 26), head="tusks", weapon="axe"), 1.2),
 "Skeleton":    ("human", dict(skin=(232, 226, 206), body=(232, 226, 206), trim=(170, 160, 140), legs=(220, 214, 196), boots=(200, 194, 176), head="skull", weapon="sword", bones=True), 1.0),
 "Ghoul":       ("human", dict(skin=(132, 152, 120), body=(82, 92, 80), trim=(60, 70, 60), legs=(82, 92, 80), boots=(100, 120, 100), head="bald", weapon="claws", eyes=(220, 240, 120)), 1.0),
 "Cultist":     ("human", dict(body=(112, 24, 36), trim=(220, 180, 80), legs=(80, 20, 30), boots=(40, 20, 20), head="hood", hoodc=(90, 18, 28), weapon="staff", orb=(255, 90, 60), robe=True, eyes=(255, 120, 80)), 1.0),
 "Dark Knight": ("human", dict(body=(42, 42, 50), trim=(170, 30, 30), legs=(34, 34, 40), boots=(24, 24, 28), head="helm", helmc=(50, 50, 60), weapon="greatsword", eyes=(255, 60, 40), cape=(120, 20, 20)), 1.15),
 "Demon":       ("human", dict(skin=(172, 42, 40), body=(96, 22, 22), trim=(255, 140, 40), legs=(80, 20, 20), boots=(40, 10, 10), head="horns", weapon="claws", wings=(90, 20, 30), eyes=(255, 220, 60)), 1.3),
 "Troll":       ("human", dict(skin=(92, 142, 132), body=(100, 80, 60), trim=(150, 120, 80), legs=(90, 70, 50), boots=(70, 110, 100), head="tusks", weapon="club"), 1.4),
 "Ogre":        ("human", dict(skin=(184, 150, 112), body=(112, 90, 60), trim=(80, 60, 40), legs=(100, 80, 56), boots=(150, 120, 90), head="bald", weapon="club"), 1.5),
 "Frost Giant": ("human", dict(skin=(172, 204, 234), body=(120, 142, 172), trim=(220, 236, 255), legs=(100, 120, 150), boots=(80, 96, 120), head="beardhelm", helmc=(150, 170, 200), weapon="axe", eyes=(120, 220, 255)), 1.8),
 "Harpy":       ("human", dict(skin=(200, 160, 130), body=(150, 110, 80), trim=(110, 80, 60), legs=(120, 100, 60), boots=(200, 160, 60), head="hair", hair=(90, 60, 40), weapon="claws", wings=(150, 110, 80)), .95),
 "Wolf":        ("beast", dict(c=(122, 122, 128), ears=True, tail=True), 1.0),
 "Boar":        ("beast", dict(c=(112, 76, 52), tusks=True, bristle=True), 1.0),
 "Basilisk":    ("beast", dict(c=(84, 124, 72), spikes=True, long=True, low=True), 1.15),
 "Lava Beast":  ("beast", dict(c=(62, 42, 36), cracks=(255, 130, 40), ears=True, spikes=True), 1.3),
 "Spider":      ("spider", dict(c=(52, 46, 54)), 1.0),
 "Sand Wyrm":   ("serpent", dict(c=(204, 172, 104)), 1.3),
 "Wyvern":      ("dragon", dict(c=(92, 112, 80), wing=(70, 90, 60)), 1.1),
 "Dragonkin":   ("dragon", dict(c=(154, 52, 42), wing=(110, 40, 40)), 1.3),
 "Wraith":      ("wraith", dict(c=(60, 62, 96)), 1.1),
 "Elemental":   ("elemental", dict(c=(120, 180, 255)), 1.1),
 "Ancient Treant": ("treant", dict(c=(100, 76, 52)), 1.7),
}

MONSTER_SPEC.update({
 # ---- 0.22 new zone species
 "Giant Beetle": ("scorpion", dict(c=(60, 96, 58), beetle=True), 1.0),
 "Gnoll":        ("human", dict(skin=(166, 134, 78), body=(104, 76, 50), trim=(70, 50, 34), legs=(88, 66, 44), boots=(52, 40, 30), head="snout", weapon="axe", fur=(150, 118, 64)), 1.05),
 "Bear":         ("beast", dict(c=(96, 66, 44), hump=True, roundears=True, ears=True), 1.45),
 "Dire Boar":    ("beast", dict(c=(62, 50, 46), tusks=True, bristle=True, spikes=True, spikec=(34, 26, 24)), 1.45),
 "Yeti":         ("human", dict(skin=(230, 236, 244), body=(206, 218, 232), trim=(160, 184, 210), legs=(200, 212, 228), boots=(170, 190, 214), head="snout", weapon="claws", fur=(224, 232, 244), eyes=(120, 200, 255)), 1.45),
 "Ice Wolf":     ("beast", dict(c=(170, 206, 236), ears=True, tail=True, spikes=True, spikec=(240, 250, 255)), 1.1),
 "Mud Leech":    ("serpent", dict(c=(72, 62, 46)), .9),
 "Swamp Hag":    ("human", dict(skin=(118, 148, 92), body=(66, 56, 82), trim=(130, 110, 60), legs=(58, 48, 70), boots=(40, 34, 30), head="hood", hoodc=(50, 42, 64), weapon="staff", orb=(120, 255, 140), robe=True), 1.05),
 "Scorpion":     ("scorpion", dict(c=(176, 126, 66)), 1.1),
 "Mummy":        ("human", dict(skin=(210, 196, 154), body=(200, 184, 144), trim=(150, 130, 90), legs=(194, 178, 138), boots=(176, 160, 120), head="bald", eyes=(120, 255, 200), weapon="claws", wraps=True), 1.05),
 "Fire Imp":     ("human", dict(skin=(226, 84, 40), body=(112, 30, 20), trim=(255, 170, 60), legs=(150, 40, 24), boots=(60, 20, 16), head="horns", wings=(170, 44, 30), weapon="dagger", flame=True), .75),
 "Magma Golem":  ("golem", dict(c=(70, 56, 52), cracks=(255, 130, 40)), 1.35),
 "Banshee":      ("wraith", dict(c=(176, 208, 222), banshee=True), 1.1),
 "Bone Knight":  ("human", dict(skin=(226, 220, 200), body=(62, 66, 80), trim=(150, 160, 180), legs=(214, 208, 190), boots=(60, 64, 78), head="helm", helmc=(70, 74, 90), eyes=(120, 255, 220), weapon="greatsword", shield=True, shieldc=(60, 72, 96)), 1.15),
 "Drake":        ("dragon", dict(c=(70, 112, 156), wing=(50, 84, 126)), 1.2),
 "Thunder Harpy": ("human", dict(skin=(214, 196, 160), body=(80, 104, 150), trim=(250, 230, 100), legs=(110, 96, 70), boots=(230, 200, 80), head="feathers", wings=(70, 130, 200), weapon="claws", eyes=(255, 255, 140)), 1.0),
 "Shadow Stalker": ("beast", dict(c=(38, 30, 56), ears=True, tail=True, spikes=True, spikec=(150, 80, 230), cracks=(170, 90, 255), long=True), 1.2),
 "Void Horror":  ("elemental", dict(c=(104, 48, 168), horror=True), 1.3),
 "Sea Serpent":  ("serpent", dict(c=(52, 150, 176)), 1.5),
 # ---- dungeon bosses (one unique look per dungeon)
 "Stone Warden":     ("golem", dict(c=(104, 112, 100), cracks=(120, 230, 160), moss=True), 1.3),
 "Broodmother":      ("spider", dict(c=(70, 36, 56)), 1.6),
 "Lich Kinglet":     ("human", dict(skin=(226, 220, 200), body=(70, 40, 110), trim=(190, 160, 255), legs=(54, 32, 90), boots=(30, 20, 50), head="skull", weapon="staff", orb=(140, 255, 160), robe=True, crown=(240, 200, 80), cape=(40, 20, 70)), 1.3),
 "Frost Tyrant":     ("human", dict(skin=(172, 204, 234), body=(120, 142, 172), trim=(220, 236, 255), legs=(100, 120, 150), boots=(80, 96, 120), head="beardhelm", helmc=(150, 180, 220), weapon="greataxe", setl="Frostwyrm", setp=("armor", "helm")), 1.35),
 "Swamp Hydra":      ("hydra", dict(c=(70, 110, 66)), 1.3),
 "Dread Captain":    ("human", dict(skin=(190, 200, 206), body=(46, 58, 84), trim=(214, 172, 62), legs=(36, 44, 64), boots=(30, 28, 34), head="hat", hatc=(26, 28, 40), eyes=(120, 230, 255), weapon="sword", cape=(110, 24, 34)), 1.25),
 "Demon Prince":     ("human", dict(skin=(160, 32, 60), body=(90, 20, 40), trim=(255, 150, 50), legs=(70, 16, 34), boots=(36, 10, 18), head="horns", wings=(110, 24, 48), weapon="greatsword", setl="Voidtouched", setp=("armor", "helm")), 1.35),
 "Sand Colossus":    ("golem", dict(c=(196, 166, 104), cracks=(255, 226, 120), crown=(240, 200, 80)), 1.45),
 "Ember Dragon":     ("dragon", dict(c=(176, 44, 30), wing=(124, 34, 26), flames=True), 1.45),
 "Wyrm Matriarch":   ("dragon", dict(c=(150, 176, 206), wing=(104, 136, 176), twin=True), 1.5),
 "Shadow Lord":      ("human", dict(skin=(60, 50, 80), body=(30, 22, 46), trim=(190, 100, 255), legs=(24, 18, 36), boots=(18, 12, 28), head="helm", helmc=(34, 26, 50), eyes=(200, 100, 255), weapon="greatsword", setl="Voidforged", setp=("armor", "helm", "weapon")), 1.4),
 "Ancient Guardian": ("golem", dict(c=(88, 102, 112), cracks=(110, 220, 255), crown=(150, 200, 230), moss=True), 1.5),
 # ---- raid and heroic bosses
 "Titan of Ash":         ("human", dict(skin=(70, 64, 62), body=(60, 54, 52), trim=(255, 126, 44), legs=(50, 46, 44), boots=(34, 30, 28), head="horns", weapon="greataxe", eyes=(255, 140, 50), setl="Ashen Titan", setp=("armor", "helm", "weapon", "trinket")), 1.5),
 "Frostwyrm Overlord":   ("dragon", dict(c=(160, 206, 244), wing=(110, 160, 224), icy=True), 1.7),
 "Dread Legion General": ("human", dict(skin=(200, 196, 190), body=(50, 34, 54), trim=(196, 60, 74), legs=(40, 28, 44), boots=(30, 20, 34), head="helm", weapon="greatsword", eyes=(255, 70, 90), setl="Dread Legion", setp=("armor", "helm", "weapon", "trinket")), 1.5),
 "Sunscar Colossus":     ("golem", dict(c=(214, 178, 96), cracks=(255, 240, 140), crown=(255, 230, 120)), 1.8),
 "Ember Dragon Emperor": ("dragon", dict(c=(190, 40, 28), wing=(60, 24, 22), flames=True, crown=(255, 220, 100)), 1.9),
 "Void Seraph":          ("human", dict(skin=(214, 200, 236), body=(64, 46, 116), trim=(196, 156, 255), legs=(50, 36, 96), boots=(36, 26, 70), head="circlet", weapon="staff", orb=(200, 160, 255), robe=True, setl="Void Seraph", setp=("armor", "helm", "weapon", "trinket")), 1.5),
 "Malachar, the Void Sovereign": ("human", dict(skin=(44, 30, 66), body=(30, 20, 50), trim=(214, 64, 255), legs=(22, 14, 38), boots=(16, 10, 28), head="helm", weapon="greatsword", eyes=(230, 100, 255), setl="Voidtouched", setp=("armor", "helm", "weapon", "trinket")), 1.6),
 "Ashmaw the Devourer":  ("dragon", dict(c=(66, 60, 56), wing=(44, 40, 40), cracks=(255, 90, 40)), 1.8),
 "Queen Veyra of the Hollow Choir": ("wraith", dict(c=(96, 206, 204), banshee=True, crown=(240, 220, 120)), 1.5),
 "Warden Kaldris, Voidforged": ("human", dict(skin=(190, 180, 210), body=(38, 26, 64), trim=(180, 110, 255), legs=(30, 20, 50), boots=(22, 14, 38), head="helm", weapon="greataxe", eyes=(180, 110, 255), setl="Voidforged", setp=("armor", "helm", "weapon", "trinket")), 1.5),
})

# boss sprites are scaled again by the engine (x1.35 / x1.6), so keep their base size modest
for _bk in ("Stone Warden", "Broodmother", "Lich Kinglet", "Frost Tyrant", "Swamp Hydra", "Dread Captain", "Demon Prince", "Sand Colossus",
            "Ember Dragon", "Wyrm Matriarch", "Shadow Lord", "Ancient Guardian", "Titan of Ash", "Frostwyrm Overlord", "Dread Legion General",
            "Sunscar Colossus", "Ember Dragon Emperor", "Void Seraph", "Malachar, the Void Sovereign", "Ashmaw the Devourer",
            "Queen Veyra of the Hollow Choir", "Warden Kaldris, Voidforged"):
    _k, _sp, _sc = MONSTER_SPEC[_bk]; MONSTER_SPEC[_bk] = (_k, _sp, round(_sc * .72, 2))

def monster_kind(name):
    base = name.split(" #")[0]
    if base.startswith("Elite "): base = base[6:]
    return base if base in MONSTER_SPEC else "Wolf"

def _weapon(S, kind, hx, hy, ang, spec, k=1.0):
    def poly(pts, col):
        pygame.draw.polygon(S, col, _rot(pts, ang, hx, hy))
    steel = (210, 214, 224); gold = (214, 172, 62); wood = (110, 76, 44)
    if kind in ("sword", "greatsword"):
        L = 62 if kind == "greatsword" else 44; w = 7 if kind == "greatsword" else 5
        poly([(-10, -3), (4, -3), (4, 3), (-10, 3)], (70, 50, 34))
        poly([(4, -10), (9, -10), (9, 10), (4, 10)], gold)
        poly([(9, -w), (9 + L, -w * .5), (14 + L, 0), (9 + L, w * .5), (9, w)], steel)
        poly([(9, 0), (9 + L, 0), (14 + L, 0), (9 + L, w * .3), (9, w * .5)], (170, 174, 186))
    elif kind == "dagger":
        poly([(-6, -2), (2, -2), (2, 2), (-6, 2)], (70, 50, 34)); poly([(2, -4), (34, 0), (2, 4)], steel); poly([(2, 0), (34, 0), (2, 4)], (170, 174, 186))
    elif kind == "axe":
        poly([(-14, -3), (56, -3), (56, 3), (-14, 3)], wood)
        poly([(40, -4), (62, -22), (66, 0), (62, 22), (40, 4)], (180, 184, 196))
    elif kind in ("club", "hammer"):
        poly([(-10, -4), (40, -5), (40, 5), (-10, 4)], wood)
        if kind == "club":
            poly([(30, -10), (54, -12), (58, 0), (54, 12), (30, 10)], shade(wood, 1.15))
        else:
            poly([(36, -14), (52, -14), (52, 14), (36, 14)], (120, 124, 134))
    elif kind == "mace":
        poly([(-10, -3), (40, -3), (40, 3), (-10, 3)], wood)
        c = _rot([(46, 0)], ang, hx, hy)[0]
        pygame.draw.circle(S, (190, 194, 204), (int(c[0]), int(c[1])), 10)
        pygame.draw.circle(S, gold, (int(c[0]), int(c[1])), 10, 3)
    elif kind in ("flask", "mug", "gem", "rod", "fish"):
        c = _rot([(10, 0)], ang, hx, hy)[0]; cx_, cy_ = int(c[0]), int(c[1])
        if kind == "flask":
            pygame.draw.rect(S, (205, 220, 230), (cx_ - 3, cy_ - 13, 6, 8)); pygame.draw.circle(S, (205, 220, 230), (cx_, cy_), 8)
            pygame.draw.circle(S, (210, 70, 90), (cx_, cy_ + 1), 6); pygame.draw.circle(S, (255, 255, 255), (cx_ - 3, cy_ - 2), 2)
            pygame.draw.rect(S, (150, 110, 70), (cx_ - 4, cy_ - 16, 8, 4))
        elif kind == "mug":
            pygame.draw.rect(S, (150, 100, 56), (cx_ - 7, cy_ - 9, 14, 17), border_radius=3); pygame.draw.rect(S, (240, 236, 220), (cx_ - 7, cy_ - 11, 14, 5), border_radius=3)
            pygame.draw.circle(S, (120, 80, 44), (cx_ + 9, cy_), 5, 2); pygame.draw.line(S, (210, 180, 120), (cx_ - 7, cy_ - 2), (cx_ + 7, cy_ - 2), 1)
        elif kind == "gem":
            pts_ = [(cx_, cy_ - 11), (cx_ + 9, cy_ - 3), (cx_ + 5, cy_ + 9), (cx_ - 5, cy_ + 9), (cx_ - 9, cy_ - 3)]
            pygame.draw.polygon(S, (90, 170, 255), pts_); pygame.draw.polygon(S, (200, 235, 255), [pts_[0], pts_[1], (cx_, cy_ - 2)]); pygame.draw.polygon(S, (40, 80, 160), pts_, 2)
            _spark(S, cx_ + 9, cy_ - 10, 5, (255, 255, 255), 200)
        elif kind == "rod":
            poly([(-20, -2), (80, -1), (80, 1), (-20, 2)], (120, 86, 50))
            e = _rot([(80, 0)], ang, hx, hy)[0]; pygame.draw.line(S, (230, 230, 220), (e[0], e[1]), (e[0] + 6, e[1] + 44), 1)
            pygame.draw.circle(S, (220, 70, 60), (int(e[0] + 6), int(e[1] + 44)), 3)
        else:
            pygame.draw.ellipse(S, (130, 170, 200), (cx_ - 14, cy_ - 6, 28, 12)); pygame.draw.polygon(S, (110, 150, 180), [(cx_ + 12, cy_), (cx_ + 22, cy_ - 8), (cx_ + 22, cy_ + 8)])
            pygame.draw.ellipse(S, (210, 226, 236), (cx_ - 12, cy_ + 1, 22, 5)); pygame.draw.circle(S, (20, 30, 40), (cx_ - 8, cy_ - 2), 2)
    elif kind in ("staff", "staffplain"):
        poly([(-30, -3), (70, -3), (70, 3), (-30, 3)], wood)
        if kind == "staff":
            c = _rot([(76, 0)], ang, hx, hy)[0]
            orb = spec.get("orb", (130, 210, 255))
            pygame.draw.circle(S, (*orb, 90), (int(c[0]), int(c[1])), 16)
            pygame.draw.circle(S, orb, (int(c[0]), int(c[1])), 9)
            pygame.draw.circle(S, (255, 255, 255), (int(c[0]) - 3, int(c[1]) - 3), 3)
    elif kind == "greataxe":
        # long haft with a double crescent head and a spike (Berserker)
        poly([(-30, -3), (74, -3), (74, 3), (-30, 3)], (86, 58, 36))
        for o in (-4, 10, 24):
            poly([(o, -4), (o + 4, -4), (o + 4, 4), (o, 4)], (60, 40, 26))
        blade = (190, 194, 206); edge = (236, 238, 244)
        poly([(54, -4), (62, -30), (78, -36), (74, -18), (70, -4)], blade)
        poly([(54, 4), (62, 30), (78, 36), (74, 18), (70, 4)], blade)
        poly([(62, -30), (78, -36), (76, -30), (64, -26)], edge)
        poly([(62, 30), (78, 36), (76, 30), (64, 26)], edge)
        poly([(74, -3), (90, 0), (74, 3)], blade)
        c = _rot([(62, 0)], ang, hx, hy)[0]
        pygame.draw.circle(S, (170, 40, 30), (int(c[0]), int(c[1])), 4)
    elif kind == "bostaff":
        # banded quarterstaff (Monk)
        poly([(-44, -3), (72, -3), (72, 3), (-44, 3)], (150, 104, 58))
        for a0 in (-44, -22, 50, 64):
            poly([(a0, -4), (a0 + 7, -4), (a0 + 7, 4), (a0, 4)], (150, 40, 30))
        poly([(68, -4), (72, -4), (72, 4), (68, 4)], (214, 172, 62)); poly([(-44, -4), (-40, -4), (-40, 4), (-44, 4)], (214, 172, 62))
    elif kind == "spear":
        poly([(-40, -3), (70, -3), (70, 3), (-40, 3)], wood)
        poly([(70, -6), (92, 0), (70, 6)], steel)
    elif kind == "claws":
        for o in (-5, 0, 5):
            poly([(0, o - 2), (16, o), (0, o + 2)], (240, 236, 220))
    elif kind == "wand":                    # 0.46.24: a short tapered wand with a glowing star tip
        poly([(-8, -3), (42, -1.5), (42, 1.5), (-8, 3)], (96, 62, 40)); poly([(-8, -3.5), (0, -3.5), (0, 3.5), (-8, 3.5)], gold)
        c = _rot([(48, 0)], ang, hx, hy)[0]; orb = spec.get("orb", (130, 210, 255))
        pygame.draw.circle(S, (*orb, 90), (int(c[0]), int(c[1])), 13); _star4(S, c[0], c[1], 11, (255, 255, 255)); _star4(S, c[0], c[1], 7, orb)
    elif kind == "scepter":                 # a gold rod with a jewelled crown
        poly([(-10, -3), (46, -3), (46, 3), (-10, 3)], gold); poly([(14, -5), (18, -5), (18, 5), (14, 5)], shade(gold, .7))
        c = _rot([(54, 0)], ang, hx, hy)[0]
        pygame.draw.circle(S, shade(gold, .7), (int(c[0]), int(c[1])), 11); pygame.draw.circle(S, (240, 90, 100), (int(c[0]), int(c[1])), 8)
        pygame.draw.circle(S, (255, 220, 220), (int(c[0]) - 3, int(c[1]) - 3), 3)
    elif kind == "daggers":
        for da in (-.32, .32): _weapon(S, "dagger", hx, hy, ang + da, spec)


_GRAD = {}
def _gradient(w, h, hi, lo, horiz=True):
    k = (w, h, hi, lo, horiz)
    g = _GRAD.get(k)
    if g is None:
        g = pygame.Surface((max(1, w), max(1, h)))
        n = w if horiz else h
        for i in range(n):
            f = hi + (lo - hi) * (i / max(1, n - 1))
            v = max(0, min(255, int(255 * f)))
            if horiz: pygame.draw.line(g, (v, v, v), (i, 0), (i, h))
            else: pygame.draw.line(g, (v, v, v), (0, i), (w, i))
        if len(_GRAD) > 600: _GRAD.clear()          # 0.45: bounded
        _GRAD[k] = g
    return g

def _gshape(S, rect, col, radius=8, hi=1.18, lo=.66, horiz=True):
    """Rounded rectangle with a light->dark gradient (cylindrical shading)."""
    r = pygame.Rect(rect)
    if r.w < 2 or r.h < 2: return
    t = pygame.Surface(r.size, pygame.SRCALPHA)
    pygame.draw.rect(t, col, t.get_rect(), border_radius=radius)
    mul = _gradient(r.w, r.h, min(1.0, hi), lo, horiz)
    t.blit(mul, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    if hi > 1.0:
        add = int(255 * (hi - 1.0) * .55)
        hl = pygame.Surface((max(1, r.w // 3), r.h - 4), pygame.SRCALPHA)
        pygame.draw.rect(hl, (add, add, add, 255), hl.get_rect(), border_radius=radius)
        t.blit(hl, (r.w // 6, 2), special_flags=pygame.BLEND_RGB_ADD)
    S.blit(t, r.topleft)

def _limb(S, p0, p1, w, col):
    """Round limb: dark edge, body colour and a highlight stripe."""
    pygame.draw.line(S, shade(col, .58), p0, p1, w + 2)
    pygame.draw.line(S, shade(col, .86), p0, p1, w)
    pygame.draw.line(S, col, (p0[0] - 1, p0[1]), (p1[0] - 1, p1[1]), max(2, int(w * .62)))
    pygame.draw.line(S, shade(col, 1.25), (p0[0] - w * .18, p0[1]), (p1[0] - w * .18, p1[1]), max(1, int(w * .22)))

def _sphere(S, c, r, col):
    pygame.draw.circle(S, shade(col, .62), c, r)
    pygame.draw.circle(S, shade(col, .88), (c[0] - 1, c[1] - 1), r - 1)
    pygame.draw.circle(S, col, (c[0] - r * .15, c[1] - r * .18), int(r * .78))
    pygame.draw.circle(S, shade(col, 1.2), (c[0] - r * .3, c[1] - r * .36), int(r * .4))



# ----------------------------------------------------------- gear set looks (0.21)
# Like Conquer Online: every armour set re-skins the hero.  Each piece you wear changes one part of the look
# (cuirass = colours, shoulders and chest emblem; crown = helm; weapon = glowing blade; relic = floating charm);
# two pieces add a matching cape and ground aura, four pieces add wings/eyes and an animated aura.
SET_LOOKS = {
    "Ashen Titan":      dict(c=(94, 86, 84),   c2=(255, 132, 48),  glow=(255, 112, 36),  cape=(64, 36, 32),   shoulder="spike",  helm="crest",  motif="flame", wings=False),
    "Frostwyrm":        dict(c=(148, 194, 228), c2=(240, 250, 255), glow=(140, 222, 255), cape=(70, 112, 170),  shoulder="wing",   helm="icecrown", motif="snow", wings=True),
    "Dread Legion":     dict(c=(58, 40, 62),   c2=(196, 60, 74),   glow=(224, 60, 92),   cape=(100, 20, 34),   shoulder="skull",  helm="horns2", motif="skull", wings=False),
    "Sunscar Colossus": dict(c=(222, 184, 96), c2=(255, 238, 154), glow=(255, 222, 104), cape=(190, 70, 40),   shoulder="dome",   helm="sunrays", motif="sun", wings=False),
    "Ember Dragon":     dict(c=(150, 38, 30),  c2=(255, 172, 62),  glow=(255, 122, 40),  cape=(90, 20, 20),    shoulder="dragon", helm="dragon", motif="scale", wings=True),
    "Void Seraph":      dict(c=(64, 46, 116),  c2=(196, 156, 255), glow=(164, 116, 255), cape=(40, 28, 84),    shoulder="wing",   helm="halo",   motif="void", wings=True),
    "Voidtouched":      dict(c=(30, 20, 50),   c2=(214, 64, 255),  glow=(204, 64, 255),  cape=(18, 10, 32),    shoulder="spike",  helm="shards", motif="void", wings=False),
    "Voidforged":       dict(c=(38, 26, 64),   c2=(180, 110, 255), glow=(176, 100, 255), cape=(24, 14, 44),    shoulder="spike",  helm="shards", motif="void", wings=True),
}
SET_ORDER = list(SET_LOOKS)

def set_key(set_name):
    for k in SET_LOOKS:
        if set_name and set_name.startswith(k): return k
    return None

def _apply_set(spec):
    k = spec.get("setl")
    if not k or k not in SET_LOOKS: return spec
    sl = SET_LOOKS[k]; pcs = set(spec.get("setp", ())); n = len(pcs)
    sp = dict(spec); sp["_sl"] = sl; sp["_sp"] = pcs; sp["_sn"] = n
    if "armor" in pcs:
        sp["body"] = sl["c"]; sp["trim"] = sl["c2"]; sp["legs"] = shade(sl["c"], .78); sp["boots"] = shade(sl["c"], .55)
        sp["tier"] = sl["glow"]; sp["tierlvl"] = 3
    if "helm" in pcs:
        sp["head"] = "helm"; sp["helmc"] = shade(sl["c"], 1.15)
        sp.pop("helmtier", None); sp["helmlvl"] = 0
    if n >= 2: sp["cape"] = sl["cape"]; sp["cape_override"] = sl["cape"]
    if n >= 4:
        sp["eyes"] = sl["glow"]
        if sl["wings"]: sp["wings"] = shade(sl["c2"], .85)
    return sp

def _spark(S, x, y, r, col, a=150):
    t = pygame.Surface((r * 4, r * 4), pygame.SRCALPHA)
    for i in range(r, 0, -1):
        pygame.draw.circle(t, (*col, int(a * (1 - i / r) ** 1.3 + 20)), (r * 2, r * 2), i * 2)
    S.blit(t, (int(x - r * 2), int(y - r * 2)))

def _motif(S, m, cx, cy, c2, glow):
    if m == "flame":
        pygame.draw.polygon(S, shade(glow, .8), [(cx, cy - 12), (cx + 8, cy + 2), (cx + 3, cy + 10), (cx - 3, cy + 10), (cx - 8, cy + 2)])
        pygame.draw.polygon(S, c2, [(cx, cy - 6), (cx + 4, cy + 2), (cx, cy + 8), (cx - 4, cy + 2)])
    elif m == "snow":
        for a in range(3):
            ang = a * math.pi / 3
            pygame.draw.line(S, (255, 255, 255), (cx - math.cos(ang) * 9, cy - math.sin(ang) * 9), (cx + math.cos(ang) * 9, cy + math.sin(ang) * 9), 2)
        pygame.draw.circle(S, glow, (cx, cy), 3)
    elif m == "skull":
        pygame.draw.circle(S, (232, 226, 210), (cx, cy - 2), 8); pygame.draw.rect(S, (232, 226, 210), (cx - 5, cy + 2, 10, 7))
        pygame.draw.circle(S, (30, 12, 20), (cx - 3, cy - 2), 2); pygame.draw.circle(S, (30, 12, 20), (cx + 3, cy - 2), 2)
    elif m == "sun":
        for a in range(8):
            ang = a * math.pi / 4
            pygame.draw.line(S, c2, (cx + math.cos(ang) * 7, cy + math.sin(ang) * 7), (cx + math.cos(ang) * 12, cy + math.sin(ang) * 12), 2)
        pygame.draw.circle(S, c2, (cx, cy), 7); pygame.draw.circle(S, (255, 252, 214), (cx - 1, cy - 1), 4)
    elif m == "scale":
        for k in range(3):
            pygame.draw.arc(S, c2, (cx - 9 + k * 3, cy - 8 + k * 5, 18 - k * 6, 12), 3.4, 6.0, 3)
        pygame.draw.polygon(S, glow, [(cx - 3, cy + 6), (cx, cy + 12), (cx + 3, cy + 6)])
    else:   # void
        pygame.draw.circle(S, shade(glow, .5), (cx, cy), 9); pygame.draw.circle(S, glow, (cx, cy), 9, 2)
        pygame.draw.circle(S, (14, 6, 24), (cx, cy), 5); pygame.draw.circle(S, c2, (cx + 1, cy - 1), 2)

def _set_body(S, spec, fx, top, swing):
    sl = spec["_sl"]; pcs = spec["_sp"]; c, c2, glow = sl["c"], sl["c2"], sl["glow"]
    if "armor" in pcs:
        _motif(S, sl["motif"], fx + 1, top + 62, c2, glow)
        # tasset skirt panels in the set colours
        for sd, dx in ((-1, -9), (1, 9)):
            pygame.draw.polygon(S, shade(c, .85), [(fx + dx - 5, top + 84), (fx + dx + 5, top + 84), (fx + dx + 4, top + 104), (fx + dx - 4, top + 106)])
            pygame.draw.line(S, c2, (fx + dx - 4, top + 105), (fx + dx + 4, top + 103), 2)
        # pauldrons
        for sd in (-1, 1):
            x = fx + sd * 17; y = top + 47
            st = sl["shoulder"]
            if st == "spike":
                pygame.draw.polygon(S, shade(c, .6), [(x - 6, y - 2), (x + sd * 2, y - 26), (x + 6, y - 2)]); pygame.draw.polygon(S, c2, [(x - 3, y - 3), (x + sd * 2, y - 22), (x + 3, y - 3)])
            elif st == "wing":
                for k in range(3):
                    pygame.draw.polygon(S, shade(c2, 1.0 - k * .12), [(x, y - 2), (x + sd * (12 + k * 4), y - 18 + k * 6), (x + sd * (6 + k * 3), y + 2 + k * 3)])
            elif st == "skull":
                pygame.draw.circle(S, (230, 224, 206), (x, y - 4), 8); pygame.draw.circle(S, (30, 12, 20), (x - 3, y - 5), 2); pygame.draw.circle(S, (30, 12, 20), (x + 3, y - 5), 2)
                pygame.draw.rect(S, (230, 224, 206), (x - 4, y, 8, 5))
            elif st == "dome":
                pygame.draw.circle(S, shade(c, .8), (x, y - 2), 12); pygame.draw.circle(S, c, (x - 1, y - 3), 11); pygame.draw.circle(S, c2, (x, y - 2), 12, 2)
                pygame.draw.circle(S, (255, 255, 255), (x - 4, y - 7), 3)
            else:   # dragon
                pygame.draw.polygon(S, shade(c, .6), [(x - 6, y), (x + sd * 14, y - 20), (x + sd * 4, y - 2)]); pygame.draw.polygon(S, c2, [(x - 3, y - 1), (x + sd * 11, y - 17), (x + sd * 3, y - 3)])
                for k in range(3): pygame.draw.arc(S, c2, (x - 8, y - 6 + k * 3, 16, 8), 3.4, 6.0, 2)
        # belt sash glow
        pygame.draw.line(S, glow, (fx - 17, top + 81), (fx + 17, top + 81), 2)
        # boots flare
        for sd in (-1, 1):
            pygame.draw.polygon(S, c2, [(fx + sd * 8 - 8, 214 - 22), (fx + sd * 8 + 8, 214 - 22), (fx + sd * 8 + 4, 214 - 18), (fx + sd * 8 - 4, 214 - 18)])
    if "trinket" in pcs:   # floating relic charm
        _spark(S, fx - 34, top + 24, 10, glow, 160)
        pygame.draw.polygon(S, shade(c2, .8), [(fx - 34, top + 14), (fx - 28, top + 24), (fx - 34, top + 34), (fx - 40, top + 24)])
        pygame.draw.polygon(S, (255, 255, 255), [(fx - 34, top + 18), (fx - 31, top + 24), (fx - 34, top + 28), (fx - 37, top + 24)])

def _set_helm(S, spec, hx, hy):
    sl = spec["_sl"]; pcs = spec["_sp"]
    if "helm" not in pcs: return
    c, c2, glow = sl["c"], sl["c2"], sl["glow"]; h = sl["helm"]
    if h == "crest":
        pygame.draw.polygon(S, shade(c2, .7), [(hx - 14, hy - 10), (hx - 22, hy - 30), (hx - 6, hy - 18), (hx + 4, hy - 38), (hx + 8, hy - 16), (hx + 20, hy - 28), (hx + 16, hy - 8)])
        pygame.draw.polygon(S, c2, [(hx - 8, hy - 14), (hx + 4, hy - 34), (hx + 8, hy - 14)])
    elif h == "icecrown":
        for k in range(5):
            x = hx - 14 + k * 7
            pygame.draw.polygon(S, (170, 214, 244), [(x - 3, hy - 14), (x, hy - 28 - (2 - abs(k - 2)) * 5), (x + 3, hy - 14)])
            pygame.draw.line(S, (255, 255, 255), (x, hy - 16), (x, hy - 26 - (2 - abs(k - 2)) * 4), 1)
        pygame.draw.line(S, (230, 246, 255), (hx - 16, hy - 13), (hx + 16, hy - 13), 3)
    elif h == "horns2":
        for sd in (-1, 1):
            pygame.draw.polygon(S, (222, 214, 190), [(hx + sd * 12, hy - 12), (hx + sd * 26, hy - 18), (hx + sd * 24, hy - 38), (hx + sd * 16, hy - 20)])
            pygame.draw.line(S, c2, (hx + sd * 14, hy - 14), (hx + sd * 24, hy - 34), 1)
        pygame.draw.polygon(S, c2, [(hx - 4, hy - 17), (hx + 2, hy - 28), (hx + 8, hy - 17)])
    elif h == "sunrays":
        for k in range(9):
            a = math.pi + k / 8 * math.pi
            pygame.draw.polygon(S, c2, [(hx + math.cos(a - .12) * 18, hy - 2 + math.sin(a - .12) * 18), (hx + math.cos(a) * 32, hy - 2 + math.sin(a) * 32), (hx + math.cos(a + .12) * 18, hy - 2 + math.sin(a + .12) * 18)])
        pygame.draw.circle(S, (255, 255, 255), (hx, hy - 15), 3)
    elif h == "dragon":
        for sd in (-1, 1):
            pygame.draw.polygon(S, shade(c, .6), [(hx + sd * 10, hy - 12), (hx + sd * 30, hy - 26), (hx + sd * 38, hy - 22), (hx + sd * 22, hy - 12)])
            pygame.draw.polygon(S, c2, [(hx + sd * 12, hy - 13), (hx + sd * 30, hy - 24), (hx + sd * 20, hy - 12)])
        for k in range(4): pygame.draw.polygon(S, c2, [(hx - 8 + k * 5, hy - 15), (hx - 6 + k * 5, hy - 24 - (k % 2) * 3), (hx - 3 + k * 5, hy - 15)])
    elif h == "halo":
        _spark(S, hx, hy - 30, 14, glow, 110)
        pygame.draw.ellipse(S, shade(c2, .8), (hx - 15, hy - 38, 30, 12), 4); pygame.draw.ellipse(S, (255, 255, 255), (hx - 15, hy - 38, 30, 12), 1)
    else:   # shards
        for k in range(5):
            a = math.pi + (k + .5) / 5 * math.pi; r = 22
            x, y = hx + math.cos(a) * r, hy - 6 + math.sin(a) * r * .9
            pygame.draw.polygon(S, shade(c2, .7), [(x, y - 9), (x + 4, y), (x, y + 6), (x - 4, y)]); pygame.draw.polygon(S, glow, [(x, y - 6), (x + 2, y), (x, y + 3), (x - 2, y)])

_WLEN = {"sword": 52, "greatsword": 74, "axe": 52, "greataxe": 72, "mace": 44, "staff": 84, "staffplain": 84, "spear": 90, "bostaff": 88, "daggers": 28, "dagger": 26, "claws": 22, "club": 40, "wand": 40}
def _set_weapon(S, spec, wpn, hx, hy, ang):
    sl = spec["_sl"]; glow = sl["glow"]; L = _WLEN.get(wpn, 46)
    t = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    ex, ey = hx + math.cos(ang) * (L + 12), hy + math.sin(ang) * (L + 12)
    pygame.draw.line(t, (*glow, 70), (hx + math.cos(ang) * 10, hy + math.sin(ang) * 10), (ex, ey), 9)
    pygame.draw.line(t, (*sl["c2"], 120), (hx + math.cos(ang) * 10, hy + math.sin(ang) * 10), (ex, ey), 3)
    S.blit(t, (0, 0))
    for i in range(0, L, 9):
        _spark(S, hx + math.cos(ang) * (i + 12), hy + math.sin(ang) * (i + 12), 4, glow, 150)
    _spark(S, ex, ey, 8, (255, 255, 255), 170)

def _inlay(S, draw):
    """Draw translucent detail onto a temporary layer, clip it to the creature's silhouette, then blend it on."""
    L = pygame.Surface(S.get_size(), pygame.SRCALPHA); draw(L)
    m = pygame.mask.from_surface(S, 24).to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
    L.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN); S.blit(L, (0, 0))

def polish(S, rim=(78, 70, 54), ao=.72, rim_px=3):
    """0.21: rim light on the upper-left edge and ambient-occlusion towards the feet (done once, at 2x, cached)."""
    w, h = S.get_size()
    sil = pygame.mask.from_surface(S, 40).to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
    sh = pygame.Surface((w, h), pygame.SRCALPHA); sh.blit(sil, (rim_px, rim_px))
    edge = sil.copy(); edge.blit(sh, (0, 0), special_flags=pygame.BLEND_RGBA_SUB)
    edge.fill((*rim, 255), special_flags=pygame.BLEND_RGBA_MULT)
    S.blit(edge, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    g = pygame.Surface((w, h))
    for y in range(h):
        f = 1.0 if y < h * .45 else 1.0 - (1.0 - ao) * ((y - h * .45) / (h * .55)) ** 1.4
        g.fill((int(255 * f),) * 3, (0, y, w, 1))
    S.blit(g, (0, 0), special_flags=pygame.BLEND_RGB_MULT)

def _glint(S, x, y, r=2):
    pygame.draw.circle(S, (255, 255, 255), (int(x), int(y)), r)

# ---------------------------------------------------------------------------------------------
# 0.23: Diablo-style humanoids.  Realistic proportions (about 7.5 heads tall), tapered torsos,
# jointed arms and legs, plate armour with specular highlights, cloth/leather with soft folds,
# long capes and small shadowed faces.  Lit from the upper left.  Same spec keys as before, so
# every class, NPC, monster, gear set and boss keeps its look.
# ---------------------------------------------------------------------------------------------
HUMAN_SEAT_CUT = 142          # 2x-space y where a mounted rider's sprite is cut (just under the hips)
_HGRAD = {}
def _hgrad(w, h, lo, hi, top=1.06, bot=.8):
    """Multiply map: light from the left (hi) to the right (lo), and from the top (top) to the bottom (bot)."""
    k = (w, h, lo, hi, top, bot)
    g = _HGRAD.get(k)
    if g is None:
        g = pygame.Surface((max(1, w), max(1, h)))
        for x in range(w):
            f = hi + (lo - hi) * (x / max(1, w - 1)) ** 1.15
            v = max(0, min(255, int(255 * f)))
            pygame.draw.line(g, (v, v, v), (x, 0), (x, h))
        vg = pygame.Surface((max(1, w), max(1, h)))
        for y in range(h):
            f = top + (bot - top) * (y / max(1, h - 1))
            v = max(0, min(255, int(255 * min(1.0, f))))
            pygame.draw.line(vg, (v, v, v), (0, y), (w, y))
        g.blit(vg, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        _HGRAD[k] = g
        if len(_HGRAD) > 600: _HGRAD.clear()
    return g

def _volume(t, floor=.55):
    """0.27: round a flat shape - darken towards its own edges (blurred silhouette) so limbs/plates read as cylinders."""
    w, h = t.get_size()
    if w < 6 or h < 6: return
    g = pygame.mask.from_surface(t, 10).to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 255))
    g = pygame.transform.smoothscale(pygame.transform.smoothscale(g, (max(2, w // 4), max(2, h // 4))), (w, h))
    g.fill((int(255 * (1 - floor)),) * 3, special_flags=pygame.BLEND_RGB_MULT)
    g.fill((int(255 * floor),) * 3, special_flags=pygame.BLEND_RGB_ADD)
    t.blit(g, (0, 0), special_flags=pygame.BLEND_RGB_MULT)

def _shp(S, pts, col, metal=False, lo=.55, hi=1.0, top=1.08, bot=.78, spec_x=.32, outline_c=None):
    """Shaded polygon.  metal=True adds a bright specular band and a dark core (polished plate)."""
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    x0, y0 = int(min(xs)) - 1, int(min(ys)) - 1; w = int(max(xs)) - x0 + 3; h = int(max(ys)) - y0 + 3
    if w < 2 or h < 2: return
    t = pygame.Surface((w, h), pygame.SRCALPHA)
    loc = [(p[0] - x0, p[1] - y0) for p in pts]
    pygame.draw.polygon(t, col, loc)
    t.blit(_hgrad(w, h, lo, hi, top, bot), (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    _volume(t, .5 if metal else .56)
    if metal:
        band = pygame.Surface((w, h), pygame.SRCALPHA)
        bx = int(w * spec_x); bw = max(2, int(w * .14))
        for i in range(bw):
            a = int(120 * (1 - abs(i - bw / 2) / (bw / 2)) ** 1.5)
            pygame.draw.line(band, (a, a, a, 255), (bx + i, 0), (bx + i, h))
        m = pygame.Surface((w, h), pygame.SRCALPHA); pygame.draw.polygon(m, (255, 255, 255, 255), loc)
        band.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        t.blit(band, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    S.blit(t, (x0, y0))
    pygame.draw.polygon(S, outline_c or shade(col, .32), pts, 1)

def _seg(S, p0, p1, w0, w1, col, metal=False, lo=.55):
    """Tapered limb segment from p0 (width w0) to p1 (width w1), shaded across its width."""
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]; d = math.hypot(dx, dy) or 1
    nx, ny = -dy / d, dx / d
    pts = [(p0[0] + nx * w0 / 2, p0[1] + ny * w0 / 2), (p1[0] + nx * w1 / 2, p1[1] + ny * w1 / 2),
           (p1[0] - nx * w1 / 2, p1[1] - ny * w1 / 2), (p0[0] - nx * w0 / 2, p0[1] - ny * w0 / 2)]
    _shp(S, pts, col, metal, lo=lo)
    pygame.draw.circle(S, shade(col, .8), (int(p1[0]), int(p1[1])), max(1, int(w1 / 2)))

def _metal_like(spec):
    return spec.get("head") in ("helm", "beardhelm") and not spec.get("robe") and not spec.get("bones")

def _face(S, spec, hx, hy, skin, eye, head):
    """Small, mostly shadowed face (3/4 view facing right) on the 16px-radius head canvas."""
    pygame.draw.circle(S, shade(skin, .55), (hx, hy), 16)
    pygame.draw.circle(S, shade(skin, .82), (hx + 1, hy), 15)
    pygame.draw.circle(S, skin, (hx + 3, hy - 1), 12)
    pygame.draw.circle(S, shade(skin, 1.12), (hx + 1, hy - 5), 6)
    # jaw shadow and cheek
    pygame.draw.arc(S, shade(skin, .45), (hx - 12, hy - 4, 28, 20), 3.6, 5.9, 3)
    if head == "skull":
        pygame.draw.circle(S, (24, 16, 16), (hx + 7, hy - 2), 5); pygame.draw.circle(S, (24, 16, 16), (hx - 1, hy - 2), 4)
        pygame.draw.circle(S, (255, 70, 50), (hx + 7, hy - 2), 2)
        pygame.draw.polygon(S, (24, 16, 16), [(hx + 3, hy + 3), (hx + 6, hy + 7), (hx + 1, hy + 7)])
        for k in range(4): pygame.draw.line(S, (40, 30, 26), (hx + k * 3 - 2, hy + 9), (hx + k * 3 - 2, hy + 13), 1)
        return
    # 0.26: readable features at game scale - eye sockets, eyes, brows, nose shadow, mouth, cheek light
    pygame.draw.ellipse(S, shade(skin, .62), (hx + 1, hy - 6, 18, 9))                                        # eye socket shadow
    brow = spec.get("brow", (52, 36, 26))
    pygame.draw.line(S, brow, (hx + 1, hy - 8), (hx + 10, hy - 9), 5); pygame.draw.line(S, brow, (hx + 12, hy - 9), (hx + 18, hy - 7), 4)
    ec = eye or (28, 20, 18)
    pygame.draw.ellipse(S, (236, 228, 214), (hx + 3, hy - 4, 7, 5)); pygame.draw.ellipse(S, (236, 228, 214), (hx + 12, hy - 4, 5, 5))
    pygame.draw.ellipse(S, ec, (hx + 5, hy - 4, 5, 6)); pygame.draw.ellipse(S, ec, (hx + 13, hy - 4, 4, 6))
    pygame.draw.ellipse(S, (12, 8, 10), (hx + 6, hy - 3, 3, 4)); pygame.draw.ellipse(S, (12, 8, 10), (hx + 14, hy - 3, 2, 4))
    if eye: pygame.draw.circle(S, (255, 255, 255), (hx + 7, hy - 3), 1)
    pygame.draw.polygon(S, shade(skin, .6), [(hx + 13, hy - 1), (hx + 19, hy + 5), (hx + 13, hy + 6)])      # nose shadow side
    pygame.draw.polygon(S, shade(skin, 1.12), [(hx + 13, hy - 2), (hx + 17, hy + 4), (hx + 13, hy + 4)])   # nose
    pygame.draw.line(S, shade(skin, .3), (hx + 6, hy + 10), (hx + 15, hy + 9), 3)                             # mouth
    pygame.draw.line(S, shade(skin, .75), (hx + 8, hy + 12), (hx + 13, hy + 12), 1)
    pygame.draw.circle(S, mix(skin, (230, 130, 120), .25), (hx + 5, hy + 4), 3)                               # cheek
    if isinstance(spec.get("beard"), tuple):
        bc = spec["beard"]
        pygame.draw.polygon(S, bc, [(hx - 4, hy + 2), (hx + 2, hy + 14), (hx + 10, hy + 18), (hx + 16, hy + 12), (hx + 15, hy + 9), (hx + 6, hy + 12), (hx + 1, hy + 4)])
        pygame.draw.line(S, shade(bc, 1.3), (hx + 2, hy + 8), (hx + 9, hy + 15), 1)

def _draw_head(spec, skin, eye):
    """The original head/hat/helmet art, re-used on a separate canvas and scaled down onto the taller body."""
    H = pygame.Surface((130, 140), pygame.SRCALPHA)
    S = H; hx, hy = 64, 78
    head = spec.get("head", "hair")
    _face(S, spec, hx, hy, skin, eye, head)
    hl = spec.get("helmlvl", 0)
    if hl >= 1 and spec.get("helmtier"):
        ht = spec["helmtier"]
        if head in ("helm", "beardhelm", "hat", "hood", "circlet", "crown", "feathers", "antlers", "hair", "warhelm", "topknot"):
            pygame.draw.polygon(S, ht, [(hx - 2, hy - 18), (hx + 12, hy - 28 - hl * 3), (hx + 8, hy - 14)])
            pygame.draw.polygon(S, shade(ht, 1.35), [(hx - 8, hy - 16), (hx + 2, hy - 30 - hl * 4), (hx + 2, hy - 15)])
    if head == "helm" or head == "beardhelm":
        hc = spec.get("helmc", (170, 174, 186))
        # great helm: domed skull, cheek plates, eye slit, nasal and a crest ridge
        _shp(S, [(hx - 18, hy + 2), (hx - 17, hy - 10), (hx - 8, hy - 19), (hx + 6, hy - 20), (hx + 16, hy - 12), (hx + 19, hy - 2), (hx + 19, hy + 12), (hx + 8, hy + 16), (hx - 4, hy + 16), (hx - 18, hy + 12)],
             hc, True, lo=.45, spec_x=.28)
        pygame.draw.line(S, (14, 10, 10), (hx + 2, hy - 2), (hx + 19, hy - 2), 4)            # visor slit
        if eye: pygame.draw.line(S, eye, (hx + 6, hy - 2), (hx + 17, hy - 2), 2)
        pygame.draw.line(S, shade(hc, 1.35), (hx - 8, hy - 18), (hx + 8, hy - 19), 2)
        pygame.draw.line(S, spec["trim"], (hx - 18, hy + 3), (hx + 19, hy + 3), 2)
        for k in range(3): pygame.draw.circle(S, shade(spec["trim"], 1.2), (hx - 12 + k * 6, hy + 8), 1)
        if head == "beardhelm":
            pygame.draw.polygon(S, (230, 236, 246), [(hx - 2, hy + 12), (hx + 16, hy + 12), (hx + 8, hy + 34)])
            pygame.draw.line(S, (190, 200, 216), (hx + 7, hy + 14), (hx + 8, hy + 30), 1)
    elif head == "hood":
        hc = spec.get("hoodc", (60, 60, 60))
        _shp(S, [(hx - 20, hy + 20), (hx - 20, hy - 6), (hx - 6, hy - 22), (hx + 10, hy - 20), (hx + 19, hy - 4), (hx + 16, hy + 4), (hx + 8, hy - 9), (hx - 2, hy + 4), (hx + 2, hy + 22)], hc, lo=.5)
        # the face inside the cowl is in deep shadow
        pygame.draw.polygon(S, (16, 12, 14), [(hx + 1, hy - 7), (hx + 10, hy - 10), (hx + 16, hy + 2), (hx + 12, hy + 12), (hx + 2, hy + 10)])
        if spec.get("mask"):
            pygame.draw.rect(S, (30, 30, 34), (hx + 3, hy + 3, 14, 7))
        if eye:
            pygame.draw.circle(S, eye, (hx + 10, hy), 2)
        else:
            pygame.draw.line(S, shade(skin, .7), (hx + 7, hy), (hx + 12, hy), 2)
    elif head == "hat":
        hc = spec.get("hatc", (70, 44, 142))
        pygame.draw.ellipse(S, shade(hc, .55), (hx - 28, hy - 14, 58, 14))
        pygame.draw.ellipse(S, shade(hc, .85), (hx - 27, hy - 15, 56, 11))
        _shp(S, [(hx - 15, hy - 11), (hx + 15, hy - 11), (hx + 4, hy - 36), (hx - 12, hy - 58), (hx - 6, hy - 36)], hc, lo=.5)
        pygame.draw.line(S, spec["trim"], (hx - 15, hy - 13), (hx + 15, hy - 13), 3)
    elif head == "circlet":
        hair = spec.get("hair", (190, 170, 140))
        pygame.draw.circle(S, shade(hair, .8), (hx - 3, hy - 3), 16, draw_top_left=True, draw_top_right=True, draw_bottom_left=True)
        pygame.draw.line(S, (230, 200, 120), (hx - 16, hy - 7), (hx + 16, hy - 7), 3)
        pygame.draw.circle(S, (120, 200, 255), (hx + 12, hy - 7), 3)
    elif head == "crown":
        hc = spec.get("hair", (200, 200, 205))
        pygame.draw.circle(S, shade(hc, .75), (hx - 3, hy - 3), 16, draw_top_left=True, draw_top_right=True, draw_bottom_left=True)
        gold = (236, 196, 70)
        pygame.draw.rect(S, gold, (hx - 15, hy - 14, 24, 7))
        for k in range(4):
            pygame.draw.polygon(S, gold, [(hx - 15 + k * 7, hy - 14), (hx - 12 + k * 7, hy - 25), (hx - 9 + k * 7, hy - 14)])
        pygame.draw.circle(S, (220, 40, 50), (hx - 3, hy - 11), 2)
    elif head == "hair":
        hc = spec.get("hair", (70, 46, 30))
        pygame.draw.circle(S, shade(hc, .75), (hx - 3, hy - 3), 16, draw_top_left=True, draw_top_right=True, draw_bottom_left=True)
        pygame.draw.circle(S, hc, (hx - 2, hy - 6), 12, draw_top_left=True, draw_top_right=True)
        for k in range(4): pygame.draw.line(S, shade(hc, 1.25), (hx - 10 + k * 5, hy - 15), (hx - 14 + k * 5, hy - 4), 1)
        if spec.get("beard"):
            pygame.draw.polygon(S, hc, [(hx, hy + 5), (hx + 16, hy + 4), (hx + 8, hy + 22), (hx + 2, hy + 18)])
    elif head == "bandana":
        _shp(S, [(hx - 16, hy - 2), (hx - 12, hy - 14), (hx, hy - 18), (hx + 13, hy - 13), (hx + 16, hy - 4)], spec["bandana"], lo=.5)
        pygame.draw.polygon(S, shade(spec["bandana"], .7), [(hx - 14, hy - 4), (hx - 28, hy + 8), (hx - 22, hy - 8)])
        pygame.draw.rect(S, (40, 30, 30), (hx + 4, hy + 4, 14, 7))
    elif head == "ears":
        pygame.draw.polygon(S, shade(skin, .8), [(hx - 10, hy - 4), (hx - 32, hy - 16), (hx - 12, hy + 4)])
        pygame.draw.polygon(S, skin, [(hx + 6, hy - 9), (hx + 26, hy - 24), (hx + 14, hy - 1)])
        pygame.draw.circle(S, (250, 220, 60), (hx + 10, hy - 1), 2)
    elif head == "snout":
        _shp(S, [(hx + 4, hy - 4), (hx + 26, hy - 1), (hx + 28, hy + 6), (hx + 6, hy + 10)], skin, lo=.6)
        pygame.draw.polygon(S, shade(skin, .8), [(hx - 8, hy - 10), (hx - 4, hy - 28), (hx + 4, hy - 12)])
        pygame.draw.circle(S, (30, 20, 20), (hx + 26, hy + 2), 2)
        pygame.draw.line(S, (240, 236, 220), (hx + 12, hy + 8), (hx + 14, hy + 12), 2)
        pygame.draw.circle(S, eye or (230, 180, 60), (hx + 8, hy - 3), 2)
    elif head == "tusks":
        pygame.draw.polygon(S, (240, 236, 220), [(hx + 7, hy + 9), (hx + 11, hy - 1), (hx + 13, hy + 9)])
        pygame.draw.line(S, shade(skin, .45), (hx + 2, hy - 8), (hx + 15, hy - 5), 3)
    elif head == "horns":
        for sgn in (-1, 1):
            pygame.draw.polygon(S, (200, 190, 160) if sgn < 0 else (232, 222, 192), [(hx + sgn * 8, hy - 10), (hx + sgn * 26, hy - 30), (hx + sgn * 20, hy - 42), (hx + sgn * 22, hy - 28), (hx + sgn * 14, hy - 7)])
    elif head == "feathers":
        pygame.draw.circle(S, spec.get("hair", (40, 30, 26)), (hx - 3, hy - 4), 15, draw_top_left=True, draw_top_right=True, draw_bottom_left=True)
        for k, c in enumerate(((180, 60, 50), (200, 170, 80), (80, 130, 180))):
            pygame.draw.polygon(S, c, [(hx - 10 + k * 3, hy - 12), (hx - 22 + k * 6, hy - 40 + k * 4), (hx - 6 + k * 3, hy - 14)])
        pygame.draw.line(S, (200, 196, 180), (hx - 15, hy - 3), (hx + 14, hy - 3), 3)
    elif head == "antlers":
        pygame.draw.circle(S, spec.get("hair", (110, 70, 40)), (hx - 3, hy - 4), 15, draw_top_left=True, draw_top_right=True, draw_bottom_left=True)
        for sgn in (-1, 1):
            bx0 = hx + sgn * 7; ac = (176, 156, 120) if sgn < 0 else (204, 184, 146)
            pygame.draw.line(S, ac, (bx0, hy - 12), (bx0 + sgn * 12, hy - 40), 4)
            pygame.draw.line(S, ac, (bx0 + sgn * 6, hy - 26), (bx0 + sgn * 18, hy - 30), 3)
            pygame.draw.line(S, ac, (bx0 + sgn * 10, hy - 34), (bx0 + sgn * 4, hy - 46), 3)
        pygame.draw.line(S, (70, 130, 60), (hx - 15, hy - 8), (hx + 14, hy - 8), 3)
    elif head == "warhelm":
        hc = spec.get("helmc", (124, 128, 138)); hair = spec.get("hair", (176, 92, 44))
        if spec.get("warpaint"):
            pygame.draw.line(S, spec["warpaint"], (hx + 3, hy + 2), (hx + 15, hy + 4), 3)
        pygame.draw.polygon(S, hair, [(hx - 4, hy + 7), (hx + 16, hy + 6), (hx + 10, hy + 24), (hx + 4, hy + 32), (hx + 1, hy + 22)])
        pygame.draw.line(S, shade(hair, .7), (hx + 4, hy + 12), (hx + 4, hy + 30), 2)
        _shp(S, [(hx - 17, hy - 2), (hx - 13, hy - 14), (hx, hy - 20), (hx + 13, hy - 14), (hx + 17, hy - 2)], hc, True, lo=.45)
        pygame.draw.line(S, spec["trim"], (hx - 17, hy - 3), (hx + 17, hy - 3), 3)
        pygame.draw.rect(S, hc, (hx + 7, hy - 3, 4, 12))
        for sgn in (-1, 1):
            pygame.draw.polygon(S, (206, 196, 166) if sgn < 0 else (236, 226, 196), [(hx + sgn * 12, hy - 10), (hx + sgn * 30, hy - 22), (hx + sgn * 32, hy - 40), (hx + sgn * 22, hy - 24), (hx + sgn * 14, hy - 16)])
    elif head == "topknot":
        hair = spec.get("hair", (30, 24, 22))
        pygame.draw.circle(S, hair, (hx - 4, hy - 21), 6)
        pygame.draw.line(S, hair, (hx - 4, hy - 16), (hx - 3, hy - 12), 4)
        sash = spec.get("sash", spec["trim"])
        pygame.draw.line(S, sash, (hx - 16, hy - 7), (hx + 15, hy - 7), 4)
        pygame.draw.polygon(S, sash, [(hx - 15, hy - 8), (hx - 28, hy + 2), (hx - 24, hy + 6), (hx - 14, hy - 4)])
    elif head == "bald":
        pygame.draw.line(S, shade(skin, .5), (hx + 2, hy - 8), (hx + 14, hy - 6), 2)
    if spec.get("_sl"): _set_helm(S, spec, hx, hy)
    if spec.get("flame"):
        for k, (dx, hh) in enumerate(((-8, 18), (0, 28), (8, 20))):
            pygame.draw.polygon(S, (255, 120, 30), [(hx + dx - 5, hy - 14), (hx + dx, hy - 14 - hh), (hx + dx + 5, hy - 14)])
            pygame.draw.polygon(S, (255, 220, 110), [(hx + dx - 2, hy - 14), (hx + dx, hy - 14 - hh * .6), (hx + dx + 2, hy - 14)])
        _spark(S, hx, hy - 24, 12, (255, 140, 50), 110)
    if spec.get("crown"):
        cc = spec["crown"]
        pygame.draw.polygon(S, cc, [(hx - 14, hy - 12), (hx - 15, hy - 26), (hx - 7, hy - 19), (hx, hy - 30), (hx + 7, hy - 19), (hx + 15, hy - 26), (hx + 14, hy - 12)])
        pygame.draw.circle(S, (255, 255, 255), (hx, hy - 24), 2)
    return H, (hx, hy)

HEAD_K = .84      # head canvas scale: a 16px-radius head becomes ~10px on the 150px-tall body

def draw_humanoid(spec, frame, attack=False, scale=1.0):
    """Returns sprite facing right.  frame 0..3 walk cycle, -1 idle."""
    spec = _apply_set(spec)
    S = pygame.Surface((220, 240), pygame.SRCALPHA)
    fx, fy = 110, 224                 # feet point (2x space)
    skin = spec.get("skin", (206, 164, 132)); body = spec["body"]; trim = spec["trim"]
    legs = spec["legs"]; boots = spec["boots"]
    metal = _metal_like(spec); bones = spec.get("bones"); robe = spec.get("robe")
    big = spec.get("head") in ("tusks", "bald", "beardhelm") and "skin" in spec     # brutes are broader
    bw = 1.18 if big else 1.0
    swing = (0, 1, 0, -1)[frame] if frame >= 0 else 0
    bob = abs(swing) * 2
    sh_y = fy - 122 - bob; waist_y = fy - 86 - bob; hip_y = fy - 78 - bob; knee_y = fy - 40
    top = fy - 169 - bob                                  # frame shared with the gear-set ornaments
    hx, hy = fx + 3, fy - 144 - bob
    cape = spec.get("cape_override") or spec.get("cape")
    # ---- wings (behind everything)
    if spec.get("wings"):
        wc = spec["wings"]; flap = 8 if frame in (1, 3) else -6
        _shp(S, [(fx - 6, sh_y + 6), (fx - 74, sh_y - 30 + flap), (fx - 66, sh_y + 20), (fx - 44, sh_y + 40)], shade(wc, .8), lo=.6)
        _shp(S, [(fx + 4, sh_y + 6), (fx + 58, sh_y - 36 + flap), (fx + 54, sh_y + 14), (fx + 30, sh_y + 36)], wc, lo=.6)
        for k in range(3):
            pygame.draw.line(S, shade(wc, .5), (fx - 6, sh_y + 6), (fx - 70 + k * 10, sh_y - 26 + flap + k * 18), 1)
    # ---- cape behind the body: long, heavy, swaying
    if cape:
        sway = swing * 4
        _shp(S, [(fx - 18 * bw, sh_y + 2), (fx + 6, sh_y + 2), (fx + 4 + sway, fy - 22), (fx - 8 + sway, fy - 10), (fx - 30 * bw + sway, fy - 14), (fx - 26 * bw, waist_y)],
             shade(cape, .85), lo=.5, top=1.0, bot=.62)
        for k in range(3):
            x0 = fx - 18 + k * 7
            pygame.draw.line(S, shade(cape, .5), (x0, sh_y + 20), (x0 - 4 + sway, fy - 16), 1)
    if spec.get("pack"):
        _shp(S, [(fx - 30, sh_y + 2), (fx - 12, sh_y), (fx - 12, waist_y + 4), (fx - 30, waist_y + 6)], (110, 78, 46), lo=.55)
        pygame.draw.line(S, (70, 50, 30), (fx - 30, sh_y + 16), (fx - 12, sh_y + 14), 2)
    # ---- legs (back leg first, darker)
    lw_th = (7 if bones else 13) * bw; lw_kn = (5 if bones else 10) * bw; lw_an = (5 if bones else 8) * bw
    feet = []
    for side, sgn in ((0, -1), (1, 1)):
        off = swing * 10 * sgn + sgn * 3
        dk = .7 if side == 0 else 1.0
        hipx = fx - 6 * bw + side * 11 * bw
        ankx = hipx + off; anky = fy - 14
        knx = (hipx + ankx) / 2 + 5 + abs(off) * .15; kny = knee_y - abs(swing) * 2
        lc = shade(legs, dk)
        if not robe:
            _seg(S, (hipx, hip_y), (knx, kny), lw_th, lw_kn, lc, metal)
            _seg(S, (knx, kny), (ankx, anky), lw_kn * 1.12, lw_an, lc, metal)
            if not metal: _seg(S, (hipx, hip_y), (knx, kny), lw_th * 1.08, lw_kn, lc)
            if metal:   # knee cop
                pygame.draw.circle(S, shade(lc, .55), (int(knx + 1), int(kny)), int(lw_kn * .62) + 1)
                pygame.draw.circle(S, shade(lc, 1.2), (int(knx), int(kny - 1)), int(lw_kn * .48))
        feet.append((ankx, anky, dk))
        # boots: shin cuff and a foot pointing the way we face
        bc = shade(boots, dk)
        if not bones:
            _shp(S, [(ankx - 6 * bw, anky - 12), (ankx + 6 * bw, anky - 12), (ankx + 7 * bw, anky + 6), (ankx + 15 * bw, anky + 9), (ankx + 15 * bw, anky + 13), (ankx - 7 * bw, anky + 13)], bc, metal, lo=.5)
            pygame.draw.line(S, shade(bc, 1.25), (ankx - 6 * bw, anky - 11), (ankx + 6 * bw, anky - 11), 2)
        else:
            pygame.draw.line(S, body, (ankx, anky), (ankx + 9, anky + 12), 4)
    # ---- back arm (+ shield carried on it)
    swa = -swing * 7
    bsh = (fx - 15 * bw, sh_y + 5); bel = (fx - 18 * bw + swa * .5, sh_y + 27); bhn = (fx - 15 * bw + swa, sh_y + 47)
    arm_c = shade(body, .62) if not bones else shade(body, .7)
    _seg(S, bsh, bel, (8 if bones else 11) * bw, (6 if bones else 9) * bw, arm_c, metal)
    _seg(S, bel, bhn, (6 if bones else 9) * bw, (5 if bones else 8) * bw, arm_c, metal)
    pygame.draw.circle(S, shade(skin, .62), (int(bhn[0]), int(bhn[1] + 2)), 5)
    if spec.get("towershield"):
        tsc = spec["towershield"]
        _shp(S, [(fx - 44, sh_y + 2), (fx - 12, sh_y), (fx - 10, sh_y + 70), (fx - 27, sh_y + 82), (fx - 44, sh_y + 72)], tsc, True, lo=.5, spec_x=.25)
        pygame.draw.polygon(S, shade(trim, .8), [(fx - 44, sh_y + 2), (fx - 12, sh_y), (fx - 10, sh_y + 70), (fx - 27, sh_y + 82), (fx - 44, sh_y + 72)], 3)
        pygame.draw.line(S, trim, (fx - 27, sh_y + 6), (fx - 27, sh_y + 74), 3)
        pygame.draw.line(S, trim, (fx - 42, sh_y + 30), (fx - 12, sh_y + 29), 3)
        pygame.draw.circle(S, shade(trim, 1.3), (fx - 27, sh_y + 30), 5)
    elif spec.get("shield"):
        shc = spec.get("shieldc", (60, 90, 170))
        pts = [(fx - 40, sh_y + 12), (fx - 14, sh_y + 10), (fx - 13, sh_y + 40), (fx - 26, sh_y + 58), (fx - 40, sh_y + 42)]
        _shp(S, pts, shc, True, lo=.5, spec_x=.25)
        pygame.draw.polygon(S, shade(trim, .85), pts, 3)
        pygame.draw.line(S, trim, (fx - 27, sh_y + 14), (fx - 27, sh_y + 52), 2)
        pygame.draw.circle(S, shade(trim, 1.25), (fx - 27, sh_y + 28), 4)
    # ---- robe skirt (long, A-line)
    if robe:
        sway = swing * 3
        _shp(S, [(fx - 14 * bw, waist_y - 2), (fx + 14 * bw, waist_y - 2), (fx + 22 * bw + sway, fy - 22), (fx + 27 * bw + sway, fy - 7), (fx + 10 + sway, fy - 3),
                 (fx - 8 + sway, fy - 5), (fx - 27 * bw + sway, fy - 8), (fx - 22 * bw + sway, fy - 22)], body, lo=.5, bot=.7)
        for k in range(4):
            x0 = fx - 10 + k * 7
            pygame.draw.line(S, shade(body, .55), (x0, waist_y + 6), (x0 + (k - 1.5) * 4 + sway, fy - 8), 1)
        pygame.draw.line(S, trim, (fx - 24 * bw + sway, fy - 10), (fx + 24 * bw + sway, fy - 10), 3)
        pygame.draw.line(S, trim, (fx + 3, waist_y), (fx + 5 + sway, fy - 10), 2)
        for (ax, ay, dk) in feet:
            pygame.draw.ellipse(S, shade(boots, dk), (ax - 4, fy - 9, 18, 8))
    # ---- torso
    tw = 21 * bw; ww = 13 * bw
    if bones:
        pygame.draw.line(S, body, (fx, sh_y), (fx, hip_y), 5)
        for i in range(5):
            y = sh_y + 8 + i * 8
            pygame.draw.arc(S, body, (fx - 15 + i, y - 4, 30 - i * 2, 12), 3.3, 6.1, 3)
        pygame.draw.ellipse(S, body, (fx - 13, hip_y - 6, 26, 12), 3)
        pygame.draw.line(S, body, (fx - 18, sh_y + 2), (fx + 18, sh_y + 2), 4)
    else:
        torso = [(fx - tw + 4, sh_y - 3), (fx - 5, sh_y - 5), (fx + 5, sh_y - 5), (fx + tw - 4, sh_y - 3), (fx + tw, sh_y + 4), (fx + tw - 1, sh_y + 14), (fx + ww + 4, sh_y + 30), (fx + ww + 1, waist_y), (fx - ww, waist_y), (fx - ww - 3, sh_y + 30), (fx - tw + 1, sh_y + 14), (fx - tw, sh_y + 4)]
        _shp(S, torso, body, metal, lo=.52, spec_x=.3)
        if metal:
            # breastplate: central ridge, pectoral plates, and the lower lames
            pygame.draw.line(S, shade(body, 1.3), (fx - 2, sh_y + 6), (fx - 1, waist_y - 3), 2)
            pygame.draw.line(S, shade(body, .45), (fx + 1, sh_y + 6), (fx + 2, waist_y - 3), 1)
            pygame.draw.arc(S, shade(body, .45), (fx - tw + 4, sh_y + 6, tw * 2 - 8, 28), 3.5, 5.95, 2)
            for k in range(2):
                y = waist_y - 12 + k * 6
                pygame.draw.line(S, shade(body, .5), (fx - ww - 1, y), (fx + ww + 1, y), 1)
                pygame.draw.line(S, shade(body, 1.25), (fx - ww, y + 1), (fx + ww, y + 1), 1)
        else:
            # cloth/leather: soft folds and a laced collar
            for k in range(4):
                x = fx - 12 + k * 7
                pygame.draw.line(S, shade(body, .6), (x, sh_y + 10), (x + (k - 1.5) * 1.5, waist_y - 2), 1)
            pygame.draw.polygon(S, shade(body, .55), [(fx - 6, sh_y), (fx + 6, sh_y), (fx, sh_y + 12)])
        # hips / faulds
        _shp(S, [(fx - ww - 1, waist_y), (fx + ww + 2, waist_y), (fx + ww + 4, hip_y + 2), (fx - ww - 2, hip_y + 2)], shade(legs, .9), metal, lo=.5)
    if spec.get("apron"):
        _shp(S, [(fx - 4, waist_y - 18), (fx + 16, waist_y - 18), (fx + 18, knee_y + 6), (fx - 2, knee_y + 8)], spec["apron"], lo=.6)
    # tabard / tassets below the belt
    if not robe and not bones:
        if metal:
            for k, dx in enumerate((-9, 4)):
                _shp(S, [(fx + dx - 7, hip_y), (fx + dx + 7, hip_y), (fx + dx + 7, hip_y + 18), (fx + dx - 6, hip_y + 20)], shade(body, .92 - k * .08), True, lo=.5)
            tab = spec.get("cape") or shade(trim, .55)
            _shp(S, [(fx - 3, waist_y + 2), (fx + 7, waist_y + 2), (fx + 7, knee_y - 4), (fx + 2, knee_y), (fx - 3, knee_y - 4)], shade(tab, .9), lo=.55)
            pygame.draw.line(S, shade(trim, .9), (fx - 3, knee_y - 5), (fx + 2, knee_y - 1), 1); pygame.draw.line(S, shade(trim, .9), (fx + 2, knee_y - 1), (fx + 7, knee_y - 5), 1)
        else:
            sway = swing * 2
            _shp(S, [(fx - ww - 2, waist_y + 2), (fx + ww + 3, waist_y + 2), (fx + ww + 6 + sway, hip_y + 16), (fx - ww - 4 + sway, hip_y + 16)], shade(body, .85), lo=.5)
    # tier pauldron glow (gear tiers)
    tc = spec.get("tier"); tl = spec.get("tierlvl", 0)
    # belt + buckle
    if not bones:
        pygame.draw.line(S, shade(trim, .4), (fx - ww - 1, waist_y + 1), (fx + ww + 2, waist_y + 1), 6)
        pygame.draw.line(S, shade(trim, .85), (fx - ww - 1, waist_y), (fx + ww + 2, waist_y), 2)
        pygame.draw.rect(S, (214, 178, 96), (fx - 1, waist_y - 3, 7, 7), border_radius=1)
        pygame.draw.rect(S, (90, 66, 30), (fx + 1, waist_y - 1, 3, 3))
    if spec.get("_sl"): _set_body(S, spec, fx, top, swing)
    # pauldrons
    if not bones:
        pc = shade(trim, .95) if metal else shade(body, .95)
        for sd in (-1, 1):
            x = fx + sd * (tw - 3); y = sh_y + 4
            if metal:
                for k in range(3):
                    r = 11 - k * 2
                    _shp(S, [(x - r * 1.1, y + k * 5), (x - r * .7, y - r * .8 + k * 5), (x + r * .7, y - r * .9 + k * 5), (x + r * 1.15, y + k * 5), (x, y + r * .45 + k * 5)],
                         shade(pc if k == 0 else body, 1.0 - k * .08) if sd > 0 else shade(pc if k == 0 else body, .7 - k * .05), True, lo=.5)
            else:      # 0.26: soft shoulder seams instead of puffy balls
                pygame.draw.ellipse(S, shade(pc, .6 if sd < 0 else .82), (x - 8, y - 4, 16, 9))
                pygame.draw.arc(S, shade(pc, 1.12 if sd > 0 else .9), (x - 8, y - 5, 16, 10), .3, 2.8, 2)
        if tc and tl >= 1:
            for sd in (-1, 1):
                _sphere(S, (int(fx + sd * (tw - 3)), int(sh_y)), 6 + tl, tc)
    if tc and tl >= 2:
        pygame.draw.circle(S, shade(tc, .5), (fx + 1, sh_y + 20), 6)
        pygame.draw.circle(S, shade(tc, 1.5), (fx + 1, sh_y + 20), 4)
    if tc and tl >= 3:
        pygame.draw.polygon(S, shade(tc, .75), [(fx - 12, hip_y), (fx + 12, hip_y), (fx + 15, hip_y + 16), (fx, hip_y + 11), (fx - 15, hip_y + 16)])
    # ---- neck and head
    pygame.draw.rect(S, shade(skin, .55), (hx - 6, sh_y - 12, 12, 14), border_radius=4)
    eye = spec.get("eyes")
    H, (ohx, ohy) = _draw_head(spec, skin, eye)
    hk = HEAD_K * (1.22 if big else 1.0)
    Hs = pygame.transform.smoothscale(H, (int(H.get_width() * hk), int(H.get_height() * hk)))
    S.blit(Hs, (int(hx - ohx * hk), int(hy - ohy * hk)))
    # ---- front arm + weapon
    wpn = spec.get("weapon")
    fsh = (fx + 14 * bw, sh_y + 5)
    if wpn == "bow":
        ax, ay = fx + 30, sh_y + 20
        _seg(S, fsh, (fx + 22, sh_y + 14), 11 * bw, 9 * bw, body, metal)
        _seg(S, (fx + 22, sh_y + 14), (ax, ay), 9 * bw, 8 * bw, body, metal)
        pull = 14 if attack else 0
        pygame.draw.arc(S, (70, 44, 24), (ax - 9, ay - 50, 26, 100), -1.4, 1.4, 6)
        pygame.draw.arc(S, (140, 96, 52), (ax - 9, ay - 50, 26, 100), -1.4, 1.4, 3)
        pygame.draw.line(S, (220, 220, 210), (ax + 7, ay - 48), (ax - pull, ay), 1)
        pygame.draw.line(S, (220, 220, 210), (ax - pull, ay), (ax + 7, ay + 48), 1)
        if attack: pygame.draw.line(S, (200, 180, 140), (ax - pull, ay), (ax + 44, ay), 2)
        pygame.draw.circle(S, skin, (ax, ay), 5)
        if spec.get("_sl") and "weapon" in spec["_sp"]:
            for k in range(7):
                a = -1.4 + k * .47; _spark(S, ax + 6 + math.cos(a) * 8, ay + math.sin(a) * 48, 4, spec["_sl"]["glow"], 150)
    else:
        ang = -1.0 if not attack else .55
        if wpn in ("staff", "staffplain", "spear", "bostaff", "greataxe"):
            ang = -1.3 if not attack else -.1
        if attack:
            fel = (fx + 26 * bw, sh_y + 12); hxp, hyp = fx + 36 * bw, sh_y + 6
        else:
            fel = (fx + 19 * bw, sh_y + 27 + swing * 2); hxp, hyp = fx + 22 * bw, sh_y + 46 + swing * 3
        if wpn:
            _weapon(S, wpn, hxp, hyp, ang, spec)
            if wpn == "daggers":
                _weapon(S, "dagger", bhn[0], bhn[1], -0.4, spec)
        _seg(S, fsh, fel, (8 if bones else 12) * bw, (6 if bones else 10) * bw, body if not bones else body, metal)
        _seg(S, fel, (hxp, hyp), (6 if bones else 10) * bw, (5 if bones else 8) * bw, body if not bones else body, metal)
        if metal:   # gauntlet
            pygame.draw.circle(S, shade(body, .5), (int(hxp), int(hyp)), 7)
            pygame.draw.circle(S, shade(body, 1.15), (int(hxp - 1), int(hyp - 1)), 5)
        else:
            pygame.draw.circle(S, shade(skin, .7), (int(hxp), int(hyp)), 6)
            pygame.draw.circle(S, skin, (int(hxp - 1), int(hyp - 1)), 4)
        if spec.get("_sl") and "weapon" in spec["_sp"] and wpn: _set_weapon(S, spec, wpn, hxp, hyp, ang)
        if spec.get("candle"):
            pygame.draw.rect(S, (240, 230, 200), (fx - 22, sh_y - 30, 6, 14))
            pygame.draw.circle(S, (255, 200, 80), (fx - 19, sh_y - 34), 4)
    # ---- detail pass: grime, stitching, skin marks and species features, clipped to the silhouette
    def _hd(L):
        # 0.26: cloth folds and seams - soft vertical creases from the belt down, chest shading above
        for k in range(10):
            x = fx - 26 + k * 5.6
            spread = (k - 4.5) * (2.2 if robe else 1.0)
            pygame.draw.line(L, (0, 0, 0, 46), (x, waist_y + 8), (x + spread, fy - 10), 2)
            pygame.draw.line(L, (255, 250, 230, 26), (x + 2, waist_y + 8), (x + 2 + spread, fy - 12), 1)
        for k in range(4):
            y = sh_y + 10 + k * 7
            pygame.draw.line(L, (0, 0, 0, 30), (fx - 16 + k * 2, y), (fx + 14 - k * 2, y + 3), 1)
        pygame.draw.line(L, (0, 0, 0, 60), (fx - 18, waist_y - 2), (fx + 18, waist_y - 2), 2)
        for k in range(26):          # fine grime / wear, the gritty look
            px = fx - 24 + h01(k, 21, 9) * 48; py = sh_y + h01(k, 22, 9) * (fy - sh_y)
            pygame.draw.circle(L, (0, 0, 0, 40), (int(px), int(py)), 1)
        for k in range(6):
            pygame.draw.line(L, (*shade(trim, 1.3), 120), (fx - 12 + k * 5, waist_y + 4), (fx - 10 + k * 5, waist_y + 4), 1)
        if spec.get("fur"):
            fc = spec["fur"]
            for k in range(46):
                px = fx - 22 + h01(k, 8, 5) * 44; py = sh_y - 4 + h01(k, 9, 5) * (fy - sh_y - 10)
                pygame.draw.line(L, (*shade(fc, .72), 170), (px, py), (px - 2, py + 7), 2); pygame.draw.line(L, (*shade(fc, 1.12), 130), (px + 1, py), (px - 1, py + 5), 1)
        if spec.get("wraps"):
            for k in range(8):
                y_ = sh_y + k * 6
                pygame.draw.line(L, (232, 220, 186, 200), (fx - 20, y_), (fx + 20, y_ + 7), 3); pygame.draw.line(L, (130, 108, 74, 150), (fx - 20, y_ + 3), (fx + 20, y_ + 10), 1)
            for k in range(8):
                y_ = hip_y + k * 9
                for sd in (-6, 6): pygame.draw.line(L, (232, 220, 186, 200), (fx + sd - 6, y_), (fx + sd + 6, y_ + 5), 3)
        hd = spec.get("head")
        if hd in ("tusks", "horns", "ears", "snout", "bald", "beardhelm") and "skin" in spec:
            sk = spec["skin"]
            for k in range(6):
                px = fx - 14 + h01(k, 3, 5) * 28; py = sh_y + 4 + h01(k, 4, 5) * 36
                pygame.draw.circle(L, (*shade(sk, .6), 90), (int(px), int(py)), 2)
            pygame.draw.line(L, (*shade(sk, .5), 150), (fx - 6, sh_y + 10), (fx + 4, sh_y + 18), 2)
        if hd == "horns":
            for k in range(3):
                pygame.draw.lines(L, (255, 150, 50, 200), False, [(fx - 12 + k * 10, sh_y + 4), (fx - 8 + k * 10, sh_y + 18), (fx - 14 + k * 10, sh_y + 30)], 2)
        if hd == "beardhelm":
            for k in range(8):
                px = fx - 14 + k * 4; pygame.draw.polygon(L, (230, 246, 255, 200), [(px, sh_y), (px + 2, sh_y - 6), (px + 4, sh_y)])
        if hd == "tusks" and spec.get("skin", (0, 0, 0))[1] > 120 and spec["skin"][0] < 100:
            pygame.draw.line(L, (200, 40, 40, 190), (fx - 14, sh_y + 10), (fx + 12, sh_y + 16), 3)
            pygame.draw.line(L, (200, 40, 40, 190), (fx - 14, sh_y + 18), (fx + 12, sh_y + 24), 3)
    _inlay(S, _hd)
    polish(S, rim=(170, 130, 30) if spec.get('elite') else (60, 54, 44), ao=.78)
    spr = outline(_finish(S, .5 * scale), (14, 10, 8, 95))
    return spr, (spr.get_width() // 2, int(fy * .5 * scale) + 1)


def _ball(S, rect, col):
    """Shaded ellipse: dark rim, body colour, upper-left highlight."""
    x, y, w, h = rect
    pygame.draw.ellipse(S, shade(col, .55), (x, y, w, h))
    pygame.draw.ellipse(S, shade(col, .85), (x + 1, y + 1, w - 2, h - 2))
    pygame.draw.ellipse(S, col, (x + w * .06, y + h * .04, w * .84, h * .78))
    pygame.draw.ellipse(S, shade(col, 1.25), (x + w * .16, y + h * .08, w * .5, h * .34))

def _fur(S, x0, x1, y_top, y_bot, col, n=26, seed=3):
    import random as _r
    r = _r.Random(seed)
    for _ in range(n):
        x = r.uniform(x0, x1); y = r.uniform(y_top, y_bot)
        c = shade(col, r.choice((.62, .8, 1.22, 1.38)))
        pygame.draw.line(S, c, (x, y), (x - 5, y + 4), 2)

def draw_beast(spec, frame, attack=False, scale=1.0, kind="beast"):
    S = pygame.Surface((220, 200), pygame.SRCALPHA)
    fx, fy = 110, 180
    c = spec["c"]; dark = shade(c, .7); light = shade(c, 1.2)
    swing = (0, 1, 0, -1)[frame] if frame >= 0 else 0
    lunge = 10 if attack else 0
    if kind == "beast":
        low = spec.get("low"); long = spec.get("long")
        bl = 46 if long else 36; bh = 18 if low else 22
        by = fy - (34 if low else 48)
        for i, (ox, side) in enumerate(((-bl + 10, 0), (bl - 12, 0), (-bl + 18, 1), (bl - 4, 1))):
            off = swing * 6 * (1 if i % 2 else -1)
            col = dark if side == 0 else c
            hip = (fx + ox, by + 4); kn = (fx + ox + off * .4 + 4, by + (fy - by) * .55); pw = (fx + ox + off, fy - 5)
            _seg(S, hip, kn, 15, 9, col); _seg(S, kn, pw, 9, 6, col)
            pygame.draw.ellipse(S, shade(col, .6), (pw[0] - 5, fy - 9, 15, 8)); pygame.draw.ellipse(S, shade(col, .95), (pw[0] - 4, fy - 10, 13, 7))
        if spec.get("tail") or long:
            tl = 60 if long else 34
            pygame.draw.line(S, dark, (fx - bl, by - 2), (fx - bl - tl, by + (14 if long else -16)), 8 if long else 6)
        _ball(S, (fx - bl, by - bh, bl * 2, bh * 2), c)
        if spec.get("hump"):
            _ball(S, (fx + bl - 44, by - bh - 16, 50, 36), shade(c, 1.08))
        _fur(S, fx - bl + 8, fx + bl - 8, by - bh + 4, by + bh - 6, c, 34, int(sum(c)))
        pygame.draw.ellipse(S, shade(c, 1.35), (fx - bl + 14, by - bh + 3, bl * 1.1, bh * .5))
        if spec.get("spikes"):
            for i in range(5):
                x = fx - bl + 14 + i * (bl * 2 - 28) / 4
                pygame.draw.polygon(S, spec.get('spikec', shade(c, .55)), [(x - 6, by - bh + 4), (x, by - bh - 12), (x + 6, by - bh + 4)])
        if spec.get("bristle"):
            for i in range(8):
                x = fx - bl + 10 + i * 8
                pygame.draw.line(S, dark, (x, by - bh + 4), (x + 3, by - bh - 6), 3)
        hx, hy = fx + bl + 6 + lunge, by - (6 if low else 14)
        _ball(S, (hx - 19, hy - 19, 38, 38), c)
        _ball(S, (hx + 2, hy - 5, 30, 18), shade(c, 1.15))
        pygame.draw.line(S, shade(c, .4), (hx + 6, hy + 6), (hx + 28, hy + 7), 2)
        _fur(S, hx - 14, hx + 8, hy - 16, hy + 4, c, 8, int(sum(c)) + 5)
        pygame.draw.circle(S, (20, 20, 20), (hx + 29, hy + 2), 3)
        pygame.draw.circle(S, (250, 200, 60) if not spec.get("cracks") else (255, 160, 40), (hx + 6, hy - 6), 3)
        if spec.get("roundears"):
            for ex_ in (-9, 6): pygame.draw.circle(S, dark, (hx + ex_, hy - 18), 9); pygame.draw.circle(S, shade(c, 1.3), (hx + ex_ + 1, hy - 17), 5)
        elif spec.get("ears"):
            pygame.draw.polygon(S, dark, [(hx - 10, hy - 10), (hx - 6, hy - 32), (hx + 2, hy - 14)])
            pygame.draw.polygon(S, c, [(hx - 2, hy - 12), (hx + 4, hy - 32), (hx + 10, hy - 12)])
        if spec.get("tusks"):
            pygame.draw.polygon(S, (240, 236, 220), [(hx + 20, hy + 8), (hx + 30, hy - 6), (hx + 24, hy + 10)])
        if attack:
            pygame.draw.polygon(S, (120, 20, 20), [(hx + 14, hy + 6), (hx + 32, hy + 8), (hx + 16, hy + 14)])
        if spec.get("cracks"):
            cr = spec["cracks"]
            pygame.draw.line(S, cr, (fx - 20, by - 10), (fx + 4, by + 2), 3)
            pygame.draw.line(S, cr, (fx + 4, by + 2), (fx + 24, by - 8), 3)
            pygame.draw.line(S, cr, (hx - 8, hy + 4), (hx + 6, hy + 8), 2)
        # 0.21 detail: claws, paws, musculature, fur streaks, teeth, whiskers and eye glint
        for i, ox in enumerate((-bl + 10, bl - 12, -bl + 18, bl - 4)):
            off = swing * 6 * (1 if i % 2 else -1); px_ = fx + ox + off
            pygame.draw.ellipse(S, shade(c, .55), (px_ - 7, fy - 7, 15, 7))
            for cl in (-3, 0, 3):
                pygame.draw.line(S, (255, 170, 70) if spec.get("cracks") else (236, 230, 210), (px_ + cl, fy - 3), (px_ + cl + 2, fy + 2), 2)
        def _bd(L):
            pygame.draw.ellipse(L, (*shade(c, .65), 120), (fx + bl - 40, by - bh + 8, 34, bh * 1.5))
            pygame.draw.ellipse(L, (*shade(c, 1.35), 90), (fx - bl + 4, by - bh + 4, bl * .9, bh * .7))
            pygame.draw.ellipse(L, (*shade(c, .55), 120), (fx - bl + 10, by + bh * .3, bl * 2 - 24, bh * .9))
            for k in range(16):
                x = fx - bl + 8 + k * (bl * 2 - 16) / 16
                pygame.draw.line(L, (*shade(c, .6), 150), (x, by - bh + 6 + k % 3 * 3), (x - 5, by + bh - 8), 1)
            for k in range(10):
                x = fx - bl + 14 + k * (bl * 2 - 28) / 10
                pygame.draw.line(L, (*shade(c, 1.45), 120), (x, by - bh + 3), (x - 3, by - bh + 14), 1)
            pygame.draw.line(L, (*shade(c, .5), 160), (hx - 14, hy - 12), (hx + 12, hy - 9), 2)      # brow
        _inlay(S, _bd)
        ec = (255, 160, 40) if spec.get("cracks") else (250, 200, 60)
        pygame.draw.ellipse(S, (250, 246, 230), (hx + 1, hy - 10, 11, 8)); pygame.draw.ellipse(S, ec, (hx + 3, hy - 9, 8, 7))
        pygame.draw.ellipse(S, (12, 8, 6), (hx + 5, hy - 9, 4, 7)); pygame.draw.circle(S, (255, 255, 255), (hx + 5, hy - 8), 1)
        pygame.draw.line(S, shade(c, .35), (hx - 1, hy - 12), (hx + 13, hy - 9), 3)
        pygame.draw.ellipse(S, (60, 40, 40), (hx + 25, hy - 1, 9, 7)); pygame.draw.circle(S, (190, 170, 170), (hx + 28, hy), 1)
        for k in range(6):      # neck ruff
            pygame.draw.polygon(S, shade(c, 1.1 if k % 2 else .85), [(hx - 18, hy - 12 + k * 5), (hx - 32, hy - 6 + k * 5), (hx - 16, hy - 4 + k * 5)])
        for k in (-1, 0, 1):
            pygame.draw.line(S, (236, 232, 220), (hx + 22, hy + 4), (hx + 38, hy + 2 + k * 4), 1)    # whiskers
        if attack:
            for k in range(3):
                pygame.draw.polygon(S, (248, 244, 232), [(hx + 16 + k * 5, hy + 7), (hx + 19 + k * 5, hy + 7), (hx + 17 + k * 5, hy + 13)])
        if spec.get("ears") and not spec.get("roundears"):
            pygame.draw.polygon(S, shade(c, 1.3), [(hx - 1, hy - 14), (hx + 3, hy - 27), (hx + 7, hy - 14)])
            pygame.draw.polygon(S, (214, 150, 150), [(hx + 1, hy - 14), (hx + 4, hy - 24), (hx + 6, hy - 14)])
        if spec.get("tail"):
            for k in range(4): pygame.draw.line(S, shade(c, 1.2), (fx - bl - 8 - k * 5, by - 8 - k * 3), (fx - bl - 14 - k * 5, by - 12 - k * 4), 1)
    elif kind == "spider":
        by = fy - 34
        for i in range(4):
            for sgn, col in ((-1, dark), (1, c)):
                ox = -14 + i * 12; off = swing * 4 * (1 if i % 2 else -1)
                kx, ky = fx + ox + sgn * 6, by - 24
                _tube(S, _bez((fx + ox, by), (kx + off - sgn * 2, ky - 10), (kx + off, ky), 5), 7, 6, col)
                _tube(S, _bez((kx + off, ky), (kx + off + sgn * 10, ky + 6), (fx + ox + sgn * 22 + off, fy - 4), 5), 6, 3, col)
        _ball(S, (fx - 50, by - 26, 56, 46), c)
        pygame.draw.ellipse(S, (170, 30, 30), (fx - 38, by - 14, 22, 16))
        pygame.draw.polygon(S, (230, 200, 60), [(fx - 27, by - 14), (fx - 20, by - 4), (fx - 34, by - 4)])
        _fur(S, fx - 46, fx, by - 22, by + 14, c, 14, 9)
        _ball(S, (fx - 1 + lunge, by - 13, 30, 30), shade(c, 1.2))
        for (ex, ey) in ((22, -4), (26, 2), (18, 0)):
            pygame.draw.circle(S, (255, 50, 40), (fx + ex + lunge, by + ey), 3)
        pygame.draw.line(S, (230, 230, 220), (fx + 26 + lunge, by + 10), (fx + 30 + lunge, by + 18), 3)
        # 0.21 detail: hairy legs and knees, chevron-marked abdomen, eight eyes, venom
        for i in range(4):
            for sgn in (-1, 1):
                ox = -14 + i * 12; off = swing * 4 * (1 if i % 2 else -1)
                kx, ky = fx + ox + sgn * 6 + off, by - 24; ex, ey = fx + ox + sgn * 22 + off, fy - 4
                for t in (.25, .5, .75):
                    qx, qy = kx + (ex - kx) * t, ky + (ey - ky) * t
                    pygame.draw.line(S, (96, 86, 100), (qx, qy), (qx + sgn * 4, qy - 3), 1)
                pygame.draw.circle(S, (118, 106, 122), (int(kx), int(ky)), 3)
        def _sd(L):
            for k in range(4):
                x = fx - 44 + k * 9
                pygame.draw.lines(L, (190, 40, 50, 200), False, [(x, by - 18), (x + 8, by - 4), (x + 16, by - 18)], 2)
            pygame.draw.ellipse(L, (255, 255, 255, 60), (fx - 40, by - 24, 26, 12))
            pygame.draw.ellipse(L, (0, 0, 0, 90), (fx - 46, by - 2, 50, 18))
        _inlay(S, _sd)
        for k, (ex, ey) in enumerate(((13, -9), (19, -10), (24, -6), (12, -3), (28, 1))):
            pygame.draw.circle(S, (255, 70, 56), (fx + ex + lunge, by + ey), 2); _glint(S, fx + ex + lunge - 1, by + ey - 1, 1)
        pygame.draw.circle(S, (160, 255, 120), (fx + 31 + lunge, by + 22), 2)
        pygame.draw.line(S, (230, 230, 220), (fx + 20 + lunge, by + 10), (fx + 22 + lunge, by + 18), 3)
    elif kind == "serpent":
        pts = []
        for i in range(12):
            t = i / 11
            pts.append((fx - 70 + t * 110, fy - 14 - math.sin(t * math.pi * 2 + swing) * 10 - (t ** 3) * 70))
        sm = pts
        _tube(S, sm, 20, 32, c)
        for i, p in enumerate(pts):
            r = 10 + i * .9
            pygame.draw.arc(S, shade(c, .5), (p[0] - r * .6, p[1] - r * .45, r * 1.2, r * 1.1), 3.4, 6.0, 1)
        hx, hy = pts[-1]
        hx += 10 + lunge
        pygame.draw.ellipse(S, c, (hx - 10, hy - 18, 44, 28))
        pygame.draw.circle(S, (40, 20, 10), (int(hx + 18), int(hy - 8)), 4)
        pygame.draw.polygon(S, (240, 236, 220), [(hx + 26, hy + 4), (hx + 30, hy + 16), (hx + 34, hy + 4)])
        # 0.21 detail: scale diamonds, pale belly, dorsal ridge, forked tongue, slit eye
        def _sr(L):
            for i, p in enumerate(pts):
                r = 10 + i * .9
                pygame.draw.ellipse(L, (*shade(c, 1.4), 120), (p[0] - r * .7, p[1] + r * .15, r * 1.4, r * .5))
                for k in range(-1, 2):
                    x = p[0] + k * r * .55; y = p[1] - r * .15 + (k % 2) * 3
                    pygame.draw.polygon(L, (*shade(c, .5), 170), [(x, y - 3), (x + 3, y), (x, y + 3), (x - 3, y)], 1)
                pygame.draw.polygon(L, (*shade(c, .45), 220), [(p[0] - 3, p[1] - r + 2), (p[0], p[1] - r - 5), (p[0] + 3, p[1] - r + 2)])
        _inlay(S, _sr)
        pygame.draw.lines(S, (214, 40, 60), False, [(hx + 34, hy - 2), (hx + 46, hy - 2)], 2)
        pygame.draw.lines(S, (214, 40, 60), False, [(hx + 46, hy - 2), (hx + 52, hy - 6)], 2); pygame.draw.lines(S, (214, 40, 60), False, [(hx + 46, hy - 2), (hx + 52, hy + 2)], 2)
        pygame.draw.circle(S, (255, 214, 70), (int(hx + 18), int(hy - 9)), 5); pygame.draw.line(S, (30, 16, 8), (hx + 18, hy - 13), (hx + 18, hy - 5), 2); _glint(S, hx + 16, hy - 11, 1)
        for k in range(5): pygame.draw.line(S, (240, 236, 220), (hx + 14 + k * 4, hy + 4), (hx + 15 + k * 4, hy + 9), 1)
    elif kind == "dragon":
        by = fy - 90 - abs(swing) * 6
        wc = spec["wing"]; flap = (-30, 0, 24, 0)[frame if frame >= 0 else 0]
        _bat_wing(S, (fx - 4, by - 6), (fx - 80, by - 84 - flap // 2), (fx - 60, by + 10), shade(wc, .8))
        _tube(S, _bez((fx - 36, by + 2), (fx - 70, by + 14), (fx - 92, by + 30), 8), 22, 6, c)
        _ball(S, (fx - 40, by - 16, 80, 34), c)
        for k in range(8):
            pygame.draw.arc(S, shade(c, .6), (fx - 36 + k * 9, by - 8, 14, 12), 3.3, 6.0, 1)
        pygame.draw.ellipse(S, shade(c, 1.35), (fx - 24, by + 4, 56, 12))
        _tube(S, _bez((fx + 26, by - 2), (fx + 52, by - 6), (fx + 54 + lunge, by - 32), 6), 22, 14, c)
        _ball(S, (fx + 42 + lunge, by - 44, 40, 24), light)
        pygame.draw.circle(S, (255, 220, 60), (fx + 64 + lunge, by - 36), 3)
        pygame.draw.polygon(S, (230, 220, 200), [(fx + 48 + lunge, by - 42), (fx + 40 + lunge, by - 58), (fx + 56 + lunge, by - 44)])
        _bat_wing(S, (fx + 4, by - 8), (fx + 60, by - 100 - flap // 2), (fx + 50, by + 4), wc)
        for ox in (-16, 16):
            _seg(S, (fx + ox, by + 10), (fx + ox + 6, by + 20), 13, 8, dark); _seg(S, (fx + ox + 6, by + 20), (fx + ox + 4, by + 31), 8, 6, dark)
        # 0.21 detail: wing bones and veins, horns, dorsal spikes, belly plates, teeth, ember nostril
        def _dg(L):
            for (rx, ry, tips) in ((fx - 4, by - 6, ((fx - 80, by - 84 - flap // 2), (fx - 60, by + 10))), (fx + 4, by - 8, ((fx + 60, by - 100 - flap // 2), (fx + 50, by + 4)))):
                for (tx, ty) in tips:
                    pygame.draw.line(L, (*shade(wc, .45), 230), (rx, ry), (tx, ty), 3)
                    for t in (.35, .6):
                        pygame.draw.line(L, (*shade(wc, .55), 150), (rx + (tx - rx) * t, ry + (ty - ry) * t), (rx + (tips[1][0] - rx) * t, ry + (tips[1][1] - ry) * t), 1)
                pygame.draw.line(L, (*shade(wc, 1.4), 120), (rx, ry), ((tips[0][0] + tips[1][0]) / 2, (tips[0][1] + tips[1][1]) / 2), 2)
            for k in range(7):
                x = fx - 34 + k * 10
                pygame.draw.polygon(L, (*shade(c, .5), 230), [(x - 4, by - 14), (x, by - 28 - (k % 2) * 5), (x + 4, by - 14)])
            for k in range(6):
                pygame.draw.line(L, (*shade(c, 1.5), 140), (fx - 20 + k * 8, by + 5), (fx - 18 + k * 8, by + 14), 2)
            for k in range(6):
                pygame.draw.arc(L, (*shade(c, .5), 160), (fx - 38 + k * 12, by - 12, 14, 12), 3.3, 6.0, 1)
        _inlay(S, _dg)
        for sgn in (-1, 1):
            pygame.draw.polygon(S, (222, 214, 190), [(fx + 48 + lunge + sgn * 4, by - 44), (fx + 44 + lunge + sgn * 12, by - 62), (fx + 54 + lunge + sgn * 6, by - 46)])
        for k in range(6): pygame.draw.polygon(S, (248, 244, 232), [(fx + 52 + lunge + k * 4, by - 32), (fx + 54 + lunge + k * 4, by - 32), (fx + 53 + lunge + k * 4, by - 26)])
        pygame.draw.circle(S, (255, 120, 40), (fx + 76 + lunge, by - 34), 2); _glint(S, fx + 63 + lunge, by - 38, 1)
        for k in range(4): pygame.draw.polygon(S, shade(c, .5), [(fx - 56 - k * 9, by + 8 + k * 4), (fx - 52 - k * 9, by + 2 + k * 4), (fx - 48 - k * 9, by + 8 + k * 4)])
        for ox in (-16, 16):
            for cl in (-3, 0, 3): pygame.draw.line(S, (232, 226, 206), (fx + ox + 4 + cl, by + 28), (fx + ox + 6 + cl, by + 34), 2)
        if spec.get("cracks"):        # molten fissures through the hide and wing membranes
            for pts_ in (((fx - 28, by - 8), (fx - 10, by + 2), (fx + 8, by - 6), (fx + 26, by + 4)), ((fx - 70, by - 36 - flap // 2), (fx - 52, by - 20), (fx - 40, by - 6)), ((fx + 22, by - 14), (fx + 44, by - 34 - flap // 2), (fx + 54, by - 52 - flap))):
                pygame.draw.lines(S, spec["cracks"], False, pts_, 3); pygame.draw.lines(S, (255, 230, 150), False, pts_, 1)
            _spark(S, fx + 76 + lunge, by - 34, 8, spec["cracks"], 150)
        if spec.get("icy"):           # jagged ice spines and frost breath
            for k in range(7):
                x = fx - 36 + k * 10
                pygame.draw.polygon(S, (200, 236, 255), [(x - 5, by - 14), (x, by - 36 - (k % 3) * 8), (x + 5, by - 14)]); pygame.draw.line(S, (255, 255, 255), (x, by - 16), (x, by - 32 - (k % 3) * 7), 1)
            for k in range(6): _spark(S, fx + 84 + lunge + k * 8, by - 32 + (k % 2) * 6, 5, (200, 240, 255), 120)
        if spec.get("flames"):        # fire plume from the maw, embers along the wings
            for k, (dx, hh) in enumerate(((0, 16), (10, 26), (22, 18), (34, 10))):
                pygame.draw.polygon(S, (255, 130, 30), [(fx + 80 + lunge + dx, by - 40 + k * 3), (fx + 96 + lunge + dx + hh, by - 34 + k * 3), (fx + 80 + lunge + dx, by - 26 + k * 3)])
                pygame.draw.polygon(S, (255, 226, 120), [(fx + 80 + lunge + dx, by - 36 + k * 3), (fx + 90 + lunge + dx + hh * .5, by - 33 + k * 3), (fx + 80 + lunge + dx, by - 29 + k * 3)])
            _spark(S, fx + 92 + lunge, by - 34, 14, (255, 140, 40), 130)
            for (ex_, ey_) in ((-60, -30), (-46, -18), (50, -46), (38, -30)): _spark(S, fx + ex_, by + ey_ - flap // 2, 4, (255, 150, 50), 150)
        if spec.get("crown"):
            cc = spec["crown"]
            pygame.draw.polygon(S, cc, [(fx + 48 + lunge, by - 44), (fx + 46 + lunge, by - 58), (fx + 54 + lunge, by - 52), (fx + 60 + lunge, by - 62), (fx + 66 + lunge, by - 52), (fx + 72 + lunge, by - 56), (fx + 70 + lunge, by - 42)])
        if spec.get("twin"):          # a second, smaller head on a lower neck
            pygame.draw.line(S, c, (fx + 28, by - 2), (fx + 58 + lunge, by - 4), 11)
            pygame.draw.ellipse(S, shade(c, 1.1), (fx + 50 + lunge, by - 16, 34, 20)); pygame.draw.circle(S, (255, 220, 60), (fx + 76 + lunge, by - 9), 3)
            pygame.draw.polygon(S, (230, 220, 200), [(fx + 56 + lunge, by - 14), (fx + 50 + lunge, by - 28), (fx + 64 + lunge, by - 15)])
            for k in range(4): pygame.draw.polygon(S, (248, 244, 232), [(fx + 66 + lunge + k * 4, by - 2), (fx + 68 + lunge + k * 4, by - 2), (fx + 67 + lunge + k * 4, by + 3)])
    elif kind == "wraith":
        by = fy - 60 - abs(swing) * 4
        col = (*c, 210)
        pygame.draw.polygon(S, col, [(fx - 24, by - 40), (fx + 24, by - 40), (fx + 30, by + 30), (fx + 14, by + 16), (fx + 2, by + 40), (fx - 10, by + 18), (fx - 26, by + 36)])
        pygame.draw.polygon(S, (*shade(c, .6), 220), [(fx - 22, by - 40), (fx - 8, by - 76), (fx + 20, by - 66), (fx + 26, by - 38)])
        pygame.draw.ellipse(S, (12, 10, 20), (fx - 4, by - 66, 26, 28))
        pygame.draw.ellipse(S, (*shade(c, 1.6), 90), (fx - 7, by - 69, 32, 34), 2)
        for k in range(4):          # cloak folds
            pygame.draw.line(S, (*shade(c, .45), 150), (fx - 18 + k * 12, by - 34), (fx - 22 + k * 13, by + 30), 2)
        pygame.draw.circle(S, (140, 220, 255), (fx + 6, by - 52), 4); pygame.draw.circle(S, (140, 220, 255), (fx + 15, by - 52), 4)
        pygame.draw.line(S, (*light, 220), (fx + 20, by - 30), (fx + 46 + lunge, by - 20), 7)
        if spec.get("banshee"):      # long streaming hair, wailing mouth
            for k in range(9):
                x0 = fx - 18 + k * 5
                pts_ = [(x0, by - 58)] + [(x0 - 6 - j * 5 + math.sin(j * 1.2 + k + swing) * 4, by - 52 + j * 11) for j in range(1, 7)]
                for j in range(len(pts_) - 1): pygame.draw.line(S, (*light, max(30, 200 - j * 28)), pts_[j], pts_[j + 1], 3)
            pygame.draw.ellipse(S, (10, 6, 16), (fx + 2, by - 46, 14, 17 + (6 if attack else 0)))
        if spec.get("crown"):
            cc = spec["crown"]
            pygame.draw.polygon(S, cc, [(fx - 6, by - 66), (fx - 8, by - 82), (fx - 1, by - 74), (fx + 5, by - 86), (fx + 11, by - 74), (fx + 18, by - 82), (fx + 18, by - 66)])
            pygame.draw.circle(S, (255, 255, 255), (fx + 5, by - 80), 2)
        # 0.21 detail: trailing tendrils, shoulder rags, glowing hand, skull jaw, drifting motes
        for k in range(5):
            x0 = fx - 22 + k * 11; pts_ = [(x0, by + 24 + (k % 2) * 6)]
            for j in range(1, 6): pts_.append((x0 + math.sin(j * 1.3 + k + swing) * 6, by + 24 + j * 9 + (k % 2) * 6))
            for j in range(len(pts_) - 1):
                pygame.draw.line(S, (*c, max(20, 190 - j * 36)), pts_[j], pts_[j + 1], max(1, 6 - j))
        def _wd(L):
            for k in range(5): pygame.draw.line(L, (*shade(c, .5), 130), (fx - 18 + k * 9, by - 30), (fx - 20 + k * 9, by + 28), 2)
            pygame.draw.ellipse(L, (*shade(c, 1.5), 80), (fx - 14, by - 30, 18, 40))
        _inlay(S, _wd)
        pygame.draw.polygon(S, (*shade(c, .5), 230), [(fx - 4, by - 36), (fx + 18, by - 36), (fx + 14, by - 30), (fx + 2, by - 30)])
        pygame.draw.circle(S, (150, 230, 255), (fx + 46 + lunge, by - 20), 7); pygame.draw.circle(S, (255, 255, 255), (fx + 46 + lunge, by - 20), 3)
        pygame.draw.circle(S, (*[min(255, v + 80) for v in c], 90), (fx + 46 + lunge, by - 20), 14, 2)
        for k in range(6):
            a = k * 1.1 + swing; pygame.draw.circle(S, (190, 230, 255), (int(fx + math.cos(a) * 36), int(by - 20 + math.sin(a) * 40)), 2)
    elif kind == "elemental":
        by = fy - 74 - abs(swing) * 5
        fr_ = (frame if frame >= 0 else 0)
        _soft_shadow(S, fx, fy - 2, 70, 16, 80)
        pygame.draw.circle(S, (*c, 46), (fx, by), 62)
        # tapering whirlwind body, three nested swirling bands
        for k, (wd, sh_) in enumerate(((46, .55), (32, .85), (18, 1.2))):
            pts_ = [(fx + math.sin(j * .9 + fr_ * .8 + k) * (10 - j * 1.2), fy - 6 - j * 12) for j in range(0, 8)]
            for j in range(len(pts_) - 1):
                w_ = max(6, int(wd * (1 - j / 9)))
                pygame.draw.line(S, (*shade(c, sh_), 235), pts_[j], pts_[j + 1], w_)
        _sphere(S, (fx, by - 6), 30, c)
        pygame.draw.circle(S, (*shade(c, 1.5), 255), (fx - 8, by - 16), 10)
        # face: glowing eyes and a hollow mouth
        for ex in (-9, 7):
            pygame.draw.ellipse(S, (255, 255, 255), (fx + ex, by - 10, 8, 6)); pygame.draw.ellipse(S, (20, 30, 60), (fx + ex + 3, by - 9, 3, 4))
        pygame.draw.ellipse(S, (16, 20, 44), (fx - 6, by + 3, 14, 7 + (5 if attack else 0)))
        # arms: crystal fists orbiting the body
        for sgn in (-1, 1):
            ax = fx + sgn * 52 + (lunge if sgn == 1 else 0); ay = by + 12 - (14 if attack and sgn == 1 else 0) + swing * 3 * sgn
            _tube(S, _bez((fx + sgn * 24, by + 4), (fx + sgn * 40, by - 8), (ax, ay), 8), 14, 9, shade(c, .9))
            pygame.draw.polygon(S, shade(c, 1.3), [(ax - 9, ay), (ax, ay - 14), (ax + 10, ay - 2), (ax + 4, ay + 12), (ax - 6, ay + 9)])
            pygame.draw.polygon(S, (240, 250, 255), [(ax - 3, ay - 2), (ax, ay - 12), (ax + 4, ay - 3)])
        for i in range(7):
            a_ = i / 7 * math.tau + fr_ * .5
            px, py = fx + math.cos(a_) * 46, by + 14 + math.sin(a_) * 16
            _shp(S, [(px - 7, py), (px, py - 14), (px + 8, py - 2), (px + 2, py + 9)], shade(c, .75 + (i % 3) * .2), lo=.5)
        if spec.get("horror"):       # writhing tentacles and a cluster of eyes
            for k in range(7):
                a0 = k / 7 * math.tau + swing * .25
                pts_ = [(fx + math.cos(a0) * 26, by + math.sin(a0) * 20)]
                for j in range(1, 6): pts_.append((fx + math.cos(a0 + math.sin(j + swing) * .3) * (26 + j * 12), by + math.sin(a0) * (20 + j * 10)))
                for j in range(len(pts_) - 1): pygame.draw.line(S, shade(c, .55 + j * .06), pts_[j], pts_[j + 1], max(2, 8 - j))
            for (ex, ey, r_) in ((-10, -6, 5), (8, -10, 4), (2, 6, 6), (-16, 8, 3), (16, 4, 3)):
                pygame.draw.circle(S, (255, 230, 255), (fx + ex, by + ey), r_); pygame.draw.circle(S, (80, 10, 120), (fx + ex + 1, by + ey), max(1, r_ // 2))
        # 0.21 detail: swirling core, crackling arcs, radiant spikes
        def _el(L):
            for k in range(4):
                pygame.draw.arc(L, (255, 255, 255, 150 - k * 25), (fx - 26 + k * 4, by - 26 + k * 3, 52 - k * 8, 52 - k * 6), k * 1.5 + swing, k * 1.5 + 3.4 + swing, 2)
            for k in range(8):
                a = k / 8 * math.tau + swing * .3
                pygame.draw.line(L, (255, 255, 255, 120), (fx + math.cos(a) * 14, by + math.sin(a) * 14), (fx + math.cos(a) * 30, by + math.sin(a) * 30), 1)
        _inlay(S, _el)
        for k in range(8):
            a = k * .9 + swing; r_ = 36 + (k % 3) * 8
            pygame.draw.circle(S, (230, 250, 255), (int(fx + math.cos(a) * r_), int(by + math.sin(a) * r_ * .6)), 2)
    elif kind == "scorpion":
        by = fy - 26; beetle = spec.get("beetle")
        for i in range(4):
            for sgn, col in ((-1, dark), (1, c)):
                ox = -26 + i * 18; off = swing * 4 * (1 if i % 2 else -1)
                kx, ky = fx + ox + sgn * 10, by - 16
                pygame.draw.line(S, col, (fx + ox, by - 4), (kx + off, ky), 5)
                pygame.draw.line(S, col, (kx + off, ky), (fx + ox + sgn * 26 + off, fy - 3), 4)
        if not beetle:    # segmented tail curling over the back, with a stinger
            tp = [(fx - 44, by - 8), (fx - 68, by - 22), (fx - 78, by - 50), (fx - 62, by - 76), (fx - 34, by - 84)]
            for j in range(len(tp) - 1):
                pygame.draw.line(S, shade(c, .8), tp[j], tp[j + 1], 12 - j * 2)
                _sphere(S, (int(tp[j][0]), int(tp[j][1])), 8 - j, shade(c, .9 + j * .05))
            pygame.draw.polygon(S, (60, 30, 20), [(tp[-1][0], tp[-1][1] - 6), (tp[-1][0] + 20, tp[-1][1] + 6), (tp[-1][0], tp[-1][1] + 8)])
            pygame.draw.circle(S, (150, 255, 110), (int(tp[-1][0] + 20), int(tp[-1][1] + 10)), 2)
        _ball(S, (fx - 50, by - 24, 66, 42), c)
        for k in range(5): pygame.draw.arc(S, shade(c, .5), (fx - 48 + k * 12, by - 22, 18, 36), 1.6, 4.7, 2)
        if beetle:        # domed shell with a split wing-case, horn on the head
            pygame.draw.ellipse(S, shade(c, 1.15), (fx - 52, by - 40, 70, 40)); pygame.draw.ellipse(S, shade(c, .6), (fx - 52, by - 40, 70, 40), 3)
            pygame.draw.line(S, shade(c, .45), (fx - 17, by - 40), (fx - 17, by - 2), 3)
            pygame.draw.ellipse(S, (255, 255, 255), (fx - 40, by - 36, 18, 8))
        _ball(S, (fx + 8 + lunge, by - 20, 36, 30), shade(c, 1.15))
        if beetle:
            pygame.draw.polygon(S, shade(c, .5), [(fx + 30 + lunge, by - 18), (fx + 50 + lunge, by - 40), (fx + 42 + lunge, by - 14)])
        for (ex, ey) in ((30, -8), (36, -2)):
            pygame.draw.circle(S, (255, 60, 40), (fx + ex + lunge, by + ey), 3); _glint(S, fx + ex + lunge - 1, by + ey - 1, 1)
        for sgn in (-1, 1):   # pincers / mandibles
            ax, ay = fx + 36 + lunge, by + 4 + sgn * 10
            pygame.draw.line(S, shade(c, .8), (fx + 26, by + sgn * 4), (ax + 14, ay + (6 if attack else 0) * sgn), 7)
            pygame.draw.polygon(S, shade(c, 1.1), [(ax + 8, ay - 5), (ax + 30 + lunge // 2, ay + sgn * (2 if attack else 5)), (ax + 12, ay + 3)])
    elif kind == "golem":
        by = fy; rock = c; crk = spec.get("cracks", (255, 130, 40))
        for ox, sgn in ((-20, -1), (20, 1)):
            off = swing * 6 * sgn
            pygame.draw.polygon(S, shade(rock, .65), [(fx + ox - 15 + off, by - 62), (fx + ox + 15 + off, by - 62), (fx + ox + 18, by - 2), (fx + ox - 18, by - 2)])
            pygame.draw.polygon(S, rock, [(fx + ox - 15 + off, by - 62), (fx + ox + 4 + off, by - 62), (fx + ox + 6, by - 2), (fx + ox - 18, by - 2)])
            pygame.draw.line(S, crk, (fx + ox - 6, by - 50), (fx + ox + 4, by - 20), 3)
        pygame.draw.polygon(S, shade(rock, .62), [(fx - 42, by - 124), (fx + 42, by - 124), (fx + 32, by - 52), (fx - 32, by - 52)])
        pygame.draw.polygon(S, rock, [(fx - 42, by - 124), (fx + 2, by - 124), (fx - 4, by - 52), (fx - 32, by - 52)])
        pygame.draw.polygon(S, shade(rock, 1.28), [(fx - 42, by - 124), (fx + 42, by - 124), (fx + 36, by - 112), (fx - 36, by - 112)])
        for pts in (((fx - 20, by - 110), (fx - 8, by - 90), (fx - 18, by - 70), (fx - 10, by - 56)), ((fx + 12, by - 116), (fx + 22, by - 94), (fx + 10, by - 78))):
            pygame.draw.lines(S, crk, False, pts, 4); pygame.draw.lines(S, (255, 255, 255), False, pts, 1)
        pygame.draw.polygon(S, shade(rock, .78), [(fx - 17, by - 152), (fx + 17, by - 152), (fx + 19, by - 122), (fx - 19, by - 122)])
        pygame.draw.polygon(S, shade(rock, 1.12), [(fx - 17, by - 152), (fx, by - 152), (fx - 2, by - 122), (fx - 19, by - 122)])
        pygame.draw.rect(S, crk, (fx - 10, by - 142, 7, 5)); pygame.draw.rect(S, crk, (fx + 3, by - 142, 7, 5))
        _spark(S, fx, by - 140, 10, crk, 120)
        for sgn in (-1, 1):
            pygame.draw.circle(S, shade(rock, .9), (fx + sgn * 42, by - 118), 18); pygame.draw.circle(S, shade(rock, 1.2), (fx + sgn * 42 - 4, by - 124), 9)
            fxp = fx + sgn * 56 + (lunge if sgn == 1 else 0); fyp = by - 52 + (-26 if attack and sgn == 1 else 0)
            pygame.draw.line(S, shade(rock, .72 if sgn < 0 else .9), (fx + sgn * 40, by - 114), (fxp, fyp - 12), 20)
            pygame.draw.rect(S, shade(rock, .8), (fxp - 18, fyp - 14, 36, 32), border_radius=8); pygame.draw.rect(S, shade(rock, 1.15), (fxp - 18, fyp - 14, 18, 14), border_radius=6)
            pygame.draw.line(S, crk, (fxp - 8, fyp), (fxp + 6, fyp + 10), 3)
        # stone detail: strata, chips, glowing core and heart-crack, knuckle spikes, orbiting rubble
        def _gl(L):
            for k in range(9):
                yy = by - 120 + k * 7
                pygame.draw.line(L, (*shade(rock, .55), 120), (fx - 40 + (k % 3) * 3, yy), (fx + 38 - (k % 2) * 5, yy + (k % 3) - 1), 1)
            for k in range(14):
                x_ = fx - 36 + (k * 23) % 72; y_ = by - 122 + (k * 31) % 66
                pygame.draw.polygon(L, (*shade(rock, 1.35 if k % 2 else .5), 140), [(x_, y_), (x_ + 5, y_ + 2), (x_ + 2, y_ + 6)])
            for k in range(6):
                yy = by - 56 + k * 9
                pygame.draw.line(L, (*shade(rock, .5), 120), (fx - 20 + (k % 2) * 4, yy), (fx - 16 + (k % 2) * 4 + 12, yy + 1), 1)
                pygame.draw.line(L, (*shade(rock, 1.3), 100), (fx + 8, yy), (fx + 24, yy + 1), 1)
        _inlay(S, _gl)
        pygame.draw.circle(S, shade(crk, .5), (fx, by - 88), 11); pygame.draw.circle(S, crk, (fx, by - 88), 8); pygame.draw.circle(S, (255, 255, 240), (fx, by - 88), 4)
        S.blit(glow(26, tuple(int(c * .45) for c in crk)), (fx - 26, by - 88 - 26), special_flags=pygame.BLEND_RGB_ADD)
        for sgn in (-1, 1):
            fxp = fx + sgn * 56 + (lunge if sgn == 1 else 0); fyp = by - 52 + (-26 if attack and sgn == 1 else 0)
            for kk in range(3):
                pygame.draw.polygon(S, shade(rock, 1.25), [(fxp - 12 + kk * 9, fyp + 16), (fxp - 8 + kk * 9, fyp + 26), (fxp - 4 + kk * 9, fyp + 16)])
        for k in range(6):
            a_ = k * 1.1 + swing * .5; rx_ = fx + math.cos(a_) * 64; ry_ = by - 110 + math.sin(a_) * 34
            pygame.draw.polygon(S, shade(rock, .8 + .1 * (k % 3)), [(rx_, ry_ - 5), (rx_ + 6, ry_), (rx_ + 2, ry_ + 6), (rx_ - 5, ry_ + 2)])
        if spec.get("moss"):
            for (mx, my, w) in ((-34, -122, 30), (10, -60, 24), (-28, -80, 18)):
                pygame.draw.ellipse(S, (70, 120, 52), (fx + mx, by + my, w, w * .5)); pygame.draw.ellipse(S, (110, 164, 76), (fx + mx + 3, by + my, w * .55, w * .22))
        if spec.get("crown"):
            cc = spec["crown"]
            pygame.draw.polygon(S, cc, [(fx - 18, by - 150), (fx - 20, by - 172), (fx - 8, by - 160), (fx, by - 178), (fx + 8, by - 160), (fx + 20, by - 172), (fx + 18, by - 150)])
            pygame.draw.circle(S, (255, 255, 255), (fx, by - 166), 3)
    elif kind == "hydra":
        by = fy - 30
        for ox, sgn in ((-34, -1), (-14, 1), (20, -1), (40, 1)):
            off = swing * 5 * sgn; pygame.draw.line(S, dark, (fx + ox, by + 8), (fx + ox + off, fy - 4), 12)
        pygame.draw.line(S, dark, (fx - 50, by), (fx - 96, by + 18), 14); pygame.draw.line(S, c, (fx - 96, by + 18), (fx - 116, by + 8), 7)
        _ball(S, (fx - 56, by - 30, 112, 58), c)
        pygame.draw.ellipse(S, shade(c, 1.4), (fx - 40, by + 2, 80, 20))
        for k in range(8): pygame.draw.polygon(S, shade(c, .5), [(fx - 48 + k * 13, by - 24), (fx - 44 + k * 13, by - 38), (fx - 38 + k * 13, by - 24)])
        for i, (ox, ang, lh) in enumerate(((-30, -.55, 96), (4, .05, 118), (36, .6, 100))):
            sway = math.sin(i * 2 + swing) * 5
            pts_ = [(fx + ox, by - 20)]
            for j in range(1, 7):
                t = j / 6; pts_.append((fx + ox + ang * lh * t + sway * t * 3 + (lunge * t if i == 1 else 0), by - 20 - lh * t))
            for j, p_ in enumerate(pts_): _sphere(S, (int(p_[0]), int(p_[1])), max(6, 14 - j), shade(c, .85 if j % 2 else 1.0))
            hx_, hy_ = pts_[-1]
            for j in range(1, len(pts_) - 1):      # pale belly plates and dorsal ridge
                pygame.draw.arc(S, shade(c, 1.45), (pts_[j][0] - 8, pts_[j][1] - 4, 16, 9), 3.4, 6.0, 2)
                pygame.draw.polygon(S, shade(c, .5), [(pts_[j][0] - 10, pts_[j][1]), (pts_[j][0] - 17, pts_[j][1] - 4), (pts_[j][0] - 9, pts_[j][1] - 7)])
            pygame.draw.polygon(S, (170, 60, 70), [(hx_ - 6, hy_ - 8), (hx_ - 20, hy_ - 22), (hx_ - 12, hy_), (hx_ - 22, hy_ + 8), (hx_ - 4, hy_ + 6)])
            pygame.draw.ellipse(S, shade(c, 1.1), (hx_ - 10, hy_ - 10, 38, 22)); pygame.draw.ellipse(S, shade(c, .6), (hx_ - 10, hy_ - 10, 38, 22), 2)
            pygame.draw.circle(S, (255, 214, 70), (int(hx_ + 8), int(hy_ - 3)), 4); pygame.draw.circle(S, (20, 10, 4), (int(hx_ + 9), int(hy_ - 3)), 2)
            for k in range(3): pygame.draw.polygon(S, (244, 240, 226), [(hx_ + 14 + k * 5, hy_ + 4), (hx_ + 16 + k * 5, hy_ + 4), (hx_ + 15 + k * 5, hy_ + 10)])
            if attack and i == 1: pygame.draw.line(S, (214, 40, 60), (hx_ + 26, hy_ + 2), (hx_ + 40, hy_ + 2), 2)
    elif kind == "treant":
        by = fy
        for ox, sgn in ((-14, -1), (14, 1)):
            pygame.draw.line(S, dark, (fx + ox, by - 40), (fx + ox + sgn * 10 + swing * 6 * sgn, by - 4), 14)
        _tube(S, _bez((fx - 2, by - 20), (fx - 14, by - 80), (fx + 2, by - 132), 10), 62, 48, c)
        pygame.draw.arc(S, dark, (fx - 12, by - 104, 24, 18), 3.4, 6.1, 3)
        _tube(S, _bez((fx + 18, by - 112), (fx + 50, by - 124), (fx + 66 + lunge, by - 80 + (20 if attack else 0)), 8), 15, 10, c)
        _tube(S, _bez((fx - 18, by - 112), (fx - 52, by - 120), (fx - 56, by - 70), 8), 15, 10, c)
        _cl = [(fx - 34, by - 118, 30), (fx + 30, by - 122, 28), (fx, by - 142, 32), (fx - 8, by - 116, 22), (fx + 14, by - 150, 20)]
        _canopy(S, fx, by - 132, 64, 34, (54, 108, 46), _rnd_mod.Random(7), density=.7, leaf=(9, 6), clusters=_cl)
        pygame.draw.circle(S, spec.get('eye', (255, 230, 90)), (fx + 6, by - 100), 5); pygame.draw.circle(S, spec.get('eye', (255, 230, 90)), (fx + 18, by - 100), 5)
        # 0.21 detail: bark ridges, knots, moss, gnarled roots, twigs, leaf highlights, shelf fungus
        def _tr(L):
            for k in range(14):
                x = fx - 24 + k * 3.7; y0 = by - 128 + h01(k, 1, 9) * 14
                pygame.draw.lines(L, (*shade(c, .45), 150), False, [(x, y0), (x + (k % 3 - 1) * 2, y0 + 30), (x - (k % 2) * 3, y0 + 62), (x + 1, by - 34)], 1)
            for (kx, ky, r) in ((-6, -80, 7), (12, -60, 5), (-16, -50, 4)):
                pygame.draw.ellipse(L, (*shade(c, .3), 220), (fx + kx - r, by + ky - r * 1.3, r * 2, r * 2.6)); pygame.draw.ellipse(L, (*shade(c, .6), 220), (fx + kx - r, by + ky - r * 1.3, r * 2, r * 2.6), 1)
            for (mx, my, w) in ((-24, -110, 18), (6, -40, 20), (-14, -70, 14)):
                pygame.draw.ellipse(L, (70, 120, 52, 190), (fx + mx, by + my, w, w * .5)); pygame.draw.ellipse(L, (110, 164, 76, 160), (fx + mx + 2, by + my, w * .6, w * .25))
            for (ox, oy, r) in ((-34, -118, 30), (30, -122, 28), (0, -142, 32)):
                for k in range(8):
                    a = k * .8; pygame.draw.circle(L, (118, 170, 78, 150), (int(fx + ox + math.cos(a) * r * .55), int(by + oy + math.sin(a) * r * .55 - 4)), 4)
                    pygame.draw.circle(L, (30, 66, 30, 120), (int(fx + ox + math.cos(a + 3) * r * .7), int(by + oy + math.sin(a + 3) * r * .7 + 4)), 3)
        _inlay(S, _tr)
        for sgn in (-1, 1):
            for k in range(3):
                pygame.draw.lines(S, shade(c, .55), False, [(fx + sgn * (18 + k * 6), by - 38), (fx + sgn * (28 + k * 10), by - 18 + k * 3), (fx + sgn * (36 + k * 12), by - 4)], 7 - k * 2)
        for k in range(4):
            pygame.draw.line(S, shade(c, .5), (fx + 56 + lunge + k * 4, by - 82 + (20 if attack else 0)), (fx + 66 + lunge + k * 5, by - 96 + k * 6 + (20 if attack else 0)), 3)
        pygame.draw.ellipse(S, (214, 120, 60), (fx - 24, by - 64, 22, 8)); pygame.draw.ellipse(S, (240, 190, 120), (fx - 22, by - 64, 16, 4))
        pygame.draw.line(S, shade(c, .3), (fx - 2, by - 110), (fx + 26, by - 106), 4)                # heavy brow
    polish(S, rim=(170, 130, 30) if spec.get('elite') else (78, 70, 54), ao=.78)
    spr = outline(_finish(S, .5 * scale))
    return spr, (spr.get_width() // 2, int(fy * .5 * scale) + 1)

_CHAR = collections.OrderedDict()
CHAR_CACHE_MAX = 2400       # 0.34.2: pose sprites kept (about 120 looks x 20 poses); least recently used go first
CHAR_CACHE_MB = 96         # 0.37.2: and never more than this much memory
_CHAR_BYTES = [0]
def _char_trim():
    if len(_CHAR) <= CHAR_CACHE_MAX and _CHAR_BYTES[0] <= CHAR_CACHE_MB * 1048576: return
    while _CHAR and (len(_CHAR) > CHAR_CACHE_MAX - 240 or _CHAR_BYTES[0] > CHAR_CACHE_MB * 1048576 * .9):
        _, (spr_, _a) = _CHAR.popitem(last=False)
        _CHAR_BYTES[0] -= _surf_bytes(spr_)
        _BOUNDS.pop(id(spr_), None)

def character_sprite(key, spec_kind, spec, frame, facing, attack=False, scale=1.0):
    k = (key, frame, facing, attack, round(scale, 2))
    if k in _CHAR:
        _CHAR.move_to_end(k)
        return _CHAR[k]
    pump()
    if spec_kind == "human":
        spr, anc = draw_humanoid(spec, frame, attack, scale)
        bulk = spec.get("bulk")
        if bulk and bulk != 1.0:       # 0.45: hulking brutes are broad and heavy, the undead gaunt
            nw = max(1, int(spr.get_width() * bulk))
            spr2 = pygame.transform.smoothscale(spr, (nw, spr.get_height()))
            anc = (int(anc[0] * bulk), anc[1]); spr = spr2
    else:
        spr, anc = draw_beast(spec, frame, attack, scale, spec_kind)
    if facing < 0:
        spr = pygame.transform.flip(spr, True, False); anc = (spr.get_width() - anc[0], anc[1])
    spr = _terrain.enhance_sprite(paint_light(spr))        # 0.45: colour and crispness finishing pass
    _CHAR[k] = r = (spr, anc)
    _CHAR_BYTES[0] += _surf_bytes(spr)
    _char_trim()
    return r

def cached_character(key, frame, facing, attack=False, scale=1.0):
    """The sprite character_sprite() would return, if it is already built (else None)."""
    k = (key, frame, facing, attack, round(scale, 2))
    r = _CHAR.get(k)
    if r is not None: _CHAR.move_to_end(k)
    return r

import weakref as _weakref
_BOUNDS = _weakref.WeakKeyDictionary()   # 0.45: keyed by the sprite itself - an entry dies with its sprite (ids were reused)
def sprite_bounds(spr):
    try:
        b = _BOUNDS.get(spr)
        if b is None:
            b = _BOUNDS[spr] = spr.get_bounding_rect()
        return b
    except TypeError:                     # a surface type without weak references: just measure it
        return spr.get_bounding_rect()

FACTION_CAPE = {"Alliance": (52, 92, 196), "Horde": (178, 40, 36)}

def actor_look(a):
    """Map an actor snapshot dict → (cache key, kind, spec, scale)."""
    kind = a.get("kind")
    if kind == "monster":
        mk = a.get("look") if a.get("look") in MONSTER_SPEC else monster_kind(a.get("name", ""))
        sk, spec, sc = MONSTER_SPEC[mk]
        sc2 = a.get("scale", 1.0)
        if a.get("name", "").startswith("Elite "):      # gilded elite: gold rim, golden pauldrons, 22% bigger
            spec = dict(spec); spec["elite"] = True
            if sk == "human": spec["tier"] = (255, 204, 70); spec["tierlvl"] = 3
            sc2 *= 1.22
            return ("m", mk, round(sc2, 2), "E"), sk, spec, sc * sc2
        return ("m", mk, round(sc2, 2)), sk, spec, sc * sc2
    if kind == "npc":
        role = a.get("role", "vendor")
        spec = dict(NPC_SPEC.get(role, NPC_SPEC["vendor"]))
        if role == "guard":
            spec["cape"] = FACTION_CAPE.get(a.get("faction"), (120, 110, 90))
        return ("n", role, a.get("faction")), "human", spec, 1.0
    role = a.get("role") or a.get("class") or "Warrior"
    spec = dict(CLASS_SPEC.get(role, CLASS_SPEC["Warrior"]))
    spec["cape"] = FACTION_CAPE.get(a.get("faction"), (110, 110, 110))
    lv = a.get("level", 1) or 1
    g = a.get("gear")
    if g:            # 0.25: computer players show the gear they actually have
        TL = {"Rare": 1, "Epic": 2, "Elite": 3, "Set": 3, "Legendary": 3}
        if TL.get(g): spec["tier"] = RARITY_COLOR[g]; spec["tierlvl"] = TL[g]
        if TL.get(g, 0) >= 2: spec["helmtier"] = RARITY_COLOR[g]; spec["helmlvl"] = TL[g]
        sl = a.get("setl"); sp = tuple(a.get("setp") or ())
        if sl in SET_LOOKS and sp: spec["setl"] = sl; spec["setp"] = tuple(sorted(sp))
        return ("p", role, a.get("faction"), g, sl if sp else "", sp), "human", spec, 1.0
    if lv >= 25:     # veteran CPU adventurers wear sets too, a piece more every few levels
        sk = SET_ORDER[(int(lv) // 15 + int(a.get("id", 0))) % 7]
        pcs = tuple(p for p, need in (("armor", 25), ("helm", 40), ("weapon", 55), ("trinket", 75)) if lv >= need)
        spec["setl"] = sk; spec["setp"] = pcs
        return ("p", role, a.get("faction"), sk, pcs), "human", spec, 1.0
    return ("p", role, a.get("faction")), "human", spec, 1.0

# --------------------------------------------------------------- icons
RARITY_COLOR = {"Common": (220, 220, 220), "Uncommon": (60, 220, 80), "Rare": (70, 140, 255), "Epic": (180, 90, 255),
                "Elite": (255, 210, 70), "Set": (60, 220, 200), "Legendary": (255, 140, 30), "Mythic": (255, 40, 40)}

_ICON = {}
def _icon_bg(n, col):
    """Rounded tile with a radial lit-from-the-upper-left gradient."""
    B = pygame.Surface((n, n), pygame.SRCALPHA)
    cx, cy = n * .42, n * .38
    steps = 14
    for i in range(steps):
        f = i / (steps - 1)
        pygame.draw.circle(B, shade(col, .42 + .78 * f), (cx, cy), int(n * 1.0 * (1 - f * .93)) + 2)
    B.fill((255, 255, 255, 255), special_flags=pygame.BLEND_RGBA_MULT)
    m = pygame.Surface((n, n), pygame.SRCALPHA); pygame.draw.rect(m, (255, 255, 255, 255), (0, 0, n, n), border_radius=max(6, n // 8))
    B.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return B

def _icon_finish(B, S, frame, n):
    """Drop shadow under the symbol, gloss on the top half, bevelled bezel."""
    sh = pygame.mask.from_surface(S, 40).to_surface(setcolor=(0, 0, 0, 120), unsetcolor=(0, 0, 0, 0))
    B.blit(sh, (n // 28 + 1, n // 22 + 1)); B.blit(S, (0, 0))
    g = pygame.Surface((n, n), pygame.SRCALPHA)
    pygame.draw.ellipse(g, (255, 255, 255, 34), (-n * .15, -n * .55, n * 1.3, n * 1.0))
    m = pygame.Surface((n, n), pygame.SRCALPHA); pygame.draw.rect(m, (255, 255, 255, 255), (0, 0, n, n), border_radius=max(6, n // 8))
    g.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN); B.blit(g, (0, 0))
    r = max(6, n // 8); w = max(3, n // 20)
    pygame.draw.rect(B, shade(frame, .45), (0, 0, n, n), w + 2, border_radius=r)
    pygame.draw.rect(B, frame, (1, 1, n - 2, n - 2), w, border_radius=r)
    pygame.draw.rect(B, shade(frame, 1.35), (w, w, n - 2 * w, n - 2 * w), 1, border_radius=r - 2)
    pygame.draw.line(B, shade(frame, 1.6), (r, 2), (n - r, 2), 2)
    return B

def _flask(S, c, liquid, bulb=20, tall=22):
    sq = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    cy = c + 10
    pygame.draw.rect(sq, (205, 220, 230, 235), (c - 8, c - tall - 8, 16, tall + 6), border_radius=4)         # neck glass
    pygame.draw.circle(sq, (205, 220, 230, 235), (c, cy), bulb + 2)
    pygame.draw.circle(sq, shade(liquid, .55), (c, cy), bulb)
    pygame.draw.circle(sq, shade(liquid, .9), (c - 1, cy), bulb - 2)
    pygame.draw.circle(sq, liquid, (c - 3, cy - 2), int(bulb * .78))
    pygame.draw.circle(sq, shade(liquid, 1.35), (c - 7, cy - 6), int(bulb * .38))
    pygame.draw.rect(sq, shade(liquid, .8), (c - 6, c - tall - 4, 12, tall - 2))
    pygame.draw.line(sq, shade(liquid, 1.4), (c - 3, c - 8), (c - 3, c - tall), 2)
    pygame.draw.ellipse(sq, shade(liquid, 1.25), (c - bulb + 3, cy - 6, bulb * 2 - 6, 8))                       # meniscus
    for (bx, by, r) in ((-6, 14, 3), (4, 8, 2), (8, 16, 2)):
        pygame.draw.circle(sq, shade(liquid, 1.5), (c + bx, cy + by - 6), r, 1)
    pygame.draw.rect(sq, (130, 88, 48), (c - 8, c - tall - 14, 16, 10), border_radius=3)                   # cork
    pygame.draw.rect(sq, (170, 122, 70), (c - 7, c - tall - 14, 5, 9), border_radius=2)
    pygame.draw.arc(sq, (255, 255, 255, 220), (c - bulb + 2, cy - bulb + 2, bulb * 2 - 4, bulb * 2 - 4), 2.2, 3.4, 3)    # glass glint
    S.blit(sq, (0, 0))
JEWEL_COLORS = {"Ruby": (220, 40, 60), "Emerald": (40, 190, 90), "Sapphire": (50, 100, 230), "Topaz": (240, 180, 40), "Diamond": (215, 235, 255)}

def item_icon(slot, rarity, size=40):
    key = (slot, rarity, size)
    if key in _ICON:
        return _ICON[key]
    S = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
    rc = RARITY_COLOR.get(rarity, (200, 200, 200))
    N = size * 2
    B = _icon_bg(N, shade(rc, .5))
    c = size
    wk = None
    if slot.startswith("weapon:"): wk = slot[7:]; slot = "weapon"
    if slot == "weapon" and wk == "bow":
        pygame.draw.arc(S, (84, 52, 26), (c - 32, c - 36, 48, 72), -1.3, 1.3, 8)
        pygame.draw.arc(S, (176, 124, 68), (c - 32, c - 36, 48, 72), -1.3, 1.3, 4)
        pygame.draw.line(S, (230, 230, 220), (c - 2, c - 34), (c - 2, c + 34), 2)
        pygame.draw.line(S, (200, 180, 140), (c - 2, c), (c + 30, c), 2)
    elif slot == "weapon":                  # 0.46.24: draw big, crop and fit so every weapon fills the tile
        T = pygame.Surface((N * 3, N * 3), pygame.SRCALPHA)
        _weapon(T, wk or "sword", N * 1.5, N * 1.5, -.785, {"orb": shade(rc, 1.2) if rc != (220, 220, 220) else (130, 210, 255)})
        bb = T.get_bounding_rect()
        if bb.w and bb.h:
            f = min(N * .80 / bb.w, N * .80 / bb.h)
            g_ = pygame.transform.smoothscale(T.subsurface(bb), (max(1, int(bb.w * f)), max(1, int(bb.h * f))))
            S.blit(g_, (c - g_.get_width() // 2, c - g_.get_height() // 2))
    elif slot == "armor":
        steel = (170, 176, 192)
        for sd in (-1, 1):
            _shp(S, [(c + sd * 18, c - 24), (c + sd * 34, c - 20), (c + sd * 36, c - 6), (c + sd * 22, c - 2)], shade(rc, .9) if sd > 0 else shade(rc, .75), True, lo=.5)
        _shp(S, [(c - 24, c - 26), (c - 8, c - 31), (c, c - 22), (c + 8, c - 31), (c + 24, c - 26), (c + 26, c - 6), (c + 19, c + 12), (c + 17, c + 28), (c - 17, c + 28), (c - 19, c + 12), (c - 26, c - 6)], steel, True, lo=.5, spec_x=.25)
        pygame.draw.line(S, shade(steel, 1.4), (c - 1, c - 20), (c - 1, c + 26), 2); pygame.draw.line(S, shade(steel, .45), (c + 2, c - 20), (c + 2, c + 26), 1)
        pygame.draw.arc(S, shade(steel, .45), (c - 22, c - 20, 44, 28), 3.5, 5.9, 2)
        pygame.draw.rect(S, rc, (c - 18, c + 14, 36, 5)); pygame.draw.rect(S, shade(rc, 1.4), (c - 18, c + 14, 36, 1))
        pygame.draw.circle(S, (240, 210, 100), (c, c + 16), 3)
    elif slot == "helm":
        steel = (170, 176, 192)
        pygame.draw.polygon(S, shade(rc, .9), [(c - 2, c - 24), (c + 8, c - 40), (c + 20, c - 30), (c + 10, c - 20)])
        _shp(S, [(c - 26, c + 24), (c - 27, c - 4), (c - 18, c - 20), (c, c - 28), (c + 18, c - 20), (c + 27, c - 4), (c + 26, c + 24), (c + 12, c + 24), (c + 8, c + 8), (c - 8, c + 8), (c - 12, c + 24)], steel, True, lo=.5, spec_x=.22)
        pygame.draw.rect(S, (16, 12, 14), (c - 18, c - 4, 36, 7), border_radius=2)
        pygame.draw.line(S, shade(steel, .4), (c, c + 8), (c, c + 24), 3)
        pygame.draw.line(S, rc, (c - 26, c - 8), (c + 26, c - 8), 3)
    elif slot == "potion":
        _flask(S, c, (206, 38, 52))
    elif slot == "mana":
        _flask(S, c, (56, 106, 232))
    elif slot == "scroll":
        _shp(S, [(c - 24, c - 22), (c + 24, c - 22), (c + 24, c + 22), (c - 24, c + 22)], (230, 212, 166), lo=.7, top=1.1, bot=.82)
        for k in range(5): pygame.draw.line(S, (150, 118, 76), (c - 16, c - 14 + k * 7), (c + 16 - (k % 2) * 8, c - 14 + k * 7), 1)
        for yy in (-24, 24):
            pygame.draw.ellipse(S, (120, 84, 46), (c - 30, c + yy - 6, 60, 12)); pygame.draw.ellipse(S, (196, 150, 90), (c - 29, c + yy - 6, 58, 8))
            pygame.draw.ellipse(S, (236, 214, 160), (c - 31, c + yy - 5, 8, 10))
        pygame.draw.circle(S, (110, 20, 30), (c + 8, c + 6), 9); pygame.draw.circle(S, (190, 44, 56), (c + 7, c + 5), 7); pygame.draw.circle(S, (240, 120, 120), (c + 4, c + 2), 2)
    elif slot == "herb":
        pygame.draw.line(S, (40, 100, 44), (c, c + 28), (c, c - 4), 4)
        for dx, ang in ((-1, -.55), (0, 0), (1, .55)):
            ca, sa = math.cos(ang - 1.57), math.sin(ang - 1.57)
            L, W = 36, 12
            tip = (c + ca * L, c - 2 + sa * L); mid = (c + ca * L * .5, c - 2 + sa * L * .5)
            nx, ny = -sa, ca
            pts = [(c, c - 2), (mid[0] + nx * W, mid[1] + ny * W), tip, (mid[0] - nx * W, mid[1] - ny * W)]
            _shp(S, pts, (74, 174, 74), lo=.6)
            pygame.draw.line(S, (150, 224, 130), (c, c - 2), tip, 1)
    elif slot in ("ore", "leather", "cloth", "dust", "essence", "fish", "food"):
        _material_icon(S, slot, c, rc)
    elif slot.startswith("jewel:"):         # 0.39: a cut jewel in its gem's colour
        gc = JEWEL_COLORS.get(slot[6:], (200, 200, 220))
        gem = [(c - 20, c - 8), (c - 10, c - 22), (c + 10, c - 22), (c + 20, c - 8), (c, c + 24)]
        _shp(S, gem, gc, lo=.55)
        pygame.draw.polygon(S, shade(gc, 1.5), [(c - 10, c - 22), (c + 10, c - 22), (c + 4, c - 8), (c - 4, c - 8)])
        pygame.draw.polygon(S, shade(gc, .55), [(c + 4, c - 8), (c + 20, c - 8), (c, c + 24)])
        pygame.draw.line(S, (255, 255, 255), (c - 12, c - 12), (c - 4, c - 18), 2)
    elif slot == "trinket":                  # 0.39: the necklace - a chain and a pendant
        pygame.draw.arc(S, (210, 176, 80), (c - 26, c - 34, 52, 52), math.pi * 1.05, math.pi * 1.95, 4)
        for i in range(9):
            a_ = math.pi * (1.05 + .9 * i / 8); px_, py_ = c + math.cos(a_) * 26, c - 8 - math.sin(a_) * 26
            pygame.draw.circle(S, (240, 210, 110), (int(px_), int(py_)), 3)
        gem = [(c, c + 2), (c + 12, c + 14), (c, c + 30), (c - 12, c + 14)]
        _shp(S, gem, shade(rc, 1.05), lo=.6); pygame.draw.polygon(S, (150, 112, 30), gem, 2)
        pygame.draw.line(S, (255, 255, 255), (c - 4, c + 8), (c - 7, c + 13), 2)
    else:
        pygame.draw.circle(S, (150, 112, 30), (c, c + 8), 24); pygame.draw.circle(S, (230, 192, 84), (c, c + 8), 22); pygame.draw.circle(S, (150, 112, 30), (c, c + 8), 14)
        pygame.draw.circle(S, (36, 30, 40), (c, c + 8), 13)
        pygame.draw.arc(S, (255, 240, 170), (c - 22, c - 14, 44, 44), 2.2, 3.4, 3)
        gem = [(c - 11, c - 22), (c + 11, c - 22), (c + 17, c - 10), (c, c + 4), (c - 17, c - 10)]
        _shp(S, gem, shade(rc, 1.05), lo=.6)
        pygame.draw.polygon(S, shade(rc, 1.5), [(c - 11, c - 22), (c, c - 22), (c - 6, c - 10), (c - 17, c - 10)])
        pygame.draw.line(S, (255, 255, 255), (c - 6, c - 19), (c - 11, c - 12), 2)
    B = _icon_finish(B, S, shade(rc, 1.05), N)
    S = B
    _ICON[key] = _finish(S)
    return _ICON[key]

def _star4(S, x, y, r, col):
    pygame.draw.polygon(S, col, [(x, y - r), (x + r * .28, y - r * .28), (x + r, y), (x + r * .28, y + r * .28), (x, y + r), (x - r * .28, y + r * .28), (x - r, y), (x - r * .28, y - r * .28)])

def _material_icon(S, kind, c, rc):
    if kind == "ore":
        base = (122, 120, 128)
        _shp(S, [(c - 28, c + 22), (c - 30, c - 2), (c - 14, c - 24), (c + 8, c - 28), (c + 28, c - 8), (c + 30, c + 22)], base, True, lo=.5, spec_x=.2)
        _shp(S, [(c - 14, c - 24), (c + 8, c - 28), (c + 2, c - 8), (c - 16, c - 4)], shade(base, 1.25), lo=.7)
        for (x, y, r) in ((-6, 6, 6), (12, 2, 5), (-18, 14, 4), (16, 14, 5)):
            _shp(S, [(c + x - r, c + y), (c + x, c + y - r), (c + x + r, c + y), (c + x, c + y + r)], (214, 134, 84), True, lo=.6)
        _star4(S, c - 8, c - 14, 6, (255, 244, 220))
    elif kind == "leather":
        hide = (150, 96, 52)
        _shp(S, [(c - 28, c - 14), (c - 10, c - 24), (c + 12, c - 20), (c + 28, c - 10), (c + 24, c + 8), (c + 28, c + 22), (c + 4, c + 28), (c - 14, c + 22), (c - 30, c + 10)], hide, lo=.55)
        pygame.draw.lines(S, shade(hide, 1.35), True, [(c - 22, c - 10), (c - 8, c - 18), (c + 10, c - 14), (c + 22, c - 6), (c + 18, c + 8), (c + 22, c + 18), (c + 4, c + 22), (c - 12, c + 16), (c - 24, c + 8)], 1)
        for k in range(9): pygame.draw.line(S, (232, 214, 170), (c - 21 + k * 5, c - 14 + (k % 3) * 2), (c - 20 + k * 5, c - 11 + (k % 3) * 2), 2)
        pygame.draw.arc(S, shade(hide, .5), (c - 16, c - 4, 26, 18), 3.4, 6.0, 3)
    elif kind == "cloth":
        for i, col in enumerate(((120, 150, 214), (156, 120, 210), (210, 160, 90))):
            y = c + 14 - i * 14
            _shp(S, [(c - 28, y), (c - 20, y - 12), (c + 22, y - 12), (c + 30, y), (c + 24, y + 8), (c - 24, y + 8)], col, lo=.55)
            pygame.draw.line(S, shade(col, 1.4), (c - 18, y - 10), (c + 20, y - 10), 1)
            for f in range(4): pygame.draw.line(S, shade(col, .55), (c - 14 + f * 12, y - 8), (c - 16 + f * 12, y + 6), 1)
    elif kind == "dust":
        for r_, a_ in ((34, 30), (24, 44)):
            pygame.draw.circle(S, (190, 130, 255, a_), (c, c + 6), r_)
        pygame.draw.polygon(S, (110, 64, 170), [(c - 30, c + 26), (c - 20, c + 6), (c - 8, c - 4), (c, c - 10), (c + 10, c - 4), (c + 22, c + 8), (c + 30, c + 26)])
        pygame.draw.polygon(S, (170, 118, 232), [(c - 22, c + 22), (c - 10, c + 4), (c, c - 6), (c + 8, c + 4), (c + 20, c + 22)])
        pygame.draw.polygon(S, (214, 176, 255), [(c - 12, c + 14), (c - 2, c - 4), (c + 6, c + 8), (c, c + 16)])
        for (x, y, r) in ((-18, -14, 7), (16, -18, 5), (22, 2, 4), (-26, 4, 4), (2, -28, 5)): _star4(S, c + x, c + y, r, (255, 240, 255))
    elif kind == "essence":
        for r_, a_ in ((38, 26), (30, 40), (22, 60)):
            pygame.draw.circle(S, (110, 255, 230, a_), (c, c), r_)
        _sphere(S, (c, c), 18, (70, 222, 214))
        pygame.draw.circle(S, (230, 255, 252), (c - 6, c - 7), 5)
        for k in range(5):
            a = k * 1.25 + .4; pygame.draw.lines(S, (150, 255, 240), False, [(c + math.cos(a) * 20, c + math.sin(a) * 20), (c + math.cos(a + .5) * 30, c + math.sin(a + .5) * 30 - 4), (c + math.cos(a + .2) * 38, c + math.sin(a + .2) * 38 - 12)], 2)
    elif kind == "fish":
        body = (116, 164, 206)
        _shp(S, [(c + 18, c - 2), (c + 34, c - 18), (c + 32, c + 14)], shade(body, .8), lo=.6)                       # tail
        _shp(S, [(c - 10, c - 12), (c + 2, c - 26), (c + 12, c - 12)], shade(body, .7), lo=.6)                         # dorsal
        _shp(S, [(c - 32, c + 2), (c - 20, c - 12), (c, c - 16), (c + 20, c - 4), (c + 20, c + 4), (c, c + 16), (c - 20, c + 12)], body, True, lo=.5, spec_x=.3)
        pygame.draw.polygon(S, (222, 232, 242), [(c - 22, c + 8), (c, c + 12), (c + 18, c + 3), (c, c + 5)])
        for r_ in range(3):
            for k in range(4): pygame.draw.arc(S, shade(body, .6), (c - 12 + k * 7 + r_ * 2, c - 10 + r_ * 5, 9, 9), 4.2, 6.0, 1)
        pygame.draw.circle(S, (255, 255, 255), (c - 22, c - 3), 4); pygame.draw.circle(S, (16, 12, 18), (c - 22, c - 3), 2)
        pygame.draw.line(S, shade(body, .4), (c - 14, c - 10), (c - 12, c + 8), 2)
    elif kind == "food":
        pygame.draw.ellipse(S, (58, 40, 30), (c - 32, c - 6, 64, 36))
        pygame.draw.ellipse(S, (214, 196, 160), (c - 31, c - 8, 62, 30))
        pygame.draw.ellipse(S, (176, 70, 40), (c - 25, c - 8, 50, 20))
        pygame.draw.ellipse(S, (232, 128, 70), (c - 22, c - 8, 40, 12))
        for (x, y, col) in ((-12, -4, (110, 170, 70)), (6, -2, (240, 220, 140)), (14, -5, (110, 170, 70)), (-2, -7, (214, 180, 120))): pygame.draw.circle(S, col, (c + x, c + y), 4)
        pygame.draw.rect(S, (150, 100, 56), (c - 6, c - 8, 36, 0))
        for k in range(3):
            x = c - 14 + k * 14
            pygame.draw.lines(S, (240, 240, 244), False, [(x, c - 14), (x - 4, c - 22), (x + 3, c - 28), (x - 2, c - 36)], 3)

ICON_WORDS = (("ore", ("iron ore", "ore")), ("leather", ("leather", "skin", "hide")), ("cloth", ("cloth",)), ("dust", ("arcane dust", "dust")),
              ("essence", ("spirit essence", "essence")), ("food", ("grilled", "stew", "feast")))
def icon_slot(label, slot, fish=()):
    """Pick the icon picture from an item's name (materials, fish, cooked food); falls back to the given slot."""
    n = (label or "").lower()
    if any(n == f.lower() for f in fish) or slot == "fish": return "fish"
    if slot in ("weapon", "armor", "helm", "trinket"): return slot
    for k, words in ICON_WORDS:
        if any(w in n for w in words): return k
    return slot

def item_slot(it):
    """0.46.24: the icon slot for a gear row - weapons get their own picture (staff, wand, axe...) from the item name."""
    sl = it["slot"]
    if sl == "weapon":
        nm = it.get("item") or it.get("label") or it.get("name") or ""
        return "weapon:" + weapon_kind(nm)
    return sl

def weapon_kind(label):
    """Which weapon picture an item name should use."""
    n = (label or "").lower()
    for words, k in ((("bow",), "bow"), (("quarterstaff", "bo staff"), "bostaff"), (("staff", "rod"), "staff"), (("wand",), "wand"), (("dagger", "kris", "stiletto", "blades"), "daggers"),
                     (("great axe", "greataxe", "cleaver", "bearded"), "greataxe"), (("axe",), "axe"), (("maul", "hammer", "flail"), "hammer"),
                     (("scepter",), "scepter"), (("mace",), "mace"), (("greatsword",), "greatsword"), (("wraps", "fist"), "claws")):
        if any(w in n for w in words): return k
    return "sword"

def ability_icon(ab, size=48):
    key = ("ab", ab["name"], size)
    if key in _ICON:
        return _ICON[key]
    S = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
    N = size * 2
    kind = ab["kind"]; n = ab["name"].lower()
    BG = {"damage": (150, 62, 32), "multi": (150, 62, 32), "charge": (150, 62, 32), "aoe": (110, 50, 150), "nova": (110, 50, 150),
          "dot": (60, 120, 40), "stun": (60, 90, 150), "lifesteal": (130, 30, 60), "execute": (140, 20, 30),
          "heal": (40, 130, 70), "hot": (40, 130, 70), "shield": (50, 100, 160), "armor": (90, 90, 110),
          "dodge": (80, 80, 120), "sprint": (170, 130, 40), "vanish": (50, 50, 70)}
    bg = BG.get(kind, (80, 80, 80))
    B = _icon_bg(N, bg)
    gl = pygame.Surface((N, N), pygame.SRCALPHA)
    for rr, aa in ((int(size * .95), 30), (int(size * .7), 40), (int(size * .45), 50)):
        pygame.draw.circle(gl, (*shade(bg, 1.7), aa), (size, size), rr)
    B.blit(gl, (0, 0))
    c = size; W = (240, 236, 220)
    def A(col, a=120): return (*col, a)
    def _arrow(x0, y0, x1, y1, w=4):
        d = math.hypot(x1 - x0, y1 - y0) or 1; ux, uy = (x1 - x0) / d, (y1 - y0) / d; nx, ny = -uy, ux
        pygame.draw.line(S, (110, 76, 44), (x0, y0), (x1, y1), w + 2); pygame.draw.line(S, (196, 150, 98), (x0, y0), (x1, y1), w - 1)
        for sg in (-1, 1):                                                                       # fletching
            pygame.draw.polygon(S, (236, 232, 220) if sg > 0 else (170, 166, 156), [(x0, y0), (x0 + ux * 12 + nx * 8 * sg, y0 + uy * 12 + ny * 8 * sg), (x0 + ux * 16, y0 + uy * 16)])
        _shp(S, [(x1 + ux * 12, y1 + uy * 12), (x1 + nx * 7, y1 + ny * 7), (x1 - ux * 4, y1 - uy * 4), (x1 - nx * 7, y1 - ny * 7)], (214, 220, 232), True, lo=.5)
    def _glowball(cx, cy, r, col):
        for rr, aa in ((r + 16, 30), (r + 9, 55)):
            pygame.draw.circle(S, (*col, aa), (cx, cy), rr)
        _sphere(S, (cx, cy), r, col)
        pygame.draw.circle(S, (255, 255, 255), (cx - r // 3, cy - r // 3), max(2, r // 4))
    if kind in ("damage", "charge", "multi") and any(w in n for w in ("shot", "arrow", "volley", "shoot")) or kind == "multi":
        cnt = 3 if kind == "multi" else 1
        for k in range(cnt):
            o = (k - (cnt - 1) / 2) * 20
            _arrow(c - 32, c + 30 + o, c + 24, c - 26 + o)
    elif kind in ("aoe", "nova"):
        cc = (150, 220, 255) if any(w in n for w in ("frost", "ice", "blizzard")) else (255, 190, 90) if any(w in n for w in ("fire", "flame", "meteor")) else (255, 240, 170) if any(w in n for w in ("holy", "consecr", "light")) else (190, 150, 255)
        for r_, a_ in ((40, 40), (30, 60)): pygame.draw.circle(S, (*cc, a_), (c, c), r_)
        for r_ in (34, 22):
            pygame.draw.circle(S, shade(cc, .55), (c, c), r_, 6); pygame.draw.circle(S, cc, (c, c), r_, 3); pygame.draw.arc(S, (255, 255, 255), (c - r_, c - r_, r_ * 2, r_ * 2), 2.2, 3.5, 2)
        for k in range(8):
            a = k / 8 * math.tau + .2
            pts = [(c + math.cos(a - .12) * 16, c + math.sin(a - .12) * 16), (c + math.cos(a) * 42, c + math.sin(a) * 42), (c + math.cos(a + .12) * 16, c + math.sin(a + .12) * 16)]
            pygame.draw.polygon(S, cc, pts)
        _glowball(c, c, 9, cc)
    elif kind in ("heal", "hot"):
        gold = (255, 226, 130)
        arms = [(c - 11, c - 32, 22, 64), (c - 32, c - 11, 64, 22)]
        for r_ in arms: pygame.draw.rect(S, (30, 100, 60), (r_[0] + 3, r_[1] + 4, r_[2], r_[3]), border_radius=5)
        for r_ in arms: pygame.draw.rect(S, (200, 246, 214), r_, border_radius=5)
        for r_ in arms: pygame.draw.rect(S, (244, 255, 248), (r_[0] + 2, r_[1] + 2, r_[2] - 6, max(2, r_[3] // 6)), border_radius=3)
        pygame.draw.circle(S, gold, (c, c), 6); pygame.draw.circle(S, (255, 255, 255), (c - 2, c - 2), 2)
        for (x, y, r) in ((-30, -26, 6), (30, 24, 5), (28, -30, 4)): _star4(S, c + x, c + y, r, (255, 255, 230))
        if kind == "hot":
            for k in range(3): pygame.draw.circle(S, (190, 255, 190), (c - 26 + k * 26, c + 36), 5)
    elif kind in ("shield", "armor"):
        cc = (150, 210, 255) if kind == "shield" else (196, 198, 212)
        pts = [(c - 30, c - 32), (c, c - 38), (c + 30, c - 32), (c + 28, c + 6), (c + 14, c + 26), (c, c + 38), (c - 14, c + 26), (c - 28, c + 6)]
        _shp(S, pts, cc, True, lo=.5, spec_x=.22)
        pygame.draw.polygon(S, (214, 172, 62), pts, 3)
        pygame.draw.line(S, shade(cc, .5), (c, c - 34), (c, c + 34), 2); pygame.draw.line(S, shade(cc, .5), (c - 26, c - 8), (c + 26, c - 8), 2)
        _sphere(S, (c, c - 8), 8, (240, 204, 90))
    elif kind == "stun":
        for k in range(3):
            a = k / 3 * math.tau - 1.57
            x, y = c + math.cos(a) * 24, c + math.sin(a) * 24 + 2
            _star4(S, x, y, 15, (255, 236, 130)); _star4(S, x, y, 8, (255, 255, 220))
        pygame.draw.arc(S, (255, 240, 170), (c - 30, c - 30, 60, 60), 0.4, 2.6, 3); pygame.draw.arc(S, (255, 240, 170), (c - 30, c - 30, 60, 60), 3.6, 5.8, 3)
        _glowball(c, c + 4, 7, (255, 220, 100))
    elif kind == "dot":
        for k in range(3):
            x = c - 24 + k * 24; y0 = c - 22 + (k % 2) * 8
            drop = [(x, y0 - 6), (x - 6, y0 + 8), (x - 10, y0 + 18), (x - 4, y0 + 28), (x + 4, y0 + 28), (x + 10, y0 + 18), (x + 6, y0 + 8)]
            _shp(S, drop, (110, 214, 70), lo=.6, top=1.15)
            pygame.draw.circle(S, (230, 255, 200), (x - 4, y0 + 16), 3)
        for (x, y) in ((-30, 28), (0, 34), (28, 30)): pygame.draw.ellipse(S, (60, 150, 50), (c + x - 6, c + y, 12, 5))
    elif kind == "lifesteal":
        pygame.draw.circle(S, (150, 20, 44), (c - 14, c - 12), 20); pygame.draw.circle(S, (150, 20, 44), (c + 14, c - 12), 20)
        pygame.draw.polygon(S, (150, 20, 44), [(c - 33, c - 4), (c + 33, c - 4), (c, c + 36)])
        pygame.draw.circle(S, (230, 56, 84), (c - 14, c - 14), 17); pygame.draw.circle(S, (230, 56, 84), (c + 14, c - 14), 17)
        pygame.draw.polygon(S, (230, 56, 84), [(c - 30, c - 4), (c + 30, c - 4), (c, c + 32)])
        pygame.draw.ellipse(S, (255, 170, 184), (c - 24, c - 26, 16, 10)); pygame.draw.circle(S, (255, 220, 224), (c - 17, c - 22), 3)
        pygame.draw.polygon(S, (255, 70, 90), [(c + 30, c + 8), (c + 34, c + 20), (c + 30, c + 24), (c + 26, c + 20)])
    elif kind == "execute":
        for sg in (-1, 1): pygame.draw.line(S, (220, 214, 200), (c - sg * 34, c + 30), (c + sg * 34, c - 14 + 34), 5)
        _sphere(S, (c, c - 8), 26, (236, 230, 216))
        _shp(S, [(c - 15, c + 10), (c + 15, c + 10), (c + 13, c + 30), (c - 13, c + 30)], (214, 208, 194), lo=.6)
        for dx in (-10, 10): pygame.draw.circle(S, (110, 8, 18), (c + dx, c - 6), 8); pygame.draw.circle(S, (255, 70, 60), (c + dx + 1, c - 5), 2)
        pygame.draw.polygon(S, (60, 40, 40), [(c, c + 4), (c - 4, c + 12), (c + 4, c + 12)])
        for k in range(4): pygame.draw.line(S, (110, 90, 84), (c - 9 + k * 6, c + 16), (c - 9 + k * 6, c + 28), 2)
    elif kind in ("dodge", "sprint"):
        for k in range(3):
            y = c - 20 + k * 20
            pygame.draw.polygon(S, (*W, 150), [(c - 38, y), (c - 4 - k * 6, y - 4), (c + 2 - k * 6, y), (c - 4 - k * 6, y + 4)])
        _shp(S, [(c - 2, c - 30), (c + 30, c - 18), (c + 34, c), (c + 28, c + 14), (c + 26, c + 28), (c - 6, c + 28), (c - 8, c + 6)], (214, 170, 90), True, lo=.5)
        pygame.draw.line(S, (110, 76, 40), (c - 6, c + 22), (c + 26, c + 22), 5)
        for k in range(3): pygame.draw.line(S, (255, 236, 170), (c + 4 + k * 8, c - 10 + k * 5), (c - 14, c - 6 + k * 5), 2)
    elif kind == "vanish":
        for r_, a_ in ((38, 40), (30, 70)): pygame.draw.circle(S, (90, 80, 140, a_), (c, c), r_)
        for (x, y, r) in ((-14, 8, 20), (12, 10, 18), (0, -10, 22), (-18, -8, 14), (20, -6, 14)):
            pygame.draw.circle(S, (44, 40, 66), (c + x, c + y), r); pygame.draw.circle(S, (84, 78, 118), (c + x - 3, c + y - 3), r - 4)
        for dx in (-9, 9): pygame.draw.circle(S, (255, 255, 255), (c + dx, c - 4), 5); pygame.draw.circle(S, (120, 200, 255), (c + dx, c - 4), 2)
    elif any(w in n for w in ("bolt", "smite", "meteor", "judgement", "blast", "fire", "frost", "lightning", "shock", "storm")):
        cc = (150, 220, 255) if any(w in n for w in ("frost", "ice")) else (255, 120, 40) if any(w in n for w in ("fire", "meteor", "flame")) else (255, 240, 120) if any(w in n for w in ("lightning", "shock", "storm", "smite")) else (190, 140, 255)
        for k in range(4):
            pygame.draw.polygon(S, (*cc, 170 - k * 30), [(c - 4 - k * 9, c + 6 + k * 9), (c - 38 - k * 5, c + 38 + k), (c - 14 - k * 9, c + 16 + k * 9)])
        _glowball(c + 8, c - 8, 20, cc)
        for k in range(6):
            a = k * 1.05 + .3; pygame.draw.line(S, shade(cc, 1.4), (c + 8 + math.cos(a) * 24, c - 8 + math.sin(a) * 24), (c + 8 + math.cos(a) * 34, c - 8 + math.sin(a) * 34), 3)
    else:
        _weapon(S, "dagger" if any(w in n for w in ("back", "shadow", "stab", "eviscer", "garrote", "rake", "claw", "swipe")) else "sword", c - 26, c + 26, -.785, {}, 1.4)
    S = _icon_finish(B, S, (214, 172, 62), N)
    _ICON[key] = _finish(S)
    return _ICON[key]

def loot_sprite(rarity):
    key = ("loot", rarity)
    if key in _ICON:
        return _ICON[key]
    rc = RARITY_COLOR.get(rarity, (220, 220, 220))
    S = pygame.Surface((80, 70), pygame.SRCALPHA)
    pygame.draw.ellipse(S, (*rc, 70), (0, 30, 80, 36))
    pygame.draw.ellipse(S, (0, 0, 0, 80), (16, 44, 48, 18))
    pygame.draw.polygon(S, (150, 110, 64), [(22, 52), (58, 52), (54, 26), (26, 26)])
    pygame.draw.polygon(S, (120, 86, 50), [(26, 26), (54, 26), (48, 16), (32, 16)])
    pygame.draw.line(S, rc, (24, 34), (56, 34), 4)
    pygame.draw.circle(S, (240, 210, 90), (40, 40), 4)
    _ICON[key] = _finish(S)
    return _ICON[key]


# ---------------------------------------------------- Conquer-style finishing
def paint_light(spr):
    """Soft top-left lighting, a darker underside and a bright rim, so the flat
    procedural figures read like shaded pre-rendered sprites."""
    w, h = spr.get_size()
    m = pygame.mask.from_surface(spr, 40)
    out = spr.copy()
    # vertical gradient: bright head/shoulders, darker legs
    grad = pygame.Surface((w, h)); grad.fill((255, 255, 255))
    for y in range(h):
        v = int(255 * (1.0 - .34 * (y / h) ** 1.4))
        pygame.draw.line(grad, (v, v, v), (0, y), (w, y))
    out.blit(grad, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    hz = pygame.Surface((w, h)); hz.fill((255, 255, 255))
    for x in range(w):
        v = int(255 * (1.0 - .2 * max(0, (x / w - .45))))
        pygame.draw.line(hz, (v, v, v), (x, 0), (x, h))
    out.blit(hz, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    # rim light on the upper-left silhouette edge, dark rim on the lower-right
    sil = m.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
    up = pygame.Surface((w, h), pygame.SRCALPHA); up.blit(sil, (1, 1))
    edge_l = pygame.Surface((w, h), pygame.SRCALPHA); edge_l.blit(sil, (0, 0))
    edge_l.blit(up, (0, 0), special_flags=pygame.BLEND_RGBA_SUB)
    lit = pygame.mask.from_surface(edge_l, 100).to_surface(setcolor=(255, 244, 214, 150), unsetcolor=(0, 0, 0, 0))
    dn = pygame.Surface((w, h), pygame.SRCALPHA); dn.blit(sil, (-1, -1))
    edge_d = pygame.Surface((w, h), pygame.SRCALPHA); edge_d.blit(sil, (0, 0))
    edge_d.blit(dn, (0, 0), special_flags=pygame.BLEND_RGBA_SUB)
    dk = pygame.mask.from_surface(edge_d, 100).to_surface(setcolor=(10, 8, 20, 120), unsetcolor=(0, 0, 0, 0))
    out.blit(dk, (0, 0)); out.blit(lit, (0, 0))
    return out

_RING = {}
def ring_sprite(kind, scale=1.0):
    """Ground ring under a character, like Conquer's selection circles."""
    key = (kind, round(scale, 2))
    r = _RING.get(key)
    if r is None:
        # 0.23: subtle Diablo-style ground rings (thin, low alpha) instead of loud double circles
        col = {"npc": (206, 176, 96), "enemy": (190, 54, 44), "ally": (80, 150, 230), "me": (150, 210, 255), "boss": (255, 120, 30)}[kind]
        w = int(30 * scale * (1.5 if kind == "boss" else 1)); h = max(8, w // 2)
        r = pygame.Surface((w * 2 + 8, h * 2 + 8), pygame.SRCALPHA)
        cx, cy = w + 4, h + 4
        a_fill, a_line = {"npc": (18, 120), "enemy": (22, 130), "ally": (22, 130), "me": (36, 200), "boss": (40, 220)}[kind]
        pygame.draw.ellipse(r, (*col, a_fill), (cx - w, cy - h, w * 2, h * 2))
        pygame.draw.ellipse(r, (*col, a_line), (cx - w, cy - h, w * 2, h * 2), 2 if kind in ("me", "boss") else 1)
        if kind in ("me", "boss"):
            pygame.draw.ellipse(r, (*shade(col, 1.3), 160), (cx - w + 6, cy - h + 3, (w - 6) * 2, (h - 3) * 2), 1)
        _RING[key] = r
    return r

def render_rim(layout, cx, cy):
    """Stone sea-wall faces where land drops down to water (drawn over the ground)."""
    Wd, Hd = CS * TW, CS * TH + 2
    x0, y0 = cx * CS, cy * CS
    surf = None
    for ly in range(CS):
        for lx in range(CS):
            x, y = x0 + lx, y0 + ly
            kind = tile_cached(layout, x, y)[0]
            if kind in ("water", "void", "lava", "dfloor"): continue
            faces = []
            pt_ = getattr(layout, "pond_tiles", {})
            if tile_cached(layout, x, y + 1)[0] == "water" and (x, y + 1) not in pt_: faces.append(0)
            if tile_cached(layout, x + 1, y)[0] == "water" and (x + 1, y) not in pt_: faces.append(1)
            if not faces: continue
            if surf is None: surf = pygame.Surface((Wd, Hd + 18), pygame.SRCALPHA)
            pxc = CS * HTW + (lx - ly) * HTW; top = (lx + ly) * HTH
            L = (pxc - HTW, top + HTH); B = (pxc, top + TH); R = (pxc + HTW, top + HTH)
            for f in faces:
                a, b = (L, B) if f == 0 else (B, R)
                dep = 13
                base = (170, 166, 158) if f == 0 else (132, 128, 122)
                pygame.draw.polygon(surf, base, [a, b, (b[0], b[1] + dep), (a[0], a[1] + dep)])
                for row in range(1, 4):
                    yy = row * dep / 4
                    pygame.draw.line(surf, shade(base, .7), (a[0], a[1] + yy), (b[0], b[1] + yy), 1)
                    off = (row % 2) * .5
                    for j in range(2):
                        t = (j + off) / 2 + .25
                        px_ = a[0] + (b[0] - a[0]) * t; py_ = a[1] + (b[1] - a[1]) * t
                        pygame.draw.line(surf, shade(base, .7), (px_, py_ + yy - dep / 4), (px_, py_ + yy), 1)
                pygame.draw.line(surf, shade(base, 1.25), a, b, 2)
                pygame.draw.line(surf, (60, 90, 100), (a[0], a[1] + dep), (b[0], b[1] + dep), 1)
    return surf


HERB_COL = [(235, 235, 150), (190, 200, 220), (150, 210, 255), (90, 200, 200), (210, 120, 200),
            (240, 200, 70), (150, 120, 190), (250, 170, 60), (240, 90, 50), (150, 70, 230)]

VEIN_COL = ((196, 112, 58), (150, 160, 176), (226, 230, 236), (240, 196, 70), (110, 220, 230))
def vein_sprite(band):
    """0.25.1: a mineable rock with metal seams (copper, iron, silver, gold, mithril)."""
    key = ("vein", band)
    if key in _ICON:
        return _ICON[key]
    mc = VEIN_COL[band % 5]
    S = pygame.Surface((96, 80), pygame.SRCALPHA)
    pygame.draw.ellipse(S, (0, 0, 0, 80), (10, 56, 76, 18))
    rock = [(14, 62), (20, 38), (36, 22), (56, 18), (74, 30), (84, 52), (78, 64), (30, 68)]
    pygame.draw.polygon(S, (92, 86, 80), rock)
    pygame.draw.polygon(S, (120, 114, 106), [(20, 38), (36, 22), (56, 18), (50, 38), (30, 46)])
    pygame.draw.polygon(S, (70, 64, 60), [(56, 18), (74, 30), (84, 52), (62, 48), (50, 38)])
    pygame.draw.polygon(S, (40, 36, 34), rock, 2)
    for (x0, y0, x1, y1) in ((26, 50, 44, 36), (44, 36, 52, 44), (58, 30, 70, 46), (34, 60, 54, 54), (62, 56, 76, 50)):
        pygame.draw.line(S, shade(mc, .6), (x0, y0 + 1), (x1, y1 + 1), 4)
        pygame.draw.line(S, mc, (x0, y0), (x1, y1), 3)
    for (x, y) in ((40, 39), (66, 40), (46, 56), (30, 49)):
        pygame.draw.circle(S, (255, 255, 255), (x, y), 2)
    _ICON[key] = _finish(S)
    return _ICON[key]

def herb_sprite(band):
    key = ("herb", band)
    if key in _ICON:
        return _ICON[key]
    rc = HERB_COL[band % 10]
    S = pygame.Surface((80, 80), pygame.SRCALPHA)
    pygame.draw.ellipse(S, (0, 0, 0, 70), (16, 54, 48, 16))
    for ang, ln in ((-.7, 24), (-.3, 32), (0, 36), (.3, 30), (.7, 22)):
        x2 = 40 + math.sin(ang) * ln; y2 = 62 - math.cos(ang) * ln
        pygame.draw.line(S, (52, 130, 52), (40, 62), (x2, y2), 3)
        pygame.draw.ellipse(S, (76, 170, 74), (x2 - 6, y2 - 7, 12, 14))
    pygame.draw.circle(S, rc, (40, 26), 8)
    pygame.draw.circle(S, (255, 255, 255), (38, 24), 3)
    for a in range(5):
        pygame.draw.circle(S, rc, (int(40 + 12 * math.cos(a * 1.256)), int(26 + 12 * math.sin(a * 1.256))), 5)
    _ICON[key] = _finish(S)
    return _ICON[key]

# ======================================================================
# Town architecture.  0.45: buildings and city walls are medieval (see medieval.py);
# what stays here is the shared iso canvas, iron lanterns, lamp posts, the fountain
# and each shop's sign and props (_station_decor).
# ======================================================================
CO_TIMBER = (62, 42, 30)
CO_GOLD = (184, 150, 82)
CO_STONE = (156, 150, 138)

class _IsoCanvas:
    """A large 2x scratch surface with a world->canvas projection; cropped at the end."""
    def __init__(self, size=(900, 1000), origin=(450, 760), k=2):
        self.S = pygame.Surface(size, pygame.SRCALPHA); self.o = origin; self.k = k
    def P(self, x, y, z=0.0):
        k = self.k
        return (self.o[0] + (x - y) * HTW * k, self.o[1] + (x + y) * HTH * k - z * k)
    def poly(self, pts, col, width=0):
        pygame.draw.polygon(self.S, col, pts, width)
    def masked(self, face_pts, painter):
        """Run painter(surface) on a temp layer and keep only what falls inside face_pts."""
        xs = [p[0] for p in face_pts]; ys = [p[1] for p in face_pts]
        x0, y0 = int(min(xs)) - 2, int(min(ys)) - 2; w, h = int(max(xs)) - x0 + 4, int(max(ys)) - y0 + 4
        if w <= 0 or h <= 0: return
        lay = pygame.Surface((w, h), pygame.SRCALPHA)
        painter(lay, (x0, y0))
        m = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.polygon(m, (255, 255, 255, 255), [(p[0] - x0, p[1] - y0) for p in face_pts])
        lay.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        self.S.blit(lay, (x0, y0))
    def crop(self, anchor_world=(0, 0, 0), scale=.5):
        r = self.S.get_bounding_rect()
        if r.w == 0: r = pygame.Rect(0, 0, 2, 2)
        sub = self.S.subsurface(r).copy()
        ax, ay = self.P(*anchor_world)
        spr = pygame.transform.smoothscale(sub, (max(1, int(r.w * scale)), max(1, int(r.h * scale))))
        return spr, (int((ax - r.x) * scale), int((ay - r.y) * scale))



def _lantern(C, at, drop=10, size=1.0):
    """0.23: a small iron lantern with an amber flame (was a red paper lantern)."""
    k = C.k; x, y = at
    pygame.draw.line(C.S, (34, 30, 28), (x, y), (x, y + drop * k), k)
    cy = y + drop * k + 7 * k * size
    w_, h_ = 9 * k * size, 12 * k * size
    r = pygame.Rect(0, 0, w_, h_); r.center = (x, cy)
    pygame.draw.polygon(C.S, (40, 36, 34), [(r.left + 2 * k, r.top), (r.right - 2 * k, r.top), (r.centerx, r.top - 4 * k * size)])
    pygame.draw.rect(C.S, (255, 186, 92), r.inflate(-2 * k, -2 * k))
    pygame.draw.rect(C.S, (255, 236, 170), (r.centerx - k, r.centery - 2 * k, 2 * k, 4 * k))
    pygame.draw.rect(C.S, (40, 36, 34), r, k)
    pygame.draw.line(C.S, (40, 36, 34), (r.centerx, r.top), (r.centerx, r.bottom), k)
    pygame.draw.rect(C.S, (40, 36, 34), (r.left - k, r.bottom, r.w + 2 * k, 2 * k))


STATION_KINDS = ("teleport", "forge", "hut", "press", "warhall", "magic", "apothecary", "inn", "jeweler", "kiln", "smithy", "general", "enchanter", "bank", "stable", "market")


def _leaded(C, face_pts, glow=(252, 214, 140), frame=None, n=2):
    """0.45: a medieval leaded window in a stone surround (replaces the old lattice panes)."""
    k = C.k
    a, b, c, d = face_pts
    cx = (a[0] + b[0] + c[0] + d[0]) / 4; cy = (a[1] + b[1] + c[1] + d[1]) / 4
    grow = lambda p, f: (cx + (p[0] - cx) * f, cy + (p[1] - cy) * f)
    C.poly([grow(p, 1.18) for p in face_pts], (150, 144, 132))
    C.poly(face_pts, (34, 28, 24))
    inner = [grow(p, .86) for p in face_pts]
    C.poly(inner, glow)
    C.poly([inner[3], _mid(inner[3], inner[2]), _mid(_mid(inner[3], inner[2]), _mid(inner[0], inner[1])), _mid(inner[3], inner[0])], shade(glow, 1.12))
    for i in range(1, n + 1):
        t = i / (n + 1)
        pygame.draw.line(C.S, (60, 52, 46), (inner[0][0] + (inner[1][0] - inner[0][0]) * t, inner[0][1] + (inner[1][1] - inner[0][1]) * t), (inner[3][0] + (inner[2][0] - inner[3][0]) * t, inner[3][1] + (inner[2][1] - inner[3][1]) * t), max(1, k // 2))
    pygame.draw.line(C.S, (60, 52, 46), _mid(inner[0], inner[3]), _mid(inner[1], inner[2]), max(1, k // 2))
    C.poly([grow(a, 1.25), grow(b, 1.25), (grow(b, 1.25)[0], grow(b, 1.25)[1] - 2 * k), (grow(a, 1.25)[0], grow(a, 1.25)[1] - 2 * k)], (176, 170, 158))

def _mid(p, q): return ((p[0] + q[0]) / 2, (p[1] + q[1]) / 2)


def _station_decor(C, onL, onR, w, d, a, ph, hgt, Fl, Fr, kind):
    """Each shop's own sign, windows and props (0.29-0.40 designs), painted on the 0.45 medieval building."""
    k = C.k
    _lattice = _leaded
    def dot(p, r, col): pygame.draw.circle(C.S, col, (int(p[0]), int(p[1])), int(r * k))
    if kind == "forge":
        # big glowing forge mouth on the right face + chimney
        mouth = [onR(.28, ph), onR(.72, ph), onR(.72, ph + 26), onR(.28, ph + 26)]
        C.poly(mouth, (30, 26, 28)); inner = [onR(.34, ph + 2), onR(.66, ph + 2), onR(.66, ph + 20), onR(.34, ph + 20)]
        C.poly(inner, (255, 120, 30)); C.poly([onR(.4, ph + 3), onR(.6, ph + 3), onR(.6, ph + 12), onR(.4, ph + 12)], (255, 220, 110))
        for t in (.12, .82): _lattice(C, [onL(t, ph + 20), onL(t + .1, ph + 20), onL(t + .1, ph + 38), onL(t, ph + 38)], glow=(255, 150, 70))
        # anvil in front
        ax_, ay_ = C.P(w - .3, d + .1, 0)
        pygame.draw.polygon(C.S, (46, 46, 54), [(ax_ - 14 * k, ay_ - 12 * k), (ax_ + 16 * k, ay_ - 12 * k), (ax_ + 8 * k, ay_ - 6 * k), (ax_ + 6 * k, ay_), (ax_ - 6 * k, ay_), (ax_ - 8 * k, ay_ - 6 * k)])
        pygame.draw.rect(C.S, (90, 90, 100), (ax_ - 14 * k, ay_ - 13 * k, 30 * k, 3 * k))
    elif kind == "warhall":
        # crossed swords shield over the door, banners and a weapon rack
        sc = onL(.5, ph + 44)
        pygame.draw.polygon(C.S, (60, 40, 30), [(sc[0] - 13 * k, sc[1] - 12 * k), (sc[0] + 13 * k, sc[1] - 12 * k), (sc[0] + 13 * k, sc[1] + 4 * k), (sc[0], sc[1] + 14 * k), (sc[0] - 13 * k, sc[1] + 4 * k)])
        pygame.draw.polygon(C.S, (200, 52, 44), [(sc[0] - 10 * k, sc[1] - 9 * k), (sc[0] + 10 * k, sc[1] - 9 * k), (sc[0] + 10 * k, sc[1] + 3 * k), (sc[0], sc[1] + 11 * k), (sc[0] - 10 * k, sc[1] + 3 * k)])
        pygame.draw.line(C.S, (230, 230, 240), (sc[0] - 9 * k, sc[1] - 8 * k), (sc[0] + 9 * k, sc[1] + 8 * k), 2 * k)
        pygame.draw.line(C.S, (230, 230, 240), (sc[0] + 9 * k, sc[1] - 8 * k), (sc[0] - 9 * k, sc[1] + 8 * k), 2 * k)
        for t in (.08, .86):
            b0 = onL(t, ph + 52); b1 = onL(t + .06, ph + 52)
            C.poly([b0, b1, (b1[0], b1[1] + 34 * k), ((b0[0] + b1[0]) / 2, b1[1] + 28 * k), (b0[0], b0[1] + 34 * k)], (170, 36, 40))
        for t in (.2, .52):
            _lattice(C, [onR(t, ph + 16), onR(t + .2, ph + 16), onR(t + .2, ph + 34), onR(t, ph + 34)], glow=(255, 190, 120))
        for j in range(4):
            rp_ = C.P(a + .3 + j * .22, d + .22, 0)
            pygame.draw.line(C.S, (120, 90, 60), (rp_[0], rp_[1]), (rp_[0] + 4 * k, rp_[1] - 36 * k), 2 * k)
            pygame.draw.polygon(C.S, (210, 214, 224), [(rp_[0] + 4 * k, rp_[1] - 36 * k), (rp_[0] + 1 * k, rp_[1] - 30 * k), (rp_[0] + 7 * k, rp_[1] - 30 * k)])
    elif kind == "hut":
        # fish sign, net racks and hanging fish
        sgn = [onL(.7, ph + 30), onL(.96, ph + 30), onL(.96, ph + 44), onL(.7, ph + 44)]
        C.poly(sgn, (240, 226, 190)); pygame.draw.polygon(C.S, (70, 44, 24), sgn, k)
        fc = onL(.83, ph + 37)
        pygame.draw.ellipse(C.S, (70, 130, 190), (fc[0] - 8 * k, fc[1] - 4 * k, 14 * k, 8 * k)); pygame.draw.polygon(C.S, (70, 130, 190), [(fc[0] + 5 * k, fc[1]), (fc[0] + 11 * k, fc[1] - 4 * k), (fc[0] + 11 * k, fc[1] + 4 * k)])
        for t in (.05, .15, .25):
            p0 = onR(t + .1, ph + 40); pygame.draw.line(C.S, (90, 70, 44), p0, (p0[0], p0[1] + 18 * k), k)
            pygame.draw.ellipse(C.S, (170, 190, 205), (p0[0] - 3 * k, p0[1] + 12 * k, 6 * k, 14 * k))
        _lattice(C, [onR(.45, ph + 14), onR(.7, ph + 14), onR(.7, ph + 30), onR(.45, ph + 30)], glow=(255, 224, 150))
        # stacked crates and a barrel
        for j, (ox, oy) in enumerate(((-.2, .2), (-.45, .1))):
            p = C.P(a + ox, d - a + .35 + oy, 0)
            pygame.draw.rect(C.S, (126, 92, 56), (p[0] - 9 * k, p[1] - 14 * k, 18 * k, 14 * k)); pygame.draw.rect(C.S, (70, 50, 30), (p[0] - 9 * k, p[1] - 14 * k, 18 * k, 14 * k), k)
    elif kind == "magic":
        # 0.38 Skill Shop: a glowing rune circle over the door, arcane windows, a floating crystal by the steps
        rc = onL(.5, ph + 42)
        pygame.draw.circle(C.S, (40, 24, 70), (int(rc[0]), int(rc[1])), 13 * k)
        pygame.draw.circle(C.S, (170, 120, 255), (int(rc[0]), int(rc[1])), 11 * k, 2 * k)
        pygame.draw.circle(C.S, (120, 220, 255), (int(rc[0]), int(rc[1])), 6 * k, k)
        for j in range(6):
            an = j / 6 * math.tau
            pygame.draw.circle(C.S, (230, 200, 255), (int(rc[0] + math.cos(an) * 8.5 * k), int(rc[1] + math.sin(an) * 8.5 * k)), max(1, k))
        for t in (.08, .76):
            _lattice(C, [onL(t, ph + 16), onL(t + .15, ph + 16), onL(t + .15, ph + 34), onL(t, ph + 34)], glow=(170, 140, 255))
        for t in (.2, .55):
            _lattice(C, [onR(t, ph + 18), onR(t + .2, ph + 18), onR(t + .2, ph + 36), onR(t, ph + 36)], glow=(120, 200, 255))
        cp_ = C.P(w + .15, d - .2, 0)
        pygame.draw.ellipse(C.S, (0, 0, 0, 60), (cp_[0] - 8 * k, cp_[1] - 3 * k, 16 * k, 6 * k))
        cy_ = cp_[1] - 30 * k
        pygame.draw.polygon(C.S, (130, 210, 255), [(cp_[0], cy_ - 12 * k), (cp_[0] + 6 * k, cy_), (cp_[0], cy_ + 12 * k), (cp_[0] - 6 * k, cy_)])
        pygame.draw.polygon(C.S, (220, 245, 255), [(cp_[0], cy_ - 12 * k), (cp_[0] + 2 * k, cy_), (cp_[0], cy_ + 12 * k), (cp_[0] - 3 * k, cy_)])
        pygame.draw.polygon(C.S, (60, 110, 190), [(cp_[0], cy_ - 12 * k), (cp_[0] + 6 * k, cy_), (cp_[0], cy_ + 12 * k), (cp_[0] - 6 * k, cy_)], k)
    elif kind == "apothecary":
        # 0.39: a potion-bottle sign, hanging herb bundles and green-lit windows
        sg = onL(.5, ph + 40)
        pygame.draw.circle(C.S, (60, 40, 30), (int(sg[0]), int(sg[1])), 11 * k)
        pygame.draw.circle(C.S, (90, 200, 110), (int(sg[0]), int(sg[1] + 2 * k)), 7 * k)
        pygame.draw.rect(C.S, (200, 220, 230), (sg[0] - 2 * k, sg[1] - 9 * k, 4 * k, 6 * k))
        for t in (.06, .16, .80, .90):
            hb = onL(t, ph + 34); pygame.draw.line(C.S, (90, 70, 44), hb, (hb[0], hb[1] + 8 * k), k)
            pygame.draw.ellipse(C.S, (96, 150, 70), (hb[0] - 3 * k, hb[1] + 7 * k, 6 * k, 10 * k))
        for t in (.2, .55):
            _lattice(C, [onR(t, ph + 16), onR(t + .2, ph + 16), onR(t + .2, ph + 32), onR(t, ph + 32)], glow=(150, 230, 150))
    elif kind == "inn":
        # 0.39: a hanging tankard sign, warm windows on both floors and a barrel by the door
        sg = [onL(.68, ph + 30), onL(.94, ph + 30), onL(.94, ph + 46), onL(.68, ph + 46)]
        C.poly(sg, (120, 82, 46)); pygame.draw.polygon(C.S, (60, 38, 20), sg, k)
        mc = onL(.81, ph + 38)
        pygame.draw.rect(C.S, (230, 190, 90), (mc[0] - 4 * k, mc[1] - 5 * k, 8 * k, 10 * k)); pygame.draw.rect(C.S, (250, 245, 230), (mc[0] - 4 * k, mc[1] - 7 * k, 8 * k, 3 * k))
        for t in (.06, .24):
            _lattice(C, [onL(t, ph + 14), onL(t + .12, ph + 14), onL(t + .12, ph + 28), onL(t, ph + 28)], glow=(255, 200, 120))
        for t in (.12, .42, .72):
            _lattice(C, [onR(t, ph + 40), onR(t + .14, ph + 40), onR(t + .14, ph + 54), onR(t, ph + 54)], glow=(255, 200, 120))
        bp = C.P(a + .1, d + .25, 0)
        pygame.draw.ellipse(C.S, (110, 72, 40), (bp[0] - 9 * k, bp[1] - 16 * k, 18 * k, 18 * k)); pygame.draw.ellipse(C.S, (60, 40, 22), (bp[0] - 9 * k, bp[1] - 16 * k, 18 * k, 18 * k), k)
    elif kind == "jeweler":
        # 0.39: a cut-gem sign and a display window that glints
        gc = onL(.5, ph + 42)
        pts = [(gc[0], gc[1] - 10 * k), (gc[0] + 9 * k, gc[1] - 3 * k), (gc[0], gc[1] + 10 * k), (gc[0] - 9 * k, gc[1] - 3 * k)]
        pygame.draw.polygon(C.S, (90, 220, 230), pts); pygame.draw.polygon(C.S, (230, 255, 255), [pts[0], pts[1], (gc[0], gc[1] - 3 * k)])
        pygame.draw.polygon(C.S, (30, 90, 110), pts, k)
        for t in (.08, .74):
            _lattice(C, [onL(t, ph + 14), onL(t + .18, ph + 14), onL(t + .18, ph + 30), onL(t, ph + 30)], glow=(200, 240, 255))
        for t in (.25, .55):
            _lattice(C, [onR(t, ph + 16), onR(t + .2, ph + 16), onR(t + .2, ph + 32), onR(t, ph + 32)], glow=(255, 230, 160))
    elif kind == "smithy":
        # 0.40: the Blacksmith's shop - a crossed hammer-and-sword sign and a rack of blades by the door
        sc = onL(.5, ph + 42)
        pygame.draw.circle(C.S, (50, 44, 40), (int(sc[0]), int(sc[1])), 12 * k)
        pygame.draw.line(C.S, (220, 224, 232), (sc[0] - 8 * k, sc[1] + 8 * k), (sc[0] + 8 * k, sc[1] - 8 * k), 2 * k)
        pygame.draw.rect(C.S, (160, 120, 70), (sc[0] + 2 * k, sc[1] - 2 * k, 3 * k, 11 * k)); pygame.draw.rect(C.S, (120, 124, 136), (sc[0] - 2 * k, sc[1] - 7 * k, 11 * k, 6 * k))
        for t in (.08, .76):
            _lattice(C, [onL(t, ph + 14), onL(t + .16, ph + 14), onL(t + .16, ph + 30), onL(t, ph + 30)], glow=(255, 190, 120))
        for j in range(3):
            rp_ = C.P(w + .2, a + .4 + j * .3, 0)
            pygame.draw.line(C.S, (110, 80, 50), rp_, (rp_[0] + 3 * k, rp_[1] - 34 * k), 2 * k)
            pygame.draw.polygon(C.S, (214, 218, 228), [(rp_[0] + 3 * k, rp_[1] - 40 * k), (rp_[0] + 6 * k, rp_[1] - 30 * k), (rp_[0] + 1 * k, rp_[1] - 30 * k)])
    elif kind == "enchanter":
        # 0.40: the Enchanter - a glowing sword-and-rune sign and blue-lit windows
        sc = onL(.5, ph + 44)
        pygame.draw.circle(C.S, (30, 30, 70), (int(sc[0]), int(sc[1])), 13 * k)
        pygame.draw.circle(C.S, (120, 180, 255), (int(sc[0]), int(sc[1])), 11 * k, 2 * k)
        pygame.draw.line(C.S, (230, 240, 255), (sc[0], sc[1] - 9 * k), (sc[0], sc[1] + 8 * k), 2 * k)
        pygame.draw.line(C.S, (200, 170, 90), (sc[0] - 5 * k, sc[1] + 3 * k), (sc[0] + 5 * k, sc[1] + 3 * k), 2 * k)
        for t in (.08, .76):
            _lattice(C, [onL(t, ph + 16), onL(t + .15, ph + 16), onL(t + .15, ph + 34), onL(t, ph + 34)], glow=(130, 190, 255))
        for t in (.22, .56):
            _lattice(C, [onR(t, ph + 18), onR(t + .2, ph + 18), onR(t + .2, ph + 36), onR(t, ph + 36)], glow=(170, 150, 255))
    elif kind == "bank":
        # 0.40: the Bank - stone pillars, a gold-coin sign and barred windows
        sc = onL(.5, ph + 44)
        pygame.draw.circle(C.S, (120, 90, 30), (int(sc[0]), int(sc[1])), 12 * k)
        pygame.draw.circle(C.S, (250, 210, 90), (int(sc[0]), int(sc[1])), 10 * k)
        pygame.draw.circle(C.S, (200, 160, 50), (int(sc[0]), int(sc[1])), 6 * k, k)
        for t in (.14, .30, .70, .86):
            pygame.draw.line(C.S, (236, 232, 222), onL(t, ph), onL(t, ph + 36), 4 * k)
        for t in (.25, .58):
            win = [onR(t, ph + 16), onR(t + .18, ph + 16), onR(t + .18, ph + 32), onR(t, ph + 32)]
            C.poly(win, (60, 60, 70))
            for q in (.33, .66): pygame.draw.line(C.S, (170, 170, 180), onR(t + .18 * q, ph + 16), onR(t + .18 * q, ph + 32), k)
    elif kind == "general":
        # 0.40: the General Store - a sack-and-scales sign, crates and a barrel out front
        sg = [onL(.66, ph + 30), onL(.94, ph + 30), onL(.94, ph + 46), onL(.66, ph + 46)]
        C.poly(sg, (236, 222, 186)); pygame.draw.polygon(C.S, (90, 60, 30), sg, k)
        mc = onL(.8, ph + 38); pygame.draw.ellipse(C.S, (170, 130, 80), (mc[0] - 6 * k, mc[1] - 5 * k, 12 * k, 10 * k))
        for t in (.08, .30):
            _lattice(C, [onL(t, ph + 14), onL(t + .14, ph + 14), onL(t + .14, ph + 30), onL(t, ph + 30)], glow=(255, 214, 150))
        for j, (ox, oy) in enumerate(((-.15, .25), (-.42, .15), (-.28, .45))):
            p = C.P(a + ox, d - a + .3 + oy, 0)
            pygame.draw.rect(C.S, (140, 100, 58), (p[0] - 9 * k, p[1] - 14 * k, 18 * k, 14 * k)); pygame.draw.rect(C.S, (80, 56, 32), (p[0] - 9 * k, p[1] - 14 * k, 18 * k, 14 * k), k)
    elif kind == "stable":
        # 0.40.1: the Stable - a horseshoe sign, cross-braced stall doors, a hay loft and hay bales out front
        sc = onL(.5, ph + 44)
        pygame.draw.circle(C.S, (90, 60, 36), (int(sc[0]), int(sc[1])), 12 * k)
        pygame.draw.arc(C.S, (200, 200, 210), (sc[0] - 8 * k, sc[1] - 7 * k, 16 * k, 16 * k), -.35, math.pi + .35, 3 * k)
        for sx_ in (-6, -2, 2, 6): pygame.draw.circle(C.S, (60, 50, 44), (int(sc[0] + sx_ * k), int(sc[1] - 4 * k + abs(sx_) * .6 * k)), max(1, k))
        for t in (.14, .56):
            dr = [onR(t, ph), onR(t + .3, ph), onR(t + .3, ph + 26), onR(t, ph + 26)]
            C.poly(dr, (110, 70, 40)); pygame.draw.polygon(C.S, (230, 222, 200), dr, k)
            pygame.draw.line(C.S, (230, 222, 200), dr[0], dr[2], k); pygame.draw.line(C.S, (230, 222, 200), dr[1], dr[3], k)
        loft = [onR(.38, ph + 36), onR(.62, ph + 36), onR(.62, ph + 50), onR(.38, ph + 50)]
        C.poly(loft, (50, 34, 22)); C.poly([onR(.40, ph + 36), onR(.60, ph + 36), onR(.60, ph + 42), onR(.40, ph + 42)], (214, 184, 92))
        for t in (.08, .78):
            _lattice(C, [onL(t, ph + 14), onL(t + .14, ph + 14), onL(t + .14, ph + 30), onL(t, ph + 30)], glow=(255, 214, 140))
        for j, (ox, oy) in enumerate(((-.15, .25), (-.45, .2), (-.3, .1))):
            p = C.P(a + ox, d - a + .3 + oy, 0); hz = 10 if j < 2 else 20
            hb = (p[0] - 11 * k, p[1] - hz * k, 22 * k, 10 * k)
            pygame.draw.rect(C.S, (214, 184, 92), hb); pygame.draw.rect(C.S, (150, 118, 50), hb, k)
            pygame.draw.line(C.S, (150, 118, 50), (p[0] - 4 * k, p[1] - hz * k), (p[0] - 4 * k, p[1] - (hz - 10) * k), k)
        # a hitching post with a water trough on the right
        tp = C.P(w + .25, d * .5, 0)
        pygame.draw.rect(C.S, (110, 76, 44), (tp[0] - 14 * k, tp[1] - 8 * k, 28 * k, 8 * k)); pygame.draw.rect(C.S, (90, 150, 200), (tp[0] - 12 * k, tp[1] - 8 * k, 24 * k, 3 * k))
        for sx_ in (-14, 14): pygame.draw.line(C.S, (96, 66, 38), (tp[0] + sx_ * k, tp[1]), (tp[0] + sx_ * k, tp[1] - 22 * k), 3 * k)
        pygame.draw.line(C.S, (96, 66, 38), (tp[0] - 14 * k, tp[1] - 20 * k), (tp[0] + 14 * k, tp[1] - 20 * k), 2 * k)
    elif kind == "teleport":
        # 0.46.36: the Waygate - a glowing teal portal ring over the door, with a crystal on either side
        sc = onL(.5, ph + 46)
        pygame.draw.circle(C.S, (20, 40, 56), (int(sc[0]), int(sc[1])), 15 * k)
        pygame.draw.circle(C.S, (90, 230, 240), (int(sc[0]), int(sc[1])), 12 * k, 2 * k)
        pygame.draw.circle(C.S, (160, 250, 255), (int(sc[0]), int(sc[1])), 6 * k)
        for t in (.08, .86):
            c0 = onL(t, ph + 20)
            pygame.draw.polygon(C.S, (90, 230, 240), [(c0[0], c0[1] - 20 * k), (c0[0] + 6 * k, c0[1] - 6 * k), (c0[0], c0[1] + 4 * k), (c0[0] - 6 * k, c0[1] - 6 * k)])
            pygame.draw.polygon(C.S, (220, 255, 255), [(c0[0], c0[1] - 20 * k), (c0[0] + 2 * k, c0[1] - 8 * k), (c0[0], c0[1] - 2 * k)])
    elif kind == "market":
        # 0.40.1: the Trade Market - a striped awning over goods tables, a balance-scales sign and sacks of wares
        sc = onL(.5, ph + 46)
        pygame.draw.circle(C.S, (40, 80, 80), (int(sc[0]), int(sc[1])), 12 * k)
        pygame.draw.line(C.S, (240, 210, 100), (sc[0], sc[1] - 8 * k), (sc[0], sc[1] + 7 * k), 2 * k)
        pygame.draw.line(C.S, (240, 210, 100), (sc[0] - 8 * k, sc[1] - 5 * k), (sc[0] + 8 * k, sc[1] - 5 * k), 2 * k)
        for sx_ in (-7, 7): pygame.draw.arc(C.S, (240, 210, 100), (sc[0] + sx_ * k - 4 * k, sc[1] - 2 * k, 8 * k, 6 * k), math.pi, math.tau, k)
        for i in range(6):
            t0_ = .04 + i * .15
            aw = [onL(t0_, ph + 34), onL(t0_ + .15, ph + 34), C.P(a + (w - 2 * a) * (t0_ + .15), d - a + .35, ph + 24), C.P(a + (w - 2 * a) * t0_, d - a + .35, ph + 24)]
            C.poly(aw, (40, 140, 130) if i % 2 else (236, 228, 206))
        for t in (.10, .70):
            tb = C.P(a + (w - 2 * a) * (t + .1), d - a + .28, ph + 10)
            pygame.draw.rect(C.S, (120, 84, 50), (tb[0] - 12 * k, tb[1] - 2 * k, 24 * k, 4 * k))
            for j, col in enumerate(((200, 60, 50), (230, 180, 60), (90, 160, 70))):
                pygame.draw.circle(C.S, col, (int(tb[0] - 7 * k + j * 7 * k), int(tb[1] - 4 * k)), 3 * k)
        for t in (.22, .56):
            _lattice(C, [onR(t, ph + 16), onR(t + .2, ph + 16), onR(t + .2, ph + 32), onR(t, ph + 32)], glow=(255, 220, 150))
        for j, (ox, oy) in enumerate(((w + .2, .55), (w + .3, .95))):
            p = C.P(ox, oy, 0)
            pygame.draw.ellipse(C.S, (184, 160, 110), (p[0] - 8 * k, p[1] - 16 * k, 16 * k, 18 * k)); pygame.draw.ellipse(C.S, (120, 96, 60), (p[0] - 8 * k, p[1] - 16 * k, 16 * k, 18 * k), k)
    elif kind == "kiln":
        # 0.39: a brick workshop with a domed kiln whose mouth glows
        kp = C.P(w + .1, d * .5, 0)
        pygame.draw.ellipse(C.S, (130, 70, 50), (kp[0] - 22 * k, kp[1] - 34 * k, 44 * k, 40 * k))
        pygame.draw.ellipse(C.S, (90, 46, 34), (kp[0] - 22 * k, kp[1] - 34 * k, 44 * k, 40 * k), 2 * k)
        pygame.draw.ellipse(C.S, (40, 20, 16), (kp[0] - 9 * k, kp[1] - 16 * k, 18 * k, 14 * k))
        pygame.draw.ellipse(C.S, (255, 150, 50), (kp[0] - 7 * k, kp[1] - 14 * k, 14 * k, 10 * k))
        pygame.draw.ellipse(C.S, (255, 230, 140), (kp[0] - 4 * k, kp[1] - 12 * k, 8 * k, 6 * k))
        _lattice(C, [onL(.1, ph + 12), onL(.28, ph + 12), onL(.28, ph + 26), onL(.1, ph + 26)], glow=(255, 170, 90))
    else:
        # wine press: big barrels in front, grapes sign and a vine over the door
        for j, (bx_, by_) in enumerate(((.15, .55), (.45, .8), (.75, .6))):
            p = C.P(a + (w - 2 * a) * bx_, d - a + .45 + by_ * .1 + j * .08, 0)
            pygame.draw.ellipse(C.S, (96, 62, 36), (p[0] - 10 * k, p[1] - 18 * k, 20 * k, 20 * k)); pygame.draw.ellipse(C.S, (60, 38, 22), (p[0] - 10 * k, p[1] - 18 * k, 20 * k, 20 * k), k)
            for yy in (-13, -7): pygame.draw.line(C.S, (150, 150, 160), (p[0] - 10 * k, p[1] + yy * k), (p[0] + 10 * k, p[1] + yy * k), k)
        for j in range(7):
            gp = onL(.3 + j * .06, ph + 34 + (j % 2) * 3); dot(gp, 3, (110, 50, 130)); dot((gp[0] - k, gp[1] - 2 * k), 1, (190, 140, 210))
        for t in (.1, .74): _lattice(C, [onL(t, ph + 16), onL(t + .15, ph + 16), onL(t + .15, ph + 34), onL(t, ph + 34)])
        # screw press on the right face
        bp = onR(.5, ph + 10); pygame.draw.rect(C.S, (110, 74, 44), (bp[0] - 4 * k, bp[1] - 14 * k, 8 * k, 26 * k))
        pygame.draw.rect(C.S, (84, 56, 34), (bp[0] - 14 * k, bp[1] - 16 * k, 28 * k, 4 * k))


def co_station(kind, style):
    from . import medieval
    return medieval.station(kind, style, lambda C, onL, onR, w, d, a, ph, hgt, Fl, Fr: _station_decor(C, onL, onR, w, d, a, ph, hgt, Fl, Fr, kind))


def co_building(kind, style, var=0):
    from . import medieval
    if kind == "house": return medieval.house(style, var)
    if kind == "tower": return medieval.tower(style, var)
    return None


def co_lamp():
    """Red paper lantern on a carved wooden post (light centre stays ~70 px above the base)."""
    C = _IsoCanvas((140, 340), (70, 320)); k = C.k
    b = C.P(0, 0, 0)
    pygame.draw.ellipse(C.S, (0, 0, 0, 70), (b[0] - 14 * k, b[1] - 4 * k, 28 * k, 9 * k))
    pygame.draw.rect(C.S, shade(CO_STONE, .8), (b[0] - 8 * k, b[1] - 6 * k, 16 * k, 7 * k))
    pygame.draw.rect(C.S, shade(CO_STONE, 1.1), (b[0] - 8 * k, b[1] - 8 * k, 16 * k, 3 * k))
    pygame.draw.rect(C.S, CO_TIMBER, (b[0] - 3 * k, b[1] - 86 * k, 6 * k, 80 * k))
    pygame.draw.rect(C.S, shade(CO_TIMBER, 1.4), (b[0] - 3 * k, b[1] - 86 * k, 2 * k, 80 * k))
    pygame.draw.line(C.S, CO_TIMBER, (b[0] - 2 * k, b[1] - 84 * k), (b[0] + 16 * k, b[1] - 84 * k), 3 * k)
    pygame.draw.line(C.S, CO_GOLD, (b[0] + 16 * k, b[1] - 86 * k), (b[0] + 19 * k, b[1] - 90 * k), 2 * k)
    _lantern(C, (b[0] + 12 * k, b[1] - 84 * k), 4, 1.25)
    # second, smaller lantern on the other side
    pygame.draw.line(C.S, CO_TIMBER, (b[0] + 2 * k, b[1] - 70 * k), (b[0] - 14 * k, b[1] - 70 * k), 2 * k)
    _lantern(C, (b[0] - 10 * k, b[1] - 70 * k), 3, .9)
    spr, anc = C.crop((0, 0, 0))
    return spr, anc

def co_fountain():
    """White marble basin with a gold-rimmed tier and a jade dragon spout."""
    C = _IsoCanvas((420, 360), (210, 250)); k = C.k
    c = C.P(.5, .5, 0)
    def ell(cx, cy, rw, rh, col, w=0): pygame.draw.ellipse(C.S, col, (cx - rw, cy - rh, rw * 2, rh * 2), w)
    ell(c[0], c[1] + 6 * k, 64 * k, 30 * k, (0, 0, 0, 70))
    ell(c[0], c[1], 60 * k, 28 * k, (176, 172, 168))
    ell(c[0], c[1] - 10 * k, 60 * k, 28 * k, (226, 222, 214))
    pygame.draw.rect(C.S, (176, 172, 168), (c[0] - 60 * k, c[1] - 10 * k, 120 * k, 10 * k))
    ell(c[0], c[1] - 10 * k, 60 * k, 28 * k, (226, 222, 214))
    ell(c[0], c[1] - 10 * k, 60 * k, 28 * k, CO_GOLD, 2 * k)
    ell(c[0], c[1] - 10 * k, 50 * k, 22 * k, (60, 136, 190))
    ell(c[0] - 8 * k, c[1] - 14 * k, 30 * k, 10 * k, (120, 190, 230))
    pygame.draw.rect(C.S, (210, 206, 198), (c[0] - 7 * k, c[1] - 52 * k, 14 * k, 44 * k))
    ell(c[0], c[1] - 50 * k, 24 * k, 9 * k, (226, 222, 214)); ell(c[0], c[1] - 50 * k, 24 * k, 9 * k, CO_GOLD, k)
    ell(c[0], c[1] - 51 * k, 18 * k, 6 * k, (70, 150, 200))
    jade = (60, 160, 120)
    pygame.draw.circle(C.S, jade, (int(c[0]), int(c[1] - 66 * k)), 9 * k)
    pygame.draw.circle(C.S, shade(jade, 1.4), (int(c[0] - 3 * k), int(c[1] - 69 * k)), 3 * k)
    for i in range(8):
        ang = i / 8 * math.tau
        ex = c[0] + math.cos(ang) * 36 * k; ey = c[1] - 14 * k + math.sin(ang) * 14 * k
        pygame.draw.line(C.S, (190, 225, 255), (c[0], c[1] - 66 * k), (ex, ey), k)
    spr, anc = C.crop((.5, .5, 0))
    return spr, anc


# ====================================================================== mounts (0.19)
_MOUNT = SurfaceCache(48)       # 0.45: memory-capped (keys include the rider, so it grew with every mounted adventurer)
GY = 222                       # ground line in 2x mount space

def _leg4(S, hip, foot, col, hoof, w=14):
    knee = (hip[0] + (foot[0] - hip[0]) * .5 + 7, hip[1] + (foot[1] - hip[1]) * .5)
    hock = (knee[0] + (foot[0] - knee[0]) * .55 - 3, knee[1] + (foot[1] - knee[1]) * .55)
    _limb(S, hip, knee, w + 3, col); _limb(S, knee, hock, max(6, w - 3), col); _limb(S, hock, foot, max(5, w - 6), shade(col, .92))
    pygame.draw.circle(S, shade(col, 1.12), (int(knee[0]), int(knee[1])), max(4, w // 2 - 1))
    pygame.draw.circle(S, shade(col, .78), (int(hock[0]), int(hock[1])), max(3, w // 2 - 3), 1)
    pygame.draw.ellipse(S, shade(hoof, .55), (foot[0] - 8, foot[1] - 5, 19, 11))
    pygame.draw.ellipse(S, hoof, (foot[0] - 7, foot[1] - 4, 17, 8))

def _wing(S, root, col, mem, bat, flap, shade_f=1.0):
    rx, ry = root
    t = (0, .5, 1, .5)[flap % 4]
    tx, ty = rx - 28 - 46 * t, ry - 98 + 112 * t
    c = shade(col, shade_f); m = shade(mem, shade_f)
    lead = [(rx, ry), (rx + (tx - rx) * .45 - 4, ry + (ty - ry) * .5 - 16), (tx, ty)]
    t1 = (tx + (rx - tx) * .22, ty + 50); t2 = (tx + (rx - tx) * .55, ty + 42 + (ry - ty) * .25); t3 = (rx + 5, ry + 18)
    pygame.draw.polygon(S, shade(m, .7), [(p[0] + 2, p[1] + 2) for p in lead + [t1, t2, t3]])
    pygame.draw.polygon(S, m, lead + [t1, t2, t3])
    if bat:
        for p in (t1, t2, ((t1[0] + t2[0]) / 2, (t1[1] + t2[1]) / 2 + 4)):
            pygame.draw.line(S, c, (rx, ry), p, 4)
        pygame.draw.lines(S, c, False, lead, 5)
    else:
        for k in range(1, 6):
            u = k / 6
            a = (tx + (t1[0] - tx) * u, ty + (t1[1] - ty) * u); b = (rx + (tx - rx) * (1 - u) * .5 + 6, ry + (ty - ry) * (1 - u) * .45)
            pygame.draw.line(S, shade(c, .8 + .04 * k), b, a, 5)
        pygame.draw.lines(S, shade(c, 1.15), False, lead, 4)

def draw_mount(look, frame, flying=False):
    """Mount facing right on a 2x canvas. Returns (surface, seat_point_2x)."""
    S = pygame.Surface((330, 250), pygame.SRCALPHA)
    f = frame % 4 if frame >= 0 else -1
    sw = (10, 0, -10, 0) if f >= 0 else (0, 0, 0, 0)
    L = {"horse": ((150, 104, 70), (214, 188, 150), (58, 38, 26)), "warhorse": ((206, 208, 216), (230, 230, 236), (210, 170, 70)),
         "wolf": ((118, 122, 132), (190, 192, 198), (60, 62, 70)), "saber": ((212, 128, 52), (240, 220, 180), (40, 26, 20)),
         "gryphon": ((204, 152, 74), (226, 190, 120), (250, 246, 236)), "wyvern": ((92, 128, 98), (190, 200, 150), (130, 70, 90)),
         "pegasus": ((246, 246, 252), (255, 255, 255), (170, 220, 255)), "drake": ((44, 40, 52), (170, 70, 36), (40, 34, 44))}[look]
    body, belly, acc = L
    cy = 126
    bob = 0 if f < 0 else (0, 3, 0, 3)[f]
    seat = (150, cy - 32 - bob)
    # --- far wing
    if flying:
        wcol = {"gryphon": (150, 104, 56), "wyvern": (104, 150, 110), "pegasus": (240, 240, 250), "drake": (30, 28, 38)}[look]
        mem = {"gryphon": (176, 126, 66), "wyvern": (150, 84, 100), "pegasus": (250, 250, 255), "drake": (120, 26, 26)}[look]
        _wing(S, (140, cy - 22 - bob), wcol, mem, look in ("wyvern", "drake"), f if f >= 0 else 0, .72)
    # --- tail
    tc = acc if look in ("horse", "pegasus", "warhorse") else body
    sway = 0 if f < 0 else (-4, 0, 4, 0)[f]
    if look in ("wyvern", "drake"):
        pts = [(86, cy), (58, cy + 14 + sway), (28, cy + 8), (8, cy - 6 + sway)]
        for a, b, w in zip(pts, pts[1:], (22, 16, 10)): _limb(S, a, b, w, shade(body, .9))
        pygame.draw.polygon(S, belly if look == "drake" else acc, [(8, cy - 6 + sway), (-2, cy - 22), (20, cy - 12)])
    elif look in ("wolf", "saber"):
        _limb(S, (88, cy - 6), (52, cy - 24 + sway), 16, shade(body, .9)); _limb(S, (52, cy - 24 + sway), (34, cy - 12), 13, shade(body, .9))
        if look == "saber": pygame.draw.line(S, (30, 20, 16), (60, cy - 22), (46, cy - 20), 5)
    elif look == "gryphon":
        _limb(S, (88, cy), (50, cy + 10 + sway), 12, shade(body, .85)); pygame.draw.ellipse(S, (130, 80, 40), (30, cy + 4 + sway, 30, 22))
    else:
        for i in range(5):
            pygame.draw.line(S, shade(tc, .8 + .08 * i), (90, cy - 10 + i * 3), (44 + sway, cy + 24 + i * 6), 6)
    # --- far legs
    for hx, foot0, k in (() if flying else ((112, 108, 2), (196, 200, 0))):      # 0.46.37: flying mounts have no legs
        s = sw[(f + k) % 4] if f >= 0 else 0
        foot = (foot0 + s * 1.5, GY - (8 if s > 0 else 0))
        if look == "wyvern" and hx > 150: continue
        _leg4(S, (hx, cy + 10), foot, shade(body, .66), shade(acc if look != "gryphon" else (232, 176, 50), .6), 13)
    # --- body
    _gshape(S, (82, cy - 32 - bob, 134, 66), body, 28, 1.18, .62)
    _gshape(S, (92, cy + 4 - bob, 112, 26), belly if look in ("drake", "wyvern", "wolf") else shade(body, .85), 12, 1.1, .7)
    # --- neck and head
    nx = (196, cy - 16 - bob)
    if look == "wyvern":
        pts = [(196, cy - 14), (220, cy - 40), (236, cy - 70), (250, cy - 86 - bob)]
        for a, b, w in zip(pts, pts[1:], (26, 20, 15)): _limb(S, a, b, w, body)
        hd = (258, cy - 92 - bob)
    elif look in ("wolf", "saber"):
        _limb(S, nx, (232, cy - 34 - bob), 28, body); hd = (240, cy - 34 - bob)
    elif look == "gryphon":
        _limb(S, nx, (226, cy - 54 - bob), 26, (240, 236, 224)); hd = (236, cy - 62 - bob)
        for i in range(5):
            pygame.draw.polygon(S, (222, 214, 196), [(200 + i * 6, cy - 22 - bob - i * 5), (192 + i * 6, cy - 2 - bob - i * 5), (208 + i * 6, cy - 12 - bob - i * 5)])
    else:
        _limb(S, nx, (228, cy - 58 - bob), 30, body); hd = (240, cy - 66 - bob)
    hx_, hy_ = hd
    if look in ("horse", "warhorse", "pegasus"):
        _gshape(S, (hx_ - 14, hy_ - 14, 52, 28), body, 12, 1.15, .7)
        pygame.draw.ellipse(S, shade(body, .75), (hx_ + 26, hy_ - 2, 16, 14))
        pygame.draw.polygon(S, shade(body, .85), [(hx_ - 4, hy_ - 12), (hx_ - 8, hy_ - 34), (hx_ + 6, hy_ - 14)])
        pygame.draw.circle(S, (20, 16, 14), (hx_ + 12, hy_ - 4), 3)
        for i in range(7):
            pygame.draw.line(S, shade(acc, .8 + .05 * i), (hx_ - 6, hy_ - 14 + i * 2), (172 - i * 3, cy - 60 - bob + i * 9), 6)
        if look == "horse": pygame.draw.line(S, (240, 240, 232), (hx_ + 14, hy_ - 12), (hx_ + 30, hy_ + 4), 4)
        if look == "pegasus":
            for i in range(4): pygame.draw.circle(S, (190, 230, 255), (hx_ - 20 - i * 14, hy_ - 10 + i * 10), 4 - i // 2)
    elif look in ("wolf", "saber"):
        _gshape(S, (hx_ - 14, hy_ - 16, 50, 32), body, 14, 1.15, .7)
        pygame.draw.polygon(S, shade(body, .8), [(hx_ - 6, hy_ - 14), (hx_ - 4, hy_ - 38), (hx_ + 8, hy_ - 14)])
        pygame.draw.polygon(S, shade(body, .8), [(hx_ + 8, hy_ - 14), (hx_ + 16, hy_ - 36), (hx_ + 20, hy_ - 12)])
        pygame.draw.ellipse(S, belly, (hx_ + 20, hy_ - 2, 26, 16)); pygame.draw.circle(S, (24, 20, 20), (hx_ + 44, hy_ + 2), 4)
        pygame.draw.circle(S, (240, 210, 90) if look == "wolf" else (240, 230, 120), (hx_ + 18, hy_ - 6), 4); pygame.draw.circle(S, (10, 10, 10), (hx_ + 19, hy_ - 6), 2)
        if look == "saber":
            for sx in (hx_ + 28, hx_ + 38): pygame.draw.polygon(S, (250, 248, 236), [(sx, hy_ + 12), (sx + 5, hy_ + 12), (sx + 2, hy_ + 32)])
            for i in range(5): pygame.draw.line(S, (30, 20, 16), (112 + i * 20, cy - 32 - bob + i % 2 * 4), (118 + i * 20, cy - 8 - bob), 6)
    elif look == "gryphon":
        pygame.draw.circle(S, (252, 248, 238), (hx_, hy_), 19); pygame.draw.circle(S, shade((252, 248, 238), .8), (hx_ - 4, hy_ + 4), 14)
        pygame.draw.polygon(S, (236, 180, 52), [(hx_ + 10, hy_ - 6), (hx_ + 40, hy_ + 6), (hx_ + 12, hy_ + 16)])
        pygame.draw.line(S, (160, 110, 30), (hx_ + 12, hy_ + 5), (hx_ + 38, hy_ + 7), 2)
        pygame.draw.circle(S, (255, 200, 40), (hx_ + 6, hy_ - 5), 5); pygame.draw.circle(S, (10, 10, 10), (hx_ + 7, hy_ - 5), 2)
        for sg in (-1, 1): pygame.draw.polygon(S, (200, 150, 80), [(hx_ - 6, hy_ - 16), (hx_ - 14 + sg * 3, hy_ - 36), (hx_ + 2, hy_ - 16)])
    elif look in ("wyvern", "drake"):
        hc = body
        pygame.draw.polygon(S, shade(hc, .85), [(hx_ - 16, hy_ - 12), (hx_ + 30, hy_ - 10), (hx_ + 52, hy_ + 6), (hx_ + 30, hy_ + 16), (hx_ - 12, hy_ + 14)])
        pygame.draw.polygon(S, hc, [(hx_ - 14, hy_ - 14), (hx_ + 32, hy_ - 12), (hx_ + 54, hy_ + 4), (hx_ + 28, hy_ + 6), (hx_ - 12, hy_ + 8)])
        for sg in (0, 1): pygame.draw.polygon(S, (230, 220, 190), [(hx_ - 8 - sg * 10, hy_ - 12), (hx_ - 28 - sg * 12, hy_ - 36 + sg * 8), (hx_ + 2 - sg * 10, hy_ - 14)])
        eye = (255, 70, 40) if look == "drake" else (255, 220, 60)
        pygame.draw.circle(S, eye, (hx_ + 12, hy_ - 5), 5); pygame.draw.circle(S, (10, 6, 6), (hx_ + 13, hy_ - 5), 2)
        for tx in (hx_ + 34, hx_ + 42): pygame.draw.polygon(S, (250, 248, 236), [(tx, hy_ + 6), (tx + 4, hy_ + 6), (tx + 2, hy_ + 16)])
        if look == "drake":
            pygame.draw.circle(S, (255, 140, 40), (hx_ + 52, hy_ + 3), 4)
            for i in range(9): pygame.draw.polygon(S, (28, 24, 34), [(100 + i * 14, cy - 33 - bob + (i % 2) * 2), (104 + i * 14, cy - 50 - bob - (i == 4) * 6), (110 + i * 14, cy - 32 - bob)])
            for i in range(5): pygame.draw.line(S, (210, 90, 40), (112 + i * 18, cy + 14 - bob), (120 + i * 18, cy + 28 - bob), 3)
    # --- near legs
    for hx, foot0, k in (() if flying else ((110, 104, 0), (198, 204, 2))):
        if look == "wyvern" and hx > 150:
            pygame.draw.line(S, shade(body, 1.0), (hx - 6, cy + 14), (hx + 8, cy + 30), 7); continue
        s = sw[(f + k) % 4] if f >= 0 else 0
        foot = (foot0 + s * 1.5, GY - (8 if s > 0 else 0))
        hoof = shade(acc, .7) if look not in ("gryphon",) else (232, 176, 50)
        if look in ("horse", "warhorse", "pegasus"): hoof = (46, 38, 32)
        _leg4(S, (hx, cy + 10), foot, shade(body, 1.0), hoof, 14)
        if look == "gryphon" and hx > 150:
            for dx in (-8, 0, 8): pygame.draw.line(S, (236, 180, 52), (foot[0] + dx * .4, foot[1] - 2), (foot[0] + dx + 6, foot[1] + 8), 3)
        if look in ("horse", "warhorse", "pegasus"):
            pygame.draw.rect(S, (240, 236, 224), (foot[0] - 7, foot[1] - 22, 14, 12), border_radius=3)
    # --- near wing
    if flying:
        _wing(S, (156, cy - 26 - bob), wcol, mem, look in ("wyvern", "drake"), (f + 1) % 4 if f >= 0 else 0, 1.0)
    # --- tack: saddle and bridle (ground mounts and pegasus/gryphon)
    sc = {"horse": (130, 40, 36), "warhorse": (170, 30, 40), "wolf": (92, 62, 40), "saber": (90, 40, 30), "gryphon": (60, 90, 170),
          "wyvern": (80, 60, 40), "pegasus": (230, 190, 70), "drake": (150, 30, 30)}[look]
    pygame.draw.rect(S, shade(sc, .7), (118, seat[1] - 2, 66, 22), border_radius=9); pygame.draw.rect(S, sc, (122, seat[1] - 6, 58, 16), border_radius=8)
    pygame.draw.line(S, (214, 172, 62), (122, seat[1] + 6), (180, seat[1] + 6), 3)
    if look == "warhorse":
        for pts in ([(176, cy - 40), (214, cy - 52), (236, cy - 76), (222, cy - 40)], [(228, hy_ - 14), (262, hy_ - 12), (268, hy_ + 6), (240, hy_ + 10)]):
            pygame.draw.polygon(S, (200, 204, 214), pts); pygame.draw.polygon(S, (214, 172, 62), pts, 3)
        pygame.draw.polygon(S, (170, 30, 40), [(100, cy - 6), (186, cy - 6), (178, cy + 40), (108, cy + 40)]); pygame.draw.lines(S, (214, 172, 62), True, [(100, cy - 6), (186, cy - 6), (178, cy + 40), (108, cy + 40)], 3)
        pygame.draw.polygon(S, (200, 30, 40), [(hx_ - 4, hy_ - 14), (hx_ + 4, hy_ - 46), (hx_ + 12, hy_ - 14)])
    if look not in ("wolf", "saber", "wyvern", "drake", "gryphon"):
        pygame.draw.line(S, (60, 40, 30), (hx_ + 28, hy_ + 8), (hx_ + 6, hy_ - 4), 3)
        pygame.draw.line(S, (60, 40, 30), (hx_ + 22, hy_ + 10), (seat[0] + 34, seat[1]), 2)
    if look == "pegasus" and f >= 0:
        for i in range(6): pygame.draw.circle(S, (200, 236, 255), (60 - i * 8 + sway, cy + 30 + i * 3), max(1, 4 - i // 2))
    # --- coat texture, muscle shading, girth and breast-collar, eye shine
    def _coat(L):
        furry = look in ("horse", "warhorse", "wolf", "saber", "pegasus")
        for k in range(150):
            x = 84 + (k * 37) % 150; y = cy - 34 - bob + (k * 53) % 68
            if furry:
                pygame.draw.line(L, (*shade(body, .72 if k % 3 else 1.28), 120), (x, y), (x + 5, y + 2 + k % 3), 1)
            else:      # scales
                pygame.draw.arc(L, (*shade(body, .6), 110), (x, y, 9, 7), 3.4, 6.1, 1)
        pygame.draw.ellipse(L, (*shade(body, 1.3), 70), (96, cy - 30 - bob, 46, 30))        # haunch
        pygame.draw.ellipse(L, (*shade(body, 1.3), 70), (160, cy - 30 - bob, 36, 28))       # shoulder
        pygame.draw.ellipse(L, (0, 0, 0, 50), (104, cy - 2 - bob, 90, 22))                  # belly shadow
    _inlay(S, _coat)
    if look in ("horse", "warhorse", "pegasus", "wolf", "saber"):
        pygame.draw.line(S, (40, 28, 22), (170, seat[1] + 14), (166, cy + 22 - bob), 5)    # girth strap
        pygame.draw.line(S, (214, 172, 62), (170, seat[1] + 14), (166, cy + 22 - bob), 1)
        pygame.draw.circle(S, (214, 172, 62), (166, cy + 22 - bob), 4)
        pygame.draw.line(S, sc, (196, cy - 24 - bob), (204, cy - 4 - bob), 4)             # breast collar
    pygame.draw.circle(S, (255, 255, 255), (int(hx_ + (12 if look in ("horse", "warhorse", "pegasus") else 18)) - 1, int(hy_ - (5 if look in ("horse", "warhorse", "pegasus") else 7))), 1)
    return S, seat

def mounted_sprite(rkey, spec, look, frame, facing, attack=False, ms=1.1, rs=1.12, flying=False):
    """Rider + mount composite. Returns (sprite, ground anchor)."""
    k = (rkey, look, frame, facing, attack, flying, round(ms, 2))
    r = _MOUNT.get(k)
    if r is not None: return r
    if len(_MOUNT) > 300: _MOUNT.clear()        # 0.44.20: bounded - each gear change used to add a new set of big composites
    ds = (look, frame if frame >= 0 else -1, flying)
    mm = _MOUNT.get(("m",) + ds)
    if mm is None:
        S, seat = draw_mount(look, frame, flying)
        spr = paint_light(outline(_finish(S, .5 * ms)))
        mm = _MOUNT.put(("m",) + ds, (spr, (seat[0] * .5 * ms + 1, seat[1] * .5 * ms + 1), (150 * .5 * ms + 1, GY * .5 * ms + 1)))
    mspr, seat, ground = mm
    rspr, ranc = draw_humanoid(spec, -1, attack, rs)
    cut = int(HUMAN_SEAT_CUT * .5 * rs) + 6
    torso = rspr.subsurface((0, 0, rspr.get_width(), min(rspr.get_height(), cut))).copy()
    PADX, PADT = 40, 110
    C = pygame.Surface((mspr.get_width() + PADX * 2, mspr.get_height() + PADT), pygame.SRCALPHA)
    C.blit(mspr, (PADX, PADT))
    sx, sy = PADX + seat[0] + 2, PADT + seat[1] + 3
    # thigh and boot hanging over the near flank
    lg = spec.get("legs", (80, 80, 90)); bt = spec.get("boots", (50, 40, 34))
    pygame.draw.line(C, shade(lg, .6), (sx - 5, sy - 2), (sx + 10, sy + 12), 11)
    pygame.draw.line(C, lg, (sx - 5, sy - 3), (sx + 9, sy + 10), 8)
    pygame.draw.ellipse(C, bt, (sx + 4, sy + 9, 15, 9)); pygame.draw.ellipse(C, (24, 18, 14), (sx + 4, sy + 9, 15, 9), 1)
    C.blit(torso, (int(sx - ranc[0]), int(sy - torso.get_height() + 4)), special_flags=0)
    # redraw the thigh over the torso hem so the leg reads as "in front"
    pygame.draw.line(C, lg, (sx - 3, sy - 1), (sx + 9, sy + 10), 7)
    anc = (PADX + ground[0], PADT + ground[1])
    if facing < 0:
        C = pygame.transform.flip(C, True, False); anc = (C.get_width() - anc[0], anc[1])
    r = _MOUNT.put(k, (C, (int(anc[0]), int(anc[1]))))
    return r


# ------------------------------------------------------------------ 0.30 modern lighting pass
# Every tree, rock, building and wall gets: a warm rim light on its sun-facing edge, a cool ambient-occlusion
# gradient toward the ground, and (in game.py) a soft directional cast shadow that follows the sun.
_MOD = {}
FLAT_DECOR = {"pebbles", "flowers", "tallgrass", "dunegrass", "fern", "reeds", "bones", "ribs", "iceshard", "vent", "glowshroom", "banner", "signpost"}
SHADOW_DECOR = {"oak", "pine", "snowpine", "willow", "palm", "cactus", "crystal", "darkcrystal", "dead", "tent", "well", "haystack", "cart", "woodpile",
                "menhir", "ruin", "tomb", "boulders", "rock", "icerock", "lavarock", "bush", "stump", "campfire"}


def modernize(spr, rim=95, ao=.80, size_gate=18):
    """Rim light + ambient occlusion on a finished sprite. Returns a new surface; falls back to the original on any error."""
    try:
        w, h = spr.get_size()
        if h < size_gate or w < size_gate:
            return spr
        out = spr.copy()
        # ambient occlusion: darker and cooler toward the base, lighter on top
        grad = pygame.Surface((w, h))
        for y in range(h):
            f = y / max(1, h - 1)
            v = int(255 * (1.0 - (1 - ao) * max(0.0, f - .35) / .65))
            top = 1.0 + .06 * max(0.0, .4 - f) / .4
            grad.fill((min(255, int(v * top)), min(255, int(v * top)), min(255, int(min(255, v + 10) * top))), (0, y, w, 1))
        out.blit(grad, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        # rim light: the sprite's own silhouette minus itself shifted down-right = a thin lit edge on the upper-left
        A = spr.copy(); A.fill((255, 240, 205, 0), special_flags=pygame.BLEND_RGB_MAX)
        sh = pygame.Surface((w, h), pygame.SRCALPHA); sh.blit(A, (2, 2))
        A.blit(sh, (0, 0), special_flags=pygame.BLEND_RGBA_SUB)
        A.set_alpha(rim)
        out.blit(A, (0, 0))
        # 0.34 round 1 (definition): a touch of midtone contrast so materials separate
        sq = out.copy(); sq.blit(out, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        sq.fill((14, 14, 14, 0), special_flags=pygame.BLEND_RGB_ADD); sq.set_alpha(52)
        out.blit(sq, (0, 0))
        # 0.34 round 2 (light): cool core-shadow edge on the lower right to pair with the warm rim on the upper left
        D = spr.copy(); D.fill((26, 30, 54, 0), special_flags=pygame.BLEND_RGB_MIN)
        sd = pygame.Surface((w, h), pygame.SRCALPHA); sd.blit(D, (-2, -2))
        D.blit(sd, (0, 0), special_flags=pygame.BLEND_RGBA_SUB)
        D.set_alpha(max(30, rim - 25))
        out.blit(D, (0, 0))
        return out
    except Exception:
        return spr


def decor_sprite(kind, var=0):
    key = (kind, var)
    r = _MOD.get(key)
    if r is None:
        spr, anc = _decor_raw(kind, var)
        r = (spr, anc) if kind in FLAT_DECOR else (modernize(spr), anc)
        _MOD[key] = r
    return r


def wall_sprite(post=False, style="Neutral", mask=None):
    """City wall tile.  0.45: with a neighbour mask (medieval.wall_mask) the tile joins its neighbours into one
    continuous curtain wall; dungeon walls (style "Dungeon") keep the old block."""
    key = ("wall", post, style, mask)
    r = _MOD.get(key)
    if r is None:
        if style == "Cover":                # 0.45: battleground cover - low ruined walls that join their neighbours
            from . import medieval
            pump(); r = medieval.curtain_wall("Neutral", mask or 0, False, H=30, ruined=True)
        elif style == "Column":             # 0.45: dungeon pillars
            from . import medieval
            pump(); r = medieval.column("Dungeon", (mask or 0) % 3)
        elif mask is not None and style != "Dungeon":
            from . import medieval
            pump(); spr, anc = medieval.curtain_wall(style, mask, post)
            r = (spr, anc)
        else:
            spr, anc = _wall_raw(post, style)
            r = (modernize(spr, 70, .86), anc)
        _MOD[key] = r
    return r


def building_sprite(kind, style, var=0):
    key = ("b", kind, style, var)
    r = _MOD.get(key)
    if r is None:
        spr, anc, bw, bd = _building_raw(kind, style, var)
        spr = modernize(spr, 90, .84, 30) if kind not in ("fountain",) else spr
        try:                                    # 0.34: thin dark contact outline so buildings read against grass and roads
            m_ = pygame.mask.from_surface(spr, 200)       # high threshold: skip the translucent ground shadow
            sil_ = m_.to_surface(setcolor=(24, 18, 14, 150), unsetcolor=(0, 0, 0, 0))
            o_ = pygame.Surface((spr.get_width() + 2, spr.get_height() + 2), pygame.SRCALPHA)
            for dx_, dy_ in ((0, 1), (2, 1), (1, 0), (1, 2)): o_.blit(sil_, (dx_, dy_))
            o_.blit(spr, (1, 1)); spr = o_; anc = (anc[0] + 1, anc[1] + 1)
        except Exception:
            pass
        r = (spr, anc, bw, bd)
        _MOD[key] = r
    return r


_SHD = SurfaceCache(24)      # 0.37.2: memory-capped


def cast_shadow(spr, anc, shear, soft=False):
    """Flattened, sheared silhouette of a sprite. shear in -3..3 (sun position); returns (surface, dx, dy) relative to the anchor.
    soft (0.37 High): the edge is blurred, like a shadow under a real sun."""
    key = (spr, shear, soft)          # 0.37.2: the sprite itself, not id(spr) - ids are reused after a sprite is freed
    r = _SHD.get(key)
    if r is not None:
        return r
    try:
        w, h = spr.get_size()
        sil = pygame.mask.from_surface(spr, 110).to_surface(setcolor=(0, 0, 0, 92), unsetcolor=(0, 0, 0, 0))    # 0.45: solid parts only
        L = 0.30 + .09 * abs(shear)
        nh = max(4, int(h * L)); sil = pygame.transform.smoothscale(sil, (w, nh))
        k = (shear / 3.0) * 1.15
        extra = int(abs(k) * nh) + 2
        out = pygame.Surface((w + extra, nh), pygame.SRCALPHA)
        for y in range(nh):
            off = int((nh - 1 - y) * k) + (extra if k < 0 else 0)
            out.blit(sil, (off, y), (0, y, w, 1))
        r = (out, -anc[0] - (extra if k < 0 else 0), -nh + 6)
        if soft:
            p = 4; ow, oh = out.get_size()
            pad = pygame.Surface((ow + p * 2, oh + p * 2), pygame.SRCALPHA); pad.blit(out, (p, p))
            pad = pygame.transform.smoothscale(pygame.transform.smoothscale(pad, (max(2, (ow + p * 2) // 3), max(2, (oh + p * 2) // 3))), pad.get_size())
            r = (pad, r[1] - p, r[2] - p)
    except Exception:
        r = (None, 0, 0)
    if r[0] is not None: _SHD.put(key, r)
    return r


# ====================================================================== 0.45: catch / gather cards
FISH_LOOK = {   # back colour, belly colour, fin colour, length:height, pattern, extra
    "Meadow Trout":   ((92, 112, 60), (236, 224, 196), (150, 140, 90), 3.6, "speckle", "stripe_pink"),
    "Ironwood Pike":  ((70, 98, 52), (222, 222, 176), (120, 120, 70), 5.0, "bars_pale", "long_snout"),
    "Frost Char":     ((84, 104, 132), (244, 240, 236), (226, 110, 70), 3.6, "spots_white", ""),
    "Storm Mackerel": ((40, 92, 140), (228, 236, 240), (90, 120, 150), 4.0, "waves", ""),
    "Fen Eel":        ((70, 60, 40), (150, 140, 100), (90, 80, 52), 6.5, "", "eel"),
    "Crown Carp":     ((206, 140, 40), (250, 214, 120), (230, 150, 50), 2.8, "scales", "barbels"),
    "Dusk Catfish":   ((76, 64, 86), (170, 156, 160), (90, 80, 96), 3.8, "", "whiskers"),
    "Sun Perch":      ((150, 150, 40), (250, 226, 120), (230, 110, 50), 2.8, "bars_dark", "spiny"),
    "Ember Koi":      ((244, 240, 232), (250, 248, 244), (240, 236, 228), 3.2, "koi", ""),
    "Void Angler":    ((60, 40, 90), (110, 80, 140), (80, 56, 120), 2.6, "", "lure"),
}
_CARD = {}


def fish_portrait(name, width=150):
    """A shaded side view of the fish you caught, drawn from its species look (cached)."""
    key = ("fish", name, width)
    if key in _CARD: return _CARD[key]
    back, belly, fin, ratio, pat, extra = FISH_LOOK.get(name, ((90, 110, 130), (230, 230, 230), (120, 130, 150), 3.4, "", ""))
    k = 2; W_ = width * k; L = W_ * .78; Hh = L / ratio
    S = pygame.Surface((W_, int(Hh * 2.6) + 20 * k), pygame.SRCALPHA)
    cx0 = W_ * .1; cy = S.get_height() / 2
    def half(t):            # body half-height along the length (0 = snout, 1 = tail root)
        if extra == "eel": return Hh * .5 * (math.sin(math.pi * min(1, t * 1.15)) ** .35) * (1 - .55 * t)
        return Hh * .5 * (math.sin(math.pi * (t ** .8)) ** .9) * (1.0 if t < .85 else 1 - (t - .85) * 3)
    n = 40
    top = [(cx0 + L * i / n, cy - half(i / n) * (1.08 if pat == "" else 1.0)) for i in range(n + 1)]
    bot = [(cx0 + L * i / n, cy + half(i / n) * .92) for i in range(n, -1, -1)]
    if extra == "long_snout":
        top[0] = (top[0][0] - 10 * k, cy - 2 * k); bot[-1] = (bot[-1][0] - 10 * k, cy + 2 * k)
    body = top + bot
    tail_x = cx0 + L
    th = max(Hh * .55, 10 * k) if extra != "eel" else Hh * .4
    tail = [(tail_x - 4 * k, cy), (tail_x + Hh * .55, cy - th), (tail_x + Hh * .42, cy), (tail_x + Hh * .55, cy + th)]
    # fins behind the body
    pygame.draw.polygon(S, shade(fin, .85), tail)
    dors = [(cx0 + L * .38, cy - half(.38)), (cx0 + L * (.46 if extra != "spiny" else .42), cy - half(.45) - Hh * (.42 if extra != "eel" else .15)),
            (cx0 + L * .66, cy - half(.66) - Hh * .12), (cx0 + L * .7, cy - half(.7))]
    if extra == "eel": dors = [(cx0 + L * .3, cy - half(.3)), (cx0 + L * .6, cy - half(.6) - Hh * .25), (cx0 + L, cy - half(.95))]
    pygame.draw.polygon(S, fin, dors)
    if extra == "spiny":
        for i in range(6):
            x = cx0 + L * (.38 + i * .05); pygame.draw.line(S, shade(fin, .6), (x, cy - half(.4 + i * .05)), (x + 2 * k, cy - half(.4) - Hh * .45), k)
    pygame.draw.polygon(S, shade(fin, .9), [(cx0 + L * .55, cy + half(.55) * .9), (cx0 + L * .6, cy + half(.6) + Hh * .3), (cx0 + L * .7, cy + half(.7) * .9)])
    # body: belly colour, then the back colour fading down, clipped to the body outline
    lay = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    y0, y1 = int(cy - Hh * .6), int(cy + Hh * .6)
    for y in range(y0, y1):
        f = (y - y0) / max(1, (y1 - y0))
        c = mix(back, belly, max(0.0, min(1.0, (f - .3) / .35)))
        pygame.draw.line(lay, c, (0, y), (W_, y))
    if pat == "speckle":
        for i in range(70):
            x = cx0 + L * (.15 + .7 * h01(i, 1, 801)); y = cy - Hh * .45 + Hh * .6 * h01(i, 2, 802)
            pygame.draw.circle(lay, (40, 34, 24) if i % 3 else (190, 60, 70), (int(x), int(y)), k + (i % 2))
    if extra == "stripe_pink":
        pygame.draw.line(lay, (220, 120, 140), (cx0 + L * .2, cy - Hh * .02), (cx0 + L * .95, cy + Hh * .02), 4 * k)
    if pat == "bars_pale":
        for i in range(9):
            x = cx0 + L * (.2 + i * .08); pygame.draw.ellipse(lay, (190, 200, 140), (x, cy - Hh * .4, 6 * k, Hh * .45))
    if pat == "spots_white":
        for i in range(40):
            x = cx0 + L * (.15 + .75 * h01(i, 3, 803)); y = cy - Hh * .42 + Hh * .5 * h01(i, 4, 804)
            pygame.draw.circle(lay, (236, 240, 250), (int(x), int(y)), k + 1)
    if pat == "waves":
        for i in range(10):
            x = cx0 + L * (.2 + i * .07)
            pygame.draw.lines(lay, (20, 40, 70), False, [(x, cy - Hh * .5), (x + 5 * k, cy - Hh * .32), (x, cy - Hh * .14)], 2 * k)
    if pat == "scales":
        for r_ in range(5):
            for i in range(14):
                x = cx0 + L * (.18 + i * .05) + (r_ % 2) * 4 * k; y = cy - Hh * .38 + r_ * Hh * .17
                pygame.draw.arc(lay, shade(back, .7), (x, y, 10 * k, 9 * k), -1.4, 1.4, k)
    if pat == "bars_dark":
        for i in range(6):
            x = cx0 + L * (.25 + i * .1); pygame.draw.polygon(lay, (60, 70, 30), [(x, cy - Hh * .48), (x + 7 * k, cy - Hh * .48), (x + 4 * k, cy + Hh * .2), (x - 2 * k, cy + Hh * .2)])
    if pat == "koi":
        for i in range(5):
            x = cx0 + L * (.15 + .7 * h01(i, 5, 805)); y = cy - Hh * .35 + Hh * .3 * h01(i, 6, 806)
            pygame.draw.ellipse(lay, (226, 80, 40), (x, y, (14 + 16 * h01(i, 7, 807)) * k, (8 + 8 * h01(i, 8, 808)) * k))
    if extra == "lure":
        pass
    m = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    pygame.draw.polygon(m, (255, 255, 255, 255), body)
    lay.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    S.blit(lay, (0, 0))
    # sheen along the back and a shadowed belly edge
    hl = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    pygame.draw.lines(hl, (255, 255, 255, 90), False, [(x, y + 3 * k) for x, y in top[4:-6]], 2 * k)
    pygame.draw.lines(hl, (0, 0, 0, 60), False, [(x, y - 2 * k) for x, y in bot[6:-4]], 2 * k)
    S.blit(hl, (0, 0))
    pygame.draw.polygon(S, shade(back, .45), body, k)
    # head: gill arc, eye, mouth
    gx = cx0 + L * .2
    pygame.draw.arc(S, shade(back, .5), (gx - Hh * .3, cy - Hh * .38, Hh * .45, Hh * .76), -1.3, 1.3, k + 1)
    ex, ey = cx0 + L * .09 + (6 * k if extra == "long_snout" else 0), cy - Hh * .12
    er = max(3 * k, Hh * .09)
    pygame.draw.circle(S, (250, 250, 240), (int(ex), int(ey)), int(er))
    pygame.draw.circle(S, (16, 14, 18), (int(ex + k), int(ey)), int(er * .62))
    pygame.draw.circle(S, (255, 255, 255), (int(ex - er * .2), int(ey - er * .3)), max(1, int(er * .22)))
    pygame.draw.line(S, shade(back, .4), (cx0 - (10 * k if extra == "long_snout" else 0) + 2 * k, cy + Hh * .05), (cx0 + L * .07, cy + Hh * .08), k)
    if extra in ("barbels", "whiskers"):
        for d_ in (-1, 1):
            pygame.draw.lines(S, shade(back, .5), False, [(cx0 + 3 * k, cy + Hh * .06), (cx0 - 8 * k, cy + Hh * (.2 + .1 * d_)), (cx0 - 14 * k, cy + Hh * (.4 + .15 * d_))], k)
    if extra == "lure":
        tip = (cx0 + L * .02, cy - Hh * .9)
        pygame.draw.lines(S, shade(back, .7), False, [(cx0 + L * .15, cy - half(.15)), (cx0 + L * .06, cy - Hh * .85), tip], k)
        g = glow(int(10 * k), (120, 230, 255)); S.blit(g, (tip[0] - g.get_width() // 2, tip[1] - g.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
        pygame.draw.circle(S, (200, 250, 255), (int(tip[0]), int(tip[1])), 3 * k)
        for i in range(5):    # teeth
            x = cx0 + 2 * k + i * 4 * k; pygame.draw.polygon(S, (240, 240, 230), [(x, cy + Hh * .05), (x + 2 * k, cy + Hh * .05), (x + k, cy + Hh * .2)])
    spr = pygame.transform.smoothscale(S, (S.get_width() // k, S.get_height() // k))
    if len(_CARD) > 200: _CARD.clear()
    _CARD[key] = spr
    return spr


def catch_icon(item, size=64):
    """Picture for a gathered item ('Fish:Name', 'Herb:Name', 'Mat:Name' or a plain item name)."""
    key = ("ci", item, size)
    if key in _CARD: return _CARD[key]
    kind, _, name = item.partition(":") if ":" in item else ("", "", item)
    if kind == "Fish":
        spr = fish_portrait(name, size * 2)
    elif kind == "Herb":
        try:
            from .engine import World
            band = World.HERBS.index(name) if name in getattr(World, "HERBS", ()) else 0
        except Exception:
            band = 0
        h = herb_sprite(band)
        spr = pygame.transform.smoothscale(h, (size, int(size * h.get_height() / max(1, h.get_width()))))
    elif kind == "Gear":
        slot, _, gname = name.partition(":")
        spr = item_icon(slot, gname.split(" ")[0] if gname.split(" ")[0] in RARITY_COLOR else "Common", size)
    else:
        spr = item_icon(icon_slot(name, "essence"), "Uncommon" if "Essence" not in name else "Epic", size)
    if len(_CARD) > 200: _CARD.clear()
    _CARD[key] = spr
    return spr


# 0.45: body shapes - broad brutes, gaunt undead - and a little more size for the big ones
for _n, _b, _sz in (("Troll", 1.28, 1.55), ("Ogre", 1.34, 1.65), ("Orc", 1.16, 1.25), ("Frost Giant", 1.26, None), ("Yeti", 1.3, None), ("Gnoll", 1.1, None),
                    ("Skeleton", .84, None), ("Ghoul", .9, None), ("Mummy", .9, None)):
    if _n in MONSTER_SPEC:
        _e = list(MONSTER_SPEC[_n])
        _e[1] = dict(_e[1]); _e[1]["bulk"] = _b
        if _sz: _e[2] = _sz
        MONSTER_SPEC[_n] = tuple(_e)


# 0.45.2: brutes no longer wear a townsman's tunic - bare-skinned trolls and ogres with leather straps and a loincloth,
# iron-plated orcs with a blood-red sash
for _n, _upd in (("Troll", dict(body=(84, 128, 118), trim=(96, 70, 44), legs=(104, 80, 54), boots=(74, 112, 102), fur=(70, 104, 92))),
                 ("Ogre", dict(body=(172, 138, 102), trim=(86, 58, 36), legs=(118, 92, 60), boots=(150, 118, 86))),
                 ("Orc", dict(body=(88, 88, 98), trim=(160, 36, 34), legs=(66, 54, 44), boots=(40, 34, 30)))):
    if _n in MONSTER_SPEC:
        _e = list(MONSTER_SPEC[_n]); _e[1] = dict(_e[1]); _e[1].update(_upd); MONSTER_SPEC[_n] = tuple(_e)
