"""Walkable PvP arenas (0.15): Duel, Team Deathmatch, Capture the Flag, Domination.

An Arena plugs into the same hooks as a dungeon Instance, but the enemy side is
an AI team of class-based "players" and the player fights next to AI team-mates.
"""
import math, random
from types import SimpleNamespace
from .instance import Instance, INST_X0, TPS, ALLY_NAMES, ALLY_CLASSES, RANGED

MODES = {
    # 12v12 and 24v24 only (0.44.10).  "rules" says which game type a map plays like; "map" is its name.
    "tdm12": dict(title="Team Deathmatch 12v12", rules="tdm", map="Fallen Citadel", n=12, size=(132, 58), target=80, time=240, mult=12, gold=170, shrines=4, cover=1.4,
                  desc="Fallen Citadel. Twelve a side across a ruined fortress. First to 80 kills."),
    "ctf12": dict(title="Capture the Flag 12v12", rules="ctf", map="Warring Fortresses", n=12, size=(136, 58), target=3, time=240, mult=12, gold=220, shrines=4, cover=1.4,
                  desc="Warring Fortresses. Two armies, two flags, one long war. First to 3 captures or most flags at time."),
    "dom12": dict(title="Domination 12v12", rules="dom", map="Fields of the Five Wells", n=12, size=(132, 58), target=500, time=240, mult=12, gold=200, shrines=4, cover=1.4,
                  desc="Fields of the Five Wells. Hold five points across the field. First to 500."),
    "tdm24": dict(title="Team Deathmatch 24v24", rules="tdm", map="Siege of Ashfall", n=24, size=(190, 76), target=160, time=480, mult=24, gold=340, shrines=6, cover=1.7,
                  desc="Siege of Ashfall. Twenty-four a side across a vast ruined city. First to 160 kills."),
    "ctf24": dict(title="Capture the Flag 24v24", rules="ctf", map="The Sundered Marches", n=24, size=(200, 76), target=3, time=480, mult=24, gold=420, shrines=6, cover=1.7,
                  desc="The Sundered Marches. Two great hosts, two flags, a long road between. First to 3 captures or most flags at time."),
    "dom24": dict(title="Domination 24v24", rules="dom", map="Crown of the Seven Wells", n=24, size=(190, 76), target=800, time=480, mult=24, gold=380, shrines=6, cover=1.7,
                  desc="Crown of the Seven Wells. Hold seven points across a huge battlefield. First to 800."),
}
ROLES = ["Tank", "Healer", "DPS", "DPS"]
ROLES12 = ["Tank", "Tank", "Healer", "Healer", "Healer"] + ["DPS"] * 7
ROLES24 = ["Tank"] * 3 + ["Healer"] * 6 + ["DPS"] * 15
RED_NAMES = ["Skarn", "Vexa", "Drog", "Nyla", "Brask", "Ilyra", "Korth", "Zeph", "Mordai", "Tavish", "Grell", "Sable", "Orrin", "Kaelis"]


def _dist(ax, ay, bx, by):
    return math.hypot(ax - bx, ay - by)


class Arena(Instance):
    kind = "arena"
    is_arena = True           # 0.45: battleground mounts may be ridden here

    def __init__(self, w, mode):
        from .engine import Actor, WORLD_H
        cfg = MODES[mode]
        self.Actor = Actor; self.w = w; self.mode = cfg.get("rules", mode); self.key = mode; self.cfg = cfg
        self.roles = ROLES24 if cfg["n"] >= 24 else ROLES12 if cfg["n"] >= 12 else ROLES
        self.shrines = []
        self.d = SimpleNamespace(id=777, name=cfg["title"], area="Arena", kind="arena")
        self.level = w.player["level"]
        self.rng = random.Random(); self.fx = random.Random()
        self.tint = (118, 98, 74)
        self.floor = {}; self.walls = set(); self.pillars = set(); self.props = []
        self.rooms = []; self.actors = {}; self.hazards = []; self.nid = 800000
        self.mark = None; self.wipes = 0; self.done = False; self.portals = []
        self.ally_deaths = 0; self.player_deaths = 0; self.stats = {"interrupts": 0, "mark_clean": 0, "fire_dodged": 0}
        self.t0 = w.tick; self.boss_ids = []; self.allies = []; self.reds = []
        self.hint = ""; self.hint_until = 0
        self.score = {"blue": 0, "red": 0}
        self.pk = 0; self.pd = 0
        self.protect_until = 0; self.player_respawn_at = 0; self.finish_at = None; self.result = ""
        self.flags = {}; self.points = []; self.carry_player = None; self._paths = {}     # _paths: used by the inherited Instance pathing
        self.return_pos = (w.player["x"], w.player["y"])
        self._build_arena(WORLD_H)
        self._spawn_teams()

    # ---------------------------------------------------------------- map
    def _build_arena(self, WORLD_H):
        Wd, Hd = self.cfg["size"]; X0 = INST_X0 + 2; Y0 = WORLD_H + 4
        self.X0, self.Y0, self.Wd, self.Hd = X0, Y0, Wd, Hd
        for x in range(X0, X0 + Wd):
            for y in range(Y0, Y0 + Hd):
                # 0.36.1: the centre stripe sits on the mirror line (it was one tile towards blue)
                self.floor[(x, y)] = "arena" if (abs(x - (X0 + (Wd - 1) / 2)) < 2 and self.mode != "dom") else "floor"
        cy = Y0 + Hd / 2
        self.blue_base = (X0 + 5.0, cy); self.red_base = (X0 + Wd - 5.0, cy)
        big = self.cfg["n"] >= 12
        # ---- objectives
        self.shrines = []
        if self.mode == "ctf":
            self.flags = {"blue": {"home": (self.blue_base[0] + 2.5, cy), "pos": (self.blue_base[0] + 2.5, cy), "carrier": None, "t": 0},
                          "red": {"home": (self.red_base[0] - 2.5, cy), "pos": (self.red_base[0] - 2.5, cy), "carrier": None, "t": 0}}
        if self.mode == "dom":
            if big:
                fr = [(.5, .5), (.5, .14), (.5, .86), (.3, .5), (.7, .5)]
                if self.cfg["n"] >= 24: fr += [(.36, .2), (.64, .8)]
                self.points = [{"x": X0 + Wd * fx_, "y": Y0 + Hd * fy_, "owner": "", "prog": 0, "n": "ABCDEFG"[i]} for i, (fx_, fy_) in enumerate(fr)]
            else:
                self.points = [{"x": X0 + Wd / 2.0, "y": Y0 + 6.0, "owner": "", "prog": 0, "n": "A"},
                               {"x": X0 + Wd / 2.0, "y": cy, "owner": "", "prog": 0, "n": "B"},
                               {"x": X0 + Wd / 2.0, "y": Y0 + Hd - 6.0, "owner": "", "prog": 0, "n": "C"}]
        # ---- healing shrines: mirrored pairs along the flanks
        ns = self.cfg.get("shrines", 2)
        for i in range(ns // 2):
            fx_ = (.34 if big else .36) + (.08 * i if big else 0); fy_ = .22 if i % 2 == 0 else .78
            for mx_ in (fx_, 1 - fx_):
                self.shrines.append((X0 + Wd * mx_, Y0 + Hd * fy_))
        # ---- cover: ruined walls and pillars, mirrored left/right so the fight is fair
        rr = random.Random(f"bg:{self.key}")
        keep = [(self.blue_base[0], self.blue_base[1], 9.0), (self.red_base[0], self.red_base[1], 9.0)]
        keep += [(x, y, 4.5) for x, y in self.shrines]
        keep += [(p_["x"], p_["y"], 5.5) for p_ in self.points]
        if self.flags: keep += [(f["home"][0], f["home"][1], 4.5) for f in self.flags.values()]
        n_blocks = int(Wd * Hd / 150 * self.cfg.get("cover", 1.0))
        placed = []
        tries = 0
        while len(placed) < n_blocks and tries < n_blocks * 30:
            tries += 1
            bx = X0 + 4 + rr.random() * (Wd / 2 - 8); by = Y0 + 3 + rr.random() * (Hd - 6)
            shape = rr.choice(((2, 2), (2, 2), (1, 4), (4, 1), (3, 1), (1, 3), (2, 3)))
            bx, by = int(bx), int(by)
            cxm, cym = bx + shape[0] / 2, by + shape[1] / 2
            if any(math.hypot(cxm - kx, cym - ky) < kr for kx, ky, kr in keep): continue
            if any(abs(cxm - ox) < 6 and abs(cym - oy) < 6 for ox, oy in placed): continue
            if abs(cym - cy) < 1.5 and abs(cxm - (X0 + Wd / 2)) > Wd / 2 - 14: continue
            placed.append((cxm, cym))
            for dx in range(shape[0]):
                for dy in range(shape[1]):
                    self.pillars.add((bx + dx, by + dy))
                    self.pillars.add((X0 + Wd - 1 - (bx + dx - X0), by + dy))
        # a central landmark for the big maps: a ring of broken columns
        if big or self.mode == "tdm":
            mcx = X0 + Wd // 2; mcy = int(cy)
            for k in range(8):
                a_ = k / 8 * 6.2832; px = mcx + int(round(math.cos(a_) * (6 if big else 4))); py = mcy + int(round(math.sin(a_) * (6 if big else 4)))
                for dx in (0, 1):
                    for dy in (0, 1):
                        self.pillars.add((px + dx, py + dy))
                        self.pillars.add((X0 + Wd - 1 - (px + dx - X0), py + dy))     # 0.36.1: mirrored like the rest of the cover
        for t in list(self.pillars):
            if (t[0], t[1]) not in self.floor: self.pillars.discard(t)
        for t in self.pillars: self.floor.pop(t, None)
        for (x, y) in list(self.floor):
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    n = (x + dx, y + dy)
                    if n not in self.floor and n not in self.pillars: self.walls.add(n)
        self.spawn = (self.blue_base[0], self.blue_base[1])
        self.portals = [(self.blue_base[0] - 1.0, self.blue_base[1] - 3.2)]
        self.props.append((self.portals[0][0], self.portals[0][1], "portal", 0))
        for bx, by in ((X0 + .8, Y0 + .8), (X0 + .8, Y0 + Hd - .8), (X0 + Wd - .8, Y0 + .8), (X0 + Wd - .8, Y0 + Hd - .8)):
            self.props.append((bx, by, "brazier", 0))
        for sx_, sy_ in self.shrines: self.props.append((sx_, sy_, "brazier", 0))

    # --------------------------------------------------------------- teams
    def _spawn_teams(self):
        w = self.w; n = self.cfg["n"]
        mx = w._effective_maxhp()
        base = self._base_dmg()
        pr = w.spec_role() or "DPS"
        names = self.rng.sample(ALLY_NAMES, len(ALLY_NAMES)); rn = self.rng.sample(RED_NAMES, len(RED_NAMES))
        _sfx = ("the Bold", "the Grim", "Ironhand", "Stormborn", "the Swift", "Ashwalker", "Oathkeeper", "Duskblade")
        k_ = 0
        while len(names) < 30: names.append(f"{ALLY_NAMES[k_ % len(ALLY_NAMES)]} {_sfx[(k_ // len(ALLY_NAMES)) % len(_sfx)]}"); k_ += 1
        k_ = 0
        while len(rn) < 30: rn.append(f"{RED_NAMES[k_ % len(RED_NAMES)]} {_sfx[(k_ // len(RED_NAMES)) % len(_sfx)]}"); k_ += 1
        roles_blue = list(self.roles[:n])
        if pr in roles_blue: roles_blue.remove(pr)
        else: roles_blue = roles_blue[:n - 1]
        for i, role in enumerate(roles_blue):
            a = self._mk_c(names[i], role, "blue", mx, base, i)
            self.allies.append(a)
        for i in range(n):
            a = self._mk_c(rn[i], self.roles[i] if n > 1 else "DPS", "red", mx, base, i)
            self.reds.append(a)
        self.squads = {}
        for team, lst in (("blue", self.allies), ("red", self.reds)):
            self._make_squads(team, lst)
        self.mt = None
        w.selected_target = None

    def _base_dmg(self):
        p = self.w.player
        return p["level"] * 2 + p["weapon"] * 5 + 4

    def _mk_c(self, name, role, team, mx, base, i):
        w = self.w; p = w.player
        cls = self.rng.choice(ALLY_CLASSES[role])
        hp = mx * {"Tank": 1.5, "Healer": .9, "DPS": 1.0}[role] * self.rng.uniform(.92, 1.08) * ((3.0 if self.cfg["n"] == 1 else .95) if team == "red" else 1.3)      # 0.44: easier - your side is sturdier, the enemy a little softer
        bx, by = (self.blue_base if team == "blue" else self.red_base)
        nn = self.cfg["n"]
        if nn <= 5: x = bx + (i % 2) * (1.0 if team == "blue" else -1.0); y = by + (i - 2) * 1.2
        else: x = bx + (i % 3) * (1.6 if team == "blue" else -1.6); y = by + (i - (nn - 1) / 2) * 1.5
        x, y = self._open_spot(x, y)
        faction = p["faction"] if team == "blue" else ("Horde" if p["faction"] == "Alliance" else "Alliance")
        kind = "ially" if team == "blue" else "imob"
        a = self._mk(name, p["level"], x, y, hp, kind=kind, role=cls, faction=faction)
        a.rrole = role; a.cls = cls; a.dead = False; a.nextact = 0; a.slot = i; a.team = team; a.pvp = True
        a.dmgm = {"Tank": .6, "Healer": .4, "DPS": 1.0}[role] * ((1.3 if self.cfg["n"] == 1 else .8) if team == "red" else 1.1)
        a.base = base; a.rng_ = 7.0 if cls in RANGED else 1.9; a.respawn = 0; a.state = "idle"; a.idx = i
        a.has_flag = False; a.cap = 0
        a.pers = self.rng.choice(("attacker", "attacker", "defender", "flex")); a.plan = None; a.next_decide = 0
        return a

    def _open_spot(self, x, y):
        """0.36.1: the nearest walkable spot - a 12-a-side line-up is tall enough to reach into the cover by the bases."""
        if (int(x), int(y)) in self.floor: return x, y
        for r in range(1, 6):
            ring = [(int(x) + dx, int(y) + dy) for dx in range(-r, r + 1) for dy in range(-r, r + 1) if max(abs(dx), abs(dy)) == r]
            ok = [t for t in ring if t in self.floor]
            if ok:
                tx, ty = min(ok, key=lambda t: _dist(x, y, t[0] + .5, t[1] + .5))
                return tx + .5, ty + .5
        return (self.blue_base if x < self.X0 + self.Wd / 2 else self.red_base)

    def combatants(self, team):
        return self.allies if team == "blue" else self.reds

    # ---------------------------------------------------------- engine hooks
    def pre_hit(self, t):
        return not getattr(t, "dead", False)

    def on_player_hit(self, t, ab): pass
    def pulled_by(self, t): pass
    def current_room(self): return None
    def boss_actor(self): return None
    def alive_allies(self): return [a for a in self.allies if not a.dead]

    def player_killed(self, t):
        self._down(t, "blue", by_player=True)
        self.w.kill_events.append({"id": t.id, "x": t.x, "y": t.y, "gold": 0, "name": t.name})
        return 0

    RESPAWN_TICKS = 60         # 0.45.6: allies and enemies wait 15 s; the player does not (TPS 4) after dying

    def player_down(self):
        return self.w.tick < self.player_respawn_at

    def on_player_death(self):
        w = self.w; p = w.player
        self.pd += 1; self.player_deaths += 1
        self._award("red", 1)
        self._drop_player_flag()
        p["x"], p["y"] = self.spawn
        p["hp"] = w._effective_maxhp(); w.buffs.clear(); w.mstatus.clear()
        self.protect_until = w.tick + 12      # 0.45.6: the player respawns immediately (only AI allies/enemies wait 15 s)
        self._say("You were slain! You respawn at your base.", "Respawned - protected for 3s")

    def on_leave(self):
        if not self.done:          # 0.45: leaving early is no longer a loss - no rating change, no rewards
            self.done = True
            self.w.city_result = f"You left the {self.cfg['title']} early - no win, no loss."

    def _say(self, msg, hint=None):
        if msg: self.w.events.append(msg)
        self.hint = hint or msg; self.hint_until = self.w.tick + 14

    # ---------------------------------------------------------- scoring
    def _award(self, team, n):
        if self.mode == "tdm":
            self.score[team] += n

    def _down(self, c, killer_team, by_player=False):
        if c.dead: return
        c.dead = True; c.hp = 0; c.state = "dead"; c.respawn = self.w.tick + self.RESPAWN_TICKS
        self.w.mstatus.pop(c.id, None)
        if c.has_flag: self._drop_flag(c)
        if c.team == "red":
            self._award("blue", 1)
            if by_player: self.pk += 1
        else:
            self._award("red", 1); self.ally_deaths += 1

    # ---------------------------------------------------------- CTF helpers
    def _drop_flag(self, c):
        for team, f in self.flags.items():
            if f["carrier"] is c:
                f["carrier"] = None; f["pos"] = f["home"]; f["t"] = self.w.tick      # 0.46.31: a dropped flag goes straight home
                self._say(f"The {team} flag has been returned.", f"{team.title()} flag returned!")
        c.has_flag = False

    def _drop_player_flag(self):
        if self.carry_player is None: return
        p = self.w.player
        f = self.flags[self.carry_player]
        f["carrier"] = None; f["pos"] = f["home"]; f["t"] = self.w.tick
        self._say(f"The {self.carry_player} flag has been returned.", f"{self.carry_player.title()} flag returned!")
        self.carry_player = None

    def _ctf_tick(self):
        now = self.w.tick; p = self.w.player
        for team, f in self.flags.items():
            if f["carrier"] is None and f["pos"] != f["home"] and now - f["t"] > 80:
                f["pos"] = f["home"]
        everyone = [("blue", a) for a in self.allies if not a.dead] + [("red", a) for a in self.reds if not a.dead]
        if not self.player_down(): everyone.append(("blue", "player"))
        for team, who in everyone:
            wx, wy = (p["x"], p["y"]) if who == "player" else (who.x, who.y)
            enemy = "red" if team == "blue" else "blue"
            fe = self.flags[enemy]; fo = self.flags[team]
            if fe["carrier"] is None and not (who == "player" and self.protect_until > now and False) and _dist(wx, wy, *fe["pos"]) < 1.7:
                fe["carrier"] = who
                if who == "player":
                    self.carry_player = enemy; self.protect_until = max(self.protect_until, now + 20)      # 5 s of grace to get away
                    if getattr(self.w, "mounted", None) and not self.w.mount_power("runner"): self.w.mounted = None   # 0.45: only Flag Runners keep riding
                else: who.has_flag = True; who.shield_until = now + 20
                self._say(("You" if who == "player" else who.name) + f" took the {enemy} flag!", f"{enemy.title()} flag taken!")
            if fo["carrier"] is None and fo["pos"] != fo["home"] and _dist(wx, wy, *fo["pos"]) < 1.7:
                fo["pos"] = fo["home"]; self._say(f"The {team} flag has been returned.", f"{team.title()} flag returned!")
            if fe["carrier"] is who and fo["pos"] == fo["home"] and fo["carrier"] is None and _dist(wx, wy, *fo["home"]) < 2.2:
                self.score[team] += 1
                fe["carrier"] = None; fe["pos"] = fe["home"]
                if who == "player": self.carry_player = None; self.pcaps = getattr(self, "pcaps", 0) + 1; self.w.mythic_event("ctfcap")
                else: who.has_flag = False; who.cap += 1
                self._say(f"{team.title()} team captured a flag! ({self.score['blue']}-{self.score['red']})", "FLAG CAPTURED!")

    def _dom_tick(self):
        p = self.w.player
        rad = 4.6 if self.cfg["n"] >= 12 else 3.4
        for pt in self.points:
            nb = sum(1 for a in self.allies if not a.dead and _dist(a.x, a.y, pt["x"], pt["y"]) < rad) + (1 if not self.player_down() and _dist(p["x"], p["y"], pt["x"], pt["y"]) < rad else 0)
            nr = sum(1 for a in self.reds if not a.dead and _dist(a.x, a.y, pt["x"], pt["y"]) < rad)
            if nb > nr: pt["prog"] = min(10, pt["prog"] + 1)
            elif nr > nb: pt["prog"] = max(-10, pt["prog"] - 1)
            if pt["prog"] >= 10 and pt["owner"] != "blue":
                pt["owner"] = "blue"; self._say(f"Point {pt['n']} captured by your team!", f"Point {pt['n']} is yours")
            elif pt["prog"] <= -10 and pt["owner"] != "red":
                pt["owner"] = "red"; self._say(f"Point {pt['n']} lost to the enemy.", f"Point {pt['n']} lost!")
            if pt["owner"]: self.score[pt["owner"]] += .25

    # ---------------------------------------------------------- AI
    def tick(self):
        w = self.w; now = w.tick
        if self.finish_at is not None:
            if now >= self.finish_at: w.leave_instance()
            return
        if self.player_down() and (self.player_respawn_at - now) % TPS == 0:
            self._say(None, f"Respawning in {max(1, (self.player_respawn_at - now) // TPS)}s...")
        elif self.player_respawn_at and now == self.player_respawn_at:
            self._say("You respawned.", "Respawned - protected for 3s")
        for a in self.allies + self.reds:
            if a.dead:
                if now >= a.respawn:
                    a.dead = False; a.hp = a.maxhp; a.state = "idle"
                    bx, by = self.blue_base if a.team == "blue" else self.red_base
                    a.x, a.y = self._open_spot(bx + self.rng.uniform(-1, 1), by + self.rng.uniform(-2, 2))
                continue
            if a.hp <= 0: self._down(a, "red" if a.team == "blue" else "blue"); continue
            self._ai(a, now)
        if now % 4 == 0 and self.shrines: self._shrine_tick()
        if self.mode == "ctf": self._ctf_tick()
        if self.mode == "dom": self._dom_tick()
        self._check_end(now)

    def _shrine_tick(self):
        """Healing shrines: stand within 2.6 tiles to recover 6% of max health per second."""
        w = self.w; p = w.player
        for sx_, sy_ in self.shrines:
            for a in self.allies + self.reds:
                if not a.dead and a.hp < a.maxhp and _dist(a.x, a.y, sx_, sy_) < 2.6:
                    a.hp = min(a.maxhp, a.hp + a.maxhp * .06)
            if _dist(p["x"], p["y"], sx_, sy_) < 2.6 and p["hp"] < w._effective_maxhp():
                w._heal(w._effective_maxhp() * .06)

    def _foes(self, a):
        foes = [x for x in (self.reds if a.team == "blue" else self.allies) if not x.dead]
        return foes

    def _hit_foe(self, a, f):
        raw = a.base * a.dmgm * self.fx.uniform(.85, 1.15)
        dmg_ = int(raw * (1 - min(.45, self.w.player.get("armor", 1) / (self.w.player.get("armor", 1) + 260.))) if f.team == "blue" else raw)
        if getattr(f, "shield_until", 0) > self.w.tick: return        # a fresh flag carrier is untouchable for a moment
        if getattr(f, "has_flag", False): dmg_ = int(dmg_ * .45)         # the flag carrier is escorted and hard to bring down
        f.hp -= dmg_
        if f.hp <= 0: self._down(f, a.team)

    def _hit_player(self, a):
        w = self.w
        if w.tick < self.protect_until: return
        raw = a.base * a.dmgm * self.fx.uniform(.85, 1.15) * .75
        if self.carry_player is not None: raw *= .45          # carrying a flag: enemies hit you far less hard
        # 0.44.12: no burst deaths - a single blow takes at most 12% of your health and a whole second of blows at most 25%,
        # so a battleground hurts like the monsters in the open world (you can see it coming and heal)
        mx = w._effective_maxhp(); armor = w.player.get("armor", 1)
        red = 1 - min(.6, armor / (armor + 180.))
        eff = min(raw * red, .12 * mx)
        now = w.tick
        log = [(t, d) for t, d in getattr(self, "_pburst", []) if now - t < 4]
        room = max(0.0, .25 * mx - sum(d for _, d in log))
        eff = min(eff, room)
        if eff < 1: return
        log.append((now, eff)); self._pburst = log
        w.damage_player(eff / max(.2, red), a, a.id)

    def _spread(self, a, gx, gy, k=1.6):
        """Keep a body's width from team-mates so the bots fan out instead of stacking into one clump."""
        px = py = 0.0; n = 0
        for m in self.combatants(a.team):
            if m is a or m.dead: continue
            dx, dy = a.x - m.x, a.y - m.y; d = math.hypot(dx, dy)
            if d < 2.2:
                if d < .05: dx, dy, d = math.cos(a.idx), math.sin(a.idx), 1.0
                w_ = (2.2 - d) / 2.2; px += dx / d * w_; py += dy / d * w_; n += 1
        if not n: return gx, gy
        return gx + px * 3.0 * k, gy + py * 3.0 * k

    def _ai(self, a, now):
        w = self.w; p = w.player; speed = .8
        if w._stunned(a): return
        foes = self._foes(a)
        targets = [(f, _dist(a.x, a.y, f.x, f.y)) for f in foes]
        if a.team == "red" and now >= self.protect_until:
            targets.append(("player", _dist(a.x, a.y, p["x"], p["y"])))
        # healers heal first
        if a.rrole == "Healer" and now >= a.nextact:
            hurt = [x for x in self.combatants(a.team) if not x.dead and x.hp < x.maxhp * .75 and _dist(a.x, a.y, x.x, x.y) < 9]
            pl_hurt = a.team == "blue" and p["hp"] < w._effective_maxhp() * .7 and _dist(a.x, a.y, p["x"], p["y"]) < 9
            if hurt or pl_hurt:
                a.nextact = now + 8
                if hurt:
                    t = min(hurt, key=lambda x: x.hp / x.maxhp); t.hp = min(t.maxhp, t.hp + t.maxhp * .22)
                else: w._heal(w._effective_maxhp() * .18)
                return
        if now >= a.next_decide: self._decide(a, now)
        carrying = a.has_flag
        plan = a.plan
        near = [t for t in targets if t[1] < (12 if a.rrole != "DPS" else 14)]
        if plan and plan[0] == "heal":
            near = [t for t in near if t[1] < 3.0]                      # retreating: only fight what is on top of you
        elif plan and plan[0] == "chase":
            near = [t for t in near if t[1] < 3.0]                      # 0.46.31: hunting the flag carrier - only fight what blocks the way
        elif plan and plan[0] in ("defend", "hold") and near:
            near = [t for t in near if _dist(plan[1], plan[2], *((p["x"], p["y"]) if t[0] == "player" else (t[0].x, t[0].y))) < 15]
        def _score(t):
            f = t[0]
            if f == "player": return t[1]
            return t[1] * (.55 + f.hp / max(1, f.maxhp))                # focus the wounded
        if getattr(a, "runner", False) and not carrying and self.mode == "ctf":
            near = [t for t in near if t[1] < 1.8]       # flag runners dash past the fighting
            fe_ = self.flags["red" if a.team == "blue" else "blue"]
            if _dist(a.x, a.y, *fe_["pos"]) < 16:
                near = []                                                       # last stretch: grab the flag, ignore everything
                if now >= getattr(a, "dash_cd", 0): a.shield_until = now + 28; a.dash_cd = now + 140       # a 7-second smoke-and-dash
        tgt = min(near, key=_score) if near and not (carrying and min(t[1] for t in near) > 2.2) else None
        if tgt is not None:
            f, d = tgt
            tx, ty = (p["x"], p["y"]) if f == "player" else (f.x, f.y)
            if d > a.rng_ * .85:
                tx, ty = self._spread(a, tx, ty, .9); self._nav(a, tx, ty, speed)
            a.state = "fight"
            if d <= a.rng_ and now >= a.nextact:
                a.nextact = now + 4
                if f == "player": self._hit_player(a)
                else: self._hit_foe(a, f)
            return
        a.state = "move"
        if getattr(a, "runner", False): speed = 1.15
        if carrying: speed = 1.3
        if getattr(a, "shield_until", 0) > now: speed = max(speed, 1.4)        # flag runners and carriers sprint
        gx, gy = self._objective(a)
        if self.mode == "ctf" and (getattr(a, "runner", False) or carrying) and abs(a.x - gx) > 26:
            gy = self.Y0 + (7.0 if a.idx % 2 == 0 else self.Hd - 7.0)         # runners and carriers flank along the edges, not through the brawl
            gx = a.x + (26 if gx > a.x else -26)
        if getattr(a, "plan", None) and a.plan[0] in ("attack", "capture", "push", "chase") and not getattr(a, "runner", False) and not carrying and _dist(a.x, a.y, gx, gy) > 22:
            # 0.44.10: spread across the map's width as you advance instead of marching down one line
            lane = self.Y0 + 5 + (self.Hd - 10) * (((a.idx * 0.618) + (0.37 if a.team == "red" else 0)) % 1.0)
            gy = lane
        gx, gy = self._spread(a, gx, gy)
        if _dist(a.x, a.y, gx, gy) > 1.4: self._nav(a, gx, gy, speed)

    def _make_squads(self, team, lst):
        """0.44.12: bots band into party-style squads - a tank, a healer and DPS - that move and fight together.
        It cannot always work out: the left-overs (and a few bots that prefer to go it alone) stay solo."""
        tanks = [a for a in lst if a.rrole == "Tank"]; heals = [a for a in lst if a.rrole == "Healer"]; dps = [a for a in lst if a.rrole == "DPS"]
        k = 0
        while tanks and heals and len(dps) >= 2:
            members = [tanks.pop(0), heals.pop(0)] + [dps.pop(0) for _ in range(min(3, len(dps)))]
            members = [m for m in members if getattr(m, "pers", "") != "loner"]
            for m in members: m.squad = (team, k)
            self.squads[(team, k)] = members; k += 1
        # a squad of three or more only: and ~1 in 6 members drifts off alone
        for key, mem in list(self.squads.items()):
            if key[0] != team: continue
            for m in mem[2:]:
                if self.rng.random() < .17: m.squad = None

    def _squad_lead(self, a):
        mem = self.squads.get(getattr(a, "squad", None)) or []
        alive = [m for m in mem if not m.dead and getattr(m, "squad", None) == a.squad]
        for m in alive:
            if m.rrole == "Tank": return m
        return alive[0] if alive else None

    def _decide(self, a, now):
        self._decide_core(a, now)
        sq = getattr(a, "squad", None)
        if sq is None or not a.plan or getattr(a, "runner", False) or a.has_flag: return
        if a.plan[0] in ("heal", "defend", "hold", "carry", "chase", "escort"): return
        lead = self._squad_lead(a)
        if lead is None or lead is a: return
        d = _dist(a.x, a.y, lead.x, lead.y)
        ang = (a.idx * 1.9) % 6.283
        if a.rrole == "Healer" or d > 7.5:
            r = 2.0 if a.rrole == "Healer" else 3.0
            a.plan = ("support", lead.x + math.cos(ang) * r, lead.y + math.sin(ang) * r)
        elif lead.plan and lead.plan[0] in ("attack", "capture", "push", "chase"):
            a.plan = (lead.plan[0], lead.plan[1] + math.cos(ang) * 2.5, lead.plan[2] + math.sin(ang) * 2.5)

    # ------------------------------------------------------------- decisions (0.44): every bot weighs the game and picks a job
    def _decide_core(self, a, now):
        a.next_decide = now + self.fx.randint(14, 36)
        team = a.team; foe_team = "red" if team == "blue" else "blue"
        mates = [x for x in self.combatants(team) if not x.dead]
        others = [x for x in mates if x is not a]
        hp = a.hp / max(1, a.maxhp)
        foe_base = self.red_base if team == "blue" else self.blue_base
        if hp < .35 and self.shrines and not a.has_flag:
            own = [s_ for s_ in self.shrines if (s_[0] < self.X0 + self.Wd / 2) == (team == "blue")] or self.shrines
            sx, sy = min(own, key=lambda s_: _dist(a.x, a.y, s_[0], s_[1]))
            a.plan = ("heal", sx, sy); return
        if self.mode == "ctf":
            fe = self.flags[foe_team]; fo = self.flags[team]
            if a.has_flag:
                a.plan = ("carry", fo["home"][0], fo["home"][1]); return
            stolen = fo["carrier"] is not None or tuple(fo["pos"]) != tuple(fo["home"])
            if stolen:
                c = fo["carrier"]
                cx, cy = (self.w.player["x"], self.w.player["y"]) if c == "player" else ((c.x, c.y) if c is not None else tuple(fo["pos"]))
                a.plan = ("chase", cx, cy); return      # 0.46.31: the enemy has our flag - the WHOLE team hunts the carrier
            defs = ()                         # 0.45: nobody stays home to defend - the whole team goes for the enemy flag
            c = fe["carrier"]
            nrun = 3 if self.cfg["n"] <= 12 else 5
            runners = sorted((x for x in mates if x.rrole == "DPS" and x not in defs), key=lambda x: x.idx)[:nrun]
            a.runner = a in runners and c is None
            if a.runner and not getattr(a, "_rbuf", False):
                a._rbuf = True; a.maxhp *= 2.5; a.hp *= 2.5          # a flag runner is a picked, well-armoured fighter
            if a.runner:
                a.plan = ("attack", fe["pos"][0], fe["pos"][1]); return
            mine = c is not None and c != "player" and getattr(c, "team", "") == team
            if c == "player" and team == "blue":
                a.plan = ("escort", self.w.player["x"], self.w.player["y"]); return
            if mine and c is not a:
                a.plan = ("escort", c.x, c.y); return      # 0.46.31: our carrier is running - everyone stays with the carrier
            if a.rrole == "Healer" and others:
                lead = min((x for x in others if x.rrole != "Healer"), key=lambda x: _dist(a.x, a.y, x.x, x.y), default=None)
                if lead is not None: a.plan = ("support", lead.x, lead.y); return
            a.plan = ("attack", fe["pos"][0], fe["pos"][1]); return
        if self.mode == "dom":
            cnt = {}
            for x in others:
                pl = getattr(x, "plan", None)
                if pl and pl[0] in ("hold", "capture"): cnt[(round(pl[1]), round(pl[2]))] = cnt.get((round(pl[1]), round(pl[2])), 0) + 1
            best = None
            for pt in self.points:
                key = (round(pt["x"]), round(pt["y"])); mine = pt["owner"] == team
                load = cnt.get(key, 0)
                want = (1 if self.cfg["n"] <= 4 else 3 if self.cfg["n"] <= 12 else 5)
                score = _dist(a.x, a.y, pt["x"], pt["y"]) + 9 * load
                if mine:
                    score += (-14 if a.pers == "defender" and load < want else 16)
                elif pt["owner"] == foe_team: score -= 6
                if best is None or score < best[0]: best = (score, pt, mine)
            _, pt, mine = best
            a.plan = ("hold" if mine else "capture", pt["x"] + (a.idx % 5 - 2) * .6, pt["y"] + (a.idx % 3 - 1) * .6); return
        # team deathmatch: push together, regroup when strung out
        if team == "red" and a.idx % 2 == 0 and now >= self.protect_until:
            a.plan = ("push", self.w.player["x"], self.w.player["y"]); return
        if others:
            mx_ = sum(x.x for x in others) / len(others); my_ = sum(x.y for x in others) / len(others)
            if _dist(a.x, a.y, mx_, my_) > 16 and a.pers != "flex":
                a.plan = ("regroup", mx_, my_); return
        foes = self._foes(a)
        if foes:
            f = min(foes, key=lambda f: _dist(a.x, a.y, f.x, f.y) * (.6 + f.hp / max(1, f.maxhp)))
            a.plan = ("push", f.x, f.y)
        else: a.plan = ("push", foe_base[0], foe_base[1])

    def _objective(self, a):
        pl = getattr(a, "plan", None)
        if pl is not None: return pl[1], pl[2]
        enemy_team = "red" if a.team == "blue" else "blue"
        foe_base = self.red_base if a.team == "blue" else self.blue_base
        if self.mode == "tdm":
            foes = self._foes(a)
            if a.team == "red" and a.idx % 2 == 0 and self.w.tick >= self.protect_until: return self.w.player["x"], self.w.player["y"]
            if foes: f = min(foes, key=lambda f: _dist(a.x, a.y, f.x, f.y)); return f.x, f.y
            return foe_base
        if self.mode == "ctf":
            fe = self.flags[enemy_team]; fo = self.flags[a.team]
            if a.has_flag: return fo["home"]
            # 0.45: every bot goes for the enemy flag (was two in three); once a teammate has it, push to their base
            if fe["carrier"] is not None and fe["carrier"] != "player" and getattr(fe["carrier"], "team", "") == a.team: return foe_base
            return fe["pos"]
        if self.mode == "dom":
            pt = self.points[a.idx % len(self.points)]; return pt["x"] + (a.idx % 5 - 2) * .6, pt["y"] + (a.idx % 3 - 1) * .6
        return foe_base

    def _check_end(self, now):
        cfg = self.cfg; el = (now - self.t0) / TPS; res = None
        if self.mode == "dom":
            if self.score["blue"] >= cfg["target"] or self.score["red"] >= cfg["target"]: res = "blue" if self.score["blue"] >= self.score["red"] else "red"
        elif self.score["blue"] >= cfg["target"] or self.score["red"] >= cfg["target"]:
            res = "blue" if self.score["blue"] > self.score["red"] else "red" if self.score["red"] > self.score["blue"] else "draw"
        if res is None and el >= cfg["time"]:
            res = "blue" if self.score["blue"] > self.score["red"] else "red" if self.score["red"] > self.score["blue"] else "draw"
        if res: self._finish(res)

    def _finish(self, res):
        w = self.w; p = w.player; cfg = self.cfg
        self.done = True; self.finish_at = w.tick + 28
        lvl = p["level"]
        if res == "blue":
            gold = lvl * cfg["gold"] // 8; xp = lvl * cfg["gold"] // 2
            p["gold"] += gold; p["xp"] += xp
            w._add_currency(pvp=10 * cfg["mult"])
            w._pvp_result(True, cfg["mult"]); w.mythic_event("arenawin")
            slot = self.rng.choice(("weapon", "armor", "helm", "trinket", "ring"))
            rar = "Epic" if (self.mode in ("ctf", "dom") or cfg["n"] >= 12) else "Rare"
            power = min(168, int(lvl * 1.2) + {"Rare": 18, "Epic": 30}[rar] + self.rng.randint(0, 5))
            prize = self.rng.random() < .25          # 0.35.1: a prize item one win in four
            if prize: w._grant_gear(w._inst_item(rar, slot).replace("Dungeon-forged", "Gladiator's"), slot, rar, power, "Arena", "", "")
            w._level_check(); w._save_player_fast()
            msg = f"VICTORY! {cfg['title']}: +{gold}g, +{xp} XP, +{10 * cfg['mult']} PvP points, rating {w.pvp_status()['rating']}." + (" A prize was added to your bag." if prize else "")
        elif res == "red":
            w._pvp_result(False, cfg["mult"]); w._add_currency(pvp=2 * cfg["mult"])
            msg = f"DEFEAT in {cfg['title']}. Rating {w.pvp_status()['rating']}."
        else:
            msg = f"{cfg['title']} ended in a draw."
        w.city_result = msg; self.result = res
        self._say(msg, "VICTORY!" if res == "blue" else "DEFEAT" if res == "red" else "DRAW")

    # ---------------------------------------------------------- snapshot
    def snapshot(self):
        w = self.w; now = w.tick; cfg = self.cfg
        party = [{"name": a.name, "role": a.rrole, "cls": a.cls, "hp": int(a.hp), "maxhp": int(a.maxhp), "dead": a.dead} for a in self.allies]
        foes = [{"name": a.name, "role": a.rrole, "cls": a.cls, "hp": int(a.hp), "maxhp": int(a.maxhp), "dead": a.dead} for a in self.reds]
        flags = []
        for team, f in self.flags.items():
            c = f["carrier"]
            if c == "player": fx_, fy_ = w.player["x"], w.player["y"]
            elif c is not None: fx_, fy_ = c.x, c.y
            else: fx_, fy_ = f["pos"]
            flags.append({"team": team, "x": fx_, "y": fy_, "home": f["pos"] == f["home"] and c is None, "carried": c is not None})
        pv = {"mode": self.mode, "title": cfg["title"], "blue": int(self.score["blue"]), "red": int(self.score["red"]), "target": cfg["target"],
              "left": max(0, int(cfg["time"] - (now - self.t0) / TPS)), "flags": flags,
              "points": [{"x": p_["x"], "y": p_["y"], "owner": p_["owner"], "prog": p_["prog"], "n": p_["n"]} for p_ in self.points],
              "shrines": [{"x": a_, "y": b_} for a_, b_ in self.shrines], "map": cfg.get("map", ""), "foes": foes, "pk": self.pk, "pd": self.pd, "carry": self.carry_player, "result": self.result,
              "protected": now < self.protect_until, "down": max(0, int((self.player_respawn_at - now + TPS - 1) / TPS)) if now < self.player_respawn_at else 0}
        return {"name": cfg["title"], "kind": "arena", "level": self.level, "room": -1, "rooms": 0, "boss": None, "hazards": [], "mark": None,
                "party": party, "portals": self.portals, "wipes": 0, "done": self.done, "hint": self.hint if now < self.hint_until else "",
                "bosses_down": 0, "bosses": 0, "elapsed": int((now - self.t0) / TPS), "pillars": sorted(self.pillars), "pvp": pv}
