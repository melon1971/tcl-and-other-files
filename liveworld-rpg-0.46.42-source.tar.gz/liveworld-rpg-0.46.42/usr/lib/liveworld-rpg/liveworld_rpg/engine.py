#!/usr/bin/env python3
import os, random, sqlite3, time, math, collections, traceback
from dataclasses import dataclass
from .mounts import MountMixin, MOUNTS as MOUNTS_ALL
from .people import PeopleMixin, LEADER_ROLES
from .jewels import JewelMixin
from .bonuses import BonusMixin
from .partyup import PartyUpMixin
from .marketplace import MarketplaceMixin
from .gather import GatherMixin
from .factions import FactionMixin, SOLDIER_ROLES, other_side, WARLORDS
from .rpg import EventList, SystemsMixin, xp_need, CAPITAL_NAMES, KING_POST, MATS as MATS_BASE, FISH as FISH_NAMES, MAT_SOLD
from pathlib import Path

DATA=Path(os.environ.get("LIVEWORLD_DATA",str(Path.home()/".local/share/liveworld-rpg")))
DATA.mkdir(parents=True,exist_ok=True,mode=0o700)      # 0.46.42: a new save folder is private to its owner
DB=DATA/"world.db"
def acquire_instance_lock():
 """0.34.2: one running copy per save folder. Returns an open lock file to keep for the life of the process, or None
 when another copy already holds the save. Two copies would overwrite each other's world every 30 seconds."""
 try:
  import fcntl
 except ImportError:
  return True
 f=open(DATA/"liveworld.lock","a+")
 try:
  fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
 except OSError:
  f.close();return None
 return f
# 0.24: the world is WS times larger on each axis (540x330 tiles), with big walled cities.
WS=5                     # 0.43: a huge world - 900x750 tiles, zones of 225x150, so travel between towns and zones takes a good while
WORLD_H=150*WS
INST_H=96                # 0.41: room for the bigger dungeon rooms
W,H=180*WS,WORLD_H+INST_H
LOOT_TTL=1200           # 0.46.27: dropped gear (open world, dungeons and raids alike) disappears after 5 minutes (4 ticks a second); herbs, veins and materials stay
WORLD_VERSION=7          # bump to rebuild the geography (towns, dungeons, monsters) of older saves
# town geometry (tiles, from the town centre)
TS=1.3                   # 0.41: town scale - every town distance below (and the shop/building posts) is 30% larger
TOWN_PLAZA_R=17.6*TS     # paved ground inside the walls
TOWN_WALL_R=19.4*TS      # centre line of the city wall
TOWN_BLOCK_R=22.0*TS     # nothing wild grows inside this
TOWN_SAFE_R=18.5*TS      # monsters never aggro and you are "in town" inside this
TOWN_EXCL_R=25.0*TS      # monsters spawn/wander no closer than this
TOWN_CLEAR_R=30.0*TS     # dungeon entrances and landmarks keep this far from a town centre
LEVEL_CAP=100
LEVEL_BRACKETS=[(1,10),(11,20),(21,30),(31,40),(41,50),(51,60),(61,70),(71,80),(81,90),(91,100)]
FACTIONS=("Alliance","Horde","Neutral")
ROLES=("Warrior","Ranger","Mage","Cleric","Rogue","Paladin","Shaman","Druid","Berserker","Warlock","Monk","Juggernaut")
MONSTERS=["Wolf","Boar","Spider","Bandit","Goblin","Kobold","Orc","Skeleton","Ghoul","Wraith","Troll","Ogre","Wyvern","Harpy","Basilisk","Elemental","Cultist","Dark Knight","Demon","Dragonkin","Ancient Treant","Frost Giant","Sand Wyrm","Lava Beast"]
TITLES=["Wanderer","Hunter","Mercenary","Pilgrim","Adventurer","Treasure Seeker","Scout","Champion","Veteran","Exile","Bounty Hunter"]
NAMES=["Alden","Mira","Rook","Sel","Kara","Venn","Tarin","Ilya","Bryn","Nessa","Corin","Dara"]
# Every outdoor zone has an explicit MMO-style level band.  Players can
# travel through higher zones, but enemies, quests and normal dungeons are
# tuned to the zone band rather than silently scaling to the player.
_AREAS0=[
# 0.42: no zone belongs to a side any more.  Every zone is "Neutral" (mixed): each holds one Alliance and one Horde town, with
 # quests for whichever side you serve.  Only the two capital zones are owned: Greenfields (Alliance) and Ashen Vale (Horde), hostile to the enemy.
 # The first two entries must stay Greenfields and Ashen Vale (their second towns are the capitals).
 ("Greenfields",0,0,45,30,"Alliance",1,10),("Ashen Vale",135,0,45,30,"Horde",1,10),
 ("Ironwood",45,0,45,30,"Neutral",11,20),("Blackthorn Wilds",90,0,45,30,"Neutral",11,20),
 ("Silverfrost",45,30,45,30,"Neutral",21,30),("Frostmarch",90,30,45,30,"Neutral",21,30),
 ("Storm Coast",0,30,45,30,"Neutral",31,40),("Saltcrag Coast",135,30,45,30,"Neutral",31,40),
 ("Mirewood Fen",0,60,45,30,"Neutral",41,50),("Bloodfen",135,60,45,30,"Neutral",41,50),
 ("Crownlands",45,60,45,30,"Neutral",51,60),("Razorgrass Steppe",90,60,45,30,"Neutral",51,60),
 ("Gravemoor",45,90,45,30,"Neutral",61,70),("Dreadmoor",90,90,45,30,"Neutral",61,70),
 ("Sunscar Desert",0,90,45,30,"Neutral",71,80),("Scorchsand Wastes",135,90,45,30,"Neutral",71,80),
 ("Ember Highlands",0,120,45,30,"Neutral",81,90),("Cinder Peaks",135,120,45,30,"Neutral",81,90),
 ("Wyrmreach",45,120,45,30,"Neutral",91,100),("Shadowlands",90,120,45,30,"Neutral",91,100)]
# the newer zones look like (and share the monsters and flavour of) one of the original twelve
BIOME_OF={"Blackthorn Wilds":"Ironwood","Silverfrost":"Frostmarch","Saltcrag Coast":"Storm Coast","Mirewood Fen":"Bloodfen",
 "Razorgrass Steppe":"Crownlands","Gravemoor":"Dreadmoor","Scorchsand Wastes":"Sunscar Desert","Cinder Peaks":"Ember Highlands"}
def bz(name):
 """The biome (look, monsters, flavour) of a zone name."""
 return BIOME_OF.get(name,name)
from . import rpg as _rpg
for _n,_b in BIOME_OF.items():           # quest flavour of the newer zones: the original's lines, with the new name
 _rpg.ZONE_FLAVOR.setdefault(_n,{k:(t.replace(_b,_n),d.replace(_b,_n)) for k,(t,d) in _rpg.ZONE_FLAVOR.get(_b,{}).items()})
AREAS=[(a[0],a[1]*WS,a[2]*WS,a[3]*WS,a[4]*WS,a[5],a[6],a[7]) for a in _AREAS0]
TOWNS_BY_ZONE={"Greenfields":("Oakwatch",""),"Ashen Vale":("Ashgate",""),"Ironwood":("Silverbrook","Ironhaven"),
 "Blackthorn Wilds":("Thornhollow","Blackspire"),"Silverfrost":("Frosthold","Wintermere"),"Frostmarch":("Rimeholt","Icefang Hold"),
 "Storm Coast":("Stormport","Harborwatch"),"Saltcrag Coast":("Saltcrag","Gullrock"),"Mirewood Fen":("Fenwall","Mirehaven"),
 "Bloodfen":("Bogrot","Redfang"),"Crownlands":("Crownspire","Kingsrest"),"Razorgrass Steppe":("Warhorn","Razorgrass Camp"),
 "Gravemoor":("Gravewatch","Stonebridge"),"Dreadmoor":("Dreadkeep","Shadowmere"),"Sunscar Desert":("Sunrest","Duneshade"),
 "Scorchsand Wastes":("Scorchmouth","Sandfang"),"Ember Highlands":("Emberfall","Cinderwatch"),"Cinder Peaks":("Ashpeak","Slagmaw"),
 "Wyrmreach":("Wyrmstead","Dragonfall"),"Shadowlands":("Nightvale","Voidspire")}
TOWN_NAMES=["Oakwatch","Ashgate","Ironhaven","Frosthold","Stormport","Fenwall","Crownspire","Dreadkeep","Sunrest","Emberfall","Wyrmstead","Shadowmere","Silverbrook","Redfang","Stonebridge","Wintermere","Harborwatch","Mirehaven","Kingsrest","Blackspire","Duneshade","Cinderwatch","Dragonfall","Nightvale"]
# Each zone has its own bestiary, like an MMO: wolves and boars in the
# starting fields, giants in the snow, demons and dragons at the top end.
ZONE_MONSTERS={
 "Greenfields":["Wolf","Boar","Kobold","Giant Beetle","Skeleton","Fire Imp"],"Ashen Vale":["Goblin","Spider","Bandit","Gnoll","Cultist","Skeleton"],
 "Ironwood":["Bandit","Spider","Orc","Bear","Dire Boar","Swamp Hag","Cultist","Ancient Treant"],"Frostmarch":["Frost Giant","Wolf","Elemental","Yeti","Ice Wolf","Wraith","Banshee"],
 "Storm Coast":["Harpy","Basilisk","Bandit","Sea Serpent","Elemental","Wraith"],"Bloodfen":["Troll","Ghoul","Spider","Mud Leech","Swamp Hag","Wraith","Cultist"],
 "Crownlands":["Ogre","Dark Knight","Orc","Cultist","Wraith","Ancient Treant"],"Dreadmoor":["Skeleton","Wraith","Ghoul","Cultist","Banshee","Bone Knight"],
 "Sunscar Desert":["Sand Wyrm","Basilisk","Cultist","Scorpion","Mummy","Elemental","Fire Imp"],"Ember Highlands":["Lava Beast","Demon","Dragonkin","Fire Imp","Magma Golem"],
 "Wyrmreach":["Wyvern","Dragonkin","Elemental","Drake","Thunder Harpy","Wraith","Fire Imp"],"Shadowlands":["Demon","Wraith","Dark Knight","Shadow Stalker","Void Horror"]}
for _n,_b in BIOME_OF.items():ZONE_MONSTERS.setdefault(_n,list(ZONE_MONSTERS[_b]))
ELITE_CHANCE=.08
# 0.23: where each shopkeeper stands, relative to the town centre (next to the market stalls)
SHOP_POSTS={"vendor":(-6.6,5.6),"grocer":(-12.6,5.6),"enchanter":(-14.0,-6.4),"blacksmith":(7.0,-6.8),"innkeeper":(7.4,7.8),"stablemaster":(-10.2,-3.2),"questgiver":(-3.4,-8.8),"dailygiver":(-7.8,-14.4),"marketeer":(-1.0,9.6),"fishmonger":(-10.4,1.4),"jeweler":(3.4,-9.2),"banker":(9.4,0.6),"king":KING_POST}
KING_POST=(KING_POST[0]*TS,KING_POST[1]*TS);SHOP_POSTS={k:(v[0]*TS,v[1]*TS) for k,v in SHOP_POSTS.items()};SHOP_POSTS["king"]=KING_POST
# 0.39: these shopkeepers work inside their own building - the building (with its name label) is what you click,
# and they are not shown as people.  They keep standing (unseen) at its door so their shop and stock still work.
BUILDING_ROLES={"vendor":"apothecary","grocer":"general","enchanter":"enchanter","banker":"bank","innkeeper":"inn","jeweler":"jeweler","blacksmith":"smithy","fishmonger":"hut","stablemaster":"stable","marketeer":"market"}
# 0.40: the Forge only makes things - the Blacksmith's own shop sells weapons and armor, the General Store sells supplies
HIDDEN_ROLES=tuple(BUILDING_ROLES)
STATION_OWNER={st:role for role,st in BUILDING_ROLES.items()}
GUARD_KINDS=("Royal Guard","Gate Guard","City Patrol")    # 0.39: the ruler's bodyguards, guards at the gates, patrols on the streets
GATE_GUARDS=4;PATROLS=3
def mkind(name):
 """Species of a monster actor name: 'Elite Wolf #12' -> 'Wolf'."""
 n=name.split(" #")[0]
 return n[6:] if n.startswith("Elite ") else n
QUEST_VERBS=["Hunt","Clear","Recover","Escort","Defeat","Investigate","Rescue","Gather"]
QUEST_TARGETS=["wolves","bandits","goblins","relics","lost travelers","cultists","undead","rare herbs","stolen supplies","beasts"]

# 0.9.0 combat/endgame definitions.  These are intentionally data-driven so
# adding a class, ability, raid or loot table does not require rewriting combat.
# 0.11.0 skill system: every class has 6 attack skills (keys 1-6), 4 defensive
# skills (keys 7-0) and 2 passives.  Skills unlock as you level, WoW-style.
#   attack kinds : damage, aoe (splash around the target), nova (around you),
#                  dot (damage every second), stun, charge (leap to the target),
#                  multi (several hits), lifesteal, execute (bonus under 35% HP)
#   defense kinds: heal, hot (heal every second), shield (absorbs damage),
#                  armor (damage reduction), dodge, sprint (run speed), vanish
# power = multiplier of your weapon damage (attacks) or share of max HP (heals,
# shields) or a fraction (armor/dodge/sprint).  cd and dur are in seconds.
def _A(name,kind,power,mana,cd,rng,unlock,**kw):
 d={"name":name,"kind":kind,"power":power,"mana":mana,"cd":cd,"range":rng,"unlock":unlock,"cat":"attack"};d.update(kw);return d
def _D(name,kind,power,mana,cd,unlock,**kw):
 d={"name":name,"kind":kind,"power":power,"mana":mana,"cd":cd,"range":0,"unlock":unlock,"cat":"defense"};d.update(kw);return d
ABILITIES={
 "Warrior":[
  _A("Heroic Strike","damage",1.5,0,2,2.0,1),
  _A("Cleave","aoe",1.05,12,6,2.0,3),
  _A("Rend","dot",.40,10,8,2.0,6,dur=8),
  _A("Shield Bash","stun",.9,12,14,2.0,10,stun=3),
  _A("Charge","charge",1.2,8,12,9.0,15,stun=1),
  _A("Execute","execute",2.25,15,10,2.0,22),
  _D("Shield Wall","armor",.50,10,40,2,dur=8),
  _D("Last Stand","heal",.30,0,45,5),
  _D("Iron Skin","shield",.25,15,30,12,dur=10),
  _D("Second Wind","hot",.04,12,40,20,dur=10)],
 "Ranger":[
  _A("Aimed Shot","damage",1.7,4,2.5,9.0,1),
  _A("Multi-Shot","aoe",1.0,16,7,9.0,3),
  _A("Serpent Sting","dot",.35,10,9,9.0,6,dur=10),
  _A("Concussive Shot","stun",.8,12,15,9.0,10,stun=3),
  _A("Rapid Fire","multi",.6,20,14,9.0,15,hits=4),
  _A("Kill Shot","execute",2.3,18,10,9.0,22),
  _D("Mend","heal",.28,12,12,2),
  _D("Disengage","sprint",.60,8,16,5,dur=4),
  _D("Camouflage","vanish",0,15,40,12,dur=6),
  _D("Barkskin","armor",.35,12,35,20,dur=10)],
 "Mage":[
  _A("Arcane Bolt","damage",1.65,8,2,9.0,1),
  _A("Frost Nova","nova",1.0,20,10,3.0,3,stun=2),
  _A("Ignite","dot",.50,14,8,9.0,6,dur=6),
  _A("Deep Freeze","stun",1.0,15,14,9.0,10,stun=3),
  _A("Arcane Missiles","multi",.5,22,12,9.0,15,hits=5),
  _A("Meteor","aoe",2.6,35,20,9.0,22),
  _D("Ice Barrier","shield",.30,18,25,2,dur=12),
  _D("Blink","sprint",.90,10,15,5,dur=8),
  _D("Mana Shield","armor",.40,15,30,12,dur=10),
  _D("Invisibility","vanish",0,20,45,20,dur=8)],
 "Cleric":[
  _A("Smite","damage",1.45,6,2,8.0,1),
  _A("Holy Nova","nova",.9,18,8,3.5,3),
  _A("Holy Fire","dot",.45,12,9,8.0,6,dur=8),
  _A("Hammer of Justice","stun",1.0,14,18,8.0,10,stun=4),
  _A("Penance","lifesteal",1.8,18,10,8.0,15,steal=.5),
  _A("Judgement","execute",2.6,25,14,8.0,22),
  _D("Greater Heal","heal",.42,24,12,2),
  _D("Renew","hot",.05,14,15,5,dur=10),
  _D("Divine Shield","shield",.60,25,60,12,dur=8),
  _D("Blessing of Stone","armor",.35,15,35,20,dur=12)],
 "Rogue":[
  _A("Backstab","damage",2.0,4,3,2.0,1),
  _A("Fan of Knives","nova",.95,16,7,3.0,3),
  _A("Rupture","dot",.50,12,9,2.0,6,dur=8),
  _A("Kidney Shot","stun",.7,14,16,2.0,10,stun=4),
  _A("Shadowstep","charge",2.0,14,11,9.0,15,stun=0),
  _A("Eviscerate","execute",2.4,18,10,2.0,22),
  _D("Evasion","dodge",.50,10,35,2,dur=8),
  _D("Recuperate","hot",.04,10,20,5,dur=12),
  _D("Vanish","vanish",0,15,40,12,dur=6),
  _D("Cloak of Shadows","shield",.30,15,35,20,dur=8)],
 # ---- 0.18.0 pure-DPS classes
 # Berserker: two-handed axe brawler. Highest raw hits, heals by dealing damage, few escapes.
 "Berserker":[
  _A("Raging Blow","damage",1.75,0,2.5,2.0,1),
  _A("Whirlwind","nova",1.15,14,7,3.0,3),
  _A("Bloodletting","dot",.45,10,8,2.0,6,dur=8),
  _A("Skull Splitter","stun",1.0,14,16,2.0,10,stun=2),
  _A("Bloodthirst","lifesteal",1.6,14,8,2.0,15,steal=.5),
  _A("Decapitate","execute",2.7,20,12,2.0,22),
  _D("Enraged Regeneration","hot",.05,12,35,2,dur=8),
  _D("Unbreakable","armor",.40,12,40,5,dur=8),
  _D("Berserker Rush","sprint",.70,8,18,12,dur=4),
  _D("Battle Trance","shield",.25,15,35,20,dur=8)],
 # Warlock: fel caster. Strongest damage-over-time and life drain, a fragile but sustained ranged kit.
 "Warlock":[
  _A("Shadow Bolt","damage",1.6,7,2,9.0,1),
  _A("Rain of Fire","aoe",1.1,18,8,9.0,3),
  _A("Corruption","dot",.60,10,8,9.0,6,dur=10),
  _A("Howl of Terror","nova",.7,16,16,3.5,10,stun=3),
  _A("Drain Life","lifesteal",1.5,16,9,9.0,15,steal=.6),
  _A("Chaos Bolt","execute",2.8,28,14,9.0,22),
  _D("Dark Pact","shield",.35,18,30,2,dur=10),
  _D("Soul Leech","hot",.05,12,20,5,dur=10),
  _D("Unending Resolve","armor",.45,15,40,12,dur=8),
  _D("Demonic Circle","sprint",.90,10,18,20,dur=8)],
 # Monk: unarmed/quarterstaff martial artist. Fast multi-hit flurries, gap closer, the best dodge.
 "Monk":[
  _A("Tiger Palm","damage",1.55,3,1.8,2.0,1),
  _A("Spinning Crane Kick","nova",1.0,14,6,3.0,3),
  _A("Flying Serpent Kick","charge",1.4,10,10,9.0,6,stun=1),
  _A("Leg Sweep","nova",.6,14,18,3.0,10,stun=3),
  _A("Fists of Fury","multi",.55,20,12,2.0,15,hits=5),
  _A("Touch of Death","execute",2.6,20,14,2.0,22),
  _D("Touch of Karma","shield",.30,15,35,2,dur=8),
  _D("Vivify","heal",.30,15,15,5),
  _D("Diffuse Magic","dodge",.50,12,35,12,dur=6),
  _D("Fortifying Brew","armor",.40,12,40,20,dur=10)],
 # ---- 0.19.0 pure tank
 # Juggernaut: tower shield and warhammer. Lowest damage, highest health and mitigation; always the Tank.
 "Juggernaut":[
  _A("Shield Slam","damage",1.35,0,2,2.0,1),
  _A("Thunder Clap","nova",.85,12,7,3.5,3,stun=1),
  _A("Sunder Armor","dot",.35,10,8,2.0,6,dur=10),
  _A("Shield Charge","charge",1.0,10,12,9.0,10,stun=2),
  _A("Revenge","lifesteal",1.15,12,7,2.0,15,steal=.45),
  _A("Avalanche Slam","aoe",1.5,20,12,2.5,22),
  _D("Bulwark","armor",.60,10,40,2,dur=8),
  _D("Fortress","shield",.50,15,30,5,dur=10),
  _D("Unyielding","hot",.05,12,30,12,dur=10),
  _D("Last Rampart","heal",.40,0,60,20)],
}
PASSIVES={
 "Warrior":[{"name":"Toughness","unlock":8,"fx":{"hp_pct":.15},"desc":"+15% maximum health"},
            {"name":"Weapon Mastery","unlock":25,"fx":{"dmg_pct":.10},"desc":"+10% damage"}],
 "Ranger":[{"name":"Eagle Eye","unlock":8,"fx":{"crit":.12},"desc":"+12% critical strike chance"},
           {"name":"Swiftness","unlock":25,"fx":{"speed":.12},"desc":"+12% run speed"}],
 "Mage":[{"name":"Arcane Intellect","unlock":8,"fx":{"mana_regen":.5},"desc":"+50% mana regeneration"},
         {"name":"Elemental Mastery","unlock":25,"fx":{"crit":.10,"dmg_pct":.05},"desc":"+10% critical strike chance, +5% damage"}],
 "Cleric":[{"name":"Spiritual Healing","unlock":8,"fx":{"heal_pct":.25},"desc":"+25% healing"},
           {"name":"Holy Armor","unlock":25,"fx":{"armor_pct":.12},"desc":"12% less damage taken"}],
 "Rogue":[{"name":"Lethality","unlock":8,"fx":{"crit":.15},"desc":"+15% critical strike chance"},
          {"name":"Agility","unlock":25,"fx":{"dodge":.08},"desc":"+8% chance to dodge attacks"}],
 "Berserker":[{"name":"Bloodlust","unlock":8,"fx":{"dmg_pct":.15},"desc":"+15% damage"},
              {"name":"Rampage","unlock":25,"fx":{"crit":.10,"hp_pct":.05},"desc":"+10% critical strike chance, +5% maximum health"}],
 "Warlock":[{"name":"Soul Siphon","unlock":8,"fx":{"dmg_pct":.10,"hp_pct":.05},"desc":"+10% damage, +5% maximum health"},
            {"name":"Shadow Mastery","unlock":25,"fx":{"crit":.08,"mana_regen":.4},"desc":"+8% critical strike chance, +40% mana regeneration"}],
 "Monk":[{"name":"Way of the Tiger","unlock":8,"fx":{"crit":.10,"dodge":.06},"desc":"+10% critical strike chance, +6% chance to dodge attacks"},
         {"name":"Inner Peace","unlock":25,"fx":{"dmg_pct":.08,"speed":.10},"desc":"+8% damage, +10% run speed"}],
 "Juggernaut":[{"name":"Plated Colossus","unlock":8,"fx":{"hp_pct":.25,"armor_pct":.10},"desc":"+25% maximum health, 10% less damage taken"},
               {"name":"Immovable","unlock":25,"fx":{"armor_pct":.12,"dodge":.05},"desc":"12% less damage taken, +5% chance to dodge attacks"}],
}
ABILITY_KEYS=tuple("1234567890!@#$%^")      # 1-0 are the ten class skills; Shift+1..6 are the six capstone spells
CAP_NAMES={
 "Warrior":("Earthshaker","Bulwark of Ages","Hundred Cuts","Rallying Cry","Decapitate","Titan's Wrath"),
 "Ranger":("Volley of Thorns","Hunter's Ward","Storm of Arrows","Nature's Gift","Heartseeker","Skyfall Barrage"),
 "Mage":("Starfall","Prismatic Ward","Arcane Barrage","Time Warp Mend","Disintegrate","Cataclysm"),
 "Cleric":("Wrath of Heaven","Aegis of Dawn","Sunburst Hail","Miracle","Divine Verdict","Judgement Day"),
 "Rogue":("Blade Tempest","Shadow Veil","Thousand Stabs","Second Life","Assassinate","Night's Reckoning"),
 "Berserker":("Rampage","Rage Barrier","Frenzied Flurry","Blood Mend","Skullsplitter","Ragnarok"),
 "Warlock":("Rain of Ruin","Soul Aegis","Chaos Bolts","Drain Soul","Doom","Abyssal Collapse"),
 "Monk":("Whirlwind Kick","Iron Mantra","Hundred Fists","Inner Peace","Touch of Death","Heavenly Palm"),
 "Juggernaut":("Seismic Slam","Fortress Stance","Piledriver","Unbreakable","Executioner's Maul","Worldbreaker"),
 "Paladin":("Hammerfall","Divine Bulwark","Wings of Retribution","Lay of Light","Sentence","Radiant Judgement"),
 "Shaman":("Chain Tempest","Spirit Shell","Thunder Volley","Ancestral Mend","Wind Fury Finisher","Earthen Cataclysm"),
 "Druid":("Starburst Grove","Ironbark","Rending Flurry","Tree of Life","Feral Finisher","Wrath of the Wild")}
def _make_capstones():
 for key,lst in ABILITIES.items():
  if len(lst)>10:continue
  cls=key.split(":")[0];nm=CAP_NAMES.get(cls)
  if not nm:continue
  rng=next((a["range"] for a in lst if a["cat"]=="attack" and a["kind"]=="damage"),2.0)
  lst+=[_A(nm[0],"aoe",3.2,30,18,rng,30),_D(nm[1],"shield",.8,25,60,40,dur=12),_A(nm[2],"multi",.95,35,20,rng,50,hits=6),
        _D(nm[3],"heal",.65,30,45,60),_A(nm[4],"execute",4.6,35,24,rng,70),_A(nm[5],"nova",3.8,45,40,4.5,80,stun=3)]
STAT_KEYS=("str","agi","int","vit")
STAT_INFO={"str":("Strength","+0.8% damage per point"),"agi":("Agility","+0.25% crit chance and +0.2% move speed per point"),
 "int":("Intellect","+0.5% healing and shields, -0.4% mana cost and +1% mana regeneration per point"),"vit":("Vitality","+8 maximum health per point")}
MAX_RANK=10               # 0.38: was 5; ranks 6-10 add less than ranks 2-5
BASE_CRIT=.05

# ---- Hybrid classes (0.11.0): Paladin, Shaman and Druid can tank, heal or deal
# damage. Their skills and passives come from the chosen role (spec).
HYBRID_SPECS={
 "Paladin":[("Protection","Tank"),("Holy","Healer"),("Retribution","DPS")],
 "Shaman":[("Earthwarden","Tank"),("Restoration","Healer"),("Elemental","DPS")],
 "Druid":[("Guardian","Tank"),("Restoration","Healer"),("Feral","DPS")],
}
ABILITIES.update({
 "Paladin:Protection":[
  _A("Crusader Strike","damage",1.4,4,2,2.0,1),
  _A("Consecration","nova",.8,14,8,3.0,3),
  _A("Hammer of the Righteous","aoe",1.1,12,6,2.0,6),
  _A("Avenger's Shield","stun",.9,12,12,9.0,10,stun=2),
  _A("Judgement","lifesteal",1.2,12,8,8.0,15,steal=.4),
  _A("Hammer of Wrath","execute",2.2,18,10,8.0,22),
  _D("Ardent Defender","armor",.50,10,40,2,dur=8),
  _D("Lay on Hands","heal",.60,0,90,5),
  _D("Divine Protection","shield",.35,15,30,12,dur=10),
  _D("Guardian's Light","hot",.04,12,30,20,dur=10)],
 "Paladin:Holy":[
  _A("Crusader Strike","damage",1.3,4,2,2.0,1),
  _A("Holy Shock","lifesteal",1.4,12,6,8.0,3,steal=.7),
  _A("Consecration","nova",.8,14,8,3.0,6),
  _A("Hammer of Justice","stun",.8,14,18,8.0,10,stun=4),
  _A("Exorcism","dot",.40,12,9,8.0,15,dur=8),
  _A("Hammer of Wrath","execute",2.0,18,10,8.0,22),
  _D("Holy Light","heal",.45,20,8,2),
  _D("Beacon of Renewal","hot",.06,15,15,5,dur=10),
  _D("Divine Shield","shield",.70,25,60,12,dur=8),
  _D("Aura Mastery","armor",.30,15,30,20,dur=10)],
 "Paladin:Retribution":[
  _A("Crusader Strike","damage",1.6,4,2,2.0,1),
  _A("Divine Storm","nova",1.1,14,7,3.0,3),
  _A("Judgement","dot",.50,12,8,8.0,6,dur=8),
  _A("Hammer of Justice","stun",.9,14,16,2.0,10,stun=3),
  _A("Templar's Verdict","multi",.7,18,10,2.0,15,hits=3),
  _A("Final Reckoning","execute",2.5,20,12,2.0,22),
  _D("Shield of Vengeance","shield",.30,15,30,2,dur=10),
  _D("Word of Glory","heal",.30,15,15,5),
  _D("Divine Steed","sprint",.60,8,20,12,dur=4),
  _D("Blessing of Protection","armor",.45,15,40,20,dur=8)],
 "Shaman:Earthwarden":[
  _A("Stormstrike","damage",1.5,4,2,2.0,1),
  _A("Earthquake","nova",.9,16,8,3.5,3),
  _A("Flame Shock","dot",.40,10,8,8.0,6,dur=8),
  _A("Earthbind Shock","stun",.8,12,14,8.0,10,stun=3),
  _A("Lava Lash","lifesteal",1.4,12,8,2.0,15,steal=.4),
  _A("Earthshatter","execute",2.2,18,10,2.0,22),
  _D("Stoneskin Totem","armor",.45,12,40,2,dur=10),
  _D("Earth Shield","shield",.35,15,30,5,dur=12),
  _D("Healing Surge","heal",.30,15,15,12),
  _D("Healing Stream Totem","hot",.04,12,30,20,dur=12)],
 "Shaman:Restoration":[
  _A("Lightning Bolt","damage",1.5,6,2,9.0,1),
  _A("Chain Lightning","aoe",1.0,16,7,9.0,3),
  _A("Flame Shock","dot",.40,10,8,9.0,6,dur=8),
  _A("Frost Shock","stun",.8,12,15,9.0,10,stun=3),
  _A("Riptide Strike","lifesteal",1.3,14,8,9.0,15,steal=.8),
  _A("Lava Burst","execute",2.0,18,10,9.0,22),
  _D("Healing Wave","heal",.45,20,8,2),
  _D("Riptide","hot",.06,14,15,5,dur=10),
  _D("Spirit Link","shield",.50,25,50,12,dur=8),
  _D("Spiritwalk","sprint",.60,8,20,20,dur=4)],
 "Shaman:Elemental":[
  _A("Lightning Bolt","damage",1.7,6,2,9.0,1),
  _A("Chain Lightning","aoe",1.1,16,7,9.0,3),
  _A("Flame Shock","dot",.50,10,8,9.0,6,dur=8),
  _A("Thunderstorm","nova",1.0,18,12,3.5,10,stun=2),
  _A("Elemental Blast","multi",.7,20,12,9.0,15,hits=3),
  _A("Earth Shock","execute",2.4,18,10,9.0,22),
  _D("Astral Shift","armor",.45,12,40,2,dur=8),
  _D("Healing Surge","heal",.30,15,15,5),
  _D("Ghost Wolf","sprint",.70,8,20,12,dur=5),
  _D("Earth Elemental","shield",.30,15,35,20,dur=10)],
 "Druid:Guardian":[
  _A("Mangle","damage",1.5,4,2,2.0,1),
  _A("Swipe","nova",.9,12,6,3.0,3),
  _A("Thrash","dot",.45,10,8,2.5,6,dur=8),
  _A("Bash","stun",.8,12,15,2.0,10,stun=4),
  _A("Wild Charge","charge",1.1,8,12,9.0,15,stun=1),
  _A("Maul","execute",2.1,15,10,2.0,22),
  _D("Barkskin","armor",.45,10,40,2,dur=10),
  _D("Frenzied Regeneration","hot",.06,12,30,5,dur=6),
  _D("Survival Instincts","shield",.40,15,40,12,dur=8),
  _D("Ironfur","dodge",.35,10,30,20,dur=8)],
 "Druid:Restoration":[
  _A("Wrath","damage",1.5,6,2,8.0,1),
  _A("Hurricane","aoe",1.0,16,8,8.0,3),
  _A("Moonfire","dot",.45,10,8,8.0,6,dur=10),
  _A("Entangling Roots","stun",.6,12,15,8.0,10,stun=4),
  _A("Nature's Drain","lifesteal",1.3,14,8,8.0,15,steal=.8),
  _A("Starsurge","execute",2.0,18,10,8.0,22),
  _D("Regrowth","heal",.40,18,8,2),
  _D("Rejuvenation","hot",.06,14,15,5,dur=12),
  _D("Ironbark","shield",.45,20,40,12,dur=10),
  _D("Stampeding Roar","sprint",.60,8,20,20,dur=4)],
 "Druid:Feral":[
  _A("Shred","damage",1.8,4,2.5,2.0,1),
  _A("Swipe","nova",1.0,14,6,3.0,3),
  _A("Rake","dot",.50,10,8,2.0,6,dur=8),
  _A("Maim","stun",.8,14,15,2.0,10,stun=3),
  _A("Pounce","charge",1.6,10,12,9.0,15,stun=1),
  _A("Ferocious Bite","execute",2.5,18,10,2.0,22),
  _D("Survival Instincts","armor",.50,10,40,2,dur=6),
  _D("Regrowth","heal",.30,15,15,5),
  _D("Dash","sprint",.80,8,20,12,dur=5),
  _D("Prowl","vanish",0,15,40,20,dur=6)],
})
MANA_REGEN_BASE=.5      # mana per tick (4 ticks a second): 2 mana a second with the Meditation passive, before regeneration bonuses
def _P(name,unlock,fx,desc):return {"name":name,"unlock":unlock,"fx":fx,"desc":desc}
PASSIVES.update({
 "Paladin:Protection":[_P("Sanctuary",8,{"hp_pct":.20,"armor_pct":.08},"+20% maximum health, 8% less damage taken"),_P("Holy Bulwark",25,{"armor_pct":.10,"heal_pct":.10},"10% less damage taken, +10% healing")],
 "Paladin:Holy":[_P("Illumination",8,{"heal_pct":.40},"+40% healing"),_P("Divine Insight",25,{"mana_regen":.5,"heal_pct":.10},"+50% mana regeneration, +10% healing")],
 "Paladin:Retribution":[_P("Sanctified Wrath",8,{"dmg_pct":.12},"+12% damage"),_P("Art of War",25,{"crit":.12},"+12% critical strike chance")],
 "Shaman:Earthwarden":[_P("Earthen Fortitude",8,{"hp_pct":.20,"armor_pct":.05},"+20% maximum health, 5% less damage taken"),_P("Elemental Shielding",25,{"armor_pct":.12},"12% less damage taken")],
 "Shaman:Restoration":[_P("Purification",8,{"heal_pct":.40},"+40% healing"),_P("Water Shield",25,{"mana_regen":.6},"+60% mana regeneration")],
 "Shaman:Elemental":[_P("Elemental Fury",8,{"crit":.12},"+12% critical strike chance"),_P("Lightning Mastery",25,{"dmg_pct":.10},"+10% damage")],
 "Druid:Guardian":[_P("Thick Hide",8,{"hp_pct":.20,"armor_pct":.08},"+20% maximum health, 8% less damage taken"),_P("Ursine Vigor",25,{"armor_pct":.10,"dodge":.05},"10% less damage taken, +5% dodge")],
 "Druid:Restoration":[_P("Living Seed",8,{"heal_pct":.40},"+40% healing"),_P("Innervate Spirit",25,{"mana_regen":.6},"+60% mana regeneration")],
 "Druid:Feral":[_P("Predatory Swiftness",8,{"crit":.12},"+12% critical strike chance"),_P("Feral Instinct",25,{"dmg_pct":.08,"speed":.05},"+8% damage, +5% run speed")],
})
# 0.38: every class/spec chooses from a pool of 7 passives (the two above plus four more at levels 15, 35, 50 and 70, and Meditation at 50);
# one passive slot from level 1 to 50, two from level 51, three from level 75 - chosen at the Skill Shop.  0.38.1: each pool's first passive is
# available from level 1, so the first slot is never empty.
_MORE_PASSIVES={
 "Warrior":[("Battle Hardened",{"armor_pct":.08,"hp_pct":.05},"8% less damage taken, +5% maximum health"),("Deep Wounds",{"crit":.08,"dmg_pct":.05},"+8% critical strike chance, +5% damage"),
            ("Juggernaut's Stride",{"speed":.10,"dodge":.04},"+10% run speed, +4% dodge"),("Warlord",{"dmg_pct":.14,"hp_pct":.08},"+14% damage, +8% maximum health")],
 "Ranger":[("Hawk's Focus",{"dmg_pct":.08},"+8% damage"),("Camouflage",{"dodge":.08,"speed":.05},"+8% dodge, +5% run speed"),
           ("Survivalist",{"hp_pct":.12,"heal_pct":.10},"+12% maximum health, +10% healing"),("Dead Eye",{"crit":.12,"dmg_pct":.10},"+12% critical strike chance, +10% damage")],
 "Mage":[("Arcane Mind",{"dmg_pct":.08},"+8% damage"),("Mana Shield",{"armor_pct":.08,"mana_regen":.2},"8% less damage taken, +20% mana regeneration"),
         ("Blink Mastery",{"speed":.12,"dodge":.04},"+12% run speed, +4% dodge"),("Archmage",{"dmg_pct":.14,"crit":.08},"+14% damage, +8% critical strike chance")],
 "Cleric":[("Devotion",{"mana_regen":.4},"+40% mana regeneration"),("Blessed Body",{"hp_pct":.12},"+12% maximum health"),
           ("Holy Fire",{"dmg_pct":.10,"crit":.05},"+10% damage, +5% critical strike chance"),("Saint",{"heal_pct":.35,"armor_pct":.06},"+35% healing, 6% less damage taken")],
 "Rogue":[("Shadow Step",{"speed":.10},"+10% run speed"),("Venom",{"dmg_pct":.10},"+10% damage"),
          ("Evasion",{"dodge":.10,"armor_pct":.04},"+10% dodge, 4% less damage taken"),("Master Assassin",{"crit":.14,"dmg_pct":.10},"+14% critical strike chance, +10% damage")],
 "Berserker":[("Thick Skull",{"hp_pct":.10,"armor_pct":.04},"+10% maximum health, 4% less damage taken"),("Blood Frenzy",{"speed":.08,"crit":.06},"+8% run speed, +6% critical strike chance"),
              ("Unstoppable",{"armor_pct":.10},"10% less damage taken"),("Avatar of War",{"dmg_pct":.18,"crit":.06},"+18% damage, +6% critical strike chance")],
 "Warlock":[("Demonic Pact",{"hp_pct":.12},"+12% maximum health"),("Fel Armor",{"armor_pct":.08,"heal_pct":.10},"8% less damage taken, +10% healing"),
            ("Malediction",{"dmg_pct":.10,"crit":.04},"+10% damage, +4% critical strike chance"),("Lord of the Abyss",{"dmg_pct":.14,"mana_regen":.4},"+14% damage, +40% mana regeneration")],
 "Monk":[("Iron Body",{"hp_pct":.10,"armor_pct":.05},"+10% maximum health, 5% less damage taken"),("Flowing Water",{"dodge":.08,"mana_regen":.2},"+8% dodge, +20% mana regeneration"),
         ("Swift Fists",{"crit":.10,"speed":.06},"+10% critical strike chance, +6% run speed"),("Grandmaster",{"dmg_pct":.14,"dodge":.06},"+14% damage, +6% dodge")],
 "Juggernaut":[("Bulwark",{"armor_pct":.08},"8% less damage taken"),("Second Skin",{"hp_pct":.15,"heal_pct":.10},"+15% maximum health, +10% healing"),
               ("Crushing Weight",{"dmg_pct":.12},"+12% damage"),("Titan",{"hp_pct":.25,"armor_pct":.10},"+25% maximum health, 10% less damage taken")],
 "Paladin:Protection":[("Righteous Fury",{"dmg_pct":.08},"+8% damage"),("Guarded by Light",{"dodge":.06,"heal_pct":.10},"+6% dodge, +10% healing"),
                       ("Divine Steed",{"speed":.10,"hp_pct":.05},"+10% run speed, +5% maximum health"),("Ardent Guardian",{"hp_pct":.20,"armor_pct":.10},"+20% maximum health, 10% less damage taken")],
 "Paladin:Holy":[("Holy Shield",{"armor_pct":.08},"8% less damage taken"),("Beacon",{"hp_pct":.10,"heal_pct":.10},"+10% maximum health, +10% healing"),
                 ("Light's Wrath",{"dmg_pct":.10},"+10% damage"),("Avenging Light",{"heal_pct":.35,"mana_regen":.3},"+35% healing, +30% mana regeneration")],
 "Paladin:Retribution":[("Crusader",{"speed":.08,"dmg_pct":.04},"+8% run speed, +4% damage"),("Seal of Command",{"crit":.06,"dmg_pct":.06},"+6% critical strike chance, +6% damage"),
                        ("Plate Mastery",{"armor_pct":.08,"hp_pct":.06},"8% less damage taken, +6% maximum health"),("Avenging Wrath",{"dmg_pct":.16,"crit":.08},"+16% damage, +8% critical strike chance")],
 "Shaman:Earthwarden":[("Stoneskin",{"armor_pct":.06,"hp_pct":.06},"6% less damage taken, +6% maximum health"),("Earthen Might",{"dmg_pct":.08},"+8% damage"),
                       ("Spirit Walk",{"speed":.10,"dodge":.04},"+10% run speed, +4% dodge"),("Mountain King",{"hp_pct":.22,"armor_pct":.10},"+22% maximum health, 10% less damage taken")],
 "Shaman:Restoration":[("Tidal Waves",{"heal_pct":.15},"+15% healing"),("Ancestral Fortitude",{"hp_pct":.12},"+12% maximum health"),
                       ("Nature's Swiftness",{"speed":.10,"mana_regen":.2},"+10% run speed, +20% mana regeneration"),("Spirit of the Ancients",{"heal_pct":.35,"armor_pct":.06},"+35% healing, 6% less damage taken")],
 "Shaman:Elemental":[("Elemental Focus",{"mana_regen":.4},"+40% mana regeneration"),("Lava Surge",{"dmg_pct":.08,"crit":.04},"+8% damage, +4% critical strike chance"),
                     ("Ghost Wolf",{"speed":.12},"+12% run speed"),("Storm Lord",{"dmg_pct":.14,"crit":.08},"+14% damage, +8% critical strike chance")],
 "Druid:Guardian":[("Bear Strength",{"dmg_pct":.08},"+8% damage"),("Survival Instincts",{"hp_pct":.12,"heal_pct":.10},"+12% maximum health, +10% healing"),
                   ("Wild Charge",{"speed":.10},"+10% run speed"),("Elder Bear",{"hp_pct":.22,"armor_pct":.10},"+22% maximum health, 10% less damage taken")],
 "Druid:Restoration":[("Nature's Grace",{"heal_pct":.15},"+15% healing"),("Barkskin",{"armor_pct":.08},"8% less damage taken"),
                      ("Travel Form",{"speed":.12},"+12% run speed"),("Avatar of Nature",{"heal_pct":.35,"mana_regen":.3},"+35% healing, +30% mana regeneration")],
 "Druid:Feral":[("Primal Fury",{"dmg_pct":.06,"crit":.04},"+6% damage, +4% critical strike chance"),("Cat's Grace",{"dodge":.08},"+8% dodge"),
                ("Savage Roar",{"dmg_pct":.10,"hp_pct":.05},"+10% damage, +5% maximum health"),("Apex Predator",{"dmg_pct":.14,"crit":.10},"+14% damage, +10% critical strike chance")],
}
for _k,_extra in _MORE_PASSIVES.items():
 PASSIVES[_k]=PASSIVES[_k][:2]+[_P(n,lv,fx,d) for lv,(n,fx,d) in zip((15,35,50,70),_extra)]
 PASSIVES[_k].sort(key=lambda p:p["unlock"])
 PASSIVES[_k][0]=dict(PASSIVES[_k][0],unlock=1)
for _k in PASSIVES:       # 0.46.29: Meditation (level 50) is in every pool; it is the only source of mana regeneration other than potions
 PASSIVES[_k].append(_P("Meditation",50,{},"Your mana regenerates on its own: 2 mana a second, faster with regeneration bonuses"))
CLASSES=("Warrior","Ranger","Mage","Cleric","Rogue","Paladin","Shaman","Druid","Berserker","Warlock","Monk","Juggernaut")
PURE_TANKS=("Juggernaut",)

COLD_WORDS=("Frost","Freeze","Avalanche","Blizzard","Glacial")
FIRE_WORDS=("Ignite","Flame","Lava","Meteor","Rain of Fire","Holy Fire","Sunburst","Inferno","Searing","Burn")
ELEC_WORDS=("Lightning","Chain Tempest","Thunderstorm","Thunder Volley","Stormstrike")
EARTH_WORDS=("Earth","Seismic")
SHADOW_WORDS=("Shadow Bolt","Corruption","Doom","Drain Life","Chaos Bolt","Touch of Death","Abyssal Collapse","Rain of Ruin")
HOLY_WORDS=("Holy","Smite","Judgement","Penance","Crusader","Consecration","Exorcism","Divine","Templar","Hammer of","Hammerfall","Radiant","Wings of Retribution","Avenger","Final Reckoning","Sentence","Wrath of Heaven")
POISON_WORDS=("Sting","Thorns","Moonfire","Entangling","Nature's Drain")
VULN_PCT=.10;VULN_SECS=4;HOLY_LEECH=.06;POISON_SECS=4;POISON_FRAC=.08       # 0.46.39: modest class flavour - shadow withers, holy leeches, poison lingers
SLOW_SECS=4;SLOW_FACTOR=.5;BURN_SECS=3;BURN_FRAC=.12      # 0.46.37: cold spells slow, fire spells ignite
SHOCK_CHANCE=.30;SHOCK_STUN=1;ARC_FRAC=.4;ARC_RANGE=4.0;EARTH_SLOW_SECS=2     # electric spells shock and arc, earth spells stagger
def spell_element(a):
 """'cold', 'fire' or '' - decided by the spell's name."""
 n=a["name"] if isinstance(a,dict) else str(a)
 if a["kind"] in ("heal","hot","shield","armor","dodge","sprint","vanish") if isinstance(a,dict) else False:return ""
 if any(w in n for w in COLD_WORDS):return "cold"
 if any(w in n for w in FIRE_WORDS):return "fire"
 if any(w in n for w in ELEC_WORDS):return "electric"
 if any(w in n for w in EARTH_WORDS):return "earth"
 if any(w in n for w in SHADOW_WORDS):return "shadow"
 if any(w in n for w in HOLY_WORDS):return "holy"
 if any(w in n for w in POISON_WORDS):return "poison"
 return ""
def describe_ability(a):
 t=_describe_base(a);el=spell_element(a);k=a["kind"];p=a["power"]
 if el=="cold":
  t=t.replace("stuns for","freezes solid for").replace("stunning for","freezing solid for")
  t+=f" Cold: chills the target, slowing it by {int((1-SLOW_FACTOR)*100)}% for {SLOW_SECS}s."
 elif el=="fire":
  t+=(f" Fire: burns the target." if k=="dot" else f" Fire: ignites the target, burning it for {int(p*BURN_FRAC*100)}% weapon damage a second for {BURN_SECS}s.")
 elif el=="electric":
  t+=f" Electric: {int(SHOCK_CHANCE*100)}% chance to shock the target stiff for {SHOCK_STUN}s, and the charge arcs to a nearby enemy for {int(ARC_FRAC*100)}% damage."
 elif el=="earth":
  t+=f" Earth: staggers the target, slowing it by {int((1-SLOW_FACTOR)*100)}% for {EARTH_SLOW_SECS}s."
 elif el=="shadow":
  t+=f" Shadow: withers the target, so it takes {int(VULN_PCT*100)}% more damage from you for {VULN_SECS}s."
 elif el=="holy":
  t+=f" Holy: heals you for {int(HOLY_LEECH*100)}% of the damage it deals."
 elif el=="poison":
  t+=f" Poison: poisons the target for {int(POISON_FRAC*100)}% weapon damage a second for {POISON_SECS}s."
 return t
def _describe_base(a):
 k=a["kind"];p=a["power"]
 t={"damage":f"Strikes for {int(p*100)}% weapon damage.",
    "aoe":f"Hits the target and everything next to it for {int(p*100)}% weapon damage.",
    "nova":f"Hits every enemy within {a['range']:g} yards for {int(p*100)}% weapon damage"+(f" and freezes them for {a['stun']}s." if a.get('stun') else "."),
    "dot":f"Deals {int(p*100)}% weapon damage every second for {a.get('dur',0)}s.",
    "stun":f"Hits for {int(p*100)}% weapon damage and stuns for {a.get('stun',0)}s.",
    "charge":f"Leaps to the target and hits for {int(p*100)}% weapon damage"+(f", stunning for {a['stun']}s." if a.get('stun') else "."),
    "multi":f"{a.get('hits',3)} rapid hits of {int(p*100)}% weapon damage each.",
    "lifesteal":f"Hits for {int(p*100)}% weapon damage and heals you for {int(a.get('steal',.5)*100)}% of it.",
    "execute":f"Hits for {int(p*100)}% weapon damage, 65% more against targets under 35% health.",
    "heal":f"Heals you for {int(p*100)}% of your maximum health.",
    "hot":f"Heals {int(p*100)}% of your maximum health every second for {a.get('dur',0)}s.",
    "shield":f"Absorbs damage equal to {int(p*100)}% of your maximum health for {a.get('dur',0)}s.",
    "armor":f"Reduces damage taken by {int(p*100)}% for {a.get('dur',0)}s.",
    "dodge":f"{int(p*100)}% chance to dodge attacks for {a.get('dur',0)}s.",
    "sprint":f"Run {int(p*100)}% faster for {a.get('dur',0)}s.",
    "vanish":f"Drops all threat: monsters fighting you lose track of you, and none notice you for {a.get('dur',0)}s."}
 return t.get(k,"")
_make_capstones()
RARITY_POWER={"Common":0,"Uncommon":8,"Rare":18,"Epic":30,"Elite":44,"Legendary":62,"Set":50,"Mythic":95}

@dataclass
class Actor:
 id:int; name:str; faction:str; level:int; x:float; y:float; hp:int; maxhp:int; kind:str; role:str=""; state:str="wander"; target:int=-1; home:str=""; timer:int=0; party:int=0; kills:int=0; deaths:int=0
@dataclass
class Quest:
 id:int; name:str; area:str; level:int; reward:int; xp:int; target:str; amount:int; progress:int=0; owner:int=0
@dataclass
class Town:
 id:int; name:str; area:str; x:float; y:float; faction:str; population:int; prosperity:int
@dataclass
class Dungeon:
 id:int; name:str; area:str; x:float; y:float; level:int; boss:str; boss_hp:int; active:int=0; party:int=0; cooldown:int=0; size:int=5; kind:str="dungeon"

class World(MountMixin, SystemsMixin, PeopleMixin, GatherMixin, FactionMixin, JewelMixin, BonusMixin, PartyUpMixin, MarketplaceMixin):
 def __init__(self):
  self.db=sqlite3.connect(DB,timeout=10)
  self.db.row_factory=sqlite3.Row
  self.db.execute("PRAGMA journal_mode=WAL"); self.db.execute("PRAGMA synchronous=NORMAL"); self.db.execute("PRAGMA foreign_keys=ON")
  self._schema()
  self.rng=random.Random(self._seed())
  self.tick=int(self._meta("tick","0")); self.day=int(self._meta("day","1"))
  self.actors=[]; self.quests=[]; self.towns=[]; self.dungeons=[]; self.parties={}
  self.player_pvp=None; self.inst=None; self._cur_ab=None; self.open_ui=None; self.city_raid=None; self.raid_call=None
  self.events=EventList(); self.last_save=time.monotonic()
  self.player=self._load_player()
  if self.player["y"]>=WORLD_H:self.player["x"],self.player["y"]=20.0,15.0
  self.player["mana"]=self.max_mana()
  self.ability_cooldowns={k:0 for k in ABILITY_KEYS}
  self.last_combat_tick=-999; self.hits_taken=[]
  self.buffs={}; self.mstatus={}; self.player_hits=[]; self.kill_events=[]; self.charge_events=[]
  self._ensure_player_progression()

  self._load_world()
  self._people_init()
  self.by_id={a.id:a for a in self.actors}   # _people_init can add adventurers
  self.apply_dead_leaders()
 def level_bracket(self, level=None):
  level=int(level if level is not None else self.player["level"])
  level=max(1,min(LEVEL_CAP,level))
  for lo,hi in LEVEL_BRACKETS:
   if lo<=level<=hi:return (lo,hi)
  return LEVEL_BRACKETS[-1]
 def bracket_label(self, level=None):
  lo,hi=self.level_bracket(level);return f"{lo}-{hi}"
 def _seed(self):
  v=self.__dict__.get("_seed_v")
  if v is not None:return v
  v=self._meta("seed",None)
  if v is None:
   v=str(random.SystemRandom().randint(1,2**31-1)); self._setmeta("seed",v); self.db.commit()
  self._seed_v=int(v);return self._seed_v
 def _meta(self,k,default=None):
  r=self.db.execute("SELECT v FROM meta WHERE k=?",(k,)).fetchone()
  return r["v"] if r else default
 def _jmeta(self,k,default,kind=dict):
  """0.46.42: saved JSON of the expected type, or a fresh copy of the default - a damaged or hand-edited save can never crash a lookup."""
  import json
  try:v=json.loads(self._meta(k,"") or "")
  except Exception:return kind() if default is None else (default.copy() if hasattr(default,"copy") else default)
  return v if isinstance(v,kind) else (kind() if default is None else (default.copy() if hasattr(default,"copy") else default))
 def _setmeta(self,k,v): self.db.execute("INSERT INTO meta(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",(k,str(v)))
 def _schema(self):
  self.db.executescript("""
  CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS player(name TEXT PRIMARY KEY,faction TEXT,level INTEGER,xp INTEGER,gold INTEGER,x REAL,y REAL,hp INTEGER,maxhp INTEGER,kills INTEGER,deaths INTEGER,weapon INTEGER,armor INTEGER,spell INTEGER, class TEXT DEFAULT 'Warrior');
  CREATE TABLE IF NOT EXISTS actors(id INTEGER PRIMARY KEY,name TEXT,faction TEXT,level INTEGER,x REAL,y REAL,hp INTEGER,maxhp INTEGER,kind TEXT,role TEXT,state TEXT,target INTEGER,home TEXT,timer INTEGER,party INTEGER,kills INTEGER,deaths INTEGER);
  CREATE TABLE IF NOT EXISTS quests(id INTEGER PRIMARY KEY,name TEXT,area TEXT,level INTEGER,reward INTEGER,xp INTEGER,target TEXT,amount INTEGER,progress INTEGER,owner INTEGER);
  CREATE TABLE IF NOT EXISTS towns(id INTEGER PRIMARY KEY,name TEXT,area TEXT,x REAL,y REAL,faction TEXT,population INTEGER,prosperity INTEGER);
  CREATE TABLE IF NOT EXISTS dungeons(id INTEGER PRIMARY KEY,name TEXT,area TEXT,x REAL,y REAL,level INTEGER,boss TEXT,boss_hp INTEGER,active INTEGER,party INTEGER,cooldown INTEGER,size INTEGER DEFAULT 5,kind TEXT DEFAULT 'dungeon');
  CREATE TABLE IF NOT EXISTS pvp_matches(id INTEGER PRIMARY KEY,mode INTEGER,state TEXT,blue TEXT,red TEXT,round INTEGER,winner TEXT,reward INTEGER);
  CREATE TABLE IF NOT EXISTS parties(id INTEGER PRIMARY KEY,leader INTEGER,role_count TEXT,state TEXT,dungeon INTEGER);
  CREATE TABLE IF NOT EXISTS inventory(actor_id INTEGER,item TEXT,qty INTEGER,PRIMARY KEY(actor_id,item));
  CREATE TABLE IF NOT EXISTS player_gear(id INTEGER PRIMARY KEY AUTOINCREMENT,slot TEXT NOT NULL,item TEXT NOT NULL,rarity TEXT NOT NULL,power INTEGER NOT NULL,source TEXT NOT NULL,owned_at INTEGER NOT NULL, class TEXT DEFAULT '', set_name TEXT DEFAULT '', equipped INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS player_currency(name TEXT PRIMARY KEY,pvp_points INTEGER NOT NULL DEFAULT 0,raid_tokens INTEGER NOT NULL DEFAULT 0,legendary_essence INTEGER NOT NULL DEFAULT 0);
  CREATE INDEX IF NOT EXISTS idx_actors_area ON actors(home);
  CREATE INDEX IF NOT EXISTS idx_actors_kind ON actors(kind);
  CREATE TABLE IF NOT EXISTS ground_loot(id INTEGER PRIMARY KEY AUTOINCREMENT,x REAL,y REAL,item TEXT NOT NULL,qty INTEGER NOT NULL,rarity TEXT NOT NULL,power INTEGER NOT NULL,slot TEXT NOT NULL,source TEXT NOT NULL,expires INTEGER NOT NULL,class TEXT DEFAULT '');
  CREATE TABLE IF NOT EXISTS pvp_profile(name TEXT PRIMARY KEY,season INTEGER NOT NULL,rating INTEGER NOT NULL DEFAULT 1000,wins INTEGER NOT NULL DEFAULT 0,losses INTEGER NOT NULL DEFAULT 0,rank TEXT NOT NULL DEFAULT 'Bronze');
  CREATE INDEX IF NOT EXISTS idx_ground_loot_expiry ON ground_loot(expires);
  """)
  pcols={r["name"] for r in self.db.execute("PRAGMA table_info(player)").fetchall()}
  if "class" not in pcols:self.db.execute("ALTER TABLE player ADD COLUMN class TEXT DEFAULT 'Warrior'")
  if "spec" not in pcols:self.db.execute("ALTER TABLE player ADD COLUMN spec TEXT DEFAULT ''")
  gcols={r["name"] for r in self.db.execute("PRAGMA table_info(player_gear)").fetchall()}
  for col,typ in (("class","TEXT DEFAULT ''"),("set_name","TEXT DEFAULT ''"),("equipped","INTEGER DEFAULT 0"),("vault","INTEGER DEFAULT 0")):
   if col not in gcols:self.db.execute(f"ALTER TABLE player_gear ADD COLUMN {col} {typ}")
  self._jewel_schema()                  # 0.39: sockets and jewels on gear
  self._bonus_schema()                  # 0.46: Magic Shop bonuses on gear
  ccols={r["name"] for r in self.db.execute("PRAGMA table_info(player_currency)").fetchall()}
  if "vault_gold" not in ccols:self.db.execute("ALTER TABLE player_currency ADD COLUMN vault_gold INTEGER NOT NULL DEFAULT 0")   # 0.35: Banker vault
  # 0.4.0 compatibility: retain existing actors/quests instead of silently resetting progress.
  acols={r["name"] for r in self.db.execute("PRAGMA table_info(actors)").fetchall()}
  for col,typ in (("party","INTEGER DEFAULT 0"),("kills","INTEGER DEFAULT 0"),("deaths","INTEGER DEFAULT 0")):
   if col not in acols:self.db.execute(f"ALTER TABLE actors ADD COLUMN {col} {typ}")
  qcols={r["name"] for r in self.db.execute("PRAGMA table_info(quests)").fetchall()}
  for col,typ in (("progress","INTEGER DEFAULT 0"),("owner","INTEGER DEFAULT 0")):
   if col not in qcols:self.db.execute(f"ALTER TABLE quests ADD COLUMN {col} {typ}")
  # 0.4.0 used actor_state; migrate it once into the new actor table.
  if not self.db.execute("SELECT 1 FROM actors LIMIT 1").fetchone():
   oldcols={r["name"] for r in self.db.execute("PRAGMA table_info(actor_state)").fetchall()}
   if oldcols:
    rows=self.db.execute("SELECT id,name,faction,level,x,y,hp,maxhp,kind,role,state,target,home,timer FROM actor_state").fetchall()
    self.db.executemany("INSERT OR IGNORE INTO actors(id,name,faction,level,x,y,hp,maxhp,kind,role,state,target,home,timer,party,kills,deaths) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      [tuple(r)+(0,0,0) for r in rows])
  dcols={r["name"] for r in self.db.execute("PRAGMA table_info(dungeons)").fetchall()}
  for col,typ in (("size","INTEGER DEFAULT 5"),("kind","TEXT DEFAULT 'dungeon'")):
   if col not in dcols:self.db.execute(f"ALTER TABLE dungeons ADD COLUMN {col} {typ}")
  # Normalize old 0.8/0.9 dungeon levels into the new fixed zone bands.
  # This is idempotent and preserves dungeon identity/progress.
  for d in self.db.execute("SELECT id,area,kind FROM dungeons").fetchall():
   ar=next((a for a in AREAS if a[0]==d["area"]),None)
   if ar:
    lo,hi=ar[6],ar[7]
    # Two normal dungeons occupy the same zone band; raids use the zone's
    # upper end so their minimum-level gate remains deterministic.
    lvl=hi if d["kind"]=="raid" else lo
    self.db.execute("UPDATE dungeons SET level=? WHERE id=?",(lvl,d["id"]))
  self.db.commit()
  self.db.commit()
 def _load_player(self):
  r=self.db.execute("SELECT * FROM player LIMIT 1").fetchone()
  if r:
   p=dict(r); p.setdefault("class","Warrior"); return p
  p={"name":"Adventurer","faction":"Alliance","level":1,"xp":0,"gold":250,"x":20.0,"y":15.0,"hp":108,"maxhp":108,"kills":0,"deaths":0,"weapon":1,"armor":1,"spell":1,"class":"Warrior","mana":100}
  self.db.execute("""INSERT INTO player(name,faction,level,xp,gold,x,y,hp,maxhp,kills,deaths,weapon,armor,spell,class) VALUES(:name,:faction,:level,:xp,:gold,:x,:y,:hp,:maxhp,:kills,:deaths,:weapon,:armor,:spell,:class)""",p); self.db.commit(); return p
 def _ensure_player_progression(self):
  self._ensure_potions()
  self.db.execute("INSERT OR IGNORE INTO player_currency(name,pvp_points,raid_tokens,legendary_essence) VALUES(?,0,0,0)",(self.player["name"],))
  self.db.execute("INSERT OR IGNORE INTO pvp_profile(name,season,rating,wins,losses,rank) VALUES(?,?,?,?,?,?)",(self.player["name"],1,1000,0,0,"Bronze"))
  self.db.commit()
 def _currency(self):
  return dict(self.db.execute("SELECT * FROM player_currency WHERE name=?",(self.player["name"],)).fetchone())
 def _add_currency(self,pvp=0,raid=0,essence=0):
  self.db.execute("UPDATE player_currency SET pvp_points=pvp_points+?,raid_tokens=raid_tokens+?,legendary_essence=legendary_essence+? WHERE name=?",(pvp,raid,essence,self.player["name"]));self.db.commit()
 def _grant_gear(self,item,slot,rarity,power,source,class_name="",set_name="",affix=None):
  import json as _j
  self.db.execute("INSERT INTO player_gear(slot,item,rarity,power,source,owned_at,class,set_name,equipped,sockets,gems,affix) VALUES(?,?,?,?,?,?,?,?,0,0,'[]',?)",(slot,item,rarity,power,source,self.tick,class_name,set_name,_j.dumps(affix) if affix else ""))
  self.db.commit()
  self.player["weapon"] = max(self.player["weapon"],power) if slot=="weapon" else self.player["weapon"]
  self.player["armor"] = max(self.player["armor"],power) if slot=="armor" else self.player["armor"]
  return f"{rarity} gear acquired: {item} ({slot}, power {power})."
 def gear(self):
  rows=self.db.execute("SELECT slot,item,rarity,power,source,class,set_name,equipped FROM player_gear ORDER BY power DESC,id DESC").fetchall()
  c=self._currency()
  if not rows:return f"No special gear yet. PvP Points: {c['pvp_points']} | Raid Tokens: {c['raid_tokens']} | Legendary Essence: {c['legendary_essence']}"
  return " | ".join(f"{r['rarity']} {r['item']} [{r['slot']}] P{r['power']}" for r in rows[:8]) + f" | PvP {c['pvp_points']} | Raid Tokens {c['raid_tokens']} | Essence {c['legendary_essence']}"
 def _ensure_potions(self):
  r=self.db.execute("SELECT qty FROM inventory WHERE actor_id=0 AND item='Health Potion'").fetchone()
  if not r:
   self.db.execute("INSERT INTO inventory(actor_id,item,qty) VALUES(0,'Health Potion',3)")
   self.db.commit()

 def use_potion(self):
  self._ensure_potions()
  r=self.db.execute("SELECT qty FROM inventory WHERE actor_id=0 AND item='Health Potion'").fetchone()
  if not r or r["qty"]<=0:return "No Health Potions."
  if self.player["hp"]>=self._effective_maxhp():return "Your health is already full."
  heal=max(25,self._effective_maxhp()//3);old=self.player["hp"]
  self.player["hp"]=min(self._effective_maxhp(),self.player["hp"]+heal)
  self.db.execute("UPDATE inventory SET qty=qty-1 WHERE actor_id=0 AND item='Health Potion'")
  self._save_player_fast()
  return f"Health Potion: restored {self.player['hp']-old} HP."

 def _effective_maxhp(self):
  sb=self._set_bonus()
  return int((self.player["maxhp"]+8*(self.stats()["vit"]+self._bread()))*(sb["maxhp"] if sb else 1.0)*(1+self.passive_fx("hp_pct")))

 def max_mana(self):
  """0.46.31: mana grows with level like health does: 100 at level 1, +6 every level."""
  return 100+6*(max(1,self.player["level"])-1)

 def _set_bonus(self):
  """0.46: sets are six pieces with 2/4/6-piece bonuses (bonuses.py); they reach your stats through gear_stats()."""
  return self.bonus_summary()

 def class_name(self):
  c=self.player.get("class","Warrior") or "Warrior"
  return c if c in CLASSES else "Warrior"
 def spec_name(self):
  c=self.class_name()
  if c not in HYBRID_SPECS:return ""
  s=self.player.get("spec") or ""
  names=[n for n,_ in HYBRID_SPECS[c]]
  return s if s in names else names[2]
 def spec_role(self):
  c=self.class_name();s=self.spec_name()
  if c in PURE_TANKS:return "Tank"
  if c not in HYBRID_SPECS:return "DPS"   # 0.19: pure damage classes fill a DPS slot in groups
  return next((r for n,r in HYBRID_SPECS.get(c,()) if n==s),"")
 def skill_key(self):
  c=self.class_name()
  return f"{c}:{self.spec_name()}" if c in HYBRID_SPECS else c
 def set_spec(self,spec):
  c=self.class_name()
  if c not in HYBRID_SPECS:return f"{c} has no specializations."
  if spec not in [n for n,_ in HYBRID_SPECS[c]]:return "Unknown specialization."
  self.player["spec"]=spec;self.ability_cooldowns={k:0 for k in ABILITY_KEYS};self.buffs={}
  self._save_player_fast()
  return f"Specialization: {spec} ({self.spec_role()}). Your skills changed."

 def set_class(self,class_name,spec=None):
  if class_name not in CLASSES:return "Unknown class."
  self.player["class"]=class_name
  if class_name in HYBRID_SPECS:
   names=[n for n,_ in HYBRID_SPECS[class_name]]
   self.player["spec"]=spec if spec in names else (self.player.get("spec") if self.player.get("spec") in names else names[2])
  self.player["mana"]=self.max_mana()
  self.ability_cooldowns={k:0 for k in ABILITY_KEYS};self.buffs={}
  self._save_player_fast()
  return f"Class selected: {class_name}. Your 6 attack and 4 defensive skills are on the hotbar (keys 1-0)."

 # ---- 0.11.0 combat: passives, buffs, crits, debuffs ----
 def passive_fx(self,key):
  v=sum(p["fx"].get(key,0) for p in self.equipped_passives())
  st=self.stats();bb=self._bread()
  if key=="dmg_pct":v+=(st["str"]+bb)*.008
  elif key=="crit":v+=(st["agi"]+bb)*.0025
  elif key=="speed":v+=(st["agi"]+bb)*.002
  elif key=="mana_regen":
   v+=(st["int"]+bb)*.01
   if self._buff("wine"):v+=.4
   mr=self._buff("mreg")
   if mr:v+=mr["value"]
  elif key=="hp_pct":
   if self._buff("wine"):v+=.10
   hb=self._buff("hpmax")
   if hb:v+=hb["value"]
  if key in ("dodge","armor_pct","mana_regen","hp_pct","dmg_pct","speed","heal_pct"):v+=self.gear_stats().get(key,0)      # 0.44: jewelry; 0.46: gear and set bonuses
  return v
 def _bread(self):
  b=self._buff("bread");return b["value"] if b else 0
 # ---- 0.28 character build: stat points (3 per level) and spell ranks (1 per level) ----
 def _build(self):
  import json
  b=getattr(self,"_build_c",None)
  if b is None:
   b=self._jmeta("build",None)
   if not isinstance(b.get("s"),dict):b["s"]={}
   if not isinstance(b.get("r"),dict):b["r"]={}
   b.setdefault("s",{});b.setdefault("r",{})
   for k in STAT_KEYS:b["s"].setdefault(k,0)
   self._build_c=b
  return b
 def _build_save(self):
  import json;self._setmeta("build",json.dumps(self._build()));self.db.commit()
 def stat_points_left(self):return max(0,3*(self.player["level"]-1)-sum(self._build()["s"].values()))
 def rank_points_left(self):return max(0,self.player["level"]-1-sum(v-1 for v in self._build()["r"].values()))
 def ability_rank(self,name):return max(1,min(MAX_RANK,self._build()["r"].get(name,1)))
 # ---- 0.38 Skill Shop: points are spent there, and every upgrade also costs gold ----
 MAGIC_SHOP_MSG="Visit a Skill Shop (in every town) to spend points, choose passives or arrange your hotbar."
 def at_magic_shop(self):return self._near_station("magic",7.0)
 def stat_cost(self,n=1):
  """Gold for the next n stat points: rises slowly with the points already spent."""
  done=sum(self._build()["s"].values());return sum(4+(done+i)//2 for i in range(n))
 def rank_cost(self,ab,r):
  """Gold to raise a skill from rank r to r+1."""
  return 15*r*r+3*ab["unlock"]
 def passive_cost(self):return 10*self.player["level"]
 def reset_cost(self):return 20*self.player["level"]
 def _pay(self,cost):
  if self.player["gold"]<cost:return False
  self.player["gold"]-=cost;self._save_player_fast();return True
 def add_stat(self,key,n=1):
  if key not in STAT_KEYS:return "Unknown stat."
  if not self.at_magic_shop():return self.MAGIC_SHOP_MSG
  n=min(n,self.stat_points_left())
  if n<=0:return "No stat points to spend."
  cost=self.stat_cost(n)
  if not self._pay(cost):return f"{n} {STAT_INFO[key][0]} costs {cost} gold."
  self._build()["s"][key]+=n;self._build_save()
  return f"{STAT_INFO[key][0]} +{n} ({cost}g)."
 def rank_up(self,name):
  ab=next((a for a in ABILITIES[self.skill_key()] if a["name"]==name),None)
  if not ab:return "Unknown spell."
  if self.player["level"]<ab["unlock"]:return f"{name} unlocks at level {ab['unlock']}."
  r=self.ability_rank(name)
  if r>=MAX_RANK:return f"{name} is already at maximum rank."
  if not self.at_magic_shop():return self.MAGIC_SHOP_MSG
  if self.rank_points_left()<1:return "No spell points to spend."
  cost=self.rank_cost(ab,r)
  if not self._pay(cost):return f"Rank {r+1} {name} costs {cost} gold."
  self._build()["r"][name]=r+1;self._build_save()
  return f"{name} is now rank {r+1} ({cost}g)."
 def reset_build(self):
  if not self.at_magic_shop():return self.MAGIC_SHOP_MSG
  cost=self.reset_cost()
  if not self._pay(cost):return f"Respeccing costs {cost} gold."
  self._build_c={"s":{k:0 for k in STAT_KEYS},"r":{}};self._build_save()
  self.ability_cooldowns={k:0 for k in ABILITY_KEYS}
  return f"Stats, spell ranks, passives and hotbar reset for {cost}g."
 # ---- 0.38 passives: a pool of 6 per class/spec; 1 slot up to level 50, 2 from level 51, 3 from level 75 ----
 def passive_slots(self):
  lv=self.player["level"]
  return 1 if lv<=50 else (2 if lv<75 else 3)
 def equipped_passives(self):
  pool=PASSIVES.get(self.skill_key(),());lvl=self.player["level"];n=self.passive_slots()
  chosen=self._build().get("pa",{}).get(self.skill_key(),[])
  out=[p for nm in chosen for p in pool if p["name"]==nm and lvl>=p["unlock"]][:n]
  for p in pool:                     # empty slots are filled with the first unlocked passives, so nobody is left with none
   if len(out)>=n:break
   if lvl>=p["unlock"] and p not in out:out.append(p)
  return out
 def equip_passive(self,name,slot=0):
  pool=PASSIVES.get(self.skill_key(),());p=next((x for x in pool if x["name"]==name),None)
  if not p:return "Unknown passive."
  if self.player["level"]<p["unlock"]:return f"{name} unlocks at level {p['unlock']}."
  n=self.passive_slots()
  cur=[x["name"] for x in self.equipped_passives()]
  if name in cur:return f"{name} is already active."
  if not self.at_magic_shop():return self.MAGIC_SHOP_MSG
  cost=self.passive_cost()
  if not self._pay(cost):return f"Changing a passive costs {cost} gold."
  slot=max(0,min(n-1,int(slot)))
  if slot<len(cur):cur[slot]=name
  else:cur.append(name)
  self._build().setdefault("pa",{})[self.skill_key()]=cur[:n];self._build_save()
  return f"Passive {slot+1}: {name} ({cost}g)."
 # ---- 0.38 hotbar: any unlocked skill in any of the 16 slots (1-0, Shift+1-6) ----
 def slot_order(self):
  """Ability index for each hotbar slot."""
  n=len(ABILITIES[self.skill_key()]);lo=self._build().get("lo",{}).get(self.skill_key())
  if isinstance(lo,list) and sorted(lo)==list(range(n)):return lo
  return list(range(n))
 def swap_slots(self,a,b):
  a,b=str(a),str(b);order=self.slot_order()
  if a not in ABILITY_KEYS or b not in ABILITY_KEYS:return "Unknown hotbar slot."
  ia,ib=ABILITY_KEYS.index(a),ABILITY_KEYS.index(b)
  if max(ia,ib)>=len(order) or ia==ib:return "Pick two different hotbar slots."
  if not self.at_magic_shop():return self.MAGIC_SHOP_MSG
  order[ia],order[ib]=order[ib],order[ia]
  self._build().setdefault("lo",{})[self.skill_key()]=order;self._build_save()
  cd=self.ability_cooldowns;cd[a],cd[b]=cd.get(b,0),cd.get(a,0)      # a cooldown follows its skill
  abl=ABILITIES[self.skill_key()]
  return f"{abl[order[ia]]['name']} and {abl[order[ib]]['name']} swapped."
 def _ranked(self,ab):
  r=self.ability_rank(ab["name"]);st=self.stats();a=dict(ab)
  a["rank"]=r
  if r>1:     # ranks 2-5: +10% power, -4% cooldown each; ranks 6-10 (0.38): +6% power, -2% cooldown each
   a["power"]=ab["power"]*(1+.10*min(4,r-1)+.06*max(0,r-5));a["cd"]=max(1,ab["cd"]*(1-.04*min(4,r-1)-.02*max(0,r-5)))
  if ab["cat"]=="defense" and ab["kind"] in ("heal","hot","shield"):a["power"]=a["power"]*(1+.005*st["int"])
  if ab["mana"]:a["mana"]=max(1,int(round(ab["mana"]*(1-min(.4,.004*st["int"])))))
  return a
 def _buff(self,name):
  b=self.buffs.get(name)
  if b and b["until"]>self.tick:return b
  return None
 def crit_chance(self):
  cb=self._buff("crit")
  return BASE_CRIT+self.passive_fx("crit")+self.gear_stats()["crit"]+(cb["value"] if cb else 0)
 def move_speed(self):
  sp=1+self.passive_fx("speed"); b=self._buff("sprint"); hb=self._buff("haste")
  return (sp+(b["value"] if b else 0)+(hb["value"] if hb else 0))*(1+self.mount_speed())
 def _ability_damage(self, ability):
  base=max(4,self.player["level"]*2 + self.player["weapon"]*5); sb=self._set_bonus(); base=int(base*(sb["damage"] if sb else 1.0))
  mb=self._buff("might");base=base*(1+self.passive_fx("dmg_pct")+(mb["value"] if mb else 0))
  return max(1,int(base*ability["power"])+self.rng.randint(0,max(2,self.player["level"]//2)))
 def ability_damage_est(self,ab):
  """0.46.37: what one hit of this skill does to you right now (for tooltips; no random roll)."""
  base=max(4,self.player["level"]*2 + self.player["weapon"]*5); sb=self._set_bonus(); base=int(base*(sb["damage"] if sb else 1.0))
  mb=self._buff("might");base=base*(1+self.passive_fx("dmg_pct")+(mb["value"] if mb else 0))
  return max(1,int(base*ab["power"]))
 def _at_city_raid(self,x,y):
  """0.38: city raids are open war - kills in and around the besieged city never make you an outlaw
  (battlegrounds, dungeons and raids are instances and never do either)."""
  r=getattr(self,"city_raid",None)
  return bool(r) and (x-r["x"])**2+(y-r["y"])**2<(TOWN_WALL_R+40)**2
 def _player_kill(self,t):
  if t.kind=="imob" and self.inst:
   self.inst.player_killed(t);return 0
  p=self.player;x,y,lvl,name=t.x,t.y,t.level,t.name
  if t.kind=="monster":self.party_share_xp(lvl)      # 0.46.27: companions earn XP too
  if t.kind=="npc" and t.role in LEADER_ROLES:      # 0.39: a quest giver or ruler slain (back in 30 minutes)
   self.leader_slain(t);gold=lvl*30;p["gold"]+=gold;p["xp"]+=lvl*60;self._level_check()
   tw_=self._town_for_actor(t)
   if tw_ is not None and p["level"]>=lvl+15 and not self.inst:       # 0.42: a hero far above the town's band wipes it out alone
    self.town_falls(tw_);bonus=lvl*40;p["gold"]+=bonus;gold+=bonus;self.events.append(f"{tw_.name} has been wiped out by {p['name']}! Its leaders are all slain (+{bonus} gold).")
   if not self._at_city_raid(x,y):self._set_outlaw(True)
   self.kill_events.append({"id":t.id,"x":x,"y":y,"gold":gold,"name":name.split(" #")[0]})
   self._save_player_fast();return gold
  if t.kind=="npc":            # 0.38: a guard beaten by an outlaw falls back and recovers instead of dying
   t.hp=t.maxhp;t.down_until=self.tick+(2400 if (not self.inst and p["level"]>=lvl+15) else 240)    # 0.42: a hero far above the town's band keeps its guards down for 10 minutes
   self.kill_events.append({"id":t.id,"x":x,"y":y,"gold":0,"name":name.split(" #")[0]})
   if t.down_until-self.tick>240:self.events.append(f"{name} is cut down.");return 0
   self.events.append(f"{name} falls back, wounded.");return 0
  if t.kind=="adventurer" and t.faction!=p["faction"] and not self.inst and not self._at_city_raid(x,y):self._set_outlaw(True)
  cr_=getattr(self,"city_raid",None)
  if cr_ and (t.role=="raider" or (t.role=="watch" and (t.x-cr_["x"])**2+(t.y-cr_["y"])**2<(TOWN_WALL_R+12)**2)):cr_["mine"]+=1
  if t.kind=="monster" and self.area(x,y)[7]>=91:self.mythic_event("zonekill")
  mult=3 if (t.kind=="monster" and name.startswith("Elite ")) else 1
  p["kills"]+=1;reward=int(lvl*self.rng.randint(1,3)*mult*(1+lvl/25.0))       # 0.35.1: gold is a grind; 0.44.19: higher zones pay much more (1.0x at lvl 1, 5x at lvl 100)
  p["gold"]+=reward
  # 0.44.17: monsters pay XP again (the line above used to swallow it in its own comment).
  # 0.44.18: XP follows the level gap between you and the monster - a level 10 hero gets next to nothing for a level 1 monster,
  # a monster above your level pays a bonus - so zones level you up and then it is time to move on.
  if t.kind=="monster" and not self.inst:
   gap_=p["level"]-lvl
   fac_=1+.1*min(5,-gap_) if gap_<0 else 1.0 if gap_<=2 else (.8,.6,.4,.25,.15,.08)[min(gap_-3,5)] if gap_<=8 else .03
   p["xp"]+=max(1,int((20+lvl*3)*mult*fac_))
   z_=self.area(x,y)
   if fac_<=.25 and p["level"]>=z_[7] and self.tick-getattr(self,"_outgrown_t",-9999)>900 and p["level"]<LEVEL_CAP:
    self._outgrown_t=self.tick;nxt_=next((a_[0] for a_ in AREAS if a_[6]==z_[7]+1 and a_[5] in (p["faction"],"Neutral")),None)
    self.events.append(f"You have outgrown {z_[0]} - monsters here give little XP now."+(f" Time to move on to {nxt_}." if nxt_ else ""))
  self.mstatus.pop(t.id,None)
  self._record_kill(t,Actor(-1,p["name"],p["faction"],p["level"],p["x"],p["y"],1,1,"player",self.class_name()))
  self._drop_loot(lvl,x,y,name)
  if mult>1:
   self._drop_loot(lvl+8,x+.4,y+.2,name);self.events.append(f"You slew {name.split(' #')[0]}! Triple reward and bonus loot.")
  self.kill_events.append({"id":t.id,"x":x,"y":y,"gold":reward,"name":name.split(" #")[0]})
  if t.kind=="monster":
   sp=mkind(name);self.quest_event("kill",sp,self.area(x,y)[0],elite=mult>1);self.roll_mats(sp,lvl,mult>1);self.add_carcass(name,x,y,lvl,mult>1)
  self._level_check()
  return reward
 def _hit(self,t,dmg,can_crit=True,kind="hit"):
  """Deal dmg to t from the player. Returns (damage, crit, killed)."""
  if t.hp<=0:return 0,False,False
  if t.kind=="imob" and self.inst and not self.inst.pre_hit(t):return 0,False,False
  crit=can_crit and self.rng.random()<self.crit_chance()
  if crit:dmg=int(dmg*1.75)
  vs_=self.mstatus.get(t.id)
  if vs_ and vs_.get("vuln",0)>self.tick:dmg=dmg*(1+VULN_PCT)
  dmg=max(1,int(dmg));t.hp-=dmg;self._aggro(t)
  if t.kind=="npc" and t.role in LEADER_ROLES:self.leader_hit(t)
  self.buffs.pop("stealth",None)
  self.player_hits.append({"id":t.id,"dmg":dmg,"crit":crit,"kind":kind})
  if t.kind=="imob" and self.inst:self.inst.on_player_hit(t,self._cur_ab)
  if t.kind=="adventurer":
   if t.hp<=0 and self._duel_guard(t):return dmg,crit,False
   self._person_hit_by_player(t)
  if t.hp<=0:
   self._player_kill(t);return dmg,crit,True
  return dmg,crit,False
 def _heal(self,amount):
  p=self.player;mx=self._effective_maxhp();old=p["hp"]
  p["hp"]=min(mx,p["hp"]+int(amount*(1+self.passive_fx("heal_pct"))))
  return p["hp"]-old
 def _stunned(self,a):
  st=self.mstatus.get(a.id)
  return bool(st and st.get("stun",0)>self.tick)
 def _enemies(self):
  f=self.player["faction"]
  return [a for a in self.actors if (a.kind in ("imob",) or (a.kind=="monster" and a.faction!=f) or self._hostile_adv(a) or self._guard_hostile(a) or self.leader_attackable(a)) and a.hp>0]

 def use_ability(self, slot):
  slot=str(slot)
  if getattr(self.inst,"player_down",None) and self.inst.player_down():return "You are dead - wait to respawn."
  if slot not in ABILITY_KEYS:return "Choose a skill key 1-0 (Shift+1-6 for capstones)."
  dm=self._dismount_for_action()
  if dm:return dm
  abilities=ABILITIES[self.skill_key()];order=self.slot_order()
  ai=ABILITY_KEYS.index(slot)
  if ai>=len(order):return "No skill in that slot."
  ab=self._ranked(abilities[order[ai]])
  p=self.player;self._cur_ab=ab
  if p["level"]<ab["unlock"]:return f"{ab['name']} unlocks at level {ab['unlock']}."
  if self.ability_cooldowns[slot]>0:return f"{ab['name']} is not ready yet ({(self.ability_cooldowns[slot]+3)//4}s)."
  if p["mana"]<ab["mana"]:return f"Not enough mana for {ab['name']}."
  k=ab["kind"];mx=self._effective_maxhp();dur=int(ab.get("dur",0)*4)
  if ab["cat"]=="defense":
   p["mana"]-=ab["mana"];self.ability_cooldowns[slot]=int(ab["cd"]*4)
   if k=="heal":
    r=self._heal(mx*ab["power"])
    if self.inst:self.inst.heal_allies(ab["power"],1.0)
    self._save_player_fast();return f"{ab['name']}: restored {r} HP."
   if k=="hot":
    self.buffs["hot"]={"name":ab["name"],"kind":k,"until":self.tick+dur,"value":ab["power"],"next":self.tick+4}
    return f"{ab['name']}: healing over {ab['dur']}s."
   if k=="shield":
    self.buffs["shield"]={"name":ab["name"],"kind":k,"until":self.tick+dur,"absorb":int(mx*ab["power"]),"max":int(mx*ab["power"])}
    return f"{ab['name']}: absorbs the next {int(mx*ab['power'])} damage."
   if k in ("armor","dodge","sprint"):
    self.buffs[k]={"name":ab["name"],"kind":k,"until":self.tick+dur,"value":ab["power"]}
    return f"{ab['name']} for {ab['dur']}s."
   if k=="vanish":
    for a in self.actors:
     if a.target==-2:a.target=-1;a.state="wander"
    self.buffs["stealth"]={"name":ab["name"],"kind":k,"until":self.tick+dur,"value":1}
    self.last_combat_tick=self.tick-100
    return f"{ab['name']}: you slip out of sight."
   return ab["name"]
  enemies=self._enemies()
  if k=="nova":
   victims=[a for a in enemies if (a.x-p["x"])**2+(a.y-p["y"])**2<=ab["range"]**2][:12]
   if not victims:return f"{ab['name']}: no enemies close enough."
   target=None
  else:
   target=None
   if getattr(self,"selected_target",None) is not None:
    target=next((a for a in enemies if a.id==self.selected_target),None)
   if target is None:
    near=[a for a in enemies if (a.x-p["x"])**2+(a.y-p["y"])**2<=ab["range"]**2]
    target=min(near,key=lambda a:(a.x-p["x"])**2+(a.y-p["y"])**2) if near else None
   if target is None:return f"{ab['name']}: no target in range."
   if math.hypot(target.x-p["x"],target.y-p["y"])>ab["range"]+.3:return f"{target.name.split(' #')[0]} is out of range for {ab['name']}."
  p["mana"]-=ab["mana"];self.ability_cooldowns[slot]=int(ab["cd"]*4)
  dmg=self._ability_damage(ab);total=0;crits=0;kills=0
  el_=spell_element(ab);arced_=set()
  def hit(t,d,**kw):
   nonlocal total,crits,kills
   d,c,kd=self._hit(t,d,**kw);total+=d;crits+=c;kills+=kd
   if el_=="holy" and k!="lifesteal" and d>0:self._heal(max(1,d*HOLY_LEECH))
   if el_ and not kd and t.hp>0:        # 0.46.37: cold slows, fire ignites
    st_=self.mstatus.setdefault(t.id,{})
    if el_=="cold":st_["slow"]=max(st_.get("slow",0),self.tick+SLOW_SECS*4)
    elif el_=="earth":st_["slow"]=max(st_.get("slow",0),self.tick+EARTH_SLOW_SECS*4)
    elif el_=="electric":
     if self.rng.random()<SHOCK_CHANCE:st_["stun"]=max(st_.get("stun",0),self.tick+SHOCK_STUN*4)
     if kw.get("kind")!="arc" and not arced_:
      arced_.add(t.id);near_=[e_ for e_ in enemies if e_ is not t and e_.hp>0 and e_.id not in arced_ and (e_.x-t.x)**2+(e_.y-t.y)**2<=ARC_RANGE**2]
      if near_:
       e_=min(near_,key=lambda q:(q.x-t.x)**2+(q.y-t.y)**2);arced_.add(e_.id);hit(e_,max(1,int(d*ARC_FRAC)),kind="arc")
    elif el_=="shadow":st_["vuln"]=max(st_.get("vuln",0),self.tick+VULN_SECS*4)
    elif el_=="poison" and not st_.get("dot"):st_["dot"]={"name":"Poisoned","until":self.tick+POISON_SECS*4,"dmg":max(1,int(self._ability_damage(ab)*POISON_FRAC)),"next":self.tick+4}
    elif el_=="fire" and not st_.get("dot"):st_["dot"]={"name":"Burning","until":self.tick+BURN_SECS*4,"dmg":max(1,int(self._ability_damage(ab)*BURN_FRAC)),"next":self.tick+4}
   return kd
  if k=="nova":
   for t in victims:
    if not hit(t,dmg,kind=k) and ab.get("stun"):self.mstatus.setdefault(t.id,{})["stun"]=self.tick+int(ab["stun"]*4)
   msg=f"{ab['name']} hits {len(victims)} enemies for {total}"
  elif k=="aoe":
   tx,ty=target.x,target.y
   splash=[a for a in enemies if a is not target and (a.x-tx)**2+(a.y-ty)**2<=2.2**2][:8]
   hit(target,dmg,kind=k)
   for a in splash:hit(a,dmg*.7,kind=k)
   msg=f"{ab['name']} hits {1+len(splash)} enemies for {total}"
  elif k=="dot":
   kd=hit(target,dmg*.5,kind=k)
   if not kd:
    st=self.mstatus.setdefault(target.id,{})
    st["dot"]={"name":ab["name"],"until":self.tick+dur,"dmg":max(1,dmg),"next":self.tick+4}
   msg=f"{ab['name']} afflicts {target.name.split(' #')[0]}"
  elif k=="stun":
   if not hit(target,dmg,kind=k):self.mstatus.setdefault(target.id,{})["stun"]=self.tick+int(ab["stun"]*4)
   msg=f"{ab['name']} stuns {target.name.split(' #')[0]}"
  elif k=="charge":
   d=math.hypot(target.x-p["x"],target.y-p["y"]) or 1
   p["x"]=target.x-(target.x-p["x"])/d*1.1;p["y"]=target.y-(target.y-p["y"])/d*1.1
   self.charge_events.append({"x":p["x"],"y":p["y"]})
   if not hit(target,dmg,kind=k) and ab.get("stun"):self.mstatus.setdefault(target.id,{})["stun"]=self.tick+int(ab["stun"]*4)
   msg=f"{ab['name']}!"
  elif k=="multi":
   for i in range(int(ab.get("hits",3))):
    if hit(target,self._ability_damage(ab),kind=k):break
   msg=f"{ab['name']} hits for {total}"
  elif k=="lifesteal":
   hit(target,dmg,kind=k);healed=self._heal(total*ab.get("steal",.5))
   msg=f"{ab['name']} hits for {total} and heals you for {healed}"
  elif k=="execute":
   if target.hp<=target.maxhp*.35:dmg=int(dmg*1.65)
   hit(target,dmg,kind=k);msg=f"{ab['name']} hits for {total}"
  else:
   hit(target,dmg,kind=k);msg=f"{ab['name']} hits {target.name.split(' #')[0]} for {total}"
  if crits:msg+=" (critical!)"
  if kills:msg+=f" — {kills} defeated."
  else:msg+="."
  self._level_check();self._save_player_fast()
  return msg

 def _combat_tick(self):
  """Damage/heal over time, buff expiry. Called every simulation tick (0.25s)."""
  if self.mstatus:
   for aid in list(self.mstatus):
    st=self.mstatus[aid];a=self.by_id.get(aid)
    if a is None or a.hp<=0:self.mstatus.pop(aid,None);continue
    dot=st.get("dot")
    if dot:
     if dot["until"]<=self.tick:st.pop("dot",None)
     elif self.tick>=dot["next"]:
      dot["next"]=self.tick+4;self._hit(a,dot["dmg"],can_crit=False,kind="dot")
    if not st.get("dot") and st.get("stun",0)<=self.tick and st.get("slow",0)<=self.tick and st.get("vuln",0)<=self.tick:self.mstatus.pop(aid,None)
  hot=self._buff("hot")
  if hot and self.tick>=hot["next"]:
   hot["next"]=self.tick+4;self._heal(self._effective_maxhp()*hot["value"])
   if self.inst:self.inst.heal_allies(hot["value"],.8)
  for k in [k for k,b in self.buffs.items() if b["until"]<=self.tick or (k=="shield" and b.get("absorb",0)<=0)]:
   self.buffs.pop(k,None)
 def _target_status(self):
  st=self.mstatus.get(getattr(self,"selected_target",None))
  if not st:return {}
  return {"stun":max(0,(st.get("stun",0)-self.tick+3)//4),"dot":(st["dot"]["name"] if st.get("dot") and st["dot"]["until"]>self.tick else "")}
 def _pop(self,name):
  v=getattr(self,name);setattr(self,name,[]);return v
 def buff_info(self):
  return [{"key":k,"name":b["name"],"kind":b["kind"],"left":max(0,(b["until"]-self.tick+3)//4),
           "absorb":b.get("absorb"),"max":b.get("max")} for k,b in self.buffs.items() if b["until"]>self.tick]
 def _drop_loot(self,level,x,y,source):
  roll=min(.999,self.rng.random()+min(.18,level/550.0))     # 0.44.19: monsters of higher zones drop better rarities
  rarity="Common" if roll<.55 else "Uncommon" if roll<.82 else "Rare" if roll<.95 else "Epic"
  power=max(2,level*2+RARITY_POWER[rarity]+self.rng.randint(0,6))
  slot=self.rng.choice(("weapon","armor","helm","trinket","ring"))
  item=f"{rarity} {self.rng.choice(('Iron','Silver','Runed','Hunter','Battle'))} {self.gear_word(slot)}"
  self.db.execute("INSERT INTO ground_loot(x,y,item,qty,rarity,power,slot,source,expires,class) VALUES(?,?,?,?,?,?,?,?,?,?)",(x,y,item,1,rarity,power,slot,source,self.tick+LOOT_TTL,self.class_name() if rarity in ("Epic",) else ""))
  self.db.commit()
 def nearby_loot(self):
  rows=self.db.execute("SELECT * FROM ground_loot WHERE expires>? AND (x-?) * (x-?) + (y-?) * (y-?) <= 36 ORDER BY id",(self.tick,self.player["x"],self.player["x"],self.player["y"],self.player["y"])).fetchall()
  return [dict(r) for r in rows]
 def pickup_loot(self,loot_id=None):
  rows=self.nearby_loot()
  if not rows:return "No loot nearby."
  r=next((x for x in rows if loot_id is None or x["id"]==loot_id),None)
  if r is None:return "That loot is gone."
  self._grant_gear(r["item"],r["slot"],r["rarity"],r["power"],r["source"],r["class"],"")
  self.db.execute("DELETE FROM ground_loot WHERE id=?",(r["id"],));self.db.commit()
  self.gain(f"Gear:{r['slot']}:{r['item']}",1,f"{r['rarity']} - Power {r['power']}")
  return f"Picked up {r['item']} (Power {r['power']})."
 def equip_gear(self,gear_id):
  r=self.db.execute("SELECT * FROM player_gear WHERE id=?",(gear_id,)).fetchone()
  if not r:return "Gear item not found."
  if r["vault"]:return f"{r['item']} is in your vault. Take it out at a Banker first."
  bad=self.item_usable(r["item"],r["slot"],r["class"])
  if bad:return bad
  if r["slot"]=="ring":          # 0.39: two rings - a third replaces the weaker one
   worn=self.db.execute("SELECT id FROM player_gear WHERE slot='ring' AND equipped>0 AND id!=? ORDER BY power ASC,id ASC",(gear_id,)).fetchall()
   if len(worn)>=2:self.db.execute("UPDATE player_gear SET equipped=0 WHERE id=?",(worn[0]["id"],))
  else:self.db.execute("UPDATE player_gear SET equipped=0 WHERE slot=?",(r["slot"],))
  self.db.execute("UPDATE player_gear SET equipped=1 WHERE id=?",(gear_id,));self._gear_changed()
  if r["slot"]=="weapon":self.player["weapon"]=max(self.player["weapon"],r["power"])
  if r["slot"]=="armor":self.player["armor"]=max(self.player["armor"],r["power"])
  self._save_player_fast()
  return f"Equipped {r['item']}."
 def inventory_rows(self):
  from .jewels import jewelry_bonus,jewel_bonus,bonus_text
  from .bonuses import btext,set_tiers
  raw=self.db.execute("SELECT id,slot,item,rarity,power,source,class,set_name,equipped,sockets,gems,affix FROM player_gear WHERE vault=0 ORDER BY equipped DESC,power DESC,id DESC").fetchall()
  rows=[dict(r) for r in raw];cls=self.class_name()
  for r,rr in zip(rows,raw):
   w=self.item_usable(r["item"],r["slot"],r["class"]);r["usable"]=not w;r["why"]=w
   r["gems"]=self._gems_of(r);r["bonus"]=", ".join(x for x in (bonus_text(jewelry_bonus(r["item"],r["slot"])),btext(self.item_bonus(rr))) if x)
   r["set_bonus"]=[f"{n} pieces: {btext(b)}" for n,b in sorted(set_tiers(r["set_name"],cls).items())] if r["set_name"] else []
   r.pop("affix",None)
   r["gem_bonus"]=[bonus_text(jewel_bonus(g)) for g in r["gems"]]
  return rows
 def pvp_status(self):
  r=self.db.execute("SELECT * FROM pvp_profile WHERE name=?",(self.player["name"],)).fetchone()
  if not r:return {"season":1,"rating":1000,"wins":0,"losses":0,"rank":"Bronze"}
  d=dict(r); season=1+(self.day-1)//30
  if d["season"]!=season:
   self.db.execute("UPDATE pvp_profile SET season=?,rating=1000,wins=0,losses=0,rank='Bronze' WHERE name=?",(season,self.player["name"]));self.db.commit()
   d={"name":self.player["name"],"season":season,"rating":1000,"wins":0,"losses":0,"rank":"Bronze"}
  return d

 def _rank_for(self,rating):
  return "Grandmaster" if rating>=2200 else "Diamond" if rating>=1900 else "Platinum" if rating>=1600 else "Gold" if rating>=1350 else "Silver" if rating>=1150 else "Bronze"

 def ability_info(self):
  lvl=self.player["level"];out=[]
  abl=ABILITIES[self.skill_key()]
  for i,ai in enumerate(self.slot_order()):
   k=ABILITY_KEYS[i];a=self._ranked(abl[ai])
   out.append({"slot":k,**a,"desc":describe_ability(a),"locked":lvl<a["unlock"],"ready":self.ability_cooldowns[k]<=0 and lvl>=a["unlock"],
               "cooldown":(self.ability_cooldowns[k]+3)//4})
  return out
 def passive_info(self):
  lvl=self.player["level"]
  eq=[p["name"] for p in self.equipped_passives()]
  return [{**p,"active":p["name"] in eq,"unlocked":lvl>=p["unlock"],"slot":eq.index(p["name"]) if p["name"] in eq else -1} for p in PASSIVES.get(self.skill_key(),())]

 def _maybe_legendary_drop(self,boss_level,source):
  # Extremely rare orange-tier drop, inspired by MMO legendary chase items.
  if self.rng.random() >= 0.008:return None
  names=[("Dawnbreaker, Heart of the Lion","weapon"),("Nightfall, Edge of Eternity","weapon"),("Worldrender, Titanplate","armor"),("Starfire, Crown of Ages","armor")]
  item,slot=self.rng.choice(names);return self._grant_gear(item,slot,"Legendary",120+min(10,boss_level//10),source)
 def _migrate_world(self):
  """0.24: the map is 3x larger per axis.  Older saves keep the character, gear, gold, potions and
  quests; the geography (towns, dungeons, monsters, NPCs) is rebuilt at the new scale."""
  if int(self._meta("world_ver","0") or 0)>=WORLD_VERSION:return
  had_world=self.db.execute("SELECT 1 FROM towns LIMIT 1").fetchone() is not None
  with self.db:
   for tbl in ("towns","dungeons","actors","parties","ground_loot"):self.db.execute(f"DELETE FROM {tbl}")
   self.db.execute("DELETE FROM inventory WHERE actor_id>0")
   self._setmeta("bestiary_v3","1");self._setmeta("world_ver",WORLD_VERSION)
  self._relocate_player=had_world
 def _relocate_player_after_migration(self):
  """Put an old save's hero in a sensible town of the new map (a town whose zone suits their level)."""
  if not getattr(self,"_relocate_player",False) or not self.towns:return
  self._relocate_player=False
  p=self.player;lvl=p["level"]
  own=[t for t in self.towns if t.faction in (p["faction"],"Neutral")] or self.towns
  def gap(t):
   ar=next((a for a in AREAS if a[0]==t.area),AREAS[0])
   return 0 if ar[6]<=lvl<=ar[7] else min(abs(lvl-ar[6]),abs(lvl-ar[7]))
  t=min(own,key=lambda t:(gap(t),t.id))
  p["x"],p["y"]=t.x+1.5,t.y+1.5
  self.events.append(f"The world has changed! Every zone now holds both Alliance and Horde towns. You wake in {t.name}.")
  try:                                   # town numbers changed: hand quests in at your new home town instead
   st=self._qs()
   for q in st["active"]:
    q["town"]=t.id;q["town_name"]=t.name
    za=next((z for z in AREAS if z[0]==q.get("area")),None)
    if za and za[5] not in (p["faction"],"Neutral"):       # a quest in what is now enemy land moves to your side's twin zone
     tw=next((z for z in AREAS if z[5] in (p["faction"],"Neutral") and bz(z[0])==bz(za[0])),None) or next((z for z in AREAS if z[5] in (p["faction"],"Neutral") and z[6]==za[6]),None)
     if tw:
      for k_ in ("desc","title"):
       if isinstance(q.get(k_),str):q[k_]=q[k_].replace(za[0],tw[0])
      q["area"]=tw[0]
   self._qs_save(st)
  except Exception:pass
  self._save_player_fast()
 def _load_world(self):
  self._migrate_world()
  rs=self.db.execute("SELECT * FROM towns").fetchall()
  if rs:self.towns=[Town(**dict(r)) for r in rs]
  else:self._generate_towns()
  self._expand_towns()
  rs=self.db.execute("SELECT * FROM dungeons").fetchall()
  if rs:self.dungeons=[Dungeon(**dict(r)) for r in rs]
  else:self._generate_dungeons()
  self._expand_dungeons();self._ensure_heroic();self._dungeons_outside_towns()
  rs=self.db.execute("SELECT * FROM actors").fetchall()
  if rs:self.actors=[Actor(**dict(r)) for r in rs]
  else:self._generate_population()
  self.actors=[a for a in self.actors if not (a.kind=="npc" and a.role=="guard" and not a.name.startswith(GUARD_KINDS))]   # 0.32: old wall patrols gone; royal, gate and patrol guards stay
  self.actors=[a for a in self.actors if not (a.kind=="npc" and a.role=="merchant")]   # 0.40.1: no more wandering caravan merchants
  self._ensure_town_npcs()
  self._ensure_stablemasters()
  self._place_shopkeepers()
  self._normalize_monsters()
  rs=self.db.execute("SELECT id,name,area,level,reward,xp,target,amount,progress,owner FROM quests").fetchall()
  if rs:self.quests=[Quest(**dict(r)) for r in rs]
  else:self._generate_quests(420)
  self._load_parties()
  self.by_id={a.id:a for a in self.actors}
  self._relocate_player_after_migration()
  self._leave_enemy_town_on_load()
 def _generate_towns(self):
  self.towns=[]; tid=1
  for i,a in enumerate(AREAS):
   for j in range(2):
    ox=(a[3]*.30 if j==0 else a[3]*.70); oy=(a[4]*.32 if j==0 else a[4]*.68)
    faction=a[5] if a[5] in FACTIONS[:2] else ("Alliance" if (i+j)%2==0 else "Horde")
    name=CAPITAL_NAMES.get(tid) or TOWNS_BY_ZONE.get(a[0],("",""))[j] or TOWN_NAMES[(tid-1)%len(TOWN_NAMES)]
    self.towns.append(Town(tid,name,a[0],a[1]+ox,a[2]+oy,faction,self.rng.randint(50,240),self.rng.randint(40,100)));tid+=1
  self.db.executemany("INSERT INTO towns VALUES(?,?,?,?,?,?,?,?)",[(t.id,t.name,t.area,t.x,t.y,t.faction,t.population,t.prosperity) for t in self.towns]);self.db.commit()
 def _expand_towns(self):
  if len(self.towns)>=2*len(AREAS):return
  existing={t.id for t in self.towns}; nextid=max(existing,default=0)+1
  for i,a in enumerate(AREAS):
   count=sum(t.area==a[0] for t in self.towns)
   if count>=2:continue
   faction=a[5] if a[5] in FACTIONS[:2] else ("Alliance" if (i+count)%2==0 else "Horde")
   name=TOWNS_BY_ZONE.get(a[0],("",""))[count] or TOWN_NAMES[(nextid-1)%len(TOWN_NAMES)]
   t=Town(nextid,name,a[0],a[1]+a[3]*.70,a[2]+a[4]*.68,faction,self.rng.randint(50,240),self.rng.randint(40,100))
   self.towns.append(t);self.db.execute("INSERT OR IGNORE INTO towns VALUES(?,?,?,?,?,?,?,?)",(t.id,t.name,t.area,t.x,t.y,t.faction,t.population,t.prosperity));nextid+=1
  self.db.commit()
 def _dungeons_outside_towns(self):
  """0.23: dungeon and raid entrances sit outside every city wall (never in a market square) and apart from each other."""
  def ok(d,x,y,placed):
   if any((t.x-x)**2+(t.y-y)**2<TOWN_CLEAR_R**2 for t in self.towns):return False
   return all((o.x-x)**2+(o.y-y)**2>=16.0**2 for o in placed if o is not d)
  placed=[];moved=False
  for d in sorted(self.dungeons,key=lambda d:d.id):
   ar=next((a for a in AREAS if a[0]==d.area),None)
   if ok(d,d.x,d.y,placed):placed.append(d);continue
   best=None
   for ring in range(1,110):
    rr=ring*1.0
    for k in range(max(8,ring*6)):
     ang=k/max(8,ring*6)*6.2832
     x=d.x+math.cos(ang)*rr;y=d.y+math.sin(ang)*rr
     if ar and not(ar[1]+2<=x<=ar[1]+ar[3]-2 and ar[2]+2<=y<=ar[2]+ar[4]-2):continue
     if ok(d,x,y,placed):best=(x,y);break
    if best:break
   if best:d.x,d.y=best;moved=True
   placed.append(d)
  if moved:
   self.db.executemany("UPDATE dungeons SET x=?,y=? WHERE id=?",[(d.x,d.y,d.id) for d in self.dungeons]);self.db.commit()
 def _generate_dungeons(self):
  bosses=dict(zip(("Greenfields","Ashen Vale","Ironwood","Frostmarch","Storm Coast","Bloodfen","Crownlands","Dreadmoor","Sunscar Desert","Ember Highlands","Wyrmreach","Shadowlands"),
   ("Stone Warden","Broodmother","Lich Kinglet","Frost Tyrant","Swamp Hydra","Dread Captain","Demon Prince","Sand Colossus","Ember Dragon","Wyrm Matriarch","Shadow Lord","Ancient Guardian")))
  self.dungeons=[]; did=1
  for i,a in enumerate(AREAS):
   for j in range(2):
    lvl=a[6]; boss=("Elder " if a[0] in BIOME_OF else "")+bosses.get(bz(a[0]),"Ancient Guardian")+(" Prime" if j else "")
    self.dungeons.append(Dungeon(did,f"{a[0]} {('Catacombs' if j==0 else 'Citadel')}",a[0],a[1]+a[3]*(.78 if j==0 else .22),a[2]+a[4]*(.22 if j==0 else .80),lvl,boss,1000+lvl*80,0,0,0,5,"dungeon"));did+=1
  self.db.executemany("INSERT INTO dungeons VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",[(d.id,d.name,d.area,d.x,d.y,d.level,d.boss,d.boss_hp,d.active,d.party,d.cooldown,d.size,d.kind) for d in self.dungeons]);self.db.commit()
 def _expand_dungeons(self):
  # Existing 0.5 worlds are extended in-place. Six 8x8 raid dungeons are added.
  if sum(d.kind=="dungeon" for d in self.dungeons)>=2*len(AREAS) and sum(d.kind=="raid" for d in self.dungeons)>=12:return
  existing={d.id for d in self.dungeons};nextid=max(existing,default=0)+1
  normal_by_area={a[0]:sum(d.area==a[0] and d.kind=="dungeon" for d in self.dungeons) for a in AREAS}
  for i,a in enumerate(AREAS):
   while normal_by_area[a[0]]<2:
    j=normal_by_area[a[0]];lvl=a[6];d=Dungeon(nextid,f"{a[0]} {'Catacombs' if j==0 else 'Citadel'}",a[0],a[1]+a[3]*(.78 if j==0 else .22),a[2]+a[4]*(.22 if j==0 else .80),lvl,f"{a[0]} Guardian {j+1}",1000+lvl*80,0,0,0,5,"dungeon")
    self.dungeons.append(d);self.db.execute("INSERT OR IGNORE INTO dungeons VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(d.id,d.name,d.area,d.x,d.y,d.level,d.boss,d.boss_hp,d.active,d.party,d.cooldown,d.size,d.kind));nextid+=1;normal_by_area[a[0]]+=1
  raid_bosses=["Titan of Ash","Frostwyrm Overlord","Dread Legion General","Sunscar Colossus","Ember Dragon Emperor","Void Seraph"]
  have={(d.boss,d.area) for d in self.dungeons if d.kind=="raid"}
  raid_band=(30,40,50,60,80,90)          # 0.35.1: every raid has an entrance on each side, in that side's zone of the band
  for i in range(6):
   for a in [x for x in AREAS if x[7]==raid_band[i]]:
    if (raid_bosses[i],a[0]) in have:continue
    lvl=a[7];d=Dungeon(nextid,f"{a[0]} RAID — {raid_bosses[i]}",a[0],a[1]+a[3]*.5,a[2]+a[4]*.5,lvl,raid_bosses[i],5000+lvl*180,0,0,0,8,"raid")
    self.dungeons.append(d);self.db.execute("INSERT OR IGNORE INTO dungeons VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(d.id,d.name,d.area,d.x,d.y,d.level,d.boss,d.boss_hp,d.active,d.party,d.cooldown,d.size,d.kind));nextid+=1
  self.db.commit()
 def _generate_population(self):
  self.actors=[]
  for i in range(380):
   a=self.rng.choice(AREAS); x=a[1]+self.rng.uniform(2,a[3]-2); y=a[2]+self.rng.uniform(2,a[4]-2)
   lvl=self.rng.randint(a[6],a[7]); f=a[5] if a[5] in FACTIONS[:2] else self.rng.choice(FACTIONS[:2]); role=self.rng.choice(ROLES); hp=90+lvl*10
   self.actors.append(Actor(i,f"{self.rng.choice(TITLES)} {self.rng.choice(NAMES)} {i}",f,lvl,x,y,hp,hp,"adventurer",role,"wander",-1,a[0],self.rng.randint(10,80)))
  i=0
  for a in AREAS:
   for _ in range(int(a[3]*a[4]/110*(3/WS)**1.4)):   # about one monster per 110 tiles at the old scale, a little sparser in the bigger world, gathered into dens (see _roll_monster)
    lvl=self.rng.randint(a[6],a[7]); hp=45+lvl*8
    m=Actor(10000+i,f"{self.rng.choice(MONSTERS)} #{i+1}","Monster",lvl,a[1],a[2],hp,hp,"monster","",self.rng.choice(("wander","hunt","guard","pack")), -1,a[0],self.rng.randint(10,70))
    self._roll_monster(m,a);self.actors.append(m);i+=1
  self._save_all(force=True)
 ROYAL_GUARD_POSTS=tuple((gx,gy+KING_POST[1]+12.6) for gx,gy in ((-2.6,-12.2),(2.6,-12.2),(-1.5,-14.4),(1.5,-14.4)))   # 0.41: around the (moved) ruler
 def _ensure_town_npcs(self):
  nextid=max((a.id for a in self.actors),default=10000)+1
  new=[]
  R2=TOWN_CLEAR_R**2
  for t in self.towns:
   near=[a for a in self.actors if a.kind=="npc" and (a.x-t.x)**2+(a.y-t.y)**2<R2]
   have={a.role for a in near}
   for a in near:          # 0.46.20: the Daily Quest Giver moved - put those already standing in the old spot at the new post
    if a.role=="dailygiver":
     px,py=SHOP_POSTS["dailygiver"]
     if abs(a.x-(t.x+px))>.5 or abs(a.y-(t.y+py))>.5:a.x=t.x+px;a.y=t.y+py
   fac=t.faction if t.faction in FACTIONS[:2] else "Neutral"
   lvl=max(1,next((a[6] for a in AREAS if a[0]==t.area),1))
   for name,role in (("Vendor","vendor"),("Blacksmith","blacksmith"),("Innkeeper","innkeeper"),("Quest Giver","questgiver"),("Daily Quest Giver","dailygiver"),("Market Warden","marketeer"),("Fishmonger","fishmonger"),("Jeweler","jeweler"),("Shopkeeper","grocer"),("Enchanter","enchanter"),("Banker","banker")):
    if role in have:continue
    px,py=SHOP_POSTS[role]
    new.append(Actor(nextid,name,fac,lvl,t.x+px,t.y+py,150,150,"npc",role,"town",-1,t.area,self.rng.randint(10,40)));nextid+=1
   if "king" not in have:
    nm,_tier=self.ruler_for(t);px,py=SHOP_POSTS["king"]
    new.append(Actor(nextid,nm,fac,lvl,t.x+px,t.y+py,300,300,"npc","king","town",-1,t.area,20));nextid+=1
   if not any(a.role=="guard" and a.name.startswith("Royal Guard") for a in near):
    for k in range(len(self.ROYAL_GUARD_POSTS)):    # 0.32: the royal guard stands around the ruler
     gx,gy=self.ROYAL_GUARD_POSTS[k]
     new.append(Actor(nextid,f"Royal Guard {t.name}",fac,lvl+3,t.x+gx,t.y+gy,400,400,"npc","guard","town",-1,t.area,self.rng.randint(10,40)));nextid+=1
   for prefix,n in (("Gate Guard",GATE_GUARDS),("City Patrol",PATROLS)):      # 0.39: guards at the gates and on patrol
    for k in range(n-sum(1 for a in near if a.role=="guard" and a.name.startswith(prefix))):
     ang=self.rng.random()*math.tau
     new.append(Actor(nextid,f"{prefix} {t.name}",fac,lvl+3,t.x+math.cos(ang)*8.2*TS,t.y+math.sin(ang)*8.2*TS,400,400,"npc","guard","town",-1,t.area,self.rng.randint(10,40)));nextid+=1
  for a in self.actors+new:          # 0.39: quest givers and rulers are as tough as the top of their town's level band
   if a.kind=="npc" and a.role in LEADER_ROLES:self.leader_stats(a,self._town_for_actor(a))
  if not new:return
  self.actors.extend(new)
  items=["Iron Sword","Oak Bow","Apprentice Staff","Chainmail","Healing Potion","Mana Potion","Iron Ore","Fine Leather"]
  for a in new:
   if a.role in ("vendor","blacksmith"):
    for item in items[:5 if a.role=="vendor" else 4]:
     self.db.execute("INSERT OR IGNORE INTO inventory(actor_id,item,qty) VALUES(?,?,?)",(a.id,item,self.rng.randint(2,12)))
  self._save_all(force=True)
 def _town_for_actor(self,a):
  return min(self.towns,key=lambda t:(t.x-a.x)**2+(t.y-a.y)**2)
 def _npc_ai(self,a):
  t=self._town_for_actor(a)
  if a.role=="merchant":
   pp=self.player
   if (a.x-pp["x"])**2+(a.y-pp["y"])**2<36 and not self.inst:return   # stop to trade while you are near
   dest=next((x for x in self.towns if x.id==a.target),None)
   if dest is None or (a.x-dest.x)**2+(a.y-dest.y)**2<64:
    here=dest or t
    dest=self.rng.choice([x for x in self.towns if x.id!=here.id] or self.towns);a.target=dest.id
   self._move(a,dest.x,dest.y,.55)
   return
  if a.role=="guard":
   if self._guard_hostile(a):return          # chasing an outlaw (see _outlaw_tick)
   if a.name.startswith("Royal Guard"):
    k=a.id%len(self.ROYAL_GUARD_POSTS);gx,gy=t.x+self.ROYAL_GUARD_POSTS[k][0],t.y+self.ROYAL_GUARD_POSTS[k][1]
    if (a.x-gx)**2+(a.y-gy)**2>.04:self._move(a,gx,gy,.6)
   elif a.name.startswith("Gate Guard"):
    gx,gy=self.gate_post(t,a);d2=(a.x-gx)**2+(a.y-gy)**2
    if d2>.04:
     if d2>16*16:a.x,a.y=gx,gy
     else:self._move(a,gx,gy,.9)
   return
  # 0.23: shopkeepers stand at their post all day (Diablo-style town), so you always know where to find them.
  gx,gy=self.shop_post(t,a.role)
  if (a.x-gx)**2+(a.y-gy)**2>.04:self._move(a,gx,gy,.45)
  if a.role=="blacksmith" and self.tick%120==0:
   self.db.execute("INSERT INTO inventory(actor_id,item,qty) VALUES(?,?,1) ON CONFLICT(actor_id,item) DO UPDATE SET qty=qty+1",(a.id,"Tempered Gear"))
   self.events.append(f"{a.name} finished crafting Tempered Gear.")
  elif a.role=="vendor" and self.tick%160==0:
   self.db.execute("INSERT INTO inventory(actor_id,item,qty) VALUES(?,?,1) ON CONFLICT(actor_id,item) DO UPDATE SET qty=qty+1",(a.id,"Healing Potion"))
 def _generate_quests(self,n):
  self.quests=[]
  for i in range(n):
   a=self.rng.choice(AREAS); lvl=self.rng.randint(a[6],a[7]); target=self.rng.choice(QUEST_TARGETS); amount=self.rng.randint(2,8)
   self.quests.append(Quest(i+1,f"{self.rng.choice(QUEST_VERBS)} {amount} {target}",a[0],lvl,30+lvl*12+amount*8,40+lvl*25,target,amount))
  self.db.executemany("INSERT INTO quests VALUES(?,?,?,?,?,?,?,?,?,?)",[(q.id,q.name,q.area,q.level,q.reward,q.xp,q.target,q.amount,q.progress,q.owner) for q in self.quests]);self.db.commit()
 def _load_parties(self):
  self.parties={}
  for r in self.db.execute("SELECT * FROM parties").fetchall():self.parties[r["id"]]=dict(r)
 def area(self,x,y):
  if y>=WORLD_H:return AREAS[0]
  for a in AREAS:
   if a[1]<=x<a[1]+a[3] and a[2]<=y<a[2]+a[4]:return a
  return AREAS[0]
 def _grid(self):
  """Spatial hash of every actor, rebuilt once per simulation tick (the world is big: no O(n) scans per actor)."""
  if getattr(self,"_gtick",None)!=self.tick or getattr(self,"_gn",-1)!=len(self.actors):
   g={}
   for x in self.actors:g.setdefault((int(x.x)>>3,int(x.y)>>3),[]).append(x)
   self._g=g;self._gtick=self.tick;self._gn=len(self.actors)
  return self._g
 def actors_near(self,a,dist,kind=None):
  d2=dist*dist;ar=a.home;g=self._grid();out=[]
  for cx in range(int(a.x-dist)>>3,(int(a.x+dist)>>3)+1):
   for cy in range(int(a.y-dist)>>3,(int(a.y+dist)>>3)+1):
    for x in g.get((cx,cy),()):
     if x is not a and (kind is None or x.kind==kind) and x.home==ar and (x.x-a.x)**2+(x.y-a.y)**2<=d2:out.append(x)
  return out
 def _move(self,a,tx,ty,speed=.35):
  dx,dy=tx-a.x,ty-a.y; d=math.hypot(dx,dy)
  if d<=.1:return
  if self.mstatus:
   st0_=self.mstatus.get(a.id)
   if st0_ and st0_.get("slow",0)>self.tick:speed*=SLOW_FACTOR
  if a.kind=="adventurer":speed*=1.8       # 0.24: the world is 3x wider, so travellers walk faster
  if a.kind=="monster" and a.role!="watch":       # 0.35: the City Watch walks its own streets
   nx=max(0,min(W-.01,a.x+dx/d*min(speed,d)));ny=max(0,min(H-.01,a.y+dy/d*min(speed,d)))
   if self.area(nx,ny)[0]!=self.area(a.x,a.y)[0] or (self._near_town(nx,ny,TOWN_EXCL_R) and not self._near_town(a.x,a.y,TOWN_EXCL_R)):return
   if self._near_town(nx,ny,TOWN_EXCL_R) and self._near_town(a.x,a.y,TOWN_EXCL_R):
    t=min(self.towns,key=lambda t:(t.x-a.x)**2+(t.y-a.y)**2);dd=math.hypot(a.x-t.x,a.y-t.y) or 1
    if math.hypot(nx-t.x,ny-t.y)<dd:return   # inside the exclusion ring: may only move outward
  st_=min(speed,d);ux_,uy_=dx/d,dy/d
  ok_=getattr(self,"terrain_ok",None)
  if ok_ is not None and not self.inst and a.y<WORLD_H:      # 0.44.20: monsters and travellers walk round rivers and lakes, never through them
   try:
    if ok_(a.x,a.y):
     for rot_ in (0,.7,-.7,1.4,-1.4):
      c_,s_=math.cos(rot_),math.sin(rot_);vx_,vy_=ux_*c_-uy_*s_,ux_*s_+uy_*c_
      if ok_(a.x+vx_*st_,a.y+vy_*st_):ux_,uy_=vx_,vy_;break
     else:return
   except Exception:pass
  a.x=max(0,min(W-.01,a.x+ux_*st_));a.y=max(0,min(H-.01,a.y+uy_*st_));a.home=self.area(a.x,a.y)[0]
 def _damage(self,a,t):
  mult={"Warrior":1.25,"Ranger":1.1,"Mage":1.35,"Cleric":.8,"Rogue":1.2,"Berserker":1.4,"Warlock":1.3,"Monk":1.25,"Juggernaut":.9}.get(a.role,1.0)
  return max(1,int((a.level*self.rng.uniform(.8,1.6))*mult))
 def _party_for(self,a):
  if a.party and a.party in self.parties:return self.parties[a.party]
  return None
 def _form_party(self,a):
  if a.party or a.kind!="adventurer" or a.level<8:return
  mates=[x for x in self.actors_near(a,10,"adventurer") if not x.party and x.faction==a.faction and abs(x.level-a.level)<=8]
  if len(mates)<3:return
  # 0.44.12: groups try to be a proper party - a tank, a healer and damage dealers - but it cannot always work out
  tk=next((x for x in mates if x.role in ("Warrior","Paladin","Juggernaut","Druid")),None) if a.role not in ("Warrior","Paladin","Juggernaut") else None
  hl=next((x for x in mates if x.role in ("Cleric","Shaman","Druid","Paladin") and x is not tk),None) if a.role not in ("Cleric","Shaman","Druid") else None
  have_tank=a.role in ("Warrior","Paladin","Juggernaut") or tk is not None
  have_heal=a.role in ("Cleric","Shaman","Druid") or hl is not None
  if not (have_tank and have_heal) and self.rng.random()<.65:return      # wait for a better mix most of the time
  picked=[x for x in (tk,hl) if x is not None]
  for x in mates:
   if len(picked)>=3:break
   if x not in picked:picked.append(x)
  members=[a]+picked[:3]
  pid=max(self.parties.keys(),default=0)+1
  for m in members:m.party=pid;m.state="party"
  self.parties[pid]={"id":pid,"leader":a.id,"role_count":",".join(m.role for m in members),"state":"forming","dungeon":0}
 def _party_ai(self,a):
  p=self._party_for(a)
  if not p:return
  members=[x for x in self.actors if x.party==p["id"]]
  if not members:return
  cands=[z for z in self.dungeons if z.cooldown<=0 and self.level_bracket(z.level)==self.level_bracket(a.level)]
  d=min(cands or self.dungeons,key=lambda z:(z.level-a.level)**2 + (0 if (z.kind=="raid" and len(members)>=12) or z.kind=="dungeon" else 10000))
  if p["state"]=="dungeon" and p.get("dungeon"):d=next((z for z in self.dungeons if z.id==p["dungeon"]),d)   # 0.34.2: fight the dungeon the party entered
  if p["state"]=="forming":
   if len(members)>=(12 if d.kind=="raid" else 4):p["state"]="travel"
  if p["state"]=="travel":
   a.gx,a.gy=d.x+(a.id%3-1)*.9,d.y+1.2+(a.id%2)*.8      # 0.25: walk there with the people mover
   if (a.x-d.x)**2+(a.y-d.y)**2<16 and d.cooldown<=0:
    p["state"]="dungeon";p["dungeon"]=d.id;d.active=1;d.party=p["id"];p["role_count"]=p["role_count"]
  elif p["state"]=="dungeon":
   if d.cooldown>0:p["state"]="rest";return
   # Only the leader advances the encounter; otherwise each party member would
   # process the same boss multiple times during one simulation tick.
   if a.id != p["leader"]: return
   total=sum(self._damage(m,a) for m in members)
   d.boss_hp-=max(10,total)
   if d.boss_hp<=0:
    self.events.append(f"{a.name}'s party defeated {d.boss} in {d.name} ({len(members)}-player encounter).")
    for m in members:
     m.state="return";m.party=0;m.hp=m.maxhp
    d.active=0;d.party=0;d.boss_hp=(5000+d.level*180 if d.kind=="raid" else 1000+d.level*80);d.cooldown=(720 if d.kind=="raid" else 240)
    p["state"]="done";p["dungeon"]=0
  elif p["state"]=="return":
   pass
  elif p["state"]=="rest":
   if d.cooldown<=0:p["state"]="travel"
 def _fight_ai(self,a):
  enemies=self.actors_near(a,3)
  enemies=[x for x in enemies if (x.kind=="monster" and x.faction!=a.faction) or (x.kind=="adventurer" and x.faction!=a.faction)]
  if not enemies:return False
  t=min(enemies,key=lambda x:(x.x-a.x)**2+(x.y-a.y)**2)
  t.hp-=self._damage(a,t);a.state="combat";a.target=t.id
  if t.hp<=0:
   a.kills+=1
   self._record_kill(t,a)
  return True
 def _near_town(self,x,y,r):
  r2=r*r
  return any((t.x-x)**2+(t.y-y)**2<r2 for t in self.towns)
 def _dens(self,ar):
  """Monster dens: fixed spots per zone where creatures gather, so the wilds have lairs to find and wide empty land between them."""
  c=getattr(self,"_den_cache",None)
  if c is None:c=self._den_cache={}
  if ar[0] in c:return c[ar[0]]
  r=random.Random(f"den:{self._seed()}:{ar[0]}");out=[]
  for _ in range(int(ar[3]*ar[4]/650)*4):
   x=ar[1]+8+r.random()*(ar[3]-16);y=ar[2]+8+r.random()*(ar[4]-16)
   if self._near_town(x,y,TOWN_EXCL_R+6) or any((o[0]-x)**2+(o[1]-y)**2<14**2 for o in out):continue
   out.append((x,y))
   if len(out)>=int(ar[3]*ar[4]/650):break
  c[ar[0]]=out;return out
 def _roll_monster(self,a,ar=None):
  ar=ar or self.rng.choice(AREAS)
  dens=self._dens(ar)
  for _ in range(40):
   if dens and self.rng.random()<.78:
    cx,cy=self.rng.choice(dens);ang=self.rng.uniform(0,6.2832);rr=self.rng.uniform(0,8.0)
    x=cx+math.cos(ang)*rr;y=cy+math.sin(ang)*rr
    if not(ar[1]+1<=x<=ar[1]+ar[3]-1 and ar[2]+1<=y<=ar[2]+ar[4]-1):continue
   else:
    x=ar[1]+self.rng.uniform(1,ar[3]-1);y=ar[2]+self.rng.uniform(1,ar[4]-1)
   if not self._near_town(x,y,TOWN_EXCL_R+2):
    ok_=getattr(self,"terrain_ok",None)          # 0.44.20: never spawn in a river or lake
    try:
     if ok_ is None or ok_(x,y):break
    except Exception:break
  kinds=ZONE_MONSTERS.get(ar[0],MONSTERS)
  kind=kinds[-1] if (kinds[-1]=="Ancient Treant" and self.rng.random()<.06) else self.rng.choice([k for k in kinds if k!="Ancient Treant"] or kinds)
  try:
   qk=self.quest_species_bias(ar[0]) if getattr(self,"_people_ready",True) else None      # 0.45: more of what your quest needs
   if qk:kind=qk
  except Exception:pass
  elite=kind!="Ancient Treant" and self.rng.random()<ELITE_CHANCE
  a.name=f"{'Elite ' if elite else ''}{kind} #{a.id-9999 if a.id>=10000 else a.id}";a.level=self.rng.randint(ar[6],ar[7])
  a.maxhp=int((70+a.level*14)*(2.6 if elite else 1));a.hp=a.maxhp;a.x,a.y=x,y;a.home=ar[0];a.state=self.rng.choice(("wander","hunt","guard","pack"));a.target=-1;a.party=0
 def _normalize_monsters(self):
  if self._meta("bestiary_v3") is None:
   for a in self.actors:      # 0.22: spread the new species and elites through existing worlds once
    if a.kind=="monster" and a.role not in SOLDIER_ROLES and a.target!=-2 and self.rng.random()<.55:self._roll_monster(a,self.area(a.x,a.y))
   self._setmeta("bestiary_v3","1");self.db.commit()
  if self._meta("bestiary_v4") is None:
   for a in self.actors:      # 0.29: tougher monsters in existing worlds too
    if a.kind=="monster" and a.role not in SOLDIER_ROLES and a.target!=-2:a.maxhp=int(a.maxhp*1.65);a.hp=a.maxhp
   self._setmeta("bestiary_v4","1");self.db.commit()
  if self._meta("bestiary_v5") is None:
   magic={"skeleton","ghoul","wraith","banshee","bone knight","mummy","cultist","swamp hag","demon","fire imp","void horror","shadow stalker","elemental","magma golem","lava beast","dragonkin","ancient treant"}
   for a in self.actors:      # 0.46.6: spread the new magic monsters through existing worlds once
    if a.kind=="monster" and a.role not in SOLDIER_ROLES and a.target!=-2 and a.role!='raider' and mkind(a.name).lower() not in magic and self.rng.random()<.4:self._roll_monster(a,self.area(a.x,a.y))
   self._setmeta("bestiary_v5","1");self.db.commit()
  for a in self.actors:
   if a.kind!="monster":continue
   ar=self.area(a.x,a.y);kind=mkind(a.name)
   if a.role=='raider':continue
   if kind not in ZONE_MONSTERS.get(ar[0],()) or not(ar[6]<=a.level<=ar[7]) or self._near_town(a.x,a.y,TOWN_EXCL_R):
    self._roll_monster(a,ar)
 def _record_kill(self,t,killer):
  if t.kind=="adventurer":
   t.deaths+=1
   self.events.append(f"{t.name} was defeated by {killer.name}.")
  else:
   if self.rng.random()<.12:self.events.append(f"{killer.name} hunted down a {t.name}.")
  if t.role=="raider":
   self._raider_gone(t);return
  if t.role=="watch":
   self._soldier_gone(t);return
  if t.kind=="monster":
   # respawn somewhere in the same zone so every zone keeps its population
   self._roll_monster(t,self.area(t.x,t.y));return
  if t.kind=="adventurer":self._person_respawn(t,count=False);return
  t.hp=t.maxhp;ar=self.rng.choice(AREAS);t.x=ar[1]+self.rng.random()*ar[3];t.y=ar[2]+self.rng.random()*ar[4];t.home=ar[0];t.state="wander";t.target=-1;t.party=0
 def _actor_ai(self,a):
  if a.kind in ("imob","ially") or a.role in SOLDIER_ROLES:return
  if a.kind=="monster" and a.target==-2:return
  a.timer-=1
  if a.timer>0:return
  a.timer=self.rng.randint(4,20) if a.kind=="adventurer" else self.rng.randint(5,18)
  if a.kind=="npc":
   if a.state=="pparty":return
   self._npc_ai(a); return
  if a.kind=="adventurer":
   if a.state=="pparty":return
   self._person_think(a)
  else:
   if self._fight_ai(a):return
   mobs=self.actors_near(a,12,"monster")
   if a.state in ("hunt","pack") and mobs:
    t=min(mobs,key=lambda x:(x.x-a.x)**2+(x.y-a.y)**2);self._move(a,t.x,t.y,.5)
   else:
    adv=self.actors_near(a,16,"adventurer")
    if a.state=="hunt" and adv:
     t=min(adv,key=lambda x:(x.x-a.x)**2+(x.y-a.y)**2);self._move(a,t.x,t.y,.48)
    else:self._roam(a)
  if a.hp<=0:self._respawn(a)
 def _roam(self,a):
  # 0.44: monsters roam between waypoints, stop to graze, and guards hold their post
  w=getattr(self,"_mway",None)
  if w is None:w=self._mway={}
  if a.state=="guard" and self.rng.random()<.6:return
  g=w.get(a.id)
  if g and math.hypot(g[0]-a.x,g[1]-a.y)>1.2 and g[2]>0:
   w[a.id]=(g[0],g[1],g[2]-1);self._move(a,g[0],g[1],1.1 if self.temper(a)=="aggressive" else .8);return
  if self.rng.random()<.35:w.pop(a.id,None);return      # pause
  if len(w)>len(self.by_id)+500:                  # 0.44.20: drop waypoints of raiders / watchmen that no longer exist
   for k in [k for k in w if k not in self.by_id]:del w[k]
  r=14 if a.state=="guard" else 22
  w[a.id]=(a.x+self.rng.uniform(-r,r),a.y+self.rng.uniform(-r,r),12)
 def _respawn(self,a):
  if a.kind=="monster":self._roll_monster(a,self.area(a.x,a.y));return
  if a.kind=="adventurer":self._person_respawn(a);return
  a.deaths+=1;a.hp=a.maxhp;a.party=0;a.state="wander";a.target=-1
  ar=self.rng.choice(AREAS);a.x=ar[1]+self.rng.uniform(1,ar[3]-1);a.y=ar[2]+self.rng.uniform(1,ar[4]-1);a.home=ar[0]
 def _raid_loot(self,d):
  # Every actual raid boss gets a distinct class-locked six-piece set (0.46: weapon, armor, helm, necklace, two rings).
  # The generated names remain stable, so old saves can safely keep their loot.
  prefixes={
   "Titan of Ash":"Ashen Titan","Frostwyrm Overlord":"Frostwyrm","Dread Legion General":"Dread Legion",
   "Sunscar Colossus":"Sunscar Colossus","Ember Dragon Emperor":"Ember Dragon","Void Seraph":"Void Seraph","Malachar, the Void Sovereign":"Voidtouched"}
  prefix=prefixes.get(d.boss,d.boss)
  c=self.class_name()
  class_words={"Warrior":"Warlord","Ranger":"Stalker","Mage":"Arcanist","Cleric":"Hierophant","Rogue":"Shadowblade","Paladin":"Lightbringer","Shaman":"Stormcaller","Druid":"Wildheart","Berserker":"Bloodreaver","Warlock":"Soulbinder","Monk":"Grandmaster","Juggernaut":"Bulwark"}
  word=class_words[c]
  pieces=[
   (f"{prefix} {word} Weapon","weapon"),
   (f"{prefix} {word} Cuirass","armor"),
   (f"{prefix} {word} Crown","helm"),
   (f"{prefix} {word} Pendant","trinket"),
   (f"{prefix} {word} Band","ring"),            # 0.46: six-piece sets - two rings
   (f"{prefix} {word} Signet","ring")]
  if getattr(d,"kind","")=="heroic" and self.rng.random()<.07:      # 0.45: Mythic raid armour - only from the last raid, and rarely
   ms,mw=self.rng.choice((("armor","Cuirass"),("helm","Crown"),("trinket","Pendant"),("ring","Signet")))
   nm=f"Sovereign's {word} {mw}"
   self._grant_gear(nm,ms,"Mythic",200+self.rng.randint(0,4),"Heroic Raid",c,"")
   self.events.append(f"MYTHIC! {nm} drops from {d.boss}.")
  if self.rng.random()>=.5:                  # 0.40: a set piece drops in about one raid clear in two - raids are the only source
   legendary=self._maybe_legendary_drop(d.level,f"{d.boss} Legendary Table")
   return legendary or ""
  item,slot=self.rng.choice(pieces)
  set_name=f"{prefix} {word} Regalia"
  power=(168 if slot=="weapon" else 176)+self.rng.randint(0,6)      # 0.44: raid gear is the best of everything except the Mythic weapon
  msg=self._grant_gear(item,slot,"Set",power,"Raid Boss",c,set_name)
  # Bosses can drop a second set piece, making the 2-piece bonus chase realistic.
  if self.rng.random()<.05:
   extra=self.rng.choice([x for x in pieces if x[0]!=item])
   self._grant_gear(extra[0],extra[1],"Set",power+4,"Raid Boss",c,set_name)
   msg += f" Bonus set piece: {extra[0]}."
  # Rare individual boss legendary remains the long-term chase.
  legendary=self._maybe_legendary_drop(d.level,f"{d.boss} Legendary Table")
  if legendary: msg += " " + legendary
  return msg

 def queue_pvp(self,mode):
  if mode not in (12,24):return "Battlegrounds are 12v12 or 24v24."
  if self.player_pvp:return "You are already in a PvP match."
  self.player_pvp={"mode":mode,"state":"forming","blue":["PLAYER"],"red":[],"round":0,"winner":"","reward":0,"player_hp":100+self.player["level"]*10,"player_maxhp":100+self.player["level"]*10}
  # Offline matchmaking: fill both teams with autonomous AI combatants.
  lo,hi=self.level_bracket()
  pool=[a for a in self.actors if a.kind=="adventurer" and lo<=a.level<=hi]
  # Keep matchmaking bracket-pure. If the simulation has too few adventurers
  # in the band, generate temporary AI opponents inside the same bracket.
  self.rng.shuffle(pool);need=mode-1
  selected=pool[:need+mode]
  while len(selected)<need+mode:
   advs_=[a for a in self.actors if a.kind=="adventurer"]
   selected.append(self.rng.choice(advs_) if advs_ else None)
  self.player_pvp["orig"]={}
  for a in selected:
   if a is not None:
    self.player_pvp["orig"].setdefault(a.id,(a.level,a.maxhp))      # 0.34.2: restored when the match ends
    a.level=self.rng.randint(lo,hi);a.maxhp=90+a.level*10;a.hp=a.maxhp
  self.player_pvp["blue"] += [a.id for a in selected[:need] if a is not None]
  self.player_pvp["red"] = [a.id for a in selected[need:need+mode] if a is not None]
  self.events.append(f"PvP {mode}x{mode} match formed — Level {lo}-{hi} bracket.")
  return f"Queued for PvP {mode}x{mode} — Level {lo}-{hi} bracket; match found offline."
 def _pvp_restore(self,m):
  for aid,(lvl,mhp) in (m.get("orig") or {}).items():
   a=self.by_id.get(aid)
   if a is not None:a.level=lvl;a.maxhp=mhp;a.hp=mhp
  m["orig"]={}
 def _pvp_result(self,win,mode):
  r=self.pvp_status()
  delta=(32 if win else -24)*mode
  rating=max(0,r["rating"]+delta)
  wins=r["wins"]+(1 if win else 0); losses=r["losses"]+(0 if win else 1)
  self.db.execute("UPDATE pvp_profile SET rating=?,wins=?,losses=?,rank=? WHERE name=?",(rating,wins,losses,self._rank_for(rating),self.player["name"]))
  self.db.commit()

 def _pvp_ai(self):
  m=self.player_pvp
  if not m:return
  if m["state"]=="forming":m["state"]="active"
  if m["state"]!="active":return
  ids={a.id:a for a in self.actors if a.kind=="adventurer"}
  teams=[m["blue"],m["red"]]
  # Player acts automatically here; the arena remains real-time and offline.
  for ti,team in enumerate(teams):
   foes=teams[1-ti]
   alive=[x for x in team if x=="PLAYER" or x in ids]
   targets=[x for x in foes if x in ids]
   if not targets and "PLAYER" not in foes:continue
   for member in alive:
    if member=="PLAYER":
     if targets:
      target=self.rng.choice(targets);dmg=max(2,self.player["level"]*2+self.player["weapon"]*4+self.rng.randint(0,7));ids[target].hp-=dmg
    else:
     a=ids[member]
     if "PLAYER" in foes:
      m["player_hp"]=max(0,m["player_hp"]-max(1,self._damage(a,a)))
     elif targets:
      target=ids[self.rng.choice(targets)];target.hp-=self._damage(a,target)
  if m["player_hp"]<=0:
   self._pvp_result(False,m["mode"])
   self.events.append(f"PvP {m['mode']}x{m['mode']} defeat. Season rating: {self.pvp_status()['rating']}.")
   for x in ids.values():
    if x.id in m["blue"]+m["red"]:x.hp=x.maxhp
   self._pvp_restore(m);self.player_pvp=None;return
  for team in teams:
   alive=sum(1 for x in team if x=="PLAYER" or (x in ids and ids[x].hp>0))
   if alive==0:
    m["state"]="done";m["winner"]="red" if team is m["blue"] else "blue";m["reward"]=25*m["mode"]
    points=4*m["mode"];self.player["gold"]+=m["reward"];self.player["xp"]+=75*m["mode"];self._add_currency(pvp=points);self._pvp_result(True,m["mode"])
    if self.rng.random()<.15:self._grant_gear(f"Arena Victor's Cache {m['mode']}x{m['mode']}","armor","Elite",100+m["mode"],"PvP Victory")
    self._level_check();self.events.append(f"PvP {m['mode']}x{m['mode']} victory: {m['winner'].upper()} team. +{m['reward']}g +{points} PvP Points.")
    for x in ids.values():
     if x.id in m["blue"]+m["red"]:x.hp=x.maxhp
    self._pvp_restore(m);self.player_pvp=None;return
  m["round"]+=1
  if m["round"]>=40:
   m["state"]="done";m["winner"]="draw";self.events.append(f"PvP {m['mode']}x{m['mode']} ended in a draw.")
   for x in ids.values():
    if x.id in m["blue"]+m["red"]:x.hp=x.maxhp
   self._pvp_restore(m);self.player_pvp=None
 # ---- City raids (0.15): elite raiders assault a town in three waves ----
 RAID_EVERY=4800;RAID_TIME=1500   # 0.23: a city raid roughly every 20-40 minutes of play, not constantly
 def _raid_start(self,town=None):
  if self.inst or getattr(self,"city_raid",None) or not self.towns:return False
  p=self.player
  near=min(self.towns,key=lambda t:(t.x-p["x"])**2+(t.y-p["y"])**2)
  if town is None:
   town=near if ((near.x-p["x"])**2+(near.y-p["y"])**2<=150*150 and self.rng.random()<.6) else self.rng.choice(self.towns)
  t=town
  ar=self.area(t.x,t.y)
  att=other_side(t.faction)            # 0.35: raids are faction wars - the other side's warband attacks
  self.city_raid={"town":t.id,"name":t.name,"x":t.x,"y":t.y,"wave":0,"waves":3,"ids":[],"start":self.tick,"end":self.tick+self.RAID_TIME,"hp":1000,"maxhp":1000,"next":self.tick+20,"lvl":ar[7]+2,"kills":0,"area":ar[0],"mine":0,"defs":[],"att":att,"fac":t.faction}
  self._raid_garrison(t,ar)
  tier=self.town_tier(t) if hasattr(self,"town_tier") else "town"
  if t.faction==p["faction"]:
   self.events.append(f"RAID! A {att} warband is assaulting the {t.faction} {tier} of {t.name} ({self._where(t.x,t.y)}). Adventurers are rallying - defend it!")
  else:
   self.events.append(f"RAID! Your {att} warband is assaulting the {t.faction} {tier} of {t.name} ({self._where(t.x,t.y)}). Join the attack - cut down its Watch!")
  return True
 def _raid_garrison(self,t,ar):
  # 0.32: every raid finds the city differently defended - from fully garrisoned to nearly empty
  r=self.city_raid
  roll=self.rng.random()
  if roll<.22:n,lab=self.rng.randint(10,12),"The garrison is at full strength"
  elif roll<.60:n,lab=self.rng.randint(5,8),"A fair garrison holds the walls"
  elif roll<.88:n,lab=self.rng.randint(1,3),"Only a few guards are on the walls"
  else:n,lab=0,"The walls are undefended"
  r["defense"]=lab;fac=t.faction if t.faction in FACTIONS[:2] else "Neutral"
  base=80000+self.tick%1000*10
  for i in range(n):
   ang=self.rng.uniform(0,6.283);rad=TOWN_WALL_R-2.5
   a=Actor(base+i,f"Town Defender {t.name}",fac,ar[7]+2,t.x+math.cos(ang)*rad,t.y+math.sin(ang)*rad,350,350,"npc","guard","town",-1,t.area,0)
   self.actors.append(a);self.by_id[a.id]=a;r["defs"].append(a.id)
  self.events.append(f"{lab} ({n} defenders).")
 def _raid_spawn_wave(self):
  r=self.city_raid;r["wave"]+=1;w=r["wave"];n=self.RAID_CAP;ids=[]      # 0.46.36: every wave comes at full strength - 24 attackers
  base=60000+self.tick%1000*10
  for i in range(n+(1 if w==3 else 0)):
   boss=(w==3 and i==n)
   ang=self.rng.uniform(0,6.283);dist=self.rng.uniform(40,50)
   x=max(1,min(W-1.5,r["x"]+math.cos(ang)*dist));y=max(1,min(WORLD_H-1.5,r["y"]+math.sin(ang)*dist))
   lvl=r["lvl"]+(3 if boss else 0)
   mh=int((45+lvl*8)*(12 if boss else 3))
   att=r.get("att","Horde")
   a=self._soldier(base+i,(WARLORDS[att] if boss else f"{att} Raider"),att,lvl,x,y,mh,"raider","Orc" if att=="Horde" else "Dark Knight")
   a.warlord=boss;a.scale=1.4 if boss else 1.08
   self.actors.append(a);self.by_id[a.id]=a;ids.append(a.id)
  r["ids"]=ids
  self.events.append(f"{r.get('att','Raid')} wave {w}/{r['waves']} approaches {r['name']}!"+(f" {WARLORDS.get(r.get('att'),'The Warlord')} leads the charge!" if w==3 else ""))
 def _raider_gone(self,t):
  t.gone=True
  if t in self.actors:self.actors.remove(t)
  self.by_id.pop(t.id,None);self.mstatus.pop(t.id,None)
  r=getattr(self,"city_raid",None)
  if r and t.id in r["ids"]:r["ids"].remove(t.id);r["kills"]+=1
 def _raid_end(self,won):
  r=self.city_raid;t=next((x for x in self.towns if x.id==r["town"]),None)
  for i in list(r["ids"])+list(r.get("defs",[])):
   a=self.by_id.get(i)
   if a:
    a.gone=True
    if a in self.actors:self.actors.remove(a)
    self.by_id.pop(i,None)
  p=self.player;near=(r["x"]-p["x"])**2+(r["y"]-p["y"])**2<=130*130
  attacker=r.get("fac",p["faction"])!=p["faction"]       # 0.35: you were on the attacking side
  if won and attacker:
   if t:t.prosperity=min(100,t.prosperity+8)
   self.city_result=f"{r['name']} held. The {r.get('att')} warband was driven off."
   self.events.append(self.city_result);self.city_raid=None;return
  if not won and attacker:
   if t:t.prosperity=max(10,t.prosperity-15)
   self.events.append(f"{r['name']} has fallen to the {r.get('att')}!");self.town_falls(t)
   if near and r["mine"]>0:
    gold=r["lvl"]*40;xp=r["lvl"]*150
    p["gold"]+=gold;p["xp"]+=xp;self._add_currency(raid=1,essence=1)
    self._level_check();self._save_player_fast()
    self.city_result=f"{r['name']} is sacked! +{gold}g, +{xp} XP, 1 Raid Token."
   else:self.city_result=f"{r['name']} was sacked, but you did not take part (cut down at least one of its Watch)."
   self.events.append(self.city_result);self.city_raid=None;return
  if won:
   self.events.append(f"{r['name']} is saved! The {r.get('att','raiders')} are defeated.")
   if t:t.prosperity=min(100,t.prosperity+8)
   if near and r["mine"]>0:
    self.mythic_event("cityraid")
    gold=r["lvl"]*40;xp=r["lvl"]*150
    p["gold"]+=gold;p["xp"]+=xp;self._add_currency(raid=1,essence=1)
    for i in range(3):self._drop_inst_rarity(r["x"]+self.rng.uniform(-2,2),r["y"]+self.rng.uniform(-2,2),r["lvl"],"Elite" if i==0 else "Epic","City Raid")
    self._level_check();self._save_player_fast()
    self.city_result=f"City saved! +{gold}g, +{xp} XP, 1 Raid Token. Elite loot dropped nearby."
   else:self.city_result=f"{r['name']} was saved, but you did not take part (kill at least one raider)."
  else:
   if t:t.prosperity=max(10,t.prosperity-15)
   self.events.append(f"{r['name']} has fallen to the {r.get('att','raiders')}!");self.town_falls(t)
   self.city_result=f"{r['name']} was overrun. Raiders retreat with the spoils."
  self.events.append(self.city_result);self.city_raid=None
 def _raid_tick(self):
  r=getattr(self,"city_raid",None)
  if not r:
   if self.raid_call:self._raid_call_tick();return
   if not self.inst and self.tick>0 and self.tick%self.RAID_EVERY==0 and self.rng.random()<.5:self._raid_announce()
   return
  p=self.player
  if self.tick>=r["next"] and not r["ids"] and r["wave"]<r["waves"]:
   self._raid_spawn_wave()
  if not r["ids"] and r["wave"]>=r["waves"]:self._raid_end(True);return
  if self.tick>=r["end"] or r["hp"]<=0:self._raid_end(False);return
  guards=[a for a in self.actors if a.kind=="npc" and a.role=="guard" and (a.x-r["x"])**2+(a.y-r["y"])**2<30*30]
  defs=[self.by_id[i] for i in r.get("defs",[]) if i in self.by_id]
  raiders=[self.by_id[i] for i in r["ids"] if i in self.by_id]
  for g in defs:
   if raiders:
    nr=min(raiders,key=lambda q:(q.x-g.x)**2+(q.y-g.y)**2);ddx,ddy=nr.x-r["x"],nr.y-r["y"];dd=math.hypot(ddx,ddy) or 1
    self._move(g,r["x"]+ddx/dd*(TOWN_WALL_R-2),r["y"]+ddy/dd*(TOWN_WALL_R-2),.9)
  drain=max(.35,1-.06*len(defs))
  for i in list(r["ids"]):
   a=self.by_id.get(i)
   if not a or a.hp<=0:
    if a:self._raider_gone(a)
    elif i in r["ids"]:r["ids"].remove(i)
    continue
   dx,dy=r["x"]-a.x,r["y"]-a.y;d=math.hypot(dx,dy)
   dp=math.hypot(p["x"]-a.x,p["y"]-a.y)
   engaged=a.target==-2 and dp<12 and not self._stunned(a)
   if not engaged and not self._stunned(a):
    if d>TOWN_WALL_R+3:self._move(a,r["x"],r["y"],.5)
    else:r["hp"]-=(8 if a.warlord else 1.2)*.25*drain      # at the walls: battering the gates
   for g in guards:
    if (g.x-a.x)**2+(g.y-a.y)**2<100:a.hp-=max(3,int(a.maxhp*.005))
   if a.hp<=0:self._raider_gone(a)
  r["hp"]=max(0,r["hp"])
 RAID_MUSTER=1200;RAID_CAP=24     # 0.44: a city raid is announced and musters for 5 minutes before it starts
 def _raid_announce(self,town=None,caller=False):
  if self.inst or self.city_raid or self.raid_call or not self.towns:return False
  p=self.player
  if town is None:
   near=min(self.towns,key=lambda t:(t.x-p["x"])**2+(t.y-p["y"])**2)
   town=near if ((near.x-p["x"])**2+(near.y-p["y"])**2<=150*150 and self.rng.random()<.6) else self.rng.choice(self.towns)
  t=town;att=other_side(t.faction);tight=self.rng.random()<.3      # most musters leave a place for you; some fill up first
  self.raid_call={"town":t.id,"name":t.name,"x":t.x,"y":t.y,"att":att,"fac":t.faction,"t0":self.tick,"go":self.tick+self.RAID_MUSTER,"cap":self.RAID_CAP,
                  "tight":tight,"open_at":self.tick+int(self.RAID_MUSTER*self.rng.uniform(.55,.85)) if tight else 0,"opened":False,
                  "target":self.RAID_CAP if tight else self.RAID_CAP-1,"ai":0,"joined":caller,"caller":caller,"where":self._where(t.x,t.y)}
  side="defend" if t.faction==p["faction"] else "attack"
  self.events.append(f"CITY RAID MUSTER: the {att} warband will assault {t.name} ({self.raid_call['where']}) in 5 minutes - {'defenders' if side=='defend' else 'attackers'} are gathering. Click Join at the top of the screen.")
  return True
 def _raid_call_tick(self):
  rc=self.raid_call;now=self.tick
  frac=min(1.0,(now-rc["t0"])/(self.RAID_MUSTER*(.4 if rc["tight"] else .85)))
  if rc["tight"] and not rc["joined"] and not rc["opened"] and now>=rc["open_at"]:
   rc["opened"]=True;rc["target"]=rc["cap"]-1;rc["ai"]=min(rc["ai"],rc["cap"]-1)      # a volunteer is called away - a place opens for you
   self.events.append(f"A volunteer is called away from the {rc['att']} muster at {rc['name']} - there is a place open.")
  rc["ai"]=max(rc["ai"],min(rc["target"],int(rc["target"]*frac)))
  if now>=rc["go"]:
   if self.inst:rc["go"]=now+40;return      # held until you are out of the dungeon or battleground
   self._raid_launch()
 def _raid_launch(self):
  rc=self.raid_call;self.raid_call=None
  rc["ai"]=rc["cap"]-(1 if rc["joined"] else 0)          # 0.45: empty places are filled - the warband always marches full
  t=next((x for x in self.towns if x.id==rc["town"]),None)
  if t is None or not self._raid_start(t):return
  if self.city_raid is not None:self.city_raid["caller"]=bool(rc.get("caller"))
  p=self.player
  if rc["joined"] and not self.inst:
   if math.hypot(p["x"]-t.x,p["y"]-t.y)>TOWN_WALL_R+30:
    side_in=t.faction==p["faction"]
    p["x"],p["y"]=(t.x+3.0,t.y+3.0) if side_in else (t.x+TOWN_WALL_R+8.0,t.y)
    self.mounted=None;self.fish_cancel("You are called to the muster.")
    self.events.append(f"The warband is full ({rc['cap']}/{rc['cap']}) and marches. You are sent to {t.name}.")
  elif not rc["joined"]:self.events.append(f"The warband marches at full strength ({rc['cap']}/{rc['cap']}) without you.")
 def join_city_raid(self):
  rc=self.raid_call
  if not rc:return "No raid is mustering."
  if self.inst:return "Not in here."
  if rc["joined"]:return "You have already joined the muster."
  if rc["ai"]>=rc["cap"]:return "The warband is full. Wait - someone may be called away."
  rc["joined"]=True
  return f"You join the muster for {rc['name']}. When it starts in {max(0,(rc['go']-self.tick)//4)//60}:{max(0,(rc['go']-self.tick)//4)%60:02d} you are sent to the fight; the rest of the places fill up."
 def raid_call_info(self):
  rc=self.raid_call
  if not rc or self.inst or self.player_pvp:return None
  p=self.player;left=max(0,(rc["go"]-self.tick)//4)
  cnt=min(rc["cap"],rc["ai"]+(1 if rc["joined"] else 0))
  return {"name":rc["name"],"att":rc["att"],"fac":rc["fac"],"where":rc["where"],"left":left,"cap":rc["cap"],"count":cnt,"joined":rc["joined"],
          "full":rc["ai"]>=rc["cap"] and not rc["joined"],"role":"defend" if rc["fac"]==p["faction"] else "attack",
          "age":max(0,(self.tick-rc["t0"])//4),"caller":bool(rc.get("caller"))}
 def leave_city_raid(self):
  """0.45: step out of a warband you joined; if you called the muster, it is cancelled (half the gold back)."""
  rc=self.raid_call
  if not rc:return "No raid is mustering."
  if rc.get("caller"):
   refund=self.CALL_RAID_COST//2;self.player["gold"]+=refund;self.raid_call=None;self._save_player_fast()
   self.events.append(f"The muster against {rc['name']} is called off.")
   return f"You call off the muster against {rc['name']}. The War Hall returns {refund} gold."
  if not rc["joined"]:return "You are not in the warband."
  rc["joined"]=False
  return f"You leave the warband for {rc['name']}. Another volunteer takes your place."
 def call_off_city_raid(self):
  """0.45: end a city raid you called yourself - the warband withdraws, nobody wins and the town is left as it was."""
  r=self.city_raid
  if not r:return "No city raid is under way."
  if not r.get("caller"):return "Only the one who called this raid can call it off."
  for i in list(r["ids"])+list(r.get("defs",[])):
   a=self.by_id.get(i)
   if a:
    a.gone=True
    if a in self.actors:self.actors.remove(a)
    self.by_id.pop(i,None)
  self.city_raid=None
  self.city_result=f"You call off the raid on {r['name']}. The warband withdraws - no win, no loss."
  self.events.append(self.city_result)
  return self.city_result
 CALL_RAID_COST=500
 def warhall_view(self):
  if not self._near_station("warhall",8):return None
  p=self.player;out=[]
  for d in self.dungeons:
   if d.kind in ("raid","heroic"):
    dist=math.hypot(d.x-p["x"],d.y-p["y"]);out.append((dist,d))
  out.sort(key=lambda t:t[0])
  raids=[{"name":d.name,"kind":d.kind,"level":d.level,"area":d.area if hasattr(d,"area") else "","where":self._where(d.x,d.y)} for _,d in out[:6]]
  return {"city_raid":self.raid_info(),"muster":self.raid_call_info(),"raids":raids,"cost":self.CALL_RAID_COST,"gold":p["gold"],"level":p["level"],"can_call":not self.city_raid and not self.raid_call and not self.inst}
 def call_city_raid(self):
  if not self._near_station("warhall",8):return "Stand at the War Hall."
  if self.city_raid or self.raid_call:return "A city raid is already under way."
  if self.player["level"]<10:return "Calling a city raid requires level 10."
  if self.player["gold"]<self.CALL_RAID_COST:return f"The War Hall wants {self.CALL_RAID_COST} gold to muster the raiders."
  p=self.player;foes=[t for t in self.towns if t.faction in ("Alliance","Horde") and t.faction!=p["faction"]] or self.towns
  t=min(foes,key=lambda t:(t.x-p["x"])**2+(t.y-p["y"])**2)      # 0.35: your side's warband attacks the nearest enemy town
  self.player["gold"]-=self.CALL_RAID_COST;self._raid_announce(t,caller=True);self._save_player_fast()
  return f"Your {p['faction']} warband is mustering against {t.name} ({self._where(t.x,t.y)}) - it marches in 5 minutes and you are in the roster."
 def raid_info(self):
  r=getattr(self,"city_raid",None)
  if not r:return None
  return {"town":r["name"],"wave":r["wave"],"waves":r["waves"],"left":len(r["ids"]),"hp":int(r["hp"]),"maxhp":r["maxhp"],"time":max(0,(r["end"]-self.tick)//4),"x":r["x"],"y":r["y"],"defense":r.get("defense",""),"defenders":len([i for i in r.get("defs",[]) if i in self.by_id]),"att":r.get("att",""),"fac":r.get("fac",""),"attack":r.get("fac",self.player["faction"])!=self.player["faction"],"caller":bool(r.get("caller"))}
 def _world_events(self):
  if self.tick%1920==0:
   self.events.append(f"Festival: {self.rng.choice(self.towns).name} increases local prosperity.")
  self.events=EventList(self.events[-12:])
 def _towns(self):
  if self.tick%80:return
  for t in self.towns:
   delta=self.rng.choice((-1,0,0,1))
   t.prosperity=max(1,min(100,t.prosperity+delta))
 def _save_all(self,force=False):
  if not force and time.monotonic()-self.last_save<30:return
  with self.db:
   self._setmeta("tick",self.tick);self._setmeta("day",self.day);self.db.execute("DELETE FROM actors")
   self.db.executemany("INSERT INTO actors VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
    [(a.id,a.name,a.faction,a.level,a.x,a.y,a.hp,a.maxhp,a.kind,a.role,a.state,a.target,a.home,a.timer,a.party,a.kills,a.deaths) for a in self.actors if a.kind not in ("imob","ially") and a.role not in SOLDIER_ROLES])
   self._people_save()
   self.db.execute("DELETE FROM parties")
   self.db.executemany("INSERT INTO parties VALUES(?,?,?,?,?)",[(p["id"],p["leader"],p["role_count"],p["state"],p["dungeon"]) for p in self.parties.values()])
   self.db.execute("UPDATE player SET faction=?,level=?,xp=?,gold=?,x=?,y=?,hp=?,maxhp=?,kills=?,deaths=?,weapon=?,armor=?,spell=?,class=?,spec=? WHERE name=?",
    tuple((self._save_pos()[0] if k=="x" else self._save_pos()[1] if k=="y" else self.player[k]) for k in ("faction","level","xp","gold","x","y","hp","maxhp","kills","deaths","weapon","armor","spell"))+(self.class_name(),self.spec_name(),self.player["name"],))
   self.db.executemany("UPDATE dungeons SET boss_hp=?,active=?,party=?,cooldown=?,size=?,kind=? WHERE id=?",
    [(d.boss_hp,d.active,d.party,d.cooldown,d.size,d.kind,d.id) for d in self.dungeons])
   self.db.executemany("UPDATE towns SET population=?,prosperity=? WHERE id=?",[(t.population,t.prosperity,t.id) for t in self.towns])
  self.last_save=time.monotonic()
 def update(self,steps=1):
  for _ in range(steps):
   self.tick+=1
   self._mount_tick()
   if self.tick%120==0:
    try:self.quest_hunt_top_up()
    except Exception:traceback.print_exc()
   if self.tick%960==0:self.day+=1;self._market_decay()
   if self.tick%6==0:self._pond_sweep()
   for d in self.dungeons:
    if d.cooldown>0:d.cooldown-=1
   for k in ABILITY_KEYS:
    if self.ability_cooldowns[k]>0:self.ability_cooldowns[k]-=1
   mm=self.max_mana();pos=(round(self.player["x"],2),round(self.player["y"],2));still=pos==getattr(self,"_mana_pos",None);self._mana_pos=pos
   med=any(p["name"]=="Meditation" for p in self.equipped_passives());fighting=self.tick-self.last_combat_tick<20
   if med:rate=MANA_REGEN_BASE*(1+self.passive_fx("mana_regen"))      # 0.46.31: Meditation regenerates everywhere, even in combat
   elif not fighting:rate=MANA_REGEN_BASE*(1 if still else .4)      # 0.46.31: out of combat everyone recovers mana, fastest standing still; in combat only Meditation does
   else:rate=0
   if rate:self.player["mana"]=min(mm,self.player.get("mana",mm)+rate*mm/100)
   self.db.execute("DELETE FROM ground_loot WHERE expires<=?",(self.tick,))
   (None if getattr(self,"sliced_ai",False) else self._actor_ai_batch());self._patrol_tick();self._people_tick();self._combat_tick();self._fish_tick();self._food_tick();self._pparty_tick();self._monster_player_ai();self._faction_tick();self._instance_tick();self._pvp_ai();self._raid_tick();self._world_events();self._towns();self._mkt_tick()
  self._save_all()
 def ai_pump(self,dt):
  """0.40.8: the whole world's AI used to run in one 20-90 ms burst every 0.25 s (a stutter). The game calls this every
  frame instead: each actor still gets one AI turn per 0.25 s, spread over the frames in between."""
  self.sliced_ai=True
  q=getattr(self,"_aiq",None) or [];i=getattr(self,"_aii",0)
  bud=min(1.0,getattr(self,"_aibud",0.0)+min(dt,.1)/.25)
  while bud>0:
   if i>=len(q):
    q=self._aiq=list(self.actors);i=0
    if not q:bud=0;break
   n=min(len(q)-i,max(1,int(bud*len(q))))
   for a in q[i:i+n]:
    if not getattr(a,"gone",False):self._actor_ai(a)
   i+=n;bud-=n/len(q)
  self._aii=i;self._aibud=0.0
 def _actor_ai_batch(self):
  # 0.37.2: iterate a copy - a raider or watch soldier killed during the loop is removed from self.actors,
  # which used to make the next actor silently skip its turn; actors removed mid-loop are skipped
  for a in list(self.actors):
   if not getattr(a,"gone",False):self._actor_ai(a)
 def _pond_sweep(self):
  wp=getattr(self,"water_push",None)
  if not wp:return
  for a in self.actors:
   r=wp(a.x,a.y)
   if r:a.x,a.y=r
  r=wp(self.player["x"],self.player["y"])
  if r:self.player["x"],self.player["y"]=r
 def attack_target(self,actor_id):
  if getattr(self.inst,"player_down",None) and self.inst.player_down():return "You are dead - wait to respawn."
  dm=self._dismount_for_action()
  if dm:return dm
  p=self.player;t=self.by_id.get(actor_id)
  self._cur_ab=None
  if not t or not (t.kind in ("monster","imob") or self._hostile_adv(t) or self._guard_hostile(t) or self.leader_attackable(t)):return "Invalid enemy target."
  if t.kind=="monster" and t.faction==p["faction"]:return f"{t.name} fights for the {t.faction}."
  if (t.x-p["x"])**2+(t.y-p["y"])**2>25:return f"{t.name} is out of range."
  base=(p["level"]*2+p["weapon"]*5+self.rng.randint(0,8))*(self._set_bonus()["damage"] if self._set_bonus() else 1.0)*(1+self.passive_fx("dmg_pct"))
  name=t.name.split(" #")[0]
  dmg,crit,killed=self._hit(t,max(3,int(base)),kind="auto")
  self._level_check();self._save_player_fast()
  if killed:return f"Defeated {name} — +{self.kill_events[-1]['gold']}g."
  return f"Hit {name} for {dmg}"+(" (critical!)" if crit else "")+"."
 # ---- Herbs, alchemy and teleport scrolls (0.13) ----
 HERBS=["Meadow Clover","Ironwood Sage","Frostpetal","Stormkelp","Fenbloom","Crownleaf","Duskmoss","Sunthistle","Emberroot","Voidlotus"]
 HERB_BLOCK=8;HERB_RESPAWN=4*180
 def _herb_taken(self):
  if not hasattr(self,"_herbs_taken"):self._herbs_taken={}
  return self._herbs_taken
 def _herb_at(self,bx,by):
  """Where (if anywhere) the herb of block (bx, by) grows - fixed for a world, so it is worked out once (0.38.1)."""
  c=self.__dict__.setdefault("_herb_memo",{});k=(bx,by)
  if k in c:return c[k]
  v=self._herb_at_calc(bx,by)
  if getattr(self,"terrain_ok",None) is not None:c[k]=v
  return v
 def _herb_at_calc(self,bx,by):
  h=(bx*73856093^by*19349663^self._seed())&0x7fffffff
  if h%100>=55:return None
  x=bx*self.HERB_BLOCK+1+(h>>7)%(self.HERB_BLOCK-2)+.5;y=by*self.HERB_BLOCK+1+(h>>13)%(self.HERB_BLOCK-2)+.5
  if y>=WORLD_H or x>=W:return None
  if self._near_town(x,y,TOWN_BLOCK_R+1):return None
  ok=getattr(self,"terrain_ok",None)
  if ok and not ok(x,y):return None
  a=self.area(x,y);band=min(9,(a[6]-1)//10)
  return {"id":bx*1000+by,"x":x,"y":y,"name":self.HERBS[band],"band":band}
 def herbs_near(self,radius=30):
  if self.inst:return []
  p=self.player;B=self.HERB_BLOCK;tk=self._herb_taken();out=[]
  for bx in range(int((p["x"]-radius)//B),int((p["x"]+radius)//B)+1):
   for by in range(int((p["y"]-radius)//B),int((p["y"]+radius)//B)+1):
    if tk.get((bx,by),0)>self.tick:continue
    h=self._herb_at(bx,by)
    if h:out.append(h)
  return out
 def _inv_qty(self,item):
  r=self.db.execute("SELECT qty FROM inventory WHERE actor_id=0 AND item=?",(item,)).fetchone()
  return r["qty"] if r else 0
 def _inv_add(self,item,n):
  self.db.execute("INSERT INTO inventory(actor_id,item,qty) VALUES(0,?,?) ON CONFLICT(actor_id,item) DO UPDATE SET qty=MAX(0,qty+?)",(item,max(0,n),n))
 def herb_count(self):
  return sum(r["qty"] for r in self.db.execute("SELECT qty FROM inventory WHERE actor_id=0 AND item LIKE 'Herb:%'").fetchall())
 def stock(self):
  return {"herbs":self.herb_count(),"mana":self._inv_qty("Mana Potion"),"scroll":self._inv_qty("Scroll of Teleportation")}
 def herb_list(self):
  return [(r["item"][5:],r["qty"]) for r in self.db.execute("SELECT item,qty FROM inventory WHERE actor_id=0 AND item LIKE 'Herb:%' AND qty>0 ORDER BY item").fetchall()]
 def gather_herb(self):
  p=self.player
  c=[h for h in self.herbs_near(4) if (h["x"]-p["x"])**2+(h["y"]-p["y"])**2<=6.25]
  if not c:return ""
  h=min(c,key=lambda h:(h["x"]-p["x"])**2+(h["y"]-p["y"])**2)
  n=1+(1 if self.rng.random()<.35 else 0)
  self._herb_taken()[(h["id"]//1000,h["id"]%1000)]=self.tick+self.HERB_RESPAWN
  self._inv_add("Herb:"+h["name"],n);self.db.commit();self.gain("Herb:"+h["name"],n)
  for _ in range(n):self.quest_event("herb",h["name"])
  if self.area(p["x"],p["y"])[7]>=91:
   for _ in range(n):self.mythic_event("herb")
  return f"Gathered {n} {h['name']}."
 def use_mana_potion(self):
  if self._inv_qty("Mana Potion")<=0:return "No Mana Potions."
  mm=self.max_mana()
  if self.player.get("mana",mm)>=mm:return "Your mana is already full."
  amt=max(50,mm//4);self.player["mana"]=min(mm,self.player.get("mana",mm)+amt);self._inv_add("Mana Potion",-1);self.db.commit()
  return f"Mana Potion: restored {amt} mana."
 def use_scroll(self):
  if self.inst:return "The scroll fizzles inside the dungeon."
  if self._inv_qty("Scroll of Teleportation")<=0:return "No Scroll of Teleportation. Brew one at an inn (4 herbs + 25g)."
  p=self.player;t=min(self.towns,key=lambda t:(t.x-p["x"])**2+(t.y-p["y"])**2)
  self._inv_add("Scroll of Teleportation",-1);p["x"]=t.x+2;p["y"]=t.y+2;self.db.commit();self._save_player_fast()
  return f"The scroll carries you to {t.name}."
 # ---- Trading market (0.13): AI traders in every town ----
 GOODS={"Health Potion":18,"Mana Potion":18,"Scroll of Teleportation":70}
 GEAR_FACTOR={"Common":1.5,"Uncommon":3,"Rare":6,"Epic":12,"Elite":20,"Set":28,"Legendary":40}
 TRADERS=["Marta the Peddler","Old Hobb","Kessa of the Caravan","Brannoch","Silvia Quickhand","Dorn the Fence","Yara Sunfield","Pell the Lender","Oswin Redcart","Nim Coinwright"]
 def market_town(self):
  if self.inst or not self.towns:return None
  p=self.player;t=min(self.towns,key=lambda t:(t.x-p["x"])**2+(t.y-p["y"])**2)
  return t if (t.x-p["x"])**2+(t.y-p["y"])**2<=40*40 else None
 def _mkt_state(self):
  import json
  return self._jmeta("mkt",None)
 def _mkt_save(self,st):
  import json;self._setmeta("mkt",json.dumps(st))
 def _mkt_mult(self,t,good):
  r=random.Random(f"{self._seed()}:{t.id}:{good}:{self.day//2}")
  m=.78+r.random()*.6
  sat=self._mkt_state().get("sat",{}).get(f"{t.id}:{good}",0)
  return m,sat
 def _good_base(self,good):
  if good.startswith("Herb:"):
   try:return 6*(self.HERBS.index(good[5:])+1)
   except ValueError:return 6
  if good.startswith("Mat:"):return MATS_BASE.get(good,10)
  if good.startswith("Fish:"):return 8+4*(max([i for i,f in enumerate(FISH_NAMES) if f in good]+[0]))
  if good.startswith("Brew:"):
   from .brews import BY_NAME
   b=BY_NAME.get(good[5:]);return b["price"] if b else 40
  if good.startswith("Food:"):return 30
  if good in ("Fishing Bait","Health Bread"):return {"Fishing Bait":8,"Health Bread":24}[good]
  if good.startswith("Scroll of") and good not in self.GOODS:return 90
  return self.GOODS.get(good,10)
 def _buy_price(self,t,good):
  m,sat=self._mkt_mult(t,good);return max(1,int(self._good_base(good)*m*1.15*(1-min(sat,10)*.02)))
 def _sell_price(self,t,good):
  m,sat=self._mkt_mult(t,good);return max(1,int(self._good_base(good)*m*.8*max(.4,1-sat*.04)))
 def _gear_value(self,rarity,power):return int(power*self.GEAR_FACTOR.get(rarity,2))
 def _listings(self,t):
  per=self.day//2;r=random.Random(f"L{self._seed()}:{t.id}:{per}")
  lvl=self.player["level"];out=[];sold=set(self._mkt_state().get("sold",[]));bots=self._bot_listings(t)
  for i in range(6):
   if i<len(bots):        # 0.46.27: real adventurers selling their spare gear
    if f"{t.id}:{per}:{i}" not in sold:
     b=bots[i];out.append({"key":f"l:{i}","label":b["label"],"sub":b["sub"],"rarity":b["rarity"],"slot":b["slot"],"power":b["power"],"price":b["price"],"item":b["item"]})
    continue
   rar=r.choices(["Uncommon","Rare"],[5,4])[0];slot=r.choice(("weapon","armor","helm","trinket"))
   power=min(168,int(lvl*1.2)+RARITY_POWER[rar]+r.randint(-2,3));pre=r.choice(("Travelling","Merchant's","Smuggled","Estate","Surplus","Trader's"))
   item=f"{rar} {pre} {self.gear_word(slot,r)}";seller=r.choice(self.TRADERS)
   if f"{t.id}:{per}:{i}" in sold:continue
   out.append({"key":f"l:{i}","label":item,"sub":f"{slot}  P{power}  from {seller}","rarity":rar,"slot":slot,"power":power,"price":int(self._gear_value(rar,power)*(.9+r.random()*.3)),"item":item})
  return out
 def market_view(self,mult=1.0):
  t=self.market_town()
  if not t:return None
  buy=[];role=""
  for g in self.GOODS:
   buy.append({"key":"g:"+g,"label":g,"sub":"stock","rarity":"Common","price":self._buy_price(t,g)})
  a=self.area(t.x,t.y);band=min(9,(a[6]-1)//10);hn="Herb:"+self.HERBS[band]
  buy.append({"key":"g:"+hn,"label":self.HERBS[band],"sub":"herb","rarity":"Common","price":self._buy_price(t,hn)})
  for m in MAT_SOLD:buy.append({"key":"g:"+m,"label":m[4:],"sub":"crafting material","rarity":"Common","price":self._buy_price(t,m)})
  buy+=self._listings(t)
  sell=[]
  for g in list(self.GOODS):
   q=self._inv_qty(g)
   if g=="Health Potion":self._ensure_potions();q=self._inv_qty(g)
   if q>0:sell.append({"key":"s:"+g,"label":g,"sub":f"x{q}","rarity":"Common","price":self._sell_price(t,g)})
  for nm,q in self.herb_list():sell.append({"key":"s:Herb:"+nm,"label":nm,"sub":f"herb x{q}","rarity":"Common","price":self._sell_price(t,"Herb:"+nm)})
  for it,q in self.inventory_goods():sell.append({"key":"s:"+it,"label":it.split(":",1)[-1],"sub":f"x{q}","rarity":"Common","price":self._sell_price(t,it)})
  if role=="fishmonger":sell=[x for x in sell if "Fish" in x["key"] or "Food:" in x["key"]]
  elif role=="jeweler":sell=[]
  for r in self.inventory_rows():
   if r["equipped"] or r["rarity"]=="Mythic":continue
   if role=="fishmonger" or (role=="jeweler" and r["slot"]!="trinket"):continue
   sell.append({"key":f"x:{r['id']}","label":r["item"],"sub":f"{r['slot']}  P{r['power']}","rarity":r["rarity"],"price":int(self._gear_value(r["rarity"],r["power"])*.4),"slot":r["slot"],"power":r["power"],"item":r["item"],"gid":r["id"]})
  return {"town":t.name,"buy":buy,"sell":sell,"list":self.mk_list_rows(t,sell,mult),"mine":self.mk_mine_rows(t),"gold":self.player["gold"]}
 def market_buy(self,key):
  t=self.market_town()
  if not t:return "You must be in a town to trade."
  v=self.market_view();row=next((b for b in v["buy"] if b["key"]==key),None)
  if not row:return "That offer is gone."
  if self.player["gold"]<row["price"]:return f"Not enough gold ({row['price']}g)."
  self.player["gold"]-=row["price"]
  if key.startswith("g:"):
   g=key[2:];self._ensure_potions();self._inv_add(g,1)
   st=self._mkt_state();k=f"{t.id}:{g}";st.setdefault("sat",{})[k]=max(-5,st.get("sat",{}).get(k,0)-1);self._mkt_save(st);msg=f"Bought {row['label']} for {row['price']}g."
  else:
   i=int(key[2:]);st=self._mkt_state();st.setdefault("sold",[]).append(f"{t.id}:{self.day//2}:{i}");st["sold"]=st["sold"][-400:];self._mkt_save(st)
   self._grant_gear(row["item"],row["slot"],row["rarity"],row["power"],"Market","","");msg=f"Bought {row['item']} (P{row['power']}) for {row['price']}g."
  self.db.commit();self._save_player_fast();return msg
 def market_sell(self,key):
  t=self.market_town()
  if not t:return "You must be in a town to trade."
  v=self.market_view();row=next((b for b in v["sell"] if b["key"]==key),None)
  if not row:return "You no longer have that."
  if key.startswith("s:"):
   g=key[2:];self._inv_add(g,-1)
   st=self._mkt_state();k=f"{t.id}:{g}";st.setdefault("sat",{})[k]=st.get("sat",{}).get(k,0)+1;self._mkt_save(st)
  else:
   self.db.execute("DELETE FROM player_gear WHERE id=?",(int(key[2:]),))
  self.player["gold"]+=row["price"];self.db.commit();self._save_player_fast()
  return f"Sold {row['label']} for {row['price']}g."

 # ---- 0.23 shops: every town has real shopkeepers standing at their stalls ----
 SHOP_TITLE={"vendor":"Potions & Remedies","grocer":"General Goods & Supplies","enchanter":"Magic Items for this Zone","blacksmith":"Weapons & Armor","merchant":"Caravan Wares","fishmonger":"Fresh Catch & Tackle","jeweler":"Rings, Amulets & Gems"}
 CLASS_WEAPONS={"Warrior":("Greatsword","Broadsword","War Axe"),"Ranger":("Longbow","Recurve Bow","Hunting Bow"),"Mage":("Staff","Spire Staff","Wand"),
  "Cleric":("Mace","Holy Mace","Scepter"),"Rogue":("Daggers","Kris Blades","Stilettos"),"Paladin":("Warhammer","Mace","Longsword"),
  "Shaman":("Totem Staff","Spirit Staff","Hand Axe"),"Druid":("Oak Staff","Thorn Staff","Crescent Staff"),"Berserker":("Great Axe","Cleaver","Bearded Axe"),
  "Warlock":("Bone Staff","Hex Staff","Rod"),"Monk":("Quarterstaff","Bo Staff","Fist Wraps"),"Juggernaut":("Maul","Warhammer","Flail")}
 MATERIAL=("Crude","Sturdy","Tempered","Fine","Masterwork")
 ROLE_TITLE={"vendor":"Apothecary","grocer":"General Store","enchanter":"Magic Shop","blacksmith":"Blacksmith","innkeeper":"Innkeeper","questgiver":"Quest Giver","dailygiver":"Daily Quests","marketeer":"Market Warden","stablemaster":"Stable Master","fishmonger":"Fishmonger","jeweler":"Jeweler","banker":"Banker"}
 def _place_shopkeepers(self):
  for a in self.actors:
   if a.kind=="npc" and a.role in SHOP_POSTS:
    t=self._town_for_actor(a);px,py=SHOP_POSTS[a.role];a.x,a.y=t.x+px,t.y+py
    if a.role in self.ROLE_TITLE and a.name!=self.ROLE_TITLE[a.role]:a.name=self.ROLE_TITLE[a.role]
 def gate_post(self,t,a):
  """0.39: gate guards stand in pairs just inside the town's gates (compass points until the gates are known)."""
  gates=(getattr(self,"gate_angles",None) or {}).get(t.id) or [0,math.pi/2,math.pi,math.pi*1.5]
  same=sorted(x.id for x in self.actors if x.kind=="npc" and x.role=="guard" and x.name==a.name)
  k=same.index(a.id) if a.id in same else a.id
  g=gates[(k//2)%len(gates)];side=1.7 if k%2 else -1.7;r=TOWN_WALL_R-1.8
  return t.x+math.cos(g)*r-math.sin(g)*side,t.y+math.sin(g)*r+math.cos(g)*side
 def _patrol_tick(self):
  """0.39: city patrols walk the ring street round the market, at walking pace (only near you - nobody sees the rest)."""
  p=self.player
  if self.inst:return
  for a in self.actors:
   if a.kind!="npc" or a.role!="guard" or not a.name.startswith("City Patrol"):continue
   if abs(a.x-p["x"])>60 or abs(a.y-p["y"])>60 or self._guard_hostile(a):continue
   t=self._town_for_actor(a)
   if t is None:continue
   wp=getattr(a,"wp",None)
   if wp is None:
    a.wp=wp=int(((math.atan2(a.y-t.y,a.x-t.x))%math.tau)/math.tau*10)%10;a.wdir=1 if a.id%2 else -1
   ang=wp/10*math.tau;gx,gy=t.x+math.cos(ang)*8.2*TS,t.y+math.sin(ang)*8.2*TS
   dx,dy=gx-a.x,gy-a.y;d=math.hypot(dx,dy)
   if d<.3:a.wp=(wp+a.wdir)%10;continue
   if d>12:a.x,a.y=gx,gy;continue
   s=min(.13,d);a.x+=dx/d*s;a.y+=dy/d*s
 def shop_post(self,t,role):
  """Where a shopkeeper of town t stands: the door of their building when the town has one (0.39), else their old post."""
  k=BUILDING_ROLES.get(role);sp=getattr(self,"station_posts",None)
  if k and sp:
   c=[(x,y) for x,y in sp.get(k,()) if (x-t.x)**2+(y-t.y)**2<26*26]
   if c:
    x,y=min(c,key=lambda q:(q[0]-t.x)**2+(q[1]-t.y)**2);return x+1.0,y+1.9
  px,py=SHOP_POSTS.get(role,(0,0));return t.x+px,t.y+py
 def place_town_npcs(self):
  """0.39: put every shopkeeper straight at their post once the town buildings are known (no walk across town)."""
  for a in self.actors:
   if a.kind=="npc" and a.role in SHOP_POSTS and a.role!="king":
    t=self._town_for_actor(a)
    if t is not None:a.x,a.y=self.shop_post(t,a.role)
 def _shop_npc(self,npc_id):
  a=self.by_id.get(npc_id) if hasattr(self,"by_id") else None
  if a is None:a=next((x for x in self.actors if x.id==npc_id),None)
  return a
 def _price_town(self,a=None):
  p=self.player;x,y=(a.x,a.y) if a else (p["x"],p["y"])
  return min(self.towns,key=lambda t:(t.x-x)**2+(t.y-y)**2)
 def _zone_band(self,t):
  """0.40: shops stock gear for the level range of the zone the town is in."""
  ar=self.area(t.x,t.y);return ar[6],ar[7]
 def _smith_stock(self,t):
  lo,hi=self._zone_band(t);per=self.day//2;r=random.Random(f"S{self._seed()}:{t.id}:{per}:{self.class_name()}")
  cls=self.class_name();sold=set(self._mkt_state().get("sold",[]))
  out=[]
  for i in range(22):
   slot="weapon" if i<10 else ("armor","helm","trinket")[i%3]
   rar=r.choices(["Common","Uncommon","Rare"],[5,5,3])[0]
   il=r.randint(lo,hi);power=min(self.SMITH_CAP,max(2,il*2+RARITY_POWER[rar]+r.randint(0,6)))
   mat=self.MATERIAL[min(4,(il//20)+r.randint(0,1))]
   base=self.gear_word(slot,r,cls)
   item=f"{rar} {mat} {base}"
   if f"s{t.id}:{per}:{i}" in sold:continue
   out.append({"key":f"b:{i}","label":item,"slot":slot,"rarity":rar,"power":power,"price":max(5,int(self._gear_value(rar,power)*1.5)),
               "item":item,"cls":cls if slot=="weapon" else "","sub":f"Lv {il} {slot}  Power {power}"})
  return out
 ENCHANT_WORDS=("Enchanted","Runed","Arcane","Spellbound","Glimmering","Starforged","Warded")
 MAGIC_CAP=166      # 0.46: Magic Shop gear stays under raid sets (168+) and Mythic gear
 SMITH_CAP=150
 def _enchant_stock(self,t):
  """0.46 Magic Shop: Rare, Epic and Elite gear that is better than any other shop's - every piece carries a bonus,
  some come already upgraded (+1 or +2), Epic and better have a socket. The zone's six-piece set is sold in its own tab."""
  from .bonuses import roll_affix,btext
  lo,hi=self._zone_band(t);per=self.day//2;cls=self.class_name()
  r=random.Random(f"E{self._seed()}:{t.id}:{per}:{cls}");sold=set(self._mkt_state().get("sold",[]))
  out=[]
  for i in range(16):
   slot="weapon" if i<6 else ("armor","helm","armor","helm","trinket","ring","trinket","ring","armor","helm")[i-6]
   rar=r.choices(["Rare","Epic","Elite"],[3,3,1 if hi>=20 else 0])[0]
   il=r.randint(lo,hi);up=r.choices([0,1,2],[6,3,1])[0]
   power=min(self.MAGIC_CAP,max(6,il*2+RARITY_POWER[rar]+6+r.randint(2,8)))+6*up
   suffix,bonus=roll_affix(r,il,rar,cls)
   item=f"{rar} {r.choice(self.ENCHANT_WORDS)} {self.gear_word(slot,r,cls)} {suffix}"+(f" +{up}" if up else "")
   if f"e{t.id}:{per}:{i}" in sold:continue
   socks=1 if rar!="Rare" else 0
   out.append({"key":f"e:{i}","label":item,"slot":slot,"rarity":rar,"power":power,"price":max(30,int(self._gear_value(rar,power)*2.2*(1+.35*up))),
               "item":item,"cls":cls if slot in ("weapon","armor","helm") else "","sockets":socks,"affix":bonus,"bonus":btext(bonus),
               "sub":f"Lv {il} {slot}  Power {power}"+("  1 socket" if socks else "")+"  -  "+btext(bonus)})
  return out
 def _magic_set_stock(self,t):
  """0.46: every Magic Shop sells its zone's six-piece set for your class (weapon, armor, helm, necklace, two rings)."""
  from .bonuses import ZONE_SET_WORD,set_tiers,btext
  ar=self.area(t.x,t.y);lo,hi=ar[6],ar[7];cls=self.class_name()
  word=ZONE_SET_WORD.get(ar[0],"Wanderer");set_name=f"{word} Set";r=random.Random(f"MS{self._seed()}:{ar[0]}:{cls}")
  tiers=set_tiers(set_name,cls);sub_b="  |  ".join(f"{n}: {btext(b)}" for n,b in sorted(tiers.items()))
  out=[]
  for i,(slot,nm) in enumerate((("weapon",None),("armor",None),("helm",None),("trinket","Pendant"),("ring","Band"),("ring","Signet"))):
   item=f"{word} {nm or self.gear_word(slot,r,cls)}"
   power=min(self.MAGIC_CAP-4,max(8,hi*2+RARITY_POWER["Epic"]+4))
   out.append({"key":f"ms:{i}","label":item,"slot":slot,"rarity":"Set","power":power,"price":max(60,int(self._gear_value("Epic",power)*2.6)),
               "item":item,"cls":cls if slot in ("weapon","armor","helm") else "","set_name":set_name,"set_bonus":sub_b,
               "sub":f"{set_name} {i+1}/6  {slot}  Power {power}"})
  return out
 def _jewel_stock(self,t):
  lvl=self.player["level"];per=self.day//2;r=random.Random(f"J{self._seed()}:{t.id}:{per}:{lvl//3}")
  sold=set(self._mkt_state().get("sold",[]));out=[]
  for i in range(14):
   rar=r.choices(["Common","Uncommon","Rare"],[4,5,3])[0]
   power=max(2,lvl*2+RARITY_POWER[rar]+r.randint(0,6))
   mat=("Copper","Silver","Gold","Sapphire","Ruby","Emerald","Diamond")[min(6,(lvl//15)+r.randint(0,1))]
   base=r.choice(("Ring","Amulet","Ring","Pendant","Signet","Talisman"))
   item=f"{rar} {mat} {base}"
   if f"s{t.id}:{per}:{i}" in sold:continue
   out.append({"key":f"b:{i}","label":item,"slot":"trinket","rarity":rar,"power":power,"price":max(5,int(self._gear_value(rar,power)*1.6)),"item":item,"cls":"","sub":f"trinket  Power {power}"})
  return out
 def shop_view(self,npc_id):
  a=self._shop_npc(npc_id)
  if a is None or a.kind!="npc":return None
  p=self.player
  if (a.x-p["x"])**2+(a.y-p["y"])**2>8*8:return None
  t=self._price_town(a);role=a.role;tabs=[]
  if role=="vendor":
   goods=[]
   for g in self.GOODS:
    goods.append({"key":"g:"+g,"label":g,"slot":{"Health Potion":"potion","Mana Potion":"mana","Scroll of Teleportation":"scroll"}.get(g,"potion"),"rarity":"Common","price":self._buy_price(t,g),"sub":"consumable","power":0})
   ar=self.area(t.x,t.y);band=min(9,(ar[6]-1)//10);hn="Herb:"+self.HERBS[band]
   goods.append({"key":"g:"+hn,"label":self.HERBS[band],"slot":"herb","rarity":"Common","price":self._buy_price(t,hn),"sub":"herb (for alchemy)","power":0})
   goods=[x for x in goods if x["label"]!="Scroll of Teleportation"]
   for sc in ("Scroll of Might","Scroll of Fortitude","Scroll of Swiftness"):
    goods.append({"key":"g:"+sc,"label":sc,"slot":"scroll","rarity":"Uncommon","price":self._buy_price(t,sc),"sub":"buff scroll","power":0})
   tabs.append({"name":"Potions & Remedies","items":goods})
  elif role=="grocer":           # 0.40: the General Store
   sup=[{"key":"g:"+g,"label":g.split(":",1)[-1],"slot":sl,"rarity":"Common","price":self._buy_price(t,g),"sub":sub,"power":0}
        for g,sl,sub in (("Scroll of Teleportation","scroll","back to town"),("Fishing Bait","fish","for fishing"),("Health Bread","potion","food buff"),("Food:Grilled Fish","potion","food"))]
   tabs.append({"name":"Supplies","items":sup})
   mats=[{"key":"g:"+m,"label":m[4:],"slot":"herb","rarity":"Common","price":self._buy_price(t,m),"sub":"crafting material","power":0} for m in MAT_SOLD]
   tabs.append({"name":"Crafting Materials","items":mats})
  elif role=="blacksmith":
   st=self._smith_stock(t)
   tabs.append({"name":"Weapons","items":[x for x in st if x["slot"]=="weapon"]})
   tabs.append({"name":"Armor","items":[x for x in st if x["slot"]!="weapon"]})
  elif role=="jeweler":
   tabs.append({"name":"Rings & Amulets","items":self._jewel_stock(t)})
  elif role=="enchanter":        # 0.40: magic gear for this zone's level range
   st=self._enchant_stock(t)
   tabs.append({"name":"Weapons","items":[x for x in st if x["slot"]=="weapon"]})
   tabs.append({"name":"Armor & Jewelry","items":[x for x in st if x["slot"]!="weapon"]})
   tabs.append({"name":"Zone Set (6)","items":self._magic_set_stock(t)})
  elif role=="fishmonger":
   ar=self.area(t.x,t.y);band=min(len(FISH_NAMES)-1,(ar[6]-1)//10)
   fish=[{"key":"g:Fish:"+FISH_NAMES[i],"label":FISH_NAMES[i],"slot":"potion","rarity":"Common","price":self._buy_price(t,"Fish:"+FISH_NAMES[i]),"sub":"fresh fish","power":0} for i in range(max(0,band-1),band+1)]
   tabs.append({"name":"Fresh Catch","items":fish})
  elif role=="merchant":
   tabs.append({"name":"Rare Wares","items":self._listings(t)})
  else:return None
  for tab in tabs:
   for it in tab["items"]:it.setdefault("slot","trinket")
  eq={r["slot"]:r for r in self.inventory_rows() if r["equipped"]}
  sell=[]
  for g in list(self.GOODS):
   q=self._inv_qty(g)
   if q>0:sell.append({"key":"s:"+g,"label":g,"slot":{"Health Potion":"potion","Mana Potion":"mana","Scroll of Teleportation":"scroll"}.get(g,"potion"),"rarity":"Common","sub":f"x{q}","price":self._sell_price(t,g),"power":0})
  for nm,q in self.herb_list():sell.append({"key":"s:Herb:"+nm,"label":nm,"slot":"herb","rarity":"Common","sub":f"herb x{q}","price":self._sell_price(t,"Herb:"+nm),"power":0})
  for it,q in self.inventory_goods():
   sell.append({"key":"s:"+it,"label":it.split(":",1)[-1],"slot":"potion" if it.startswith("Food:") else "scroll" if it.startswith("Scroll") else "herb","rarity":"Common","sub":f"x{q}","price":self._sell_price(t,it),"power":0})
  for r in self.inventory_rows():
   if r["equipped"] or r["rarity"]=="Mythic":continue
   sell.append({"key":f"x:{r['id']}","label":r["item"],"slot":r["slot"],"rarity":r["rarity"],"sub":f"{r['slot']}  Power {r['power']}","power":r["power"],"price":max(1,int(self._gear_value(r["rarity"],r["power"])*.4))})
  return {"npc":a.id,"name":a.name,"role":role,"title":self.SHOP_TITLE.get(role,"Shop"),"town":t.name,"tabs":tabs,"sell":sell,"gold":p["gold"],"can_craft":False,
          "equipped":{k:{"item":v["item"],"power":v["power"],"rarity":v["rarity"]} for k,v in eq.items()}}
 def shop_buy(self,npc_id,key):
  v=self.shop_view(npc_id)
  if not v:return "Walk up to the shopkeeper to trade."
  row=next((it for tab in v["tabs"] for it in tab["items"] if it["key"]==key),None)
  if not row:return "That item is no longer for sale."
  if self.player["gold"]<row["price"]:return f"Not enough gold — {row['label']} costs {row['price']}g."
  t=self._price_town(self._shop_npc(npc_id))
  self.player["gold"]-=row["price"]
  if key.startswith("g:"):
   g=key[2:];self._ensure_potions();self._inv_add(g,1)
   st=self._mkt_state();k=f"{t.id}:{g}";st.setdefault("sat",{})[k]=max(-5,st.get("sat",{}).get(k,0)-1);self._mkt_save(st)
   msg=f"Bought {row['label']} for {row['price']}g."
  else:
   st=self._mkt_state()
   tag=(f"s{t.id}:{self.day//2}:{key[2:]}" if key.startswith("b:") else f"e{t.id}:{self.day//2}:{key[2:]}" if key.startswith("e:") else f"{t.id}:{self.day//2}:{key[2:]}")
   st.setdefault("sold",[]).append(tag);st["sold"]=st["sold"][-400:];self._mkt_save(st)
   self._grant_gear(row["item"],row["slot"],row["rarity"],row["power"],"Magic Shop" if key[:2] in ("e:","ms") else "Shop",row.get("cls",""),row.get("set_name",""),row.get("affix"))
   if row.get("sockets"):self.db.execute("UPDATE player_gear SET sockets=? WHERE id=(SELECT MAX(id) FROM player_gear)",(row["sockets"],))
   msg=f"Bought {row['item']} (Power {row['power']}) for {row['price']}g. Equip it from your Bag (I)."
  self.db.commit();self._save_player_fast();return msg
 def shop_sell(self,npc_id,key):
  v=self.shop_view(npc_id)
  if not v:return "Walk up to the shopkeeper to trade."
  row=next((it for it in v["sell"] if it["key"]==key),None)
  if not row:return "You no longer have that."
  t=self._price_town(self._shop_npc(npc_id))
  if key.startswith("s:"):
   g=key[2:];self._inv_add(g,-1)
   st=self._mkt_state();k=f"{t.id}:{g}";st.setdefault("sat",{})[k]=st.get("sat",{}).get(k,0)+1;self._mkt_save(st)
  else:
   self.db.execute("DELETE FROM player_gear WHERE id=?",(int(key[2:]),))
  self.player["gold"]+=row["price"];self.db.commit();self._save_player_fast()
  return f"Sold {row['label']} for {row['price']}g."
 def _market_decay(self):
  st=self._mkt_state()
  if st.get("sat") and st.get("day",0)!=self.day:
   st["sat"]={k:(v-1 if v>0 else v+1 if v<0 else 0) for k,v in st["sat"].items()};st["sat"]={k:v for k,v in st["sat"].items() if v}
   st["day"]=self.day;self._mkt_save(st)
 def interact_nearby(self):
  p=self.player
  if self.inst:return self.leave_instance() if self.inst.near_portal() else "You need to stand next to a portal to leave."
  npcs=[a for a in self.actors if a.kind=="npc" and a.hp>0 and a.role not in HIDDEN_ROLES and (a.x-p["x"])**2+(a.y-p["y"])**2<=36]
  clicked_npc=False
  tt=getattr(self,"talk_to",None)
  pa=self.by_id.get(tt) if tt is not None else None
  if pa is not None and (pa.kind=="adventurer" or (pa.kind=="npc" and pa.role=="guard" and not self.refuse_service(pa))) and (pa.x-p["x"])**2+(pa.y-p["y"])**2<=49:
   self.talk_to=None;self.open_ui="person";self.person_id=pa.id
   return self.greet_person(pa.id)
  if getattr(self,"talk_to",None) is not None:
   tn=next((a for a in npcs if a.id==self.talk_to),None);self.talk_to=None
   if tn is not None:npcs=[tn];clicked_npc=True
  et_=self.enemy_town_at(p["x"],p["y"],p["faction"])
  if et_ is not None and (getattr(self,"talk_to",None) is None or not npcs) and any(self._near_station(k_,5.0) for k_ in ("warhall","forge","hut","press","magic","inn","kiln","apothecary","jeweler","smithy","general","enchanter","bank","stable","market","teleport")):
   return f"The doors are barred to the {p['faction']} in {et_.name}."
  cs_=getattr(self,"click_station",None);self.click_station=None
  lead_near_=any(x.role in ("questgiver","king","dailygiver") and (x.x-p["x"])**2+(x.y-p["y"])**2<=2.6**2 for x in npcs)
  if (not clicked_npc and cs_ is None and not lead_near_) or cs_ is not None:
   _sdist=lambda k:min(((x-p["x"])**2+(y-p["y"])**2 for x,y in (self.station_posts or {}).get(k,())),default=1e9)
   for st_,nm_,tx_ in sorted((("teleport","Waygate","Spend 50 gold and a Scroll of Teleportation to travel to a friendly city."),("market","Trade Market","Prices change from town to town and day to day - buy cheap, sell dear."),("stable","Stable","Looking for a faster ride? Train your riding and pick a mount."),("bank","Bank","Your vault is safe with us. Gold kept here is never lost when you fall, and every Bank in the realm opens the same vault."),("enchanter","Magic Shop","Enchanted weapons, armor and jewelry for this zone's levels."),("smithy","Blacksmith","Weapons and armor for sale."),("general","General Store","Travel scrolls, bait, food and crafting materials."),("apothecary","Apothecary","Potions, herbs and buff scrolls."),("jeweler","Jeweler","Rings, amulets and fine gems - and a buyer for your trinkets."),("inn","Inn","Rest a while: the innkeeper brews potions and scrolls and cooks hot meals."),("kiln","Jeweler's Kiln","Cut jewels, craft rings and necklaces, and set jewels into socketed gear."),("magic","Skill Shop","Raise your spell ranks, spend stat points, choose passives and arrange your hotbar."),("warhall","War Hall","Enter the PvP battlegrounds, rally against city raids and find raid dungeons."),("forge","Forge","Forge weapons and armour up to Legendary tier here, or bring materials to the blacksmith."),("hut","Fishing Hut","Craft rods, bait and fish-oil tonics - and cook your catch."),("press","Wine Press","Press herbs into health and mana potions, or make Sunwine.")),key=lambda e:_sdist(e[0])):
    if cs_ is not None and cs_!=st_:continue
    if (cs_==st_ and self._near_station(st_,6.5)) or self._near_station(st_,5.0 if st_ in ("warhall","magic","inn","kiln","apothecary","jeweler","smithy","general","enchanter","bank","stable","market","teleport") else 3.8) and (st_ in ("warhall","magic","inn","kiln","apothecary","jeweler","smithy","general","enchanter","bank","stable","market","teleport") or not any((x.x-p["x"])**2+(x.y-p["y"])**2<=2.4**2 for x in npcs)):
     if st_=="forge":
      m=self.mythic_forge()          # 0.39: the Forge does the blacksmith's Mythic weapon step
      if m:return m
     self.open_ui="craft";self.craft_station={"forge":"forge","hut":"hut","press":"press","inn":"inn"}.get(st_,"")
     own=STATION_OWNER.get(st_)
     sk=min((a for a in self.actors if a.kind=="npc" and a.role==own),key=lambda a:(a.x-p["x"])**2+(a.y-p["y"])**2,default=None) if own else None
     self.shop_npc=sk.id if sk is not None else None
     if st_=="bank":self.open_ui="vault";return f"{nm_}: {tx_}"
     if st_=="stable":self.open_ui="stable";return f"{nm_}: {tx_}"
     if st_=="market":self.open_ui="market";return f"{nm_}: {tx_}"
     if st_ in ("apothecary","jeweler","smithy","general","enchanter"):
      if sk is None:return f"The {nm_} is closed."
      self.open_ui="shop";return f"{nm_}: {tx_}"
     if st_=="warhall":self.open_ui="warhall"
     if st_=="teleport":self.open_ui="teleport"
     if st_=="magic":self.open_ui="magic"
     if st_=="kiln":self.open_ui="kiln"
     return f"{nm_}: {tx_}"
  if not npcs:
   g=self.gather_herb()
   if g:return g
   g=self.mine_vein()
   if g:return g
   g=self.skin_carcass()
   if g:return g
   if self._dungeon_near():return self.enter_instance()
   if getattr(self,"water_near",None) and self.water_near(p["x"],p["y"]):return self.fish_action()
   near=[a for a in self.actors if a.kind=="adventurer" and a.hp>0 and (a.x-p["x"])**2+(a.y-p["y"])**2<=12]
   if near:
    pa=min(near,key=lambda a:(a.x-p["x"])**2+(a.y-p["y"])**2);self.open_ui="person";self.person_id=pa.id
    return self.greet_person(pa.id)
   return "Nothing nearby to interact with."
  n=min(npcs,key=lambda a:(a.x-p["x"])**2+(a.y-p["y"])**2)
  no_=self.refuse_service(n)
  if no_:return no_
  if n.role in ("questgiver","king","dailygiver"):
   self.open_ui="quests";self.shop_npc=n.id
   return f"{n.name}: "+("The realm has need of heroes, traveller." if n.role=="king" else "Daily tasks for the zones about - one of each, once every 24 hours." if n.role=="dailygiver" else "Take a look at the notice board - there is work to be done.")
  if n.role=="marketeer":
   self.open_ui="market";return f"{n.name}: Welcome to the Trade Market. Prices change from town to town and day to day - buy cheap, sell dear."
  if n.role in ("vendor","blacksmith","merchant","fishmonger","jeweler"):
   if n.role=="blacksmith":
    m=self.mythic_forge()
    if m:return m
   self.open_ui="shop";self.shop_npc=n.id
   greet={"vendor":"Potions, supplies and crafting materials — take a look.","blacksmith":"Fresh steel from the forge. Buy gear, or bring me materials and I'll forge your own.","merchant":"Rare goods from the road. Today only!","fishmonger":"Fresh from the water. Sell me your catch, or buy a fresh fish.","jeweler":"Rings, amulets and fine gems. Sell me any trinkets you do not need."}[n.role]
   return f"{n.name}: {greet}"
  if n.role=="banker":
   self.open_ui="vault";return f"{n.name}: Your vault is safe with us. Gold kept here is never lost when you fall, and every Banker in the realm opens the same vault."
  if n.role=="innkeeper":
   self.open_ui="craft";self.craft_station="inn";return f"{n.name}: Bring me herbs and fish - I'll brew potions and scrolls, and cook you a hot meal."
  if n.role=="guard":return f"{n.name}: Keep your weapons ready; the roads are dangerous."
  if n.role=="stablemaster":
   self.open_ui="stable";return f"{n.name}: Looking for a faster ride? Train your riding and pick a mount."
  return f"{n.name} has nothing to say."
 def _save_player_fast(self):
  self.db.execute("UPDATE player SET x=?,y=?,hp=?,gold=?,xp=?,level=?,kills=?,deaths=?,weapon=?,armor=?,spell=?,class=?,spec=? WHERE name=?",
   (self._save_pos()[0],self._save_pos()[1],self.player["hp"],self.player["gold"],self.player["xp"],self.player["level"],self.player["kills"],self.player["deaths"],self.player["weapon"],self.player["armor"],self.player["spell"],self.class_name(),self.spec_name(),self.player["name"]));self.db.commit()
 def _level_check(self):
  while self.player["level"]<LEVEL_CAP and self.player["xp"]>=xp_need(self.player["level"]):
   self.player["xp"]-=xp_need(self.player["level"]);self.player["level"]+=1;self.player["maxhp"]+=12;self.player["hp"]=self.player["maxhp"];self.player["mana"]=self.max_mana()
 def snapshot(self):
  a=self.area(self.player["x"],self.player["y"] if self.player["y"]<WORLD_H else 0)
  px,py=self.player["x"],self.player["y"]
  if self.inst:src=self.inst.actors.values()
  else:                         # 0.39: only the grid cells within 30 tiles, not every actor in the world, each frame
   g=self._grid();src=[x for cx in range((int(px)-31)>>3,((int(px)+31)>>3)+1) for cy in range((int(py)-31)>>3,((int(py)+31)>>3)+1) for x in g.get((cx,cy),())]
  tk=self.tick
  nearby=sorted((x for x in src if (x.x-px)**2+(x.y-py)**2<900 and not (x.kind=="imob" and x.hp<=0 and tk-getattr(x,"dead_tick",0)>10)),key=lambda x:(x.x-px)**2+(x.y-py)**2)[:260]
  ifx=[]
  if self.inst is not None and getattr(self.inst,"fxq",None):ifx=self.inst.fxq;self.inst.fxq=[]
  if getattr(self,"pfx",None):ifx=list(ifx)+self.pfx;self.pfx=[]      # 0.46.27: companions' attacks and heals in the open world
  sp=dict(self.player);sp["maxhp"]=self._effective_maxhp();sp["maxmana"]=self.max_mana();sp["outlaw"]=(self.outlaw_left()+3)//4
  cnt=self._counts()
  return {"player":sp,"abilities":self.ability_info(),"set_bonus":self._set_bonus(),"potions":self.db.execute("SELECT qty FROM inventory WHERE actor_id=0 AND item='Health Potion'").fetchone()["qty"],"target_id":getattr(self,"selected_target",None),"herbs":self.herbs_near(30),"city_raid":self.raid_info(),"raid_call":self.raid_call_info(),"city_result":self.__dict__.pop("city_result",None),"stock":self.stock(),"herb_list":self.herb_list(),
    "target":self._target_snap(),
    "loot":[{"id":r["id"],"x":r["x"],"y":r["y"],"item":r["item"],"rarity":r["rarity"],"power":r["power"],"slot":r["slot"],"cls":(r["class"] or ""),"left":r["expires"]-self.tick} for r in self.db.execute("SELECT * FROM ground_loot WHERE expires>?",(self.tick,)).fetchall()],
    "inventory":self.inventory_rows(),"pvp_status":self.pvp_status(),"area":(self.inst.d.name if self.inst else a[0]),"area_level":(f"{self.inst.level}" if self.inst else f"{a[6]}-{a[7]}"),"level_bracket":self.bracket_label(),"actors":[self._actor_snap(x) for x in nearby],"buffs":self.buff_info(),"passives":self.passive_info(),"move_speed":self.move_speed(),
   "player_hits":self._pop("player_hits"),"kill_events":self._pop("kill_events"),"charge_events":self._pop("charge_events"),
   "build":{"s":dict(self._build()["s"]),"g":self.gear_stats(),"stat_left":self.stat_points_left(),"rank_left":self.rank_points_left()},"mount":self.mount_info(),"spec":self.spec_name(),"role":self.spec_role(),"crit_chance":self.crit_chance(),
   "target_status":self._target_status(),"in_combat":self.tick-self.last_combat_tick<20,"hits_taken":self._pop_hits(),
   "events":self.events[-5:],"areas":len(AREAS),"monsters":cnt["monster"],"adventurers":cnt["adventurer"],"npcs":cnt["npc"],
   "quests":len(self.quests),"towns":len(self.towns),"dungeons":len(self.dungeons),"raid_dungeons":cnt["raid"],"parties":cnt["parties"],"pvp":self.player_pvp,
   "currency":self._currency(),"gear":self.gear(),"day":self.day,"hour":(self.tick//40)%24,"tick":self.tick,"instance":(self.inst.snapshot() if self.inst else None),"mythic":self.mythic_info(),"pparty":self.party_snapshot(),"quest_marks":self.quest_marks(),**self.rpg_snapshot(),"dungeon_near":self._dungeon_near(),"inst_fx":ifx,**self.people_snapshot(),**self.gather_snapshot(),"gains":self.gains_snapshot()}

 def _target_snap(self):
  a=self.by_id.get(getattr(self,"selected_target",None))
  if a is None or a not in self.actors:return None
  return {"id":a.id,"name":a.name,"level":a.level,"hp":a.hp,"maxhp":a.maxhp,"kind":("monster" if a.kind=="imob" else "adventurer" if a.kind=="ially" else a.kind)}
 def _counts(self):
  """Population counts for the snapshot, recounted once per tick instead of every frame."""
  c=self.__dict__.get("_cnt")
  if c is None or c[0]!=self.tick:
   k=collections.Counter(x.kind for x in self.actors)
   k["raid"]=sum(d.kind=="raid" for d in self.dungeons)
   k["parties"]=sum(1 for p in self.parties.values() if p["state"] not in ("done","rest"))
   c=self._cnt=(self.tick,k)
  return c[1]
 # ---- 0.10.0: monsters fight back, death/respawn, character creation ----
 def _aggro(self,t):
  if t.kind=="imob" and self.inst:self.inst.pulled_by(t)
  if t.kind=="monster" and t.hp>0:t.target=-2;t.state="hunt"
  self.last_combat_tick=self.tick
 def _pop_hits(self):
  h=self.hits_taken;self.hits_taken=[];return h
 def _in_safe_town(self):
  p=self.player
  return any((t.x-p["x"])**2+(t.y-p["y"])**2<TOWN_SAFE_R**2 and self.friendly_to(t,p["faction"]) for t in self.towns)
 def temper(self,a):
  # 0.44: every monster has a stable temperament: elites and one in three beasts are aggressive, some are territorial, the rest passive
  if a.name.startswith("Elite "):return "aggressive"
  k=(a.id*2654435761>>7)%10
  return "aggressive" if k<3 else "territorial" if k<7 else "passive"
 def _monster_player_ai(self):
  p=self.player;px,py=p["x"],p["y"];safe=self._in_safe_town()
  if self.is_flying():
   # flying riders are out of reach: monsters lose interest
   for a in self.actors:
    if a.kind=="monster" and a.target==-2 and a.role not in SOLDIER_ROLES:a.target=-1;a.state="wander"
   return
  mx=self._effective_maxhp();engaged=False
  for a in self.actors:
   if a.kind!="monster" or a.faction==p["faction"]:continue      # 0.35: your own side's soldiers never turn on you
   dx,dy=px-a.x,py-a.y;d2=dx*dx+dy*dy
   rd=a.role in SOLDIER_ROLES
   if rd and a.target!=-2 and d2<100:self._aggro(a)
   if a.target!=-2:
    # Hostile monsters notice you when you walk close (not inside towns).
    tm=self.temper(a)
    sight=13 if tm=="aggressive" else 6 if tm=="territorial" else 0
    if self._buff("stealth"):sight=min(sight,2)
    if not safe and sight and d2<sight*sight and (tm=="aggressive" or a.level>=p["level"]-6) and not rd and self.tick>=getattr(self,"_cb_ignore",{}).get(a.id,0):
     self._aggro(a)
     for b in self.actors_near(a,9,"monster"):      # pack mates join the pull
      if b.state=="pack" and b.target!=-2 and b.faction!=p["faction"]:self._aggro(b)
    else:continue
   d=math.sqrt(d2)
   if rd:
    if d>20:a.target=-1;continue
   elif d>(30 if self.temper(a)=="aggressive" else 20) or safe:
    a.target=-1;a.state="wander"
    if d>20:a.hp=a.maxhp  # leash: outrun a monster and it resets
    continue
   engaged=True
   if self._stunned(a):continue
   if d>1.2:self._move(a,px,py,.42)
   a.timer-=1
   if d<=1.6 and a.timer<=0:
    a.timer=8
    db=self._buff("dodge")
    ev=self._buff("evade")
    if self.rng.random()<(db["value"] if db else 0)+self.passive_fx("dodge")+(ev["value"] if ev else 0):
     self.hits_taken.append({"id":a.id,"dmg":0,"miss":True});self.last_combat_tick=self.tick;continue
    armor=p.get("armor",1)
    ab=self._buff("armor")
    df=self._buff("def")
    red=min(.8,self.passive_fx("armor_pct")+(ab["value"] if ab else 0)+(df["value"] if df else 0))
    dmg=(3+a.level*1.8)*(1.6 if a.name.startswith('Elite ') else 1)*self.rng.uniform(.8,1.25)*(1-min(.6,armor/(armor+180.)))*(1-red)
    if getattr(self,"mounted",None) and self.mount_power("ward"):dmg*=.75      # 0.45 Barding
    dmg=max(1,int(dmg))
    sh=self._buff("shield");absorbed=0
    if sh:
     absorbed=min(sh["absorb"],dmg);sh["absorb"]-=absorbed;dmg-=absorbed
    p["hp"]-=dmg;self.hits_taken.append({"id":a.id,"dmg":dmg,"absorbed":absorbed})
    self.last_combat_tick=self.tick
    if getattr(self,"mounted",None) and not self.is_flying() and not self.mount_power("steady"):
     self.mounted=None;self.events.append("You were knocked off your mount!")
    if p["hp"]<=0:self._player_died(a);return
  # 0.46.13: no real exchange (hit/cast) and no movement for 10s (40 ticks) -> drop the chase so "IN COMBAT" cannot stick
  # (e.g. a monster stuck across the river keeps 'engaging' you forever)
  if self.last_combat_tick==self.tick:self._cb_real=self.tick
  if (px,py)!=getattr(self,"_cb_pos",None):self._cb_pos=(px,py);self._cb_move=self.tick
  if engaged and self.tick-getattr(self,"_cb_real",0)>=40 and self.tick-getattr(self,"_cb_move",0)>=40:
   ign=self.__dict__.setdefault("_cb_ignore",{})
   for a in self.actors:
    if a.kind=="monster" and a.target==-2:a.target=-1;a.state="wander";ign[a.id]=self.tick+200
   self.last_combat_tick=self.tick-100;engaged=False
  if engaged:self.last_combat_tick=self.tick
  elif self.tick-self.last_combat_tick>20 and p["hp"]<mx:
   p["hp"]=min(mx,p["hp"]+max(1,mx//80))
  if p["hp"]>mx:p["hp"]=mx
 def _player_died(self,killer):
  self.mounted=None
  if self.inst:
   self.inst.on_player_death();self.last_combat_tick=self.tick-100;self._save_player_fast();return
  p=self.player
  for a in self.actors:
   if a.target==-2:a.target=-1;a.state="wander";a.hp=a.maxhp
  own=[t for t in self.towns if t.faction==p["faction"]] or self.towns
  t=min(own,key=lambda t:(t.x-p["x"])**2+(t.y-p["y"])**2)
  lost=p["gold"]//20;p["gold"]-=lost;p["deaths"]+=1
  if self.outlaw_left()>0:self._set_outlaw(False)      # 0.38: death pays for your crimes
  p["x"],p["y"]=t.x+1.5,t.y+1.5;p["hp"]=max(1,self._effective_maxhp()//2)
  kn=getattr(killer,"name",None) or "your wounds"          # 0.45: deaths with no attacker (hazards, damage over time) no longer crash
  self.events.append(f"You were slain by {kn}. You wake in {t.name} (-{lost}g).")
  self.last_combat_tick=self.tick-100;self._save_player_fast()
 def character_created(self):
  return self._meta("character_created","0")=="1"
 def create_character(self,name,faction,class_name,spec=None):
  name=(name or "").strip()[:16] or "Adventurer"
  if faction not in ("Alliance","Horde"):faction="Alliance"
  if class_name not in CLASSES:class_name="Warrior"
  old=self.player["name"]
  if name!=old and self.db.execute("SELECT 1 FROM player WHERE name=?",(name,)).fetchone():name=old
  self.db.execute("UPDATE player SET name=?,faction=?,class=? WHERE name=?",(name,faction,class_name,old))
  self.db.execute("UPDATE OR IGNORE player_currency SET name=? WHERE name=?",(name,old))
  self.db.execute("UPDATE OR IGNORE pvp_profile SET name=? WHERE name=?",(name,old))
  self.player.update(name=name,faction=faction,**{"class":class_name})
  if class_name in HYBRID_SPECS:self.set_class(class_name,spec)
  if self.player["level"]<=1 and self.player["xp"]==0:
   start="Greenfields" if faction=="Alliance" else "Ashen Vale"
   t=next((t for t in self.towns if t.area==start),self.towns[0])
   self.player["x"],self.player["y"]=t.x+1.5,t.y+1.5
  self._setmeta("character_created","1");self.db.commit();self._ensure_player_progression();self._save_player_fast()
  return f"Welcome, {name} the {faction} {class_name}."
 # ---- 0.12.0: walkable dungeons, boss mechanics, Heroic raid, Mythic quests ----
 def _save_pos(self):
  if self.inst:return self.inst.return_pos
  return self.player["x"],self.player["y"]
 def _actor_snap(self,x):
  d={"id":x.id,"name":x.name,"faction":x.faction,"level":x.level,"x":x.x,"y":x.y,"hp":x.hp,"maxhp":x.maxhp,"kind":x.kind,"role":x.role,"state":x.state,"party":x.party,"aggro":x.target==-2,"stun":x.id in self.mstatus and self.mstatus[x.id].get("stun",0)>self.tick,"dot":bool(self.mstatus.get(x.id,{}).get("dot"))}
  if x.state=="pparty":d["pmember"]=True
  if x.kind=="adventurer":self.person_snap_fields(x,d)
  elif x.kind=="npc" and self._guard_hostile(x):d["hostile"]=True;d["atk"]=getattr(x,"atk_tick",-99)
  if x.kind=="npc" and (x.role in HIDDEN_ROLES or (x.role in LEADER_ROLES and x.hp<=0)):d["hidden"]=True
  elif x.kind=="npc" and self.leader_attackable(x):d["hostile"]=True
  if x.role in SOLDIER_ROLES:
   d["soldier"]=x.role
   d["look"]=getattr(x,"look","Orc");d["boss"]=getattr(x,"warlord",False);d["scale"]=getattr(x,"scale",1.0);d["aggro"]=x.target==-2;d["temper"]=self.temper(x)
  if getattr(x,"pvp",False):
   d["kind"]="adventurer";d["role"]=x.cls;d["ally"]=(x.team=="blue");d["aggro"]=False;d["rrole"]=x.rrole;d["hp"]=max(0,int(x.hp));d["name"]=x.name+(" [FLAG]" if getattr(x,"has_flag",False) else "")
   if x.dead:d["hp"]=0
  elif x.kind=="imob":
   d["kind"]="monster";d["look"]=getattr(x,"look","Skeleton");d["boss"]=(x.role=="boss");d["aggro"]=(x.state=="fight");d["scale"]=getattr(x,"scale",1.0)
   d["atk"]=getattr(x,"atk_tick",-99)
   if x.hp<=0:d["hp"]=0;d["dead"]=True;d["dead_age"]=(self.tick-getattr(x,"dead_tick",self.tick))/4.0
  elif x.kind=="ially":
   d["kind"]="adventurer";d["role"]=x.role;d["ally"]=True;d["rrole"]=getattr(x,"rrole","DPS");d["aggro"]=False
   d["atk"]=getattr(x,"atk_tick",-99)
   if getattr(x,"dead",False):d["hp"]=0;d["dead"]=True;d["corpse"]=True
  return d
 def _dungeon_near(self):
  if self.inst:return None
  p=self.player
  c=[d for d in self.dungeons if (d.x-p["x"])**2+(d.y-p["y"])**2<=36]
  if not c:return None
  d=min(c,key=lambda d:(d.x-p["x"])**2+(d.y-p["y"])**2)
  need=91 if d.kind=="heroic" else max(1,d.level-12)
  return {"id":d.id,"name":d.name,"kind":d.kind,"level":d.level,"boss":d.boss,"need":need,"ok":p["level"]>=need,"size":{"dungeon":4,"raid":12,"heroic":12}.get(d.kind,d.size)}
 def _ensure_heroic(self):
  for zn in ("Wyrmreach","Shadowlands"):            # 0.35.1: one heroic entrance per side
   if any(d.kind=="heroic" and d.area==zn for d in self.dungeons):continue
   nid=max((d.id for d in self.dungeons),default=0)+1
   ar=next(a for a in AREAS if a[0]==zn)
   d=Dungeon(nid,f"{zn} HEROIC — Throne of the Void Sovereign",zn,ar[1]+ar[3]*.55,ar[2]+ar[4]*.85,100,"Malachar, the Void Sovereign",30000,0,0,0,10,"heroic")
   self.dungeons.append(d)
   self.db.execute("INSERT OR IGNORE INTO dungeons VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(d.id,d.name,d.area,d.x,d.y,d.level,d.boss,d.boss_hp,d.active,d.party,d.cooldown,d.size,d.kind))
  self.db.commit()
 def _instance_tick(self):
  if self.inst:
   m=getattr(self,"mounted",None)       # 0.42: no mounts in dungeons or raids; 0.45: battleground mounts are allowed in battlegrounds
   if m and not (self.in_battleground() and MOUNTS_ALL.get(m,{}).get("bg")):self.mounted=None
   self.inst.tick()
 def enter_instance(self):
  if getattr(self,"mounted",None) and not self.inst:self.mounted=None
  from . import instance as I
  if self.inst:return "You are already inside a dungeon."
  nd=self._dungeon_near()
  if not nd:return "Stand next to a dungeon entrance to go in."
  if not nd["ok"]:return f"{nd['name']} requires level {nd['need']}."
  d=next(x for x in self.dungeons if x.id==nd["id"])
  inst=I.Instance(self,d);inst.return_pos=(d.x,d.y+3.2)
  self.inst=inst;I.ACTIVE=inst
  for a in inst.actors.values():
   self.actors.append(a);self.by_id[a.id]=a
  self.player["x"],self.player["y"]=inst.spawn
  self.selected_target=None;self.mstatus.clear();self.buffs.clear()
  for a in self.actors:
   if a.target==-2 and a.kind=="monster":a.target=-1;a.state="wander"
  self.events.append(f"You enter {d.name}. Party: {len(inst.allies)+1} adventurers.")
  return f"You enter {d.name}. Your party of {len(inst.allies)+1} follows you in. Use the portal at the entrance (F) to leave, or press O to open an exit portal anywhere."
 def enter_arena(self,mode):
  if getattr(self,"mounted",None) and not self.inst:self.mounted=None
  from . import instance as I
  from . import arena as A
  if self.inst:return "Leave your current instance first."
  if self.player_pvp:return "You are busy."
  if mode not in A.MODES:return "Unknown arena mode."
  if self.player["level"]<5:return "Arena PvP unlocks at level 5."
  inst=A.Arena(self,mode)
  self.inst=inst;I.ACTIVE=inst
  for a in inst.actors.values():
   self.actors.append(a);self.by_id[a.id]=a
  self.player["x"],self.player["y"]=inst.spawn
  self.selected_target=None;self.mstatus.clear();self.buffs.clear()
  self.player["hp"]=self._effective_maxhp();self.player["mana"]=self.max_mana()
  for a in self.actors:
   if a.target==-2 and a.kind=="monster":a.target=-1;a.state="wander"
  self.events.append(f"You enter the arena: {A.MODES[mode]['title']}.")
  return f"{A.MODES[mode]['title']} begins! {A.MODES[mode]['desc']}"
 def open_exit_portal(self):
  """Cast an exit portal anywhere inside a dungeon, raid or arena (button / key O)."""
  if not self.inst or not hasattr(self.inst,"open_portal"):return "You are not inside a dungeon."
  return self.inst.open_portal()
 def instance_ready(self):
  if not self.inst or not hasattr(self.inst,"ready"):return ""
  return self.inst.ready()
 def leave_instance(self,silent=False):
  from . import instance as I
  inst=self.inst
  if not inst:return "You are not inside a dungeon."
  if hasattr(inst,"on_leave"):inst.on_leave()
  ids=set(inst.actors)
  self.actors=[a for a in self.actors if a.id not in ids]
  for i in ids:self.by_id.pop(i,None);self.mstatus.pop(i,None)
  self.player["x"],self.player["y"]=inst.return_pos
  self.inst=None;I.ACTIVE=None;self.selected_target=None
  self.player["hp"]=max(1,min(self._effective_maxhp(),self.player["hp"]))
  if not silent:
   self.events.append("You leave the dungeon.");self._save_player_fast()
  return "You step through the portal and leave the dungeon."
 def damage_player(self,raw,src,src_id=0,mech=False):
  """Damage to the player from an instance monster. mech=True: boss mechanics (no armour/dodge, shield still absorbs)."""
  p=self.player
  if p["hp"]<=0:return 0
  db=self._buff("dodge")
  if not mech and self.rng.random()<(db["value"] if db else 0)+self.passive_fx("dodge"):
   self.hits_taken.append({"id":src_id,"dmg":0,"miss":True});self.last_combat_tick=self.tick;return 0
  ab=self._buff("armor")
  red=min(.8,self.passive_fx("armor_pct")+(ab["value"] if ab else 0))
  if mech:dmg=raw*(1-red*.6)
  else:
   armor=p.get("armor",1);dmg=raw*(1-min(.6,armor/(armor+180.)))*(1-red)
  if getattr(self,"mounted",None) and self.mount_power("ward"):dmg*=.75      # 0.45 Barding
  dmg=max(1,int(dmg))
  sh=self._buff("shield");absorbed=0
  if sh:
   absorbed=min(sh["absorb"],dmg);sh["absorb"]-=absorbed;dmg-=absorbed
  p["hp"]-=dmg;self.hits_taken.append({"id":src_id,"dmg":dmg,"absorbed":absorbed,"mech":mech})
  self.last_combat_tick=self.tick
  if p["hp"]<=0:
   if self.inst:self.inst.stats.setdefault("killers",{}).setdefault(getattr(src,'name','?')[:18]+(' (mech)' if mech else ''),0);self.inst.stats["killers"][getattr(src,'name','?')[:18]+(' (mech)' if mech else '')]+=1
   self._player_died(src)
  return dmg
 # ---- instance loot and rewards
 def _inst_rarity(self,kind,tier):
  r=self.rng.random()
  if tier=="trash":
   # 0.40: dungeons drop really good gear; raids drop the best (and are the only place set pieces come from)
   t={"dungeon":(("Rare",.45),("Epic",.85),("Elite",1)),"raid":(("Epic",.5),("Elite",.92),("Legendary",1)),"heroic":(("Epic",.3),("Elite",.88),("Legendary",1))}[kind]
  else:
   t={"dungeon":(("Epic",.5),("Elite",.93),("Legendary",1)),"raid":(("Elite",.62),("Legendary",1)),"heroic":(("Elite",.42),("Legendary",1))}[kind]
  for name,c in t:
   if r<=c:return name
  return t[-1][0]
 def _inst_item(self,rarity,slot):
  if rarity=="Legendary":
   return {"weapon":"Dawnbreaker, Heart of the Lion","armor":"Worldrender, Titanplate","helm":"Starfire, Crown of Ages","trinket":"Eternity's Hourglass","ring":"Band of the First Dawn"}[slot] if self.rng.random()<.5 else {"weapon":"Nightfall, Edge of Eternity","armor":"Mantle of the Last Dawn","helm":"Crown of the Long Night","trinket":"Heart of the Titan","ring":"Signet of the Long Night"}[slot]
  pre=self.rng.choice(("Runed","Dungeon-forged","Vaulted","Ancient","Gilded","Warded"))
  return f"{rarity} {pre} {self.gear_word(slot)}"
 def drop_instance_loot(self,x,y,level,kind,tier,source):
  rarity=self._inst_rarity(kind,tier)
  return self._drop_inst_rarity(x,y,level,rarity,source)
 def _drop_inst_rarity(self,x,y,level,rarity,source):
  slot=self.rng.choice(("weapon","armor","helm","trinket","ring"))
  power=min(168,int(level*1.2)+RARITY_POWER[rarity]+self.rng.randint(0,6))
  item=self._inst_item(rarity,slot)
  cls=self.class_name() if rarity in ("Epic","Elite","Legendary") else ""
  self.db.execute("INSERT INTO ground_loot(x,y,item,qty,rarity,power,slot,source,expires,class) VALUES(?,?,?,?,?,?,?,?,?,?)",(x,y,item,1,rarity,power,slot,source,self.tick+LOOT_TTL,cls))
  self.db.commit()
  return rarity
 def add_instance_boss_rewards(self,inst,b):
  d=inst.d;kind=inst.kind;n=1 if kind=="dungeon" else 2          # 0.35.1: one drop per dungeon boss, two per raid boss
  got=[]
  for i in range(n):
   got.append(self.drop_instance_loot(b.x+self.rng.uniform(-1.4,1.4),b.y+self.rng.uniform(-1.4,1.4),inst.level,kind,"boss",b.name))
  if kind!="dungeon" and b.final:self._add_currency(raid=1,essence=1)       # 0.35.1: one Raid Token and one Essence per full clear
  ess=self.rng.randint(1,2) if kind!="dungeon" else self.rng.randint(0,1)
  if ess:self._inv_add("Mat:Spirit Essence",ess);self.db.commit();self.gain("Mat:Spirit Essence",ess)
  self.quest_event("boss")
  self.events.append(f"{b.name} is defeated! Loot dropped ({', '.join(got)}).")
  if kind in ("raid","heroic") and b.final:
   self._raid_loot(d)
  if kind=="heroic" and b.final:
   if self.rng.random()<.004 and self.player["level"]>=91:
    m=self._grant_mythic(source="Void Sovereign (rare drop)")
    if m:self.events.append(m)
  # quest events
  if self.player["level"]>=91:
   if kind=="heroic":
    self.mythic_event("hboss",idx=b.idx)
    if b.final:self.mythic_event("hclear")
   elif b.final and inst.level>=91:self.mythic_event("dgboss")
 def add_instance_clear_rewards(self,inst):
  p=self.player;kind=inst.kind
  gold=int(inst.level*{"dungeon":15,"raid":35,"heroic":90}[kind]);xp=int(inst.level*{"dungeon":150,"raid":300,"heroic":750}[kind])
  p["gold"]+=gold;p["xp"]+=xp;self._level_check()
  if kind=="heroic" and p["level"]>=91 and inst.ally_deaths==0 and inst.player_deaths==0:self.mythic_event("flawless")
  self.events.append(f"Dungeon cleared in {int((self.tick-inst.t0)/4)}s: +{gold}g +{xp} XP"+(" (flawless!)" if inst.ally_deaths==0 and inst.player_deaths==0 else "")+".")
  self._save_player_fast()
 def close(self):
  if getattr(self,"_closed",False):return          # 0.34.2: safe to call twice (reset path + final cleanup)
  self._closed=True
  try:
   for step in (lambda:self.inst and self.leave_instance(silent=True),lambda:self.player_pvp and self._pvp_restore(self.player_pvp)):
    try:step()
    except Exception:traceback.print_exc()        # 0.37.2: a failure leaving a dungeon or arena must not skip the save
   self._save_all(force=True)
   self._backup()
  finally:
   self.db.close()
 def _backup(self):
  """0.37.2: after a clean save keep a copy (world.db.bak) that open_world() restores if the save is ever damaged."""
  try:
   tmp=DB.with_name(DB.name+".bak.tmp")
   dst=sqlite3.connect(tmp)
   try:self.db.backup(dst)
   finally:dst.close()
   os.replace(tmp,DB.with_name(DB.name+".bak"))
  except Exception:traceback.print_exc()

def _db_ok(path):
 try:
  c=sqlite3.connect(path)
  try:return c.execute("PRAGMA quick_check").fetchone()[0]=="ok"
  finally:c.close()
 except sqlite3.DatabaseError:return False

def open_world():
 """0.37.2: open the save; a damaged one is moved aside (never deleted) and the last clean backup is restored,
 or a new world starts. Returns (world, message or None)."""
 if not DB.exists() or _db_ok(DB):
  try:return World(),None
  except sqlite3.DatabaseError:traceback.print_exc()
 stamp=time.strftime("%Y%m%d-%H%M%S")
 for suf in ("","-wal","-shm"):
  f=DB.with_name(DB.name+suf)
  if f.exists():os.replace(f,DB.with_name(f"{DB.name}{suf}.damaged-{stamp}"))
 bak=DB.with_name(DB.name+".bak")
 if bak.exists() and _db_ok(bak):
  import shutil
  shutil.copyfile(bak,DB)
  try:return World(),"Your save was damaged; it was restored from the last clean exit."
  except sqlite3.DatabaseError:
   traceback.print_exc();os.replace(DB,DB.with_name(f"{DB.name}.bak-damaged-{stamp}"))
 return World(),f"Your save was damaged and could not be restored; a new world was started. The old file was kept as {DB.name}.damaged-{stamp}."
