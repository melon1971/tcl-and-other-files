GTK Desktop Monitor for Debian 13 (trixie)

This package provides a lightweight GTK3 desktop monitor with one-second
updates. It displays CPU, RAM, swap, root filesystem, load, uptime, kernel,
OS, temperature, and battery information when available.

Network addresses are intentionally not collected, read, stored, or displayed.
The program does not inspect /proc/net or network interface configuration.

Launch manually with:
  gtk-desktop-monitor

A desktop launcher is installed. Automatic startup is enabled for common GTK
sessions (GNOME, XFCE, LXDE, LXQt, MATE, Cinnamon, Unity). KDE Plasma users
should use the KDE package or launch this GTK monitor manually if desired.

Right-click the monitor to close it. On X11, left-drag moves it.

Security hardening in 1.0.1:
  - No shell commands or subprocesses are used.
  - Temperature discovery does not follow symlinked sysfs directories.
  - Optional kernel/system values are validated and degrade to n/a safely.
