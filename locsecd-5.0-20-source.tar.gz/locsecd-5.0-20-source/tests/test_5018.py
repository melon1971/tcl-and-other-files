#!/usr/bin/python3
"""5.0-18 checks, no root needed: the locsecd-web profile lets pgrep read other processes' details (in enforce mode
a real machine logged apparmor="DENIED" operation="ptrace" profile="locsecd-web" comm="pgrep" peer="unconfined"),
and, given locsec-vm-check.sh, its enforce-readiness report no longer says "nothing was blocked" after a DENIED line.
Usage: test_5018.py path/to/locsecd.py [path/to/locsec-vm-check.sh]"""
import sys, os, re, shutil, subprocess, tempfile
HERE = os.path.dirname(os.path.abspath(sys.argv[1]))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
src = open(sys.argv[1]).read()
prof = open(os.path.join(ROOT, 'etc/apparmor.d/locsecd')).read()
# Each profile on its own: test_507 looked for the rule anywhere in the file, so the broker's copy hid that the web one had none.
web = prof[prof.index('profile locsecd-web '):prof.index('profile locsecd-broker ')]
broker = prof[prof.index('profile locsecd-broker '):]
rule = re.compile(r'^\s*ptrace read peer=unconfined,\s*$', re.M)
check("the web half runs pgrep (external_aide), so its profile needs the ptrace rule", "['pgrep','-a','-f'" in src and '/usr/bin/pgrep ix,' in web)
check('locsecd-web has: ptrace read peer=unconfined,', bool(rule.search(web)))
check('locsecd-broker still has: ptrace read peer=unconfined,', bool(rule.search(broker)))
check('locsecd-web allows ptrace read only (no trace, no other peer)', not re.search(r'^\s*ptrace\s+(?!read peer=unconfined,)', web, re.M))
check('the version is 5.0-18 or later', re.search(r"VERSION_FALLBACK='5\.0-(1[89]|[2-9][0-9])'", src) is not None)
ap = shutil.which('apparmor_parser') or ('/usr/sbin/apparmor_parser' if os.path.exists('/usr/sbin/apparmor_parser') else None)
if ap:
    r = subprocess.run([ap, '-Q', '-K', os.path.join(ROOT, 'etc/apparmor.d/locsecd')], capture_output=True, text=True)
    check('apparmor_parser accepts the profile', r.returncode == 0)
if len(sys.argv) > 2:
    # The enforce-readiness report of locsec-vm-check.sh on its own, with both profiles in enforce mode and no ALLOWED lines.
    sh = open(sys.argv[2]).read()
    block = sh[sh.index('  echo "== AppArmor enforce readiness'):sh.index('echo "== ClamAV =="')]
    d = tempfile.mkdtemp()
    open(os.path.join(d, 'profiles'), 'w').write('locsecd-web (enforce)\nlocsecd-broker (enforce)\n')
    open(os.path.join(d, 'klog'), 'w').write('')
    harness = ('atleast(){ return 0; }; ok(){ echo "PASS  $*"; }; warn(){ echo "WARN  $*"; }; bad(){ echo "FAIL  $*"; }\n'
               'MINE="$1"\nif true; then\n' + block)
    env = dict(os.environ, LOCSEC_VMCHECK_AAPROFILES=os.path.join(d, 'profiles'), LOCSEC_VMCHECK_KLOG=os.path.join(d, 'klog'))
    denied = ('Oct 16 03:41:03 homebox kernel: audit: type=1400 audit(1792140063.298:203): apparmor="DENIED" operation="ptrace" '
              'class="ptrace" profile="locsecd-web" pid=315083 comm="pgrep" requested_mask="read" denied_mask="read" peer="unconfined"')
    out = subprocess.run(['bash', '-c', harness, 'readiness', denied], capture_output=True, text=True, env=env).stdout
    check('readiness after a DENIED line: a warning, not "nothing was blocked"', 'WARN' in out and '1 DENIED line' in out and 'nothing was blocked' not in out)
    out = subprocess.run(['bash', '-c', harness, 'readiness', ''], capture_output=True, text=True, env=env).stdout
    check('readiness with no DENIED line: still "nothing was blocked"', re.search(r'^PASS .*nothing was blocked', out, re.M) is not None and 'WARN' not in out)
    shutil.rmtree(d)
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
