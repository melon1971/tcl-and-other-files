# Scanistry 5.0

Scanistry is a local host-security controller for 24/7 background operation. It
installs as the native Qt6 desktop build on Debian 12 and 13, Ubuntu 24.04 LTS, 26.04 LTS and 26.10,
Linux Mint 22, and LMDE 6 and 7 (amd64).

Release status (5.0-25): a small fix. URLhaus switched off its keyless downloads on 2026-10-23 (HTTP 410 Gone), so
Scanistry drops the old address and downloads URLhaus again once you set "urlhaus_auth_key" to a free abuse.ch Auth-Key.
The Logs page no longer tells you to check your network connection when a list has been retired (see CHANGELOG-5.0-25).

5.0-24: a small fix. The debsecan report no longer lists fixes that are already installed as waiting (see CHANGELOG-5.0-24).

5.0-23: blocked domains. A domain name (an advert or tracker from a DNS-lookup alert) can be blocked for
every program on this computer, in Scanistry's own section of /etc/hosts: "Fix it" on the alert, the new Blocked domains
card on Firewall & Blocks (both need sudo scanistryctl approve ID), sudo scanistryctl block-domain NAME, or block_domains
in scanistry.conf. Outbound alerts now give an exact ss filter, and a DNS lookup is explained as one (see CHANGELOG-5.0-23).

5.0-22: a small fix. The AIDE report explains the timers.target.wants folder that Scanistry's installer
changes when it switches off the aide package's daily check (see CHANGELOG-5.0-22).

5.0-21: a small fix. The scanistry-web AppArmor profile lets the dashboard read the clamd local
override that the AIDE report checks for Scanistry's own rule, which enforce mode refused (see CHANGELOG-5.0-21).

5.0-19: a small fix. AIDE reports explain the links and folders that sudo systemctl
enable/disable/mask and sudo update-rc.d change, from sudo's lines in the journal, instead of calling them not
explained and advising a reinstall (see CHANGELOG-5.0-19).

5.0-18: a small fix. The scanistry-web AppArmor profile lets pgrep read other processes' details,
which enforce mode refused on a real machine (the Scans page could miss an AIDE run another program started), and
scanistry-vm-check.sh no longer calls enforce mode clean after a DENIED line (see CHANGELOG-5.0-18).

5.0-17: a small fix. feed_auto_block_limit now counts only new blocks per refresh, so threat-feed
blocks no longer stop for good at the first 500 entries of the feeds; a failed Unblock no longer drops the block
from the list while the firewall keeps it (see CHANGELOG-5.0-17).

5.0-16: a small fix. sudo scanistryctl approve -y ID now works (the ID and -y can come in either
order), and approve asks on stdin when /dev/tty is not available (see CHANGELOG-5.0-16).

5.0-15: a fix. sudo scanistryctl apparmor enforce and status now count AppArmor log lines
since the broker last started, not over the whole boot, so lines an earlier profile logged before an upgrade
no longer block the switch to enforce mode, and the scanistry-web profile may read /var/log/dpkg.log* for the
AIDE explanations, and an AIDE or rkhunter scan that found something is no longer shown as a Problem on the
Logs page (see CHANGELOG-5.0-15).

5.0-14: hardening release. Turning the firewall off, opening a port, stopping or disabling a service,
replacing the AIDE baseline and forced or clean-file quarantine now need an administrator's approval
(sudo scanistryctl approve ID) when the dashboard asks for them; Scanistry's AppArmor profiles load in enforce mode (with a
data-driven fallback to complain mode on upgrade, and sudo scanistryctl apparmor to switch); the broker may write only three
lock files in /run instead of all of it; the dashboard runs without inline script ('unsafe-inline' is gone from its
Content-Security-Policy); four kernel settings are added and the sysctl file's end-of-line comments are fixed.
5.0-14 is not yet installed on a real machine: install it in a VM first and run scanistry-vm-check.sh, which checks
the 5.0-14 changes too (see CHANGELOG-5.0-14). See CHANGELOG-5.0-14 and the earlier changelogs.

Note: Debsecan's vulnerability feed is keyed to Debian package versions and is
not reliable on Ubuntu/Mint, since Ubuntu ships different package versions
under the same names. On Ubuntu and Mint, Debsecan is skipped automatically and
CVE/update checks rely on `apt-get`'s Ubuntu security-pocket candidates
instead, which is accurate for this distro.

## Native desktop installation

The native GUI is a Qt6 application with the dashboard embedded through QtWebEngine.
It does not normally open an external web browser. This package makes
python3-pyqt6, python3-pyqt6.qtwebengine, rsyslog, xdg-utils and libnotify-bin
hard dependencies so an APT-aware installation pulls in the complete desktop stack.
Use `sudo apt install ./scanistry_<version>_amd64.deb` from a terminal; raw `dpkg -i` does not resolve
and download dependencies, and the GDebi graphical installer is not recommended (it can fail with a
GTK/VTE error and look frozen). The persistent tray/panel icon remains enabled through
`/etc/xdg/autostart/scanistry-tray.desktop`.


- UFW integration with nftables fallback
- persistent automatic IP blocking
- built-in port-scan detection from the firewall log (replaces PortSentry; opens no ports)
- authentication success/failure monitoring with a configurable time window
- ClamAV and freshclam integration
- AIDE, Lynis, Debsecan/CVE and rkhunter scans
- tcpdump/tshark packet capture
- continuously refreshed IP/domain IOC feeds
- optional automatic enforcement of feed IP indicators
- Debian security/package update integration

## Idle scanning

Heavy scans run only after the configured load has remained below `idle_load` for
`idle_seconds`. The normal scan interval is six hours.

Scanistry does not wake a suspended or hibernated computer to run scans. While a job is
running it holds a systemd-logind sleep inhibitor (and ignores lid close) so the job is
not frozen halfway; see `inhibit_sleep_during_jobs` and `inhibit_lid_switch`.

## Automatic remediation

Remediation is a fixed rule per incident type, chosen by the daemon and nothing
else. Package remediation is performed through Debian's package-management
mechanisms and is recorded as changed package versions in the update result.

Malware deletion is restricted to files already inside Scanistry's quarantine area.

## Network capture

Packet captures remain local under `/var/lib/scanistry/captures` and can be opened
with Wireshark. Analyze uses a built-in, memory-safe header reader; the optional
Deep analysis runs tshark sandboxed as a throwaway unprivileged user.


3.4 adds persistent incident history, IPv4/IPv6 nftables containment, configurable automatic-response policy, IPv6 port-scan event parsing, ClamAV daemon scan preference, and reboot-required reporting after package updates.


Threat-intelligence feeds refresh twice per day by default (`feed_interval=43200`). Repeated feed indicators are deduplicated into one active incident with a count and last-seen timestamp. Investigate/Contain/Resolve actions now return an action log explaining what Scanistry did, why it did it, and the relevant command/output, with an **OK** button to close the result.

Threat-intelligence feeds refresh twice per day by default (feed_interval=43200). Repeated feed indicators are deduplicated into one active incident with a count and last-seen timestamp. Investigate/Contain/Resolve actions return an action log explaining what Scanistry did, why it did it, and the relevant command/output, with an OK button to close the result.

## Resource controls

Scanistry 4.0.4 expires automatic firewall blocks after 30 days and removes their corresponding UFW/nftables entries. Repeated detections of an already-active block do not create another firewall rule or ban. Heavy background scans are started with low CPU priority and idle I/O.

## Incident Confirm

The Incidents page replaces the per-incident Delete button with Confirm. Confirm asks for operator confirmation, collects bounded local evidence, then performs only fixed remediation appropriate to the incident type: network containment for hostile addresses, ClamAV quarantine for detected malware, and APT package remediation for high/critical CVE findings. Each action is recorded in the incident action log and a JSON incident report.

Threat-feed entries are indicators of concern, not proof that the listed address connected to this host.

## 4.0.4 logging behavior
Threat-intelligence feed inventory is not recorded as incidents or per-IP operational log entries. Feed addresses may still be enforced by the firewall when feed blocking is enabled, but the incident stream is reserved for observed security events. Authentication logging records both successful and denied attempts in Scanistry's own log (successful ones at INFO, denied ones at WARN) while `log_auth_each_attempt` is true, which is the default. Setting it to false keeps the per-attempt lines out of the log; detection, counting and automatic blocking are unaffected.


4.0.11-10 hardening: dashboard report reads are bounded by the configured report-size limits to prevent oversized JSON from exhausting system memory.

## AIDE baseline lifecycle

Scanistry never overwrites an existing `/var/lib/aide/aide.db` through the normal Initialize AIDE action. If a valid active database exists, Scanistry reports that AIDE is already initialized. Debian's daily AIDE job may also leave `/var/lib/aide/aide.db.new` beside it; this is a pending baseline for administrator review.

Use `scanistryctl aide-accept` only after reviewing the differences. Scanistry validates the pending database, makes it `root:root` mode `0600`, retains the previous active database as `aide.db.scanistry-backup`, and atomically promotes the pending file. Use `scanistryctl aide-reinitialize` when you intentionally want a completely fresh replacement baseline. Do not manually copy `aide.db.new` over `aide.db`.

