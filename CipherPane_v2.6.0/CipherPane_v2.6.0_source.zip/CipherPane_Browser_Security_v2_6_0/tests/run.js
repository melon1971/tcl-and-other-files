// Run: node tests/run.js   (no dependencies)
"use strict";
global.self = global;
const assert = require("assert");
const fs = require("fs");
const path = require("path");
require("../lists.js");
require("../reputation.js");
const L = CipherLists;
const R = CipherReputation;
let n = 0;
function t(name, fn) { fn(); n++; console.log("ok -", name); }
const dl = (f, mode, trusted, extra) => L.checkDownload(Object.assign({ url: "https://files.example/d", filename: f }, extra || {}), { mode, trusted: trusted || [] });

// ---- parser ----
t("parser formats", () => {
  assert.deepStrictEqual(L.domainsFromLine("0.0.0.0 ads.example.com # c"), ["ads.example.com"]);
  assert.deepStrictEqual(L.domainsFromLine("||t.example.net^"), ["t.example.net"]);
  assert.deepStrictEqual(L.domainsFromLine("||t.example.net^$third-party"), []);
  assert.deepStrictEqual(L.domainsFromLine("@@||ok.example.com^"), []);
  assert.deepStrictEqual(L.domainsFromLine("a_b.example.com"), []);
});
t("parser has no quadratic blow-up", () => {
  const s = "a.com" + " ".repeat(2000000) + "x";
  const t0 = Date.now(); L.domainsFromLine(s); assert(Date.now() - t0 < 200);
  const big = ("x".repeat(1500) + "\n").repeat(1000);
  const t1 = Date.now(); L.parseFilterLines(big); assert(Date.now() - t1 < 500);
});
t("host helpers", () => {
  assert(L.isPrivateHost("[::ffff:7f00:1]"));
  assert(L.isPrivateHost("[::ffff:a00:1]"));
  assert(!L.isPrivateHost("[::ffff:808:808]"));
  assert(L.isPrivateHost("192.168.1.5") && !L.isPrivateHost("8.8.8.8"));
});

// ---- local lookalike / homoglyph reputation ----
t("lookalike detection catches typos, homoglyphs, digit swaps and bait names", () => {
  for (const h of ["paypa1.com", "gogle.com", "paypla.com", "rnicrosoft.com", "g00gle.com", "\u0440\u0430\u0443\u0440\u0430l.com", "pay-pal.com",
                   "paypal-login.com", "secure-paypal.net", "paypal.com.evil.test", "login.paypal.evil.test", "paypal.top", "paypa1.co.uk",
                   "amaz0n.co.uk", "app1e.com", "faceb00k.com", "g\u0456thub.com", "micr\u043esoft.com"])
    assert(R.scoreHost(h).score >= 70, h);
  assert.strictEqual(R.scoreHost("micros oft.com").score, 0);
});
t("legitimate sites are not flagged (false-positive regression set)", () => {
  for (const h of ["github.io", "amazon.es", "google.es", "paypal.me", "apply.com", "ample.com", "case.com", "phase.com", "1.com", "0.com",
                   "a1.example.org", "www.apple.org", "chase.org", "facebook.github.io", "google.github.io", "microsoft.github.io",
                   "mail.google.com", "docs.google.com", "www.amazon.co.uk", "example.org", "1.1.1.1", "localhost", "m\u00fcnchen.de",
                   "b\u00fccher.de", "applepie.com", "ebay.com", "pay.example.com"])
    assert.strictEqual(R.scoreHost(h).score < 70, true, h + " -> " + JSON.stringify(R.scoreHost(h)));
});
t("domain parsing uses the registrable name for two-part suffixes", () => {
  assert.deepStrictEqual(R.parseHost("a.b.example.co.uk"), { labels: ["a", "b", "example", "co", "uk"], rootIdx: 2, tld: "uk" });
  assert.strictEqual(R.parseHost("example.com").rootIdx, 0);
});
t("user allow-list suppresses local heuristic", () => {
  assert.strictEqual(R.scoreHost("paypa1.com", ["paypa1.com"]).score, 0);
  assert.strictEqual(R.scoreHost("login.paypa1.com", ["paypa1.com"]).score, 0);
});
t("edit distance is bounded and counts a swap as one edit", () => {
  assert.strictEqual(R.editDistance("paypal", "paypa1", 1), 1);
  assert.strictEqual(R.editDistance("paypal", "paypla", 1), 1);
  assert(R.editDistance("paypal", "unrelated", 1) > 1);
});

// ---- settings import sanitizer ----
t("settings import keeps only known, valid values", () => {
  const out = L.sanitizeSettings({ malwareEnabled: false, adsEnabled: "yes", downloadGuard: "strict", autoUpdateHours: 12, evil: 1,
    __proto__: { polluted: true }, trustedDomains: ["A.example.com", "bad_", 5], sourceEnabled: { urlhaus: false, nope: true, phishing: "x" },
    blockedCount: 99, autoLists: { urlhaus: ["x.example.com"] } });
  assert.deepStrictEqual(out, { malwareEnabled: false, downloadGuard: "strict", autoUpdateHours: 12, trustedDomains: ["a.example.com"], sourceEnabled: { urlhaus: false } });
  assert.deepStrictEqual(L.sanitizeSettings(null), {});
  assert.deepStrictEqual(L.sanitizeSettings([1]), {});
  assert.deepStrictEqual(L.sanitizeSettings({ autoUpdateHours: 1 }), {});
  assert.strictEqual(L.sanitizeSettings({ customBlockedDomains: Array.from({ length: 30000 }, (_, i) => "d" + i + ".example.com") }).customBlockedDomains.length, L.LIMITS.MAX_CUSTOM);
});

// ---- feed sources ----
t("every feed has HTTPS mirrors on hosts the CSP allows; no retired URLs", () => {
  const m = JSON.parse(fs.readFileSync(path.join(__dirname, "../manifest.json"), "utf8"));
  const csp = m.content_security_policy.extension_pages;
  for (const s of L.SOURCES) {
    assert(s.urls.length >= 1 && !("url" in s), s.id);
    for (const u of s.urls) { assert(/^https:\/\//.test(u), u); assert(csp.includes("https://" + new URL(u).hostname), u); }
  }
  const all = L.SOURCES.flatMap(s => s.urls).join(" ");
  assert(!/urlhaus\.abuse\.ch\/downloads\/hostfile/.test(all) && !/main\/domains\/light\.txt/.test(all));
  assert(L.isProtected("curbengh.github.io") && L.isProtected("cdn.jsdelivr.net"));
});

// ---- download guard ----
t("A-tier and disguised names blocked in balanced", () => {
  for (const f of ["x.url", "x.xll", "x.jnlp", "x.vbs", "doc.pdf.exe", "photo.jpg   .exe", "a\u202Egpj.exe"])
    assert(dl(f, "balanced"), f);
});
t("name tricks do not hide the extension (strict)", () => {
  for (const f of ["a.exe.", "a.exe ", "a.exe::$DATA", "a.exe\u200b", "C:\\x\\a.exe", "report#1.exe"])
    assert(dl(f, "strict"), JSON.stringify(f));
});
t("balanced allows ordinary https installers, blocks raw IP / http", () => {
  assert.strictEqual(dl("setup.exe", "balanced"), null);
  assert(dl("setup.exe", "balanced", [], { url: "https://8.8.4.4/setup.exe" }));
  assert(dl("setup.exe", "balanced", [], { url: "http://files.example/setup.exe" }));
});
t("strict: archives, generic MIME, trust rules", () => {
  assert(dl("a.zip", "strict"));
  assert.strictEqual(dl("a.zip", "strict", ["example"]), null);
  assert.strictEqual(dl("a.zip", "balanced"), null);
  assert(dl("blob", "strict", [], { mime: "application/octet-stream" }));
  assert.strictEqual(dl("blob", "balanced", [], { mime: "application/octet-stream" }), null);
  assert.strictEqual(dl("a.exe", "strict", ["files.example"]), null);
  // trusted referrer must not trust a hostile file host
  assert(dl("a.exe", "strict", ["good.example"], { referrer: "https://good.example/" }));
  // trusted first host but redirected to an untrusted one
  assert(dl("a.exe", "strict", ["files.example"], { finalUrl: "https://evil.example/a.exe" }));
});
t("scriptable documents only blocked from raw IPs", () => {
  assert(dl("x.svg", "balanced", [], { url: "https://8.8.4.4/x.svg" }));
  assert.strictEqual(dl("x.svg", "balanced"), null);
});
t("MIME mismatch and off mode", () => {
  assert(dl("a.docx", "balanced", [], { mime: "application/x-msdownload" }));
  assert.strictEqual(dl("a.vbs", "off"), null);
});

// ---- merged lists ----
t("manual import cannot push malware lists out", () => {
  const mk = (p, k) => Array.from({ length: k }, (_, i) => p + i + ".example.com");
  const state = { autoLists: { urlhaus: mk("m", 30000), phishing: mk("p", 30000), hagezi_light: mk("h", 50000) },
                  bulkBlockedDomains: mk("u", 100000), sourceEnabled: {} };
  const r = L.mergedBulk(state, 100000);
  assert.strictEqual(r.threat.length, 60000);
  assert(r.threat.length + r.other.length <= 100000);
  assert(r.other.includes("u0.example.com"));
});
t("updater redirects stay on the configured HTTPS host", () => {
  assert(L.sourceRedirectAllowed("https://raw.githubusercontent.com/a", "https://raw.githubusercontent.com/b"));
  assert(!L.sourceRedirectAllowed("https://raw.githubusercontent.com/a", "https://evil.example/b"));
  assert(!L.sourceRedirectAllowed("http://raw.githubusercontent.com/a", "https://raw.githubusercontent.com/b"));
  assert(!L.sourceRedirectAllowed("https://raw.githubusercontent.com/a", "http://raw.githubusercontent.com/b"));
});
t("auto lists cannot block updater hosts or their parent domains", () => {
  const r = L.mergedBulk({ autoLists: { urlhaus: [
    "github.io", "gitlab.io", "githubusercontent.com", "jsdelivr.net", "pages.dev",
    "curbengh.github.io", "malware-filter.gitlab.io", "cdn.jsdelivr.net",
    "raw.githubusercontent.com", "urlhaus-filter.pages.dev", "safe.example"
  ] } }, 100);
  assert.deepStrictEqual(r.threat, ["safe.example"]);
});
t("disabled source is excluded", () => {
  const r = L.mergedBulk({ autoLists: { urlhaus: ["a.example.com"] }, sourceEnabled: { urlhaus: false } }, 10);
  assert.strictEqual(r.threat.length, 0);
});
t("array hygiene", () => {
  assert.deepStrictEqual(L.cleanDomains("notarray"), []);
  assert.deepStrictEqual(L.cleanDomains([1, null, "A.Example.com ", "bad_", "a.example.com"]), ["a.example.com"]);
  assert.deepStrictEqual(L.mergedBulk({ autoLists: { urlhaus: "x" }, bulkBlockedDomains: {} }).threat, []);
});

// ---- manifest compatibility ----
t("manifest: icons, options page, minimal permissions, Firefox data-collection minimums", () => {
  const m = JSON.parse(fs.readFileSync(path.join(__dirname, "../manifest.json"), "utf8"));
  assert.strictEqual(m.minimum_chrome_version, "121");
  assert(parseInt(m.browser_specific_settings.gecko.strict_min_version, 10) >= 140);
  assert(parseInt(m.browser_specific_settings.gecko_android.strict_min_version, 10) >= 142);
  assert.deepStrictEqual(m.browser_specific_settings.gecko.data_collection_permissions.required, ["none"]);
  assert(m.background.service_worker && !m.background.scripts);
  assert(!m.permissions.includes("tabs"), "tabs permission is redundant with <all_urls>");
  assert(m.permissions.includes("webNavigation"));
  assert.strictEqual(m.version, "2.6.0");
  assert.strictEqual(m.options_ui.page, "options.html");
  for (const sz of ["16", "32", "48", "128"]) assert(fs.existsSync(path.join(__dirname, "..", m.icons[sz])), "icon " + sz);
});
t("build: chrome and firefox packages are valid, complete and differ only where they must", () => {
  const { execFileSync } = require("child_process");
  execFileSync(process.execPath, [path.join(__dirname, "../tools/build.js")], { stdio: "pipe" });
  const rd = (d) => JSON.parse(fs.readFileSync(path.join(__dirname, "../dist", d, "manifest.json"), "utf8"));
  const c = rd("chrome"), f = rd("firefox");
  assert(c.background.service_worker && !c.background.scripts && !c.browser_specific_settings);
  assert(!f.background.service_worker && f.background.scripts.join() === "lists.js,reputation.js,background.js");
  assert(!f.minimum_chrome_version && !f.web_accessible_resources[0].use_dynamic_url);
  for (const d of ["chrome", "firefox"]) {
    for (const x of ["options.html", "options.js", "options.css", "popup.html", "icons/icon128.png", "rules_ads.json"])
      assert(fs.existsSync(path.join(__dirname, "../dist", d, x)), d + "/" + x);
    assert(!fs.existsSync(path.join(__dirname, "../dist", d, "tests")));
  }
});
t("html pages use no inline script, inline style or event-handler attributes", () => {
  for (const f of fs.readdirSync(path.join(__dirname, "..")).filter(x => x.endsWith(".html"))) {
    const h = fs.readFileSync(path.join(__dirname, "..", f), "utf8");
    assert(!/<script(?![^>]*\bsrc=)[^>]*>/i.test(h), f + " inline script");
    assert(!/\son[a-z]+\s*=/i.test(h) && !/\sstyle\s*=/i.test(h) && !/<style/i.test(h), f);
  }
});

// ---- static rules ----
const rules = JSON.parse(fs.readFileSync(path.join(__dirname, "../rules_malware.json"), "utf8"));
const byId = id => rules.find(r => r.id === id);
const hit = (id, url) => new RegExp(byId(id).condition.regexFilter, "i").test(url);
t("static rules: unique ids, valid regex", () => {
  assert.strictEqual(new Set(rules.map(r => r.id)).size, rules.length);
  for (const r of rules) if (r.condition.regexFilter) new RegExp(r.condition.regexFilter);
});
t("LAN exemption is anchored", () => {
  assert(hit(18, "http://10.0.0.5/a.exe"));
  assert(hit(18, "http://192.168.1.2:8080/a.exe"));
  assert(hit(18, "http://u@10.0.0.5/a.exe"));
  for (const u of ["http://10.evil.com/a.exe", "http://192.168.evil.io/x", "http://10.1.2.3.evil.io/x", "http://10.0.0.1@8.8.8.8/a.exe", "http://172.15.0.1/x"])
    assert(!hit(18, u), u);
});
t("raw-IP file rules: userinfo, scripts, IPv6", () => {
  assert(hit(10, "http://1.2.3.4/a.exe"));
  assert(hit(10, "http://user@1.2.3.4/a.exe?x=1"));
  assert(hit(12, "http://1.2.3.4/x.js"));
  assert(byId(12).condition.resourceTypes.includes("script"));
  assert(hit(11, "https://[2001:db8::1]/a.exe"));
  assert(!hit(10, "https://example.com/a.exe"));
});

// ---- v2.6.0 hardening / cleanup ----
t("registry suffixes can never be blocked by a downloaded feed", () => {
  for (const d of ["co.uk", "com.au", "org.uk", "ac.uk", "co.jp", "gov.in", "com.br"]) assert(L.isProtected(d), d);
  for (const d of ["example.co", "shop.co.uk", "foo.com", "ads.example.net"]) assert(!L.isProtected(d), d);
  const merged = L.mergedBulk({ autoLists: { urlhaus: ["co.uk", "bad.example.com", "com.au"] }, sourceEnabled: {} }, 100);
  assert.deepStrictEqual(merged.threat, ["bad.example.com"]);
});
t("settings export format: new name accepted, pre-rename name still imports, others refused", () => {
  assert.strictEqual(L.SETTINGS_FORMAT, "cipherpane-settings");
  assert(L.isSettingsFormat("cipherpane-settings") && L.isSettingsFormat("aegisgate-settings"));
  assert(!L.isSettingsFormat("other") && !L.isSettingsFormat(undefined) && !L.isSettingsFormat({}));
});
t("shared age formatter", () => {
  assert.strictEqual(L.fmtAge(Date.now()), "just now");
  assert.strictEqual(L.fmtAge(Date.now() - 30 * 60000), "30 min ago");
  assert.strictEqual(L.fmtAge(Date.now() - 5 * 3600000), "5 h ago");
  assert.strictEqual(L.fmtAge(Date.now() - 4 * 86400000), "4 d ago");
});
t("reputation module exposes only what is used", () => {
  assert.deepStrictEqual(Object.keys(R).sort(), ["editDistance", "parseHost", "scoreHost"]);
});
t("manifest: strict extension-page CSP and consistent naming", () => {
  const m = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "manifest.json"), "utf8"));
  const csp = m.content_security_policy.extension_pages;
  for (const d of ["default-src 'none'", "script-src 'self'", "object-src 'none'", "frame-src 'none'", "base-uri 'none'", "form-action 'none'"]) assert(csp.includes(d), d);
  assert(!/unsafe-(inline|eval)/.test(csp));
  assert.strictEqual(m.name, "CipherPane Browser Security");
  for (const f of ["manifest.json", "popup.html", "options.html", "blocked.html", "nohttps.html", "background.js", "popup.js", "options.js"])
    assert(!/aegis/i.test(fs.readFileSync(path.join(__dirname, "..", f), "utf8").replace("aegisgate-settings", "")), f + " still mentions the old name");
});

console.log("\n" + n + " test groups passed");

// page scripts against a stub DOM
require("./pages.js");

// worker + streaming-parser tests against a mocked chrome API (async, prints its own summary)
require("./runtime.js");
