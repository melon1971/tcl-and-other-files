// Runtime tests: loads the real background.js in a vm against a mocked `chrome` API, plus the
// streaming list parser. Run: node tests/runtime.js   (also run by node tests/run.js). No dependencies.
// These are unit/integration tests against a mock, not a browser test.
"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.join(__dirname, "..");
const read = f => fs.readFileSync(path.join(ROOT, f), "utf8");
const clone = x => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
const tick = (ms = 15) => new Promise(r => setTimeout(r, ms));
let passed = 0;
async function t(name, fn) { await fn(); passed++; console.log("ok -", name); }

// ---------------------------------------------------------------- chrome mock
function makeEnv(fetchImpl) {
  const local = {}, session = {};
  const SESSION_QUOTA = 10 * 1024 * 1024;
  const area = (store, quota) => ({
    store,
    async get(keys) {
      if (keys == null) return clone(store);
      const out = {};
      if (typeof keys === "string") keys = [keys];
      if (Array.isArray(keys)) { for (const k of keys) if (k in store) out[k] = clone(store[k]); }
      else for (const k of Object.keys(keys)) out[k] = k in store ? clone(store[k]) : keys[k];
      return out;
    },
    async set(o) {
      const next = { ...store, ...clone(o) };
      if (quota && JSON.stringify(next).length > quota) throw new Error("QUOTA_BYTES quota exceeded");
      Object.assign(store, clone(o));
    }
  });
  const ev = () => { const fns = []; return { addListener(f) { fns.push(f); }, fns }; };
  const sessionRules = [];
  const dynamicSyncCalls = [];
  const chrome = {
    runtime: { id: "abc", getURL: p => "chrome-extension://abc/" + p, onMessage: ev(), onInstalled: ev(), onStartup: ev(), onSuspend: ev() },
    storage: { local: area(local), session: area(session, SESSION_QUOTA), onChanged: ev() },
    tabs: { query: async () => [{ id: 1 }, { id: 2 }, { id: 5 }], update: async () => {}, onRemoved: ev(), onUpdated: ev() },
    webRequest: { onCompleted: ev(), onErrorOccurred: ev(), onBeforeRedirect: ev() },
    downloads: { onCreated: ev(), onChanged: ev(), cancel: async () => {}, removeFile: async () => {}, erase: async () => {}, search: async () => [], download: async () => 1 },
    alarms: { get: async () => undefined, create: async () => {}, clear: async () => {}, onAlarm: ev() },
    action: { setBadgeText() {}, setBadgeBackgroundColor() {}, getBadgeText: async () => "" },
    declarativeNetRequest: {
      sessionRules,
      getSessionRules: async () => clone(sessionRules),
      updateSessionRules: async ({ removeRuleIds = [], addRules = [] }) => {
        for (const id of removeRuleIds) { const i = sessionRules.findIndex(r => r.id === id); if (i >= 0) sessionRules.splice(i, 1); }
        sessionRules.push(...clone(addRules));
      },
      getDynamicRules: async () => [], updateDynamicRules: async (args) => { dynamicSyncCalls.push(clone(args)); }, updateEnabledRulesets: async () => {}
    }
  };
  const ctx = vm.createContext({ console: { log() {}, warn() {}, error() {} }, URL, URLSearchParams, TextEncoder, TextDecoder,
    setTimeout, clearTimeout, AbortController, Response, fetch: fetchImpl || (async () => { throw new Error("no network in tests"); }), chrome });
  ctx.self = ctx;
  vm.runInContext(read("lists.js"), ctx, { filename: "lists.js" });
  vm.runInContext(read("background.js"), ctx, { filename: "background.js" });
  const POPUP = "chrome-extension://abc/popup.html";
  const send = (msg, senderUrl = POPUP, id = "abc") => new Promise(res => {
    const handled = chrome.runtime.onMessage.fns[0](msg, { id, url: senderUrl }, res);
    if (handled !== true) res(undefined);   // handler declined (returned false): no response
  });
  return { chrome, local, session, sessionRules, dynamicSyncCalls, send, ctx, POPUP };
}
const NOHTTPS = (host, s) => `chrome-extension://abc/nohttps.html?u=${encodeURIComponent("http://" + host + "/")}&s=${s}`;

(async () => {
  // ------------------------------------------------------------ request log bounds
  await t("log entries are length-bounded and per-tab capped", async () => {
    const env = makeEnv();
    const done = env.chrome.webRequest.onCompleted.fns[0];
    for (let i = 0; i < 400; i++)
      done({ tabId: 5, type: "script", url: "https://a.example/" + "x".repeat(200000) + "?q=" + i });
    const r = await env.send({ type: "GET_TAB_LOGS", tabId: 5 });
    assert.strictEqual(r.logs.length, 150);
    assert(r.logs.every(e => e.url.length <= 512 && e.host.length <= 253));
  });

  await t("tab count is capped; negative ids ignored; clear cannot create entries", async () => {
    const env = makeEnv();
    const done = env.chrome.webRequest.onCompleted.fns[0];
    done({ tabId: -1, type: "image", url: "https://a.example/x" });
    for (let id = 0; id < 1500; id++) done({ tabId: id, type: "image", url: "https://a.example/" + "y".repeat(300) });
    await env.send({ type: "CLEAR_TAB_LOGS", tabId: 99999999 });
    env.chrome.runtime.onSuspend.fns[0]();
    await tick();
    const saved = env.session.tabLogs;
    const keys = Object.keys(saved);
    assert(keys.length <= 500, "kept " + keys.length);
    assert(!("-1" in saved) && !("99999999" in saved));
    assert(JSON.stringify(saved).length < 4.6 * 1024 * 1024);
  });

  await t("flush stays inside the session quota even with worst-case entries", async () => {
    const env = makeEnv();
    const done = env.chrome.webRequest.onCompleted.fns[0];
    for (let id = 0; id < 500; id++)
      for (let i = 0; i < 150; i++) done({ tabId: id, type: "websocket", url: "https://" + "h".repeat(60) + ".example/" + "z".repeat(900) });
    let rejected = false;
    const origSet = env.chrome.storage.session.set;
    env.chrome.storage.session.set = async o => { try { return await origSet(o); } catch (e) { rejected = true; throw e; } };
    env.chrome.runtime.onSuspend.fns[0]();
    await tick(50);
    assert(!rejected, "log write exceeded the session quota");
    assert(Object.keys(env.session.tabLogs || {}).length > 0);
  });

  await t("log requests and popup-only messages from other pages are refused", async () => {
    const env = makeEnv();
    assert.strictEqual(await env.send({ type: "GET_TAB_LOGS", tabId: 1 }, NOHTTPS("a.example", 1)), undefined);
    assert.strictEqual(await env.send({ type: "GET_TAB_LOGS", tabId: 1 }, env.POPUP, "someone-else"), undefined);
    assert.strictEqual(await env.send({ type: "GET_TAB_LOGS", tabId: -5 }), undefined);
    assert.strictEqual(await env.send({ type: "GET_TAB_LOGS", tabId: 1.5 }), undefined);
  });

  // ------------------------------------------------------------ HTTP fallback gate
  await t("ALLOW_HTTP: session rules are capped, newest kept, oldest evicted", async () => {
    const env = makeEnv();
    for (let i = 0; i < 260; i++) {
      const host = `h${i}.example.com`;
      const r = await env.send({ type: "ALLOW_HTTP", host, mode: "session" }, NOHTTPS(host, 0));
      assert(r && r.ok, host);
    }
    assert(env.sessionRules.length <= 200, "rules: " + env.sessionRules.length);
    const filters = env.sessionRules.map(r => r.condition.urlFilter);
    assert(filters.includes("|http://h259.example.com^"));
    assert(!filters.includes("|http://h0.example.com^"));
  });

  await t("ALLOW_HTTP: host must match the warning page's own URL", async () => {
    const env = makeEnv();
    const r = await env.send({ type: "ALLOW_HTTP", host: "evil.example.com", mode: "session" }, NOHTTPS("a.example.com", 1));
    assert.strictEqual(r.ok, false);
    assert.strictEqual(env.sessionRules.length, 0);
  });

  await t("ALLOW_HTTP: 'always' needs the page to have offered it (s=1); modes are validated", async () => {
    const env = makeEnv();
    let r = await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "always" }, NOHTTPS("a.example.com", 0));
    assert.strictEqual(r.ok, false);
    r = await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "forever" }, NOHTTPS("a.example.com", 1));
    assert.strictEqual(r.ok, false);
    r = await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "always" }, NOHTTPS("a.example.com", 1));
    assert.strictEqual(r.ok, true);
    assert.deepStrictEqual(Array.from(env.local.httpAllowedDomains), ["a.example.com"]);
  });

  await t("ALLOW_HTTP is refused from the popup and from foreign senders", async () => {
    const env = makeEnv();
    assert.strictEqual(await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "session" }, env.POPUP), undefined);
    assert.strictEqual(await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "session" }, NOHTTPS("a.example.com", 1), "other-ext"), undefined);
  });

  await t("ALLOW_HTTP: warning-page URL with embedded credentials or an oversized target is refused", async () => {
    const env = makeEnv();
    const withCreds = `chrome-extension://abc/nohttps.html?u=${encodeURIComponent("http://user:pw@a.example.com/")}&s=1`;
    assert.strictEqual((await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "session" }, withCreds)).ok, false);
    const huge = `chrome-extension://abc/nohttps.html?u=${encodeURIComponent("http://a.example.com/" + "x".repeat(3000))}&s=1`;
    assert.strictEqual((await env.send({ type: "ALLOW_HTTP", host: "a.example.com", mode: "session" }, huge)).ok, false);
    assert.strictEqual(env.sessionRules.length, 0);
  });

  await t("message payloads must have the right shape (non-string host / id refused)", async () => {
    const env = makeEnv();
    const sneaky = { toString() { return "a.example.com"; } };
    assert.strictEqual((await env.send({ type: "ALLOW_HTTP", host: sneaky, mode: "session" }, NOHTTPS("a.example.com", 1))).ok, false);
    assert.strictEqual((await env.send({ type: "ALLOW_HTTP", host: "a".repeat(300) + ".com", mode: "session" }, NOHTTPS("a.example.com", 1))).ok, false);
    assert.strictEqual((await env.send({ type: "ALLOW_DOWNLOAD", id: { toString() { return "x"; } } }, env.POPUP)).ok, false);
    assert.strictEqual((await env.send({ type: "ALLOW_DOWNLOAD", id: "x".repeat(65) }, env.POPUP)).ok, false);
    assert.strictEqual(env.sessionRules.length, 0);
  });

  await t("new-install feed schedule defaults to six hours", async () => {
    const env = makeEnv();
    assert.strictEqual(vm.runInContext("DEFAULT_STATE.autoUpdateHours", env.ctx), 6);
    assert.strictEqual(vm.runInContext("clampHours(undefined)", env.ctx), 6);
  });

  // ------------------------------------------------------------ local URL heuristic
  await t("local URL heuristic blocks authority userinfo without network lookups", async () => {
    const env = makeEnv();
    const rules = vm.runInContext("buildRules(DEFAULT_STATE, false)", env.ctx);
    const suspicious = rules.filter(r => r.condition && r.condition.regexFilter === "^https?://[^/?#]*@");
    assert.strictEqual(suspicious.length, 2);
    assert(suspicious.some(r => r.condition.resourceTypes.includes("main_frame") &&
      r.action.type === "redirect"));
    assert(suspicious.some(r => r.condition.resourceTypes.includes("script") &&
      r.action.type === "block"));
    const re = new RegExp(suspicious[0].condition.regexFilter, "i");
    assert(re.test("https://trusted.example@attacker.test/login"));
    assert(!re.test("https://trusted.example/login"));
    assert(!re.test("https://attacker.test/path?next=user@example.test"));
  });

  // ------------------------------------------------------------ updater: bodies are never left unread
  const hosts = n => Array.from({ length: n }, (_, i) => `0.0.0.0 d${i}.badhost.example`).join("\n");
  function trackedBody(text, status, headers, url) {
    const state = { cancelled: false };
    const enc = new TextEncoder().encode(text || "");
    const stream = new ReadableStream({
      start(c) { c.enqueue(enc); c.close(); },
      cancel() { state.cancelled = true; }
    });
    const resp = new Response(status === 304 ? null : stream, { status, headers });
    if (url) Object.defineProperty(resp, "url", { value: url });
    return { resp, state };
  }
  async function runUpdate(responses, initial, onFetch) {
    let env;
    env = makeEnv(async (u) => {
      if (onFetch) onFetch(env, u);
      const handler = responses[u];
      if (!handler) throw new Error("unmocked URL " + u);
      return handler();
    });
    if (initial) Object.assign(env.local, clone(initial));
    await env.send({ type: "UPDATE_LISTS_NOW" });
    for (let i = 0; i < 200; i++) {
      await tick(10);
      const m = env.local.autoListMeta;
      if (m && m.lastRun && !m.running) break;
    }
    return env;
  }

  await t("updater: HTTP errors, foreign redirects and HTML pages cancel the body", async () => {
    const e500 = trackedBody("oops", 500, {});
    const away = trackedBody(hosts(5), 200, {}, "https://evil.example/hostfile");
    const html = trackedBody("<html>portal</html>", 200, { "content-type": "text/html" });
    await runUpdate({
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": () => e500.resp,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": () => away.resp,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": () => html.resp,
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => trackedBody("", 404, {}).resp,
      "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 404, {}).resp,
      "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": () => trackedBody("", 404, {}).resp
    });
    assert(e500.state.cancelled, "500 body left unread");
    assert(away.state.cancelled, "redirected body left unread");
    assert(html.state.cancelled, "html body left unread");
  });

  await t("updater: good feed is parsed from the stream, protected domains dropped", async () => {
    const ok = trackedBody("# hosts\n" + hosts(2000) + "\n0.0.0.0 www.github.com\n0.0.0.0 github.com\n", 200, { "content-type": "text/plain", etag: "\"v1\"" });
    const env = await runUpdate({
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": () => ok.resp,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp,
      "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp,
      "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp,
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => trackedBody("", 500, {}).resp
    });
    const list = env.local.autoLists.urlhaus;
    assert.strictEqual(list.length, 2001);                // 2000 + www.github.com (subdomains stay blockable)
    assert(!list.includes("github.com"));
    assert.strictEqual(env.local.autoListMeta.sources.urlhaus.etag, "\"v1\"");
  });

  await t("updater: a poisoned feed line for a registry suffix (co.uk) is dropped", async () => {
    const ok = trackedBody("# hosts\n" + hosts(50) + "\n0.0.0.0 co.uk\n0.0.0.0 com.au\n0.0.0.0 shop.co.uk\n", 200, { "content-type": "text/plain" });
    const none = () => trackedBody("", 500, {}).resp;
    const env = await runUpdate({
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => ok.resp,
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": none,
      "https://urlhaus-filter.pages.dev/urlhaus-filter-hosts-online.txt": none,
      "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": none,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": none,
      "https://phishing-filter.pages.dev/phishing-filter-hosts.txt": none,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": none,
      "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": none
    });
    const list = env.local.autoLists.urlhaus;
    assert(!list.includes("co.uk") && !list.includes("com.au"));
    assert(list.includes("shop.co.uk"));                  // a real site under the suffix stays blockable
  });

  await t("updater: migrates stale persisted source-host blocks before attempting feeds", async () => {
    const fail = () => trackedBody("", 503, {}).resp;
    const responses = {
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": fail,
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": fail,
      "https://urlhaus-filter.pages.dev/urlhaus-filter-hosts-online.txt": fail,
      "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": fail,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": fail,
      "https://phishing-filter.pages.dev/phishing-filter-hosts.txt": fail,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": fail,
      "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": fail
    };
    const firstFetchState = [];
    const env = await runUpdate(responses, {
      autoLists: {
        urlhaus: ["github.io", "gitlab.io", "githubusercontent.com", "jsdelivr.net", "pages.dev", "safe.example"],
        phishing: ["malware-filter.gitlab.io", "safe-phish.example"]
      }
    }, (e, url) => {
      if (!firstFetchState.length) firstFetchState.push({
        url, lists: clone(e.local.autoLists), synced: e.dynamicSyncCalls.length > 0
      });
    });
    assert.deepStrictEqual(firstFetchState[0].lists.urlhaus, ["safe.example"]);
    assert.deepStrictEqual(firstFetchState[0].lists.phishing, ["safe-phish.example"]);
    assert(firstFetchState[0].synced, "stale DNR rules were not rebuilt before fetching");
    assert.deepStrictEqual(env.local.autoLists.urlhaus, ["safe.example"]);
    assert.deepStrictEqual(env.local.autoLists.phishing, ["safe-phish.example"]);
  });

  await t("updater: a dead primary mirror (410) falls through to the next mirror", async () => {
    const dead = trackedBody("gone", 410, {});
    const ok = trackedBody("0.0.0.0 a1.example.com\n0.0.0.0 a2.example.com\n", 200, { "content-type": "text/plain" });
    const calls = [];
    const env = await runUpdate({
      "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => { calls.push("m1"); return dead.resp; },
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": () => { calls.push("m2"); return ok.resp; },
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp, "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp, "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp
    });
    assert.deepStrictEqual(calls, ["m1", "m2"]);
    assert(dead.state.cancelled);
    assert.deepStrictEqual(env.local.autoLists.urlhaus, ["a1.example.com", "a2.example.com"]);
    const meta = env.local.autoListMeta.sources.urlhaus;
    assert(meta.ok && meta.url === "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt");
  });

  await t("updater: every mirror failing reports each host and keeps the old list", async () => {
    const env = await runUpdate({
      "https://curbengh.github.io/malware-filter/urlhaus-filter-hosts-online.txt": () => trackedBody("", 410, {}).resp, "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt": () => trackedBody("", 404, {}).resp,
      "https://curbengh.github.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp, "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt": () => trackedBody("", 500, {}).resp,
      "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp, "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/light-onlydomains.txt": () => trackedBody("", 500, {}).resp
    });
    const m = env.local.autoListMeta.sources.urlhaus;
    assert(!m.ok && /curbengh\.github\.io: HTTP 410/.test(m.error) && /malware-filter\.gitlab\.io: HTTP 404/.test(m.error), m.error);
  });

  // ------------------------------------------------------------ streaming parser
  const L = vm.runInContext("CipherLists", makeEnv().ctx);
  // hooks.open = leave the stream open after the chunks, like a body that is still downloading
  const streamOf = (chunks, hooks) => new Response(new ReadableStream({
    start(c) { for (const ch of chunks) c.enqueue(typeof ch === "string" ? new TextEncoder().encode(ch) : ch); if (!(hooks && hooks.open)) c.close(); },
    cancel() { if (hooks) hooks.cancelled = true; }
  }));

  await t("stream parser: lines split across chunks, CRLF, no trailing newline", async () => {
    const r = streamOf(["0.0.0.0 ads.ex", "ample.com\r\n||t.exa", "mple.net^\n", "plain.example.org"]);
    const out = await L.parseResponseDomains(r, 1e6, { max: 100 });
    assert.deepStrictEqual(Array.from(out), ["ads.example.com", "t.example.net", "plain.example.org"]);
  });

  await t("stream parser: multi-byte characters split across chunks decode correctly", async () => {
    const bytes = new TextEncoder().encode("0.0.0.0 b\u00fccher.example.com\n");   // ü is 2 bytes
    const r = streamOf([bytes.slice(0, 10), bytes.slice(10)]);
    assert.deepStrictEqual(Array.from(await L.parseResponseDomains(r, 1e6, {})), ["xn--bcher-kva.example.com"]);
  });

  await t("stream parser: same result as the one-shot parser on a large mixed list", async () => {
    const lines = [];
    for (let i = 0; i < 60000; i++) lines.push(i % 7 === 0 ? `||t${i}.example.net^` : i % 11 === 0 ? `# c${i}` : i % 13 === 0 ? `@@||ok${i}.example.com^` : `0.0.0.0 h${i}.example.com`);
    const text = lines.join("\n");
    const bytes = new TextEncoder().encode(text);
    const chunks = []; let p = 0, k = 1;
    while (p < bytes.length) { const n = 1 + ((k = (k * 48271) % 2147483647) % 9000); chunks.push(bytes.slice(p, p + n)); p += n; }
    const streamed = await L.parseResponseDomains(streamOf(chunks), 1e8, { max: 100000 });
    assert.deepStrictEqual(Array.from(streamed), Array.from(L.parseFilterLines(text, { max: 100000 })));
  });

  await t("stream parser: newline-free body is not buffered; byte cap and max stop the read", async () => {
    const hooks = { cancelled: false, open: true };
    const blob = new Uint8Array(5 * 1024 * 1024).fill(97);
    assert.deepStrictEqual(Array.from(await L.parseResponseDomains(streamOf([blob]), 1e8, {})), []);
    await assert.rejects(L.parseResponseDomains(streamOf([blob, blob]), 6 * 1024 * 1024, {}), /list too large/);
    const many = [Array.from({ length: 1000 }, (_, i) => `0.0.0.0 m${i}.example.com`).join("\n")];
    const r = await L.parseResponseDomains(streamOf(many, hooks), 1e8, { max: 10 });
    assert.strictEqual(r.length, 10);
    await tick();
    assert(hooks.cancelled, "body not cancelled after max reached");
    const big = new Response("x", { headers: { "content-length": String(1e9) } });
    await assert.rejects(L.parseResponseDomains(big, 1e6, {}), /list too large/);
  });

  console.log("\n" + passed + " runtime tests passed");
})().catch(e => { console.error("RUNTIME TEST FAILED:", e); process.exit(1); });
