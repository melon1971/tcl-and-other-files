"""LiveWorld RPG 1.0.29 - the look of the ten pets (and of the pets the computer-controlled people keep).

Each pet is painted facing right on a 2x canvas (so the edges are smooth once it is scaled down), with a walk cycle (frame 0-3, -1 = standing)
and a wing beat for the flyers; the sprite is then outlined like every character in the game and cached.  Drawn with plain pygame shapes:
no image files.
"""
import math

import pygame

from . import gfx

CW, CH = 170, 130          # the 2x canvas
GX, GY = 85, 112           # where its feet touch the ground (the anchor)
_CACHE = {}


def _sh(c, f): return gfx.shade(c, f)


def blob(S, cx, cy, rx, ry, col, light=1.18, dark=.72):
    """A rounded body part: a dark rim, the colour, and a lighter patch up and to the left, so it reads as a volume."""
    pygame.draw.ellipse(S, _sh(col, dark), (cx - rx, cy - ry, rx * 2, ry * 2))
    pygame.draw.ellipse(S, col, (cx - rx + 2, cy - ry + 1, rx * 2 - 5, ry * 2 - 5))
    pygame.draw.ellipse(S, _sh(col, light), (cx - rx * .62, cy - ry * .8, rx * 1.1, ry * 1.0))


def limb(S, x0, y0, x1, y1, w, col):
    pygame.draw.line(S, _sh(col, .66), (x0, y0), (x1, y1), w + 3)
    pygame.draw.line(S, col, (x0, y0), (x1, y1), w)
    pygame.draw.circle(S, _sh(col, .66), (int(x1), int(y1)), (w + 3) // 2)
    pygame.draw.circle(S, col, (int(x1), int(y1)), w // 2 + 1)


def eye(S, x, y, r=4, iris=(30, 24, 20)):
    pygame.draw.circle(S, (250, 248, 240), (int(x), int(y)), r + 1)
    pygame.draw.circle(S, iris, (int(x + 1), int(y)), max(2, r - 1))
    pygame.draw.circle(S, (10, 8, 8), (int(x + 1), int(y)), max(1, r - 3))
    pygame.draw.circle(S, (255, 255, 255), (int(x - 1), int(y - 1)), 1)


def tri(S, pts, col):
    pygame.draw.polygon(S, _sh(col, .66), pts)
    c = (sum(p[0] for p in pts) / 3, sum(p[1] for p in pts) / 3)
    pygame.draw.polygon(S, col, [(c[0] + (p[0] - c[0]) * .78, c[1] + (p[1] - c[1]) * .78) for p in pts])


def legs4(S, f, xs, hip_y, col, w=9, lift=9, ground=GY):
    """Four legs; a walking cycle swings the diagonal pairs."""
    for i, x in enumerate(xs):
        ph = 0 if f < 0 else math.sin((f / 4 + (.5 if i % 2 else 0) + (.25 if i >= 2 else 0)) * math.tau)
        limb(S, x, hip_y, x + ph * 9, ground - max(0, -ph) * lift, w, _sh(col, .86 if i % 2 else 1.0))


def _wing(S, root, tipy, col, mem, flap, span=44, feather=False):
    """A wing beating up and down: flap runs -1 (raised) to 1 (lowered)."""
    rx, ry = root
    up = -flap
    tip = (rx - 8 + span * .55, ry - 6 - up * 34 - 26)
    mid = (rx - 20, ry - up * 16 - 22)
    tail = (rx - span, ry - up * 12 - 10 + (6 if feather else 0))
    pts = [root, mid, tip, (tip[0] - 4, tip[1] + 16), tail, (rx - 10, ry + 2)]
    pygame.draw.polygon(S, _sh(mem, .7), pts)
    pygame.draw.polygon(S, mem, [(rx + (x - rx) * .88, ry + (y - ry) * .88 - 1) for x, y in pts])
    pygame.draw.lines(S, col, False, [root, mid, tip], 4)
    if feather:
        for i in range(5):
            t = i / 4
            a = (mid[0] + (tip[0] - mid[0]) * t, mid[1] + (tip[1] - mid[1]) * t)
            pygame.draw.line(S, _sh(col, .78), a, (a[0] - 8 - t * 8, a[1] + 24), 3)


# ------------------------------------------------------------------ the ten
def _wolf(S, f, bob, P):
    c = P["coat"]
    limb(S, 52, 66, 36 - (f == 1) * 4, 46, 9, c)                                # tail
    legs4(S, f, (58, 70, 98, 108), 74, c, 9)
    blob(S, 84, 68 - bob, 34, 20, c)
    blob(S, 100, 74 - bob, 17, 12, P["belly"], 1.1, .85)
    blob(S, 116, 52 - bob, 17, 15, c)
    blob(S, 132, 58 - bob, 13, 8, _sh(c, 1.1))
    pygame.draw.circle(S, (20, 16, 16), (143, 56 - bob), 3)
    tri(S, [(105, 42 - bob), (110, 22 - bob), (120, 40 - bob)], c); tri(S, [(118, 42 - bob), (126, 24 - bob), (130, 44 - bob)], _sh(c, .9))
    eye(S, 122, 49 - bob, 3, (200, 160, 40))


def _badger(S, f, bob, P):
    c = P["coat"]
    legs4(S, f, (56, 68, 100, 112), 82, c, 11, 6)
    for x in (56, 68, 100, 112):
        pygame.draw.line(S, (230, 230, 220), (x + 3, GY - 1), (x + 9, GY), 2)
    blob(S, 84, 76 - bob, 40, 19, c)
    pygame.draw.polygon(S, _sh(c, 1.35), [(60, 64 - bob), (110, 60 - bob), (100, 68 - bob), (64, 72 - bob)])
    blob(S, 118, 66 - bob, 17, 13, c)
    blob(S, 132, 71 - bob, 12, 8, (232, 226, 214), 1.0, .8)
    pygame.draw.polygon(S, (20, 18, 18), [(108, 58 - bob), (140, 66 - bob), (132, 70 - bob), (112, 66 - bob)])        # the dark face stripe
    pygame.draw.circle(S, (20, 16, 16), (141, 70 - bob), 3)
    eye(S, 122, 62 - bob, 3, (60, 40, 20)); tri(S, [(110, 55 - bob), (113, 44 - bob), (121, 54 - bob)], (50, 46, 46))


def _hawk(S, f, bob, P):
    c = P["coat"]; fl = 0 if f < 0 else (-1, 0, 1, 0)[f]
    _wing(S, (78, 54 - bob), 0, _sh(c, .8), _sh(c, .95), fl - .2, 46, True)
    pygame.draw.polygon(S, _sh(c, .7), [(60, 70 - bob), (30, 86 - bob), (36, 94 - bob), (66, 80 - bob)])                  # tail
    pygame.draw.polygon(S, _sh(c, .9), [(58, 72 - bob), (36, 88 - bob), (44, 92 - bob), (68, 80 - bob)])
    blob(S, 86, 66 - bob, 28, 17, c)
    blob(S, 90, 72 - bob, 17, 10, P["belly"], 1.1, .85)
    blob(S, 112, 52 - bob, 13, 12, _sh(c, 1.1))
    pygame.draw.polygon(S, (240, 196, 60), [(121, 48 - bob), (140, 56 - bob), (123, 62 - bob)]); pygame.draw.polygon(S, (200, 150, 30), [(130, 53 - bob), (140, 56 - bob), (127, 59 - bob)])
    eye(S, 116, 49 - bob, 3, (230, 170, 40))
    for x in (86, 98):
        limb(S, x, 80 - bob, x - 2, 92 - bob, 4, (240, 196, 60))


def _bear(S, f, bob, P):
    c = P["coat"]
    legs4(S, f, (54, 68, 102, 114), 76, c, 15, 6)
    pygame.draw.circle(S, _sh(c, .8), (44, 62 - bob), 6)
    blob(S, 82, 66 - bob, 40, 30, c)
    blob(S, 118, 54 - bob, 21, 19, c)
    blob(S, 134, 62 - bob, 12, 9, P["belly"], 1.0, .8)
    pygame.draw.circle(S, (24, 18, 16), (143, 60 - bob), 3)
    for ex in (108, 126): pygame.draw.circle(S, _sh(c, .66), (ex, 36 - bob), 8); pygame.draw.circle(S, _sh(c, 1.05), (ex, 36 - bob), 6); pygame.draw.circle(S, P["belly"], (ex, 37 - bob), 3)
    eye(S, 124, 50 - bob, 3, (50, 34, 20))
    for x in (54, 68, 102, 114): pygame.draw.line(S, (232, 226, 214), (x + 4, GY - 1), (x + 9, GY - 1), 3)


def _fox(S, f, bob, P):
    c = P["coat"]
    sway = 0 if f < 0 else (-3, 0, 3, 0)[f]
    pygame.draw.ellipse(S, _sh(c, .7), (14 + sway, 36 - bob, 56, 30)); pygame.draw.ellipse(S, c, (17 + sway, 38 - bob, 50, 25))
    pygame.draw.ellipse(S, (250, 240, 220), (14 + sway, 42 - bob, 18, 18))
    for i in range(3): pygame.draw.circle(S, (255, 150 - i * 30, 40), (26 + sway - i * 2, 50 - bob - i * 4), 4 - i)          # embers in the tail
    legs4(S, f, (60, 72, 98, 108), 74, (50, 38, 34), 7, 8)
    blob(S, 84, 68 - bob, 30, 16, c)
    blob(S, 98, 72 - bob, 14, 9, (250, 240, 220), 1.0, .85)
    blob(S, 112, 54 - bob, 15, 13, c)
    pygame.draw.polygon(S, _sh(c, .75), [(120, 46 - bob), (142, 56 - bob), (122, 62 - bob)]); pygame.draw.polygon(S, c, [(121, 48 - bob), (139, 56 - bob), (123, 60 - bob)])
    pygame.draw.circle(S, (20, 16, 16), (141, 56 - bob), 3)
    tri(S, [(100, 44 - bob), (104, 20 - bob), (116, 42 - bob)], (50, 38, 34)); tri(S, [(112, 42 - bob), (122, 22 - bob), (126, 44 - bob)], (60, 44, 38))
    eye(S, 118, 51 - bob, 3, (230, 150, 30))


def _tortoise(S, f, bob, P):
    c = P["coat"]
    legs4(S, f, (52, 66, 100, 114), 84, (112, 130, 96), 14, 4)
    blob(S, 128, 74 - bob, 13, 11, (122, 142, 104)); pygame.draw.circle(S, (20, 20, 16), (135, 72 - bob), 2)
    eye(S, 131, 69 - bob, 2, (30, 30, 20))
    pygame.draw.ellipse(S, _sh(c, .6), (36, 36 - bob, 90, 60)); pygame.draw.ellipse(S, c, (39, 38 - bob, 84, 54))
    pygame.draw.ellipse(S, _sh(c, 1.18), (48, 40 - bob, 50, 28))
    for sx_, sy_ in ((80, 56), (62, 52), (98, 58), (70, 70), (92, 72), (82, 42)):
        pygame.draw.ellipse(S, _sh(c, .74), (sx_ - 11, sy_ - 8 - bob, 22, 16), 2)
    pygame.draw.ellipse(S, (96, 140, 84), (52, 44 - bob, 20, 8)); pygame.draw.ellipse(S, (120, 164, 100), (56, 44 - bob, 12, 4))      # moss
    pygame.draw.line(S, _sh(c, .55), (44, 86 - bob), (118, 86 - bob), 4)


def _sprite(S, f, bob, P):
    fl = 0 if f < 0 else (-1, 0, 1, 0)[f]
    glow = pygame.Surface((CW, CH), pygame.SRCALPHA)
    for r_, a_ in ((52, 14), (42, 18), (32, 22), (22, 26)): pygame.draw.circle(glow, (200, 255, 240, a_), (80, 58 - bob), r_)
    S.blit(glow, (0, 0))
    w_ = pygame.Surface((CW, CH), pygame.SRCALPHA)            # four dragonfly wings, beating
    for tip, base in (((50 - fl * 4, 8 - bob + fl * 5), (76, 56 - bob)), ((34 - fl * 2, 26 - bob + fl * 4), (76, 62 - bob)),
                      ((98 + fl * 3, 10 - bob + fl * 5), (84, 56 - bob)), ((118 + fl * 2, 28 - bob + fl * 4), (84, 62 - bob))):
        mid = ((tip[0] + base[0]) / 2 + (6 if tip[0] > base[0] else -6), (tip[1] + base[1]) / 2 - 8)
        pygame.draw.polygon(w_, (190, 240, 255, 150), [base, mid, tip, ((tip[0] + base[0]) / 2 - 3, (tip[1] + base[1]) / 2 + 10)])
        pygame.draw.polygon(w_, (240, 255, 255, 230), [base, mid, tip, ((tip[0] + base[0]) / 2 - 3, (tip[1] + base[1]) / 2 + 10)], 2)
    S.blit(w_, (0, 0))
    limb(S, 74, 76 - bob, 70 + (f == 1) * 3, 100, 6, P["coat"]); limb(S, 86, 76 - bob, 90 - (f == 3) * 3, 100, 6, _sh(P["coat"], .9))
    blob(S, 80, 66 - bob, 13, 17, P["coat"])
    blob(S, 80, 40 - bob, 14, 13, (248, 224, 196))
    pygame.draw.polygon(S, P["hair"], [(66, 38 - bob), (74, 22 - bob), (92, 24 - bob), (96, 40 - bob), (88, 32 - bob), (74, 34 - bob)])
    tri(S, [(94, 36 - bob), (104, 28 - bob), (96, 42 - bob)], (248, 224, 196))      # a pointed ear
    eye(S, 86, 41 - bob, 2, (60, 150, 200))
    pygame.draw.circle(S, (255, 250, 200), (100, 62 - bob), 6); pygame.draw.line(S, (200, 180, 120), (88, 68 - bob), (100, 62 - bob), 2)        # a glowing wand tip


def _panther(S, f, bob, P):
    c = P["coat"]
    sway = 0 if f < 0 else (-4, 0, 4, 0)[f]
    pygame.draw.lines(S, _sh(c, .6), False, [(52, 66 - bob), (34, 62 - bob), (22 + sway, 44 - bob), (28 + sway, 30 - bob)], 12)
    pygame.draw.lines(S, c, False, [(52, 66 - bob), (34, 62 - bob), (22 + sway, 44 - bob), (28 + sway, 30 - bob)], 8)
    legs4(S, f, (58, 70, 100, 110), 76, c, 9, 10)
    blob(S, 82, 68 - bob, 36, 16, c)
    blob(S, 118, 54 - bob, 17, 14, c)
    blob(S, 132, 60 - bob, 10, 7, _sh(c, 1.15), 1.0, .8)
    pygame.draw.circle(S, (200, 100, 130), (140, 58 - bob), 3)
    for ex in (108, 124): pygame.draw.circle(S, _sh(c, .66), (ex, 41 - bob), 6); pygame.draw.circle(S, _sh(c, 1.05), (ex, 42 - bob), 4)
    eye(S, 125, 51 - bob, 3, (220, 230, 40)); pygame.draw.circle(S, (255, 255, 120), (127, 51 - bob), 1)
    pygame.draw.circle(S, (130, 80, 170), (126, 51 - bob), 5, 1)


def _pseudo(S, f, bob, P, camo=False):
    c = P["coat"]; fl = 0 if f < 0 else (-1, 0, 1, 0)[f]
    sway = 0 if f < 0 else (-3, 0, 3, 0)[f]
    # the long barbed tail with its stinger
    pygame.draw.lines(S, _sh(c, .62), False, [(60, 72 - bob), (42, 78 - bob), (28 + sway, 66 - bob), (22 + sway, 46 - bob)], 11)
    pygame.draw.lines(S, c, False, [(60, 72 - bob), (42, 78 - bob), (28 + sway, 66 - bob), (22 + sway, 46 - bob)], 7)
    pygame.draw.polygon(S, (236, 226, 196), [(17 + sway, 48 - bob), (22 + sway, 30 - bob), (28 + sway, 48 - bob)])
    pygame.draw.polygon(S, (150, 220, 90), [(20 + sway, 40 - bob), (22 + sway, 32 - bob), (25 + sway, 40 - bob)])
    _wing(S, (88, 56 - bob), 0, _sh(c, .75), (214, 140, 110), fl - .1, 40)
    legs4(S, f, (66, 78, 96, 106), 76, _sh(c, .9), 8, 8)
    blob(S, 82, 70 - bob, 30, 14, c)
    blob(S, 86, 76 - bob, 20, 8, P["belly"], 1.05, .85)
    for i in range(8):                                                           # a ridge of spines along the back
        x = 60 + i * 6; pygame.draw.polygon(S, _sh(c, .6), [(x, 58 - bob + (i % 2)), (x + 3, 51 - bob), (x + 6, 58 - bob)])
    blob(S, 118, 56 - bob, 15, 12, c)
    pygame.draw.polygon(S, _sh(c, .7), [(126, 52 - bob), (146, 60 - bob), (126, 66 - bob)]); pygame.draw.polygon(S, c, [(127, 54 - bob), (143, 60 - bob), (127, 64 - bob)])
    for tx in (134, 139): pygame.draw.polygon(S, (250, 248, 236), [(tx, 61 - bob), (tx + 3, 61 - bob), (tx + 1, 66 - bob)])
    pygame.draw.polygon(S, (236, 226, 196), [(108, 46 - bob), (102, 30 - bob), (114, 44 - bob)]); pygame.draw.polygon(S, (236, 226, 196), [(118, 44 - bob), (116, 26 - bob), (124, 44 - bob)])    # two horns
    eye(S, 124, 54 - bob, 3, (255, 214, 60))


def _gryphon(S, f, bob, P):
    c = P["coat"]; fl = 0 if f < 0 else (-1, 0, 1, 0)[f]
    _wing(S, (84, 52 - bob), 0, _sh(c, .78), _sh(c, .98), fl - .1, 50, True)
    limb(S, 54, 72 - bob, 38, 80 - bob, 8, c); pygame.draw.polygon(S, _sh(c, .6), [(34, 76 - bob), (22, 84 - bob), (38, 90 - bob)])      # tufted tail
    legs4(S, f, (62, 74, 98, 108), 78, c, 10, 9)
    for x in (98, 108): pygame.draw.line(S, (250, 200, 60), (x + 4, GY - 1), (x + 9, GY - 1), 3)
    blob(S, 80, 70 - bob, 32, 18, c)
    blob(S, 108, 58 - bob, 21, 15, (244, 242, 232))                              # the white eagle breast and neck
    blob(S, 120, 46 - bob, 14, 13, (248, 246, 238))
    pygame.draw.polygon(S, (240, 196, 60), [(128, 40 - bob), (150, 52 - bob), (130, 56 - bob)]); pygame.draw.polygon(S, (200, 150, 30), [(138, 46 - bob), (150, 52 - bob), (133, 54 - bob)])
    eye(S, 124, 43 - bob, 3, (240, 170, 30))
    for i in range(3): pygame.draw.polygon(S, (248, 246, 238), [(108 + i * 5, 32 - bob), (112 + i * 5, 22 - bob), (116 + i * 5, 34 - bob)])


LOOKS = {
    "wolf_pup": (_wolf, dict(coat=(128, 130, 140), belly=(208, 206, 200)), 1.0),
    "delver_badger": (_badger, dict(coat=(98, 92, 90), belly=(232, 226, 214)), 1.0),
    "skyhawk": (_hawk, dict(coat=(150, 104, 62), belly=(238, 226, 200)), 1.0),
    "cave_bear_cub": (_bear, dict(coat=(116, 78, 48), belly=(190, 150, 104)), 1.1),
    "ember_fox": (_fox, dict(coat=(214, 112, 40), belly=(250, 240, 220)), .95),
    "granite_tortoise": (_tortoise, dict(coat=(122, 122, 128), belly=(150, 160, 130)), 1.05),
    "glimmer_sprite": (_sprite, dict(coat=(110, 190, 170), hair=(150, 90, 200)), .8),
    "shadow_panther": (_panther, dict(coat=(54, 46, 70), belly=(80, 70, 96)), 1.0),
    "pseudo_dragon": (_pseudo, dict(coat=(168, 78, 52), belly=(232, 196, 120)), .9),
    "gryphon_hatchling": (_gryphon, dict(coat=(196, 148, 80), belly=(244, 242, 232)), 1.05),
}


def pet_sprite(key, frame=-1, facing=1, scale=1.0, camo=False):
    """(surface, anchor): the pet facing `facing` (1 right, -1 left), its feet at the anchor.  Cached; `scale` 1.0 is about 85 px wide."""
    k = (key, frame if frame >= 0 else -1, 1 if facing >= 0 else -1, round(scale, 2), bool(camo))
    got = _CACHE.get(k)
    if got is not None: return got
    if len(_CACHE) > 400: _CACHE.clear()
    fn, P, sz = LOOKS.get(key, LOOKS["wolf_pup"])
    S = pygame.Surface((CW, CH), pygame.SRCALPHA)
    f = frame % 4 if frame >= 0 else -1
    bob = 0 if f < 0 else (0, 2, 0, 2)[f]
    pygame.draw.ellipse(S, (0, 0, 0, 0), (0, 0, 1, 1))
    if key == "pseudo_dragon": fn(S, f, bob, P, camo)
    else: fn(S, f, bob, P)
    if camo:                      # the Pseudo-Dragon's scales take the colour of the ground: grey-green and half seen through
        t = S.copy(); t.fill((120, 150, 100, 255), special_flags=pygame.BLEND_RGBA_MULT)
        S = pygame.transform.smoothscale(t, S.get_size()); S.fill((255, 255, 255, 120), special_flags=pygame.BLEND_RGBA_MULT)
    s = .5 * scale * sz
    spr = gfx.outline(gfx._finish(S, s))
    anc = (GX * s + 1, GY * s + 1)
    if facing < 0:
        spr = pygame.transform.flip(spr, True, False); anc = (spr.get_width() - anc[0], anc[1])
    got = _CACHE[k] = (spr, (int(anc[0]), int(anc[1])))
    return got
