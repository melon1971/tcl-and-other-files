"""LiveWorld RPG 1.0.29 - Pets: a companion that is yours alone, bought at the Pet Store in every town.

* PET STORE - a labelled building in every town, city and capital.  Ten pets, from a Wolf Pup to a Pseudo-Dragon; each has a level
  to buy it at and a price that grows with your level.  You can own all ten; one follows you at a time (key P: call or dismiss).
* NOT A PARTY MEMBER - a pet takes no party place (the 3 companions, hirelings and the 4/8/12/24-player groups are untouched), never
  rolls for loot and is not counted in a raid group.  It is the player's pet: it fights for you, it does not join you.
* STANCE (key R cycles, or click the pet frame): ATTACK (chases whatever hunts you), DEFEND (stays at your side, takes a share of the
  blows aimed at you) or GATHER (collects herbs, ore and carcass materials near you; comes back when a fight starts).
* ABILITIES - each pet has one or two (the Pseudo-Dragon has two plus the senses of its kind); active ones fire by themselves on a
  cooldown, passive ones are always on.  Their rank is 1 + (level - 1) // 10, so they grow with the pet.
* LEVELS - a pet earns experience from every kill (yours, its own, your companions') and from every harvest.  A pet behind your
  level catches up faster; it never passes you.  Stats and ability ranks grow with its level.
* EVERYWHERE YOU GO - it follows you into dungeons, raids, city raids and battlegrounds.  Monsters never aim at a pet (it guards you
  instead), and a pet whose health runs out is simply knocked out: it respawns at your side at full health after 25 s, or at once when you leave
  a dungeon, raid or battleground - it is never lost, keeps its level, experience and stance, and costs nothing.
* NPC PETS - adventurers on both sides (and the battleground bots) can have a pet of their own, chosen by who they are; it is
  drawn at their heels and adds to their strength.
State is kept in the world's meta table (key "pets"), so older saves simply start with no pets.
"""
import json
import math
import random
import zlib

STANCES = ("attack", "defend", "gather")
STANCE_TITLE = {"attack": "Attack", "defend": "Defend", "gather": "Gather"}
STANCE_TEXT = {"attack": "chases and fights whatever hunts you", "defend": "stays at your side and takes a share of the blows meant for you",
               "gather": "collects herbs, ore and carcass materials near you (returns when a fight starts)"}
PET_MAX = 100                     # level cap = the player's
KO_TICKS = 4 * 25                 # a knocked-out pet respawns at your side, at full health, after 25 s (at once when you leave a dungeon, raid or battleground)
GATHER_R = 18.0                   # how far from you a pet in Gather stance will fetch
LEASH_WORLD = 32.0                # farther than this from you and it catches up at once
LEASH_INST = 14.0

# key: name, role, flying, level to buy, gold per level, health x, damage x, speed (tiles per tick), armour (share of guarded damage it shrugs off),
#      reach (1.2 = bite, more = ranged), ability keys, innate traits, description
SPECIES = {
    "wolf_pup": dict(name="Wolf Pup", role="Fighter", fly=False, need=1, unit=8, hp=1.0, atk=1.15, spd=.95, armor=.10, reach=1.3,
                     abil=("rending_bite", "pack_howl"), traits=(),
                     desc="A grey hill-wolf pup. Fierce, loyal and always first into a fight."),
    "delver_badger": dict(name="Delver Badger", role="Gatherer", fly=False, need=1, unit=7, hp=1.25, atk=.6, spd=.85, armor=.20, reach=1.3,
                          abil=("forager", "lucky_find"), traits=(),
                          desc="A stout burrower with a nose for herbs and ore. Sent out to gather, it comes back with more."),
    "skyhawk": dict(name="Skyhawk", role="Scout", fly=True, need=3, unit=9, hp=.7, atk=1.0, spd=1.15, armor=0.0, reach=6.5,
                    abil=("dive", "keen_eyes"), traits=(),
                    desc="A hawk of the high crags. Strikes from the air and spots weak points and distant herbs."),
    "cave_bear_cub": dict(name="Cave Bear Cub", role="Tank", fly=False, need=5, unit=10, hp=2.1, atk=.6, spd=.85, armor=.35, reach=1.4,
                          abil=("thick_hide", "roar"), traits=(),
                          desc="A cub of the deep caves already built like a wall. Takes the blows meant for you."),
    "ember_fox": dict(name="Ember Fox", role="Fighter", fly=False, need=8, unit=11, hp=.9, atk=1.1, spd=1.1, armor=0.0, reach=1.3,
                      abil=("ember_bite", "smoke_step"), traits=(),
                      desc="A red fox whose bite leaves embers behind, and whose smoke makes you hard to hit."),
    "granite_tortoise": dict(name="Granite Tortoise", role="Tank", fly=False, need=10, unit=10, hp=2.6, atk=.4, spd=.6, armor=.50, reach=1.3,
                             abil=("shell_ward",), traits=(),
                             desc="Slow, huge and nearly unbreakable. Raises a ward of stone around you when you are hurt."),
    "glimmer_sprite": dict(name="Glimmer Sprite", role="Healer", fly=True, need=12, unit=16, hp=.75, atk=.5, spd=1.05, armor=0.0, reach=6.0,
                           abil=("mending_light", "moon_blessing"), traits=(),
                           desc="A tiny winged light. Mends your wounds in a fight and quickens the mind between them."),
    "shadow_panther": dict(name="Shadow Panther", role="Fighter", fly=False, need=15, unit=14, hp=1.1, atk=1.35, spd=1.2, armor=.05, reach=1.4,
                           abil=("pounce", "hamstring"), traits=(),
                           desc="A black panther cub. Leaps on its prey, then cripples whatever tries to run."),
    "pseudo_dragon": dict(name="Pseudo-Dragon", role="Hybrid", fly=True, need=20, unit=30, hp=1.0, atk=1.0, spd=1.1, armor=.15, reach=1.5,
                          abil=("poison_sting", "magic_resistance"), traits=("keen_senses", "darkvision", "telepathy", "camouflage"),
                          desc="A small dragon no bigger than a cat, with a barbed tail, bright eyes and scales that match the ground it rests on."),
    "gryphon_hatchling": dict(name="Gryphon Hatchling", role="Flying Fighter", fly=True, need=25, unit=20, hp=1.2, atk=1.15, spd=1.25, armor=.05, reach=1.5,
                              abil=("wing_buffet", "updraft"), traits=(),
                              desc="A young gryphon, all beak, claw and wing. Beats foes back and lifts your stride."),
}
SPECIES_ORDER = ("wolf_pup", "delver_badger", "skyhawk", "cave_bear_cub", "ember_fox", "granite_tortoise", "glimmer_sprite", "shadow_panther",
                 "pseudo_dragon", "gryphon_hatchling")
assert set(SPECIES_ORDER) == set(SPECIES) and len(SPECIES) == 10

# key: name, kind, cooldown in seconds (0 = always on)
ABILITIES = {
    "rending_bite": ("Rending Bite", "active", 8), "pack_howl": ("Pack Howl", "active", 30),
    "forager": ("Forager", "passive", 0), "lucky_find": ("Lucky Find", "passive", 0),
    "dive": ("Dive", "active", 7), "keen_eyes": ("Keen Eyes", "passive", 0),
    "thick_hide": ("Thick Hide", "passive", 0), "roar": ("Roar", "active", 25),
    "ember_bite": ("Ember Bite", "active", 9), "smoke_step": ("Smoke Step", "passive", 0),
    "shell_ward": ("Shell Ward", "active", 20),
    "mending_light": ("Mending Light", "active", 7), "moon_blessing": ("Moon Blessing", "passive", 0),
    "pounce": ("Pounce", "active", 14), "hamstring": ("Hamstring", "active", 9),
    "poison_sting": ("Poison Sting", "active", 10), "magic_resistance": ("Magic Resistance", "passive", 0),
    "wing_buffet": ("Wing Buffet", "active", 12), "updraft": ("Updraft", "passive", 0),
}
# the Pseudo-Dragon's innate traits (its kind's senses): always on, no rank
TRAITS = {
    "keen_senses": ("Keen Senses", "Sharp eyes, ears and nose: +25% gathering range, and a better chance to spot the best materials."),
    "darkvision": ("Darkvision & Blindsight", "Sees in the dark and senses what it cannot see: +10% damage at night and in every dungeon, raid and battleground."),
    "telepathy": ("Limited Telepathy", "Speaks into your mind: warns you when an Elite monster lurks within 25 tiles."),
    "camouflage": ("Camouflage", "Its scales take the colour of the ground. At rest it blends in, and its first strike from hiding hits 50% harder."),
}


def pet_rank(level):
    return max(1, min(10, 1 + (int(level) - 1) // 10))


def ability_text(key, rank):
    """What an ability does at this rank, in words for the guide, the store and the tooltip."""
    r = rank
    return {
        "rending_bite": f"Bite that bleeds the foe for {int((1.2 + .25 * r) * 100)}% of the pet's damage over 5 s.",
        "pack_howl": f"A howl at the start of a fight: +{4 + r}% damage for you for 10 s.",
        "forager": f"Gathers {10 + 4 * r}% more: a chance of a double harvest, and +{r * 1.5:.1f} tiles of gathering range.",
        "lucky_find": f"{5 + 2 * r}% of its harvests turn up a bonus find (Arcane Dust, Spirit Essence or a rare herb).",
        "dive": f"Swoops on the foe for {int((1.5 + .12 * r) * 100)}% damage from the air.",
        "keen_eyes": f"+{1 + .6 * r:.1f}% critical strike chance for you, and +25% gathering range.",
        "thick_hide": f"Takes {6 + 1.2 * r:.0f}% of the blows aimed at you in any fighting stance (half as much again in Defend).",
        "roar": f"Roars at foes near you: you take {10 + r}% less damage for 8 s.",
        "ember_bite": f"Bite that burns the foe for {int((.9 + .22 * r) * 100)}% of the pet's damage over 6 s.",
        "smoke_step": f"Smoke at your heels: +{2 + .8 * r:.1f}% chance to dodge a blow.",
        "shell_ward": f"A ward of stone on you that absorbs {25 + 3 * r}% of the pet's health, for 12 s, when you are hurt or a fight begins.",
        "mending_light": f"Heals you for {5 + .8 * r:.1f}% of your health (and itself) when you are hurt.",
        "moon_blessing": f"+{20 + 8 * r}% mana regeneration for you.",
        "pounce": f"Leaps on the foe for {int((1.6 + .15 * r) * 100)}% damage and stuns it for {1 + .1 * r:.1f} s.",
        "hamstring": f"A raking strike for 100% damage that halves the foe's speed for 5 s.",
        "poison_sting": f"Tail sting: poisons the foe for {int((1.4 + .3 * r) * 100)}% of the pet's damage over 6 s" + (", and the poison can put it to sleep (stun) for 3 s." if r >= 6 else " (from rank 6 it can also put the foe to sleep)."),
        "magic_resistance": f"Spells and boss mechanics hurt you {8 + 2 * r}% less.",
        "wing_buffet": f"Beats its wings: foes within 3 tiles take {int((.8 + .1 * r) * 100)}% damage and are stunned for 0.6 s.",
        "updraft": f"+{3 + .6 * r:.1f}% run speed for you.",
    }[key]


def pet_stats(key, level):
    sp = SPECIES[key]; lvl = max(1, int(level))
    return {"maxhp": int((60 + lvl * 22) * sp["hp"]), "dmg": round((3 + lvl * 1.3) * sp["atk"], 1)}


def xp_need(level):
    """Experience from one pet level to the next."""
    return 40 + int(level) ** 2 * 3 // 2


# NPC pets: which pets a class of adventurer favours (the first one they can afford the level for, then by who they are)
NPC_LIKES = {"Warrior": ("wolf_pup", "cave_bear_cub"), "Paladin": ("gryphon_hatchling", "granite_tortoise", "wolf_pup"), "Juggernaut": ("cave_bear_cub", "granite_tortoise"),
             "Ranger": ("skyhawk", "wolf_pup", "shadow_panther"), "Mage": ("ember_fox", "pseudo_dragon", "glimmer_sprite"), "Rogue": ("shadow_panther", "ember_fox"),
             "Cleric": ("glimmer_sprite", "granite_tortoise"), "Druid": ("cave_bear_cub", "delver_badger", "glimmer_sprite"), "Shaman": ("granite_tortoise", "glimmer_sprite"),
             "Warlock": ("pseudo_dragon", "ember_fox", "shadow_panther"), "Berserker": ("wolf_pup", "shadow_panther"), "Monk": ("delver_badger", "skyhawk", "ember_fox")}
NPC_PET_PCT = 38                    # of adventurers (level 3 and up) have one
PET_NAMES = ["Ash", "Pip", "Bramble", "Cinder", "Fen", "Juniper", "Maple", "Nettle", "Onyx", "Rook", "Sorrel", "Tansy", "Wren", "Ziggy", "Biscuit",
             "Clover", "Dusk", "Ember", "Flint", "Gideon", "Hazel", "Ivy", "Kit", "Lark", "Moss", "Nibs", "Pebble", "Quill", "Rusty", "Thistle"]


class _Rt:
    """The live side of the active pet - where it stands, its health, its cooldowns.  Never saved (the level, xp and stance are)."""
    def __init__(self, key, x, y):
        self.key = key; self.x = x; self.y = y; self.hp = 1.0; self.maxhp = 1; self.ctx = None; self.down_until = 0
        self.cd = {}; self.dots = {}; self.tgt = None; self.atk_t = -99; self.hit_t = -99; self.node = None; self.node_t = 0
        self.camo = False; self.warned = {}; self.face = 1; self.dirty_t = 0; self.say_t = -999; self.search_t = 0; self.busy = 0; self.hp_f = 1.0


class PetMixin:
    """Mixed into engine.World."""

    # ------------------------------------------------------------ state (meta "pets")
    def _pets(self):
        st = getattr(self, "_pet_st", None)
        if st is None:
            raw = self._jmeta("pets", None)
            owned = {}
            for k, r in (raw.get("owned") or {}).items() if isinstance(raw.get("owned"), dict) else ():
                if k not in SPECIES or not isinstance(r, dict): continue
                try: lvl = max(1, min(PET_MAX, int(r.get("level", 1))))
                except (TypeError, ValueError): lvl = 1
                try: xp = max(0, int(r.get("xp", 0)))
                except (TypeError, ValueError): xp = 0
                stance = r.get("stance") if r.get("stance") in STANCES else "attack"
                nm = r.get("name") if isinstance(r.get("name"), str) and r.get("name") else PET_NAMES[zlib.crc32(k.encode()) % len(PET_NAMES)]
                owned[k] = {"name": nm[:16], "level": lvl, "xp": xp, "stance": stance}
            act = raw.get("active") if raw.get("active") in owned else ""
            st = self._pet_st = {"owned": owned, "active": act, "dirty": False}
        return st

    def _pets_flush(self):
        """Write the pets to the meta table (no commit - the caller commits)."""
        st = self._pets()
        self._setmeta("pets", json.dumps({"v": 1, "owned": st["owned"], "active": st["active"]})); st["dirty"] = False

    def _pets_save(self):
        self._pets_flush(); self.db.commit()

    def _pet_active(self):
        st = self._pets()
        return (st["active"], st["owned"][st["active"]]) if st["active"] else None

    # ------------------------------------------------------------ the store
    def at_petshop(self):
        return bool(self._near_station("petshop", 7.0)) and not self.inst

    def pet_price(self, key):
        return max(10, int(SPECIES[key]["unit"] * max(10, self.player["level"]) * getattr(self, "BUY_MULT", 1)))

    def pet_start_level(self):
        """A new pet is a youngster, but not a newborn: about 60% of your level."""
        return max(1, min(PET_MAX, int(self.player["level"] * .6)))

    def buy_pet(self, key):
        if not self.at_petshop(): return "Visit the Pet Store in any town to buy a pet."
        sp = SPECIES.get(key)
        if sp is None: return "The shopkeeper has never heard of that animal."
        st = self._pets(); p = self.player
        if key in st["owned"]: return f"You already have {st['owned'][key]['name']} the {sp['name']}."
        if p["level"] < sp["need"]: return f"A {sp['name']} is for adventurers of level {sp['need']} and up."
        price = self.pet_price(key)
        if p["gold"] < price: return f"A {sp['name']} costs {price:,} gold. You have {p['gold']:,}."
        p["gold"] -= price
        nm = next((n for n in PET_NAMES[zlib.crc32(key.encode()) % len(PET_NAMES):] + PET_NAMES if n not in {r["name"] for r in st["owned"].values()}), "Pet")
        st["owned"][key] = {"name": nm, "level": self.pet_start_level(), "xp": 0, "stance": "attack"}
        called = ""
        if not st["active"]:
            st["active"] = key; self._pet_rt = None; called = " It follows you at once."
        self._pets_save(); self._save_player_fast()
        return f"{nm} the {sp['name']} (level {st['owned'][key]['level']}) is yours for {price:,} gold.{called} Press P to call or dismiss a pet, R to change its stance."

    def pet_store_view(self):
        if not self.at_petshop(): return None
        st = self._pets(); p = self.player; out = []
        for k in SPECIES_ORDER:
            sp = SPECIES[k]; r = st["owned"].get(k)
            out.append({"key": k, "name": sp["name"], "role": sp["role"], "fly": sp["fly"], "need": sp["need"], "price": self.pet_price(k), "owned": bool(r),
                        "pet_name": r["name"] if r else "", "level_ok": p["level"] >= sp["need"], "desc": sp["desc"],
                        "abilities": [(ABILITIES[a][0], ABILITIES[a][1], ability_text(a, 1)) for a in sp["abil"]],
                        "traits": [TRAITS[t] for t in sp["traits"]], "start": self.pet_start_level(),
                        "hp": pet_stats(k, self.pet_start_level())["maxhp"], "dmg": pet_stats(k, self.pet_start_level())["dmg"]})
        t = self._tavern_town() if hasattr(self, "_tavern_town") else None
        return {"town": t.name if t else "", "gold": p["gold"], "pets": out, "active": st["active"], "owned_n": len(st["owned"])}

    # ------------------------------------------------------------ calling, dismissing, stance
    def call_pet(self, key):
        st = self._pets(); sp = SPECIES.get(key)
        if sp is None or key not in st["owned"]: return "You do not own that pet."
        if st["active"] == key: return f"{st['owned'][key]['name']} is already at your side."
        st["active"] = key; self._pet_rt = None; self._pets_save()
        r = st["owned"][key]
        return f"{r['name']} the {sp['name']} comes to your side ({STANCE_TITLE[r['stance']]} stance)."

    def dismiss_pet(self):
        st = self._pets()
        if not st["active"]: return "You have no pet with you."
        r = st["owned"][st["active"]]; st["active"] = ""; self._pet_rt = None; self._pets_save()
        return f"{r['name']} goes to rest. Press P to call a pet."

    def set_pet_stance(self, stance):
        a = self._pet_active()
        if a is None: return "You have no pet with you. Press P to call one."
        if stance not in STANCES: return "Pets know the Attack, Defend and Gather stances."
        a[1]["stance"] = stance; rt = getattr(self, "_pet_rt", None)
        if rt is not None: rt.node = None; rt.tgt = None
        self._pets_save()
        return f"{a[1]['name']}: {STANCE_TITLE[stance]} stance - {STANCE_TEXT[stance]}."

    def cycle_pet_stance(self):
        a = self._pet_active()
        if a is None: return "You have no pet with you. Press P to call one."
        return self.set_pet_stance(STANCES[(STANCES.index(a[1]["stance"]) + 1) % len(STANCES)])

    # ------------------------------------------------------------ experience
    def pet_gain_xp(self, n):
        """Experience for the active pet.  Returns True when it gained a level."""
        a = self._pet_active()
        if a is None or n <= 0: return False
        key, r = a; cap = min(PET_MAX, self.player["level"]); up = False
        if r["level"] >= cap: return False
        r["xp"] += int(n)
        while r["level"] < cap and r["xp"] >= xp_need(r["level"]):
            r["xp"] -= xp_need(r["level"]); r["level"] += 1; up = True
        if r["level"] >= cap: r["xp"] = 0
        self._pets()["dirty"] = True
        if up:
            rt = getattr(self, "_pet_rt", None)
            if rt is not None: rt.hp = pet_stats(key, r["level"])["maxhp"]
            rk = pet_rank(r["level"])
            self.events.append(f"{r['name']} the {SPECIES[key]['name']} reaches level {r['level']}!" + (f" Its abilities are now rank {rk}." if (r["level"] - 1) % 10 == 0 else ""))
            self._pets_save()
        return up

    def pet_share_xp(self, mob_level, mult=1.0):
        """Called when something dies to you, your companions or your pet: a share of the experience for the pet."""
        a = self._pet_active()
        if a is None: return
        r = a[1]; gap = r["level"] - mob_level
        fac = 1 + .1 * min(5, -gap) if gap < 0 else 1.0 if gap <= 2 else (.8, .6, .4, .25, .15, .08)[min(gap - 3, 5)] if gap <= 8 else .03
        catch = 1 + min(2.0, max(0, self.player["level"] - r["level"]) * .08)       # behind you? it learns faster
        self.pet_gain_xp(max(1, int((12 + mob_level * 2) * fac * catch * mult)))

    # ------------------------------------------------------------ foes in the three places a pet fights
    def _pet_foes(self, x, y, dist):
        inst = self.inst
        d2 = dist * dist
        if inst is None: return self._pp_foes(x, y, dist)
        if getattr(inst, "is_arena", False):
            return [f for f in inst.reds if not f.dead and f.hp > 0 and (f.x - x) ** 2 + (f.y - y) ** 2 <= d2]
        return [m for m in inst._live_mobs() if m.hp > 0 and (m.x - x) ** 2 + (m.y - y) ** 2 <= d2]

    def _pet_hit(self, foe, dmg, rt, ability=False):
        """The pet's blow lands: world foes die to you (loot, gold, xp), instance and battleground foes fall as they do to your allies."""
        inst = self.inst
        if foe.hp <= 0: return 0
        dmg = max(1, int(dmg))
        if inst is None:
            foe.hp -= dmg; self._aggro(foe)
            if foe.hp <= 0:
                self.events.append(f"{self._pets()['owned'][rt.key]['name']} slays {foe.name.split(' #')[0]}.")
                self._player_kill(foe)          # the kill is yours (and so is the pet's share of the experience, in _player_kill)
                rt.tgt = None
        elif getattr(inst, "is_arena", False):
            if getattr(foe, "shield_until", 0) > self.tick: return 0
            if getattr(foe, "has_flag", False): dmg = int(dmg * .45)
            foe.hp -= dmg
            if foe.hp <= 0: inst._down(foe, "blue"); rt.tgt = None
        else:
            if getattr(foe, "role", "") == "boss" and inst.boss_immune(foe): return 0
            foe.hp -= dmg
            if foe.hp <= 0: inst.mob_dead(foe, by_player=False); rt.tgt = None
        return dmg

    def _pet_status(self, foe, kind, secs):
        """Stun or slow a foe (bosses shrug stuns off)."""
        if kind == "stun" and getattr(foe, "role", "") == "boss": return
        self.mstatus.setdefault(foe.id, {})[kind] = max(self.mstatus.get(foe.id, {}).get(kind, 0), self.tick + int(secs * 4))

    # ------------------------------------------------------------ movement
    def _pet_place(self, rt, ang=2.4):
        p = self.player
        rt.x, rt.y = p["x"] + math.cos(ang) * 1.6, p["y"] + math.sin(ang) * 1.6
        if self.inst is not None and self.inst.floor.get((int(rt.x), int(rt.y))) is None: rt.x, rt.y = p["x"], p["y"]

    def _pet_walk(self, rt, tx, ty, speed):
        dx, dy = tx - rt.x, ty - rt.y; d = math.hypot(dx, dy)
        if d < .05: return
        if abs(dx - dy) > .02: rt.face = 1 if dx - dy > 0 else -1
        inst = self.inst
        if inst is not None: inst._step_to(rt, tx, ty, speed); return
        st = min(speed, d); ux, uy = dx / d, dy / d
        ok = getattr(self, "terrain_ok", None)
        if ok is not None and not SPECIES[rt.key]["fly"]:
            try:
                if ok(rt.x, rt.y):
                    for rot in (0, .7, -.7, 1.4, -1.4):
                        c, s = math.cos(rot), math.sin(rot); vx, vy = ux * c - uy * s, ux * s + uy * c
                        if ok(rt.x + vx * st, rt.y + vy * st): ux, uy = vx, vy; break
                    else: return
            except Exception: pass
        from . import engine as E
        rt.x = max(0, min(E.W - .01, rt.x + ux * st)); rt.y = max(0, min(E.H - .01, rt.y + uy * st))

    # ------------------------------------------------------------ buffs the pet gives you
    def _pet_buff(self, key, name, value, secs, **extra):
        cur = self.buffs.get(key)
        if cur and cur["until"] > self.tick and not cur.get("pet"): return False       # a drink, scroll or spell of the same kind holds
        self.buffs[key] = dict({"name": name, "kind": key, "until": self.tick + int(secs * 4), "value": value, "pet": True}, **extra)
        return True

    def _pet_passives(self, rt, key, rank):
        ab = SPECIES[key]["abil"]
        if "keen_eyes" in ab: self._pet_buff("crit", "Keen Eyes", round((1 + .6 * rank) / 100, 3), 12)
        if "smoke_step" in ab: self._pet_buff("dodge", "Smoke Step", round((2 + .8 * rank) / 100, 3), 12)
        if "moon_blessing" in ab: self._pet_buff("mreg", "Moon Blessing", round((20 + 8 * rank) / 100, 2), 12)
        if "updraft" in ab: self._pet_buff("haste", "Updraft", round((3 + .6 * rank) / 100, 3), 12)

    # ------------------------------------------------------------ damage you take (called from the two places the player is hurt)
    def pet_guard_share(self, key, stance, rank):
        sp = SPECIES[key]; s = 0.0
        if stance == "defend": s += .18 + .02 * rank
        if "thick_hide" in sp["abil"] and stance != "gather": s += (.06 + .012 * rank) * (1.5 if stance == "defend" else 1.0)
        return min(.55, s)

    def _pet_absorb(self, dmg, mech=False):
        """The pet stands between you and a blow: it takes its share (and Magic Resistance softens spells); you take the rest."""
        rt = getattr(self, "_pet_rt", None); a = self._pet_active()
        if rt is None or a is None or rt.down_until or dmg <= 0: return dmg
        key, r = a; sp = SPECIES[key]; p = self.player
        if r["stance"] == "gather" or (rt.x - p["x"]) ** 2 + (rt.y - p["y"]) ** 2 > 81: return dmg
        rank = pet_rank(r["level"])
        if mech and "magic_resistance" in sp["abil"]: dmg *= 1 - (.08 + .02 * rank)
        take = dmg * self.pet_guard_share(key, r["stance"], rank)
        if take > 0:
            rt.hp -= take * (1 - sp["armor"]); rt.hit_t = self.tick; dmg -= take
            if rt.hp <= 0: self._pet_ko(rt, r)
        return max(1, int(dmg))

    def _pet_ko(self, rt, r):
        rt.hp = 0; rt.down_until = self.tick + KO_TICKS; rt.tgt = None; rt.node = None; rt.dots.clear()
        self.events.append(f"{r['name']} is knocked out! It will respawn at your side in 25 seconds.")

    # ------------------------------------------------------------ the tick
    def _pet_tick(self):
        try: self._pet_tick_body()
        except Exception:                 # a pet must never stop the world: report it once and carry on
            if not getattr(self, "_pet_err", False):
                import traceback; self._pet_err = True; traceback.print_exc()

    def _pet_tick_body(self):
        a = self._pet_active(); p = self.player
        if a is None:
            self._pet_rt = None; return
        key, rec = a; sp = SPECIES[key]; now = self.tick
        rt = getattr(self, "_pet_rt", None)
        if rt is None or rt.key != key:
            rt = self._pet_rt = _Rt(key, p["x"], p["y"]); self._pet_place(rt); rt.maxhp = pet_stats(key, rec["level"])["maxhp"]; rt.hp = rt.maxhp
        mx = pet_stats(key, rec["level"])["maxhp"]
        if mx != rt.maxhp: rt.hp = min(mx, rt.hp + max(0, mx - rt.maxhp)); rt.maxhp = mx          # a level-up raises health
        rt.hp = min(rt.maxhp, rt.hp)
        ctx = id(self.inst) if self.inst is not None else 0
        if ctx != rt.ctx:                       # through a portal, out of a dungeon: it stands beside you again (a knocked-out pet is back at once)
            rt.ctx = ctx; self._pet_place(rt); rt.node = None; rt.tgt = None; rt.dots.clear()
            if rt.down_until and self.inst is None: rt.down_until = 0; rt.hp = rt.maxhp
        lim = LEASH_INST if self.inst is not None else LEASH_WORLD
        if (rt.x - p["x"]) ** 2 + (rt.y - p["y"]) ** 2 > lim * lim: self._pet_place(rt); rt.node = None
        if rt.down_until:
            if now < rt.down_until: return
            rt.down_until = 0; rt.hp = rt.maxhp; self._pet_place(rt)          # respawns at your side with full health
            self.events.append(f"{rec['name']} respawns at your side.")
        down = p["hp"] <= 0 or bool(getattr(self.inst, "player_down", None) and self.inst.player_down())
        if now - rt.hit_t > 40 and now % 20 == 0 and now - self.last_combat_tick > 20: rt.hp = min(rt.maxhp, rt.hp + rt.maxhp * .03)
        if rec["xp"] and now % 240 == 0 and self._pets()["dirty"]: self._pets_flush()
        rank = pet_rank(rec["level"])
        if now % 16 == 0 and not down: self._pet_passives(rt, key, rank)
        if down: return
        # dots tick once a second
        if rt.dots and now % 4 == 0: self._pet_dot_tick(rt, rec)
        stance = rec["stance"]; busy = now - self.last_combat_tick < 20
        foes = self._pet_foes(p["x"], p["y"], 16 if stance == "attack" else 6.5) if stance != "gather" else []
        foe = self.by_id.get(rt.tgt) if rt.tgt is not None else None
        if foe is not None and foe.id not in {f.id for f in foes}: foe = None
        if foe is None and foes:
            foe = min(foes, key=lambda m: (m.x - rt.x) ** 2 + (m.y - rt.y) ** 2); rt.tgt = foe.id
        elif foe is None: rt.tgt = None
        if foe is not None:
            rt.node = None; self._pet_fight(rt, key, rec, foe, foes, rank)
        elif stance == "gather" and not busy and self.inst is None:
            self._pet_gather(rt, key, rec, rank)
        else:
            rt.node = None; self._pet_follow(rt, key, rec)
        # the Pseudo-Dragon blends into the ground when it has not fought for a moment
        rt.camo = "camouflage" in sp["traits"] and now - rt.atk_t > 12
        if "telepathy" in sp["traits"] and now % 40 == 0 and self.inst is None: self._pet_telepathy(rt, rec)

    def _pet_follow(self, rt, key, rec):
        p = self.player; ang = {"attack": 2.4, "defend": .8, "gather": 3.9}[rec["stance"]]
        tx, ty = p["x"] + math.cos(ang) * 1.9, p["y"] + math.sin(ang) * 1.9
        d = math.hypot(tx - rt.x, ty - rt.y); sp = SPECIES[key]
        if d > 1.3: self._pet_walk(rt, tx, ty, sp["spd"] * (1.7 if d > 6 else .6 if d < 3 else 1.0))

    def _pet_dmg(self, rec, key, mult=1.0):
        d = pet_stats(key, rec["level"])["dmg"] * mult
        if rec["stance"] == "defend": d *= .8
        if "darkvision" in SPECIES[key]["traits"] and (self.inst is not None or not 6 <= (self.tick // 40) % 24 < 19): d *= 1.1
        if self.rng.random() < .08: d *= 1.5
        return d * self.rng.uniform(.85, 1.2)

    def _pet_fight(self, rt, key, rec, foe, foes, rank):
        sp = SPECIES[key]; now = self.tick; reach = sp["reach"]; ranged = reach > 2
        want = reach * .75 if ranged else 1.1
        d = math.hypot(foe.x - rt.x, foe.y - rt.y)
        if d > want: self._pet_walk(rt, foe.x, foe.y, sp["spd"] * (1.8 if d > 6 else 1.0))
        d = math.hypot(foe.x - rt.x, foe.y - rt.y)
        self._pet_abilities(rt, key, rec, foe, foes, rank, d)
        if d <= reach + .6 and now - rt.atk_t >= (5 if ranged else 4):
            mult = 1.5 if (rt.camo and "camouflage" in sp["traits"]) else 1.0          # the Pseudo-Dragon's first strike from hiding
            rt.atk_t = now; rt.face = 1 if (foe.x - foe.y) - (rt.x - rt.y) > 0 else -1
            dmg = self._pet_hit(foe, self._pet_dmg(rec, key, mult), rt)
            self._pp_fx("shot" if ranged else "melee", "pet", foe.id, cls="Ranger" if ranged else "Rogue", dmg=dmg)

    def _pet_cd(self, rt, ab):
        return rt.cd.get(ab, 0) <= self.tick

    def _pet_use(self, rt, ab):
        rt.cd[ab] = self.tick + ABILITIES[ab][2] * 4

    def _pet_abilities(self, rt, key, rec, foe, foes, rank, d):
        sp = SPECIES[key]; now = self.tick; p = self.player; r = rank
        near = d <= sp["reach"] + 1.5
        mx = self._effective_maxhp()
        for ab in sp["abil"]:
            if ABILITIES[ab][1] != "active" or not self._pet_cd(rt, ab): continue
            if ab == "rending_bite" and near:
                self._pet_dot(rt, foe, "Bleeding", self._pet_dmg(rec, key, 1.2 + .25 * r) / 5, 5)
            elif ab == "pack_howl":
                if not self._pet_buff("might", "Pack Howl", round((4 + r) / 100, 3), 10): continue
            elif ab == "dive" and d <= sp["reach"] + 1:
                self._pet_hit(foe, self._pet_dmg(rec, key, 1.5 + .12 * r), rt); self._pp_fx("shot", "pet", foe.id, cls="Ranger", dmg=0)
            elif ab == "roar":
                if not self._pet_buff("def", "Roar", round((10 + r) / 100, 3), 8): continue
                self._pp_fx("taunt", "pet", "pet")
            elif ab == "ember_bite" and near:
                self._pet_dot(rt, foe, "Burning", self._pet_dmg(rec, key, .9 + .22 * r) / 6, 6)
            elif ab == "shell_ward":
                if p["hp"] > mx * .75 and now - self.last_combat_tick > 8: continue
                sh = self.buffs.get("shield")
                if sh and sh["until"] > now and sh.get("absorb", 0) > 0: continue
                ab_ = int(rt.maxhp * (.25 + .03 * r))
                self.buffs["shield"] = {"name": "Shell Ward", "kind": "shield", "until": now + 48, "absorb": ab_, "max": ab_, "pet": True}
            elif ab == "mending_light":
                if p["hp"] > mx * .8 and rt.hp > rt.maxhp * .7: continue
                amt = self._heal(mx * (.05 + .008 * r))
                rt.hp = min(rt.maxhp, rt.hp + rt.maxhp * (.05 + .008 * r))
                self._pp_fx("heal", "pet", "player", cls="Cleric", amt=int(amt))
            elif ab == "pounce" and d <= 7:
                rt.x, rt.y = foe.x - (foe.x - rt.x) * .15, foe.y - (foe.y - rt.y) * .15          # the leap
                self._pet_hit(foe, self._pet_dmg(rec, key, 1.6 + .15 * r), rt); rt.atk_t = now
                self._pet_status(foe, "stun", 1 + .1 * r); self._pp_fx("melee", "pet", foe.id, cls="Rogue", dmg=0)
            elif ab == "hamstring" and near:
                self._pet_hit(foe, self._pet_dmg(rec, key, 1.0), rt); self._pet_status(foe, "slow", 5); self._pp_fx("melee", "pet", foe.id, cls="Rogue", dmg=0)
            elif ab == "poison_sting" and near:
                self._pet_dot(rt, foe, "Poisoned", self._pet_dmg(rec, key, 1.4 + .3 * r) / 6, 6)
                if r >= 6 and self.rng.random() < .25: self._pet_status(foe, "stun", 3)           # the poison can send a foe to sleep
                self._pp_fx("melee", "pet", foe.id, cls="Warlock", dmg=0)
            elif ab == "wing_buffet" and near:
                for f in [f for f in foes if (f.x - rt.x) ** 2 + (f.y - rt.y) ** 2 <= 9]:
                    self._pet_hit(f, self._pet_dmg(rec, key, .8 + .1 * r), rt); self._pet_status(f, "stun", .6)
                self._pp_fx("melee", "pet", foe.id, cls="Paladin", dmg=0)
            else: continue
            self._pet_use(rt, ab)

    def _pet_dot(self, rt, foe, label, per_sec, secs):
        until = self.tick + secs * 4
        rt.dots[foe.id] = {"until": until, "per": max(1.0, per_sec), "label": label}
        st = self.mstatus.setdefault(foe.id, {})
        if not st.get("dot"):               # shows on the target frame like a spell's burn; the damage is the pet's own (dmg 0 here, so the spell tick leaves it alone)
            st["dot"] = {"name": label, "until": until, "dmg": 0, "next": until + 1, "pet": True}

    def _pet_dot_tick(self, rt, rec):
        for fid, dt in list(rt.dots.items()):
            f = self.by_id.get(fid)
            if f is None or f.hp <= 0 or getattr(f, "dead", False) or self.tick >= dt["until"]:
                rt.dots.pop(fid, None)
                if f is not None and ((self.mstatus.get(fid) or {}).get("dot") or {}).get("pet"): self.mstatus[fid].pop("dot", None)
                continue
            self._pet_hit(f, dt["per"], rt)

    def _pet_telepathy(self, rt, rec):
        """The Pseudo-Dragon's whisper: an Elite monster within 25 tiles that is not hunting you yet."""
        p = self.player
        g = self._grid(); best = None
        for cx in range(int(p["x"] - 25) >> 3, (int(p["x"] + 25) >> 3) + 1):
            for cy in range(int(p["y"] - 25) >> 3, (int(p["y"] + 25) >> 3) + 1):
                for m in g.get((cx, cy), ()):
                    if m.kind == "monster" and m.hp > 0 and m.name.startswith("Elite ") and m.faction != p["faction"] and m.target != -2:
                        d = (m.x - p["x"]) ** 2 + (m.y - p["y"]) ** 2
                        if d <= 625 and self.tick - rt.warned.get(m.id, -9999) > 2400 and (best is None or d < best[0]): best = (d, m)
        if best is not None:
            m = best[1]; rt.warned[m.id] = self.tick
            if len(rt.warned) > 40: rt.warned = {k: v for k, v in rt.warned.items() if self.tick - v < 2400}
            dx, dy = m.x - p["x"], m.y - p["y"]
            dirn = ("east", "south-east", "south", "south-west", "west", "north-west", "north", "north-east")[int(((math.atan2(dy, dx) + math.pi / 8) % math.tau) // (math.pi / 4))]
            self.events.append(f"{rec['name']} whispers in your mind: {m.name.split(' #')[0]} lurks to the {dirn}.")

    # ------------------------------------------------------------ gathering
    def _pet_range(self, key, rank):
        sp = SPECIES[key]; rng_ = GATHER_R
        if "forager" in sp["abil"]: rng_ += rank * 1.5
        if "keen_eyes" in sp["abil"] or "keen_senses" in sp["traits"]: rng_ *= 1.25
        return rng_

    def _pet_nodes(self, rng_):
        p = self.player; out = []
        r2 = rng_ * rng_
        for kind, lst in (("herb", self.herbs_near(rng_)), ("vein", self.veins_near(rng_)), ("skin", self.skins_near(rng_))):
            for n in lst:
                if (n["x"] - p["x"]) ** 2 + (n["y"] - p["y"]) ** 2 <= r2: out.append((kind, n))
        return out

    def _pet_node_ok(self, kind, n):
        if kind == "herb": return self._herb_taken().get((n["id"] // 1000, n["id"] % 1000), 0) <= self.tick
        if kind == "vein": return self._ore_taken().get((n["id"] // 1000, n["id"] % 1000), 0) <= self.tick
        return n in self._skins() and n["until"] > self.tick

    def _pet_gather(self, rt, key, rec, rank):
        now = self.tick; sp = SPECIES[key]; p = self.player
        if rt.node is not None and not self._pet_node_ok(*rt.node): rt.node = None
        if rt.node is None:
            if now - rt.search_t < 8: self._pet_follow(rt, key, rec); return
            rt.search_t = now
            rng_ = self._pet_range(key, rank); nodes = self._pet_nodes(rng_)
            if nodes:
                rt.node = min(nodes, key=lambda kn: (kn[1]["x"] - rt.x) ** 2 + (kn[1]["y"] - rt.y) ** 2); rt.busy = 0
            else:
                self._pet_follow(rt, key, rec); return
        kind, n = rt.node
        d = math.hypot(n["x"] - rt.x, n["y"] - rt.y)
        if d > 1.0: self._pet_walk(rt, n["x"], n["y"], sp["spd"] * (1.5 if d > 5 else 1.0)); return
        rt.busy += 1                                # a moment of digging, picking or skinning
        if rt.busy < 6: return
        rt.busy = 0; rt.node = None
        self._pet_harvest(rt, key, rec, rank, kind, n)

    def _pet_harvest(self, rt, key, rec, rank, kind, n):
        r = self.rng; sp = SPECIES[key]; got = []; src = ""
        double = "forager" in sp["abil"] and r.random() < (10 + 4 * rank) / 100
        if kind == "herb":
            cnt = 1 + (1 if r.random() < .35 else 0) + (1 if double else 0)
            tk = self._herb_taken(); tk[(n["id"] // 1000, n["id"] % 1000)] = self.tick + self.HERB_RESPAWN
            got.append(("Herb:" + n["name"], cnt)); src = n["name"]
            for _ in range(cnt): self.quest_event("herb", n["name"])
        elif kind == "vein":
            b = n["band"]
            got.append(("Mat:Iron Ore", 1 + b // 2 + (1 if r.random() < .5 else 0) + (1 if double else 0)))
            if b >= 2 and r.random() < .35 + b * .1: got.append(("Mat:Arcane Dust", 1))
            if b >= 3 and r.random() < .06 * b: got.append(("Mat:Spirit Essence", 1))
            self._ore_taken()[(n["id"] // 1000, n["id"] % 1000)] = self.tick + 4 * 300; src = n["name"]
        else:
            self._skins().remove(n)
            got.append(("Mat:Leather Scrap", 1 + (1 if r.random() < .55 else 0) + (1 if n["level"] > 40 else 0) + (2 if n["elite"] else 0) + (1 if double else 0)))
            if n["elite"] and r.random() < .3: got.append(("Mat:Spirit Essence", 1))
            src = n["name"]
        luck = (5 + 2 * rank) / 100 if "lucky_find" in sp["abil"] else 0.0
        if "keen_senses" in sp["traits"]: luck += .06
        if luck and r.random() < luck:
            got.append(r.choice((("Mat:Arcane Dust", 1), ("Mat:Spirit Essence", 1), ("Mat:Arcane Dust", 2))) if kind != "herb" or rank >= 3 else ("Herb:" + n["name"], 1))
        for item, c in got: self._inv_add(item, c); self.gain(item, c, src)
        self.db.commit()
        txt = ", ".join(f"{c} {item.split(':', 1)[1]}" for item, c in got)
        self.events.append(f"{rec['name']} brings you {txt}.")
        self.pet_gain_xp(6 + self.player["level"] // 5 + (n.get("band", 0) * 2 if kind != "skin" else 2))

    # ------------------------------------------------------------ what the screen and windows see
    def pet_snapshot(self):
        a = self._pet_active(); rt = getattr(self, "_pet_rt", None)
        if a is None or rt is None: return {"pet": None}
        key, r = a; sp = SPECIES[key]
        return {"pet": {"key": key, "name": r["name"], "species": sp["name"], "level": r["level"], "x": rt.x, "y": rt.y, "hp": int(rt.hp), "maxhp": int(rt.maxhp),
                        "stance": r["stance"], "fly": sp["fly"], "down": max(0, (rt.down_until - self.tick + 3) // 4) if rt.down_until else 0,
                        "camo": rt.camo, "xp": r["xp"], "xp_need": xp_need(r["level"]), "atk": rt.atk_t, "face": rt.face, "gather": bool(rt.node) and rt.busy > 0,
                        "rank": pet_rank(r["level"])}}

    def pets_view(self):
        """The pet window (key P): every pet you own and the one at your side."""
        st = self._pets(); out = []
        for k in SPECIES_ORDER:
            r = st["owned"].get(k)
            if not r: continue
            sp = SPECIES[k]; rk = pet_rank(r["level"]); ps = pet_stats(k, r["level"])
            out.append({"key": k, "name": r["name"], "species": sp["name"], "role": sp["role"], "level": r["level"], "rank": rk, "xp": r["xp"], "xp_need": xp_need(r["level"]),
                        "stance": r["stance"], "active": st["active"] == k, "fly": sp["fly"], "maxhp": ps["maxhp"], "dmg": ps["dmg"], "desc": sp["desc"],
                        "abilities": [(ABILITIES[a][0], ABILITIES[a][1], ability_text(a, rk)) for a in sp["abil"]], "traits": [TRAITS[t] for t in sp["traits"]],
                        "guard": int(self.pet_guard_share(k, r["stance"], rk) * 100)})
        return {"pets": out, "active": st["active"], "gold": self.player["gold"], "at_shop": self.at_petshop()}

    # ------------------------------------------------------------ pets of the computer-controlled people
    def npc_pet(self, a):
        """The pet of an adventurer, a hireling or a battleground bot (None for most monsters, guards and the like).  Worked out from who
        they are, so it never needs saving: about four in ten have one, the favourite of their class, a few levels behind them."""
        if not (a.kind in ("adventurer", "ially") or getattr(a, "pvp", False)) or a.level < 3: return None
        c = self.__dict__.setdefault("_npcpet_c", {})
        hit = c.get(a.id)
        if hit is not None and hit[0] == (a.level, a.role, a.faction): return hit[1]
        h = zlib.crc32(f"{self._seed()}:{a.id}:{a.faction}:pet".encode())
        res = None
        if h % 100 < NPC_PET_PCT:
            likes = [k for k in NPC_LIKES.get(a.role, SPECIES_ORDER) if SPECIES[k]["need"] <= a.level] or [k for k in SPECIES_ORDER if SPECIES[k]["need"] <= a.level]
            if likes:
                key = likes[(h >> 8) % len(likes)]
                res = {"key": key, "name": SPECIES[key]["name"], "level": max(1, a.level - 3)}
        if len(c) > 4000: c.clear()
        c[a.id] = ((a.level, a.role, a.faction), res)
        return res
