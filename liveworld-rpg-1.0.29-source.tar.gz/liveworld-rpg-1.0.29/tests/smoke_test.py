#!/usr/bin/env python3
"""LiveWorld RPG smoke tests.

Runs the real game code headlessly (SDL dummy video/audio) against a throwaway save
folder, so it never touches ~/.local/share/liveworld-rpg.

    python3 tests/smoke_test.py                 # everything
    python3 tests/smoke_test.py ArenaMaps       # one group
    LW_PKG=/path/to/package-root python3 tests/smoke_test.py

LW_PKG is the source tree (the folder holding DEBIAN/ and usr/); it defaults to this folder's parent.
"""
import collections, hashlib, json, math, os, re, sys, tempfile, unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = Path(os.environ.get("LW_PKG", HERE.parent)).resolve()
LIB = PKG / "usr" / "lib" / "liveworld-rpg"

os.environ["LIVEWORLD_DATA"] = tempfile.mkdtemp(prefix="lw-smoke-")
os.environ["XDG_STATE_HOME"] = tempfile.mkdtemp(prefix="lw-smoke-state-")
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
sys.path.insert(0, str(LIB))

from liveworld_rpg import arena as A, instance as I, engine as E   # noqa: E402

ALL_MODES = list(A.MODES)
CLASSES = list(E.CLASSES)


def new_world(level=20, faction="Alliance", cls="Warrior"):
    """A fresh world in its own save folder."""
    E.DATA = Path(tempfile.mkdtemp(prefix="lw-world-"))
    E.DB = E.DATA / "world.db"
    w = E.World()
    w.create_character("Smoke", faction, cls)
    w.player["level"] = level
    return w


def flood(floor, start):
    start = (int(start[0]), int(start[1]))
    seen = {start}; q = collections.deque([start])
    while q:
        x, y = q.popleft()
        for n in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if n in floor and n not in seen:
                seen.add(n); q.append(n)
    return seen


def enter(w, mode):
    """Enter an arena, first leaving whatever an earlier failed check left us in."""
    if w.inst: w.leave_instance(silent=True)
    msg = w.enter_arena(mode)
    assert isinstance(w.inst, A.Arena), msg
    return w.inst


def run_until_out(w, limit):
    n = 0
    while w.inst is not None and n < limit:
        w.update(1); n += 1
    return n


# ======================================================================= package
class Package(unittest.TestCase):
    def test_versions_agree(self):
        control = (PKG / "DEBIAN" / "control").read_text()
        deb_ver = re.search(r"^Version:\s*(\S+)", control, re.M).group(1)
        game_ver = re.search(r'^VERSION = "([^"]+)"', (LIB / "liveworld_rpg" / "game.py").read_text(), re.M).group(1)
        init_ver = re.search(r'__version__\s*=\s*"([^"]+)"', (LIB / "liveworld_rpg" / "__init__.py").read_text()).group(1)
        meta = (PKG / "usr/share/metainfo/liveworld-rpg.metainfo.xml").read_text()
        meta_ver = re.search(r'<release version="([^"]+)"', meta).group(1)
        guide_head = (PKG / "usr/share/doc/liveworld-rpg/GUIDE.md").read_text().splitlines()[0]
        self.assertEqual({deb_ver, game_ver, init_ver, meta_ver}, {deb_ver},
                         f"control {deb_ver}, game.py {game_ver}, __init__ {init_ver}, metainfo {meta_ver}")
        self.assertIn(".".join(deb_ver.split(".")[:2]), guide_head)

    def test_md5sums_cover_every_file(self):
        listed = {}
        for line in (PKG / "DEBIAN" / "md5sums").read_text().splitlines():
            h, p = line.split(None, 1); listed[p.strip()] = h
        actual = {str(f.relative_to(PKG)) for f in (PKG / "usr").rglob("*") if f.is_file() and "__pycache__" not in f.parts}
        self.assertEqual(sorted(set(listed) ^ actual), [], "files missing from / extra in md5sums")
        for p, h in listed.items():
            self.assertEqual(hashlib.md5((PKG / p).read_bytes()).hexdigest(), h, p)

    def test_guide_md_matches_ingame_guide(self):
        from liveworld_rpg import guide
        md = (PKG / "usr/share/doc/liveworld-rpg/GUIDE.md").read_text()
        body = md.split("\n", 1)[1]
        want = "".join(f"\n## {t}\n\n" + "".join(f"- {l}\n" for l in lines) for t, lines in guide.PAGES)
        self.assertEqual(body.strip(), want.strip())

    def test_launchers_and_desktop_files(self):
        for b in ("liveworld-rpg", "liveworld-create-character", "liveworld-uninstall"):
            f = PKG / "usr/bin" / b
            self.assertTrue(os.access(f, os.X_OK), b)
            self.assertTrue(f.read_text().startswith("#!/bin/sh"), b)
        for d in (PKG / "usr/share/applications").glob("*.desktop"):
            txt = d.read_text()
            exe = re.search(r"^Exec=(\S+)", txt, re.M).group(1)
            self.assertTrue((PKG / "usr/bin" / exe).exists(), f"{d.name}: {exe}")

    def test_shell_scripts(self):
        """0.37.2: every script parses with /bin/sh (dash on Debian/Ubuntu) and uses no bash-only read -p."""
        import subprocess
        for f in list((PKG / "usr/bin").iterdir()) + [PKG / "DEBIAN/postinst", PKG / "DEBIAN/postrm", PKG / "build.sh"]:
            with self.subTest(script=f.name):
                self.assertEqual(subprocess.run(["sh", "-n", str(f)]).returncode, 0)
                self.assertNotIn("read -r -p", f.read_text())


# ========================================================================= saves
class Saves(unittest.TestCase):
    """0.37.2: damaged saves and settings files never stop the game starting."""

    def test_damaged_save_is_restored_from_backup(self):
        E.DATA = Path(tempfile.mkdtemp(prefix="lw-save-")); E.DB = E.DATA / "world.db"
        w, msg = E.open_world(); self.assertIsNone(msg)
        w.create_character("Keeper", "Horde", "Monk"); w.player["gold"] = 4321; w.close()
        self.assertTrue((E.DATA / "world.db.bak").exists())
        E.DB.write_bytes(b"\0not a database" * 200)
        for s in ("-wal", "-shm"):
            if (E.DATA / ("world.db" + s)).exists(): (E.DATA / ("world.db" + s)).unlink()
        w, msg = E.open_world()
        self.assertIn("restored", msg); self.assertEqual((w.player["name"], w.player["gold"]), ("Keeper", 4321)); w.close()
        self.assertTrue(list(E.DATA.glob("world.db.damaged-*")), "the damaged file must be kept")

    def test_damaged_save_without_backup_starts_fresh(self):
        E.DATA = Path(tempfile.mkdtemp(prefix="lw-save-")); E.DB = E.DATA / "world.db"
        E.DB.write_bytes(b"garbage" * 100)
        w, msg = E.open_world()
        self.assertIn("new world", msg); self.assertFalse(w.character_created()); w.close()

    def test_bad_settings_file(self):
        from liveworld_rpg import game as G
        G.SETTINGS.write_text("[1, 2, 3]")
        self.assertEqual(G.load_settings(), {})
        G.SETTINGS.write_text(json.dumps({"brightness": "bright", "vol_master": 9, "vol_sfx": float("nan"), "quality": "High"}))
        st = G.load_settings()
        self.assertEqual(G.setting_num(st, "brightness", 1.0, .7, 1.6), 1.0)
        self.assertEqual(G.setting_num(st, "vol_master", .8, 0, 1), 1)
        self.assertEqual(G.setting_num(st, "vol_sfx", .8, 0, 1), .8)
        self.assertIn(G.default_quality(), (1, 2))
        G.SETTINGS.unlink()


# ========================================================================= 0.38 magic shop
class MagicShop(unittest.TestCase):
    """Spell ranks, stat points, passives and the hotbar layout are bought at the Skill Shop in every town."""

    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.w = new_world(level=55, cls="Warrior"); cls.w.player["gold"] = 100000
        cls.layout = gfx.WorldLayout(cls.w); cls.w.station_posts = cls.layout.stations

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def at_shop(self, on=True):
        x, y = self.w.station_posts["magic"][0]
        self.w.player["x"], self.w.player["y"] = (x + 2, y + 2) if on else (x + 40, y + 40)

    def test_every_town_has_a_magic_shop(self):
        shops = self.layout.stations.get("magic", [])
        for t in self.w.towns:
            with self.subTest(town=t.name):
                self.assertTrue(any((x - t.x) ** 2 + (y - t.y) ** 2 < E.TOWN_WALL_R ** 2 for x, y in shops))

    def test_spending_only_at_the_shop_and_costs_gold(self):
        w = self.w; self.at_shop(False)
        self.assertIn("Skill Shop", w.rank_up("Cleave")); self.assertIn("Skill Shop", w.add_stat("str"))
        self.at_shop(True); g0 = w.player["gold"]; r0 = w.ability_rank("Cleave"); pts = w.rank_points_left()
        self.assertIn("rank", w.rank_up("Cleave"))
        self.assertEqual((w.ability_rank("Cleave"), w.rank_points_left()), (r0 + 1, pts - 1)); self.assertLess(w.player["gold"], g0)
        s0 = w._build()["s"]["vit"]; w.add_stat("vit", 5); self.assertEqual(w._build()["s"]["vit"], s0 + 5)

    def test_ranks_go_to_ten(self):
        w = self.w; self.at_shop(True)
        for _ in range(12): w.rank_up("Rend")
        self.assertEqual(w.ability_rank("Rend"), 10)
        self.assertIn("maximum", w.rank_up("Rend"))

    def test_passive_slots_and_choice(self):
        w = self.w; self.at_shop(True)
        for lvl, n in ((1, 1), (20, 1), (50, 1), (51, 2), (74, 2), (75, 3), (100, 3)):
            w.player["level"] = lvl; self.assertEqual(w.passive_slots(), n, lvl); self.assertEqual(len(w.equipped_passives()), n, lvl)
        w.player["level"] = 55
        for cls_, pool in E.PASSIVES.items():
            self.assertEqual(len(pool), 7, cls_)
        self.assertIn("Passive", w.equip_passive("Deep Wounds", 1))
        self.assertIn("Deep Wounds", [p["name"] for p in w.equipped_passives()])
        self.assertIn("unlocks", w.equip_passive("Warlord", 0))

    def test_hotbar_swap_moves_the_skill(self):
        w = self.w; self.at_shop(True)
        first, cap = w.ability_info()[0]["name"], w.ability_info()[10]["name"]
        self.assertIn("swapped", w.swap_slots("1", "!"))
        self.assertEqual((w.ability_info()[0]["name"], w.ability_info()[10]["name"]), (cap, first))
        w.swap_slots("1", "!")
        self.assertEqual(w.ability_info()[0]["name"], first)


# ========================================================================= 0.38 consent pvp and outlaws
class Outlaws(unittest.TestCase):
    """1.0.24: open PvP against the other faction; kills go on your record - 5 = red name, 5 in 10 minutes = black (every guard attacks)."""

    def setUp(self):
        self.w = new_world(level=40, faction="Alliance", cls="Warrior")
        self.foe = next(a for a in self.w.actors if a.kind == "adventurer" and a.faction == "Horde")
        p = self.w.player; self.foe.x, self.foe.y = p["x"] + 1.5, p["y"]; self.foe.party = 0; self.foe.state = "town"
        self.w._gtick = -1          # 1.0.27: the spatial grid's tick is _gtick (_grid_tick invalidated nothing)

    def tearDown(self):
        self.w.close()

    def test_open_pvp_against_the_other_side_only(self):
        w = self.w
        self.assertTrue(w._hostile_adv(self.foe))
        self.assertIn(self.foe, w._enemies())
        friend = next(a for a in w.actors if a.kind == "adventurer" and a.faction == "Alliance")
        self.assertFalse(w._hostile_adv(friend))

    def test_one_kill_never_flags_you(self):
        w = self.w; self.foe.hp = 1; w.player["level"] = 90
        w.attack_target(self.foe.id)
        self.assertEqual(w.outlaw_left(), 0); self.assertFalse(w.is_red()); self.assertAlmostEqual(w.infamy(), 1, delta=.01)

    def test_red_then_black(self):
        from liveworld_rpg import people as P
        w = self.w
        for _ in range(4): w._pk_record()
        self.assertFalse(w.is_red())
        w.tick += P.BLACK_WINDOW                           # the burst window passes; one kill is forgiven
        for _ in range(2): w._pk_record()
        self.assertTrue(w.is_red()); self.assertEqual(w.outlaw_left(), 0, "red, not black")
        enemy_guard = next(a for a in w.actors if a.kind == "npc" and a.role == "guard" and a.faction == "Horde")
        own_guard = next(a for a in w.actors if a.kind == "npc" and a.role == "guard" and a.faction == "Alliance")
        self.assertTrue(w._guard_hostile(enemy_guard)); self.assertFalse(w._guard_hostile(own_guard))
        self.assertTrue(w.snapshot()["player"]["red"])
        for _ in range(3): w._pk_record()                   # 5 inside 10 minutes
        self.assertAlmostEqual(w.outlaw_left(), P.OUTLAW_TICKS, delta=2)
        self.assertTrue(w._guard_hostile(own_guard), "black: every town's guards")
        w.tick += 6 * P.RED_FORGIVE + P.OUTLAW_TICKS
        self.assertFalse(w.is_red(), "red fades with time")

    def test_black_death_drops_only_to_heroes(self):
        w = self.w; w.player["level"] = 90
        w._grant_gear("Epic Runed Greatsword", "weapon", "Epic", 150, "test")
        gid = w.db.execute("SELECT id FROM player_gear WHERE item='Epic Runed Greatsword'").fetchone()["id"]; w.equip_gear(gid)
        monster = next(a for a in w.actors if a.kind == "monster")
        w._set_outlaw(True); w.player["gold"] = 1000; w._player_died(monster)
        self.assertEqual(w.player["gold"], 950, "a monster takes the usual 5%")
        self.assertEqual(w.db.execute("SELECT COUNT(*) AS n FROM player_gear").fetchone()["n"], 1, "monsters never make you drop gear")
        w._set_outlaw(True); w.player["gold"] = 1000; w.rng.seed(3)
        w._player_died(self.foe)
        self.assertEqual(w.player["gold"], 500, "a hero takes half")
        self.assertEqual(w.outlaw_left(), 0)

    def test_dropped_gear_comes_back_intact(self):
        w = self.w
        w._grant_gear("Heroic Ashen Crown", "helm", "Set", 160, "Raid", "", "Ashen Titan")
        gid = w.db.execute("SELECT id FROM player_gear WHERE item='Heroic Ashen Crown'").fetchone()["id"]
        w.db.execute("UPDATE player_gear SET sockets=2, gems='[\"Ruby\"]', equipped=1 WHERE id=?", (gid,)); w.db.commit()
        w.rng.seed(1)
        while not w._black_drop(w.player["x"], w.player["y"]): pass
        self.assertIsNone(w.db.execute("SELECT id FROM player_gear WHERE item='Heroic Ashen Crown'").fetchone())
        self.assertIn("Picked up", w.pickup_loot())
        g = w.db.execute("SELECT * FROM player_gear WHERE item='Heroic Ashen Crown'").fetchone()
        self.assertEqual((g["set_name"], g["sockets"], g["gems"], g["power"]), ("Ashen Titan", 2, '["Ruby"]', 160))

    def test_city_raid_kills_never_make_an_outlaw(self):
        w = self.w; w._start_death_fight(self.foe)
        w.city_raid = {"x": self.foe.x, "y": self.foe.y, "ids": [], "defs": [], "town": -1}
        self.foe.hp = 1; w.player["level"] = 90
        w.attack_target(self.foe.id)
        self.assertEqual(w.outlaw_left(), 0)
        w.city_raid = None

    def test_battleground_kills_never_make_an_outlaw(self):
        w = self.w
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                inst = enter(w, mode)
                foe = next(a for a in inst.actors.values() if getattr(a, "team", "") == "red")
                foe.hp = 1; w.player["level"] = 90; w.player["x"], w.player["y"] = foe.x + 1, foe.y
                w.attack_target(foe.id)
                self.assertEqual(w.outlaw_left(), 0)
                w.leave_instance(silent=True)

    def test_guards_attack_outlaws_and_death_clears_it(self):
        w = self.w; w._set_outlaw(True)
        guard = next(a for a in w.actors if a.kind == "npc" and a.role == "guard")
        self.assertTrue(w._guard_hostile(guard))
        w.player["x"], w.player["y"] = guard.x + 1, guard.y; w.player["hp"] = 10 ** 6
        hp0 = w.player["hp"]
        for _ in range(40): w._outlaw_tick(); w.tick += 1
        self.assertLess(w.player["hp"], hp0, "guards must hit an outlaw")
        self.assertNotEqual(w.attack_target(guard.id), "Invalid enemy target.")
        guard.hp = 1; w.player["level"] = 90; w.player["x"], w.player["y"] = guard.x + 1, guard.y
        self.assertIn("Defeated", w.attack_target(guard.id))          # 1.0.24: a beaten guard is slain - off the streets
        self.assertTrue(guard.slain); self.assertFalse(w._guard_hostile(guard))
        self.assertTrue(w.snapshot() is not None)
        w._player_died(guard)
        self.assertEqual(w.outlaw_left(), 0)

    def test_outlaw_flag_survives_a_reload(self):
        w = self.w; w._set_outlaw(True); left = w.outlaw_left(); db = E.DB
        w.close(); E.DB = db
        self.w = E.World()
        self.assertAlmostEqual(self.w.outlaw_left(), left, delta=4)


# ========================================================================= 0.39 town leaders
class TownLeaders(unittest.TestCase):
    """Quest givers and rulers of enemy towns can be slain (city raids, or a strong hero alone) and return in 30 minutes."""

    def setUp(self):
        self.w = new_world(level=90, faction="Alliance", cls="Warrior")
        self.w.player["level"] = 90
        self.enemy = next(t for t in self.w.towns if t.faction == "Horde")
        self.own = next(t for t in self.w.towns if t.faction == "Alliance")

    def tearDown(self):
        self.w.close()

    def leader(self, t, role):
        return next(a for a in self.w.actors if a.kind == "npc" and a.role == role and self.w._town_for_actor(a) is t)

    def test_own_town_leaders_are_safe(self):
        self.assertFalse(self.w.leader_attackable(self.leader(self.own, "king")))

    def test_slay_enemy_quest_giver_and_respawn(self):
        w = self.w; qg = self.leader(self.enemy, "questgiver")
        self.assertTrue(w.leader_attackable(qg))
        w.player["x"], w.player["y"] = qg.x + 1, qg.y
        for _ in range(400):
            if qg.hp <= 0: break
            w.attack_target(qg.id); w.tick += 1
        self.assertLessEqual(qg.hp, 0, "a level 90 hero must beat a low town's quest giver")
        self.assertGreater(w.infamy(), .9, "the kill goes on your record")
        self.assertTrue(any(w._guard_hostile(g) for g in w.actors if g.kind == "npc" and g.role == "guard" and w._town_for_actor(g) is self.enemy))
        w.tick = (qg.dead_until // 40 + 1) * 40; w._leader_tick()        # respawns are checked every 10 s
        self.assertEqual(qg.hp, qg.maxhp)

    def test_fallen_town_loses_its_leaders(self):
        w = self.w; w.town_falls(self.enemy)
        self.assertLessEqual(self.leader(self.enemy, "king").hp, 0)
        self.assertLessEqual(self.leader(self.enemy, "questgiver").hp, 0)

    def test_guards_are_posted(self):
        for t in self.w.towns[:5]:
            names = [a.name.split(" ")[0] + " " + a.name.split(" ")[1] for a in self.w.actors if a.kind == "npc" and a.role == "guard" and self.w._town_for_actor(a) is t]
            self.assertGreaterEqual(names.count("Gate Guard"), 4); self.assertGreaterEqual(names.count("City Patrol"), 3); self.assertGreaterEqual(names.count("Royal Guard"), 4)


# ========================================================================= 0.39 jewelcrafting
class Jewels(unittest.TestCase):
    """Jewels are cut at the Jeweler's Kiln, become rings and necklaces, and go into gear sockets."""

    def setUp(self):
        from liveworld_rpg import gfx
        self.w = new_world(level=55, cls="Warrior"); w = self.w
        w.station_posts = gfx.WorldLayout(w).stations
        w.player["gold"] = 10 ** 6; w._inv_add("Mat:Iron Ore", 300); w._inv_add("Mat:Arcane Dust", 100); w.db.commit()
        x, y = w.station_posts["kiln"][0]; w.player["x"], w.player["y"] = x + 2, y + 2

    def tearDown(self):
        self.w.close()

    def test_every_town_has_jeweler_and_kiln(self):
        for k in ("jeweler", "kiln", "apothecary", "inn", "smithy", "general", "stable", "market"):
            self.assertEqual(len(self.w.station_posts.get(k, [])), len(self.w.towns), k)

    def test_cut_craft_wear_and_socket(self):
        w = self.w
        self.assertIn("cut", w.cut_jewel("Clean Ruby")); self.assertIn("cut", w.cut_jewel("Clean Ruby")); self.assertIn("cut", w.cut_jewel("Flawless Diamond"))
        self.assertIn("unlocks", w.cut_jewel("Perfect Ruby").replace("need level", "unlocks"))
        self.assertIn("craft", w.craft_jewelry("ring|Clean Ruby"))
        w._grant_gear("Epic Runed Greatsword", "weapon", "Epic", 80, "test")
        ids = {r["item"]: r for r in w.inventory_rows()}
        gid = ids["Epic Runed Greatsword"]["id"]
        self.assertEqual(ids["Epic Runed Greatsword"]["sockets"], 0, "gear starts without sockets")
        w._inv_add("Mat:Spirit Essence", 10); w.db.commit()
        self.assertIn("opens socket 1", w.add_socket(gid))
        s0 = w.stats()["str"]
        w.equip_gear(ids["Clean Ruby Ring"]["id"]); w._gear_changed()
        self.assertEqual(w.stats()["str"], s0 + 10)
        w.equip_gear(ids["Epic Runed Greatsword"]["id"])
        c0 = w.crit_chance(); self.assertIn("set into", w.socket_jewel(ids["Epic Runed Greatsword"]["id"], "Flawless Diamond"))
        self.assertGreater(w.crit_chance(), c0)
        self.assertIn("no free socket", w.socket_jewel(ids["Epic Runed Greatsword"]["id"], "Clean Ruby"))
        self.assertIn("opens socket 2", w.add_socket(gid)); self.assertIn("opens socket 3", w.add_socket(gid))
        self.assertIn("already has 3", w.add_socket(gid))
        w.player["level"] = 5; self.assertIn("needs level", w.add_socket(ids["Clean Ruby Ring"]["id"])); w.player["level"] = 55
        self.assertIn("shatters", w.unsocket_jewel(ids["Epic Runed Greatsword"]["id"], 0))
        self.assertAlmostEqual(w.crit_chance(), c0)

    def test_two_rings(self):
        w = self.w
        for _ in range(3): w.cut_jewel("Clean Emerald"); w.craft_jewelry("ring|Clean Emerald")
        rings = [r for r in w.inventory_rows() if r["slot"] == "ring"]
        for r in rings: w.equip_gear(r["id"])
        self.assertEqual(sum(1 for r in w.inventory_rows() if r["slot"] == "ring" and r["equipped"]), 2)

    def test_kiln_needed(self):
        w = self.w; w.player["x"] += 60
        self.assertIn("Kiln", w.cut_jewel("Clean Ruby"))


# ========================================================================= 0.40 shops
class Shops(unittest.TestCase):
    """The Blacksmith sells weapons and armor, the General Store supplies, the Apothecary potions; the Forge only crafts."""

    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.w = new_world(level=30); cls.w.station_posts = gfx.WorldLayout(cls.w).stations; cls.w.place_town_npcs(); cls.w.player["gold"] = 10 ** 6

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def open(self, kind):
        w = self.w; t = w.towns[0]
        x, y = min(w.station_posts[kind], key=lambda q: (q[0] - t.x) ** 2 + (q[1] - t.y) ** 2)
        w.player["x"], w.player["y"] = x + 1.5, y + 1.5; w.talk_to = None; w.click_station = kind
        w.interact_nearby(); return w.open_ui, getattr(w, "shop_npc", None)

    def test_no_caravan_merchants(self):
        """0.40.1: the wandering Caravan Merchants are gone, and the Stable Master and Market Warden work inside their buildings."""
        self.assertFalse([a for a in self.w.actors if a.kind == "npc" and a.role == "merchant"])
        ui, _ = self.open("stable"); self.assertEqual(ui, "stable")
        ui, _ = self.open("market"); self.assertEqual(ui, "market")

    def test_blacksmith_sells_gear(self):
        ui, npc = self.open("smithy"); self.assertEqual(ui, "shop")
        tabs = {t["name"]: t["items"] for t in self.w.shop_view(npc)["tabs"]}
        self.assertTrue(tabs.get("Weapons")) ; self.assertTrue(tabs.get("Armor"))
        key = tabs["Weapons"][0]["key"]; self.assertIn("Bought", self.w.shop_buy(npc, key))

    def test_general_store_sells_supplies(self):
        ui, npc = self.open("general"); self.assertEqual(ui, "shop")
        names = [i["label"] for t in self.w.shop_view(npc)["tabs"] for i in t["items"]]
        for want in ("Scroll of Teleportation", "Fishing Bait", "Iron Ore"): self.assertIn(want, names)
        self.assertIn("Bought", self.w.shop_buy(npc, "g:Fishing Bait"))

    def test_apothecary_sells_potions(self):
        ui, npc = self.open("apothecary")
        names = [i["label"] for t in self.w.shop_view(npc)["tabs"] for i in t["items"]]
        self.assertIn("Health Potion", names); self.assertIn("Scroll of Might", names)

    def test_magic_shop_sells_zone_level_magic_items(self):
        ui, npc = self.open("enchanter"); self.assertEqual(ui, "shop")
        t = self.w.towns[0]; lo, hi = self.w._zone_band(t)
        items = [i for tab in self.w.shop_view(npc)["tabs"] if not tab.get("name", tab.get("label", "")).startswith("Zone Set") for i in tab["items"]]      # the Zone Set tab has its own "Set" rarity
        self.assertTrue(items and all(i["rarity"] in ("Rare", "Epic", "Elite") for i in items))
        lv = [int(i["sub"].split()[1]) for i in items]
        self.assertTrue(all(lo <= x <= hi for x in lv), (lo, hi, lv))
        epic = next(i for i in items if i["rarity"] == "Epic")
        self.w.shop_buy(npc, epic["key"])
        self.assertEqual(self.w.inventory_rows()[0]["sockets"] if self.w.inventory_rows()[0]["item"] == epic["item"] else max(r["sockets"] for r in self.w.inventory_rows() if r["item"] == epic["item"]), 1)

    def test_bank_opens_vault(self):
        ui, _ = self.open("bank"); self.assertEqual(ui, "vault")
        self.assertIsNotNone(self.w.vault_view())

    def test_sets_only_from_raids(self):
        rows = [r for tab in self.w._smith_recipes() for r in tab["rows"]]
        self.assertTrue(rows)
        self.assertFalse([r for r in rows if r.get("rarity") == "Set" or r.get("set_name")], "the Forge must not make set pieces")

    def test_forge_only_crafts(self):
        ui, npc = self.open("forge")
        self.assertEqual(ui, "craft"); self.assertIsNone(npc)


# ========================================================================= world
class WorldBoot(unittest.TestCase):
    def test_every_class_and_faction(self):
        for faction in ("Alliance", "Horde"):
            for cls in CLASSES:
                with self.subTest(faction=faction, cls=cls):
                    w = new_world(level=1, faction=faction, cls=cls)
                    self.assertEqual((w.player["class"], w.player["faction"]), (cls, faction))
                    self.assertTrue(w.character_created())
                    w.update(8)
                    self.assertIsNone(w.inst)
                    w.close()

    def test_world_survives_a_reload(self):
        w = new_world(level=7)
        w.player["gold"] = 1234; w._save_player_fast(); w._save_all(force=True); w.close()
        w2 = E.World()
        self.assertEqual((w2.player["name"], w2.player["level"], w2.player["gold"]), ("Smoke", 7, 1234))
        w2.close()


# ===================================================================== arena maps
class ArenaMaps(unittest.TestCase):
    """Layout checks for every battleground map - no simulation."""

    @classmethod
    def setUpClass(cls):
        cls.w = new_world(level=30)

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def build(self, mode):
        return enter(self.w, mode)

    def tearDown(self):
        if self.w.inst: self.w.leave_instance(silent=True)

    def test_mode_table(self):
        names = set()
        for mode, cfg in A.MODES.items():
            with self.subTest(mode=mode):
                self.assertIn(cfg["n"], (12, 24))
                self.assertIn(cfg.get("rules", mode), ("tdm", "ctf", "dom"))
                self.assertGreater(cfg["target"], 0); self.assertGreater(cfg["time"], 0)
                self.assertEqual(cfg["time"], 240, "every battleground (12v12 and 24v24) lasts 4 minutes")
                self.assertTrue(cfg["map"] and cfg["map"] in cfg["desc"])
                names.add(cfg["map"])
        self.assertEqual(len(names), len(A.MODES), "every mode needs its own map")

    def test_objectives_on_floor_and_reachable(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                a = self.build(mode)
                reach = flood(a.floor, a.spawn)
                self.assertEqual(len(reach), len(a.floor), f"{len(a.floor) - len(reach)} floor tiles cut off")
                spots = {"blue base": a.blue_base, "red base": a.red_base, "spawn": a.spawn}
                spots.update({f"portal{i}": p for i, p in enumerate(a.portals)})
                spots.update({f"shrine{i}": s for i, s in enumerate(a.shrines)})
                spots.update({f"{t} flag": f["home"] for t, f in a.flags.items()})
                spots.update({f"point {p['n']}": (p["x"], p["y"]) for p in a.points})
                for name, (x, y) in spots.items():
                    self.assertTrue((int(x), int(y)) in reach, f"{name} at ({x:.1f},{y:.1f}) is not walkable")
                self.assertEqual(len(a.shrines), a.cfg["shrines"])
                if a.mode == "ctf": self.assertEqual(set(a.flags), {"blue", "red"})
                if a.mode == "dom": self.assertEqual(len(a.points), 7 if a.cfg["n"] >= 24 else 5)
                self.w.leave_instance(silent=True)

    def test_layout_is_mirrored_and_fixed(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                a = self.build(mode); pillars = set(a.pillars); floor = set(a.floor)
                X0, Wd = a.X0, a.Wd
                for (x, y) in floor:
                    self.assertTrue((X0 + Wd - 1 - (x - X0), y) in floor, f"map is not left/right symmetric at {(x, y)}")
                self.w.leave_instance(silent=True)
                b = self.build(mode)
                self.assertTrue(set(b.pillars) == pillars, "the same map must build the same way every time")
                self.assertGreater(len(pillars), 0, "no cover at all")
                self.w.leave_instance(silent=True)

    def test_teams_spawn_on_floor(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                a = self.build(mode); n = a.cfg["n"]
                self.assertEqual(len(a.allies), n - 1, "you fill one of your team's slots")
                self.assertEqual(len(a.reds), n)
                self.assertEqual(len({c.id for c in a.allies + a.reds}), 2 * n - 1, "duplicate actor ids")
                for c in a.allies + a.reds:
                    self.assertTrue((int(c.x), int(c.y)) in a.floor, f"{c.name} ({c.team}) spawned in a wall")
                self.assertEqual((self.w.player["x"], self.w.player["y"]), a.spawn)
                json.dumps(a.snapshot())
                self.w.leave_instance(silent=True)

    def test_twelve_a_side_roles(self):
        a = self.build("tdm12")
        roles = collections.Counter(c.rrole for c in a.reds)
        self.assertEqual(roles, {"Tank": 2, "Healer": 3, "DPS": 7})


# ================================================================= arena matches
class ArenaMatches(unittest.TestCase):
    """Plays each map to the end and checks the scoring rules."""

    def setUp(self):
        self.w = new_world(level=30)

    def tearDown(self):
        if self.w.inst: self.w.leave_instance(silent=True)
        self.w.close()

    def test_every_map_plays_to_a_result(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                w = self.w; before = {a.id for a in w.actors}; home = (w.player["x"], w.player["y"])
                a = enter(w, mode)
                ticks = run_until_out(w, int(a.cfg["time"] * I.TPS) + 200)
                self.assertIsNone(w.inst, f"{mode} still running after {ticks} ticks")
                self.assertIn(a.result, ("blue", "red", "draw"))
                self.assertTrue(w.city_result)
                self.assertEqual({x.id for x in w.actors}, before, "arena actors leaked into the world")
                self.assertEqual((w.player["x"], w.player["y"]), home, "not sent back to where you entered")
                self.assertGreater(w.player["hp"], 0)

    def test_tdm_kills_score(self):
        w = self.w; a = enter(w, "tdm12")
        a.player_killed(a.reds[0])
        self.assertEqual((a.score["blue"], a.pk), (1, 1))
        self.assertTrue(a.reds[0].dead)
        w.player["hp"] = 1; a.on_player_death()
        self.assertEqual((a.score["red"], a.pd), (1, 1))
        self.assertEqual((w.player["x"], w.player["y"]), a.spawn)
        self.assertEqual(w.player["hp"], w._effective_maxhp())

    def test_ctf_player_capture_and_drop(self):
        w = self.w; a = enter(w, "ctf12")
        for c in a.allies + a.reds: c.dead = True; c.respawn = 10 ** 9      # an empty map: only you
        w.player["x"], w.player["y"] = a.flags["red"]["home"]; a._ctf_tick()
        self.assertEqual(a.carry_player, "red")
        w.player["x"], w.player["y"] = a.flags["blue"]["home"]; a._ctf_tick()
        self.assertEqual(a.score["blue"], 1); self.assertIsNone(a.carry_player)
        self.assertEqual(a.flags["red"]["pos"], a.flags["red"]["home"])
        # dying while carrying drops the flag, and a dropped flag goes straight home (0.46.31)
        w.player["x"], w.player["y"] = a.flags["red"]["home"]; a._ctf_tick()
        a.on_player_death()
        self.assertIsNone(a.carry_player)
        self.assertIsNone(a.flags["red"]["carrier"]); self.assertEqual(a.flags["red"]["pos"], a.flags["red"]["home"])

    def test_ctf_dropped_flag_returns(self):
        w = self.w; a = enter(w, "ctf12")
        f = a.flags["blue"]; f["pos"] = (f["home"][0] + 10, f["home"][1]); f["t"] = w.tick
        for c in a.allies + a.reds: c.dead = True; c.respawn = 10 ** 9
        w.player["x"], w.player["y"] = a.red_base
        for _ in range(85): w.tick += 1; a._ctf_tick()
        self.assertEqual(f["pos"], f["home"], "a flag left on the ground must go home by itself")

    def test_ctf_carrier_drop_returns_at_once_and_target_is_three(self):
        w = self.w; a = enter(w, "ctf12")
        for c in a.allies + a.reds: c.dead = True; c.respawn = 10 ** 9
        r = a.reds[0]; r.dead = False; r.x, r.y = a.flags["blue"]["home"]
        a._ctf_tick(); self.assertIs(a.flags["blue"]["carrier"], r)
        r.x += 20; a._drop_flag(r)
        self.assertIsNone(a.flags["blue"]["carrier"]); self.assertEqual(a.flags["blue"]["pos"], a.flags["blue"]["home"])
        for m in ("ctf12", "ctf24"): self.assertEqual(A.MODES[m]["target"], 3)
        a.score["blue"] = 3; a._check_end(w.tick); self.assertTrue(a.done)

    def test_ctf_everyone_hunts_the_carrier_and_teams_are_even(self):
        w = self.w; a = enter(w, "ctf12")
        self.assertEqual(len(a.allies) + 1, len(a.reds))
        r = a.reds[0]; r.dead = False; a.flags["blue"]["carrier"] = r; r.has_flag = True      # the enemy holds our flag...
        a.allies[0].has_flag = True; a.flags["red"]["carrier"] = a.allies[0]                    # ...while we hold theirs
        for m in a.allies[1:]:
            m.hp = m.maxhp; a._decide_core(m, w.tick)
            self.assertEqual(m.plan[0], "chase", m.rrole)

    def test_hurt_bots_go_to_a_shrine_heal_and_come_back(self):
        """1.0.19: allies and enemies alike break off for a shrine when low, stay until healed, then rejoin."""
        for mode in ("ctf12", "tdm24", "dom12"):
            with self.subTest(mode=mode):
                w = self.w; a = enter(w, mode)
                for team in (a.allies, a.reds):
                    b = team[1]; b.hp = b.maxhp * .2
                    a._ai(b, w.tick)
                    self.assertEqual(b.plan[0], "heal", f"{b.team} bot at 20% health did not go for a shrine")
                    self.assertIn((b.plan[3], b.plan[4]), a.shrines)
                    self.assertLess(math.hypot(b.plan[1] - b.plan[3], b.plan[2] - b.plan[4]), 2.3, "heal spot outside the shrine circle")
                # walk it there and let the shrine work, with no one else around
                for c in a.allies + a.reds:
                    if c is not a.allies[1]: c.dead = True; c.respawn = 10 ** 9
                b = a.allies[1]; healed = False
                for _ in range(400):
                    w.tick += 1; a._ai(b, w.tick)
                    if w.tick % 4 == 0: a._shrine_tick()
                    if not (b.plan and b.plan[0] == "heal"): healed = True; break
                self.assertTrue(healed, "never left the shrine")
                self.assertGreaterEqual(b.hp / b.maxhp, .9, "left the shrine before it was healed")
                w.leave_instance(silent=True)

    def test_flag_carrier_heals_only_on_the_way_home(self):
        w = self.w; a = enter(w, "ctf24")
        c = a.allies[0]; c.has_flag = True; a.flags["red"]["carrier"] = c
        c.x, c.y = a.X0 + a.Wd / 2, a.Y0 + a.Hd / 2          # mid-field on the way home: shrines are close to the route
        c.hp = c.maxhp * .5; a._decide_core(c, w.tick); self.assertEqual(c.plan[0], "carry", "a healthy carrier runs home")
        c.hp = c.maxhp * .2; a._ai(c, w.tick); self.assertEqual(c.plan[0], "heal", "a badly hurt carrier stops at a shrine on the way")
        near_home = (a.flags["blue"]["home"][0] + 4, a.Y0 + a.Hd / 2)
        c.plan = None; c.next_decide = 0; c.x, c.y = near_home; c.hp = c.maxhp * .2; a._ai(c, w.tick + 1)
        self.assertNotEqual(c.plan[0], "heal", "beside its own flag a carrier just runs in - no detour back to mid-field")
        c.x, c.y = a.X0 + a.Wd / 2, a.Y0 + a.Hd / 2; c.plan = None; a._ai(c, w.tick + 2)
        c.hp = c.maxhp * .7; a._ai(c, w.tick + 3); self.assertNotEqual(getattr(c, "plan", None) and c.plan[0], "heal", "carrier healed enough - back to the run")

    def test_bots_are_independent_and_follow_the_live_carrier(self):
        w = self.w; a = enter(w, "ctf12")
        self.assertEqual(a.squads, {}, "no squads - every bot decides for itself")
        for m in a.allies:
            a._decide_core(m, w.tick); self.assertNotIn(m.plan[0], ("support",), "nobody trails a leader")
        r = a.reds[0]; a.flags["blue"]["carrier"] = r; r.has_flag = True
        m = a.allies[2]; a._decide_core(m, w.tick); self.assertEqual(m.plan[0], "chase")
        r.x += 9; r.y += 3
        self.assertEqual(a._objective(m), (r.x, r.y), "the hunters head for where the carrier is now")
        # a capture or a taken flag makes everyone rethink within a couple of seconds
        for x in a.allies + a.reds: x.next_decide = w.tick + 999
        a._react()
        self.assertTrue(all(x.next_decide <= w.tick + 6 for x in a.allies + a.reds if not x.dead))

    def test_dom_points_capture_and_score(self):
        for mode in ("dom12", "dom24"):
            with self.subTest(mode=mode):
                w = self.w; a = enter(w, mode)
                for c in a.allies + a.reds: c.dead = True; c.respawn = 10 ** 9
                pt = a.points[0]; w.player["x"], w.player["y"] = pt["x"], pt["y"]
                for _ in range(10): a._dom_tick()
                self.assertEqual(pt["owner"], "blue")
                s0 = a.score["blue"]
                for _ in range(4 * I.TPS): a._dom_tick()
                self.assertAlmostEqual(a.score["blue"] - s0, 4.0, msg="one owned point scores 1 per second")
                w.leave_instance(silent=True)

    def test_rewards_match_the_guide(self):
        # guide: PvP Points 120 per 12v12 win, 24 for a loss
        for mode, win_pts, loss_pts in (("tdm12", 120, 24), ("ctf12", 120, 24)):
            with self.subTest(mode=mode):
                w = self.w
                cur = lambda: w.db.execute("SELECT pvp_points FROM player_currency WHERE name=?", (w.player["name"],)).fetchone()[0]
                enter(w, mode); p0, g0 = cur(), w.player["gold"]
                w.inst._finish("blue")
                self.assertEqual(cur() - p0, win_pts); self.assertGreater(w.player["gold"], g0)
                run_until_out(w, 40); self.assertIsNone(w.inst)
                enter(w, mode); p0 = cur()
                w.inst._finish("red")
                self.assertEqual(cur() - p0, loss_pts)
                run_until_out(w, 40)

    def test_leaving_early_is_no_win_no_loss(self):
        w = self.w; r0 = w.pvp_status()["rating"]
        enter(w, "dom12"); w.update(4); w.leave_instance()
        self.assertIn("no win, no loss", w.city_result)
        self.assertEqual(w.pvp_status()["rating"], r0)

    def test_entry_rules(self):
        w = self.w
        self.assertIn("Unknown", w.enter_arena("nope"))
        w.player["level"] = 4; self.assertIn("level 5", w.enter_arena("tdm12")); self.assertIsNone(w.inst)
        w.player["level"] = 30; w.enter_arena("tdm12")
        self.assertIn("Leave your current instance", w.enter_arena("ctf12"))

    def test_mounted_player_is_dismounted(self):
        w = self.w; w.mounted = "anything"
        w.enter_arena("tdm12"); self.assertFalse(getattr(w, "mounted", None))


# ======================================================================= person window gear (1.0.19)
class PersonGear(unittest.TestCase):
    def setUp(self): self.w = new_world(level=30)
    def tearDown(self): self.w.close()

    def test_gear_tab_matches_overview_and_set(self):
        w = self.w
        people = [x for x in w.actors if x.kind == "adventurer" and hasattr(x, "gear")]
        self.assertTrue(people)
        for g in ("Poor", "Common", "Rare", "Elite", "Set", "Legendary", "Mythic"):
            x = people[0]; x.gear = g
            x.setl, x.setp = ("Frostwyrm", ("armor", "helm", "weapon", "trinket")) if g in ("Set", "Legendary", "Mythic") else ("", ())
            info = w.person_info(x.id); rows = info["gear_rows"]
            self.assertEqual(info["gear"], g)
            with self.subTest(gear=g):
                for row in rows:
                    if row["slot"] in x.setp:
                        self.assertIn("Frostwyrm", row["item"]); self.assertEqual(row["rarity"], g)
                    else:
                        self.assertEqual(row["rarity"], "Elite" if g == "Set" else g, row)
        # an Elite outfit with one set piece shows that piece as a Set item
        x.gear = "Elite"; x.setl, x.setp = "Ashen Titan", ("armor",)
        rows = {r["slot"]: r for r in w.person_info(x.id)["gear_rows"]}
        self.assertEqual(rows["armor"]["rarity"], "Set"); self.assertIn("Ashen Titan", rows["armor"]["item"])
        self.assertEqual(rows["ring"]["rarity"], "Elite")
        # a better grade means more power
        x.setl, x.setp = "", ()
        pw = {}
        for g in ("Common", "Rare", "Mythic"):
            x.gear = g; pw[g] = sum(r["power"] for r in w.person_info(x.id)["gear_rows"])
        self.assertLess(pw["Common"], pw["Rare"]); self.assertLess(pw["Rare"], pw["Mythic"])


# ======================================================================= prices (1.0.19)
class Prices(unittest.TestCase):
    """Buying gear, potions, jewelry, mounts and crafting costs twice what 1.0.18 charged; selling pays the same."""
    def setUp(self): self.w = new_world(level=30)
    def tearDown(self): self.w.close()

    def test_buy_doubled_sell_unchanged(self):
        w = self.w; t = w.towns[0]
        self.assertEqual(E.World.BUY_MULT, 2)
        for g in ("Health Potion", "Mana Potion"):
            self.assertEqual(w._buy_price(t, g), 2 * w._buy_price(t, g, raw=True))
            m, sat = w._mkt_mult(t, g)
            self.assertEqual(w._sell_price(t, g), max(1, int(w._good_base(g) * m * .8 * max(.4, 1 - sat * .04))), "selling pays the same")
        self.assertEqual(w._buy_price(t, "Fishing Bait"), w._buy_price(t, "Fishing Bait", raw=True), "only the doubled kinds change")
        for row in w._smith_stock(t):
            self.assertEqual(row["price"], max(5, int(w._gear_value(row["rarity"], row["power"]) * 1.5)) * 2)
        for row in w._jewel_stock(t):
            self.assertEqual(row["price"], max(5, int(w._gear_value(row["rarity"], row["power"]) * 1.6)) * 2)

    def test_mounts_riding_jewels_and_crafting(self):
        from liveworld_rpg import mounts as Mo, jewels as J, rpg as R
        self.assertEqual(Mo.MOUNTS["chestnut"]["price"], 1000); self.assertEqual(Mo.MOUNTS["drake"]["price"], 130000)
        self.assertEqual([Mo.RIDING[i][2] for i in (1, 2, 3, 4)], [600, 4000, 16000, 50000])
        self.assertEqual(J.jewelry_cost(0)[1], 100); self.assertEqual(J.cut_cost(0)[2], 40)
        self.assertEqual([c[4] for c in J.SOCKET_COSTS], [500, 3000, 12000])
        w = self.w
        rods = {r["key"]: r["gold"] for r in w._hut_recipes()}
        self.assertEqual(rods["hut:rod1"], 300); self.assertEqual(rods["hut:rod3"], 8000)
        inn = {r["key"]: r["gold"] for r in w._alchemy_recipes()}
        self.assertEqual(inn["scroll"], 50)
        forge = [r for tab in w._smith_recipes() if tab["name"] == "Weapons" for r in tab["rows"]]
        self.assertEqual(forge[0]["gold"], R.FORGE_TIERS[0][7] * 2)

    def test_upgrade_shows_what_it_charges(self):
        w = self.w
        w._grant_gear("Epic Test Blade", "weapon", "Epic", 80, "Test", "", "")
        r = w.db.execute("SELECT * FROM player_gear WHERE item='Epic Test Blade'").fetchone()
        row = next(x for x in w._upgrade_rows() if x["key"] == f"up:{r['id']}")
        self.assertEqual(row["gold"], w._upgrade_cost(r, 0)[1])
        self.assertEqual(row["gold"], max(80, 80 * 10) * 2)
        for it, q in w._upgrade_cost(r, 0)[0]: w._inv_add(it, q + 50)
        w.player["gold"] = 10 ** 6; g0 = w.player["gold"]
        w._invc = None; msg = w.forge_upgrade(r["id"])
        self.assertEqual(g0 - w.player["gold"], row["gold"], msg)


# ======================================================================= preset bots, class drops, raid lineups (1.0.19)
class PresetsAndDrops(unittest.TestCase):
    def setUp(self): self.w = new_world(level=30, cls="Mage")
    def tearDown(self): self.w.close()

    def test_bots_keep_level_and_gear(self):
        w = self.w
        a = next(x for x in w.actors if x.kind == "adventurer" and hasattr(x, "gear"))
        lv, gear = a.level, a.gear
        for _ in range(50): w._person_gain(a, 100); w._person_upgrade(a)
        self.assertEqual((a.level, a.gear), (lv, gear))

    def test_dead_bots_respawn_with_the_same_gear(self):
        w = self.w
        for a in [x for x in w.actors if x.kind == "adventurer" and hasattr(x, "gear")][:30]:
            before = (a.level, a.gear, a.setl, tuple(a.setp), a.maxhp, w.npc_gear(a))
            a.hp = 0; w._person_respawn(a)
            self.assertEqual((a.level, a.gear, a.setl, tuple(a.setp), a.maxhp, w.npc_gear(a)), before, a.name)
            self.assertEqual(a.hp, a.maxhp)
        # and through a save and reload
        w._save_all(force=True)
        snap = {a.id: (a.level, a.gear, a.setl, tuple(a.setp)) for a in w.actors if a.kind == "adventurer"}
        w.close(); w2 = E.World(); self.w = w2
        for a in w2.actors:
            if a.id in snap: self.assertEqual((a.level, a.gear, a.setl, tuple(a.setp)), snap[a.id], a.name)

    def test_two_hundred_roamers_some_maxed(self):
        w = self.w
        ro = [a for a in w.actors if w._is_roamer(a)]
        self.assertEqual(len(ro), 200)
        self.assertEqual(sum(1 for a in ro if a.faction == "Alliance"), 100)
        maxed = [a for a in ro if a.level == 100 and a.gear == "Mythic" and len(a.setp) == 4]
        self.assertGreater(len(maxed), 8); self.assertLess(len(maxed), 70)
        self.assertGreater(len({a.level for a in ro}), 40, "all different levels")

    def test_instance_drops_are_for_your_class(self):
        w = self.w
        for _ in range(60):
            for rar in ("Rare", "Epic", "Elite", "Legendary", "Mythic"):
                w._drop_inst_rarity(w.player["x"], w.player["y"], 30, rar, "Test", power=90)
        rows = w.db.execute("SELECT item, slot, class FROM ground_loot").fetchall()
        self.assertTrue(rows)
        for r in rows:
            self.assertEqual(r["class"], "Mage", r["item"])
            self.assertEqual(w.item_usable(r["item"], r["slot"], r["class"]), "", r["item"])
            self.assertNotIn("Titanplate", r["item"])

    def test_raids_bring_more_tanks_and_healers(self):
        # 1.0.24: 12-player raids 3 tanks / 3 healers / 6 DPS, 24-player raids 6 / 6 / 12
        self.assertEqual(I.PARTY["raid"], {"Tank": 3, "Healer": 3, "DPS": 6})
        for t in ("raid_h", "heroic"): self.assertEqual(I.PARTY[t], {"Tank": 6, "Healer": 6, "DPS": 12})
        self.assertEqual(sum(I.PARTY["raid"].values()), 12); self.assertEqual(sum(I.PARTY["raid_h"].values()), 24)


# ======================================================================= mana (0.46.31)
class Mana(unittest.TestCase):
    def setUp(self): self.w = new_world(level=1, cls="Mage")
    def tearDown(self): self.w.close()

    def test_max_mana_grows_with_level(self):
        w = self.w
        vals = []
        for lvl in (1, 10, 50, 90):
            w.player["level"] = lvl; vals.append(w.max_mana())
        self.assertEqual(vals[0], 100); self.assertEqual(vals, sorted(vals)); self.assertEqual(vals[1], 154)
        self.assertEqual(w.snapshot()["player"]["maxmana"], w.max_mana())

    def test_level_up_refills_mana(self):
        w = self.w; w.player["mana"] = 5; w.player["xp"] = 10 ** 9; w._level_check()
        self.assertEqual(w.player["mana"], w.max_mana()); self.assertGreater(w.max_mana(), 100)

    def test_regen_only_out_of_combat_unless_meditation(self):
        w = self.w; w.player["level"] = 30
        def regen(combat):
            w.player["mana"] = 10; w.last_combat_tick = w.tick if combat else -999
            w.update(8); return w.player["mana"]
        self.assertGreater(regen(False), 10)
        self.assertEqual(regen(True), 10)

    def test_mana_potion_scales(self):
        w = self.w; w.player["level"] = 90; w._inv_add("Mana Potion", 1); w.player["mana"] = 0
        w.use_mana_potion(); self.assertEqual(w.player["mana"], w.max_mana() // 4)


# ======================================================================= battle mounts (0.46.33)
class BattleMounts(unittest.TestCase):
    def test_battle_mount_is_battleground_only(self):
        w = new_world(level=40)
        try:
            st = w._mst(); st["riding"] = 2; st["owned"] = ["bg_wolf"]; st["active"] = "bg_wolf"; st["bg_active"] = None
            st = w._mst_save() or w._mst()
            w._mount_cache = None; st = w._mst()                      # reload: a battle mount can never be the open-world mount
            self.assertNotEqual(st["active"], "bg_wolf")
            ok, why = w.can_mount(); self.assertFalse(ok, "no open-world mount owned")
            w.mounted = "bg_wolf"; w._mount_tick(); self.assertIsNone(w.mounted, "battle mount vanishes outside battlegrounds")
            enter(w, "ctf12"); w.mounted = None
            self.assertEqual(w.mount(), "You mount your Recruit's Battle Wolf.")
            w.leave_instance(silent=True); w._mount_tick(); self.assertIsNone(w.mounted)
        finally: w.close()


# ======================================================================= town guards vs enemy bots (0.46.34)
class TownDefense(unittest.TestCase):
    def test_guards_attack_enemy_faction_adventurers_in_town(self):
        w = new_world(level=40, faction="Alliance")
        try:
            t = next(x for x in w.towns if x.faction == "Horde")
            bot = next(a for a in w.actors if a.kind == "adventurer" and a.faction == "Alliance" and not a.party)
            bot.x, bot.y = t.x + 2, t.y + 2; bot.hp = bot.maxhp = 2000; bot.state = "town"
            g = next(a for a in w.actors if a.kind == "npc" and a.role == "guard" and w._town_for_actor(a) is t)
            g.x, g.y = bot.x + 1, bot.y; g.hp = g.maxhp
            w.player["x"], w.player["y"] = t.x - 400, t.y; hp0 = bot.hp
            for _ in range(24): w.tick += 1; w._gtick = -1; w._town_defense_tick()
            self.assertLess(bot.hp, hp0, "a Horde guard must hit an Alliance bot inside its walls")
            # a bot of the town's own faction is left alone
            ally = next(a for a in w.actors if a.kind == "adventurer" and a.faction == "Horde" and not a.party)
            ally.x, ally.y = t.x + 2, t.y + 2; ally.hp = ally.maxhp; w.tick += 4; w._gtick = -1; w._town_defense_tick()
            self.assertEqual(ally.hp, ally.maxhp)
        finally: w.close()


# ======================================================================= wide bridges (1.0.24)
class Bridges(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.gfx = gfx
        cls.w = new_world(level=20)
        cls.layout = gfx.WorldLayout(cls.w)

    @classmethod
    def tearDownClass(cls): cls.w.close()

    def test_decks_are_wider(self):
        g = self.gfx
        for _run, hw in g._bridges(self.layout)[0]:
            self.assertGreaterEqual(g._bridge_half(hw), (hw * 1.1 + .6) * 1.4)

    def test_whole_deck_is_walkable(self):
        g = self.gfx; lay = self.layout
        for run, hw in g._bridges(lay)[0]:
            e = g._bridge_half(hw) - .9
            for off in (-e, -e / 2, 0, e / 2, e):
                for i in range(len(run)):
                    (x0, y0), (x1, y1) = run[max(0, i - 1)], run[min(len(run) - 1, i + 1)]
                    dx, dy = x1 - x0, y1 - y0; L = math.hypot(dx, dy) or 1; nx, ny = -dy / L, dx / L
                    k = (int(math.floor(run[i][0] + nx * off)), int(math.floor(run[i][1] + ny * off)))
                    with self.subTest(bridge=run[0], offset=round(off, 2)):
                        self.assertTrue(g.tile_info(lay, *k)[0] not in ("water", "lava", "void") or k in lay.deck)
                        self.assertIsNone(lay.pond_push(k[0] + .5, k[1] + .5))


# ======================================================================= waygates and raids (0.46.36)
class Waygates(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.w = new_world(level=40, faction="Alliance"); cls.w.player["gold"] = 500
        cls.layout = gfx.WorldLayout(cls.w); cls.w.station_posts = cls.layout.stations

    @classmethod
    def tearDownClass(cls): cls.w.close()

    def test_every_town_city_and_capital_has_a_waygate(self):
        w = self.w; ids = w.teleport_town_ids()
        self.assertEqual(ids, {t.id for t in w.towns})
        self.assertEqual({w.town_tier(t) for t in w.towns}, {"capital", "city", "town"})
        tp = [b for b in self.layout.buildings if b[2] == "teleport"]
        self.assertEqual(len(tp), len(w.towns), "every settlement has exactly one Waygate building")
        posts = w.station_posts["teleport"]
        for t in w.towns:
            with self.subTest(town=t.name, tier=w.town_tier(t)):
                self.assertEqual(sum((x - t.x) ** 2 + (y - t.y) ** 2 < E.TOWN_WALL_R ** 2 for x, y in posts), 1)

    def test_waygate_lists_every_settlement_of_your_side(self):
        w = self.w; w.inst = None
        for t in w.towns:
            post = min(w.station_posts["teleport"], key=lambda q: (q[0] - t.x) ** 2 + (q[1] - t.y) ** 2)
            w.player["x"], w.player["y"] = post[0] + 1, post[1] + 1
            v = w.teleport_view()
            with self.subTest(town=t.name):
                self.assertIsNotNone(v)
                self.assertEqual({d["id"] for d in v["dests"]}, {x.id for x in w.towns if x.faction == "Alliance"})
                self.assertEqual([d["id"] for d in v["dests"] if d["here"]], [t.id] if t.faction == "Alliance" else [])
                self.assertEqual([d["name"] for d in v["dests"]], sorted((d["name"] for d in v["dests"]), key=str.casefold), "A to Z")

    def test_teleport_costs_gold_and_a_scroll(self):
        w = self.w; w.inst = None
        mine = [t for t in w.towns if t.id in w.teleport_town_ids() and t.faction == "Alliance"]
        a, b = mine[0], mine[1]
        post = min(w.station_posts["teleport"], key=lambda q: (q[0] - a.x) ** 2 + (q[1] - a.y) ** 2)
        w.player["x"], w.player["y"] = post[0] + 1, post[1] + 1
        w._inv_add("Scroll of Teleportation", -w._inv_qty("Scroll of Teleportation"))
        self.assertIn("Scroll", w.teleport_to(b.id)); self.assertEqual(w.player["gold"], 500)
        w._inv_add("Scroll of Teleportation", 1)
        self.assertIn("carries you", w.teleport_to(b.id))
        self.assertEqual((w.player["gold"], w._inv_qty("Scroll of Teleportation")), (450, 0))
        self.assertLess(math.hypot(w.player["x"] - b.x, w.player["y"] - b.y), 40)
        self.assertEqual(w.teleport_view(), None if not w._near_station("teleport", 8) else w.teleport_view())
        enemy = next(t for t in w.towns if t.faction == "Horde" and t.id in w.teleport_town_ids())
        w.player["x"], w.player["y"] = post[0] + 1, post[1] + 1; w._inv_add("Scroll of Teleportation", 1)
        self.assertIn("cannot", w.teleport_to(enemy.id))

    def test_city_raids_are_24_a_side_and_always_full(self):
        w = self.w
        self.assertEqual(w.RAID_CAP, 24)
        t = w.towns[0]; w.city_raid = None; w.raid_call = None; w.inst = None
        w._raid_announce(t); rc = w.raid_call
        self.assertEqual(rc["cap"], 24); self.assertGreaterEqual(rc["target"], 23)
        w._raid_launch(); self.assertIsNotNone(w.city_raid)
        w._raid_spawn_wave(); self.assertGreaterEqual(len(w.city_raid["ids"]), 24)
        w._raid_end(True); w.city_raid = None


    def test_two_minute_muster_fills_and_everyone_defends(self):
        w = self.w; w.city_raid = None; w.raid_call = None; w.inst = None
        self.assertEqual(w.RAID_MUSTER, 2 * 60 * 4, "a city raid musters for 2 minutes")
        fac = w.player["faction"]
        t = next(x for x in w.towns if x.faction == fac)
        w._raid_announce(t); rc = w.raid_call
        self.assertFalse(rc["tight"], "the roster always keeps a place for you")
        w.tick += int(w.RAID_MUSTER * .75); w._raid_call_tick()
        self.assertEqual(rc["ai"], rc["cap"] - 1, "the roster fills up during the muster")
        w.tick = rc["go"]; w._raid_call_tick(); cr = w.city_raid
        self.assertIsNotNone(cr)
        near = [a for a in w.actors if a.kind == "adventurer" and a.faction == fac and math.hypot(a.x - cr["x"], a.y - cr["y"]) < 150
                and a.state not in ("duel", "aiduel", "fight", "offer") and not a.party and w._friendly_town(t, a)]
        self.assertTrue(near)
        for _ in range(12): w.update(1)
        defending = [a for a in near if a.state == "defend" or a.hp <= 0]
        self.assertGreaterEqual(len(defending), len(near) * .9, f"{len(defending)} of {len(near)} nearby adventurers defend")
        w._raid_end(True); w.city_raid = None

# ======================================================================= spell elements (0.46.37)
class SpellElements(unittest.TestCase):
    def test_elements_and_descriptions(self):
        by = {a["name"]: a for v in E.ABILITIES.values() for a in v}
        for name, el, word in (("Frost Nova", "cold", "slowing"), ("Deep Freeze", "cold", "freezes"), ("Meteor", "fire", "ignites"),
                               ("Lightning Bolt", "electric", "shock"), ("Earthquake", "earth", "staggers")):
            self.assertEqual(E.spell_element(by[name]), el, name)
            self.assertIn(word, E.describe_ability(by[name]), name)
        for name in ("Rapid Fire", "Blade Tempest", "Heroic Strike", "Ice Barrier"):
            self.assertEqual(E.spell_element(by[name]), "", name)

    def test_class_flavour_is_modest(self):
        by = {a["name"]: a for v in E.ABILITIES.values() for a in v}
        for name, el in (("Shadow Bolt", "shadow"), ("Smite", "holy"), ("Serpent Sting", "poison"), ("Moonfire", "poison"), ("Holy Fire", "fire")):
            self.assertEqual(E.spell_element(by[name]), el, name)
        self.assertLessEqual(E.VULN_PCT, .10); self.assertLessEqual(E.HOLY_LEECH, .06); self.assertLessEqual(E.POISON_FRAC * E.POISON_SECS, .35)
        w = new_world(level=30, cls="Warlock")
        try:
            w.player["mana"] = 999
            mob = next(a for a in w.actors if a.kind == "monster" and a.faction != w.player["faction"])
            mob.hp = mob.maxhp = 100000; w.player["x"], w.player["y"] = mob.x + 1.0, mob.y; w._gtick = -1
            ab = next(a for a in w.ability_info() if a["name"] == "Shadow Bolt" or E.spell_element(a) == "shadow")
            w.selected_target = mob.id; w.ability_cooldowns[ab["slot"]] = 0; w.use_ability(ab["slot"])
            self.assertGreater(w.mstatus[mob.id].get("vuln", 0), w.tick)
        finally: w.close()

    def test_cold_slows_and_fire_burns_in_combat(self):
        w = new_world(level=30, cls="Mage")
        try:
            w.player["mana"] = 999
            mob = next(a for a in w.actors if a.kind == "monster" and a.faction != w.player["faction"])
            mob.hp = mob.maxhp = 100000; w.player["x"], w.player["y"] = mob.x + 1.0, mob.y
            w._gtick = -1
            ab = next(i for i, a in enumerate(w.ability_info()) if a["name"] == "Deep Freeze")
            w.selected_target = mob.id; w.ability_cooldowns[w.ability_info()[ab]["slot"]] = 0
            w.use_ability(w.ability_info()[ab]["slot"])
            self.assertGreater(w.mstatus[mob.id].get("slow", 0), w.tick)
            ab = next(a for a in w.ability_info() if a["name"] == "Meteor")
            w.player["level"] = 40; w.ability_cooldowns[ab["slot"]] = 0; w.use_ability(ab["slot"])
            self.assertEqual(w.mstatus[mob.id]["dot"]["name"], "Burning")
        finally: w.close()


# ======================================================================= 1.0.25 frost mage, silence, mana flow, respec price
class FrostMageKit(unittest.TestCase):
    def setUp(self): self.w = new_world(level=30, cls="Mage"); self.w.player["mana"] = 9999

    def tearDown(self): self.w.close()

    def info(self, name): return next(a for a in self.w.ability_info() if a["name"] == name)

    def cast(self, name, mob):
        w = self.w; w.player["mana"] = 9999; w.player["x"], w.player["y"] = mob.x + 1.0, mob.y
        w.selected_target = mob.id; ab = self.info(name); w.ability_cooldowns[ab["slot"]] = 0
        return w.use_ability(ab["slot"])

    def mob(self, name=None):
        w = self.w
        m = next(a for a in w.actors if a.kind == "monster" and a.faction != w.player["faction"])
        m.hp = m.maxhp = 10 ** 6; w._gtick = -1
        if name: m.name = name
        return m

    def test_respec_costs_500_gold_a_level(self):
        w = self.w
        for lvl in (1, 10, 50, 100):
            w.player["level"] = lvl; self.assertEqual(w.reset_cost(), 500 * lvl)
        self.assertEqual(E.RESET_GOLD_PER_LEVEL, 500)

    def test_the_kit_fits_the_hotbar_and_the_cooldowns_are_short(self):
        abl = E.ABILITIES["Mage"]; names = [a["name"] for a in abl]
        self.assertEqual((len(abl), len(set(names))), (16, 16)); self.assertLessEqual(len(abl), len(E.ABILITY_KEYS))
        for n in ("Arcane Bolt", "Frostbolt", "Ice Lance"): self.assertEqual(self.info(n)["cd"], 1, n)
        for a in abl: self.assertLessEqual(a["cd"], 30, a["name"])
        self.assertEqual([a["cd"] for a in abl[10:]], [7, 24, 8, 18, 10, 16])      # capstones at 40%
        self.assertLessEqual(max(a["cd"] for a in abl[:10] if a["name"] != "Arcane Meditation"), 10)

    def test_frostbolt_always_slows_and_ice_lance_freezes_more(self):
        w = self.w; m = self.mob()
        for _ in range(8):      # the slow never fails, whatever the dice say
            w.mstatus.pop(m.id, None); self.cast("Frostbolt", m)
            self.assertGreaterEqual(w.mstatus[m.id]["slow"] - w.tick, 6 * 4 - 1)
        self.assertEqual(self.info("Ice Lance")["freeze"], .5); self.assertLess(self.info("Frostbolt")["freeze"], E.FREEZE_CHANCE)
        real = w.rng.random
        try:
            w.rng.random = lambda: .3      # under Ice Lance's 50%, over Frostbolt's 10% and ...
            w.mstatus.pop(m.id, None); self.cast("Ice Lance", m); self.assertGreater(w.mstatus[m.id].get("stun", 0), w.tick)
            w.mstatus.pop(m.id, None); self.cast("Frostbolt", m); self.assertLessEqual(w.mstatus[m.id].get("stun", 0), w.tick)
        finally: w.rng.random = real

    def test_bosses_are_slowed_but_never_frozen_by_the_roll(self):
        w = self.w; m = self.mob(); m.kind, m.role = "imob", "boss"; real = w.rng.random
        try:
            w.rng.random = lambda: 0.0
            w.mstatus.pop(m.id, None); self.cast("Ice Lance", m)
            self.assertGreater(w.mstatus[m.id].get("slow", 0), w.tick); self.assertLessEqual(w.mstatus[m.id].get("stun", 0), w.tick)
        finally: w.rng.random = real

    def test_ice_lance_hits_harder_on_a_slowed_target(self):
        w = self.w; m = self.mob(); real = w.rng.random; seen = {}
        try:
            w.rng.random = lambda: .99      # no crits, no freezes
            for tag, slowed in (("cold", False), ("slowed", True)):
                tot = 0
                for _ in range(12):
                    w.mstatus.pop(m.id, None)
                    if slowed: w.mstatus[m.id] = {"slow": w.tick + 100}
                    hp = m.hp; self.cast("Ice Lance", m); tot += hp - m.hp
                seen[tag] = tot
        finally: w.rng.random = real
        self.assertGreater(seen["slowed"], seen["cold"] * 1.3)

    def test_silence_stops_a_caster_monster_from_attacking(self):
        w = self.w; m = self.mob("Cultist #9001"); m.level = 5; p = w.player
        p["x"], p["y"] = m.x + .5, m.y      # out of the safe starting town, next to the cultist
        def swings(silenced):
            w.mstatus.pop(m.id, None); m.timer = 0; m.target = -2; m.state = "chase"; m.x, m.y = p["x"] + .5, p["y"]; p["hp"] = p["maxhp"]
            if silenced: w.mstatus[m.id] = {"silence": w.tick + 40}
            w.hits_taken.clear(); w._monster_player_ai(); return len(w.hits_taken)
        self.assertGreater(swings(False), 0); self.assertEqual(swings(True), 0)
        w.mstatus.pop(m.id, None); self.assertIn("silences", self.cast("Glacial Silence", m))
        self.assertTrue(w._silenced(m)); self.assertGreaterEqual(w.mstatus[m.id]["silence"] - w.tick, 4 * 4 - 1)
        w.tick += 4 * 4 + 2; self.assertFalse(w._silenced(m))      # and it wears off

    def test_silence_interrupts_a_boss_cast_and_does_not_silence_it(self):
        w = self.w; calls = []
        stub = type("Inst", (), {"_interrupt": lambda s, b, by_player: calls.append(by_player)})()
        boss = type("Boss", (), {"kind": "imob", "role": "boss", "cast": {"interruptible": True}})()
        I.Instance.on_player_hit(stub, boss, self.info("Glacial Silence")); self.assertEqual(calls, [True])
        boss.cast = {"interruptible": False}; I.Instance.on_player_hit(stub, boss, self.info("Glacial Silence")); self.assertEqual(calls, [True])
        boss.cast = {"interruptible": True}; I.Instance.on_player_hit(stub, boss, self.info("Frostbolt")); self.assertEqual(calls, [True])
        m = self.mob(); m.kind, m.role = "imob", "boss"; self.assertIn("interrupts", self.cast("Glacial Silence", m))
        self.assertFalse(w._silenced(m))

    def test_silenced_caster_hero_cannot_strike(self):
        w = self.w; hero = type("H", (), {"id": 777, "role": "Mage"})(); arch = type("H", (), {"id": 778, "role": "Ranger"})()
        w.mstatus[777] = {"silence": w.tick + 40}; w.mstatus[778] = {"silence": w.tick + 40}
        self.assertTrue(w._caster_silenced(hero)); self.assertFalse(w._caster_silenced(arch))      # an archer is not a caster

    def test_arcane_meditation_restores_mana_even_in_combat(self):
        w = self.w; w.player["level"] = 5; ab = self.info("Arcane Meditation")
        self.assertEqual((ab["unlock"], ab["mana"]), (4, 0)); self.assertFalse(ab["locked"])
        mm = w.max_mana(); w.player["mana"] = 0; w.last_combat_tick = w.tick
        w.update(16); idle = w.player["mana"]      # four seconds in combat: no natural regeneration
        self.assertEqual(idle, 0)
        w.ability_cooldowns[ab["slot"]] = 0; self.assertIn("restoring", w.use_ability(ab["slot"]))
        def fight(ticks):      # stay "in combat" the whole time, so only the spell can be giving mana
            for _ in range(ticks): w.last_combat_tick = w.tick; w.update(1)
        fight(16); self.assertGreaterEqual(w.player["mana"], mm * .05 * 3 - 1); self.assertLessEqual(w.player["mana"], mm * .05 * 5 + 1)
        fight(40); full = w.player["mana"]      # 8 seconds in all: about 40% of the mana pool, then it stops
        self.assertGreaterEqual(full, mm * .05 * 7 - 1); self.assertLessEqual(full, mm * .05 * 8 + 1)
        fight(40); self.assertEqual(w.player["mana"], full)
        self.assertEqual(E.spell_element(self.info("Arcane Meditation")), "")      # "Arcane" in the name does not make it a shock spell

    def test_descriptions_exist_for_the_new_kinds(self):
        for n in ("Frostbolt", "Ice Lance", "Glacial Silence", "Arcane Meditation"):
            self.assertTrue(self.info(n)["desc"], n)
        self.assertIn("harder", self.info("Ice Lance")["desc"]); self.assertIn("50%", self.info("Ice Lance")["desc"])
        self.assertIn("silences", self.info("Glacial Silence")["desc"]); self.assertIn("mana", self.info("Arcane Meditation")["desc"])


# ======================================================================= damaged saves (0.46.42)
class DamagedSaves(unittest.TestCase):
    def test_garbage_in_the_save_never_crashes_a_lookup(self):
        w = new_world(level=40, cls="Warrior")
        try:
            for bad in ("[]", "5", "null", '"text"', "{not json", '{"owned": "x", "active": 7, "riding": "high"}', '{"active": 3, "finished": 4}'):
                for key in ("mounts", "quests2", "mkt", "build", "mythic", "pparty", "dead_leaders"):
                    w._setmeta(key, bad)
                w._mount_cache = None; w._build_c = None; w._dead_leaders = None
                w._qs(); w._mst(); w._mkt_state(); w._build(); w._pp_ids(); w.mythic_info()
                w.can_mount(); w.market_view() if w.market_town() else None; w.teleport_view()
                self.assertIsInstance(w._mst()["owned"], list); self.assertIsInstance(w._qs()["active"], list)
        finally: w.close()

    def test_unknown_mounts_in_a_save_are_dropped(self):
        w = new_world(level=40)
        try:
            w._setmeta("mounts", json.dumps({"riding": 99, "owned": ["wolf", "nonsense", 5], "active": "nonsense"}))
            w._mount_cache = None; st = w._mst()
            self.assertEqual((st["owned"], st["active"], st["riding"]), (["wolf"], None, 0))
        finally: w.close()


# ======================================================================= dungeons
class RestAfterBosses(unittest.TestCase):
    """1.0.18: dungeons and raids alike - no rest after a trash room, 15 seconds after a boss."""
    def test_rest_only_after_bosses(self):
        w = new_world(level=100)
        try:
            for kind, hero in (("dungeon", False), ("dungeon", True), ("raid", False), ("raid", True)):
                with self.subTest(kind=kind, heroic=hero):
                    d = next(x for x in w.dungeons if x.kind == kind)
                    w.player["x"], w.player["y"] = d.x, d.y + 1
                    msg = w.enter_instance(hero)
                    self.assertIsNotNone(w.inst, msg)
                    inst = w.inst
                    for typ, want in (("trash", 0), ("boss", 15)):
                        r = next(r for r in inst.rooms if r["type"] == typ and not r["cleared"])
                        inst.rest_until = 0
                        for mid in r["mobs"]: inst.actors[mid].hp = 0
                        inst._room_ai(r)
                        self.assertTrue(r["cleared"])
                        self.assertEqual(inst.rest_left(), want, f"{kind} {typ} room")
                    w.leave_instance(silent=True)
        finally:
            w.close()


# ======================================================================= raids 1.0.24: groups, falling, friendly fire
class RaidFalls(unittest.TestCase):
    def setUp(self):
        self.w = new_world(level=60)

    def tearDown(self):
        if self.w.inst: self.w.leave_instance(silent=True)
        self.w.close()

    def enter(self, kind, hero):
        w = self.w
        if w.inst: w.leave_instance(silent=True)
        d = next(x for x in w.dungeons if x.kind == kind)
        w.player["x"], w.player["y"] = d.x, d.y + 1
        msg = w.enter_instance(hero); self.assertIsNotNone(w.inst, msg)
        return w.inst

    def pull_boss(self, inst):
        r = next(r for r in inst.rooms if r["type"] in ("boss", "final"))
        for rr in inst.rooms:
            if rr is r: break
            for mid in rr["mobs"]: inst.actors[mid].hp = 0
            rr["cleared"] = rr["pulled"] = True
        self.w.player["x"], self.w.player["y"] = r["cx"], r["cy"] + 4
        inst._pull(r)
        return inst.actors[r["boss"]]

    def test_raid_groups(self):
        for kind, hero, want in (("raid", False, {"Tank": 3, "Healer": 3, "DPS": 6}), ("raid", True, {"Tank": 6, "Healer": 6, "DPS": 12}),
                                 ("heroic", True, {"Tank": 6, "Healer": 6, "DPS": 12})):
            with self.subTest(kind=kind, heroic=hero):
                self.w.player["level"] = 100 if kind == "heroic" else 60
                inst = self.enter(kind, hero)
                got = collections.Counter(a.rrole for a in inst.allies); got[self.w.spec_role()] += 1
                self.assertEqual(dict(got), want)

    def test_falling_in_a_raid_is_not_a_wipe(self):
        from liveworld_rpg import instance as I
        w = self.w; inst = self.enter("raid", False); boss = self.pull_boss(inst)
        w.damage_player(w._effective_maxhp() * 50, boss, boss.id, mech=True)
        self.assertTrue(inst.player_down()); self.assertEqual(inst.wipes, 0); self.assertEqual(w.player["hp"], 0)
        self.assertEqual(w.damage_player(9999, boss, boss.id), 0, "nothing hits a fallen raider")
        self.assertIn("down", w.use_potion())
        self.assertGreater(boss.hp, 0)
        for _ in range((I.BATTLE_REZ + 3) * I.TPS):
            w.update(1)
            if not inst.player_down(): break
        self.assertFalse(inst.player_down(), "a healer resurrects you")
        self.assertGreater(w.player["hp"], 0); self.assertEqual(inst.wipes, 0)

    def test_wipe_only_when_everyone_is_down(self):
        w = self.w; inst = self.enter("raid", False); boss = self.pull_boss(inst)
        w.damage_player(w._effective_maxhp() * 50, boss, boss.id, mech=True)
        for a in inst.allies: a.hp = 0; a.dead = True; a.dead_tick = w.tick
        w.update(1)
        self.assertEqual(inst.wipes, 1); self.assertFalse(inst.player_down()); self.assertGreater(w.player["hp"], 0)

    def test_leaving_never_lands_you_in_something_solid(self):
        w = self.w; inst = self.enter("dungeon", False)
        rx, ry = inst.return_pos
        w.terrain_ok = lambda x, y: (x - rx) ** 2 + (y - ry) ** 2 > 1.5 ** 2      # a tree / rock / pond right on the exit spot
        try:
            w.leave_instance(silent=True)
            self.assertTrue(w.terrain_ok(w.player["x"], w.player["y"]), "the character must not be stuck on leaving")
            self.assertLess(math.hypot(w.player["x"] - rx, w.player["y"] - ry), 4)
        finally:
            w.terrain_ok = None

    def test_dungeon_death_still_wipes(self):
        w = self.w; inst = self.enter("dungeon", False); boss = self.pull_boss(inst)
        w.damage_player(w._effective_maxhp() * 50, boss, boss.id, mech=True)
        self.assertEqual(inst.wipes, 1); self.assertFalse(inst.player_down())

    def test_no_friendly_fire(self):
        w = self.w; inst = self.enter("raid", False); boss = self.pull_boss(inst)
        a = inst.allies[0]; hp0 = a.hp
        self.assertEqual(w._hit(a, 500)[0], 0); self.assertEqual(a.hp, hp0)
        for x in inst.allies: x.x, x.y = w.player["x"] + .5, w.player["y"]
        hps = [x.hp for x in inst.allies]
        inst.mark = {"start": w.tick, "until": w.tick, "boss": boss.id}; inst._mark_tick()
        self.assertEqual([x.hp for x in inst.allies], hps, "the Void Mark never hurts your allies")

    def test_city_raids_come_every_18_to_32_minutes(self):
        w = self.w
        if w.inst: w.leave_instance(silent=True)
        w.city_raid = None; w.raid_call = None; w._raid_next = None
        w._raid_tick(); first = w._raid_next - w.tick
        self.assertTrue(w.RAID_FIRST[0] <= first <= w.RAID_FIRST[1])
        w.tick = w._raid_next; w._raid_tick()
        self.assertIsNotNone(w.raid_call, "a raid is announced when it falls due")
        self.assertTrue(w.RAID_GAP[0] <= w._raid_next - w.tick <= w.RAID_GAP[1])


class Dungeons(unittest.TestCase):
    def test_each_instance_kind(self):
        w = new_world(level=100)
        try:
            for kind, hero in (("dungeon", False), ("dungeon", True), ("raid", False), ("raid", True), ("heroic", True)):
                with self.subTest(kind=kind, heroic=hero):
                    d = next(x for x in w.dungeons if x.kind == kind)
                    w.player["x"], w.player["y"] = d.x, d.y + 1
                    msg = w.enter_instance(hero)
                    self.assertIsNotNone(w.inst, msg)
                    inst = w.inst
                    self.assertEqual(len(inst.allies) + 1, E.PARTY_SIZE[inst.tier], "party size")
                    self.assertEqual(inst.heroic, hero)
                    self.assertTrue(all(y < E.H - 1 and x < E.W - 1 for x, y in inst.floor), "instance outside the reserved strip")
                    self.assertTrue((int(inst.spawn[0]), int(inst.spawn[1])) in inst.floor, "spawn in a wall")
                    reach = flood(inst.floor, inst.spawn)
                    for act in inst.actors.values():
                        self.assertTrue((int(act.x), int(act.y)) in reach, f"{act.name} unreachable at {(act.x, act.y)}")
                    for _ in range(300):
                        w.update(1)
                        if w.inst is None: break
                    json.dumps(inst.snapshot())
                    if w.inst: w.leave_instance()
                    self.assertIsNone(w.inst)
        finally:
            w.close()


class TieredInstances(unittest.TestCase):
    """1.0.16: Regular / Heroic dungeons (4 / 8) and raids (12 / 24) in every zone; instance gear is the best; Mythic in the last zones."""
    @classmethod
    def setUpClass(cls):
        cls.w = new_world(level=100)

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def test_every_zone_has_dungeons_and_a_raid(self):
        for a in E.AREAS:
            with self.subTest(zone=a[0]):
                self.assertEqual(sum(1 for d in self.w.dungeons if d.area == a[0] and d.kind == "dungeon"), 2)
                self.assertEqual(sum(1 for d in self.w.dungeons if d.area == a[0] and d.kind == "raid"), 1)

    def test_party_sizes(self):
        self.assertEqual(I.sizes_for("dungeon"), (4, 8))
        self.assertEqual(I.sizes_for("raid"), (12, 24))
        self.assertEqual(I.sizes_for("heroic"), (None, 24))

    def test_rooms_grow_with_the_party(self):
        sizes = [I.GEOM[t][0] for t in ("dungeon", "dungeon_h", "raid", "raid_h")]
        self.assertEqual(sizes, sorted(sizes))
        for t, (room, step, corr) in I.GEOM.items():
            rows = max(r_ for _c, r_ in I.SNAKE[:len(I.PLAN[t])]) + 1
            self.assertGreaterEqual(room, 37, f"{t}: room for 24 to move (1.0.24)")
            self.assertLess(3 + (rows - 1) * step + room + 2, E.INST_H, t)
            self.assertGreater(step - room, 2 * corr, t)

    def test_entrance_opens_the_difficulty_picker(self):
        w = self.w
        d = next(x for x in w.dungeons if x.kind == "raid")
        w.player["x"], w.player["y"] = d.x, d.y + 1
        msg = w.interact_nearby()
        self.assertIsNone(w.inst, msg); self.assertEqual(w.open_ui, "instpick")
        w.open_ui = None
        v = w.instance_choices()
        self.assertEqual([o["size"] for o in v["options"]], [12, 24])
        self.assertLess(v["options"][0]["gear"][0], v["options"][1]["gear"][0])
        h = next(x for x in w.dungeons if x.kind == "heroic")
        w.player["x"], w.player["y"] = h.x, h.y + 1
        w.choose_instance()
        self.assertIsNotNone(w.inst); self.assertEqual(w.inst.tier, "heroic")
        w.leave_instance(silent=True)

    def test_instance_gear_beats_everything_else(self):
        w = self.w
        for lv in range(1, 101):
            best_other = max(lv * 2 + E.RARITY_POWER["Legendary"] + 16,       # Legendary questline (the strongest quest piece)
                             min(186, lv * 2 + E.RARITY_POWER["Legendary"] + 3 + 12),   # Ascendant Forge piece
                             min(w.MAGIC_CAP, lv * 2 + E.RARITY_POWER["Elite"] + 14) + 12,  # Magic Shop Elite +2
                             min(182, lv * 2 + 62))                             # Legendary Gladiator's
            if lv >= 90: best_other = max(best_other, 204)                    # Mythic Gladiator's weapon
            lows = [w.inst_power(lv, "Rare", t, trash=True) for t in ("dungeon", "dungeon_h", "raid", "raid_h", "heroic") for _ in range(3)]
            self.assertGreater(min(lows), best_other, lv)
        tiers = [w.inst_power(50, "Elite", t) for t in ("dungeon", "dungeon_h", "raid", "raid_h")]
        self.assertTrue(all(b > a - 5 for a, b in zip(tiers, tiers[1:])))
        # 1.0.17: Heroic raid (24) gear is best in slot - its weakest piece beats any other difficulty's best, Mythic included
        for lv in (10, 50, 100):
            best_other = max(w.inst_power(lv, "Mythic", t) for t in ("dungeon", "dungeon_h", "raid") for _ in range(20))
            worst_hr = min(w.inst_power(lv, "Rare", "raid_h", trash=True) for _ in range(20))
            self.assertGreater(worst_hr, best_other, lv)

    def test_raid_finder_shows_this_zone_and_returns_you(self):
        """1.0.17: the War Hall's Raid Finder lists the zone's raid and dungeons and sends you straight in."""
        from liveworld_rpg import gfx
        w = self.w
        w.station_posts = gfx.WorldLayout(w).stations
        posts = (w.station_posts or {}).get("warhall")
        self.assertTrue(posts)
        w.player["x"], w.player["y"] = posts[0]
        zone = w.area(*posts[0])[0]
        f = w.finder_list()
        self.assertEqual(f["zone"], zone)
        self.assertTrue(f["raids"]); self.assertEqual(len(f["dungeons"]), 2)
        self.assertTrue(all(d["area"] == zone for d in f["raids"] + f["dungeons"]))
        raid = next(d for d in f["raids"] if d["kind"] == "raid")
        self.assertEqual(raid["sizes"], (12, 24))
        other = next(d for d in w.dungeons if d.kind == "raid" and d.area != zone)
        self.assertIsNone(w.inst); w.enter_from_finder(other.id, True); self.assertIsNone(w.inst)
        msg = w.enter_from_finder(raid["id"], True)
        self.assertIsNotNone(w.inst, msg); self.assertEqual(w.inst.tier, "raid_h"); self.assertEqual(len(w.inst.allies) + 1, 24)
        w.leave_instance(silent=True)
        self.assertTrue(w._near_station("warhall", 9), "back at the War Hall")
        w.enter_from_finder(f["dungeons"][0]["id"], False)
        self.assertEqual(w.inst.tier, "dungeon"); w.leave_instance(silent=True)

    def test_throne_keeps_level_100_after_reload(self):
        """1.0.17: loading a save used to put the level 100 Throne down to level 91."""
        w = new_world(level=100); w.close()
        w = E.World()
        try:
            self.assertTrue([d for d in w.dungeons if d.kind == "heroic"])
            self.assertTrue(all(d.level == 100 for d in w.dungeons if d.kind == "heroic"))
        finally: w.close()

    def test_mythic_only_in_the_last_zones(self):
        w = self.w
        seen = {}
        for area in ("Greenfields", "Crownlands", "Wyrmreach", "Shadowlands"):
            seen[area] = {w.drop_instance_loot(0, 0, 90, "raid_h", "boss", "x", area=area) for _ in range(200)}
        self.assertNotIn("Mythic", seen["Greenfields"] | seen["Crownlands"])
        self.assertIn("Mythic", seen["Wyrmreach"]); self.assertIn("Mythic", seen["Shadowlands"])
        row = w.db.execute("SELECT * FROM ground_loot WHERE rarity='Mythic' ORDER BY id DESC LIMIT 1").fetchone()
        self.assertTrue(row["item"].startswith(("Wyrmforged", "Umbral")))
        from liveworld_rpg.bonuses import mythic_bonus
        self.assertTrue(mythic_bonus(row["item"], row["slot"], w.class_name()))
        w.db.execute("DELETE FROM ground_loot"); w.db.commit()


# ======================================================================== render
class Render(unittest.TestCase):
    """Draws real frames through game.Game with the dummy video driver."""

    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import game as G
        cls.G = G
        cls.w = new_world(level=30)
        cls.g = G.Game(cls.w)
        cls.g.mouse = (10, 10)
        cls.g.apply_quality(1, False, False)

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def frames(self, n=6, ticks=True):
        for _ in range(n):
            if ticks: self.w.update(1)
            self.g.frame(1 / 30); self.G.present()

    def test_people_render_as_3d_bodies(self):
        from liveworld_rpg import gfx
        looks = []
        for a in self.w.actors:
            d = {"id": a.id, "kind": a.kind, "role": a.role, "faction": a.faction, "level": a.level, "name": a.name, "gear": getattr(a, "gear", "Common"),
                 "setl": getattr(a, "setl", ""), "setp": list(getattr(a, "setp", ()))}
            key, sk, spec, sc = gfx.actor_look(d)
            if sk == "human": looks.append(spec)
        seen = {}
        for sp in looks:
            seen.setdefault((sp.get("head"), bool(sp.get("robe")), sp.get("weapon")), sp)
        self.assertGreater(len(seen), 15)
        for k_, sp in list(seen.items())[:60]:
            for fr in (-1, 1):
                gfx.LIGHT3D[0] = True
                spr, anc = gfx.draw_humanoid3d(sp, fr, fr == 1, 1.0)
                r = spr.get_bounding_rect()
                self.assertGreater(r.h, 80, k_); self.assertGreater(r.w, 25, k_)
        # the flat look stays for Lite graphics
        gfx.LIGHT3D[0] = False
        spr2, _ = gfx.draw_humanoid(next(iter(seen.values())), -1, False, 1.0)
        gfx.LIGHT3D[0] = True
        self.assertGreater(spr2.get_bounding_rect().h, 80)

    def test_houses_are_taller_on_the_same_footprint(self):
        from liveworld_rpg import gfx
        for var in range(4):
            spr, anc, w_, d_ = gfx.co_building("house", "Alliance", var)
            self.assertEqual((w_, d_), (2.0, 2.0), "footprint unchanged")
            self.assertGreater(spr.get_height(), 150, "two storeys or more")

    def test_mounts_render_in_3d(self):
        from liveworld_rpg import gfx, mount3d
        self.assertTrue(mount3d.HAVE)
        for look in mount3d.LOOKS:
            for fr in (-1, 0, 1, 2, 3):
                for fly in ((False, True) if look in ("gryphon", "wyvern", "pegasus", "drake") else (False,)):
                    S, seat = gfx.draw_mount(look, fr, fly)
                    self.assertEqual(S.get_size(), (330, 250))
                    self.assertGreater(S.get_bounding_rect().width, 150, f"{look} frame {fr} drew nothing")
        spr, anc = gfx.mounted_sprite(("t",), {"body": (90, 90, 100), "trim": (200, 170, 60), "legs": (60, 60, 70), "boots": (40, 30, 20)}, "horse", 1, 1)
        self.assertGreater(spr.get_width(), 100)

    def test_people_stand_on_bridge_decks(self):
        from liveworld_rpg import gfx
        brs = gfx._bridges(self.g.layout)[0]
        self.assertTrue(brs, "the world has bridges")
        run, hw = max(brs, key=lambda b: len(b[0]))
        mx, my = run[len(run) // 2]
        self.assertGreater(gfx.bridge_lift(self.g.layout, mx, my), 10, "mid-span is up on the deck")
        self.assertEqual(gfx.bridge_lift(self.g.layout, mx + 40, my + 40), 0.0)
        stone, RISE, ramp, e = gfx._bridge_geom(run, hw)
        self.assertGreater(e, hw, "bridges are wider than the road")

    def test_battlefield_ground(self):
        w = self.w
        a = enter(w, "ctf12")
        from liveworld_rpg import instance as I_
        x, y = int(a.X0 + a.Wd * .3), int(a.Y0 + 6)
        k, c = I_.tile_info_for(x, y)
        self.assertEqual(k, "dfloor"); self.assertGreater(c[1], c[0], "a green meadow away from the road")
        self.frames(4)
        w.leave_instance(silent=True)

    def test_full_sprite_cache_trims_without_error(self):
        """1.0.19: once the character sprite cache was full, trimming it raised TypeError every frame - which closed the map."""
        from liveworld_rpg import gfx
        old = gfx.CHAR_CACHE_MAX
        try:
            gfx.CHAR_CACHE_MAX = 260
            for i in range(300):
                spr = self.G.pygame.Surface((4, 4), self.G.pygame.SRCALPHA)
                gfx._CHAR[("t", i)] = (spr, (2, 2)); gfx._CHAR_BYTES[0] += 64
                gfx._BOUNDS[spr] = spr.get_bounding_rect()
                gfx._char_trim()
            self.assertLessEqual(len(gfx._CHAR), 260)
        finally:
            gfx.CHAR_CACHE_MAX = old

    def test_map_stays_open(self):
        self.g.mode = "map"; self.g.map_open_default() if hasattr(self.g, "map_open_default") else None
        self.frames(8)
        self.assertEqual(self.g.mode, "map")
        self.g.mode = "world"

    def test_world_frames(self):
        for q in (0, 1, 2):
            with self.subTest(quality=q):
                self.g.apply_quality(q, False, False); self.frames()
                self.assertEqual(self.g.quality, q)
        for hour in (7.6, 12.0, 17.6, 22.0):        # 0.37 High: sun rays, sharpening and soft shadows at every time of day
            with self.subTest(hour=hour):
                self.w.tick = int(hour * 40); self.frames(3, ticks=False)
        self.g.apply_quality(1, False, False)

    def test_every_arena_map_draws(self):
        for mode in ALL_MODES:
            with self.subTest(mode=mode):
                enter(self.w, mode)
                self.frames(8)
                self.w.inst._finish("blue"); self.frames(4)
                self.w.leave_instance(silent=True); self.frames(2)

    def test_windows_draw(self):
        for m in ("guide", "pvp", "armory", "stats", "skills", "inventory", "map", "quests", "settings", "vault"):
            with self.subTest(window=m):
                self.g.mode = m; self.frames(2, ticks=False)
        self.g.mode = "world"

    def test_difficulty_picker_and_24_player_raid_draw(self):
        """1.0.16: the Regular / Heroic picker and a 24-player raid (two-column party frames) draw."""
        w, g = self.w, self.g
        for kind in ("dungeon", "raid"):
            d = next(x for x in w.dungeons if x.kind == kind)
            w.player["level"] = max(w.player["level"], d.level)
            w.player["x"], w.player["y"] = d.x, d.y + 1
            g.msg(w.choose_instance(), (255, 255, 255)); g.open_world_ui()
            self.assertEqual(g.mode, "instpick")
            self.frames(2, ticks=False)
            g.pick_instance(True)
            self.assertIsNotNone(w.inst); self.assertEqual(g.mode, "world")
            self.assertEqual(w.inst.tier, kind + "_h")
            self.frames(6)
            w.leave_instance(silent=True); self.frames(2)
        w.player["level"] = 30

    def test_clicking_a_building_opens_it(self):
        """0.36.2: no hanging signs; clicking the building itself opens its window, even with an NPC beside it."""
        self.assertFalse(hasattr(self.G, "station_plaque") or hasattr(self.G, "STATION_SIGNS"))
        g, w, p = self.g, self.w, self.w.player
        for kind, want in (("hut", ("craft", "hut")), ("forge", ("craft", "forge")), ("press", ("craft", "press")), ("warhall", ("pvp", None)), ("magic", ("magic", None)),
                           ("smithy", ("shop", None)), ("general", ("shop", None)), ("enchanter", ("shop", None)), ("bank", ("vault", None)), ("stable", ("stable", None)), ("market", ("market", None)), ("apothecary", ("shop", None)), ("jeweler", ("shop", None)), ("kiln", ("kiln", None)), ("inn", ("craft", "inn")), ("tavern", ("tavern", None)), ("petshop", ("petshop", None))):
            with self.subTest(station=kind):
                posts = (w.station_posts or {}).get(kind)
                self.assertTrue(posts, f"no {kind} in town")
                p["x"], p["y"] = posts[0]; g.mode = "world"; g.pending = None
                self.frames(2, ticks=False)
                spot = None
                for rr, obj in g.hit_rects:
                    if obj[0] != "station" or obj[1] != kind: continue
                    for fx_ in range(rr.left + 2, rr.right - 2, 4):
                        for fy_ in range(rr.top + 2, rr.bottom - 2, 4):
                            top = next((o for r2, o in reversed(g.hit_rects) if r2.collidepoint((fx_, fy_))), None)
                            # 1.0.23: a person under the cursor wins over the building, so test a spot nobody stands on
                            if top is obj and not any(o[0] == "actor" and r2.collidepoint((fx_, fy_)) for r2, o in g.hit_rects): spot = (fx_, fy_); break
                        if spot: break
                    if spot: break
                self.assertIsNotNone(spot, f"{kind} building is not clickable")
                labels = [rr for rr, obj in g.hit_rects if obj[0] == "station" and obj[1] == kind and rr.height < 30]
                self.assertTrue(labels, f"{kind} has no name label")
                g.click_world(spot, 1)
                self.assertEqual(g.pending[:2], ("station", kind))
                p["x"], p["y"] = g.pending[2] + 2.4, g.pending[3] + 2.4
                g.resolve_pending()
                self.assertEqual(g.mode, want[0], f"{kind}: {g.log[-1] if getattr(g, 'log', None) else ''}")
                if want[1]: self.assertEqual(g.craft_station, want[1])
        g.mode = "world"


class DungeonLabelAndInn(unittest.TestCase):
    """1.0.13: the map label matches the real party; night sleepers use the real Inn post."""
    def test_party_size_matches_instance_party(self):
        for kind, need in I.PARTY.items():
            self.assertEqual(E.PARTY_SIZE[kind], sum(need.values()), kind)

    def test_inn_post_matches_building(self):
        from liveworld_rpg import gfx
        self.assertEqual(tuple(E.INN_POST), tuple(gfx.STATION_POSTS["inn"]))


class CityRaidBoss(unittest.TestCase):
    """1.0.24: attacking a city, every guard is a target and stays dead; the ruler is the boss - its fall ends the raid."""
    def setUp(self):
        self.w = new_world(level=95, faction="Alliance", cls="Warrior")
        w = self.w; self.t = next(t for t in w.towns if t.faction == "Horde" and w.town_tier(t) == "city")
        w.raid_call = None; w.city_raid = None
        self.assertTrue(w._raid_start(self.t)); self.r = w.city_raid
        w.player["x"], w.player["y"] = self.t.x + 2, self.t.y + 2; w._outlaw_tick()

    def tearDown(self):
        self.w.city_raid = None; self.w.close()

    def guards(self):
        return [a for a in self.w.actors if a.kind == "npc" and a.role == "guard" and self.w._town_for_actor(a) is self.t and a.hp > 0 and not getattr(a, "slain", False)]

    def test_every_guard_is_a_target_and_stays_dead(self):
        w = self.w; gs = self.guards()
        self.assertTrue(gs)
        for g in gs:
            with self.subTest(guard=g.name):
                self.assertTrue(w._guard_hostile(g), f"{g.name} must be attackable in a raid")
        defs = set(self.r.get("defs", []))
        for g in (max((a for a in gs if a.id not in defs), key=lambda a: (a.x - self.t.x) ** 2 + (a.y - self.t.y) ** 2),      # a patrol or gate guard
                  next((a for a in gs if a.id in defs), None)):                                                            # and one of the garrison
            if g is None: continue
            g.hp = 1; w.player["x"], w.player["y"] = g.x + 1, g.y
            self.assertIn("Defeated", w.attack_target(g.id))
            self.assertNotIn(g, self.guards()); self.assertFalse(w._guard_hostile(g))
            self.assertTrue(getattr(g, "slain", False) or g.id not in w.by_id, "dead, not 'wounded'")
        self.assertEqual(w.outlaw_left(), 0); self.assertEqual(w.infamy(), 0)

    def test_killing_the_ruler_ends_the_raid(self):
        w = self.w
        w._raid_tick()
        king = next(a for a in w.actors if a.kind == "npc" and a.role == "king" and w._town_for_actor(a) is self.t)
        self.assertGreater(king.maxhp, king.raid_boss, "the ruler has boss health")
        self.assertTrue(w.leader_attackable(king))
        king.hp = 1; w.player["x"], w.player["y"] = king.x + 1, king.y
        w.attack_target(king.id); w._raid_tick()
        self.assertIsNone(w.city_raid, "the raid is over")
        self.assertTrue(w.town_protected(self.t), "the city is taken")
        self.assertEqual(king.maxhp, king.raid_boss or king.maxhp)


class SmarterNPCs(unittest.TestCase):
    """1.0.24: better-geared computer heroes, level-scaled guards, potions and healing in any fight."""
    @classmethod
    def setUpClass(cls): cls.w = new_world(level=50)

    @classmethod
    def tearDownClass(cls): cls.w.close()

    def test_gear_mix(self):
        advs = [a for a in self.w.actors if a.kind == "adventurer"]
        self.assertFalse(any(a.gear == "Poor" for a in advs))
        good = sum(1 for a in advs if a.gear in ("Epic", "Elite", "Set", "Legendary", "Mythic")) / len(advs)
        self.assertGreater(good, .35)

    def test_guards_scale_with_level(self):
        gs = [a for a in self.w.actors if a.kind == "npc" and a.role == "guard" and not a.name.startswith("Town Defender")]
        lo = min(gs, key=lambda a: a.level); hi = max(gs, key=lambda a: a.level)
        self.assertGreater(hi.level, lo.level)
        self.assertGreater(sum(a.maxhp for a in gs if a.level == hi.level) / max(1, sum(1 for a in gs if a.level == hi.level)),
                           sum(a.maxhp for a in gs if a.level == lo.level) / max(1, sum(1 for a in gs if a.level == lo.level)))

    def test_potion_and_healer(self):
        w = self.w
        a = next(x for x in w.actors if x.kind == "adventurer" and x.role not in w.HEALER_CLASSES)
        a.hp = int(a.maxhp * .2); a.pot_t = 0; w._person_sustain(a)
        self.assertGreater(a.hp, a.maxhp * .5)
        h = next(x for x in w.actors if x.kind == "adventurer" and x.role in w.HEALER_CLASSES)
        h.hp = int(h.maxhp * .4); h.pot_t = 10 ** 9; h.healed_t = -999; w._person_sustain(h)
        self.assertGreater(h.hp, h.maxhp * .6)


class RangedReach(unittest.TestCase):
    """1.0.24: ranged skills reach half as far again; melee and novas are unchanged."""
    def test_ranges(self):
        A = E.ABILITIES
        bolt = next(a for a in A["Mage"] if a["name"] == "Arcane Bolt"); self.assertEqual(bolt["range"], 13.5)
        nova = next(a for a in A["Mage"] if a["name"] == "Frost Nova"); self.assertEqual(nova["range"], 3.0)
        strike = next(a for a in A["Warrior"] if a["name"] == "Heroic Strike"); self.assertEqual(strike["range"], 2.0)
        for k, lst in A.items():
            for a in lst:
                with self.subTest(cls=k, skill=a["name"]):
                    self.assertFalse(a["cat"] == "attack" and a["kind"] != "nova" and 6 <= a["range"] < 9, "a ranged skill was left short")


class MountGrip(unittest.TestCase):
    """1.0.24: being hit only sometimes throws you off a ground mount - less often the better you ride."""
    def test_chance_falls_with_riding(self):
        w = new_world(level=60)
        try:
            mx = w._effective_maxhp(); rates = []
            for rk in (1, 2, 3, 4):
                w._mst()["riding"] = rk; w.rng.seed(rk)
                rates.append(sum(w._thrown_off(1) for _ in range(4000)) / 4000)
            self.assertEqual(rates, sorted(rates, reverse=True))
            self.assertLess(rates[0], .3); self.assertLess(rates[-1], .1)
            self.assertTrue(w._thrown_off(mx * .3), "a heavy blow always throws you")
        finally:
            w.close()


class UniqueRulers(unittest.TestCase):
    """1.0.14: no two kings, queens or mayors share a name, and rulers in old saves are renamed on load."""
    def test_every_ruler_has_their_own_name(self):
        w = E.World()
        names = [w.ruler_for(t)[0].split(" ", 1)[1] for t in w.towns]
        self.assertEqual(len(names), len(set(names)), "two rulers share a name")

    def test_old_save_rulers_are_renamed(self):
        w = E.World()
        for a in w.actors:
            if a.role == "king": a.name = "High King Aldric"
        w._ensure_town_npcs()
        kings = [a.name for a in w.actors if a.role == "king"]
        self.assertEqual(len(kings), len(set(kings)))


class RaidSides(unittest.TestCase):
    """1.0.15: in a city raid you can only hit the other side - never your own town's leaders, guards or allies."""
    def setUp(self):
        self.w = new_world(level=90, faction="Alliance", cls="Warrior")
        self.own = next(t for t in self.w.towns if t.faction == "Alliance")
        self.enemy = next(t for t in self.w.towns if t.faction == "Horde")

    def tearDown(self):
        self.w.city_raid = None; self.w.close()

    def town_npcs(self, t, role):
        return [a for a in self.w.actors if a.kind == "npc" and a.role == role and self.w._town_for_actor(a) is t]

    def raid(self, t):
        w = self.w
        w.city_raid = {"town": t.id, "x": t.x, "y": t.y, "ids": [], "defs": [], "att": "Horde" if t.faction == "Alliance" else "Alliance", "fac": t.faction, "mine": 0}
        w.player["x"], w.player["y"] = t.x + 2, t.y

    def test_defender_cannot_hit_own_leaders_or_guards(self):
        w = self.w; self.raid(self.own); w._set_outlaw(True)      # even an outlaw defender is not fighting their own town
        for role in ("king", "questgiver"):
            for a in self.town_npcs(self.own, role):
                self.assertFalse(w.leader_attackable(a), a.name)
                a.x, a.y = w.player["x"] + 1, w.player["y"]
                self.assertEqual(w.attack_target(a.id), "Invalid enemy target.")
        for g in self.town_npcs(self.own, "guard"):
            self.assertFalse(w._guard_hostile(g), g.name)
        bad = [a for a in w._enemies() if a.kind == "npc" and w._town_for_actor(a) is self.own]
        self.assertEqual(bad, [])
        self.assertFalse(any(v > w.tick for v in getattr(w, "town_aggro", {}).values()))

    def test_defender_cannot_hit_allied_adventurers(self):
        w = self.w; self.raid(self.own)
        ally = next(a for a in w.actors if a.kind == "adventurer" and a.faction == "Alliance")
        ally.x, ally.y = w.player["x"] + 1, w.player["y"]; w.pfoes[ally.id] = w.tick
        self.assertFalse(w._hostile_adv(ally))
        self.assertEqual(w.attack_target(ally.id), "Invalid enemy target.")

    def test_attacker_can_hit_enemy_leaders(self):
        w = self.w; self.raid(self.enemy)
        for a in self.town_npcs(self.enemy, "king"):
            self.assertTrue(w.leader_attackable(a))

    def test_raiders_are_still_targets(self):
        w = self.w; self.raid(self.own); p = w.player
        r = w._soldier(9_900_001, "Horde Raider", "Horde", 30, p["x"] + 1, p["y"], 500, "raider", "Orc")
        w.actors.append(r); w.by_id[r.id] = r
        self.assertIn(r, w._enemies())
        self.assertNotEqual(w.attack_target(r.id), "Invalid enemy target.")


class ScrollStaysOnYourSide(unittest.TestCase):
    """1.0.23: a Scroll of Teleportation (T) never carries you into an enemy faction's town."""
    def test_scroll_skips_enemy_towns(self):
        for fac in ("Horde", "Alliance"):
            w = new_world(20, fac)
            for t in [t for t in w.towns if w.hostile_town(t, fac)]:
                w.player["x"], w.player["y"] = t.x, t.y
                w._inv_add("Scroll of Teleportation", 1)
                w.use_scroll()
                dest = min(w.towns, key=lambda u: (u.x - w.player["x"]) ** 2 + (u.y - w.player["y"]) ** 2)
                self.assertFalse(w.hostile_town(dest, fac), f"{fac} scrolled from {t.name} into enemy {dest.name}")


class TownsfolkInView(unittest.TestCase):
    """1.0.23: no building or name board stands over a quest giver, daily quest giver or ruler, and every river has bridges."""
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx as G
        cls.G = G; cls.w = new_world(20, "Horde"); cls.lay = G.WorldLayout(cls.w)

    def test_no_building_in_front_of_quest_npcs(self):
        for a in (a for a in self.w.actors if a.kind == "npc" and a.role in ("questgiver", "dailygiver", "king")):
            for b in self.lay.buildings:
                if b[2] == "fountain" or abs(b[0] - a.x) > 25 or abs(b[1] - a.y) > 25: continue
                s_ = 1.4 if b[2] == "tower" else 2.0; cx, cy = b[0] + s_ / 2, b[1] + s_ / 2
                u = (cx - cy) - (a.x - a.y); v = (cx + cy) - (a.x + a.y)
                self.assertFalse(abs(u) < s_ + .5 and .5 < v < 13, f"{b[2]} in front of {a.name}")

    def test_every_town_keeps_its_stations(self):
        for t in self.w.towns:
            for k in self.G.STATION_POSTS:
                self.assertTrue(any(b[2] == k and abs(b[0] + 1 - t.x) < 30 and abs(b[1] + 1 - t.y) < 30 for b in self.lay.buildings), (t.name, k))

    def test_every_river_has_a_bridge(self):
        mids = [r[len(r) // 2] for r, _hw in self.G._bridges(self.lay)[0]]
        for run, _k in self.lay.rivers[:self.lay._main_rivers]:
            if len(run) < 8: continue
            self.assertTrue(any((p[0] - m[0]) ** 2 + (p[1] - m[1]) ** 2 < 36 for p in run for m in mids), run[0])


class EntrancesBeatHerbs(unittest.TestCase):
    """1.0.23: F at any dungeon or raid door opens it - a herb, vein or carcass beside the door never takes the key press."""
    def test_every_entrance_opens(self):
        for _ in range(3):
            w = new_world(20, "Alliance")
            for d in w.dungeons:
                w.inst = None; w.open_ui = None
                w.player["x"], w.player["y"] = d.x, d.y + 1
                msg = w.interact_nearby()
                self.assertFalse(str(msg).startswith(("Gathered", "Mined", "Skinned")), (d.name, msg))
                if w.inst: w.leave_instance(silent=True)


class GuardsAreCityDefense(unittest.TestCase):
    """1.0.23: guards defend their city - they cannot be recruited, and any in an old save's party go back on duty."""
    def test_guards_cannot_join(self):
        w = new_world(30, "Horde")
        g = next(a for a in w.actors if a.kind == "npc" and a.role == "guard" and a.faction == "Horde")
        w.player["x"], w.player["y"] = g.x + 1, g.y
        for _ in range(20): self.assertNotIn("joins", w.party_invite(g.id))
        self.assertIsNone(w.person_info(g.id))
        w._pp_save([g.id]); g.state = "pparty"; g.party = -1
        w._pp_guards_checked = False; w.update()
        self.assertNotIn(g.id, w._pp_ids()); self.assertEqual(g.state, "guard")


# ======================================================================= 1.0.26: bigger towns, the Tavern, battle mount powers, raid outcomes
class TownLayout(unittest.TestCase):
    """No shop (with its name board) covers another building in any town; the screen boxes match the real sprites."""
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.gfx = gfx; cls.w = new_world(level=30); cls.lay = gfx.WorldLayout(cls.w)

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def test_no_shop_overlaps_anything(self):
        gfx = self.gfx; bad = []
        by_town = {}
        for bx, by, kind, style, var in self.lay.buildings:
            if kind == "fountain": continue
            t = min(self.w.towns, key=lambda t: (t.x - bx) ** 2 + (t.y - by) ** 2)
            by_town.setdefault(t.name, []).append((kind, gfx.screen_box(kind, bx, by, kind in gfx.STATION_KINDS)))
        for tn, items in by_town.items():
            for i, (ka, a) in enumerate(items):
                for kb, b in items[i + 1:]:
                    if ka not in gfx.STATION_KINDS and kb not in gfx.STATION_KINDS: continue
                    if gfx.box_overlap(a, b) > 900: bad.append((tn, ka, kb, int(gfx.box_overlap(a, b))))
        self.assertEqual(bad, [], "shops or their name boards overlap")

    def test_every_town_has_all_shops_and_a_tavern(self):
        for k in ("tavern", "petshop", "teleport", "general", "magic", "inn", "hut", "warhall", "stable", "bank"):
            self.assertEqual(len(self.lay.stations.get(k, [])), len(self.w.towns), k)

    def test_solid_boxes_match_the_sprites(self):
        import pygame
        gfx = self.gfx
        for k in list(gfx.STATION_KINDS) + ["house", "tower"]:
            with self.subTest(kind=k):
                spr, anc, bw, bd = gfx.building_sprite(k, "Horde", 0)
                rs = pygame.mask.from_surface(spr, 200).get_bounding_rects()
                u = rs[0].unionall(rs[1:])
                real = (anc[0] - u.left, anc[1] - u.top, u.right - anc[0], u.bottom - anc[1])
                for got, want in zip(gfx.SOLID_BOX[k], real):
                    self.assertLessEqual(want, got + 6, f"{k}: the sprite grew past its SOLID_BOX {gfx.SOLID_BOX[k]} vs {real}")

    def test_towns_fit_inside_their_zones(self):
        for t in self.w.towns:
            a = next(z for z in E.AREAS if z[0] == t.area)
            m = E.TOWN_BLOCK_R
            self.assertTrue(a[1] + m <= t.x <= a[1] + a[3] - m and a[2] + m <= t.y <= a[2] + a[4] - m, t.name)


class Tavern(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import gfx
        cls.w = w = new_world(level=40, faction="Horde", cls="Mage"); w.player["gold"] = 10 ** 6
        w.station_posts = gfx.WorldLayout(w).stations; w.place_town_npcs()
        cls.t = t = next(t for t in w.towns if t.faction == "Horde")
        tx, ty = min(w.station_posts["tavern"], key=lambda q: (q[0] - t.x) ** 2 + (q[1] - t.y) ** 2)
        w.player["x"], w.player["y"] = tx + 1, ty + 2

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def test_opens_from_the_building(self):
        w = self.w; w.interact_nearby(); self.assertEqual(w.open_ui, "tavern"); w.open_ui = None
        v = w.tavern_view(); self.assertEqual(len(v["drinks"]), 7); self.assertEqual(len(v["offers"]), 8)
        self.assertGreaterEqual(len(v["duelists"]), 3, "pit fighters are always there")

    def test_drinks_buff_once_per_kind(self):
        w = self.w; w.buffs.pop("might", None); g0 = w.player["gold"]
        self.assertIn("Firebrand Whisky", w.buy_drink("firebrand_whisky")); self.assertTrue(w._buff("might"))
        self.assertLess(w.player["gold"], g0)
        self.assertIn("already", w.buy_drink("firebrand_whisky"))

    def test_hire_renew_dismiss_and_expire(self):
        w = self.w
        for a in list(w.party_members()): w.party_dismiss(a.id)
        for _ in range(3): w.update(20)
        o = w.hire_offers()
        self.assertIn("joins your party", w.hire(o[0]["key"])); self.assertIn("joins your party", w.hire(o[2]["key"]))
        hs = w.hirelings_info(); self.assertEqual(len(hs), 2); self.assertEqual(len(w.party_members()), 2)
        self.assertIn("another hour", w.renew_hireling(hs[0]["id"]))
        w.dismiss_hireling(hs[1]["id"]); self.assertNotIn(hs[1]["id"], w.by_id)
        w._hst()[hs[0]["id"]]["until"] = w.tick + 1
        for _ in range(2): w.update(20)
        self.assertEqual(w.hirelings_info(), []); self.assertEqual(w.party_members(), [])

    def test_pit_fighter_duel_pays_and_cleans_up(self):
        w = self.w; w.duel = None; w.last_combat_tick = -999; g0 = w.player["gold"]
        w.tavern_duel("pit1", True); self.assertTrue(w.duel and w.duel.get("tavern"))
        aid = w.duel["id"]; a = w.by_id[aid]; wager = w.duel["wager"]; wins0 = w._tv()["wins"]
        for _ in range(14): w.player["hp"] = 10 ** 5; w.update(1)
        n = 0
        while w.duel and n < 300: w.player["hp"] = 10 ** 5; w._hit(a, a.maxhp // 6 + 1); w.update(1); n += 1
        self.assertIsNone(w.duel); self.assertEqual(w.player["gold"] - g0, wager); self.assertEqual(w._tv()["wins"], wins0 + 1)
        w.update(20); self.assertNotIn(aid, w.by_id, "the pit fighter goes back to the pit")


class BattleMountPowers(unittest.TestCase):
    def setUp(self):
        from liveworld_rpg import mounts as M
        self.M = M
        self.w = w = new_world(level=60, faction="Horde", cls="Mage")
        st = w._mst(); st["riding"] = 4; st["owned"] = list(M.BG_MOUNTS) + ["drake"]; st["bg_active"] = "bg_nightmare"; st["active"] = "drake"
        enter(w, "tdm12"); w.tick += 100; w.last_combat_tick = -999
        self.assertIn("Nightmare", w.mount())

    def tearDown(self):
        self.w.close()

    def test_no_battle_mount_flies(self):
        for k, m in self.M.BG_MOUNTS.items(): self.assertFalse(m["fly"], k)
        w = self.w; w.mounted = "drake"; w.update(1); self.assertIsNone(w.mounted, "a flying mount never stays up in a battleground")

    def test_stampede_and_cooldown(self):
        w = self.w; base = w.move_speed()
        self.assertIn("Stampede", w.mount_ability("sprint")); self.assertAlmostEqual(w.move_speed() / base, 4.0 / 3.1, places=2)
        self.assertIn("not ready", w.mount_ability("sprint"))

    def test_frost_breath_hits_without_dismounting(self):
        w = self.w; p = w.player
        foes = [a for a in w.actors if a.kind == "imob" and a.hp > 0]
        f = foes[0]; p["x"], p["y"] = f.x + 6, f.y; hp0 = sum(a.hp for a in foes)
        for _ in range(17): p["hp"] = w._effective_maxhp(); w.update(1)
        self.assertLess(sum(a.hp for a in foes), hp0); self.assertEqual(w.mounted, "bg_nightmare")

    def test_shadow_veil_hides_you(self):
        w = self.w; inst = w.inst; inst.protect_until = 0
        self.assertIn("Shadow Veil", w.mount_ability("veil")); self.assertTrue(w._buff("stealth"))
        hits = []; inst._hit_player = lambda a: hits.append(a.id)
        reds = [a for a in w.actors if a.kind == "imob" and a.hp > 0]; p = w.player
        for _ in range(30):
            r = min(reds, key=lambda a: (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2); p["x"], p["y"] = r.x + 4, r.y
            p["hp"] = w._effective_maxhp(); w.update(1)
        self.assertLessEqual(len(hits), 3)


class RaidOutcome(unittest.TestCase):
    """1.0.26: only the ruler's fall takes a city - time running out or broken gates do not."""
    def setUp(self):
        self.w = w = new_world(level=80, faction="Horde")
        self.t = next(t for t in w.towns if t.faction == "Horde" and w.town_tier(t) == "city")
        w.raid_call = None; w.city_raid = None; self.assertTrue(w._raid_start(self.t)); self.r = w.city_raid
        w.player["x"], w.player["y"] = self.t.x + 2, self.t.y + 2

    def tearDown(self):
        self.w.city_raid = None; self.w.close()

    def test_timeout_with_the_ruler_alive_holds(self):
        w = self.w; w._raid_tick(); self.r["end"] = w.tick; w._raid_tick()
        self.assertIsNone(w.city_raid); self.assertFalse(w.town_protected(self.t), "the city did not fall")

    def test_broken_gates_do_not_take_the_city(self):
        w = self.w; w._raid_tick(); self.r["hp"] = 0; w._raid_tick()
        self.assertIs(w.city_raid, self.r); self.assertTrue(self.r.get("breach"))

    def test_next_wave_comes_on_time_and_raiders_are_on_the_map(self):
        w = self.w; w.tick = self.r["next"]; w._raid_tick(); self.assertEqual(self.r["wave"], 1)
        keep = self.r["ids"][0]
        for i in self.r["ids"][1:]: w.by_id[i].hp = 0
        w._raid_tick(); self.assertEqual(self.r["wave"], 1)
        w.tick = self.r["wave_t"] + w.RAID_TIME // 4; w._raid_tick()
        self.assertEqual(self.r["wave"], 2, "a straggler no longer holds back the next wave"); self.assertIn(keep, self.r["ids"])
        info = w.raid_info(); self.assertEqual(len(info["foes"]), len([i for i in self.r["ids"] if i in w.by_id])); self.assertIsNotNone(info["near"])


# ======================================================================= 1.0.29: pets
def pet_world(level=40, faction="Alliance", cls="Warrior", gold=10 ** 6):
    """A world with the hero standing at the Pet Store of the nearest town of their side."""
    from liveworld_rpg import gfx
    w = new_world(level=level, faction=faction, cls=cls); w.player["gold"] = gold
    w.station_posts = gfx.WorldLayout(w).stations; w.place_town_npcs()
    t = next(t for t in w.towns if t.faction == faction)
    tx, ty = min(w.station_posts["petshop"], key=lambda q: (q[0] - t.x) ** 2 + (q[1] - t.y) ** 2)
    w.player["x"], w.player["y"] = tx + 1, ty + 2
    return w


def clear_monsters(w, x, y, r=45):
    """Send every monster near (x, y) far away, so a test is not interrupted by a fight."""
    for a in w.actors:
        if a.kind == "monster" and (a.x - x) ** 2 + (a.y - y) ** 2 < r * r: a.x, a.y = 3.0, 3.0; a.target = -1


def make_foe(w, dx=2.5, hp=10 ** 5):
    """A monster that hunts the hero from dx tiles away."""
    p = w.player
    m = next(a for a in w.actors if a.kind == "monster" and a.hp > 0 and a.faction != p["faction"] and not a.name.startswith("Elite "))
    m.x, m.y = p["x"] + dx, p["y"]; m.hp = m.maxhp = hp; m.target = -2; m.state = "chase"
    return m


class Pets(unittest.TestCase):
    """1.0.29: the Pet Store, ten pets, stance, abilities, levels, saves, instances, battlegrounds and NPC pets."""
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import pets as P
        cls.P = P; cls.w = pet_world(40); cls.spot = (cls.w.player["x"], cls.w.player["y"])

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def setUp(self):
        w = self.w
        if w.inst: w.leave_instance(silent=True)
        w.player["x"], w.player["y"] = self.spot
        w._pets()["owned"].clear(); w._pets()["active"] = ""; w._pet_rt = None; w.player["hp"] = w._effective_maxhp(); w.player["level"] = 40
        w.player["gold"] = 10 ** 6; w.buffs.clear(); w.mstatus.clear()

    def own(self, key, stance="attack", level=24, active=True):
        w = self.w; w._pets()["owned"][key] = {"name": "Tester", "level": level, "xp": 0, "stance": stance}
        if active: w._pets()["active"] = key
        w._pet_rt = None

    # ---------------------------------------------------------------- the ten
    def test_ten_pets_with_one_or_two_abilities(self):
        P = self.P
        self.assertEqual(len(P.SPECIES), 10); self.assertEqual(len(set(P.SPECIES_ORDER)), 10)
        self.assertEqual(len({v["name"] for v in P.SPECIES.values()}), 10)
        for k, sp in P.SPECIES.items():
            with self.subTest(pet=k):
                self.assertIn(len(sp["abil"]), (1, 2))
                for a in sp["abil"]:
                    self.assertIn(a, P.ABILITIES)
                    for rk in range(1, 11): self.assertTrue(P.ability_text(a, rk))
        roles = {v["role"] for v in P.SPECIES.values()}
        for need in ("Fighter", "Healer", "Tank", "Gatherer"): self.assertIn(need, roles)
        self.assertTrue(any(v["fly"] for v in P.SPECIES.values()), "a flying pet")
        pd = P.SPECIES["pseudo_dragon"]
        self.assertEqual(set(pd["traits"]), {"keen_senses", "darkvision", "telepathy", "camouflage"})
        self.assertIn("poison_sting", pd["abil"]); self.assertIn("magic_resistance", pd["abil"])

    def test_every_pet_is_drawn(self):
        from liveworld_rpg import petgfx
        for k in self.P.SPECIES_ORDER:
            for fr in (-1, 0, 1, 2, 3):
                for face in (1, -1):
                    spr, anc = petgfx.pet_sprite(k, fr, face, 1.0)
                    self.assertGreater(spr.get_bounding_rect().w, 30, k); self.assertTrue(0 <= anc[0] <= spr.get_width() and 0 <= anc[1] <= spr.get_height())
        spr, _ = petgfx.pet_sprite("pseudo_dragon", -1, 1, 1.0, True); self.assertGreater(spr.get_bounding_rect().w, 30)

    # ---------------------------------------------------------------- the store
    def test_store_opens_from_the_building_and_sells_pets(self):
        w = self.w; w.open_ui = None; w.interact_nearby(); self.assertEqual(w.open_ui, "petshop"); w.open_ui = None
        v = w.pet_store_view(); self.assertEqual(len(v["pets"]), 10)
        g0 = w.player["gold"]; price = w.pet_price("wolf_pup")
        self.assertIn("is yours", w.buy_pet("wolf_pup"))
        self.assertEqual(g0 - w.player["gold"], price)
        rec = w._pets()["owned"]["wolf_pup"]; self.assertEqual(rec["level"], 24); self.assertEqual(w._pets()["active"], "wolf_pup", "the first pet comes along at once")
        self.assertIn("already", w.buy_pet("wolf_pup"))
        self.assertIn("is yours", w.buy_pet("delver_badger")); self.assertEqual(w._pets()["active"], "wolf_pup", "a second pet waits until you call it")
        self.assertIn("comes to your side", w.call_pet("delver_badger")); self.assertEqual(w._pets()["active"], "delver_badger")
        self.assertIn("rest", w.dismiss_pet()); self.assertEqual(w._pets()["active"], "")

    def test_store_checks_level_gold_and_place(self):
        w = self.w
        w.player["level"] = 5; self.assertIn("level 20", w.buy_pet("pseudo_dragon")); self.assertNotIn("pseudo_dragon", w._pets()["owned"])
        w.player["level"] = 40; w.player["gold"] = 5; self.assertIn("costs", w.buy_pet("gryphon_hatchling"))
        w.player["gold"] = 10 ** 6; px, py = w.player["x"], w.player["y"]; w.player["x"] += 60
        self.assertIn("Pet Store", w.buy_pet("wolf_pup")); w.player["x"], w.player["y"] = px, py
        self.assertIn("never heard", w.buy_pet("unicorn"))

    def test_prices_grow_with_level(self):
        w = self.w; w.player["level"] = 20; a = w.pet_price("ember_fox"); w.player["level"] = 60; b = w.pet_price("ember_fox")
        self.assertGreater(b, a)

    # ---------------------------------------------------------------- not a party member
    def test_pets_take_no_party_place(self):
        from liveworld_rpg.partyup import PARTY_MAX
        w = self.w; self.own("wolf_pup"); w.update(2)
        self.assertEqual(w.party_members(), []); self.assertEqual(w.party_snapshot(), []); self.assertEqual(w._pp_ids(), [])
        advs = [a for a in w.actors if a.kind == "adventurer" and a.faction == w.player["faction"]][:PARTY_MAX]
        w._pp_save([a.id for a in advs]); w.update(2)
        self.assertEqual(len(w.party_members()), PARTY_MAX, "a full party of companions and the pet besides")
        self.assertIn("full", w.party_invite(next(a.id for a in w.actors if a.kind == "adventurer" and a.id not in w._pp_ids())))
        self.assertEqual(len(w.party_in_instance()), PARTY_MAX); self.assertIsNotNone(w.pet_snapshot()["pet"])
        w._pp_save([])

    def test_group_sizes_do_not_change_with_a_pet(self):
        w = self.w; d = next(x for x in w.dungeons if x.kind == "raid"); w.player["level"] = max(40, d.level)
        sizes = []
        for with_pet in (False, True):
            self.setUp(); w.player["level"] = max(40, d.level)
            if with_pet: self.own("cave_bear_cub")
            w.player["x"], w.player["y"] = d.x, d.y + 1; w._enter_dungeon(d, False, (d.x, d.y + 3))
            inst = w.inst; w.update(3)
            sizes.append((len(inst.allies), inst.snapshot()["size"], [a["name"] for a in inst.snapshot()["party"]]))
            if with_pet: self.assertTrue(w.pet_snapshot()["pet"] and "Tester" not in sizes[-1][2], "the pet is not in the raid group")
            w.leave_instance(silent=True)
        self.assertEqual(sizes[0][:2], sizes[1][:2])
        a = enter(self.w, "tdm12"); self.assertEqual(len(a.allies), 11); w.leave_instance(silent=True)

    # ---------------------------------------------------------------- stance
    def test_stance_control(self):
        w = self.w
        self.assertIn("no pet", w.set_pet_stance("defend")); self.assertIn("no pet", w.cycle_pet_stance())
        self.own("wolf_pup"); w.update(1)
        self.assertEqual(w.pet_snapshot()["pet"]["stance"], "attack")
        self.assertIn("Defend", w.set_pet_stance("defend")); self.assertEqual(w.pet_snapshot()["pet"]["stance"], "defend")
        self.assertIn("Gather", w.cycle_pet_stance()); self.assertIn("Attack", w.cycle_pet_stance()); self.assertEqual(w.pet_snapshot()["pet"]["stance"], "attack")
        self.assertIn("Attack, Defend and Gather", w.set_pet_stance("flee"))
        w.set_pet_stance("gather"); self.assertEqual(w._pets()["owned"]["wolf_pup"]["stance"], "gather")

    def test_attack_stance_fights_defend_guards_gather_does_not_fight(self):
        w = self.w
        for stance, fights in (("attack", True), ("defend", True), ("gather", False)):
            with self.subTest(stance=stance):
                self.setUp(); self.own("wolf_pup", stance); clear_monsters(w, w.player["x"], w.player["y"]); w.update(2)
                m = make_foe(w, 2.5 if stance != "attack" else 6.0); hp0 = m.hp
                for _ in range(40): w.player["hp"] = w._effective_maxhp(); m.target = -2; m.x, m.y = w.player["x"] + 2.0, w.player["y"]; w.update(1)
                self.assertEqual(m.hp < hp0, fights); m.hp = m.maxhp = 100; m.x, m.y = 3.0, 3.0

    def test_defend_shares_the_blows_and_a_knocked_out_pet_comes_back(self):
        w = self.w; P = self.P
        self.own("cave_bear_cub", "defend"); w.update(2); rt = w._pet_rt; hp0 = rt.hp
        left = w._pet_absorb(1000); self.assertLess(left, 1000); self.assertLess(rt.hp, hp0)
        w.set_pet_stance("gather"); self.assertEqual(w._pet_absorb(1000), 1000, "a gathering pet does not guard")
        w.set_pet_stance("attack"); self.assertLess(w._pet_absorb(1000), 1000, "Thick Hide works in any fighting stance")
        w.set_pet_stance("defend"); w._pet_absorb(10 ** 7); self.assertTrue(w._pet_rt.down_until); self.assertGreater(w.pet_snapshot()["pet"]["down"], 0)
        self.assertEqual(w._pet_absorb(1000), 1000, "a knocked-out pet guards nobody")
        for _ in range(P.KO_TICKS + 2): w.update(1)
        self.assertEqual(w._pet_rt.down_until, 0); self.assertGreater(w._pet_rt.hp, 0); self.assertEqual(w._pets()["active"], "cave_bear_cub", "never lost")

    def test_killed_pet_respawns_at_your_side_with_full_health(self):
        w = self.w; P = self.P; p = w.player; gold = p["gold"]
        self.own("granite_tortoise", "defend", 33); w._pets()["owned"]["granite_tortoise"]["xp"] = 123; w.update(2); w._pet_absorb(10 ** 7)
        self.assertTrue(w._pet_rt.down_until); p["x"] += 25; clear_monsters(w, p["x"], p["y"], 60)
        for _ in range(P.KO_TICKS + 2): w.update(1)
        s = w.pet_snapshot()["pet"]; r = w._pets()["owned"]["granite_tortoise"]
        self.assertEqual((s["hp"], s["down"]), (s["maxhp"], 0)); self.assertLess(math.hypot(s["x"] - p["x"], s["y"] - p["y"]), 4, "back at your side")
        self.assertEqual((r["level"], r["xp"], r["stance"]), (33, 123, "defend")); self.assertEqual(p["gold"], gold, "no cost")
        # in a dungeon and a battleground, and at once on leaving
        d = next(x for x in w.dungeons if x.kind == "raid"); p["level"] = max(40, d.level); p["x"], p["y"] = d.x, d.y + 1
        w._enter_dungeon(d, False, (d.x, d.y + 3)); w.update(2); w._pet_absorb(10 ** 7); self.assertTrue(w._pet_rt.down_until)
        for _ in range(P.KO_TICKS + 2): w.update(1)
        s = w.pet_snapshot()["pet"]; self.assertEqual((s["hp"], s["down"]), (s["maxhp"], 0)); self.assertLess(math.hypot(s["x"] - p["x"], s["y"] - p["y"]), 5)
        w._pet_absorb(10 ** 7); w.leave_instance(silent=True); w.update(2)
        self.assertEqual(w.pet_snapshot()["pet"]["down"], 0, "out of the dungeon it is back at once")
        enter(w, "tdm12"); w.update(2); w._pet_absorb(10 ** 7)
        for _ in range(P.KO_TICKS + 2): w.update(1)
        self.assertEqual(w.pet_snapshot()["pet"]["down"], 0); w.leave_instance(silent=True)
        # a pet knocked out when the game is saved comes back after a reload
        w._pet_absorb(10 ** 7); w._pets_save(); self.assertEqual(json.loads(w._meta("pets"))["owned"]["granite_tortoise"]["level"], 33)

    def test_npc_pets_cannot_die_and_follow_their_owner_back(self):
        w = self.w; a = next(a for a in w.actors if a.kind == "adventurer" and w.npc_pet(a)); pt = w.npc_pet(a); w.player["x"], w.player["y"] = a.x, a.y
        hp = a.hp; a.hp = 0; d = next(x for x in w.snapshot()["actors"] if x["id"] == a.id); self.assertNotIn("pet", d, "gone with a fallen owner")
        a.hp = hp or 50; d = next(x for x in w.snapshot()["actors"] if x["id"] == a.id); self.assertEqual(d["pet"], pt["key"], "back with the owner"); self.assertEqual(w.npc_pet(a), pt, "same level and kind")

    def test_player_damage_path_uses_the_pet(self):
        w = self.w; self.own("cave_bear_cub", "defend"); w.update(2); hp0 = w._pet_rt.hp
        m = make_foe(w, 1.0); w.player["hp"] = w._effective_maxhp(); w.damage_player(500, m, m.id)
        self.assertLess(w._pet_rt.hp, hp0); m.hp = 100; m.x, m.y = 3.0, 3.0

    # ---------------------------------------------------------------- follows
    def test_pet_follows_and_catches_up(self):
        w = self.w; self.own("wolf_pup"); clear_monsters(w, w.player["x"], w.player["y"], 60); w.update(2)
        w.player["x"] += 15
        for _ in range(25): w.update(1)
        s = w.pet_snapshot()["pet"]; self.assertLess(math.hypot(s["x"] - w.player["x"], s["y"] - w.player["y"]), 4)
        w.player["x"] += 80; w.update(1)
        s = w.pet_snapshot()["pet"]; self.assertLess(math.hypot(s["x"] - w.player["x"], s["y"] - w.player["y"]), 4, "a long way off it is simply beside you again")

    # ---------------------------------------------------------------- gathering
    def _herb_spot(self, w):
        for bx in range(4, 60):
            for by in range(4, 60):
                v = w._herb_at(bx, by)
                if v: return v
        self.fail("no herb in the world")

    def test_gather_stance_collects_herbs_ore_and_carcass_materials(self):
        w = self.w; p = w.player; self.own("delver_badger", "gather", 30)
        h = self._herb_spot(w); p["x"], p["y"] = h["x"] + 3, h["y"]; clear_monsters(w, p["x"], p["y"], 80)
        self.assertTrue(w.herbs_near(15)); herbs0 = w.herb_count(); xp0 = w._pets()["owned"]["delver_badger"]["xp"]; lvl0 = w._pets()["owned"]["delver_badger"]["level"]
        for _ in range(200): w.last_combat_tick = -999; w.update(1)
        self.assertGreater(w.herb_count(), herbs0, "the pet brought herbs"); rec = w._pets()["owned"]["delver_badger"]
        self.assertTrue(rec["xp"] > xp0 or rec["level"] > lvl0, "gathering earns the pet experience")
        # ore
        v = next((w._vein_at(bx, by) for bx in range(2, 70) for by in range(2, 70) if w._vein_at(bx, by)), None); self.assertIsNotNone(v)
        p["x"], p["y"] = v["x"] + 3, v["y"]; clear_monsters(w, p["x"], p["y"], 80)
        ore0 = w._inv_qty("Mat:Iron Ore")
        for _ in range(900):
            w.last_combat_tick = -999; w.update(1)
            if w._inv_qty("Mat:Iron Ore") > ore0: break          # (it may fetch a herb or two nearby first)
        self.assertGreater(w._inv_qty("Mat:Iron Ore"), ore0, "the pet mined the vein")
        # a carcass
        w.add_carcass("Wolf", p["x"] + 4, p["y"], 12, False); lea0 = w._inv_qty("Mat:Leather Scrap")
        for _ in range(600):
            w.last_combat_tick = -999; w.update(1)
            if w._inv_qty("Mat:Leather Scrap") > lea0: break
        self.assertGreater(w._inv_qty("Mat:Leather Scrap"), lea0, "the pet skinned it")

    def test_gather_pet_goes_back_to_you_in_a_fight_and_other_stances_do_not_gather(self):
        w = self.w; p = w.player; self.own("delver_badger", "attack", 30)
        h = self._herb_spot(w); p["x"], p["y"] = h["x"] + 3, h["y"]; clear_monsters(w, p["x"], p["y"], 80); herbs0 = w.herb_count()
        for _ in range(120): w.last_combat_tick = -999; w.update(1)
        self.assertEqual(w.herb_count(), herbs0, "an Attack-stance pet does not gather")
        w.set_pet_stance("gather"); w.update(2); w.last_combat_tick = w.tick; w._pet_rt.node = None
        w.update(1); self.assertIsNone(w._pet_rt.node, "in a fight it stays by you")

    # ---------------------------------------------------------------- abilities
    def test_each_pet_works_in_a_fight(self):
        w = self.w; p = w.player
        for k in self.P.SPECIES_ORDER:
            with self.subTest(pet=k):
                self.setUp(); self.own(k, "attack", 40); clear_monsters(w, p["x"], p["y"]); w.update(2)
                m = make_foe(w, 3.0); hp0 = m.hp
                for _ in range(80):
                    p["hp"] = w._effective_maxhp() * (.4 if k == "glimmer_sprite" else 1.0) if _ == 0 else p["hp"]
                    m.target = -2; m.x, m.y = p["x"] + 2.5, p["y"]; w.last_combat_tick = w.tick; w.update(1)
                self.assertLess(m.hp, hp0, f"{k} damaged the foe")
                if k == "glimmer_sprite": self.assertGreater(p["hp"], w._effective_maxhp() * .4, "the sprite healed the hero")
                m.hp = m.maxhp = 100; m.x, m.y = 3.0, 3.0; m.target = -1

    def test_pseudo_dragon_poison_senses_and_camouflage(self):
        w = self.w; p = w.player; P = self.P
        self.own("pseudo_dragon", "attack", 40); clear_monsters(w, p["x"], p["y"], 60); w.update(25)
        self.assertTrue(w.pet_snapshot()["pet"]["camo"], "at rest it blends into the ground")
        rt = w._pet_rt; m = make_foe(w, 1.5); rt.cd.clear()
        w._pet_abilities(rt, "pseudo_dragon", w._pets()["owned"]["pseudo_dragon"], m, [m], 4, 1.0)
        self.assertIn(m.id, rt.dots); self.assertEqual(w.mstatus[m.id]["dot"]["name"], "Poisoned"); hp0 = m.hp
        for _ in range(8): w.player["hp"] = w._effective_maxhp(); m.target = -2; w.update(1)
        self.assertLess(m.hp, hp0 - 1, "the poison works over time")
        # Magic Resistance: spells and boss mechanics hurt less, plain blows do not
        self.setUp(); self.own("pseudo_dragon", "attack", 40); w.update(2)
        self.assertEqual(w._pet_absorb(100, False), 100); self.assertLess(w._pet_absorb(100, True), 100)
        # Limited Telepathy: it warns of an Elite nearby
        el = next((a for a in w.actors if a.kind == "monster" and a.name.startswith("Elite ") and a.faction != p["faction"]), None)
        if el is not None:
            clear_monsters(w, p["x"], p["y"], 60); el.x, el.y = p["x"] + 12, p["y"]; el.hp = el.maxhp = 500; el.target = -1; el.state = "wander"
            seen = []
            for _ in range(90): w.update(1); seen += [e for e in w.events[-3:] if "whispers" in str(e)]
            self.assertTrue(seen, "the pseudo-dragon whispers a warning")
        m.hp = 100; m.x, m.y = 3.0, 3.0

    def test_poison_can_put_a_foe_to_sleep_only_at_high_rank(self):
        w = self.w; p = w.player; self.own("pseudo_dragon", "attack", 100); clear_monsters(w, p["x"], p["y"]); w.update(2)
        rt = w._pet_rt; m = make_foe(w, 1.5); asleep = 0
        for i in range(60):
            rt.cd.clear(); w.mstatus.pop(m.id, None); w._pet_abilities(rt, "pseudo_dragon", w._pets()["owned"]["pseudo_dragon"], m, [m], 10, 1.0)
            asleep += bool(w.mstatus.get(m.id, {}).get("stun", 0) > w.tick)
        self.assertGreater(asleep, 3)
        w.mstatus.pop(m.id, None); rt.cd.clear(); rt.dots.clear(); m.hp = 100; m.x, m.y = 3.0, 3.0

    def test_passive_abilities_give_buffs(self):
        w = self.w
        for k, buff in (("skyhawk", "crit"), ("ember_fox", "dodge"), ("glimmer_sprite", "mreg"), ("gryphon_hatchling", "haste")):
            with self.subTest(pet=k):
                self.setUp(); self.own(k); w.tick += 16 - w.tick % 16; w.update(1); w.tick += 16 - w.tick % 16 - 1; w.update(1)
                self.assertTrue(w._buff(buff), f"{k} -> {buff}")

    def test_a_drink_keeps_its_place_over_a_pet_buff(self):
        w = self.w; w.buffs["crit"] = {"name": "Rogue's Cider", "kind": "crit", "until": w.tick + 999, "value": .05}
        self.assertFalse(w._pet_buff("crit", "Keen Eyes", .04, 12)); self.assertEqual(w.buffs["crit"]["name"], "Rogue's Cider")

    # ---------------------------------------------------------------- levels
    def test_pets_level_up_and_grow(self):
        w = self.w; P = self.P; self.own("wolf_pup", "attack", 24); rec = w._pets()["owned"]["wolf_pup"]
        self.assertTrue(w.pet_gain_xp(P.xp_need(24))); self.assertEqual(rec["level"], 25)
        self.assertTrue(any("reaches level 25" in str(e) for e in w.events[-4:]))
        self.assertGreater(P.pet_stats("wolf_pup", 50)["maxhp"], P.pet_stats("wolf_pup", 10)["maxhp"]); self.assertGreater(P.pet_stats("wolf_pup", 50)["dmg"], P.pet_stats("wolf_pup", 10)["dmg"])
        self.assertEqual((P.pet_rank(1), P.pet_rank(10), P.pet_rank(11), P.pet_rank(100)), (1, 1, 2, 10))
        self.assertNotEqual(P.ability_text("pounce", 1), P.ability_text("pounce", 10))
        w.player["level"] = 30; rec["level"] = 29; rec["xp"] = 0; w.pet_gain_xp(10 ** 6)
        self.assertEqual(rec["level"], 30, "a pet never passes you"); self.assertEqual(rec["xp"], 0)
        self.assertFalse(w.pet_gain_xp(500))

    def test_kills_and_catch_up_give_experience(self):
        w = self.w; self.own("wolf_pup", "attack", 20); rec = w._pets()["owned"]["wolf_pup"]
        w.pet_share_xp(20); a = rec["xp"]; self.assertGreater(a, 0)
        rec["xp"] = 0; w.player["level"] = 40; w.pet_share_xp(20); behind = rec["xp"]
        rec["xp"] = 0; rec["level"] = 39; w.pet_share_xp(20); self.assertGreater(behind, rec["xp"], "a pet behind you learns faster")
        rec["xp"] = 0; rec["level"] = 20; m = make_foe(w, 1.0, 5); m.hp = 1; clear_monsters(w, w.player["x"] + 80, w.player["y"] + 80, 1)
        m.x, m.y = w.player["x"] + 1, w.player["y"]; w._hit(m, 50)
        self.assertGreater(rec["xp"] + (rec["level"] - 20) * 10 ** 5, 0, "a kill of yours teaches the pet")

    def test_level_up_during_a_fight_heals_and_saves(self):
        w = self.w; self.own("wolf_pup", "attack", 24); w.update(2); w._pet_rt.hp = 5
        w.pet_gain_xp(self.P.xp_need(24)); self.assertEqual(w._pet_rt.hp, self.P.pet_stats("wolf_pup", 25)["maxhp"], "a new level restores its health")
        w._pets_save(); self.assertEqual(json.loads(w._meta("pets"))["owned"]["wolf_pup"]["level"], 25)

    # ---------------------------------------------------------------- saves
    def test_save_and_reload_keeps_pets(self):
        w = pet_world(50); db = (E.DATA, E.DB)
        self.assertIn("is yours", w.buy_pet("shadow_panther")); self.assertIn("is yours", w.buy_pet("skyhawk"))
        w.call_pet("skyhawk"); w.set_pet_stance("gather"); rec = w._pets()["owned"]["skyhawk"]; rec["level"] = 31; rec["xp"] = 77; w._pets()["dirty"] = True
        name = rec["name"]; w.close()
        E.DATA, E.DB = db; w2 = E.World()
        try:
            st = w2._pets(); self.assertEqual(sorted(st["owned"]), ["shadow_panther", "skyhawk"]); self.assertEqual(st["active"], "skyhawk")
            r2 = st["owned"]["skyhawk"]; self.assertEqual((r2["level"], r2["xp"], r2["stance"], r2["name"]), (31, 77, "gather", name))
            w2.update(2); s = w2.pet_snapshot()["pet"]; self.assertEqual((s["key"], s["level"], s["stance"]), ("skyhawk", 31, "gather"))
        finally:
            w2.close()

    def test_old_and_damaged_saves_have_safe_defaults(self):
        w = new_world(level=10)
        try:
            self.assertIsNone(w._meta("pets")); self.assertEqual(w._pets()["owned"], {}); self.assertEqual(w.pet_snapshot(), {"pet": None}); w.update(3)
            self.assertEqual(w.pets_view()["pets"], []); self.assertIn("no pet", w.cycle_pet_stance())
            for junk in ("[1,2]", "not json", json.dumps({"owned": [1], "active": 3}),
                         json.dumps({"owned": {"nope": {}, "wolf_pup": {"level": "x", "xp": -5, "stance": "zzz"}, "ember_fox": 5}, "active": "nope"})):
                w._pet_st = None; w._setmeta("pets", junk); st = w._pets(); w.update(2)
                self.assertEqual(st["active"], ""); self.assertTrue(set(st["owned"]) <= {"wolf_pup"})
            w._pet_st = None; w._setmeta("pets", json.dumps({"owned": {"wolf_pup": {"level": 9999, "xp": "?", "stance": "zzz"}}, "active": "wolf_pup"}))
            r = w._pets()["owned"]["wolf_pup"]; self.assertEqual((r["level"], r["xp"], r["stance"]), (self.P.PET_MAX, 0, "attack")); w.update(2); self.assertEqual(w.pet_snapshot()["pet"]["key"], "wolf_pup")
        finally:
            w.close()

    # ---------------------------------------------------------------- dungeons, raids and battlegrounds
    def test_pet_goes_into_dungeons_and_raids_and_fights(self):
        w = self.w; p = w.player
        for kind in ("dungeon", "raid"):
            with self.subTest(kind=kind):
                self.setUp(); self.own("wolf_pup", "attack", 40)
                d = next(x for x in w.dungeons if x.kind == kind); p["level"] = max(40, d.level); p["x"], p["y"] = d.x, d.y + 1
                w._enter_dungeon(d, False, (d.x, d.y + 3)); inst = w.inst; w.update(3)
                s = w.pet_snapshot()["pet"]; self.assertIsNotNone(s); self.assertLess(math.hypot(s["x"] - p["x"], s["y"] - p["y"]), 5, "it came in with you")
                r = next(r for r in inst.rooms if r["type"] == "trash"); inst._pull(r); m = inst.actors[r["mobs"][0]]
                p["x"], p["y"] = m.x - 2.5, m.y; hits = []; orig = w._pet_hit
                w._pet_hit = lambda foe, dmg, rt, ability=False, _o=orig: (hits.append(foe.id), _o(foe, dmg, rt, ability))[1]
                try:
                    for _ in range(40):
                        p["hp"] = w._effective_maxhp(); m.hp = max(m.hp, 50); w.update(1)
                finally:
                    w._pet_hit = orig
                self.assertTrue(hits, f"the pet fought in the {kind}")
                w.leave_instance(silent=True); w.update(2)
                s = w.pet_snapshot()["pet"]; self.assertLess(math.hypot(s["x"] - p["x"], s["y"] - p["y"]), 5, "and came out with you")

    def test_pet_fights_in_a_battleground_and_kills_count(self):
        w = self.w; p = w.player; self.own("shadow_panther", "attack", 30); inst = enter(w, "tdm12"); w.update(3)
        s = w.pet_snapshot()["pet"]; self.assertIsNotNone(s)
        f = inst.reds[0]; p["x"], p["y"] = f.x + 2.5, f.y; hits = []; orig = w._pet_hit
        w._pet_hit = lambda foe, dmg, rt, ability=False, _o=orig: (hits.append(foe.id), _o(foe, dmg, rt, ability))[1]
        try:
            for _ in range(60): p["hp"] = w._effective_maxhp(); inst.protect_until = w.tick + 10; w.update(1)
        finally:
            w._pet_hit = orig
        self.assertTrue(hits, "the pet attacked the enemy team")
        foe = next(x for x in inst.reds if not x.dead); foe.hp = 1; xp0 = w._pets()["owned"]["shadow_panther"]["xp"]; sc0 = inst.score["blue"]
        rt = w._pet_rt; w._pet_hit(foe, 50, rt)
        self.assertTrue(foe.dead); self.assertEqual(inst.score["blue"], sc0 + 1, "the pet's kill scores for your team")
        self.assertGreater(w._pets()["owned"]["shadow_panther"]["xp"], xp0)
        w.leave_instance(silent=True)

    # ---------------------------------------------------------------- the people
    def test_npc_pets_on_both_sides(self):
        w = self.w; seen = {}
        for f in ("Alliance", "Horde"):
            advs = [a for a in w.actors if a.kind == "adventurer" and a.faction == f]
            pets = [(a, w.npc_pet(a)) for a in advs]
            n = sum(1 for _, p_ in pets if p_)
            self.assertGreater(n, 0, f"{f} adventurers keep pets"); self.assertLess(n, len(advs), "not all of them do")
            seen[f] = n
            for a, p_ in pets:
                if p_: self.assertIn(p_["key"], self.P.SPECIES); self.assertGreaterEqual(a.level, self.P.SPECIES[p_["key"]]["need"]); self.assertEqual(w.npc_pet(a), p_, "the same pet every time")
                elif a.level < 3: self.assertIsNone(p_)
        a, p_ = next((a, p_) for a in w.actors if a.kind == "adventurer" for p_ in [w.npc_pet(a)] if p_)
        w.player["x"], w.player["y"] = a.x, a.y; snap = w.snapshot(); d = next(x for x in snap["actors"] if x["id"] == a.id)
        self.assertEqual((d["pet"], d["pet_lvl"]), (p_["key"], p_["level"])); self.assertEqual(w.person_info(a.id)["pet"], p_)
        self.assertEqual(w.party_members(), [], "an NPC's pet is not in your party")
        plain = next(m for m in w.actors if m.kind == "monster"); self.assertIsNone(w.npc_pet(plain))

    def test_npc_pet_adds_to_their_damage(self):
        w = self.w; a = next(a for a in w.actors if a.kind == "adventurer" and w.npc_pet(a) and a.level >= 30); pt = w.npc_pet(a); b = next(x for x in w.actors if x.kind == "monster")
        w.rng.seed(5); with_pet = sum(w._damage(a, b) for _ in range(400))
        real = w.npc_pet; w.npc_pet = lambda x: None
        try: w.rng.seed(5); without = sum(w._damage(a, b) for _ in range(400))
        finally: w.npc_pet = real
        self.assertAlmostEqual((with_pet - without) / 400, pt["level"] * .3, delta=.6, msg="the pet adds about 0.3 damage per pet level, per blow")

    def test_battleground_bots_can_have_pets(self):
        w = self.w; inst = enter(w, "tdm12"); w.update(2); snap = w.snapshot()
        have = {d["id"]: d for d in snap["actors"] if d.get("pet")}
        self.assertTrue(have, "some of the bots in the battleground have pets"); w.leave_instance(silent=True)

    # ---------------------------------------------------------------- the in-game guide
    def test_guide_describes_pets(self):
        from liveworld_rpg import guide
        pages = dict(guide.PAGES); self.assertIn("Pets", pages); txt = " ".join(pages["Pets"])
        for sp in self.P.SPECIES.values(): self.assertIn(sp["name"].upper(), txt)
        for word in ("pet store", "party", "attack", "defend", "gather", "level", "pseudo-dragon", "dungeon", "battleground", "raid", "loot", "stance"): self.assertIn(word, txt.lower())
        allt = " ".join(" ".join(l) for l in pages.values()); self.assertIn("Pet Store", allt)


class PetsOnScreen(unittest.TestCase):
    """1.0.29: the client draws the pet, its frame, the Pet Store and pet windows, and the pets of the computer-controlled people."""
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import game as G
        cls.G = G; cls.w = pet_world(40)
        cls.g = G.Game(cls.w); cls.g.mouse = (10, 10); cls.g.apply_quality(1, False, False)
        cls.spot = (cls.w.player["x"], cls.w.player["y"])

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def frames(self, n=6, ticks=True):
        for _ in range(n):
            if ticks: self.w.update(1)
            self.g.frame(1 / 30); self.G.present()

    def key(self, k):
        import pygame
        return self.g.on_key(pygame.event.Event(pygame.KEYDOWN, key=k, mod=0, unicode=""))

    def test_store_window_buys_a_pet_and_the_hud_shows_it(self):
        import pygame
        g, w = self.g, self.w; w.player["x"], w.player["y"] = self.spot; w._pets()["owned"].clear(); w._pets()["active"] = ""; w._pet_rt = None; w.player["gold"] = 10 ** 6
        w.open_ui = None; g.msg(w.interact_nearby(), (255, 255, 255)); g.open_world_ui(); self.assertEqual(g.mode, "petshop")
        self.frames(2, ticks=False); self.assertIn("pbuy_wolf_pup", g.ui_rects); self.assertIn("pbuy_pseudo_dragon", g.ui_rects)
        g.mouse = g.ui_rects["pbuy_wolf_pup"].center; self.frames(1, ticks=False)         # the hover tooltip draws
        g.on_mouse_down(g.ui_rects["pbuy_wolf_pup"].center, 1); self.assertIn("wolf_pup", w._pets()["owned"])
        self.frames(2, ticks=False); self.assertIn("pcall_wolf_pup", g.ui_rects)
        g.mode = "world"; g.mouse = (10, 10); self.frames(8)
        self.assertIn("petstance", g.ui_rects); self.assertIn("petw", g.ui_rects)
        g.on_mouse_down(g.ui_rects["petstance"].center, 1); self.assertEqual(w.pet_snapshot()["pet"]["stance"], "defend")

    def test_keys_p_and_r(self):
        import pygame
        g, w = self.g, self.w; w._pets()["owned"]["wolf_pup"] = {"name": "Tester", "level": 20, "xp": 0, "stance": "attack"}; w._pets()["active"] = "wolf_pup"; w._pet_rt = None
        g.mode = "world"; self.frames(3)
        self.key(pygame.K_r); self.assertEqual(w.pet_snapshot()["pet"]["stance"], "defend")
        self.key(pygame.K_r); self.key(pygame.K_r); self.assertEqual(w.pet_snapshot()["pet"]["stance"], "attack")
        self.key(pygame.K_p); self.assertEqual(g.mode, "pets"); self.frames(3, ticks=False)
        self.assertIn("pstance_gather", g.ui_rects); g.on_mouse_down(g.ui_rects["pstance_gather"].center, 1); self.assertEqual(w.pet_snapshot()["pet"]["stance"], "gather")
        self.assertIn("pdismiss", g.ui_rects); g.on_mouse_down(g.ui_rects["pdismiss"].center, 1); self.assertEqual(w._pets()["active"], "")
        self.frames(2, ticks=False); self.assertIn("pcall_wolf_pup", g.ui_rects); g.on_mouse_down(g.ui_rects["pcall_wolf_pup"].center, 1); self.assertEqual(w._pets()["active"], "wolf_pup")
        self.key(pygame.K_p); self.assertEqual(g.mode, "world")

    def test_pet_windows_draw_every_pet(self):
        g, w = self.g, self.w
        for k in self.G.petmod.SPECIES_ORDER: w._pets()["owned"][k] = {"name": "N" + k[:3], "level": 30, "xp": 5, "stance": "attack"}
        for k in self.G.petmod.SPECIES_ORDER:
            w._pets()["active"] = k; w._pet_rt = None; g.pets_sel = k; g.mode = "pets"; self.frames(3)
            g.mode = "world"; w.player["x"], w.player["y"] = self.spot; self.frames(3)       # in the world, walking, then at rest, with its plate
        g.mode = "petshop"; self.frames(2, ticks=False); g.mode = "world"
        w._pets()["active"] = "pseudo_dragon"; w._pet_rt = None; self.frames(40)
        self.assertTrue(g.snap["pet"]["camo"]); self.frames(4)

    def test_knocked_out_pet_and_pet_in_an_instance_draw(self):
        g, w = self.g, self.w; w._pets()["owned"]["cave_bear_cub"] = {"name": "Bruno", "level": 30, "xp": 0, "stance": "defend"}; w._pets()["active"] = "cave_bear_cub"; w._pet_rt = None
        w.player["x"], w.player["y"] = self.spot; self.frames(3); w._pet_absorb(10 ** 7); self.frames(4); self.assertGreater(g.snap["pet"]["down"], 0)
        w._pet_rt.down_until = 0; w._pet_rt.hp = w._pet_rt.maxhp
        inst = enter(w, "tdm12"); self.frames(6)
        self.assertIsNotNone(g.snap["pet"]); self.assertTrue(any(a.get("pet") for a in g.snap["actors"]), "bots with pets are drawn")
        w.leave_instance(silent=True); self.frames(3)

    def test_adventurer_pets_are_drawn_at_their_heels(self):
        g, w = self.g, self.w
        a = next(a for a in w.actors if a.kind == "adventurer" and w.npc_pet(a) and a.faction != w.player["faction"])
        w.player["x"], w.player["y"] = a.x + 2, a.y; self.frames(6)
        self.assertTrue(any(d.get("pet") for d in g.snap["actors"])); self.assertTrue(getattr(g, "npet_d", None), "the pet of a computer hero is on screen")
        a2 = next(a for a in w.actors if a.kind == "adventurer" and w.npc_pet(a) and a.faction == w.player["faction"])
        w.player["x"], w.player["y"] = a2.x + 2, a2.y; self.frames(6)


class AddsOnTheTank(unittest.TestCase):
    """1.0.29: party bots kill adds that are on the tank too - after adds on the squishies, before the rest."""
    def setUp(self):
        self.w = w = new_world(level=40, faction="Horde", cls="Mage")
        d = next(x for x in w.dungeons if x.kind == "dungeon"); w.player["level"] = max(40, d.level); w.player["x"], w.player["y"] = d.x, d.y + 1
        w._enter_dungeon(d, False, (d.x, d.y + 3)); self.inst = w.inst; w.update(2)
        r = next(r for r in self.inst.rooms if r["type"] == "trash"); self.inst._pull(r)
        self.mobs = [self.inst.actors[i] for i in r["mobs"]]

    def tearDown(self):
        self.w.close()

    def test_focus_ranks_squishy_adds_then_tank_adds_then_loose_ones(self):
        inst = self.inst; tank = inst.mt; dps = next(a for a in inst.allies if a.rrole == "DPS"); healer = next(a for a in inst.allies if a.rrole == "Healer")
        self.assertIsNotNone(tank)
        for m in self.mobs: m.role = "add"; m.tgt = None; m.hp = m.maxhp
        a, b, c = self.mobs[:3]
        a.tgt = tank; b.tgt = None; c.tgt = tank; a.hp = a.maxhp * .3
        self.assertIs(inst._focus(), a, "an add on the tank is a target (the most wounded first)")
        b.tgt = healer; self.assertIs(inst._focus(), b, "an add on the healer comes first")
        b.tgt = dps; self.assertIs(inst._focus(), b)
        b.tgt = "player"; self.assertIs(inst._focus(), b, "an add on the (DPS) player comes first")
        b.hp = 0; a.tgt = None; c.tgt = tank; self.assertIs(inst._focus(), c, "an add on the tank beats a loose one"); 

    def test_a_dps_bot_attacks_an_add_on_the_tank(self):
        w = self.w; inst = self.inst; tank = inst.mt; hits = []
        for m in self.mobs: m.role = "mob"; m.hp = m.maxhp = 10 ** 6
        add = self.mobs[0]; add.role = "add"; add.tgt = tank; add.hp = add.maxhp = 10 ** 6
        orig = inst._ally_attack
        inst._ally_attack = lambda a, f, now, _o=orig: (hits.append((a.rrole, f.id)), _o(a, f, now))[1]
        try:
            for _ in range(120):
                w.player["hp"] = w._effective_maxhp(); add.tgt = tank; w.update(1)
        finally:
            inst._ally_attack = orig
        self.assertTrue(any(r == "DPS" and i == add.id for r, i in hits), "a DPS bot hit the add that was on the tank")
        self.assertLess(add.hp, add.maxhp)


class SpellReset(unittest.TestCase):
    """1.0.29: spell points can be reset on their own, for every class and every specialisation."""
    def test_every_class_and_spec_can_respec_its_spells(self):
        from liveworld_rpg import gfx
        w = new_world(level=60)
        try:
            w.station_posts = {"magic": [(w.player["x"], w.player["y"])]}
            combos = [(c, None) for c in CLASSES if c not in E.HYBRID_SPECS] + [(c, n) for c, sp in E.HYBRID_SPECS.items() for n, _ in sp]
            self.assertGreaterEqual(len(combos), 12 + 6)
            for cls, spec in combos:
                with self.subTest(cls=cls, spec=spec):
                    w.set_class(cls, spec)
                    if spec: w.set_spec(spec)
                    w._build_c = {"s": {k: 0 for k in E.STAT_KEYS}, "r": {}}; w._build_save(); w.player["gold"] = 10 ** 8
                    left0 = w.rank_points_left(); self.assertEqual(left0, 59)
                    abl = [a for a in E.ABILITIES[w.skill_key()] if a["unlock"] <= 60]
                    for a in abl[:6]: self.assertIn("is now rank", w.rank_up(a["name"]))
                    w.add_stat("str", 3); order = list(w.slot_order()); w.swap_slots("1", "2"); passive = w.equip_passive(next(p["name"] for p in E.PASSIVES[w.skill_key()] if p["unlock"] <= 60))
                    spent = left0 - w.rank_points_left(); self.assertEqual(spent, 6)
                    gold = w.player["gold"]; self.assertIn(f"{spent} spell points back", w.reset_spells())
                    self.assertEqual(gold - w.player["gold"], 500 * 60, "same price as the full reset")
                    self.assertEqual(w.rank_points_left(), left0, "every spell point is back"); self.assertTrue(all(w.ability_rank(a["name"]) == 1 for a in abl))
                    self.assertEqual(w._build()["s"]["str"], 3, "stats kept"); self.assertNotEqual(w.slot_order(), order, "hotbar layout kept")
                    self.assertTrue(w.equipped_passives()); self.assertEqual(len(w.slot_order()), len(E.ABILITIES[w.skill_key()]), "every spell still on the hotbar")
                    for a in abl[:6]: self.assertIn("is now rank", w.rank_up(a["name"]), "points can be spent again")
                    w.reset_spells(); self.assertIn("Stats, spell ranks", w.reset_build()); self.assertEqual(w.stat_points_left(), 3 * 59)
            w.player["gold"] = 0; w._build()["r"]["x"] = 2; self.assertIn("costs", w.reset_spells())
            w.station_posts = {}; self.assertIn("Skill Shop", w.reset_spells())
        finally:
            w.close()


class StuckHeroes(unittest.TestCase):
    """1.0.29: computer players never stand still for ever - not in a fight that gets nowhere, not against a palisade, not inside the other side's town."""
    @classmethod
    def setUpClass(cls):
        from liveworld_rpg import game as G
        cls.w = new_world(level=60, faction="Horde", cls="Mage"); cls.g = G.Game(cls.w)          # the client gives the world its walls, gates and walkable ground
        cls.w.player["x"], cls.w.player["y"] = 3.0, 3.0

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def test_a_fight_that_goes_nowhere_is_broken_off(self):
        from liveworld_rpg import people
        w = self.w; hero = next(a for a in w.actors if a.kind == "adventurer" and not a.party and a.level >= 50); m = next(a for a in w.actors if a.kind == "monster" and a.faction != hero.faction)
        hero.x, hero.y = 600.0, 600.0; hero.state = "hunt"; hero.hp = hero.maxhp; hero.gx = None; hero.target = -1
        m.x, m.y = 601.0, 600.0; m.hp = m.maxhp = 10 ** 8; m.target = hero.id; m.state = "combat"
        x0, y0 = hero.x, hero.y; y0 = hero.y
        for _ in range(people.FIGHT_CAP + 200):
            hero.hp = hero.maxhp; w.update(1)
            if m.hp < m.maxhp * .999999: m.hp = m.maxhp
        self.assertGreater(math.hypot(hero.x - x0, hero.y - 600.0), 8, "the hero left the stalemate")
        m.hp = m.maxhp = 100; m.x, m.y = 3.0, 3.0; m.target = -1

    def test_a_hero_with_a_goal_that_cannot_move_gives_it_up(self):
        w = self.w; hero = next(a for a in w.actors if a.kind == "adventurer" and not a.party and a.state != "party")
        hero.x, hero.y = 700.0, 700.0; hero.state = "hunt"; hero.gx, hero.gy = 760.0, 700.0; hero.task_until = w.tick + 9999
        real = w._step; w._step = lambda a, *args, **kw: None if a is hero else real(a, *args, **kw)       # something holds it fast
        try:
            for _ in range(300): w.update(1)
        finally:
            w._step = real
        self.assertTrue(hero.gx is None or (hero.gx, hero.gy) != (760.0, 700.0), "it dropped the goal it could not reach")

    def test_heroes_get_out_of_the_other_sides_town_through_a_gate(self):
        from liveworld_rpg import engine as E
        w = self.w; R = E.TOWN_WALL_R; t = next(t for t in w.towns if t.faction == "Horde")
        foes = [a for a in w.actors if a.kind == "adventurer" and a.faction == "Alliance" and not a.party][:8]
        for k, a in enumerate(foes):
            ang = k * .79 + .3; a.x, a.y = t.x + math.cos(ang) * (R - 2.5), t.y + math.sin(ang) * (R - 2.5); a.state = "hunt"; a.hp = a.maxhp
            a.gx, a.gy = t.x + math.cos(ang) * (R + 45), t.y + math.sin(ang) * (R + 45); a.task_until = w.tick + 9999; a._lp = None
        for _ in range(500): w.update(1)
        still_in = [a.name for a in foes if math.hypot(a.x - t.x, a.y - t.y) < R + 1]
        self.assertEqual(still_in, [], "nobody is left pressed against the palisade inside the enemy town")

    def test_nobody_with_somewhere_to_go_stands_still_for_long(self):
        w = self.w
        for _ in range(900): w.update(1)
        tick = w.tick; bad = []
        for a in w.actors:
            if a.kind != "adventurer" or a.state not in ("travel", "hunt", "roam", "town") or a.gx is None: continue
            if getattr(a, "_lp", None) is not None and getattr(a, "_lt", tick) < tick - 400 and math.hypot(a.gx - a.x, a.gy - a.y) > 4: bad.append((a.name, a.state))
        self.assertEqual(bad, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)

