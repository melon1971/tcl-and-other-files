"""Mounts and riding (0.19.0) — WoW-style riding training plus Conquer-style steeds.

Riding skill is trained at a Stable Master in any town, in four tiers.  Each
mount needs a riding tier; tiers 3 and 4 also unlock flying mounts (never allowed in battlegrounds, dungeons or raids).  Attacking or
using a skill dismounts you; a ground mount may throw you off when you are hit (1.0.24: rarely, less often the better you ride).
State is stored in the world's meta table, so existing saves keep working.
"""
import json

# tier: (name, level, price, description) - 1.0.19: riding and mount prices doubled
RIDING = {
    1: ("Apprentice Riding", 5, 600, "Ride ground mounts (+60% speed)."),
    2: ("Journeyman Riding", 25, 4000, "Ride swift ground mounts (+100% speed)."),
    3: ("Expert Riding", 40, 16000, "Ride swift war mounts (+150% speed)."),
    4: ("Master Riding", 60, 50000, "Ride the fastest mounts (+200% speed)."),
}

# id: dict(name, look, tier, speed bonus, fly, price, desc)
MOUNTS = {
    "chestnut":  dict(name="Chestnut Mare", look="horse", tier=1, speed=.60, fly=False, price=1000,
                      desc="A dependable riding horse from the town stables."),
    "wolf":      dict(name="Timber Wolf", look="wolf", tier=1, speed=.60, fly=False, price=1400,
                      desc="A great grey wolf, raised by the hill clans."),
    "warhorse":  dict(name="Armored Warhorse", look="warhorse", tier=2, speed=1.0, fly=False, price=8000,
                      desc="A barded war steed in gilded plate. Swift and proud."),
    "sabertooth": dict(name="Ember Sabertooth", look="saber", tier=2, speed=1.0, fly=False, price=10000,
                      desc="A striped sabertooth from the Ember Highlands."),
    "destrier":  dict(name="Royal Destrier", look="warhorse", tier=3, speed=1.5, fly=False, price=20000,
                      desc="A tall white destrier of the king's stables. Swift over any road."),
    "frostsaber": dict(name="Frostmane Sabertooth", look="saber", tier=3, speed=1.5, fly=False, price=20000,
                      desc="A pale sabertooth bred in the snows of Frostmarch."),
    "charger":   dict(name="Spectral Charger", look="horse", tier=4, speed=2.0, fly=False, price=60000,
                      desc="A ghostly steed that never tires."),
    "gryphon":   dict(name="Royal Gryphon", look="gryphon", tier=3, speed=1.6, fly=True, price=36000,
                      desc="A golden-feathered gryphon. Flies over water, walls and mountains - never into a battleground."),
    "wyvern":    dict(name="Frost Wyvern", look="wyvern", tier=3, speed=1.6, fly=True, price=36000,
                      desc="A pale wyvern from the high peaks. Monsters cannot reach you in the air."),
    "pegasus":   dict(name="Celestial Pegasus", look="pegasus", tier=4, speed=2.2, fly=True, price=110000,
                      desc="A winged white steed that gallops on the wind."),
    "drake":     dict(name="Shadow Drake", look="drake", tier=4, speed=2.2, fly=True, price=130000,
                      desc="A black drake from the Shadowlands. The fastest thing in the sky."),
    "direwolf":  dict(name="Shadow Dire Wolf", look="wolf", tier=4, speed=2.0, fly=False, price=90000,
                      desc="A huge black wolf from the Shadowlands. The fastest mount in the realm."),
}
# 0.45: battleground mounts - bought with PvP Points at the War Hall Armory.  Unlike every other mount they may be ridden
# inside battlegrounds (they are all ground mounts - nothing flies in a battleground), and each carries special powers (while you ride):
#   regen  - Second Wind: recover 2% health a second          ward   - Barding: take 25% less damage
#   charge - Battle Charge: your first attack after you dismount hits 50% harder for 6 s
#   runner - Flag Runner: keep riding while you carry a flag   steady - never thrown off when you are hit
# 1.0.26 - battle mounts fight too:
#   frost   - Frost Breath: while you ride, the mount casts Frostbolt at the nearest enemy every 2 s (13.5 tiles); its rank
#             follows the mount's tier (frost_rank) - it slows for 6 s, may freeze, and never dismounts you
#   sprint  - Stampede (key B): +200% speed or more (sprint) for 6 s, every 25 s
#   veil    - Shadow Veil (key L): invisible for veil seconds - enemies only see you within 2 tiles; attacking or taking a flag
#             breaks it, and it cannot be used while you carry a flag.  Every 50 s
#   trample - Trample: enemies you ride through are knocked down (1 s stun) and hurt, each at most once every 5 s
BG_MOUNTS = {
    "bg_wolf":    dict(name="Recruit's Battle Wolf", look="wolf", tier=1, speed=.70, fly=False, price=0, pvp=300, wins=0, powers=("regen", "frost", "sprint"),
                       frost_rank=2, sprint=2.0,
                       power_text="Frost Breath (Frostbolt rank 2). Stampede +200% speed (B). Second Wind.",
                       desc="A scarred war wolf from the battleground kennels."),
    "bg_charger": dict(name="Gladiator's Charger", look="warhorse", tier=2, speed=1.05, fly=False, price=0, pvp=1200, wins=10, powers=("ward", "regen", "frost", "sprint", "trample"),
                       frost_rank=4, sprint=2.0,
                       power_text="Frost Breath (rank 4). Stampede +200% (B). Trample. Barding. Second Wind.",
                       desc="A barded charger in the colours of the arena."),
    "bg_saber":   dict(name="Vicious Sabertooth", look="saber", tier=2, speed=1.1, fly=False, price=0, pvp=2000, wins=20, powers=("charge", "ward", "frost", "sprint", "veil"),
                       frost_rank=4, sprint=2.0, veil=8,
                       power_text="Shadow Veil 8s (L). Frost Breath (rank 4). Stampede +200% (B). Battle Charge. Barding.",
                       desc="A sabertooth with a spiked war harness."),
    "bg_courser": dict(name="Bloodsand Courser", look="horse", tier=3, speed=1.55, fly=False, price=0, pvp=3500, wins=35, powers=("runner", "ward", "regen", "frost", "sprint", "veil"),
                       frost_rank=6, sprint=2.5, veil=10,
                       power_text="Stampede +250% (B). Shadow Veil 10s (L). Frost Breath (rank 6). Flag Runner. Barding. Second Wind.",
                       desc="The fastest horse of the Bloodsand Colosseum."),
    "bg_nightmare": dict(name="Mythic Gladiator's Nightmare", look="warhorse", tier=4, speed=2.1, fly=False, price=0, pvp=9000, wins=80,
                         powers=("runner", "ward", "regen", "charge", "steady", "frost", "sprint", "veil", "trample"),
                         frost_rank=10, sprint=3.0, veil=15,
                         power_text="Every power: Frost Breath (rank 10), Stampede +300% (B), Shadow Veil 15s (L), Trample, and it never throws you.",
                         desc="A flame-maned nightmare, the prize of a thousand battles."),
}
SPRINT_TICKS = 24            # Stampede lasts 6 s ...
SPRINT_CD = 100              # ... every 25 s
VEIL_CD = 200                # Shadow Veil every 50 s
FROST_EVERY = 8              # Frost Breath: a Frostbolt every 2 s ...
FROST_RANGE = 13.5           # ... at an enemy within 13.5 tiles (a caster's ranged reach)
TRAMPLE_CD = 20              # each enemy trampled at most once every 5 s
for _k, _v in BG_MOUNTS.items():
    _v["bg"] = True
    assert not _v["fly"], _k            # 1.0.26: no flying mounts in battlegrounds, ever
MOUNTS.update(BG_MOUNTS)
BG_ORDER = list(BG_MOUNTS)

MOUNT_ORDER = ["chestnut", "wolf", "warhorse", "sabertooth", "destrier", "frostsaber", "charger", "direwolf", "gryphon", "wyvern", "pegasus", "drake"]
_RENAMED = {}                       # 0.42: flying mounts are back (0.24 had turned them into ground mounts)
STABLE_POST = (3.6, -12.6)          # where the Stable Master stands, relative to the town centre


class MountMixin:
    """Mixed into engine.World."""

    # ------------------------------------------------------------ state
    def _mst(self):
        st = getattr(self, "_mount_cache", None)
        if st is None:
            st = self._jmeta("mounts", None)
            if not isinstance(st.get("riding"), int) or not 0 <= st["riding"] <= max(RIDING): st["riding"] = 0      # 0.46.42: validate what the save holds
            if not isinstance(st.get("owned"), list): st["owned"] = []
            st.setdefault("active", None)
            st["owned"] = [x for x in dict.fromkeys(_RENAMED.get(x, x) for x in st["owned"] if isinstance(x, str)) if x in MOUNTS]
            if st["active"] not in MOUNTS or st["active"] not in st["owned"]: st["active"] = None
            if st.get("bg_active") not in st["owned"]: st["bg_active"] = None
            if st["active"] in _RENAMED: st["active"] = _RENAMED[st["active"]]
            st.setdefault("bg_active", None)
            if st["active"] and MOUNTS.get(st["active"], {}).get("bg"):      # 0.46.33: a battleground mount is never your open-world mount
                st["bg_active"] = st["bg_active"] or st["active"]
                alt = [o for o in st["owned"] if o in MOUNTS and not MOUNTS[o].get("bg")]
                st["active"] = max(alt, key=lambda o: MOUNTS[o]["speed"]) if alt else None
            self._mount_cache = st
        return st

    def _mst_save(self):
        self._setmeta("mounts", json.dumps(self._mst())); self.db.commit()


    def mounted_def(self):
        m = getattr(self, "mounted", None)
        return MOUNTS.get(m) if m else None

    def mount_power(self, power):
        """0.45: True while you ride a battleground mount with this power."""
        d = self.mounted_def()
        return bool(d and power in d.get("powers", ()))

    def in_battleground(self):
        return bool(self.inst) and bool(getattr(self.inst, "is_arena", False))

    def _mount_tick(self):
        """Second Wind: 0.5% health a tick (2% a second) while riding a mount with regen.  1.0.26: Frost Breath and Trample."""
        d_ = self.mounted_def()
        if d_ and d_.get("bg") and not self.in_battleground(): self.mounted = None      # 0.46.33: battle mounts only exist in battlegrounds
        if d_ and d_.get("fly") and self.in_battleground(): self.mounted = None; self.events.append("No flying mounts in battlegrounds.")   # 1.0.26: never
        if getattr(self, "mounted", None) and d_ and d_.get("bg") and self.in_battleground():
            try: self._mount_combat_tick(d_)
            except Exception:
                import traceback; traceback.print_exc()
        if getattr(self, "mounted", None) and self.mount_power("regen"):
            mx = self._effective_maxhp(); p = self.player
            if 0 < p["hp"] < mx: p["hp"] = min(mx, p["hp"] + max(1, mx // 200))

    # ------------------------------------------------------------ 1.0.26: battle mount powers
    def _mcd(self):
        c = getattr(self, "_mount_cds", None)
        if c is None: c = self._mount_cds = {}
        return c

    def _mount_foes(self, rng):
        p = self.player; r2 = rng * rng
        return [a for a in self.actors if a.kind == "imob" and a.hp > 0 and not getattr(a, "dead", False) and (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2 <= r2]

    def _mount_bolt_damage(self, rank):
        base = max(4, self.player["level"] * 2 + self.eff_weapon() * 5)
        return max(1, int(base * 1.70 * (.35 + .065 * rank)))

    def _mount_combat_tick(self, d):
        p = self.player; tick = self.tick; veiled = bool(self._buff("stealth"))
        if getattr(self.inst, "player_down", None) and self.inst.player_down(): return
        pw = d.get("powers", ())
        if "frost" in pw and not veiled and tick % FROST_EVERY == 0:
            foes = self._mount_foes(FROST_RANGE)
            sel = getattr(self, "selected_target", None)
            t = next((a for a in foes if a.id == sel), None) or (min(foes, key=lambda a: (a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2) if foes else None)
            if t is not None:
                rank = d.get("frost_rank", 1)
                dmg, crit, killed = self._hit(t, self._mount_bolt_damage(rank), kind="mountfrost")
                if dmg and not killed and t.hp > 0:
                    st_ = self.mstatus.setdefault(t.id, {})
                    st_["slow"] = max(st_.get("slow", 0), tick + 24)
                    if self.rng.random() < .10: st_["stun"] = max(st_.get("stun", 0), tick + 6)
                q = self.__dict__.setdefault("pfx", [])
                if len(q) < 40: q.append({"t": "shot", "src": "player", "dst": t.id, "cls": "Frost"})
        pos_ = (round(p["x"], 2), round(p["y"], 2)); moving = pos_ != getattr(self, "_mt_pos", None); self._mt_pos = pos_
        if "trample" in pw and moving:
            cd = self._mcd().setdefault("trample", {})
            for a in self._mount_foes(1.4):
                if cd.get(a.id, -99) > tick: continue
                cd[a.id] = tick + TRAMPLE_CD
                dmg, crit, killed = self._hit(a, max(1, self._mount_bolt_damage(d.get("frost_rank", 4)) // 2), kind="trample")
                if not killed and a.hp > 0:
                    st_ = self.mstatus.setdefault(a.id, {}); st_["stun"] = max(st_.get("stun", 0), tick + 4)
            if len(cd) > 200: self._mount_cds["trample"] = {k: v for k, v in cd.items() if v > tick}

    def mount_powers_info(self):
        """For the HUD: the active powers of the battle mount you ride, with their cooldowns (seconds)."""
        d = self.mounted_def()
        if not d or not d.get("bg") or not self.in_battleground(): return []
        c = self._mcd(); out = []
        if "sprint" in d.get("powers", ()):
            b = self._buff("mount_sprint")
            out.append({"key": "sprint", "name": "Stampede", "hotkey": "B", "pct": int(d.get("sprint", 2.0) * 100),
                        "cd": max(0, (c.get("sprint", 0) - self.tick + 3) // 4), "on": (b["until"] - self.tick + 3) // 4 if b else 0})
        if "veil" in d.get("powers", ()):
            b = self._buff("stealth")
            out.append({"key": "veil", "name": "Shadow Veil", "hotkey": "L", "secs": d.get("veil", 8),
                        "cd": max(0, (c.get("veil", 0) - self.tick + 3) // 4), "on": (b["until"] - self.tick + 3) // 4 if b else 0})
        if "frost" in d.get("powers", ()):
            out.append({"key": "frost", "name": f"Frost Breath r{d.get('frost_rank', 1)}", "hotkey": "", "cd": 0, "on": 0, "passive": True})
        return out

    def mount_ability(self, key):
        d = self.mounted_def()
        if not d or not d.get("bg") or not self.in_battleground():
            return "Mount powers work on a battle mount, in a battleground."
        pw = d.get("powers", ()); c = self._mcd()
        if key == "sprint":
            if "sprint" not in pw: return f"Your {d['name']} cannot Stampede."
            if c.get("sprint", 0) > self.tick: return f"Stampede is not ready ({(c['sprint'] - self.tick + 3) // 4}s)."
            c["sprint"] = self.tick + SPRINT_CD
            self.buffs["mount_sprint"] = {"name": "Stampede", "kind": "mount_sprint", "until": self.tick + SPRINT_TICKS, "value": d.get("sprint", 2.0)}
            return f"Stampede! +{int(d.get('sprint', 2.0) * 100)}% speed for 6 seconds."
        if key == "veil":
            if "veil" not in pw: return f"Your {d['name']} has no Shadow Veil."
            if getattr(self.inst, "carry_player", None): return "Not while you carry a flag."
            if c.get("veil", 0) > self.tick: return f"Shadow Veil is not ready ({(c['veil'] - self.tick + 3) // 4}s)."
            c["veil"] = self.tick + VEIL_CD
            self.buffs["stealth"] = {"name": "Shadow Veil", "kind": "vanish", "until": self.tick + d.get("veil", 8) * 4, "value": 1}
            for a in self.actors:
                if a.kind == "imob" and getattr(a, "target", None) == -2: a.target = -1
            return f"Shadow Veil: you vanish for {d.get('veil', 8)} seconds. Attacking or taking a flag breaks it."
        return "Unknown mount power."

    def is_flying(self):
        d = self.mounted_def()
        return bool(d and d["fly"])

    def mount_speed(self):
        d = self.mounted_def()
        if d and d.get("bg") and self._buff("mount_sprint"):          # 1.0.26: Stampede
            return max(d["speed"], d.get("sprint", 2.0))
        return d["speed"] if d else 0.0

    def near_stable_master(self):
        p = self.player
        sm = self.__dict__.get("_stablemasters")
        if sm is None or sm[0] != len(self.actors):     # the list of stable masters, refreshed when the population changes
            sm = self._stablemasters = (len(self.actors), [a for a in self.actors if a.kind == "npc" and a.role == "stablemaster"])
        # 0.40.1: the Stable Master works inside the Stable, so standing at the building counts too
        return any((a.x - p["x"]) ** 2 + (a.y - p["y"]) ** 2 <= 49 for a in sm[1]) or self._near_station("stable", 7.0)

    def mount_info(self):
        st = self._mst(); d = self.mounted_def()
        return {"mounted": getattr(self, "mounted", None), "fly": bool(d and d["fly"]), "look": d["look"] if d else None,
                "speed": d["speed"] if d else 0, "riding": st["riding"], "owned": list(st["owned"]), "active": st["active"], "bg_active": st.get("bg_active"),
                "near_stable": self.near_stable_master()}

    # ------------------------------------------------------------ shop
    def buy_riding(self, tier):
        st = self._mst(); p = self.player
        if tier not in RIDING: return "Unknown riding skill."
        name, lvl, price, _ = RIDING[tier]
        if not self.near_stable_master(): return "Visit the Stable in any town to train riding."
        if st["riding"] >= tier: return f"You already know {name}."
        if st["riding"] < tier - 1: return f"Train {RIDING[tier - 1][0]} first."
        if p["level"] < lvl: return f"{name} requires level {lvl}."
        if p["gold"] < price: return f"{name} costs {price:,} gold. You have {p['gold']:,}."
        p["gold"] -= price; st["riding"] = tier; self._mst_save(); self._save_player_fast()
        return f"You learned {name}! {RIDING[tier][3]}"

    def buy_mount(self, mid):
        st = self._mst(); p = self.player
        m = MOUNTS.get(mid)
        if not m: return "Unknown mount."
        if m.get("bg"): return f"The {m['name']} is earned with PvP Points at the War Hall Armory."
        if not self.near_stable_master(): return "Visit the Stable in any town to buy mounts."
        if mid in st["owned"]: return f"You already own the {m['name']}."
        if st["riding"] < m["tier"]:
            nt = st["riding"] + 1; rn, rl, rp, _ = RIDING[nt]
            return f"Train {rn} first ({rp:,} gold, level {rl}) - you need it to ride the {m['name']}. Use the Riding tab at the Stable."
        if p["gold"] < m["price"]: return f"The {m['name']} costs {m['price']:,} gold. You have {p['gold']:,}."
        p["gold"] -= m["price"]; st["owned"].append(mid)
        if not st["active"] or MOUNTS[st["active"]]["speed"] <= m["speed"]: st["active"] = mid
        self._mst_save(); self._save_player_fast()
        need = RIDING[m["tier"]][0]
        tail = "" if st["riding"] >= m["tier"] else f" You need {need} to ride it."
        return f"You bought the {m['name']}! Press X to summon it.{tail}"

    def set_active_mount(self, mid):
        st = self._mst()
        if mid not in st["owned"]: return "You don't own that mount."
        if MOUNTS[mid].get("bg"):      # 0.46.33: battle mounts are chosen separately and only used in battlegrounds
            st["bg_active"] = mid; self._mst_save()
            return f"{MOUNTS[mid]['name']} will be your mount in battlegrounds (X to summon there)."
        st["active"] = mid; self._mst_save()
        if getattr(self, "mounted", None) and self.mounted != mid and not self.is_flying():
            self.mounted = None
        return f"{MOUNTS[mid]['name']} is now your active mount (X to summon)."

    # ------------------------------------------------------------ riding
    def can_mount(self):
        st = self._mst(); mid = st["active"]
        if self.inst:
            # 0.45: battleground mounts may be ridden in battlegrounds (never in dungeons or raids)
            bg = [o for o in st["owned"] if MOUNTS.get(o, {}).get("bg") and MOUNTS[o]["tier"] <= st["riding"]]
            if not self.in_battleground():
                return False, "No mounts in dungeons or raids."
            if not bg:
                return False, "Only battleground mounts can be ridden here - earn one with PvP Points at the War Hall Armory."
            mid = st.get("bg_active")
            if mid not in bg:
                mid = max(bg, key=lambda o: MOUNTS[o]["speed"])
            if self.tick - getattr(self, "last_combat_tick", -999) < 20: return False, "You can't mount while in combat."
            self._bg_mount = mid
            return True, ""
        self._bg_mount = None
        if self.player_pvp: return False, "You can't summon a mount here."
        if not mid: return False, "You have no mount. Buy one at the Stable in any town."
        m = MOUNTS[mid]
        if st["riding"] < m["tier"]:
            alt = [o for o in st["owned"] if MOUNTS[o]["tier"] <= st["riding"] and (not MOUNTS[o]["fly"] or True)]
            if alt:
                st["active"] = max(alt, key=lambda o: MOUNTS[o]["speed"]); self._mst_save(); m = MOUNTS[st["active"]]
            else:
                nt = st["riding"] + 1; rn, rl, rp, _ = RIDING[nt]
                return False, f"You can't ride the {m['name']} yet: first train {rn} at the Stable ({rp:,} gold, level {rl}). Riding skill is separate from buying the mount."
        if self.tick - getattr(self, "last_combat_tick", -999) < 20: return False, "You can't mount while in combat."
        return True, ""

    def mount(self):
        ok, why = self.can_mount()
        if not ok: return why
        self.mounted = getattr(self, "_bg_mount", None) or self._mst()["active"]
        for a in self.actors:
            if a.kind == "monster" and a.target == -2 and self.is_flying():
                a.target = -1; a.state = "wander"
        m = MOUNTS[self.mounted]
        return f"You mount your {m['name']}."

    def dismount(self, force=False, reason=None):
        if not getattr(self, "mounted", None): return ""
        if not force and self.is_flying():
            ok = getattr(self, "terrain_ok", None)
            if ok and not ok(self.player["x"], self.player["y"]):
                return "You can't land here. Fly over open ground first."
        self.mounted = None
        return reason or "You dismount."

    def _dismount_for_action(self):
        """Attacks and skills dismount you first (WoW). Returns an error string if you can't land."""
        if not getattr(self, "mounted", None): return ""
        charge = self.mount_power("charge")
        r = self.dismount()
        if charge and not r.startswith("You can't land"):      # 0.45 Battle Charge
            mb = self.buffs.get("might")
            if not mb or mb.get("until", 0) <= self.tick or mb.get("value", 0) < .5:
                self.buffs["might"] = {"name": "Battle Charge", "kind": "might", "until": self.tick + 24, "value": .5}
        return r if r.startswith("You can't land") else ""

    def _ensure_stablemasters(self):
        from .engine import Actor, FACTIONS, AREAS
        nid = max((a.id for a in self.actors), default=10000) + 1; added = False
        for t in self.towns:
            if any(a.kind == "npc" and a.role == "stablemaster" and (a.x - t.x) ** 2 + (a.y - t.y) ** 2 < 26 * 26 for a in self.actors):
                continue
            lvl = max(1, next((a[6] for a in AREAS if a[0] == t.area), 1))
            self.actors.append(Actor(nid, "Stable Master", t.faction if t.faction in FACTIONS[:2] else "Neutral", lvl,
                                     t.x + STABLE_POST[0], t.y + STABLE_POST[1], 150, 150, "npc", "stablemaster", "town", -1, t.area, 20))
            nid += 1; added = True
        if added:
            self._save_all(force=True)
