"""1.0.19: near-3D mounts.

Each animal is built from rounded 3D parts (capsules that taper from one radius to another, each with a depth) laid out
on the 2x mount canvas (330 x 250, facing right, ground line GY).  The parts are merged into one height field with a
smooth union, so joints weld organically (a neck flows into the chest, a thigh into the haunch).  The surface is then lit
like a solid: sun from the upper left, a cool sky fill from above, a soft specular sheen on the coat (strong on armour),
a rim light on the silhouette and a fine coat texture.  Manes, tails, eyes, hooves, tack and armour trim are drawn on top.

numpy is required (it ships with python3-pygame on Debian/Ubuntu); without it gfx keeps the old flat mounts.
"""
import math
try:
    import numpy as np
    import pygame
    import pygame.surfarray as _sa
    HAVE = True
except Exception:          # pragma: no cover
    np = None; HAVE = False

CW, CH = 330, 250
GY = 222
_LIGHT = None
_NOISE = {}


def _light():
    global _LIGHT
    if _LIGHT is None:
        L = np.array([-.52, -.70, .58], np.float32); _LIGHT = L / np.linalg.norm(L)
    return _LIGHT


def _noise(seed, w=CW, h=CH, sx=1.0, sy=6.0):
    """Streaky coat noise: fine along x (the hair lies along the body), smoother across."""
    k = (seed, w, h, sx, sy)
    n = _NOISE.get(k)
    if n is None:
        rng = np.random.default_rng(seed)
        a = rng.standard_normal((h, w)).astype(np.float32)
        # blur mostly along x so it reads as hair
        for _ in range(int(sy)):
            a = (a + np.roll(a, 1, 1) + np.roll(a, -1, 1)) / 3.0
        for _ in range(int(sx)):
            a = (a + np.roll(a, 1, 0) + np.roll(a, -1, 0)) / 3.0
        a -= a.mean(); a /= (a.std() + 1e-6)
        n = _NOISE[k] = a
    return n


class Body:
    """A height field built from tapered 3D capsules with a smooth union."""

    def __init__(self, w=CW, h=CH):
        self.w, self.h = w, h
        self.H = np.full((h, w), -1e9, np.float32)
        self.C = np.zeros((h, w, 3), np.float32)
        self.S = np.zeros((h, w), np.float32)          # specular strength (coat .2, armour 1.0)
        self.F = np.zeros((h, w), np.float32)          # fur texture amount
        self.ys, self.xs = np.mgrid[0:h, 0:w].astype(np.float32)

    def cap(self, a, b, r0, r1, col, z0=0.0, z1=None, k=6.0, spec=.18, fur=1.0):
        """Capsule from a=(x, y) to b with radii r0..r1 and depth z0..z1 (bigger z = nearer the viewer)."""
        if z1 is None: z1 = z0
        ax, ay = a; bx, by = b
        m = max(r0, r1) + 2
        x0 = int(max(0, min(ax, bx) - m)); x1 = int(min(self.w, max(ax, bx) + m + 1))
        y0 = int(max(0, min(ay, by) - m)); y1 = int(min(self.h, max(ay, by) + m + 1))
        if x1 <= x0 or y1 <= y0: return
        X = self.xs[y0:y1, x0:x1]; Y = self.ys[y0:y1, x0:x1]
        dx, dy = bx - ax, by - ay; L2 = dx * dx + dy * dy
        if L2 < 1e-6: t = np.zeros_like(X)
        else: t = np.clip(((X - ax) * dx + (Y - ay) * dy) / L2, 0, 1)
        px = ax + dx * t; py = ay + dy * t
        d2 = (X - px) ** 2 + (Y - py) ** 2
        r = r0 + (r1 - r0) * t
        inside = d2 < r * r
        if not inside.any(): return
        h = np.where(inside, (z0 + (z1 - z0) * t) + np.sqrt(np.maximum(r * r - d2, 0)), -1e9).astype(np.float32)
        self._merge(h, (y0, y1, x0, x1), col, k, spec, fur)

    def ball(self, c, r, col, z=0.0, sq=1.0, k=6.0, spec=.18, fur=1.0):
        """An ellipsoid: radius r across, r * sq tall."""
        cx, cy = c
        rx, ry = r, r * sq
        x0 = int(max(0, cx - rx - 2)); x1 = int(min(self.w, cx + rx + 3))
        y0 = int(max(0, cy - ry - 2)); y1 = int(min(self.h, cy + ry + 3))
        if x1 <= x0 or y1 <= y0: return
        X = self.xs[y0:y1, x0:x1]; Y = self.ys[y0:y1, x0:x1]
        q = ((X - cx) / rx) ** 2 + ((Y - cy) / ry) ** 2
        inside = q < 1
        if not inside.any(): return
        h = np.where(inside, z + r * np.sqrt(np.maximum(1 - q, 0)), -1e9).astype(np.float32)
        self._merge(h, (y0, y1, x0, x1), col, k, spec, fur)

    def _merge(self, h, box, col, k, spec, fur):
        y0, y1, x0, x1 = box
        Hs = self.H[y0:y1, x0:x1]
        a = Hs; b = h
        both = (a > -1e8) & (b > -1e8)
        # polynomial smooth max where both exist, plain max elsewhere
        hh = np.clip(.5 + .5 * (b - a) / max(k, 1e-3), 0, 1)
        sm = a * (1 - hh) + b * hh + k * hh * (1 - hh)
        new = np.where(both, sm, np.maximum(a, b))
        wgt = np.where(both, hh, (b > a).astype(np.float32))[..., None]
        col_ = np.array(col, np.float32)
        self.C[y0:y1, x0:x1] = self.C[y0:y1, x0:x1] * (1 - wgt) + col_ * wgt
        self.S[y0:y1, x0:x1] = self.S[y0:y1, x0:x1] * (1 - wgt[..., 0]) + spec * wgt[..., 0]
        self.F[y0:y1, x0:x1] = self.F[y0:y1, x0:x1] * (1 - wgt[..., 0]) + fur * wgt[..., 0]
        self.H[y0:y1, x0:x1] = new

    def render(self, seed=7):
        """Light the height field. Returns an RGBA pygame Surface."""
        H = self.H
        mask = H > -1e8
        Hf = np.where(mask, H, 0).astype(np.float32)
        # gradient of the surface; at the silhouette the surface turns away from us
        gx = np.zeros_like(Hf); gy = np.zeros_like(Hf)
        gx[:, 1:-1] = (Hf[:, 2:] - Hf[:, :-2]) * .5
        gy[1:-1, :] = (Hf[2:, :] - Hf[:-2, :]) * .5
        edge = np.zeros_like(mask)
        edge[:, 1:-1] |= ~mask[:, 2:] | ~mask[:, :-2]
        edge[1:-1, :] |= ~mask[2:, :] | ~mask[:-2, :]
        gx = np.clip(gx, -3, 3); gy = np.clip(gy, -3, 3)
        # coat: hair-like streaks bend the normal slightly
        fn = _noise(seed, w=self.w, h=self.h, sx=0.0, sy=3.0) * self.F
        gy = gy + fn * .07
        nz = np.ones_like(Hf)
        n = np.stack([-gx, -gy, nz], -1)
        n /= np.linalg.norm(n, axis=-1, keepdims=True) + 1e-6
        Lv = _light()
        diff = np.clip(n @ Lv, 0, 1)
        sky = np.clip(-n[..., 1] * .5 + .5, 0, 1)                         # facing up -> more sky light
        hv = Lv + np.array([0, 0, 1], np.float32); hv /= np.linalg.norm(hv)
        spec = np.clip(n @ hv, 0, 1) ** 24 * self.S
        rim = np.clip(1 - n[..., 2], 0, 1) ** 2.5
        # ambient occlusion: deeper parts (far legs, belly underside) darker
        if mask.any():
            hmin, hmax = np.percentile(Hf[mask], 5), np.percentile(Hf[mask], 98)
        else:
            hmin, hmax = 0, 1
        depth = np.clip((Hf - hmin) / max(1e-3, hmax - hmin), 0, 1)
        ao = .62 + .38 * depth
        light = (.30 + .22 * sky) * ao + .78 * diff * (.55 + .45 * ao)
        col = self.C * light[..., None]
        col += (spec * 255.0)[..., None]
        col += rim[..., None] * np.array([60, 70, 90], np.float32) * .55
        col *= (1 + .035 * fn)[..., None]
        col = np.clip(col, 0, 255)
        surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        px = _sa.pixels3d(surf); al = _sa.pixels_alpha(surf)
        px[...] = col.transpose(1, 0, 2).astype(np.uint8)
        al[...] = (mask.astype(np.uint8) * 255).T
        del px, al
        return surf


# ------------------------------------------------------------------------------------------- colours per look
LOOKS = {
    "horse":    dict(coat=(132, 86, 52), belly=(150, 104, 66), mane=(46, 30, 20), hoof=(44, 36, 30), sock=(232, 226, 214), blaze=True),
    "warhorse": dict(coat=(214, 214, 218), belly=(226, 226, 230), mane=(236, 236, 240), hoof=(60, 56, 52), sock=None, blaze=False, armour=True),
    "pegasus":  dict(coat=(242, 242, 248), belly=(250, 250, 255), mane=(178, 216, 248), hoof=(170, 160, 150), sock=None, blaze=False),
    "wolf":     dict(coat=(112, 114, 122), belly=(196, 196, 200), mane=(84, 86, 94), hoof=(46, 44, 46)),
    "saber":    dict(coat=(206, 126, 56), belly=(238, 220, 186), mane=(40, 26, 20), hoof=(52, 40, 34), stripes=True),
    "gryphon":  dict(coat=(196, 146, 72), belly=(222, 186, 120), mane=(248, 244, 232), hoof=(232, 176, 50)),
    "wyvern":   dict(coat=(86, 124, 92), belly=(186, 196, 148), mane=(120, 64, 84), hoof=(60, 54, 50), scales=True),
    "drake":    dict(coat=(48, 42, 58), belly=(170, 72, 38), mane=(30, 26, 38), hoof=(40, 34, 44), scales=True),
}


def _shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def _legs_for(f):
    """Leg swing offsets for walk frame f (-1 = standing)."""
    if f < 0: return (0, 0, 0, 0)
    return ((10, 0, -10, 0)[f], (-10, 0, 10, 0)[f], (0, 10, 0, -10)[f], (0, -10, 0, 10)[f])


def _equine(B, P, f, bob, cy):
    coat, belly = P["coat"], P["belly"]
    far = _shade(coat, .8)
    sw = _legs_for(f)
    # far legs (behind the body, lower depth)
    for (hx, hy), s, front in (((112, cy + 6), sw[1], False), ((196, cy + 8), sw[3], True)):
        _leg_equine(B, (hx, hy - bob), s, far, P, z=-14, front=front, cy=cy)
    # body: haunch, barrel, chest
    B.ball((108, cy - 6 - bob), 40, coat, z=0, sq=.92, k=10)
    B.cap((110, cy - 2 - bob), (186, cy - 4 - bob), 36, 35, coat, z0=2, z1=2, k=12)
    B.ball((190, cy - 4 - bob), 36, coat, z=4, sq=1.0, k=12)
    B.cap((116, cy + 22 - bob), (186, cy + 22 - bob), 16, 16, belly, z0=8, z1=8, k=10, spec=.1)
    # neck: thick at the withers, tapering up to the head
    B.cap((196, cy - 22 - bob), (226, cy - 66 - bob), 25, 15, coat, z0=6, z1=8, k=10)
    # head: skull and muzzle
    hx, hy = 236, cy - 76 - bob
    B.ball((hx, hy), 15, coat, z=10, sq=.95, k=6)
    B.cap((hx + 2, hy + 2), (hx + 30, hy + 20), 13, 9, coat, z0=10, z1=10, k=6)
    B.ball((hx + 30, hy + 21), 9.5, _shade(coat, .92), z=10, sq=.9, k=4)
    # ears
    B.cap((hx - 4, hy - 10), (hx - 8, hy - 30), 5, 1.5, coat, z0=8, z1=8, k=2)
    B.cap((hx + 4, hy - 10), (hx + 2, hy - 30), 5, 1.5, _shade(coat, .9), z0=12, z1=12, k=2)
    # near legs
    for (hx_, hy_), s, front in (((114, cy + 8), sw[0], False), ((198, cy + 10), sw[2], True)):
        _leg_equine(B, (hx_, hy_ - bob), s, coat, P, z=16, front=front, cy=cy)
    return (hx, hy)


def _leg_equine(B, hip, s, col, P, z, front, cy):
    hx, hy = hip
    knee = (hx + s * .5 + (4 if front else -6), hy + 40)
    hock = (hx + s * 1.0 + (2 if front else -2), hy + 66)
    foot = (hx + s * 1.5, GY - 6 - (6 if s > 0 else 0))
    upper_r = 15 if not front else 13
    B.cap((hx, hy - 16), knee, upper_r + 6, 9, col, z0=z, z1=z, k=8)
    B.cap(knee, hock, 8.5, 6.5, col, z0=z, z1=z, k=4)
    B.cap(hock, (foot[0], foot[1] - 6), 6.5, 6, col, z0=z, z1=z, k=3)
    if P.get("sock") and z > 0 and not front:
        B.cap((hock[0], hock[1] + 6), (foot[0], foot[1] - 6), 7, 7, P["sock"], z0=z + 1, z1=z + 1, k=2, spec=.1)
    B.cap((foot[0] - 1, foot[1] - 6), (foot[0] + 2, foot[1] + 2), 8, 9, P["hoof"], z0=z, z1=z, k=2, spec=.5, fur=0)


def _canine(B, P, f, bob, cy, feline=False):
    coat, belly = P["coat"], P["belly"]
    far = _shade(coat, .8)
    sw = _legs_for(f)
    for (hx, hy), s, front in (((104, cy + 6), sw[1], False), ((198, cy + 8), sw[3], True)):
        _leg_paw(B, (hx, hy - bob), s, far, P, z=-12, front=front)
    B.ball((104, cy - 2 - bob), 32, coat, z=0, sq=.95, k=10)
    B.cap((106, cy - 2 - bob), (190, cy - 8 - bob), 29, 34, coat, z0=2, z1=4, k=12)
    B.ball((196, cy - 8 - bob), 34, coat, z=4, sq=1.0, k=12)
    B.cap((118, cy + 20 - bob), (196, cy + 18 - bob), 13, 19, belly, z0=8, z1=10, k=10, spec=.1)
    # neck ruff and head
    B.cap((200, cy - 22 - bob), (226, cy - 40 - bob), 26, 21, coat, z0=6, z1=8, k=10)
    hx, hy = 238, cy - 44 - bob
    B.ball((hx, hy), 21, coat, z=10, sq=.92, k=8)
    snout = (hx + 34, hy + 10) if not feline else (hx + 26, hy + 8)
    B.cap((hx + 8, hy + 2), snout, 13, 8 if not feline else 10, _shade(coat, 1.0), z0=12, z1=12, k=6)
    B.ball((snout[0] - 2, snout[1] + 6), 8, belly, z=12, sq=.7, k=4, spec=.1)
    B.ball(snout, 4.5, (30, 26, 26), z=17, k=1, spec=.6, fur=0)                 # nose
    # ears
    er = 7 if not feline else 6
    B.cap((hx - 8, hy - 14), (hx - 10, hy - 34 + (8 if feline else 0)), er, 1.5, coat, z0=8, z1=8, k=2)
    B.cap((hx + 4, hy - 16), (hx + 6, hy - 36 + (8 if feline else 0)), er, 1.5, _shade(coat, .92), z0=12, z1=12, k=2)
    # tail
    if feline:
        pts = [(78, cy - 14 - bob), (52, cy - 6 - bob), (34, cy + 14 - bob), (30, cy + 34 - bob)]
        for a, b in zip(pts, pts[1:]): B.cap(a, b, 9, 8, coat, z0=-2, z1=-2, k=6)
    else:
        pts = [(78, cy - 16 - bob), (50, cy - 2 - bob), (34, cy + 18 - bob)]
        for (a, b), r0, r1 in zip(zip(pts, pts[1:]), (10, 14), (14, 9)): B.cap(a, b, r0, r1, P["mane"] if a == pts[-2] else coat, z0=-2, z1=-2, k=8)
    for (hx_, hy_), s, front in (((106, cy + 8), sw[0], False), ((200, cy + 10), sw[2], True)):
        _leg_paw(B, (hx_, hy_ - bob), s, coat, P, z=16, front=front)
    return (hx, hy)


def _leg_paw(B, hip, s, col, P, z, front):
    hx, hy = hip
    knee = (hx + s * .5 + (2 if front else -8), hy + 42)
    foot = (hx + s * 1.5 + (4 if front else 0), GY - 8 - (6 if s > 0 else 0))
    B.cap((hx, hy - 18), knee, 20 if not front else 16, 10, col, z0=z, z1=z, k=8)
    B.cap(knee, (foot[0] - 2, foot[1] - 4), 9.5, 8, col, z0=z, z1=z, k=4)
    B.cap((foot[0] - 4, foot[1]), (foot[0] + 10, foot[1] + 2), 9, 8, col, z0=z, z1=z, k=4)


def _gryphon(B, P, f, bob, cy):
    coat, white = P["coat"], P["mane"]
    B.ball((108, cy - 2 - bob), 34, coat, z=0, sq=.95, k=10)
    B.cap((108, cy - 2 - bob), (186, cy - 10 - bob), 31, 33, coat, z0=2, z1=4, k=12)
    B.ball((192, cy - 14 - bob), 34, white, z=4, k=12, spec=.12)                 # feathered breast
    B.cap((196, cy - 30 - bob), (224, cy - 58 - bob), 24, 18, white, z0=6, z1=8, k=10, spec=.12)
    hx, hy = 236, cy - 64 - bob
    B.ball((hx, hy), 19, white, z=10, k=8, spec=.12)
    # tucked legs (it flies): front talons and hind paws under the body
    B.cap((198, cy + 18 - bob), (214, cy + 46 - bob), 10, 7, (232, 176, 50), z0=12, z1=12, k=4, spec=.4, fur=0)
    B.cap((112, cy + 20 - bob), (98, cy + 44 - bob), 13, 9, coat, z0=12, z1=12, k=6)
    # tail with a tuft
    B.cap((78, cy - 4 - bob), (40, cy + 12 - bob), 7, 5, coat, z0=-2, z1=-2, k=4)
    B.ball((34, cy + 16 - bob), 11, _shade(coat, .7), z=-2, k=4)
    return (hx, hy)


def _reptile(B, P, f, bob, cy, flying):
    coat, belly = P["coat"], P["belly"]
    far = _shade(coat, .78)
    B.cap((96, cy - 4 - bob), (184, cy - 10 - bob), 30, 34, coat, z0=2, z1=4, k=12, spec=.35)
    B.cap((108, cy + 16 - bob), (184, cy + 14 - bob), 16, 20, belly, z0=10, z1=10, k=10, spec=.25)
    # tail tapering to a spade
    pts = [(96, cy - 2 - bob), (64, cy + 12 - bob), (36, cy + 6 - bob), (14, cy - 8 - bob)]
    for (a, b), r0, r1 in zip(zip(pts, pts[1:]), (26, 16, 10), (16, 10, 5)): B.cap(a, b, r0, r1, coat, z0=0, z1=-2, k=8, spec=.35)
    # long neck curving up
    pts = [(188, cy - 18 - bob), (212, cy - 44 - bob), (230, cy - 72 - bob), (246, cy - 88 - bob)]
    for (a, b), r0, r1 in zip(zip(pts, pts[1:]), (24, 18, 15), (18, 15, 13)): B.cap(a, b, r0, r1, coat, z0=6, z1=8, k=8, spec=.35)
    hx, hy = 256, cy - 92 - bob
    B.ball((hx, hy), 17, coat, z=10, sq=.85, k=6, spec=.35)
    B.cap((hx + 6, hy + 2), (hx + 44, hy + 8), 12, 7, coat, z0=10, z1=10, k=6, spec=.35)     # snout
    B.cap((hx + 4, hy + 12), (hx + 40, hy + 14), 7, 4, belly, z0=11, z1=11, k=3, spec=.25)  # jaw
    # horns
    B.cap((hx - 4, hy - 12), (hx - 30, hy - 32), 5, 1.5, (226, 214, 186), z0=8, z1=8, k=1, spec=.6, fur=0)
    B.cap((hx + 6, hy - 14), (hx - 16, hy - 40), 5, 1.5, (236, 224, 196), z0=12, z1=12, k=1, spec=.6, fur=0)
    if not flying:
        sw = _legs_for(f)
        for (hx_, hy_), s, z, c in (((112, cy + 10), sw[1], -10, far), ((180, cy + 10), sw[3], -10, far),
                                    ((114, cy + 12), sw[0], 16, coat), ((182, cy + 12), sw[2], 16, coat)):
            _leg_paw(B, (hx_, hy_ - bob), s, c, P, z=z, front=hx_ > 150)
    else:
        B.cap((114, cy + 22 - bob), (104, cy + 46 - bob), 11, 8, coat, z0=14, z1=14, k=6, spec=.35)
        B.cap((180, cy + 22 - bob), (192, cy + 44 - bob), 10, 7, coat, z0=14, z1=14, k=6, spec=.35)
    return (hx, hy)


# ------------------------------------------------------------------------------------------- 2D details on top
def _hair(S, root_pts, tip_pts, col, width=3, n=26, seed=1, wave=0.0):
    """A lock of hair: many strands from a root line to a tip line, shaded dark to light with a highlight."""
    import random as _r
    rr = _r.Random(seed)
    for i in range(n):
        u = i / max(1, n - 1)
        a = root_pts[min(len(root_pts) - 1, int(u * (len(root_pts) - 1)))]
        b = tip_pts[min(len(tip_pts) - 1, int(u * (len(tip_pts) - 1)))]
        jx, jy = rr.uniform(-2.5, 2.5), rr.uniform(-2, 2)
        m = ((a[0] + b[0]) / 2 + jx + math.sin(u * 7 + wave) * 3, (a[1] + b[1]) / 2 + jy)
        f = .62 + .5 * rr.random()
        c = _shade(col, f)
        pygame.draw.lines(S, c, False, [a, m, (b[0] + jx, b[1] + jy)], width)
    for i in range(0, n, 4):          # highlights
        u = i / max(1, n - 1)
        a = root_pts[min(len(root_pts) - 1, int(u * (len(root_pts) - 1)))]
        b = tip_pts[min(len(tip_pts) - 1, int(u * (len(tip_pts) - 1)))]
        pygame.draw.line(S, _shade(col, 1.6) + (150,), a, ((a[0] * 2 + b[0]) / 3, (a[1] * 2 + b[1]) / 3), 1)


def wing3d(S, root, col, mem, bat, flap, scale=1.0):
    """1.0.19: a shaded wing.  Feathered (gryphon, pegasus): rows of coverts, secondaries and long primaries, each feather
    lit along its length.  Bat-winged (wyvern, drake): finger bones with a translucent membrane that darkens toward the trailing
    edge.  flap 0..3 raises and lowers the wing."""
    rx, ry = root
    lift = (-1.0, -.35, .35, -.35)[flap % 4]
    span = 92 * scale
    tip_ang = math.radians(-128 + lift * 30)                      # pointing up and back (kept inside the canvas)
    def pt(a, r): return (rx + math.cos(a) * r, ry + math.sin(a) * r)
    if bat:
        elbow = pt(tip_ang + .25, span * .38)
        fingers = [tip_ang - .05, tip_ang - .45, tip_ang - .85, tip_ang - 1.25]
        tips = [(elbow[0] + math.cos(a) * span * (.75 - i * .08), elbow[1] + math.sin(a) * span * (.75 - i * .08)) for i, a in enumerate(fingers)]
        L = pygame.Surface(S.get_size(), pygame.SRCALPHA)
        for i in range(len(tips) - 1):                            # membrane panels, darker toward the trailing edge
            poly = [elbow, tips[i], ((tips[i][0] + tips[i + 1][0]) / 2, (tips[i][1] + tips[i + 1][1]) / 2 + 14 * scale), tips[i + 1]]
            f = .78 + i * .08
            pygame.draw.polygon(L, _shade(mem, f) + (225,), poly)
        pygame.draw.polygon(L, _shade(mem, .7) + (225,), [root, elbow, tips[-1], (rx - 40 * scale, ry + 10)])
        S.blit(L, (0, 0))
        for t_ in tips: pygame.draw.line(S, _shade(col, .8), elbow, t_, max(2, int(4 * scale)))       # finger bones
        pygame.draw.line(S, _shade(col, 1.1), root, elbow, max(3, int(8 * scale)))                     # arm
        pygame.draw.line(S, _shade(col, 1.4), (root[0], root[1] - 2), (elbow[0], elbow[1] - 2), 2)
        pygame.draw.polygon(S, (230, 220, 190), [(elbow[0] - 3, elbow[1]), (elbow[0] + 3, elbow[1]), (elbow[0], elbow[1] - 10)])
        return
    # feathered: a solid wing (arm, hand) with overlapping rows of broad feathers, primaries longest at the tip
    wrist = pt(tip_ang + .55, span * .42)
    tipp = (wrist[0] + math.cos(tip_ang - .15) * span * .62, wrist[1] + math.sin(tip_ang - .15) * span * .62)
    def feathers(n, start, end, length, width, tone, from_arm):
        for i in range(n):
            u = i / max(1, n - 1)
            if from_arm: bx, by = (wrist[0] + (rx - wrist[0]) * u, wrist[1] + (ry - wrist[1]) * u)
            else: bx, by = (tipp[0] + (wrist[0] - tipp[0]) * u, tipp[1] + (wrist[1] - tipp[1]) * u)
            ang = start + (end - start) * u
            Ln = length * (1.0 - .25 * u if not from_arm else .8 + .2 * (1 - u))
            dx, dy = math.cos(ang), math.sin(ang); nx, ny = -dy, dx
            w_ = width
            tip = (bx + dx * Ln, by + dy * Ln)
            poly = [(bx - nx * w_ * .5, by - ny * w_ * .5), (bx + nx * w_ * .5, by + ny * w_ * .5),
                    (tip[0] + nx * w_ * .45, tip[1] + ny * w_ * .45), (tip[0] + dx * w_ * .5, tip[1] + dy * w_ * .5), (tip[0] - nx * w_ * .35, tip[1] - ny * w_ * .35)]
            c = _shade(col, tone * (.92 + .16 * (1 - u)))
            pygame.draw.polygon(S, _shade(c, .7), [(x_ + 1, y_ + 2) for x_, y_ in poly])     # soft shadow under each feather
            pygame.draw.polygon(S, c, poly)
            pygame.draw.line(S, _shade(c, 1.22), (bx, by), tip, 1)                          # shaft
            pygame.draw.line(S, _shade(c, .72), poly[1], poly[2], 1)                         # shaded edge
    down = tip_ang + 1.65                                                # feathers hang back and down from the leading edge
    feathers(14, down - .55, down - .1, span * .55, 10 * scale, .92, False)     # primaries along the hand
    feathers(13, down - .05, down + .25, span * .42, 10 * scale, .98, True)     # secondaries along the arm
    feathers(12, down - .25, down + .1, span * .26, 9 * scale, 1.06, True)      # coverts on top
    pygame.draw.line(S, _shade(col, 1.12), root, wrist, max(5, int(11 * scale)))
    pygame.draw.line(S, _shade(col, 1.12), wrist, tipp, max(3, int(7 * scale)))
    pygame.draw.line(S, _shade(col, 1.35), (root[0], root[1] - 3), (wrist[0], wrist[1] - 3), 2)


def _eye(S, x, y, r=4, iris=(46, 30, 20)):
    pygame.draw.ellipse(S, (18, 12, 10), (x - r - 1, y - r + 1, r * 2 + 2, r * 2 - 1))
    pygame.draw.ellipse(S, iris, (x - r + 1, y - r + 2, r * 2 - 2, r * 2 - 3))
    pygame.draw.circle(S, (250, 250, 250), (int(x + 1), int(y - 1)), max(1, r // 3))


def draw_mount3d(look, frame, flying, wing_fn=None):
    """Returns (surface, seat) on the 2x canvas, like gfx.draw_mount."""
    P = LOOKS[look]
    f = frame % 4 if frame >= 0 else -1
    cy = 126
    bob = 0 if f < 0 else (0, 3, 0, 3)[f]
    seat = (150, cy - 32 - bob)
    S = pygame.Surface((CW, CH), pygame.SRCALPHA)
    B = Body()
    wcol = {"gryphon": (150, 104, 56), "wyvern": (104, 150, 110), "pegasus": (240, 240, 250), "drake": (30, 28, 38)}.get(look)
    mem = {"gryphon": (176, 126, 66), "wyvern": (150, 84, 100), "pegasus": (250, 250, 255), "drake": (120, 26, 26)}.get(look)
    if flying: wing3d(S, (140, cy - 22 - bob), _shade(wcol, .78), _shade(mem, .78), look in ("wyvern", "drake"), f if f >= 0 else 0, .72)
    # tails / manes that sit behind the body
    if look in ("horse", "warhorse", "pegasus"):
        sway = 0 if f < 0 else (-5, 0, 5, 0)[f]
        _hair(S, [(84, cy - 26 - bob), (80, cy - 18 - bob), (78, cy - 10 - bob)],
              [(52 + sway, cy + 50), (60 + sway, cy + 62), (70 + sway, cy + 70)], P["mane"], 2, 70, seed=3, wave=f)
    if look in ("horse", "warhorse", "pegasus"): head = _equine(B, P, f, bob, cy)
    elif look in ("wolf", "saber"): head = _canine(B, P, f, bob, cy, feline=look == "saber")
    elif look == "gryphon": head = _gryphon(B, P, f, bob, cy)
    else: head = _reptile(B, P, f, bob, cy, flying)
    # saddle (part of the 3D body so it is lit with it)
    tack = {"horse": (124, 42, 34), "warhorse": (170, 30, 40), "wolf": (92, 62, 40), "saber": (90, 40, 30), "gryphon": (60, 90, 170),
            "wyvern": (80, 60, 40), "pegasus": (200, 160, 60), "drake": (150, 30, 30)}[look]
    B.ball((150, seat[1] + 8), 30, _shade(tack, .75), z=30, sq=.42, k=2, spec=.12, fur=0)        # saddle cloth
    B.ball((150, seat[1] + 1), 21, (92, 58, 34), z=36, sq=.36, k=2, spec=.55, fur=0)             # leather seat
    B.cap((128, seat[1] + 2), (131, seat[1] - 7), 5, 4, (84, 52, 30), z0=40, z1=40, k=3, spec=.55, fur=0)     # cantle
    B.cap((170, seat[1] + 2), (172, seat[1] - 5), 4, 3, (84, 52, 30), z0=40, z1=40, k=3, spec=.55, fur=0)     # pommel
    if P.get("armour"):          # barding: chanfron, crinet and peytral plates, lit as polished steel
        hx, hy = head
        B.cap((hx - 6, hy - 6), (hx + 26, hy + 14), 14, 10, (196, 200, 210), z0=16, z1=16, k=2, spec=1.0, fur=0)
        B.cap((198, cy - 28), (222, cy - 62), 22, 14, (186, 190, 200), z0=14, z1=16, k=3, spec=1.0, fur=0)
        B.ball((200, cy - 6), 28, (184, 188, 198), z=18, sq=.85, k=3, spec=1.0, fur=0)                # peytral (chest plate)
    if P.get("scales"): B.F *= .0
    body = B.render(seed=sum(map(ord, look)) % 997)
    S.blit(body, (0, 0))
    hx, hy = head
    if P.get("armour"):          # a draped caparison with folds and gold trim over the flank
        top_y = seat[1] + 14; bot_y = cy + 46 - bob
        pts = [(98, top_y + 6), (186, top_y + 2), (194, bot_y - 4), (96, bot_y)]
        pygame.draw.polygon(S, (150, 22, 34), pts)
        for i in range(9):                                      # folds: light and dark vertical bands
            x = 102 + i * 10
            pygame.draw.line(S, (186, 40, 52), (x, top_y + 8), (x - 2, bot_y - 2), 3)
            pygame.draw.line(S, (110, 14, 24), (x + 5, top_y + 10), (x + 4, bot_y - 1), 2)
        pygame.draw.lines(S, (226, 186, 76), False, [(96, bot_y), (145, bot_y + 3), (194, bot_y - 4)], 3)
        pygame.draw.line(S, (226, 186, 76), (98, top_y + 6), (186, top_y + 2), 2)
        cx_ = 146; cy_ = (top_y + bot_y) // 2
        pygame.draw.circle(S, (226, 186, 76), (cx_, cy_), 9, 2); pygame.draw.circle(S, (240, 210, 110), (cx_, cy_), 3)
    # pattern and detail passes
    if P.get("stripes"):          # tiger stripes, kept inside the body's outline
        bodymask = body.copy(); bodymask.fill((255, 255, 255, 0), special_flags=pygame.BLEND_RGBA_MAX)
        st2 = pygame.Surface((CW, CH), pygame.SRCALPHA)
        for i in range(8):
            x = 92 + i * 15
            pygame.draw.polygon(st2, (44, 26, 16, 210), [(x, cy - 40 - bob), (x + 7, cy - 40 - bob), (x + 10, cy - 12 - bob + (i % 2) * 6), (x + 6, cy - 4 - bob)])
        st2.blit(bodymask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        S.blit(st2, (0, 0))
    if P.get("scales"):
        for k in range(120):
            x = 96 + (k * 37) % 96; y = cy - 34 - bob + (k * 53) % 46
            if S.get_at((int(x), int(y)))[3] > 0:
                pygame.draw.arc(S, _shade(P["coat"], .62) + (120,), (x, y, 10, 7), 3.4, 6.1, 1)
        for i in range(9):
            sx = 100 + i * 14
            pygame.draw.polygon(S, _shade(P["mane"], 1.1), [(sx, cy - 36 - bob), (sx + 5, cy - 52 - bob - (i == 4) * 6), (sx + 10, cy - 35 - bob)])
    if look in ("horse", "warhorse", "pegasus"):
        # mane: from the crest of the neck (poll to withers), falling down over the near side
        crest = [(hx - 6 + (186 - (hx - 6)) * t, hy - 12 + ((cy - 40 - bob) - (hy - 12)) * t) for t in [i / 7 for i in range(8)]]
        tips = [(x + 7, y + 26 - 6 * (i / 7)) for i, (x, y) in enumerate(crest)]
        _hair(S, crest, tips, P["mane"], 3, 110, seed=5, wave=f)
        _hair(S, [(hx - 2, hy - 12), (hx + 2, hy - 12)], [(hx + 4, hy + 2), (hx + 8, hy)], P["mane"], 2, 8, seed=6)
        if P.get("blaze"): pygame.draw.line(S, (238, 232, 222), (hx + 8, hy - 8), (hx + 28, hy + 16), 5)
        _eye(S, hx + 8, hy - 2, 4)
        pygame.draw.ellipse(S, (24, 16, 12), (hx + 32, hy + 18, 6, 4))           # nostril
        if look != "warhorse":
            pygame.draw.lines(S, (52, 34, 24), False, [(hx + 30, hy + 12), (hx + 10, hy + 4), (hx - 4, hy - 6)], 3)   # bridle
            pygame.draw.lines(S, (52, 34, 24), False, [(hx + 28, hy + 16), (186, seat[1] - 2)], 2)                       # rein
            pygame.draw.circle(S, (214, 180, 80), (hx + 30, hy + 14), 3)
    elif look in ("wolf", "saber"):
        _eye(S, hx + 14, hy - 6, 4, iris=(214, 176, 60) if look == "wolf" else (220, 200, 90))
        if look == "saber":
            for sx in (hx + 18, hx + 26): pygame.draw.polygon(S, (250, 248, 236), [(sx, hy + 16), (sx + 5, hy + 16), (sx + 2, hy + 38)])
        else:
            _hair(S, [(206, cy - 40 - bob), (196, cy - 30 - bob)], [(214, cy - 10 - bob), (204, cy - 4 - bob)], P["coat"], 2, 14, seed=8)
    elif look == "gryphon":
        pygame.draw.polygon(S, (236, 180, 52), [(hx + 12, hy - 6), (hx + 44, hy + 6), (hx + 30, hy + 12), (hx + 12, hy + 16)])
        pygame.draw.polygon(S, (190, 130, 30), [(hx + 30, hy + 12), (hx + 44, hy + 6), (hx + 38, hy + 16)])
        _eye(S, hx + 6, hy - 6, 5, iris=(240, 180, 40))
        for i in range(6):
            pygame.draw.polygon(S, (230, 222, 206), [(200 + i * 5, cy - 18 - bob - i * 6), (190 + i * 5, cy + 2 - bob - i * 6), (208 + i * 5, cy - 8 - bob - i * 6)])
    else:
        _eye(S, hx + 14, hy - 4, 5, iris=(255, 70, 40) if look == "drake" else (255, 220, 60))
        for tx in (hx + 30, hx + 38): pygame.draw.polygon(S, (250, 248, 236), [(tx, hy + 12), (tx + 4, hy + 12), (tx + 2, hy + 20)])
        if look == "drake": pygame.draw.circle(S, (255, 140, 40), (hx + 44, hy + 8), 4)
    # girth strap and stirrup under the saddle
    if look in ("horse", "warhorse", "pegasus", "wolf", "saber"):
        pygame.draw.line(S, (40, 28, 22), (166, seat[1] + 14), (162, cy + 24 - bob), 5)
        pygame.draw.circle(S, (214, 180, 80), (162, cy + 24 - bob), 4, 2)
        pygame.draw.line(S, (214, 172, 62), (126, seat[1] + 8), (174, seat[1] + 8), 2)
    if flying: wing3d(S, (156, cy - 26 - bob), wcol, mem, look in ("wyvern", "drake"), (f + 1) % 4 if f >= 0 else 0, 1.0)
    if look == "pegasus" and f >= 0:
        for i in range(6): pygame.draw.circle(S, (200, 236, 255), (60 - i * 8, cy + 30 + i * 3), max(1, 4 - i // 2))
    return S, seat
