#!/bin/bash
# Sign a LocSec release with YOUR OWN GnuPG key (5.0-6). This script never creates a key.
#   LOCSEC_SIGN_KEY=<key id or fingerprint> bash sign-release.sh FILE...
# For each FILE it writes FILE.asc (a detached, armored signature) and verifies it straight away.
# Sign the .deb, the source tarball, the guide and locsec-vm-check.sh, then SHA256SUMS-<version>.txt last,
# so the signed checksum file covers everything:  sha256sum FILE... > SHA256SUMS-5.0-6.txt
# To make a release key once (you choose the name, expiry and passphrase; keep the secret key offline or backed up):
#   gpg --quick-generate-key "LocSec release <you@example.org>" ed25519 sign 2y
#   gpg --armor --export <fingerprint> > locsec-release-key.asc     # publish this next to the releases
# To check a download:  gpg --import locsec-release-key.asc && gpg --verify FILE.asc FILE
#   (compare the key's fingerprint with the one published separately - a key you only got from the same place
#   as the files proves nothing).
set -eu
[ -n "${LOCSEC_SIGN_KEY:-}" ] || { echo "set LOCSEC_SIGN_KEY to the id or fingerprint of your signing key" >&2; exit 2; }
command -v gpg >/dev/null || { echo "gpg is not installed (apt install gnupg)" >&2; exit 2; }
gpg --list-secret-keys "$LOCSEC_SIGN_KEY" >/dev/null 2>&1 || { echo "no secret key matches '$LOCSEC_SIGN_KEY' in this keyring" >&2; exit 2; }
[ $# -gt 0 ] || { echo "usage: LOCSEC_SIGN_KEY=KEYID $0 FILE..." >&2; exit 2; }
for f in "$@"; do
  [ -f "$f" ] || { echo "not a file: $f" >&2; exit 2; }
  rm -f -- "$f.asc"
  gpg --batch --yes --local-user "$LOCSEC_SIGN_KEY" --armor --detach-sign --output "$f.asc" -- "$f"
  gpg --verify "$f.asc" "$f" 2>&1 | grep -E "Good signature|BAD" || { echo "verification failed for $f" >&2; exit 1; }
  echo "signed: $f.asc"
done
