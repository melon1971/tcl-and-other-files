#!/usr/bin/env python3
"""5.0-5: CVE report wording and status, and the ClamAV "OUTDATED" explanation.

No root needed; nothing on the system is touched. The functions under test are taken out of
locsecd.py by name (importing the whole file reads /etc/locsecd), so this runs anywhere.

Found on Debian 13 with 5.0-3: the CVE report's "APT security candidates" heading read OK above a
pending-update warning, and its advice ("Press Update system ... LocSec also installs security
updates by itself") was wrong for claude-desktop, a package from a third-party repository that
neither the automatic updates nor Update system install while update_security_only is true.

    python3 test_reports_505.py PATH/locsecd.py
"""
import ast, re, sys
from pathlib import Path

PATH = sys.argv[1] if len(sys.argv) > 1 else '/usr/lib/locsecd/locsecd.py'
src = open(PATH, encoding='utf-8').read()
tree = ast.parse(src)

def take(*names):
    out = []
    for n in tree.body:
        nm = getattr(n, 'name', None)
        if nm is None and isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name): nm = n.targets[0].id
        if nm in names: out.append(ast.get_source_segment(src, n))
    return '\n'.join(out)

passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('ok  ', name)
    else: failed += 1; print('FAIL', name, detail)

CFG = {}
ns = {'re': re, 'Path': Path, 'CFG': CFG}
exec(take('_APT_INST_RE', '_apt_parse_pending', 'explain_result'), ns)
check('shared apt parser exists', '_apt_parse_pending' in ns)

SIM = """NOTE: This is only a simulation!
Inst claude-desktop [2.26454.2] (2.31226.0 Anthropic:stable [amd64])
Inst libssl3t64 [3.5.1-1] (3.5.1-1+deb13u1 Debian-Security:13/stable-security [amd64])
Inst libnew1 (1.0-1 Debian:13/stable [amd64])
Conf claude-desktop (2.31226.0 Anthropic:stable [amd64])
"""
p = ns['_apt_parse_pending'](SIM) if '_apt_parse_pending' in ns else []
check('two upgrades, the new dependency left out', [x[0] for x in p] == ['claude-desktop', 'libssl3t64'], p)
check('claude-desktop is not a security update', p and p[0][4] is False and p[0][3] == ['Anthropic:stable'])
check('libssl3t64 is a security update', len(p) > 1 and p[1][4] is True)

def items(out, **cfg):
    CFG.clear(); CFG.update(cfg)
    return ns['explain_result']({'name': 'APT security candidates', 'output': out, 'status': 'warning'})

it = items(SIM, update_security_only=True, auto_update=True)
sec = [i for i in it if 'security update' in i['title']]
oth = [i for i in it if 'other update' in i['title']]
check('security updates listed as a warning', sec and sec[0]['lvl'] == 'warn' and 'libssl3t64' in sec[0]['text'])
check('other updates listed as information, with their origin', oth and oth[0]['lvl'] == 'info' and 'claude-desktop (from Anthropic:stable)' in oth[0]['text'])
check('and the advice says Update system does not install them', oth and 'does not install them' in oth[0]['fix'] and 'sudo apt upgrade' in oth[0]['fix'])
check('no claim that LocSec installs a third-party package', not any('claude-desktop' in i['text'] and 'by itself' in i['fix'] for i in it))

it = items('Inst claude-desktop [2.26454.2] (2.31226.0 Anthropic:stable [amd64])\n', update_security_only=False, auto_update=True)
check('with update_security_only false, other updates go through Update system', it and 'Update system' in it[0]['fix'] and 'by itself' in it[0]['fix'])
it = items(SIM, update_security_only=True, auto_update=False)
check('with auto_update false, nothing promises Update system installs them',
      it and all('auto_update is false' in i['fix'] for i in it if 'security update' in i['title']))
it = items('NOTE: This is only a simulation!\n', update_security_only=True)
check('nothing pending: up to date', any(i['title'] == 'Up to date' for i in it))

cve = take('cve_scan')
check('APT security candidates gets a status of its own', re.search(r"'name':'APT security candidates','rc':rc,'status':st", cve) is not None)
check('status: warning for security, info for other, ok for none',
      "'warning' if any(p[4] for p in pend) else 'info' if pend else 'ok'" in cve)

FRESH = """Fri Oct  9 11:07:17 2026 -> ClamAV update process started at Fri Oct  9 11:07:17 2026
WARNING: Fri Oct  9 11:07:18 2026 -> Your ClamAV installation is OUTDATED!
WARNING: Fri Oct  9 11:07:18 2026 -> Local version: 1.4.3 Recommended version: 1.4.6
Fri Oct  9 11:07:18 2026 -> DON'T PANIC! Read https://docs.clamav.net/manual/Installing.html
Fri Oct  9 11:07:18 2026 -> daily.cld database is up-to-date (version: 28148, sigs: 355740, f-level: 90, builder: svc.clamav-publisher)
"""
it = ns['explain_result']({'name': 'ClamAV definitions', 'status': 'up-to-date', 'rc': 0, 'output': FRESH})
eng = [i for i in it if 'engine' in i['title'].lower()]
check('freshclam OUTDATED is explained', eng and eng[0]['lvl'] == 'info' and '1.4.3' in eng[0]['text'] and '1.4.6' in eng[0]['text'])
check('and the definitions are still reported up to date', any(i['title'] == 'Already up to date' for i in it))
it = ns['explain_result']({'name': 'rkhunter definitions', 'status': 'up-to-date', 'rc': 0, 'output': 'Checking file i18n/en [ No update ]'})
check('rkhunter definitions are unaffected', [i['title'] for i in it] == ['Already up to date'])

print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)
