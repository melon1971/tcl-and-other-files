#!/usr/bin/python3
"""5.0-11: apparmor-utils and libcap2-bin are recommended, and the docs say where aa-enforce comes from. No root needed.
Usage: test_5011.py path/to/locsecd.py"""
import sys, os, re
HERE = os.path.dirname(os.path.abspath(sys.argv[1])); ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
rd = lambda p: open(os.path.join(ROOT, p)).read()
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
ctl = rd('DEBIAN/control')
rec = re.search(r'^Recommends:\s*(.*)$', ctl, re.M).group(1)
dep = re.search(r'^Depends:\s*(.*)$', ctl, re.M).group(1)
check('apparmor-utils is recommended', 'apparmor-utils' in rec)
check('libcap2-bin is recommended', 'libcap2-bin' in rec)
check('suricata-update is still recommended', 'suricata-update' in rec)
check('they are recommends, not hard dependencies', 'apparmor-utils' not in dep and 'libcap2-bin' not in dep)
check('the control file version is 5.0-12', re.search(r'^Version: 5\.0-12$', ctl, re.M) is not None)
check('README.Debian says where aa-enforce comes from', 'apparmor-utils' in rd('usr/share/doc/locsecd/README.Debian') and 'aa-enforce' in rd('usr/share/doc/locsecd/README.Debian'))
check('the AppArmor profile header says where aa-enforce comes from', 'come from the apparmor-utils package' in rd('etc/apparmor.d/locsecd'))
check('the changelog exists', os.path.exists(os.path.join(ROOT, 'usr/share/doc/locsecd/CHANGELOG-5.0-11')))
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
