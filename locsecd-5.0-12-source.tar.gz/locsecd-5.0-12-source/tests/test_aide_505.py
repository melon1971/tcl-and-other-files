#!/usr/bin/env python3
"""5.0-5: AIDE explains more of what a normal week of updates changes, and its commands are whole.

No root needed; nothing on the system is touched. The functions under test are taken out of
locsecd.py by name. The update-alternatives check uses this machine's own alternatives database
when it has the plzip link group (the tester's machine), and is skipped otherwise.

Found on Debian 13 with 5.0-3 (29 unexplained files after a week): LocSec's own AppArmor drop-ins,
update-alternatives links (lzip), files written by package setup scripts (claude-desktop's AppArmor
profile and apt source, libxml-sax-perl's ParserDetails.ini) and CUPS's printers.conf.O were all
"unexplained"; ~/.gnupg was called "a start-up or login file"; and the suggested commands for
locsecd*.service.d/locsec-apparmor.conf lost the end of the path (".service." and "locsec-apparmor.").

    python3 test_aide_505.py PATH/locsecd.py
"""
import ast, os, re, shlex, sys, tempfile
from pathlib import Path

PATH = sys.argv[1] if len(sys.argv) > 1 else '/usr/lib/locsecd/locsecd.py'
src = open(PATH, encoding='utf-8').read()
tree = ast.parse(src)
def take(*names):
    out = []
    for n in tree.body:
        nm = getattr(n, 'name', None)
        if nm is None and isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name): nm = n.targets[0].id
        if nm in names: out.append(ast.get_source_segment(src, n))
    return '\n'.join(out)

passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('ok  ', name)
    else: failed += 1; print('FAIL', name, detail)

NAMES = ('_aide_derived_from', '_alternatives_known', '_AIDE_SCRIPT_CACHE', '_DPKG_INFO', '_aide_script_writer', 'glob_escape',
         '_AIDE_SELF_BACKUP', '_aide_locsec_file', '_AA_CLAMD_LOCAL', '_AIDE_HOME_STARTUP', '_aide_home_what')
code = take(*NAMES)
ns = {'re': re, 'os': os, 'Path': Path}
exec(code, ns)
for n in NAMES:
    check(f'{n} exists', n in ns)
if failed:
    print(f'{passed} passed, {failed} failed'); sys.exit(1)

# LocSec's own drop-ins
for p in ('/etc/systemd/system/locsecd.service.d', '/etc/systemd/system/locsecd.service.d/locsec-apparmor.conf',
          '/etc/systemd/system/locsecd-broker.service.d', '/etc/systemd/system/locsecd-broker.service.d/locsec-apparmor.conf'):
    check(f"LocSec's own file: {p}", ns['_aide_locsec_file'](p))
check('a stranger drop-in is not LocSec\'s', not ns['_aide_locsec_file']('/etc/systemd/system/ssh.service.d/evil.conf'))

# Setup scripts, with a stand-in /var/lib/dpkg/info
with tempfile.TemporaryDirectory() as d:
    info = Path(d)
    (info / 'claude-desktop.postinst').write_text('APPARMOR_DIR="$ROOT/etc/apparmor.d"\nPROFILE_NAME="claude-desktop"\n'
                                                  'echo deb ... > /etc/apt/sources.list.d/claude-desktop.list\n')
    (info / 'libxml-sax-perl.postinst').write_text('update-perl-sax-parsers --add ... # /etc/perl/XML/SAX/ParserDetails.ini\n')
    (info / 'ibverbs-providers:amd64.postinst').write_text('rm -rf /etc/libibverbs.d.old\n')
    ns['_DPKG_INFO'] = d; ns['_AIDE_SCRIPT_CACHE'].clear()
    pk = ['claude-desktop', 'libxml-sax-perl', 'ibverbs-providers']
    w = ns['_aide_script_writer']
    check('apt source named in the script', w('/etc/apt/sources.list.d/claude-desktop.list', pk) == 'claude-desktop')
    check('AppArmor profile: folder and name in the script', w('/etc/apparmor.d/claude-desktop', pk) == 'claude-desktop')
    check('ParserDetails.ini named in the script', w('/etc/perl/XML/SAX/ParserDetails.ini', pk) == 'libxml-sax-perl')
    check('its new folder too', w('/etc/perl/XML/SAX', pk) == 'libxml-sax-perl' and w('/etc/perl/XML', pk) == 'libxml-sax-perl')
    check('package script files with :arch are read', w('/etc/libibverbs.d.old', pk) == 'ibverbs-providers')
    check('a file no script names stays unexplained', w('/etc/apparmor.d/totally-new', pk) == '')
    check('a name in the script but another folder does not count', w('/etc/cron.d/claude-desktop', pk) == '')
    check('only packages changed since the snapshot are asked', w('/etc/apt/sources.list.d/claude-desktop.list', ['bash']) == '')
    ns['_DPKG_INFO'] = '/var/lib/dpkg/info'; ns['_AIDE_SCRIPT_CACHE'].clear()

# CUPS backups
check('printers.conf.O is a CUPS backup', bool(ns['_AIDE_SELF_BACKUP'].match('/etc/cups/printers.conf.O')))
check('but not any .O file', not ns['_AIDE_SELF_BACKUP'].match('/etc/cups/cupsd.conf.O.sh'))

# Home folders
st = ns['_AIDE_HOME_STARTUP']
check('~/.config/autostart is a start-up place', bool(st.search('/home/smullen/.config/autostart')) and bool(st.search('/home/smullen/.config/autostart/x.desktop')))
check('~/.bashrc is a start-up file', bool(st.search('/home/smullen/.bashrc')))
check('~/.gnupg is not', not st.search('/home/smullen/.gnupg') and not st.search('/home/smullen/.gnupg/pubring.kbx'))
check('~/.gnupg is described as the GnuPG keyring', 'GnuPG' in ns['_aide_home_what']('/home/smullen/.gnupg/trustdb.gpg'))

# The quarantine sentence is removed without cutting a path
blk = take('analyze_aide_report', 'aide_explain', '_aide_records')
fixsrc = re.search(r"kept=\[x for x in re\.split\(r'\(\?<=\\\.\)\\s\+',fix\)", src)
check('sentence split ignores dots inside paths', fixsrc is not None)
q = shlex.quote('/etc/systemd/system/locsecd-broker.service.d/locsec-apparmor.conf')
fix = (f'If you or a program you installed made it, nothing to fix. If you do not know it, look at it: sudo ls -la {q}  (for a file: sudo head -n 20 {q}). '
       'If it is still a mystery, quarantine it on the Malware / Quarantine page.')
kept = [x for x in re.split(r'(?<=\.)\s+', fix) if x.strip() and 'quarantine' not in x.lower()]
out = ' '.join(kept) + ' Do not quarantine it: the system needs this file.'
check('the path survives whole', out.count('locsec-apparmor.conf') == 2 and src.count('(for a file: sudo head -n 20 {q}). ') == 1 and 'Do not quarantine it' in out and 'Malware' not in out, out)

# update-alternatives, on this machine
if Path('/var/lib/dpkg/alternatives/lzip').is_file() and os.path.islink('/etc/alternatives/lzip'):
    b, how = ns['_aide_derived_from']('/etc/alternatives/lzip')
    check('/etc/alternatives/lzip ends at a real program', b and not b[0].startswith('/etc/alternatives/') and 'alternatives' in how, (b, how))
    b2, _ = ns['_aide_derived_from']('/usr/bin/lzip')
    check('/usr/bin/lzip (pointing into /etc/alternatives) too', b2 == b, (b2, b))
    b3, _ = ns['_aide_derived_from']('/etc/alternatives/lzip.1.gz')
    check('a follower link (manual page) too', b3 and b3[0].endswith('.gz'), b3)
else:
    print('skip  update-alternatives checks (no lzip link group on this machine)')
check('a path that is not a link is not derived', ns['_aide_derived_from']('/etc/hostname') == ([], ''))

print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)
