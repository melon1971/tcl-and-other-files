#!/usr/bin/env python3
"""5.0-5: one wrong local password is one "Wrong password" line in LocSec's log, with its user.

No root needed; nothing on the system is touched. The functions under test are taken out of
locsecd.py by name.

On 5.0-3 one mistyped password at 9:46 showed twice on the LocSec log page: 'A login as
"smullen" was refused' (the PAM "authentication failure" line) and 'A login as someone was
refused' (unix_chkpwd's "password check failed for user (smullen)", which has no user= field).

    python3 test_auth_505.py PATH/locsecd.py
"""
import ast, hashlib, ipaddress, re, sys

PATH = sys.argv[1] if len(sys.argv) > 1 else '/usr/lib/locsecd/locsecd.py'
src = open(PATH, encoding='utf-8').read()
tree = ast.parse(src)
def take(*names):
    out = []
    for n in tree.body:
        nm = getattr(n, 'name', None)
        if nm is None and isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name): nm = n.targets[0].id
        if nm in names: out.append(ast.get_source_segment(src, n))
    return '\n'.join(out)

passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('ok  ', name)
    else: failed += 1; print('FAIL', name, detail)

LOG = []
def safe_ip(x):
    try: return ipaddress.ip_address(x)
    except ValueError: return None
ns = {'re': re, 'hashlib': hashlib, 'CFG': {}, 'AUTHSEEN': None, 'safe_ip': safe_ip,
      '_load_seen': lambda p: {}, '_remember_seen': lambda p, s: None,
      'log': lambda m, lvl='INFO': LOG.append((lvl, m))}
exec(take('_P', '_SSHD_ADDR', '_PAM_SSHD', '_auth_parse', '_auth_ip', '_auth_details', '_AUTH_COMPANION', 'record_auth_events'), ns)

PAM = 'pam_unix(sudo:auth): authentication failure; logname=smullen uid=1000 euid=0 tty=/dev/pts/2 ruser=smullen rhost=  user=smullen'
CHK = 'password check failed for user (smullen)'
ev = lambda msg, kind='auth-failure': {'kind': kind, 'line': 'Oct  9 09:46:01 debian x: ' + msg, 'msg': msg, 'trusted': True}

ns['record_auth_events']([ev(PAM), ev(CHK)])
deny = [m for l, m in LOG if m.startswith('denied authentication attempt')]
check('one wrong password is logged once', len(deny) == 1, deny)
check('and names the user', deny == ['denied authentication attempt user=smullen'], deny)

LOG.clear()
ns['record_auth_events']([ev('unix_chkpwd[4242]: password check failed for user (smullen)')])
check('the unix_chkpwd line with its prefix is skipped too', not LOG, LOG)

check('a "for user (NAME)" line still gets its user', ns['_auth_details'](CHK)[0] == 'smullen')

LOG.clear()
ns['record_auth_events']([ev('Failed password for invalid user admin from 203.0.113.9 port 4242 ssh2')])
check('an SSH failure is still logged with user and address',
      LOG == [('WARN', 'denied authentication attempt user=admin from=203.0.113.9')], LOG)

LOG.clear()
ns['record_auth_events']([ev('pam_unix(sudo:session): session opened for user root(uid=0) by smullen(uid=1000)', 'auth-success')])
check('a success is still logged', LOG and LOG[0][1].startswith('successful authentication'), LOG)

print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)
