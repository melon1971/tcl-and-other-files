#!/usr/bin/python3
"""5.0-7 checks, no root needed: notifications off by default with Enable/Disable buttons, the window no
longer kept off the taskbar, rkhunter "file properties changed" classification, the AppArmor profile.
Usage: test_507.py path/to/locsecd.py"""
import sys, os, re, importlib.util, shutil, subprocess
os.environ['LOCSEC_INPROCESS_BROKER'] = '1'
HERE = os.path.dirname(os.path.abspath(sys.argv[1]))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
spec = importlib.util.spec_from_file_location('locsecd_507', sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
src = open(sys.argv[1]).read(); gui = open(os.path.join(HERE, 'locsec-gui.py')).read()
prof = open(os.path.join(ROOT, 'etc/apparmor.d/locsecd')).read()
# --- notifications
check('every desktop notification kind is off by default', m.DEFAULTS['notify_on'] and not any(m.DEFAULTS['notify_on'].values()))
check('the defaults cover every kind the dashboard offers', set(m.DEFAULTS['notify_on']) == set(m._NOTIFY_KINDS))
check('dashboard has an Enable notifications button', 'setAllNotify(true)">Enable notifications</button>' in src)
check('dashboard has a Disable notifications button', 'setAllNotify(false)">Disable notifications</button>' in src)
check('dashboard says notifications are off until enabled', 'Notifications are off until you enable them.' in src)
check('panel icon pop-ups are gated by the user preference', gui.count('_panel_notifications_on()') >= 3)
check('panel icon menu has Enable and Disable notifications', "'Enable notifications'" in gui and "'Disable notifications'" in gui)
# --- window
check('the window is no longer kept off the taskbar (no skip-taskbar code left)', 'SKIP_TASKBAR' not in gui and '_skip_taskbar' not in gui and 'SKIP_PAGER' not in gui)
check('XWayland is no longer forced on Wayland', "os.environ['QT_QPA_PLATFORM']='xcb'" not in gui)
check('nothing hides the window when another window is clicked', not re.search(r'applicationStateChanged|focusChanged|WindowDeactivate|ApplicationInactive', gui))
check('closing the window still hides it to the panel icon', 'self.hide(); self.controller.hidden_to_tray()' in gui)
# --- rkhunter
real = m._dpkg_file_intact
blk = ["Warning: The file properties have changed:", "         File: /usr/bin/su", "         Current hash: aa", "         Stored hash : bb"]
m._dpkg_file_intact = lambda p: p == '/usr/bin/su'
ok, why = m._rkhunter_classify(blk)
check('rkhunter: properties changed on a package file that verifies is informational', ok and 'verifies unmodified' in why)
m._dpkg_file_intact = lambda p: False
check('rkhunter: properties changed on a file that does not verify still needs review', not m._rkhunter_classify(blk)[0])
m._dpkg_file_intact = lambda p: True
check('rkhunter: a block naming two files is never waved through', not m._rkhunter_classify(["Warning: The file properties have changed:", "         File: /usr/bin/su", "         File: /usr/bin/login"])[0])
check('rkhunter: a block with no file is never waved through', not m._rkhunter_classify(["Warning: The file properties have changed:", "         Current hash: aa"])[0])
check("rkhunter: a new member of the sudo group still needs review", not m._rkhunter_classify(["Warning: Changes found in the group file for group 'sudo':", "         User 'smullen' has been added to the group"])[0])
m._dpkg_file_intact = real
calls = []
def fake_broker(verb, **kw): calls.append(kw.get('pkg')); return 0, ''
m.broker = fake_broker; m._PKGV_CACHE.clear()
m.run = lambda argv, t=20, *a, **k: (0, 'coreutils: /usr/bin/su\n')
real(  '/usr/bin/su'); real('/usr/bin/su')
check('rkhunter: dpkg --verify runs once per package per scan', calls.count('coreutils') == 1)
m._PKGV_CACHE.clear()
# --- AppArmor profile
check('web profile runs its helpers with ix (NoNewPrivileges forbids the child-profile transition)', 'Cx -> helpers' not in prof and '/usr/bin/journalctl ix,' in prof and 'profile helpers' not in prof)
for rule in ('/home/ r,', '/usr/bin/nmcli ix,', '/usr/bin/nice ix,', '/usr/bin/ionice ix,', '/usr/bin/debsecan rix,', '/usr/bin/dpkg ix,', '/etc/dpkg/** r,', '/usr/share/dpkg/** r,', '/var/log/journal/ r,', '/run/log/journal/ r,', '/sys/block/ r,', '/var/lib/suricata/** r,', '/usr/bin/pgrep ix,', '/usr/bin/lsblk ix,', 'ptrace read peer=unconfined,', '/proc/ r,'):
    check(f'profile has: {rule}', rule in prof)
ap = shutil.which('apparmor_parser') or ('/usr/sbin/apparmor_parser' if os.path.exists('/usr/sbin/apparmor_parser') else None)
if ap:
    r = subprocess.run([ap, '-Q', '-K', os.path.join(ROOT, 'etc/apparmor.d/locsecd')], capture_output=True, text=True)
    check('apparmor_parser accepts the profile', r.returncode == 0)
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
