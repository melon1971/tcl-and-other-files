#!/usr/bin/env python3
"""5.0-5: the daemon reads its addresses and default routes from /proc/net instead of running "ip".

No root needed; nothing on the system is touched. The functions under test are taken out of
locsecd.py by name and given sample /proc/net files.

"ip" always failed inside locsecd.service with rc=1 and no output: iproute2 drops its
capabilities with capset() at start, which the unit's SystemCallFilter=~@privileged refuses.
So every start logged '"ip -o addr show" gave no address', and the Suricata interface check
(follow the default route) never found a default route. Reproduced on Debian 13 with
systemd-run: ip works with SystemCallFilter=~@privileged plus capset, and fails without it.

    python3 test_netinfo_505.py PATH/locsecd.py
"""
import ast, ipaddress, re, struct, sys
from pathlib import Path as RealPath

PATH = sys.argv[1] if len(sys.argv) > 1 else '/usr/lib/locsecd/locsecd.py'
src = open(PATH, encoding='utf-8').read()
tree = ast.parse(src)
def take(*names):
    return '\n'.join(ast.get_source_segment(src, n) for n in tree.body if getattr(n, 'name', None) in names)

passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('ok  ', name)
    else: failed += 1; print('FAIL', name, detail)

FILES = {}
class FakePath:
    def __init__(self, p): self.p = str(p)
    def read_text(self):
        if self.p not in FILES: raise FileNotFoundError(self.p)
        return FILES[self.p]

ns = {'Path': FakePath, 'ipaddress': ipaddress, 'struct': struct}
code = take('_proc_default_routes', '_ids_default_iface')
check('_proc_default_routes exists', '_proc_default_routes' in code)
if code: exec(code, ns)
code = code if '_proc_default_routes' in ns else ''

HDR = 'Iface\tDestination\tGateway \tFlags\tRefCnt\tUse\tMetric\tMask\t\tMTU\tWindow\tIRTT\n'
# The tester's machine: default via 192.168.0.1 dev wlo1 metric 600, plus its subnet route.
FILES['/proc/net/route'] = HDR + 'wlo1\t00000000\t0100A8C0\t0003\t0\t0\t600\t00000000\t0\t0\t0\nwlo1\t0000A8C0\t00000000\t0001\t0\t0\t600\t00FFFFFF\t0\t0\t0\n'
FILES['/proc/net/ipv6_route'] = ''
if code:
    check('the tester machine: wlo1 via 192.168.0.1', ns['_proc_default_routes']() == [(600, 'wlo1', '192.168.0.1')], ns['_proc_default_routes']())
    check('Suricata follows wlo1', ns['_ids_default_iface']() == 'wlo1')

# Wired and wireless both up: the lower metric wins. A route that is down is ignored.
FILES['/proc/net/route'] = HDR + ('wlo1\t00000000\t0100A8C0\t0003\t0\t0\t600\t00000000\t0\t0\t0\n'
                                  'enp3s0\t00000000\t0101A8C0\t0003\t0\t0\t100\t00000000\t0\t0\t0\n'
                                  'eth9\t00000000\t0102A8C0\t0002\t0\t0\t1\t00000000\t0\t0\t0\n')
# IPv6: a default via fe80::1 on enp3s0, and the kernel's "unreachable" default on lo.
z = '0' * 32
FILES['/proc/net/ipv6_route'] = (f'{z} 00 {z} 00 fe800000000000000000000000000001 00000400 00000001 00000000 00000003 enp3s0\n'
                                 f'{z} 00 {z} 00 {z} ffffffff 00000001 00000000 00200200 lo\n'
                                 f'20010db8000000000000000000000000 40 {z} 00 {z} 00000100 00000001 00000000 00000001 enp3s0\n')
if code:
    r = ns['_proc_default_routes']()
    check('IPv4 by metric, the down route left out', [x[1] for x in r if '.' in x[2]] == ['enp3s0', 'wlo1'], r)
    check('IPv6 default parsed, lo and non-default routes left out', [x for x in r if ':' in x[2]] == [(1024, 'enp3s0', 'fe80::1')], r)
    check('Suricata follows the lowest-metric IPv4 route', ns['_ids_default_iface']() == 'enp3s0')

FILES.clear()
if code:
    check('no /proc/net files: no routes, no crash', ns['_proc_default_routes']() == [] and ns['_ids_default_iface']() == '')

# Nothing in the daemon runs "ip" any more.
check('no "ip" command left in locsecd.py', re.search(r"run\(\[\s*'ip'\s*,", src) is None)
check('the old warning is gone', '"ip -o addr show" gave no address' not in src)
infra = take('infrastructure_ips')
check('infrastructure addresses use the /proc/net gateways', '_proc_default_routes()' in infra)

print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)
