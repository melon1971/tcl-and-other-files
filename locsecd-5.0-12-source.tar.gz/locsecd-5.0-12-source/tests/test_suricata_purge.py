#!/usr/bin/python3
"""5.0-2: suricata.yaml on purge, and the rule-path rewrite on non-default paths.
Usage: test_suricata_purge.py path/to/locsecd.py   (no root needed; works in temporary files only)

1. locsec-suricata-setup records the sha256 of every suricata.yaml it writes, and drops the
   record once someone else has changed the file.
2. point_rules_at_suricata_update() on configurations that do not use Debian's paths.
3. The purge block of DEBIAN/postrm, run against temporary files: suricata.yaml.locsec-orig
   goes back only while suricata.yaml is still what LocSec wrote."""
import hashlib, importlib.machinery, importlib.util, os, subprocess, sys, tempfile
sys.dont_write_bytecode = True   # never leave a __pycache__ in the package tree

LOCSECD = os.path.abspath(sys.argv[1])
TREE = os.path.normpath(os.path.join(os.path.dirname(LOCSECD), '..', '..', '..'))
HELPER = os.path.join(TREE, 'usr', 'lib', 'locsecd', 'locsec-suricata-setup')
POSTRM = os.path.join(TREE, 'DEBIAN', 'postrm')

passed = failed = 0
def check(label, cond):
    global passed, failed
    if cond: passed += 1
    else: failed += 1; print('FAIL:', label)

sha = lambda b: hashlib.sha256(b).hexdigest()
loader = importlib.machinery.SourceFileLoader('suricata_setup', HELPER)
spec = importlib.util.spec_from_loader('suricata_setup', loader)
h = importlib.util.module_from_spec(spec); loader.exec_module(h)
h.config_test = lambda path: (True, 'ok')

# ---- 1. the restore record ----
d = tempfile.mkdtemp()
h.CONF = os.path.join(d, 'suricata.yaml'); h.BACKUP = h.CONF + '.locsec-orig'
h.STATE = os.path.join(d, 'state', 'suricata-setup.json'); h.RESTORE = os.path.join(d, 'state', 'suricata-restore.sha256')
ORIG = b'af-packet:\n  - interface: eth0\n'
open(h.CONF, 'wb').write(ORIG)
rec = lambda: open(h.RESTORE).read() if os.path.exists(h.RESTORE) else None
check('first edit writes', h.write_checked(['af-packet:', '  - interface: enp1s0'], 'test'))
check('first edit keeps the original as .locsec-orig', open(h.BACKUP, 'rb').read() == ORIG)
check('first edit records the new file', rec() == f'{sha(open(h.CONF, "rb").read())}  {h.CONF}\n')
h.write_checked(['af-packet:', '  - interface: wlp2s0'], 'test')
check('a second LocSec edit updates the record', rec() == f'{sha(open(h.CONF, "rb").read())}  {h.CONF}\n')
open(h.CONF, 'a').write('# the administrator was here\n')
h.write_checked(['af-packet:', '  - interface: enp1s0', '# the administrator was here'], 'test')
check('an edit after the administrator\'s drops the record', rec() is None)
h.write_checked(['af-packet:', '  - interface: wlp2s0', '# the administrator was here'], 'test')
check('and it does not come back', rec() is None)
check('the original is never overwritten', open(h.BACKUP, 'rb').read() == ORIG)
h.config_test = lambda path: (False, 'rejected')
open(h.CONF, 'wb').write(ORIG); os.unlink(h.BACKUP)
check('a rejected edit changes nothing', not h.write_checked(['x: 1'], 'test') and open(h.CONF, 'rb').read() == ORIG)
h.config_test = lambda path: (True, 'ok')

# ---- 2. rule paths that are not Debian's ----
def rewrite(text):
    return '\n'.join(h.point_rules_at_suricata_update(text.split('\n')))
cases = {
    'custom path, block list, comments after': (
        'vars:\n  HOME_NET: any\n\ndefault-rule-path: /usr/local/etc/suricata/rules\n\nrule-files:\n'
        '  - local.rules\n  - emerging-scan.rules\n  # - disabled.rules\n\n# Classification\n'
        'classification-file: /usr/local/etc/suricata/classification.config\n'),
    'quoted path and quoted files': (
        'default-rule-path: "/opt/rules"\nrule-files:\n  - "a.rules"\n  - \'b.rules\'\nreference-config-file: /opt/ref\n'),
    'inline list': ('default-rule-path: /srv/ids/rules\nrule-files: [a.rules, b.rules]\noutputs: []\n'),
    'inline list with a comment': ('default-rule-path: /srv/ids/rules\nrule-files: [a.rules] # ours\nlogging: {}\n'),
    'no rule-files at all': ('default-rule-path: /srv/ids/rules\noutputs: []\n'),
    'no default-rule-path at all': ('rule-files:\n  - /abs/path/x.rules\nlogging: {}\n'),
}
for name, text in cases.items():
    out = rewrite(text)
    lines = out.split('\n')
    path, files = h.rules_loaded_by(lines)
    check(f'{name}: loads only suricata-update\'s file', path == h.RULES_DIR and files == ['suricata.rules'])
    check(f'{name}: one default-rule-path and one rule-files key', sum(l.startswith('default-rule-path:') for l in lines) == 1
          and sum(l.startswith('rule-files:') for l in lines) == 1)
    kept = [l for l in text.split('\n') if l and not l.startswith(('default-rule-path:', 'rule-files:'))
            and not l.lstrip().startswith('- ')]
    check(f'{name}: every other line is kept', all(l in lines for l in kept))
    p0, f0 = h.rules_loaded_by(text.split('\n'))
    check(f'{name}: the original is read correctly', name.startswith('no ') or f0)
check('inline list is read', h.rules_loaded_by(['rule-files: [a.rules, "b.rules"]'])[1] == ['a.rules', 'b.rules'])

# ---- 3. the purge block ----
src = open(POSTRM).read()
block = src[src.index('# >>> suricata restore'):src.index('# <<< suricata restore')]
fake = tempfile.mkdtemp(); open(os.path.join(fake, 'systemctl'), 'w').write('#!/bin/sh\nexit 0\n'); os.chmod(os.path.join(fake, 'systemctl'), 0o755)
def purge(setup):
    d = tempfile.mkdtemp(); conf = os.path.join(d, 'suricata.yaml'); mark = os.path.join(d, 'mark')
    setup(conf, mark)
    sh = block.replace('/etc/suricata/suricata.yaml', conf).replace('/var/lib/locsecd-broker/suricata-restore.sha256', mark)
    r = subprocess.run(['sh', '-eu', '-c', sh], capture_output=True, text=True, env=dict(os.environ, PATH=fake + ':/usr/bin:/bin'))
    return r, conf
def lw(conf, mark, edited=False, markpath=None):
    open(conf + '.locsec-orig', 'wb').write(ORIG); open(conf, 'wb').write(b'ours\n')
    open(mark, 'w').write(f'{sha(b"ours\n")}  {markpath or conf}\n')
    if edited: open(conf, 'ab').write(b'admin\n')
r, conf = purge(lambda c, m: lw(c, m))
check(f'unchanged since LocSec: the original goes back ({r.stdout.strip()} {r.stderr.strip()})',
      r.returncode == 0 and open(conf, 'rb').read() == ORIG and not os.path.exists(conf + '.locsec-orig'))
r, conf = purge(lambda c, m: lw(c, m, edited=True))
check('changed since LocSec: both files stay', r.returncode == 0 and open(conf, 'rb').read() == b'ours\nadmin\n'
      and os.path.exists(conf + '.locsec-orig') and 'left as it is' in r.stdout)
r, conf = purge(lambda c, m: (lw(c, m), os.unlink(m)))
check('no record (an older LocSec edited it): both files stay', r.returncode == 0 and open(conf, 'rb').read() == b'ours\n'
      and os.path.exists(conf + '.locsec-orig'))
r, conf = purge(lambda c, m: lw(c, m, markpath='/etc/passwd'))
check('a record naming another file is ignored', r.returncode == 0 and open(conf, 'rb').read() == b'ours\n')
r, conf = purge(lambda c, m: (open(c, 'wb').write(b'x\n'),))
check('no .locsec-orig: nothing happens, nothing printed', r.returncode == 0 and r.stdout == '' and open(conf, 'rb').read() == b'x\n')

print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)
