#!/usr/bin/python3
"""5.0-9: the weekly checks are planned on different days, at most two per day. No root needed.
Usage: test_sched_509.py path/to/locsecd.py"""
import sys, os, time, importlib.util
os.environ['LOCSEC_INPROCESS_BROKER'] = '1'
spec = importlib.util.spec_from_file_location('locsecd_sched509', sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
W = 604800; DAY = 86400
now = time.mktime((2026, 10, 9, 15, 30, 0, 0, 0, -1))
day = lambda t: time.strftime('%Y-%m-%d', time.localtime(t))
six = ['aide', 'lynis', 'debsecan', 'rkhunter', 'ports_fw', 'cve']
# all six were run by hand on one afternoon (what the real machine showed)
last = {k: now - 3600 * (i + 1) for i, k in enumerate(six)}
p1 = m._weekly_plan(last, W, 1, 0, now)
check('one per day: six checks run on one afternoon are planned on six different days', len({day(t) for t in p1.values()}) == 6)
check('one per day: the first is planned a week after its last run', min(p1.values()) >= min(last.values()) + W)
p2 = m._weekly_plan(last, W, 2, 0, now)
days = {}
for t in p2.values(): days[day(t)] = days.get(day(t), 0) + 1
check('two per day: never more than two checks on one day', max(days.values()) <= 2)
check('two per day: six checks take three days', len(days) == 3)
check('a per-day setting above two is treated as two', max(__import__('collections').Counter(day(t) for t in m._weekly_plan(last, W, 9, 0, now).values()).values()) <= 2)
# already-spread checks keep their own days
spread = {k: now - 6 * DAY + i * DAY - 3600 for i, k in enumerate(six)}
p3 = m._weekly_plan(spread, W, 1, 0, now)
check('checks already one day apart keep one day each', len({day(t) for t in p3.values()}) == 6)
# overdue checks are planned from today, not in the past, and today's starts count
over = {k: now - 10 * DAY for k in six}
p4 = m._weekly_plan(over, W, 1, 1, now)
check('overdue checks are never planned in the past', all(t >= now for t in p4.values()))
check('a check that already started today uses up today: nothing else planned today', all(day(t) != day(now) for t in p4.values()))
p5 = m._weekly_plan(over, W, 1, 0, now)
check('with nothing started today the most overdue goes today', sorted(day(t) for t in p5.values())[0] == day(now))
check('the plan never loses a check', set(p1) == set(six) and set(p5) == set(six))
check('the setting is limited to 1..2', m.CONF_LIMITS['scan_jobs_per_day'] == (1, 2, 1) if hasattr(m, 'CONF_LIMITS') else "'scan_jobs_per_day':(1,2,1)" in open(sys.argv[1]).read())
check('the schedule page says how many start per day', "at most '+sc.weekly_per_day+' weekly check" in open(sys.argv[1]).read())
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
