#!/usr/bin/env python3
"""5.0-3: a descriptor dropped in transit, and a Lynis run whose report cannot be read.

No root needed; nothing on the system is touched. The functions under test are taken out of
locsecd.py by name (importing the whole file reads /etc/locsecd), so this runs anywhere.

In 5.0-2 the kernel dropped every descriptor passed between the two halves (AppArmor
file_receive on a "disconnected path"). The broker then hung up without reading the request,
the dashboard showed "Connection reset by peer", and a Lynis run whose report could not be
read was shown as "OK, no findings".

    python3 test_fd_transit.py PATH/locsecd.py
"""
import array, ast, json, os, re, socket, struct, sys, tempfile, time, stat

PATH = sys.argv[1] if len(sys.argv) > 1 else '/usr/lib/locsecd/locsecd.py'
src = open(PATH, encoding='utf-8').read()
tree = ast.parse(src)

def take(*names):
    """The source of the named top-level functions, classes and assignments."""
    out = []
    for node in tree.body:
        n = getattr(node, 'name', None)
        if n is None and isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
            n = node.targets[0].id
        if n in names: out.append(ast.get_source_segment(src, node))
    return '\n'.join(out)

passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('ok  ', name)
    else: failed += 1; print('FAIL', name, detail)

ns = {'os': os, 'json': json, 'socket': socket, 'struct': struct, 'array': array}
exec(take('FDDropped', '_sock_send', '_sock_recv'), ns)
check('FDDropped exists and is a ValueError', 'FDDropped' in ns and issubclass(ns['FDDropped'], ValueError))

# 1. A descriptor that does not arrive: simulated by a receive buffer with room for none,
#    which sets MSG_CTRUNC exactly as the kernel does when a security module drops one.
real_recvmsg = socket.socket.recvmsg
a, b = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
fd = os.open(os.devnull, os.O_RDONLY)
ns['_sock_send'](a, {'verb': 'capture.start', 'args': {'iface': 'any'}}, [fd])
os.close(fd)
class NoRoom(socket.socket):
    def recvmsg(self, bufsize, ancbufsize=0, flags=0):
        return real_recvmsg(self, bufsize, 0, flags)
b2 = NoRoom(fileno=b.detach())
try:
    ns['_sock_recv'](b2, 1 << 20); got = None
except Exception as e: got = e
check('dropped descriptor raises FDDropped', type(got).__name__ == 'FDDropped', repr(got))
check('the message says where to look', got is not None and 'file_receive' in str(got), str(got))
b2.setblocking(False)
try: left = b2.recv(1)
except BlockingIOError: left = None
check('the whole request was read (no reset for the client)', left is None, repr(left))

# The answer reaches the client as a refusal, not a connection reset.
ns['_sock_send'](b2, {'refused': f'refused: {got}'})
b2.close()
try: resp, fds = ns['_sock_recv'](a, 1 << 20, 1); err = None
except Exception as e: resp, err = None, e
check('client gets a refusal it can show', isinstance(resp, dict) and 'file_receive' in resp.get('refused', ''), repr(err or resp))
a.close()

# 2. A descriptor that does arrive still works.
a, b = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
fd = os.open(os.devnull, os.O_RDONLY)
ns['_sock_send'](a, {'x': 1}, [fd]); os.close(fd)
msg, fds = ns['_sock_recv'](b, 1 << 20)
check('a normal descriptor still arrives', msg == {'x': 1} and len(fds) == 1 and stat.S_ISCHR(os.fstat(fds[0]).st_mode))
for f in fds: os.close(f)
a.close(); b.close()

# 3. The broker answers a dropped descriptor instead of hanging up.
conn_src = take('_broker_conn')
check('the broker replies on FDDropped', re.search(r'except FDDropped.*?_sock_send\(conn', conn_src, re.S) is not None)

# 4. Lynis: exit code 0 but no readable report is an error, never "OK".
class _Path(str): pass
lns = {'re': re, 'os': os, 'stat': stat, 'time': time, 'have': lambda t: True,
       'CFG': {'lynis_timeout': 3600}, 'log': lambda *a, **k: None}
exec(take('_LYNIS_NOISE', '_scan_lynis'), lns)
def scan_tool(name, argv, timeout, **kw):
    return {'name': 'Lynis', 'rc': 0, 'output': '[WARNING]: Test KRNL-5820 had a long execution: 12.3 seconds'}
lns['scan_tool'] = scan_tool
def no_report(path): raise PermissionError(13, 'refused: a file descriptor sent with the message did not arrive')
lns['_priv_open'] = no_report
r = lns['_scan_lynis']()
check('Lynis without a readable report is an error', r['status'] == 'error', r['status'])
check('and says it is not a clean result', 'not a clean result' in r['output'], r['output'])

# A real report still gives "ok" with the hardening index.
tmp = tempfile.NamedTemporaryFile('wb', delete=False)
tmp.write(b'hardening_index=72\nsuggestion[]=SSH-7408|Consider hardening SSH|-|-|\n'); tmp.close()
lns['_priv_open'] = lambda p: open(tmp.name, 'rb')
r = lns['_scan_lynis']()
os.unlink(tmp.name)
check('a readable report is still ok', r['status'] == 'ok', r['status'])
check('with its hardening index', 'Hardening index: 72/100' in r['output'], r['output'])

print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)
