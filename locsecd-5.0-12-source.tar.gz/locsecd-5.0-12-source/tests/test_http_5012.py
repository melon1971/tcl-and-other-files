#!/usr/bin/python3
"""5.0-12: the dashboard page really is served (5.0-10 and 5.0-11 sent a 404 body instead, because a '#' comment
inside the one-line statement chain commented out the end of it). Starts the real request handler on a local port
and loads the page the way the desktop window does. No root needed.
Usage: test_http_5012.py path/to/locsecd.py"""
import sys, os, re, importlib.util, threading, http.client, http.server
os.environ['LOCSEC_INPROCESS_BROKER'] = '1'
spec = importlib.util.spec_from_file_location('locsecd_http5012', sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), m.Handler); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
def get(path, cookie=None, ua='Mozilla/5.0 QtWebEngine/6.8'):
    c = http.client.HTTPConnection('127.0.0.1', port, timeout=15)
    h = {'Host': '127.0.0.1:8765', 'User-Agent': ua}
    if cookie: h['Cookie'] = cookie
    c.request('GET', path, headers=h); r = c.getresponse(); body = r.read(); return r.status, dict(r.getheaders()), body
code = m.mint_login_code()
st, hd, body = get('/dashboard?code=' + code)
check('a login code is exchanged for a session cookie and a redirect to /dashboard', st == 302 and hd.get('Location') == '/dashboard' and 'Set-Cookie' in hd)
ck = hd.get('Set-Cookie', '').split(';')[0]
st, hd, body = get('/dashboard', ck)
check('the dashboard page returns 200', st == 200)
check('it is the HTML page, not an error body', body.lstrip()[:15].lower().startswith(b'<!doctype html') or b'<html' in body[:400].lower())
check('the page is big (the whole dashboard), not a short JSON error', len(body) > 100000)
check('Content-Length matches the body that was sent', int(hd.get('Content-Length', -1)) == len(body))
check('Content-Type is text/html', 'text/html' in hd.get('Content-Type', ''))
check('the page is not the not-found error', b'"error"' not in body[:200])
check('the desktop window gets a header without payment and usb', hd.get('Permissions-Policy') == 'camera=(), microphone=(), geolocation=()')
st2, hd2, body2 = get('/dashboard', ck, ua='Mozilla/5.0 (X11; Linux) Firefox/130.0')
check('another browser gets the full Permissions-Policy and the same page', hd2.get('Permissions-Policy') == 'camera=(), microphone=(), geolocation=(), payment=(), usb=()' and len(body2) == len(body))
check('the security headers are still sent', all(h in hd for h in ('X-Frame-Options', 'X-Content-Type-Options', 'Referrer-Policy', 'Cache-Control', 'Content-Security-Policy')))
st, hd, body = get('/dashboard?code=' + code)
check('a login code cannot be used twice', st in (401, 429))
st, hd, body = get('/nonexistent', ck)
check('an unknown path with a session is still a 404 JSON error', st == 404 and b'not found' in body)
# a guard against the same mistake anywhere in the file: a '#' comment in the middle of a '; '-joined line
src = open(sys.argv[1]).read().split('\n')
bad = [i + 1 for i, l in enumerate(src) if re.match(r'\s{8,}(?:self\.|data=|return )', l) and re.search(r"\)\s+#.*;\s*(?:self\.|return)", l)]
check('no line has a comment in the middle of a statement chain (the 5.0-10 bug): ' + (str(bad) if bad else 'none'), not bad)
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
