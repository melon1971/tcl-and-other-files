#!/usr/bin/env python3
"""5.0-5: packet captures reach the file through a pipe.

No root needed; nothing on the system is touched. The functions under test are taken out of
locsecd.py by name (importing the whole file reads /etc/locsecd), so this runs anywhere.

In 5.0-2 and 5.0-3 the capture unit was handed the capture file itself. Debian's tcpdump
AppArmor profile (enforce) could not name a file opened in another mount namespace by a
confined process, swapped it for a null device (file_inherit ... disconnected path), and every
capture was empty. Checked on Debian 13: 0 bytes written straight into the file, 5307 through
a pipe, under the same unit settings.

    python3 test_capture_pipe.py PATH/locsecd.py
"""
import ast, os, re, subprocess, sys, tempfile

PATH = sys.argv[1] if len(sys.argv) > 1 else '/usr/lib/locsecd/locsecd.py'
src = open(PATH, encoding='utf-8').read()
tree = ast.parse(src)

def take(*names):
    return '\n'.join(ast.get_source_segment(src, n) for n in tree.body if getattr(n, 'name', None) in names)

passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('ok  ', name)
    else: failed += 1; print('FAIL', name, detail)

LOG = []
ns = {'os': os, 'log': lambda m, lvl='INFO': LOG.append((lvl, m))}
code = take('_pump')
check('_pump exists', bool(code))
if code: exec(code, ns)

# 1. Everything a child writes into the pipe ends up in the file, in order.
if code:
    payload = os.urandom(3 * (1 << 20) + 12345)
    with tempfile.TemporaryDirectory() as d:
        fn = os.path.join(d, 'c.pcapng')
        keep = os.open(fn, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
        r, w = os.pipe()
        child = subprocess.Popen([sys.executable, '-I', '-c',
                                  'import sys; d=sys.stdin.buffer.read(); sys.stdout.buffer.write(d)'],
                                 stdin=subprocess.PIPE, stdout=w)
        os.close(w)
        dup = os.dup(keep)
        import threading
        t = threading.Thread(target=ns['_pump'], args=(r, dup)); t.start()
        child.communicate(payload); t.join(30)
        check('copier finished at end of file', not t.is_alive())
        check('the file holds every byte, in order', open(fn, 'rb').read() == payload)
        for f, what in ((r, 'read end'), (dup, 'file copy it was given')):
            try: os.fstat(f); closed = False
            except OSError: closed = True
            check(f'copier closed the {what}', closed)
        check("the caller's descriptor is still open", os.fstat(keep).st_size == len(payload))
        os.close(keep)

# 2. Error-output mode keeps only the tail and writes nothing.
if code:
    r, w = os.pipe()
    os.write(w, b'x' * 5000 + b'\ntcpdump: any: You don\'t have permission to capture on that device\n'); os.close(w)
    tail = ns['_pump'](r, None, cap=2048)
    check('keeps only the last 2048 bytes', len(tail) == 2048 and tail.endswith(b'on that device\n'))

# 3. The capture unit no longer gets the file: tcpdump's stdout is a pipe the broker copies.
start = take('_bv_capture_start')
check('capture.start found', bool(start))
check('tcpdump is not handed the capture file as stdout', 'stdout=out' not in start)
check('tcpdump writes into a pipe', re.search(r'Popen\(argv,[^)]*stdout=data_w', start) is not None)
check('the copier gets its own copy of the file descriptor', 'os.dup(keep)' in start)
check('an empty capture is logged with the reason', 'recorded nothing' in start)

print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)
