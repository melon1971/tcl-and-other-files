#!/usr/bin/python3
"""5.0-6: the ClamAV batch unit runs as the clamav user with CAP_DAC_READ_SEARCH as an ambient
capability (so it cannot write root's files), and the profile still has no mount-namespace option
(that would break clamdscan --fdpass). No root needed.
Usage: test_clamav_506.py path/to/locsecd.py"""
import sys, os, importlib.util, types, pwd
os.environ['LOCSEC_INPROCESS_BROKER'] = '1'
spec = importlib.util.spec_from_file_location('locsecd_clam506', sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
real = pwd.getpwnam
pwd.getpwnam = lambda n: types.SimpleNamespace(pw_uid=118) if n == 'clamav' else real(n)
p = m._clam_user_props()
check('with a clamav account: User=clamav', 'User=clamav' in p)
check('with a clamav account: CAP_DAC_READ_SEARCH is the only ambient capability', [x for x in p if x.startswith('AmbientCapabilities=')] == ['AmbientCapabilities=CAP_DAC_READ_SEARCH'])
def nouser(n):
    if n == 'clamav': raise KeyError(n)
    return real(n)
pwd.getpwnam = nouser
check('without a clamav account: the profile is used unchanged', m._clam_user_props() == [])
pwd.getpwnam = real
prof = m._JOB_PROFILES['clamav']
bad = [x for x in prof if x.split('=')[0] in ('ProtectSystem', 'ProtectHome', 'PrivateTmp', 'ReadWritePaths', 'ReadOnlyPaths', 'ProtectKernelTunables', 'ProtectControlGroups', 'PrivateDevices', 'MountFlags', 'BindPaths', 'TemporaryFileSystem')]
check('clamav profile has no mount-namespace option (clamdscan --fdpass needs the host mount namespace)', not bad)
check('clamav profile bounding set is CAP_DAC_READ_SEARCH only', 'CapabilityBoundingSet=CAP_DAC_READ_SEARCH' in prof)
# the batch verb passes the user properties on, after the reset of ambient capabilities
seen = {}
def fake(cmd, timeout=60, input_text=None, prefix='', props=None, profile=None, save_to=None, **kw):
    seen.update(cmd=cmd, props=list(props or []), profile=profile); return 0, ''
m._run_transient = fake
pwd.getpwnam = lambda n: types.SimpleNamespace(pw_uid=118) if n == 'clamav' else real(n)
fn = getattr(m._bv_clamav_batch, '__wrapped__', m._bv_clamav_batch)
fn('fdpass', 60, '/var/lib/locsecd-broker/work/clamav-batch-1-aaaaaaaa-1.txt', '/var/lib/locsecd-broker/work/clamav-out-1-aaaaaaaa-1.txt')
pwd.getpwnam = real
check('batch verb: clamav profile', seen.get('profile') == 'clamav')
check('batch verb: runs as clamav', 'User=clamav' in seen.get('props', []))
check('batch verb: still --fdpass', '--fdpass' in seen.get('cmd', []))
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
