#!/usr/bin/python3
"""5.0-10: the Permissions-Policy header for the desktop window, the tcpdump /dev/null denial on the Logs page,
and the sys_ptrace capability in the broker profile. No root needed.
Usage: test_5010.py path/to/locsecd.py"""
import sys, os, importlib.util
os.environ['LOCSEC_INPROCESS_BROKER'] = '1'
HERE = os.path.dirname(os.path.abspath(sys.argv[1])); ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
spec = importlib.util.spec_from_file_location('locsecd_5010', sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
F = []
def check(name, ok):
    print(('PASS  ' if ok else 'FAIL  ') + name)
    if not ok: F.append(name)
src = open(sys.argv[1]).read(); prof = open(os.path.join(ROOT, 'etc/apparmor.d/locsecd')).read()
check('the desktop window gets a Permissions-Policy without payment and usb', "if 'QtWebEngine' in (self.headers.get('User-Agent') or '')" in src and "'camera=(), microphone=(), geolocation=()' if" in src)
check('a normal browser still gets the full Permissions-Policy', "camera=(), microphone=(), geolocation=(), payment=(), usb=()'" in src)
kernel = ('audit: type=1400 audit(1791576385.1:186): apparmor="DENIED" operation="file_inherit" class="file" '
          'info="Failed name lookup - disconnected path" error=-13 profile="tcpdump" name="dev/null" pid=38641 comm="tcpdump" requested_mask="wr" denied_mask="wr" fsuid=0 ouid=0')
r = m._sys_explain('kernel', kernel, 1791576385, kernel, [])
check('tcpdump /dev/null denial is information, not a warning', r and r.get('lvl') in ('info',) or (r and 'info' in str(r)))
r2 = m._sys_explain('kernel', kernel.replace('name="dev/null"', 'name="/etc/shadow"').replace('Failed name lookup - disconnected path', ''), 1791576385, kernel, [])
check('a real tcpdump denial is still a warning', r2 and 'warn' in str(r2))
check('broker profile states sys_ptrace', 'deny capability sys_ptrace,' in prof)
check('broker profile still allows its three capabilities', all(c in prof for c in ('capability dac_read_search,', 'capability net_admin,', 'capability net_raw,')))
print(f'{len(F)} failed' if F else 'all passed'); sys.exit(1 if F else 0)
