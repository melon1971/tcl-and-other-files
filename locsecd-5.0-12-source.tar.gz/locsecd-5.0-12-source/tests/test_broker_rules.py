#!/usr/bin/python3
"""Rule tests for locsecd.py's privilege broker: every refusal must happen before any
command runs, and privileged commands must be refused outside a broker verb.
Usage: test_broker_rules.py path/to/locsecd.py   (root, throwaway container)"""
import sys, os, shutil, subprocess, importlib.util, collections
import time
# The AIDE tests use log lines stamped -05:00 and compare them with local times, so pin the clock:
# with TZ=UTC one -97 test failed for no reason in LocSec.
os.environ['TZ'] = 'America/Chicago'; time.tzset()

PATH = sys.argv[1]
REC = []
class FakeProc:
    pid = 999998; returncode = None
    def __init__(self, argv, **kw): self.args = argv
    def poll(self): return self.returncode
    def wait(self, timeout=None): return 0
    def terminate(self): self.returncode = -15
    def kill(self): self.returncode = -9
    def communicate(self, *a, **k): return (None, None)
def fake_run(argv, input=None, stdin=None, stdout=None, stderr=None, timeout=None, check=False, text=False, **kw):
    REC.append([str(x) for x in argv])
    out = b''
    if argv[:2] == ['systemctl', 'show'] and '--value' in argv: out = (argv[-1] + '\n').encode()
    if hasattr(stdout, 'write'): stdout.write(out); return subprocess.CompletedProcess(argv, 0)
    return subprocess.CompletedProcess(argv, 0, stdout=out.decode() if text else out, stderr='')
def fake_popen(argv, *a, **kw):
    REC.append([str(x) for x in argv]); return FakeProc(argv)
subprocess.run = fake_run; subprocess.Popen = fake_popen
subprocess.check_output = lambda *a, **k: ''

shutil.rmtree('/var/lib/locsecd', ignore_errors=True); shutil.rmtree('/var/lib/locsecd-broker', ignore_errors=True)
os.environ['LOCSEC_INPROCESS_BROKER'] = '1'
os.makedirs('/run/user/1000', exist_ok=True); open('/run/user/1000/bus', 'w').close()
shutil.rmtree('/run/user/1001', ignore_errors=True)
os.makedirs('/srv/t', exist_ok=True); open('/srv/t/a.txt', 'w').write('x')
if os.path.lexists('/srv/t/link'): os.unlink('/srv/t/link')
os.symlink('/etc/hostname', '/srv/t/link')

spec = importlib.util.spec_from_file_location('locsecd_rules', PATH)
m = importlib.util.module_from_spec(spec); sys.argv = [PATH]; spec.loader.exec_module(m)
m.have = lambda c: True
m.shutil.disk_usage = lambda p: collections.namedtuple('u', 'total used free')(1 << 40, 0, 1 << 40)

passed = failed = 0
def check(label, cond):
    global passed, failed
    if cond: passed += 1
    else: failed += 1; print('FAIL:', label)

def refused(label, verb, **args):
    """The verb must be refused and must not run anything."""
    REC.clear()
    r = m.broker(verb, **args)
    ok = not REC and (
        (isinstance(r, tuple) and len(r) == 2 and r[0] == 126) or r is False or r is None
        or (isinstance(r, tuple) and len(r) == 3 and r[0] is None)
        or (isinstance(r, tuple) and len(r) == 2 and isinstance(r[0], dict) and 'error' in r[0] and r[1] == 400)
        or (isinstance(r, dict) and (r.get('ok') is False or r.get('status') == 'error')))
    check(f'{label}: refused without running anything (got {str(r)[:80]}, ran {REC[:1]})', ok)

def runs(label, verb, expect, **args):
    """The verb must run, and its first command must contain these tokens in order."""
    REC.clear()
    r = m.broker(verb, **args)
    flat = [' '.join(c) for c in REC]
    check(f'{label}: ran {expect!r} (ran {flat[:2]})', any(expect in c for c in flat))
    return r

# --- the dispatcher itself ---
refused('unknown verb', 'fw.ufw.flush')
refused('unexpected argument', 'fw.ufw.enable', force=True)
refused('missing argument', 'fw.ufw.deny')
refused('bool must be a bool', 'job.quarantine_restore', qid='0123456789abcdef', overwrite='yes')

# --- firewall ---
for bad in ('0.0.0.0/0', '10.0.0.0/7', '::/0', '2001:db8::/15', '1.2.3.4; rm -rf /', '-h', '1.2.3.4 any', ''):
    refused(f'deny {bad!r}', 'fw.ufw.deny', target=bad)
    refused(f'nft add {bad!r}', 'fw.nft.add', target=bad)
runs('deny a /8', 'fw.ufw.deny', 'ufw insert 1 deny from 10.0.0.0/8', target='10.0.0.0/8')
runs('deny /32 is canonicalised', 'fw.ufw.deny', 'ufw insert 1 deny from 203.0.113.9', target='203.0.113.9/32')
runs('deny IPv6', 'fw.nft.add', 'nft add element inet locsec blocked6 { 2001:db8::/32 }', target='2001:db8::/32')
runs('undeny allows any valid net', 'fw.ufw.undeny', 'ufw delete deny from 0.0.0.0/0', target='0.0.0.0/0')
refused('undeny garbage', 'fw.ufw.undeny', target='any')
for port, proto in ((0, 'tcp'), (70000, 'tcp'), ('22 ', 'tcp'), (True, 'tcp'), (22, 'icmp'), (22, 'TCP')):
    refused(f'allow {port!r}/{proto}', 'fw.ufw.allow_port', port=port, proto=proto)
runs('allow 22/tcp', 'fw.ufw.allow_port', 'ufw allow 22/tcp', port=22, proto='tcp')
refused('ufw status detail', 'fw.ufw.status', detail='--dry-run')
refused('fallback: 9 ports', 'fw.nft.fallback_apply', ssh_ports=list(range(1, 10)))
refused('fallback: port 0', 'fw.nft.fallback_apply', ssh_ports=[0])
refused('fallback: not a list', 'fw.nft.fallback_apply', ssh_ports='22')

# --- services ---
for unit in ('-h.service', '../ssh.service', 'ssh', 'ssh.socket', 'a b.service', 'x'*130+'.service'):
    refused(f'svc unit {unit[:30]!r}', 'svc.control', unit=unit, action='start')
refused('svc action', 'svc.control', unit='clamav-daemon.service', action='mask')
REC.clear(); r = m.broker('svc.control', unit='ssh.service', action='stop')
check('protected unit refused inside the broker', r[0] == 126 and not any(c[:2] == ['systemctl', 'stop'] for c in REC))
REC.clear(); r = m.broker('svc.control', unit='cups.service', action='stop')
check('unmanaged unit refused by default', r[0] == 126 and not any(c[:2] == ['systemctl', 'stop'] for c in REC))
m.CFG['allow_manual_service_control'] = True
runs('unmanaged unit allowed when configured', 'svc.control', 'systemctl stop -- cups.service', unit='cups.service', action='stop')
m.CFG['allow_manual_service_control'] = False
runs('managed unit', 'svc.control', 'systemctl restart -- clamav-daemon.service', unit='clamav-daemon.service', action='restart')
refused('svc.fixed op', 'svc.fixed', op='ssh.stop')
refused('stop_stale: other unit', 'jobs.stop_stale', units=['ssh.service'])
refused('stop_stale: apt unit', 'jobs.stop_stale', units=['locsecd-apt-p12-deadbeef.service'])
refused('stop_stale: empty', 'jobs.stop_stale', units=[])
runs('stop_stale', 'jobs.stop_stale', 'systemctl stop -- locsecd-scan-p12-deadbeef.service', units=['locsecd-scan-p12-deadbeef.service'])

# --- packages ---
refused('apt_install: not ours', 'job.apt_install', packages=['netcat-openbsd'])
refused('apt_install: option', 'job.apt_install', packages=['-o'])
refused('apt_install: string', 'job.apt_install', packages='aide')
refused('apt_upgrade: option', 'job.apt_upgrade', packages=['-oAPT::Get::AllowUnauthenticated=1'])
refused('apt_upgrade: shell', 'job.apt_upgrade', packages=['foo;id'])
refused('apt_upgrade: empty', 'job.apt_upgrade', packages=[])
runs('apt_upgrade with arch', 'job.apt_upgrade', '--only-upgrade', packages=['libc6:i386', 'g++-12'])
runs('apt_install ours', 'job.apt_install', 'apt-get install -y --no-install-recommends clamav-daemon clamav-freshclam', packages=['clamav-daemon', 'clamav-freshclam'])

# --- files and paths ---
W = str(m.BROKER_WORK / 'aide-full-20261004-120000-deadbeef.txt')
refused('aide conf', 'job.aide_check', conf='/tmp/evil.conf', timeout=600, save_to=W)
refused('aide save_to', 'job.aide_check', conf='/etc/aide/aide.conf', timeout=600, save_to='/etc/cron.d/x')
refused('aide save_to in the unprivileged half', 'job.aide_check', conf='/etc/aide/aide.conf', timeout=600, save_to=str(m.REPORTS / 'aide-full-20261004-120000-deadbeef.txt'))
refused('aide timeout', 'job.aide_init', timeout=10)
refused('clamav list file', 'job.clamav_batch', mode='clamscan', timeout=60, batch_file='/etc/shadow',
        out_file=str(m.BROKER_WORK / 'clamav-out-1-deadbeef-1.txt'))
refused('clamav mode', 'job.clamav_batch', mode='--remove', timeout=60, batch_file=str(m.BROKER_WORK / 'clamav-batch-1-deadbeef-1.txt'),
        out_file=str(m.BROKER_WORK / 'clamav-out-1-deadbeef-1.txt'))
refused('clamav list in the unprivileged half', 'job.clamav_batch', mode='clamscan', timeout=60, batch_file=str(m.STATE / 'clamav-batch-1-deadbeef-1.txt'),
        out_file=str(m.BROKER_WORK / 'clamav-out-1-deadbeef-1.txt'))
refused('quarantine relative', 'job.quarantine', path='etc/passwd', signature='x')
refused('quarantine symlink', 'job.quarantine', path='/srv/t/link', signature='x')
refused('quarantine directory', 'job.quarantine', path='/srv/t', signature='x')
refused('quarantine missing', 'job.quarantine', path='/srv/t/nope', signature='x')
os.makedirs(str(m.QUAR), exist_ok=True); open(str(m.QUAR / 'aaaa.qf'), 'w').close()
refused('quarantine vault file', 'job.quarantine', path=str(m.QUAR / 'aaaa.qf'), signature='x')
r = runs('quarantine a file', 'job.quarantine', 'locsec-quarantine quarantine /srv/t/a.txt sig', path='/srv/t/a.txt', signature='sig\nwith newline')
check('signature control characters removed', any(c[-1] == 'sig with newline' for c in REC))
refused('restore id', 'job.quarantine_restore', qid='../../etc')
refused('clamscan file', 'scan.clamscan_file', path='/srv/t/link')
os.makedirs(str(m.CAPTURES), exist_ok=True); open(str(m.CAPTURES / 'c.pcapng'), 'wb').close()
cfd = os.open(str(m.CAPTURES / 'c.pcapng'), os.O_RDONLY)
refused('tshark: a path instead of a descriptor', 'job.tshark', mode='summary', capture='c.pcapng')
rfd, wfd = os.pipe()
refused('tshark: a pipe is not a file', 'job.tshark', mode='summary', capture=m.PassFD(rfd))
refused('tshark mode', 'job.tshark', mode='-V', capture=m.PassFD(cfd))
runs('tshark', 'job.tshark', 'tshark -n -r - -q -z io,phs', mode='summary', capture=m.PassFD(cfd))
rofd = os.open('/srv/t/a.txt', os.O_RDONLY)
refused('capture into a read-only descriptor', 'capture.start', iface='any', seconds=5, out=m.PassFD(rofd))
refused('capture into a non-empty file', 'capture.start', iface='any', seconds=5, out=m.PassFD(os.open('/srv/t/a.txt', os.O_RDWR)))
refused('aide.check: report must be writable', 'aide.check', report=m.PassFD(rofd))
for p in ('/etc/shadow', '/root/.ssh/id_rsa', '/var/log/../../etc/shadow', '/var/lib/locsecd/api.token', '/var/log/suricata/../../../etc/shadow',
          '/var/log/suricata/x.txt', 'var/log/auth.log', '/var/log/locsecd-broker/x.log'):
    refused(f'file.open {p}', 'file.open', path=p)
    refused(f'file.stat {p}', 'file.stat', path=p)
os.makedirs('/var/log/suricata', exist_ok=True)
if os.path.lexists('/var/log/suricata/evil.json'): os.unlink('/var/log/suricata/evil.json')
os.symlink('/etc/shadow', '/var/log/suricata/evil.json')
refused('file.open through a symlink', 'file.open', path='/var/log/suricata/evil.json')
open('/var/log/suricata/eve.json', 'w').write('{}\n')
fd = m.broker('file.open', path='/var/log/suricata/eve.json')
check('file.open hands over a read-only descriptor', isinstance(fd, int) and fd >= 0 and os.read(fd, 2) == b'{}'
      and (__import__('fcntl').fcntl(fd, __import__('fcntl').F_GETFL) & os.O_ACCMODE) == os.O_RDONLY)
check('file.stat', m.broker('file.stat', path='/var/log/suricata/eve.json').get('st_size') == 3)
check('file.stat of a missing file', m.broker('file.stat', path='/var/log/rkhunter.log' if not os.path.exists('/var/log/rkhunter.log') else '/var/log/suricata/none.json') == {'exists': False})
refused('net.sockets view', 'net.sockets', view='-K')
runs('net.sockets', 'net.sockets', 'ss -Hlntup', view='listening')
refused('pkg.verify option', 'pkg.verify', pkg='--root=/tmp')
runs('pkg.verify', 'pkg.verify', 'dpkg --verify openssh-server', pkg='openssh-server')
refused('quarantine.restore id', 'quarantine.restore', qid='../../x')
runs('aide dedup uses fixed paths', 'job.aide_dedup', '/var/lib/aide/aide.db.new /var/lib/aide/aide.db')
refused('ids op', 'job.ids', op='--force')

# --- desktop, capture, power ---
refused('notify uid 0', 'notify.desktop', uid=0, kind='test', title='t', body='b')
refused('notify uid without bus', 'notify.desktop', uid=1001, kind='test', title='t', body='b')
runs('notify', 'notify.desktop', 'notify-send', uid=1000, kind='test', title='t', body='<b>')
check('notify body escaped', any('&lt;b&gt;' in c for c in REC[0]))
check('notify runs as the user', any(x == '--property=User=1000' for x in REC[0]))
for bad in ('-w', '-i', 'eth0 -w /etc/x', 'x' * 40, ''):
    refused(f'capture iface {bad[:12]!r}', 'capture.start', iface=bad, seconds=60)
refused('capture seconds', 'capture.start', iface='any', seconds=99999)
def newcap(i):
    return m.PassFD(os.open(str(m.CAPTURES / f'cap{i}.pcapng'), os.O_RDWR | os.O_CREAT | os.O_TRUNC))
res = [m.broker('capture.start', iface='any', seconds=5, out=newcap(i)) for i in range(4)]
check('3 captures start', all(r[1] == 200 for r in res[:3]))
check('4th capture refused (429)', res[3][1] == 429)
# 5.0-2: tcpdump runs in its own unit and drops to the tcpdump user, not inside the broker as root.
_tcp = [c for c in REC if c[:1] == ['systemd-run'] and 'tcpdump' in c]
check('tcpdump command', bool(_tcp) and all(c[c.index('tcpdump') + 1:c.index('tcpdump') + 3] == ['-Z', 'tcpdump'] and '-i' in c for c in _tcp))
check('tcpdump unit has only its own capabilities', bool(_tcp) and all(
      '--property=CapabilityBoundingSet=CAP_NET_RAW CAP_NET_ADMIN CAP_SETUID CAP_SETGID' in c
      and '--property=BindsTo=locsecd-broker.service' in c and '--pipe' in c for c in _tcp))
check('no tcpdump started outside a unit', not any(c[:1] == ['tcpdump'] for c in REC))
check('captures are listed by inode', len(m.broker('capture.active')) == 3)
REC.clear()
check('capture.stop_all', m.broker('capture.stop_all') == 3 and m.broker('capture.active') == [])
check('capture.stop_all stops the capture units', any(c[:3] == ['systemctl', 'stop', '--no-block'] and
      sum(1 for x in c if x.startswith('locsecd-capture-p')) == 3 for c in REC))
m.ACTIVE_CAPTURES.clear()
refused('inhibit what', 'power.inhibit_start', what='shutdown', why='x')
REC.clear(); m.broker('power.inhibit_start', what='sleep', why='x'); m.broker('power.inhibit_start', what='sleep', why='x')
check('one inhibitor per client', sum(1 for c in REC if c[0] == 'systemd-inhibit') == 1)

# --- runtime guard: privileged commands outside a verb ---
def blocked(label, cmd):
    REC.clear(); r = m.run(cmd, 5)
    check(f'guard: {label}', r[0] == 126 and not REC)
for cmd in (['ufw', 'status'], ['nft', 'list', 'ruleset'], ['nice', '-n', '10', 'ionice', '-c', '3', 'ufw', 'status'],
            ['/usr/sbin/ufw', 'disable'], ['systemctl', 'restart', 'ssh.service'], ['systemctl', '--no-block', 'stop', 'x.service'],
            ['systemd-run', 'id'], ['apt-get', 'update'], ['tcpdump', '-i', 'any'], ['env', 'A=1', 'nft', 'flush', 'ruleset']):
    blocked(' '.join(cmd), cmd)
REC.clear(); r = m.run(['systemctl', 'is-active', 'x.service'], 5)
check('guard lets systemctl is-active through', REC == [['systemctl', 'is-active', 'x.service']])
REC.clear(); r = m.run(['ss', '-lntup'], 5)
check('guard lets ss through', REC == [['ss', '-lntup']])
REC.clear(); r = m._run_transient(['id'], 5)
check('guard: _run_transient outside a verb', r[0] == 126 and not REC)
REC.clear(); r = m.run_privileged(['apt-get', 'update'], 5)
check('guard: run_privileged outside a verb', r[0] == 126 and not REC)
check('catalogue lists every verb', all(v in m.broker_catalogue() for v in m._VERBS))
internal = {k for k, v in m._VERBS.items() if not v['remote']}
check('steps that need the AIDE lock or the quarantine checks are broker-internal',
      {'job.aide_init', 'job.aide_reinit', 'job.aide_accept', 'job.aide_check', 'job.aide_dedup', 'job.quarantine',
       'job.quarantine_restore', 'job.clamav_batch', 'scan.clamscan_file', 'jobs.stop_stale'} <= internal)

# the orphan-unit sweep must never ask to stop the broker itself (found on a real Debian 13 host)
_sent = []
_orig_run, _orig_broker = m.run, m.broker
m.run = lambda argv, timeout=0, **k: (0, 'locsecd-broker.service loaded active running LocSec broker\nlocsecd-scan-p999999-deadbeef.service loaded active running scan\nlocsecd-apt-p999998-deadbeef.service loaded active running apt\n')
m.broker = lambda verb, **kw: _sent.append((verb, kw))
m._sweep_orphan_units()
m.run, m.broker = _orig_run, _orig_broker
check('orphan sweep asks to stop only the stale scan unit, never the broker or an apt unit',
      _sent == [('jobs.stop_stale', {'units': ['locsecd-scan-p999999-deadbeef.service']})])

# ---- 4.0.11-93: found on a real Debian 13 host ----
# ss runs in a transient unit, so the broker (no CAP_SYS_PTRACE) still gets process names
runs('net.sockets runs ss in a transient unit', 'net.sockets', 'systemd-run', view='listening_table')
# AIDE: the snapshot time comes from the broker's aide.state, not a stat() the unprivileged side cannot do
_sv = (m._aide_db_state, m._aide_parse, m._dpkg_owners, m._pkg_activity, m.AIDE_DB)
m._aide_db_state = lambda: {'database': {'exists': True, 'mtime': 1000.0}}
m._aide_parse = lambda path: {'entries': [('added', '/etc/default/suricata')], 'details': {}, 'ts': 0, 'verdict': 'changed', 'counts': {}}
m._dpkg_owners = lambda paths: {'/etc/default/suricata': ['suricata']}
m._pkg_activity = lambda: {'suricata': 2000.0}
m.AIDE_DB = m.Path('/nonexistent/aide.db')
_a = m._aide_analyze('/x')
m._aide_db_state, m._aide_parse, m._dpkg_owners, m._pkg_activity, m.AIDE_DB = _sv
check('AIDE: a package installed after the snapshot explains its files', _a['n_explained'] == 1 and _a['baseline'] == 1000.0)
# rkhunter: LocSec's own account in adm / systemd-journal is expected; another user, or sudo, is not
_pw = m.pwd if hasattr(m, 'pwd') else None
import pwd as _pwdmod, types as _types
_real = _pwdmod.getpwnam
_pwdmod.getpwnam = lambda n: _types.SimpleNamespace(pw_uid=115, pw_shell='/usr/sbin/nologin') if n == 'locsec' else _real(n)
ok1 = m._rkhunter_classify(["Warning: Changes found in the group file for group 'adm':", "         User 'locsec' has been added to the group"])[0]
ok2 = m._rkhunter_classify(["Warning: Changes found in the group file for group 'systemd-journal':", "         User 'locsec' has been added to the group"])[0]
no1 = m._rkhunter_classify(["Warning: Changes found in the group file for group 'adm':", "         User 'mallory' has been added to the group"])[0]
no2 = m._rkhunter_classify(["Warning: Changes found in the group file for group 'sudo':", "         User 'locsec' has been added to the group"])[0]
no3 = m._rkhunter_classify(["Warning: Changes found in the group file for group 'adm':", "         User 'locsec' has been added to the group", "         User 'mallory' has been added to the group"])[0]
_pwdmod.getpwnam = _real
check('rkhunter: locsec added to adm / systemd-journal is expected', ok1 and ok2)
check('rkhunter: another user in adm, locsec in sudo, or locsec plus someone else still need review', not (no1 or no2 or no3))
_fi = m._dpkg_file_intact
m._dpkg_file_intact = lambda p: p == '/usr/sbin/rsyslogd'
okr = m._rkhunter_classify(["Warning: The file '/usr/sbin/rsyslogd' exists on the system, but it is not present in the 'rkhunter.dat' file."])[0]
nor = m._rkhunter_classify(["Warning: The file '/usr/sbin/evil' exists on the system, but it is not present in the 'rkhunter.dat' file."])[0]
m._dpkg_file_intact = _fi
check('rkhunter: a file missing from rkhunter.dat is expected only if dpkg vouches for it', okr and not nor)
# Lynis: promiscuous interface is expected only on Suricata's capture interface
_ci = m._ids_capture_ifaces
m._ids_capture_ifaces = lambda: ['wlo1']
_lo = "Warnings (2):\n - Found promiscuous interface [wlo1] [NETW-3015]\n"
def _lyn(iface):
    out = 'Hardening index: 72/100\nWarnings:\n - NETW-3015: Found promiscuous interface [%s]\n' % iface
    return [i for i in m.explain_result({'name': 'Lynis', 'status': 'warning', 'output': out, 'warnings': 1})]
_e1 = _lyn('wlo1'); _e2 = _lyn('eth9')
m._ids_capture_ifaces = _ci
def _lv(items): return [str(i) for i in items]
check('Lynis: promiscuous Suricata interface is informational', any('Suricata is listening' in x for x in _lv(_e1)) and not any('Lynis warning' in x for x in _lv(_e1)))
check('Lynis: promiscuous other interface still warns', any('Lynis warning' in x for x in _lv(_e2)))
# this machine's addresses when "ip" fails
_r = m.run
m.run = lambda argv, timeout=0, **k: (1, 'ip: failed') if argv[:1] == ['ip'] else _r(argv, timeout, **k)
m._LOCAL_ADDRS.update(ts=0.0, addrs=frozenset())
_ad = m._local_addrs()
m.run = _r
check('local addresses fall back to /proc/net when ip fails', any(not a.is_loopback for a in _ad) or not any('LOCAL' in l for l in open('/proc/net/fib_trie')))
# definitions update writes a report
_b, _h = m.broker, m.have
m.have = lambda c: c in ('rkhunter', 'freshclam')
m.broker = lambda verb, **kw: (0, 'ok') if verb.startswith('job.') else None
m.fix_rkhunter_web_cmd = lambda: None
_d = m.update_definitions()
m.broker, m.have = _b, _h
check('definitions update saves a report', 'report' in _d and os.path.exists(_d['report']))

# ---- 4.0.11-95 ----
# Lynis prints two spaces before the bracket ("Found promiscuous interface  [wlo1]")
_ci = m._ids_capture_ifaces
m._ids_capture_ifaces = lambda: ['wlo1']
_out2 = 'Hardening index: 72/100\nWarnings:\n - NETW-3015: Found promiscuous interface  [wlo1]\n'
_e3 = [str(i) for i in m.explain_result({'name': 'Lynis', 'status': 'warning', 'output': _out2, 'warnings': 1})]
m._ids_capture_ifaces = _ci
check('Lynis: real two-space output is recognised as Suricata\'s interface', any('Suricata is listening' in x for x in _e3) and not any('Lynis warning' in x for x in _e3))
# definitions report: worded as an update, not as a malware scan
_d1 = [str(i) for i in m.explain_result({'name': 'ClamAV definitions', 'status': 'up-to-date', 'rc': 1, 'output': ''})]
_d2 = [str(i) for i in m.explain_result({'name': 'rkhunter definitions', 'status': 'updated', 'rc': 2, 'output': ''})]
_d3 = [str(i) for i in m.explain_result({'name': 'ClamAV definitions', 'status': 'findings-or-error', 'rc': 62, 'output': 'Can\'t connect'})]
check('definitions report: worded as an update', any('Already up to date' in x for x in _d1) and not any('malware' in x for x in _d1)
      and any("'Updated'" in x for x in _d2) and any('Update failed' in x for x in _d3))
# Suricata rules: not reloaded again within ids_rules_min_hours, even across a restart
import threading as _th
_started = []
_orig_thread = _th.Thread
class _T:
    def __init__(self, target=None, **k): self.t = target
    def start(self): _started.append(1)
m.threading.Thread = _T
_h = m.have; m.have = lambda c: True
_stamp = getattr(m, '_IDS_RULES_STAMP', m.STATE / 'ids-rules-updated')
try:
    _stamp.parent.mkdir(parents=True, exist_ok=True)
    _stamp.write_text(str(int(m.time.time())) + '\n'); m.ids_rules_update(); fresh = len(_started)
    _stamp.write_text(str(int(m.time.time()) - 7 * 3600) + '\n'); m.ids_rules_update(); old = len(_started) - fresh
    _stamp.unlink(); m.ids_rules_update(); none = len(_started) - fresh - old
finally:
    m.threading.Thread = _orig_thread; m.have = _h
check('Suricata rules: skipped within 6 h of the last update, run when older or never', fresh == 0 and old == 1 and none == 1)

# ---- 4.0.11-96: no full scan ----
check('full scan removed: no heavy_scan, no /api/scan', not hasattr(m, 'heavy_scan') and "'/api/scan'" not in m.DASHBOARD and 'Full scan' not in m.DASHBOARD)
_btn = m.DASHBOARD
_top = _btn.find('>AIDE</button>'); _upd = _btn.find('>Update system</button>')
check('scan buttons are named plainly and come before the update buttons', ' only</button>' not in _btn and 0 <= _top < _upd
      and all(f'>{n}</button>' in _btn for n in ('AIDE', 'Lynis', 'Debsecan', 'rkhunter', 'ClamAV', 'Ports/firewall', 'CVE scan'))
      and all(f'>{n}</button>' in _btn for n in ('Update virus/rootkit definitions now', 'Build AIDE database')))

# AIDE: files a package's setup makes (found on Debian 13: .pyc, rc links, .wants links, .dpkg-old, Synaptic logs)
_sv = (m._aide_db_state, m._aide_parse, m._dpkg_owners, m._pkg_activity)
_paths = ['/usr/lib/python3/dist-packages/numpy/__pycache__/__init__.cpython-313.pyc', '/usr/lib/python3/dist-packages/numpy/__pycache__',
          '/etc/rc2.d/S01suricata', '/etc/systemd/system/multi-user.target.wants/suricata.service', '/etc/locsecd/locsecd.conf.dpkg-old',
          '/root/.config/synaptic/log/2026-10-03.212806.log',
          '/usr/lib/python3/dist-packages/oldpkg/__pycache__/x.cpython-313.pyc', '/etc/rc2.d/S01mystery', '/usr/bin/evil']
_own = {'/usr/lib/python3/dist-packages/numpy/__init__.py': ['python3-numpy'], '/usr/lib/python3/dist-packages/numpy': ['python3-numpy'],
        '/etc/init.d/suricata': ['suricata'], '/usr/lib/systemd/system/suricata.service': ['suricata'], '/etc/locsecd/locsecd.conf': ['locsecd'],
        '/usr/lib/python3/dist-packages/oldpkg/x.py': ['python3-oldpkg']}
m._aide_db_state = lambda: {'database': {'exists': True, 'mtime': m.time.mktime(m.time.strptime('2026-10-02 01:15', '%Y-%m-%d %H:%M'))}}
m._aide_parse = lambda path: {'entries': [('added', x) for x in _paths], 'details': {}, 'ts': 0, 'verdict': 'changed', 'counts': {}}
m._dpkg_owners = lambda paths: {x: _own[x] for x in paths if x in _own}
_t = m.time.mktime(m.time.strptime('2026-10-03 21:30', '%Y-%m-%d %H:%M'))
m._pkg_activity = lambda: {'python3-numpy': _t, 'suricata': _t, 'locsecd': _t, 'python3-oldpkg': 1.0}
_r = {x['path']: x['explained'] for x in m._aide_analyze('/y')['records']}
m._aide_db_state, m._aide_parse, m._dpkg_owners, m._pkg_activity = _sv
check('AIDE: byte-code, enable links, .dpkg-old and Synaptic logs of changed packages are explained',
      all(_r[x] for x in _paths[:6]))
check('AIDE: the same kinds of file for an unchanged or unknown package, and unowned files, are not',
      not any(_r[x] for x in _paths[6:]))

# ---- 4.0.11-97 ----
REC.clear(); m.broker('job.freshclam'); _fc = [' '.join(c) for c in REC]
check('freshclam runs without --quiet so its own words say what happened', any('freshclam' in c for c in _fc) and not any('freshclam --quiet' in c for c in _fc))
_ds = getattr(m, '_defs_status', None)
check('definitions status comes from the tools\' own words', _ds is not None
      and _ds('clamav', 0, 'daily.cld database is up-to-date (version: 27791)') == 'up-to-date'
      and _ds('clamav', 0, 'daily.cld updated (version: 27792, sigs: 2070000)') == 'updated'
      and _ds('clamav', 1, '') == 'up-to-date' and _ds('clamav', 0, '') == 'ok' and _ds('clamav', 62, 'x') == 'findings-or-error'
      and _ds('rkhunter', 0, '  Checking file i18n/en [ No update ]') == 'up-to-date'
      and _ds('rkhunter', 2, '  Checking file suspscan.dat [ Updated ]') == 'updated' and _ds('rkhunter', 1, '') == 'findings-or-error')
check('report labels for definitions', "'updated':'Updated'" in m.DASHBOARD and "'up-to-date':'Up to date'" in m.DASHBOARD)
_rq = m.broker('quarantine.restore', qid='../../../etc/cron.d/x')
check('restore with a malformed id says so', isinstance(_rq, dict) and _rq.get('ok') is False and 'not a quarantine item' in str(_rq.get('error')))
_eng = ['[100 - Suricata-Main] 2026-10-03 19:32:31 Error: af-packet: eth0: failed to find interface: No such device',
        '[100 - Suricata-Main] 2026-10-03 19:32:31 Warning: af-packet: eth0: failed to init socket',
        '[200 - Suricata-Main] 2026-10-03 21:44:11 Notice: threads: Threads created -> W: 4 FM: 1 FR: 1   Engine started.',
        '[200 - Suricata-Main] 2026-10-04 08:54:38 Warning: af-packet: wlo1: failed to poll interface: Network is down']
_fl = m.friendly_log('suricata-engine', _eng)
_lv = [(r['lvl'], r['title']) for r in _fl]
check('Suricata engine log: problems before the latest clean start are history, later ones still count',
      sum(1 for l, t in _lv if l == 'bad') == 0 and sum(1 for l, t in _lv if l == 'warn') == 1
      and any(t.startswith('Earlier error') for l, t in _lv))

# AIDE (-97): account files from the system log, LocSec's own files, rebuilt files, folders whose entries changed
import io as _io
_base = m.time.mktime(m.time.strptime('2026-10-02 01:15', '%Y-%m-%d %H:%M'))
_t = m.time.mktime(m.time.strptime('2026-10-03 21:30', '%Y-%m-%d %H:%M'))
def _run_aide(entries, details, auth_lines, activity):
    sv = (m._aide_db_state, m._aide_parse, m._dpkg_owners, m._pkg_activity, m._priv_open)
    m._aide_db_state = lambda: {'database': {'exists': True, 'mtime': _base}}
    m._aide_parse = lambda path: {'entries': entries, 'details': details, 'ts': 0, 'verdict': 'changed', 'counts': {}}
    m._dpkg_owners = lambda paths: {x: ['suricata'] for x in paths if x in ('/etc/init.d/suricata',)}
    m._pkg_activity = lambda: activity
    def po(path):
        if str(path) == '/var/log/auth.log': return _io.BytesIO('\n'.join(auth_lines).encode())
        raise OSError('no such file')
    m._priv_open = po
    try: return {x['path']: x for x in m._aide_analyze('/z')['records']}
    finally: m._aide_db_state, m._aide_parse, m._dpkg_owners, m._pkg_activity, m._priv_open = sv
_sys_lines = ['2026-10-03T19:30:01.123456-05:00 debian groupadd[1201]: group added to /etc/group: name=locsec, GID=120',
              '2026-10-03T19:30:01.223456-05:00 debian groupadd[1201]: group added to /etc/gshadow: name=locsec',
              '2026-10-03T19:30:01.323456-05:00 debian groupadd[1201]: new group: name=locsec, GID=120',
              '2026-10-03T19:30:01.423456-05:00 debian useradd[1202]: new user: name=locsec, UID=115, GID=120, home=/nonexistent, shell=/usr/sbin/nologin, from=none',
              "2026-10-03T19:30:01.523456-05:00 debian usermod[1203]: add 'locsec' to group 'adm'",
              "2026-10-03T19:30:01.623456-05:00 debian usermod[1203]: add 'locsec' to shadow group 'adm'"]
_acts = {'suricata': _t, 'locsecd': _t, 'python3-numpy': _t}
_ent = [('changed', '/etc/passwd'), ('changed', '/etc/shadow'), ('changed', '/etc/gshadow'), ('changed', '/etc/ld.so.cache'),
        ('changed', '/etc/locsecd/dashboard.key'), ('added', '/etc/rc2.d/S01suricata'), ('changed', '/etc/rc2.d'), ('changed', '/root')]
_det = {'/etc/rc2.d': {'mtime': ('a', 'b')}, '/root': {'mtime': ('a', 'b')}, '/etc/passwd': {'size': ('2443', '2520')}}
_r1 = _run_aide(_ent, _det, _sys_lines, _acts)
check('AIDE: account files explained when the log shows only system accounts added', all(_r1[x]['explained'] for x in ('/etc/passwd', '/etc/shadow', '/etc/gshadow')) and 'locsec' in _r1['/etc/passwd']['why'])
check('AIDE: ld.so.cache, LocSec\'s own files and a folder whose entries are explained are explained', all(_r1[x]['explained'] for x in ('/etc/ld.so.cache', '/etc/locsecd/dashboard.key', '/etc/rc2.d')))
check('AIDE: a folder with no explained entries inside is not', not _r1['/root']['explained'])
_r2 = _run_aide(_ent, _det, _sys_lines + ['2026-10-03T20:00:00.000000-05:00 debian passwd[1300]: pam_unix(passwd:chauthtok): password changed for smelon',
                                         '2026-10-03T20:01:00.000000-05:00 debian useradd[1301]: new user: name=intruder, UID=1001, GID=1001, home=/home/intruder, shell=/bin/bash, from=/dev/pts/1'], _acts)
check('AIDE: a password change or a new login account keeps the account files as warnings and names them',
      not _r2['/etc/shadow']['explained'] and _r2['/etc/shadow']['lvl'] == 'warn' and 'smelon' in _r2['/etc/shadow']['why'] and 'intruder' in _r2['/etc/passwd']['why'])
_r3 = _run_aide(_ent, _det, [], _acts)
check('AIDE: account files never get "quarantine it" advice, with or without the log',
      all('quarantine it on' not in r[x]['fix'] and 'Do not' in r[x]['fix'] for r in (_r2, _r3) for x in ('/etc/passwd', '/etc/shadow')))

# ---- 4.0.11-98: refusal log lines ----
_logged = []; _svlog = m.log
m.log = lambda msg, level='INFO': _logged.append((level, str(msg)))
try:
    m.broker('file.open', path='/etc/shadow')
    m.broker('file.open', path='/etc/x\n2026-01-01 INFO forged\x1b[31m' + 'A' * 400)
    m.broker('fw.ufw.deny', target='0.0.0.0/0')
    m.broker('fw.ufw.flush')
finally:
    m.log = _svlog
_ref = [t for l, t in _logged if 'privilege broker: refused' in t]
_who = f'from pid {os.getpid()} uid {os.getuid()}'
check('every refusal names the caller\'s pid and uid', len(_ref) == 4 and all(_who in t for t in _ref))
check('file.open refusal names the path', any("path: '/etc/shadow' is not a file LocSec reads" in t for t in _ref))
check('a crafted path is escaped and cut short in the log',
      any('\\n2026-01-01 INFO forged\\x1b[31m' in t and '...' in t and 'A' * 200 not in t for t in _ref)
      and not any('\n' in t or '\x1b' in t for t in _ref))
check('argument-check refusal names the caller', any(t.startswith(f'privilege broker: refused fw.ufw.deny {_who} (in-process): target:') for t in _ref))
_src = open(PATH).read()
check('fd-for-plain-argument wording', "must be a plain value, not a file descriptor" in _src and 'is not a file descriptor argument' not in _src)
_units = os.path.join(os.path.dirname(os.path.abspath(PATH)), '..', '..', '..', 'lib', 'systemd', 'system')
if os.path.isdir(_units):
    check('broker unit sets SyslogIdentifier=locsecd-broker', 'SyslogIdentifier=locsecd-broker\n' in open(os.path.join(_units, 'locsecd-broker.service')).read())
    check('daemon unit sets SyslogIdentifier=locsecd', 'SyslogIdentifier=locsecd\n' in open(os.path.join(_units, 'locsecd.service')).read())

# ---- 4.0.11-99: desktop notifications, Fix it on a lifted block ----
# The daemon runs as locsec with ProtectHome=true and cannot see /run/user. A session must be found
# from loginctl alone; the broker checks the session bus.
_svrun = m.run
def _fake_run(cmd, *a, **k):
    if cmd[:2] == ['loginctl', 'list-sessions']: return 0, '7 4242 someone seat0 tty2\n'
    if cmd[:2] == ['loginctl', 'show-session']: return 0, 'Type=wayland\nActive=yes\nRemote=no\n'
    return _svrun(cmd, *a, **k)
m.run = _fake_run
try: _du = m._desktop_users()
finally: m.run = _svrun
check('a GNOME/Wayland session is found without looking in /run/user (hidden from the daemon)',
      not os.path.exists('/run/user/4242') and _du == [4242])
import tempfile as _tf, json as _json
_svn = (m.NOTIFY_LOG, m._desktop_users, m._desktop_send)
m.NOTIFY_LOG = m.Path(_tf.mkdtemp()) / 'n.jsonl'
try:
    m._desktop_users = lambda: [4242]; m._desktop_send = lambda *a: False
    m._deliver_notifications([('rootkit-warning', 'x', 'y')])
    _last = _json.loads(m.NOTIFY_LOG.read_text().splitlines()[-1])
    check('a notification the desktop did not show is kept as waiting, not recorded as shown', _last.get('shown') is False)
    m._desktop_send = lambda *a: True
    m._deliver_notifications([('rootkit-warning', 'z', 'y')])
    check('a delivered notification is recorded as shown', _json.loads(m.NOTIFY_LOG.read_text().splitlines()[-1]).get('shown') is True)
finally:
    m.NOTIFY_LOG, m._desktop_users, m._desktop_send = _svn
_svb = m._is_blocked; m._is_blocked = lambda ip: False
try:
    check('no "Fix it" on a block that worked and was later lifted',
          not m.incident_can_fix({'kind': 'block', 'indicator': '203.0.113.5', 'action': 'blocked', 'state': 'new'}))
    check('"Fix it" still retries a block that failed',
          m.incident_can_fix({'kind': 'block', 'indicator': '203.0.113.5', 'action': 'failed', 'state': 'new'}))
finally:
    m._is_blocked = _svb

# ---- 4.0.11-102: ClamAV ----
_ex = m._clamav_excludes()
check('ClamAV scans leave out the quarantine vault where it is now', '^/var/lib/locsecd-broker' in _ex and '^/var/lib/locsecd/quarantine' not in _ex)
# clamd is started once the first signatures exist, but only if systemd skipped its start for want of them
_svrun, _svbr = m.run, m.broker
_made = not os.path.exists('/var/lib/clamav/main.cvd')
if _made: os.makedirs('/var/lib/clamav', exist_ok=True); open('/var/lib/clamav/main.cvd', 'w').close()
def _kick(show):
    if not hasattr(m, 'clamd_after_first_signatures'): return None
    calls = []
    m.run = lambda cmd, *a, **k: (0, show) if cmd[:2] == ['systemctl', 'show'] else _svrun(cmd, *a, **k)
    m.broker = lambda verb, **kw: calls.append((verb, kw))
    m._CLAMD_KICK.update(checked=0.0, done=False)
    try: m.clamd_after_first_signatures()
    finally: m.run, m.broker = _svrun, _svbr
    return calls
_skipped = 'ActiveState=inactive\nUnitFileState=enabled\nConditionResult=no\nConditionTimestampMonotonic=5000000\nActiveEnterTimestampMonotonic=0\n'
try:
    check('clamd skipped at install is started once signatures exist', _kick(_skipped) == [('svc.fixed', {'op': 'clamd.start'})])
    check('a clamd stopped on purpose is left stopped', _kick(_skipped.replace('ActiveEnterTimestampMonotonic=0', 'ActiveEnterTimestampMonotonic=9000000')) == [])
    check('a disabled clamd is left alone', _kick(_skipped.replace('UnitFileState=enabled', 'UnitFileState=disabled')) == [])
finally:
    if _made: os.unlink('/var/lib/clamav/main.cvd')
# postinst writes nothing to clamd.conf, and removes an older LocSec's lines only when that restores ucf's file
_pi = os.path.join(os.path.dirname(os.path.abspath(PATH)), '..', '..', '..', 'DEBIAN', 'postinst')
if os.path.exists(_pi):
    _txt = open(_pi).read()
    check('postinst does not append to clamd.conf', '>>"$CLAMD_CONF"' not in _txt and "printf 'ExcludePath" not in _txt)
    import re as _re, hashlib as _hl
    _mm = _re.search(r"<<'PYCLAMD'.*?\n(.*?)\nPYCLAMD", _txt, _re.S)
    _py = _mm.group(1) if _mm else 'pass'
    _d = _tf.mkdtemp(); _c = os.path.join(_d, 'clamd.conf'); _h = os.path.join(_d, 'hashfile')
    _orig = b'#Automatically Generated by clamav-daemon postinst\nExcludePath ^/proc/\nUser clamav\n'
    def _clean(content):
        open(_c, 'wb').write(content); open(_h, 'w').write(_hl.md5(_orig).hexdigest() + '  ' + _c + '\n')
        _sv = sys.argv; sys.argv = ['x', _c, _h]
        try: exec(compile(_py, 'postinst-clamd', 'exec'), {'__name__': '__main__'})
        except SystemExit: pass
        finally: sys.argv = _sv
        return open(_c, 'rb').read()
    check('postinst removes LocSec\'s old lines when that gives back the package\'s file',
          _clean(_orig + b'ExcludePath ^/dev/\nExcludePath ^/run/\nExcludePath ^/home/\\.ecryptfs/\n') == _orig)
    _admin = _orig + b'MaxThreads 4\nExcludePath ^/dev/\n'
    check('postinst leaves a clamd.conf the administrator also edited as it is', _clean(_admin) == _admin)

# 4.0.11-103: the units name no AppArmor profile
import re as _re2
for _n in ('locsecd.service', 'locsecd-broker.service'):
    _u = os.path.join(os.path.dirname(os.path.abspath(PATH)), '..', '..', '..', 'lib', 'systemd', 'system', _n)
    if os.path.exists(_u):
        check(_n + ' has no AppArmorProfile= line', not _re2.search(r'^AppArmorProfile=', open(_u).read(), _re2.M))

# 5.0-2: every job unit gets the capability set of its profile, never "all of them" by default
def _unit(verb, **args):
    REC.clear(); m.broker(verb, **args)
    return next((c for c in REC if c[:1] == ['systemd-run']), [])
def _prop(c, name):
    k = '--property=' + name + '='
    return [x[len(k):] for x in c if x.startswith(k)]
_cfd2 = os.open(str(m.CAPTURES / 'c2.pcapng'), os.O_RDWR | os.O_CREAT | os.O_TRUNC)
_jobs = {
    'lynis': _unit('job.lynis', timeout=600),
    'rkhunter': _unit('job.rkhunter_check'),
    'aideinit': _unit('job.aide_init', timeout=600),
    'aide_dedup': _unit('job.aide_dedup'),
    'rkhunter_conf': _unit('job.rkhunter_fix_conf'),
    'ids': _unit('job.ids', op='rules'),
    'ss': _unit('net.sockets', view='listening'),
    'tshark': _unit('job.tshark', mode='summary', capture=m.PassFD(_cfd2)),
    'apt_update': _unit('job.apt_update'),
    'apt_simulate': _unit('job.apt_simulate'),
    'freshclam': _unit('job.freshclam'),
    'apt_upgrade': _unit('job.apt_upgrade', packages=['bash']),
    'pkg_verify': _unit('pkg.verify', pkg='openssh-server'),
}
for _k, _c in _jobs.items():
    check(f'{_k}: started in a unit', bool(_c))
    check(f'{_k}: no ambient capabilities', '--property=AmbientCapabilities=' in _c and '--property=AmbientCapabilities=~' not in _c)
    _b = _prop(_c, 'CapabilityBoundingSet')
    check(f'{_k}: exactly one capability bounding set ({_b})', len(_b) == 1)
    if _k != 'apt_upgrade':
        check(f'{_k}: not every capability', _b != ['~'])
check('apt upgrade keeps every capability (dpkg is root by definition)', _prop(_jobs['apt_upgrade'], 'CapabilityBoundingSet') == ['~'])
check('tshark has no capabilities at all', _prop(_jobs['tshark'], 'CapabilityBoundingSet') == [''])
check('ss has only ptrace and read-search', _prop(_jobs['ss'], 'CapabilityBoundingSet') == ['CAP_SYS_PTRACE CAP_DAC_READ_SEARCH'])
for _k in ('lynis', 'rkhunter', 'aideinit', 'apt_update', 'apt_simulate', 'freshclam', 'ids'):
    check(f'{_k}: cannot write /usr, /boot or /etc', _prop(_jobs[_k], 'ProtectSystem') == ['full'])
    check(f'{_k}: cannot load kernel modules', 'CAP_SYS_MODULE' in _prop(_jobs[_k], 'CapabilityBoundingSet')[0]
          and _prop(_jobs[_k], 'CapabilityBoundingSet')[0].startswith('~'))
check('ids may write /etc/suricata only', _prop(_jobs['ids'], 'ReadWritePaths') == ['/etc/suricata'])
check('aide dedup writes /var/lib/aide only, with no network', _prop(_jobs['aide_dedup'], 'ProtectSystem') == ['strict']
      and _prop(_jobs['aide_dedup'], 'ReadWritePaths') == ['/var/lib/aide'] and _prop(_jobs['aide_dedup'], 'PrivateNetwork') == ['yes'])
# 5.0-3: dpkg --verify runs as root:root in a unit (the broker's group is locsec and it has no
# CAP_SETGID, so dpkg could not reset its group and every verify failed).
check('pkg.verify runs dpkg in a unit', 'dpkg' in _jobs['pkg_verify'] and '--verify' in _jobs['pkg_verify'])
check('pkg.verify unit: read-search only, no network, read-only system',
      _prop(_jobs['pkg_verify'], 'CapabilityBoundingSet') == ['CAP_DAC_READ_SEARCH']
      and _prop(_jobs['pkg_verify'], 'ProtectSystem') == ['strict'] and _prop(_jobs['pkg_verify'], 'PrivateNetwork') == ['yes']
      and not _prop(_jobs['pkg_verify'], 'Group'))
# 5.0-3: the ClamAV unit must stay in the host mount namespace, or clamd's AppArmor profile
# refuses every descriptor clamdscan --fdpass hands it.
_cl = m._JOB_PROFILES['clamav']
_mnt = ('ProtectSystem', 'ProtectHome', 'PrivateTmp', 'PrivateDevices', 'ReadWritePaths', 'ReadOnlyPaths',
        'InaccessiblePaths', 'ProtectKernelTunables', 'ProtectKernelModules', 'ProtectKernelLogs',
        'ProtectControlGroups', 'ProtectProc', 'PrivateMounts', 'TemporaryFileSystem', 'BindPaths', 'DynamicUser')
check('clamav unit has no mount-namespace option', not [p for p in _cl if p.split('=', 1)[0] in _mnt])
check('clamav unit: read-search only, localhost only',
      'CapabilityBoundingSet=CAP_DAC_READ_SEARCH' in _cl and 'IPAddressDeny=any' in _cl and 'IPAddressAllow=localhost' in _cl)
REC.clear()
_tl = getattr(m._BROKER_TLS, 'depth', 0); m._BROKER_TLS.depth = 1
try: _r = m._run_transient(['id'], 5, prefix='locsecd-priv')
finally: m._BROKER_TLS.depth = _tl
check('a job unit without a profile is refused before anything runs', _r[0] == 126 and not REC)

print(f'{passed} passed, {failed} failed')
sys.exit(1 if failed else 0)

